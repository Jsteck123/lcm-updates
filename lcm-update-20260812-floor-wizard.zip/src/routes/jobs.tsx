import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useLcmStore } from "@/store/lcm-store";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input, Select, Label } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  formatCurrency,
  formatDateTime,
  formatPercent,
  formatSeconds,
} from "@/lib/utils";
import {
  completedJobsForPart,
  computePartRunStats,
  jobVsQuote,
} from "@/lib/lcm/job-averages";
import { DEFAULT_OPERATIONS } from "@/lib/lcm/ops";
import { X, TrendingDown, TrendingUp, Minus } from "lucide-react";

export const Route = createFileRoute("/jobs")({
  component: JobsPage,
});

function JobsPage() {
  const jobs = useLcmStore((s) => s.jobs);
  const quotes = useLcmStore((s) => s.quotes);
  const maxOps =
    useLcmStore((s) => s.settings.maxOperations) || DEFAULT_OPERATIONS;
  const [status, setStatus] = useState("all");
  const [q, setQ] = useState("");
  const [selectedPart, setSelectedPart] = useState<{
    partNumber: string;
    revision: string;
  } | null>(null);

  const filtered = useMemo(() => {
    return jobs
      .filter((j) => {
        if (status !== "all" && j.status !== status) return false;
        if (!q.trim()) return true;
        const hay =
          `${j.partNumber} ${j.operator} ${j.machine} ${j.customer} ${j.revision}`.toLowerCase();
        return hay.includes(q.toLowerCase());
      })
      .sort(
        (a, b) =>
          new Date(b.startTime).getTime() - new Date(a.startTime).getTime(),
      );
  }, [jobs, status, q]);

  const partReport = useMemo(() => {
    if (!selectedPart) return null;
    const runs = completedJobsForPart(
      jobs,
      selectedPart.partNumber,
      selectedPart.revision,
    );
    const allRev = completedJobsForPart(
      jobs,
      selectedPart.partNumber,
      undefined,
    );
    const useRuns = runs.length ? runs : allRev;
    const stats = computePartRunStats(
      jobs,
      selectedPart.partNumber,
      selectedPart.revision,
      maxOps,
    );
    const quote =
      quotes.find(
        (x) =>
          x.partNumber.toUpperCase() ===
            selectedPart.partNumber.toUpperCase() &&
          (!selectedPart.revision ||
            x.revision.toUpperCase() === selectedPart.revision.toUpperCase()),
      ) ||
      quotes.find(
        (x) =>
          x.partNumber.toUpperCase() === selectedPart.partNumber.toUpperCase(),
      ) ||
      null;

    // Price at a glance from quote qty breaks
    const priceRows =
      quote?.quantities
        ?.map((qty, i) => ({
          qty: qty || 0,
          each: quote.prices?.[i] || 0,
        }))
        .filter((r) => r.qty > 0) || [];

    // Time trend: first completed vs last completed vs quote
    const ordered = [...useRuns].sort(
      (a, b) =>
        new Date(a.endTime || a.startTime).getTime() -
        new Date(b.endTime || b.startTime).getTime(),
    );
    const first = ordered[0];
    const last = ordered[ordered.length - 1];
    const firstVs = first ? jobVsQuote(first) : null;
    const lastVs = last ? jobVsQuote(last) : null;

    return {
      runs: useRuns,
      stats,
      quote,
      priceRows,
      firstVs,
      lastVs,
      first,
      last,
    };
  }, [selectedPart, jobs, quotes, maxOps]);

  return (
    <div className="mx-auto max-w-7xl space-y-5">
      <div>
        <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight">
          Job History
        </h1>
        <p className="text-sm text-[var(--color-muted)] mt-1">
          Every job run is saved here. Click a part to see all runs, shop
          averages, and quote prices for requote decisions. Completing a job
          updates that part's setup/run times in the database (rolling
          average).
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <Input
          placeholder="Filter part, operator, machine…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="sm:max-w-xs"
        />
        <div className="sm:w-48 space-y-1">
          <Label className="sr-only">Status</Label>
          <Select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="all">All statuses</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed</option>
            <option value="Downtime">Downtime</option>
          </Select>
        </div>
      </div>

      <div className="grid lg:grid-cols-12 gap-4">
        <Card className={selectedPart ? "lg:col-span-7" : "lg:col-span-12"}>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">
              {filtered.length} job{filtered.length === 1 ? "" : "s"}
            </CardTitle>
            <CardDescription>
              Click a row to open the part run report
            </CardDescription>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <table className="w-full text-sm min-w-[720px]">
              <thead>
                <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
                  <th className="pb-2 font-medium">Start</th>
                  <th className="pb-2 font-medium">Part</th>
                  <th className="pb-2 font-medium">Operator</th>
                  <th className="pb-2 font-medium">Machine</th>
                  <th className="pb-2 font-medium">Qty</th>
                  <th className="pb-2 font-medium">Q → Act</th>
                  <th className="pb-2 font-medium">Eff</th>
                  <th className="pb-2 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((j) => {
                  const eff =
                    j.efficiency > 1 ? j.efficiency / 100 : j.efficiency;
                  const vs = jobVsQuote(j);
                  const slower = vs.ratio > 1.05;
                  const faster = vs.ratio < 0.95 && vs.quotedSeconds > 0;
                  return (
                    <tr
                      key={j.id}
                      className="border-b border-[var(--color-border)] last:border-0 hover:bg-[var(--color-surface-2)] cursor-pointer"
                      onClick={() =>
                        setSelectedPart({
                          partNumber: j.partNumber,
                          revision: j.revision || "",
                        })
                      }
                    >
                      <td className="py-2 text-[var(--color-muted)] whitespace-nowrap text-xs">
                        {formatDateTime(j.startTime)}
                      </td>
                      <td className="py-2 font-medium">
                        {j.partNumber}
                        <span className="text-[var(--color-subtle)] ml-1 text-xs">
                          rev {j.revision || "—"}
                        </span>
                      </td>
                      <td className="py-2 text-xs">{j.operator || "—"}</td>
                      <td className="py-2 text-xs">{j.machine}</td>
                      <td className="py-2 tabular text-xs">
                        {j.quantityCompleted}/{j.quantity}
                      </td>
                      <td className="py-2 tabular text-xs">
                        <span className="text-[var(--color-muted)]">
                          {formatSeconds(vs.quotedSeconds)}
                        </span>
                        <span className="text-[var(--color-subtle)] mx-1">
                          →
                        </span>
                        <span
                          className={
                            slower
                              ? "text-[var(--color-danger)] font-medium"
                              : faster
                                ? "text-[var(--color-success)] font-medium"
                                : ""
                          }
                        >
                          {formatSeconds(vs.actualSeconds)}
                        </span>
                      </td>
                      <td className="py-2 tabular text-xs">
                        {formatPercent(eff)}
                      </td>
                      <td className="py-2">
                        <Badge
                          tone={
                            j.status === "Completed"
                              ? "success"
                              : j.status === "In Progress"
                                ? "info"
                                : "warn"
                          }
                        >
                          {j.status}
                        </Badge>
                      </td>
                    </tr>
                  );
                })}
                {filtered.length === 0 && (
                  <tr>
                    <td
                      colSpan={8}
                      className="py-10 text-center text-[var(--color-muted)]"
                    >
                      No jobs match.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </CardContent>
        </Card>

        {selectedPart && partReport && (
          <Card className="lg:col-span-5">
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <CardTitle className="text-base font-mono">
                    {selectedPart.partNumber}
                    <span className="text-sm font-sans font-normal text-[var(--color-muted)] ml-2">
                      rev {selectedPart.revision || "—"}
                    </span>
                  </CardTitle>
                  <CardDescription>
                    {partReport.stats.completedRuns} completed run
                    {partReport.stats.completedRuns === 1 ? "" : "s"} · avg eff{" "}
                    {formatPercent(partReport.stats.avgEfficiency)}
                  </CardDescription>
                </div>
                <Button
                  type="button"
                  size="icon"
                  variant="ghost"
                  onClick={() => setSelectedPart(null)}
                  aria-label="Close"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4 max-h-[70vh] overflow-y-auto">
              {/* At a glance */}
              <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-2">
                <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">
                  Requote at a glance
                </div>
                {partReport.quote ? (
                  <>
                    <div className="text-sm">
                      Quote in DB · {partReport.quote.customer || "—"} ·{" "}
                      {partReport.quote.date?.slice(0, 10)}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {partReport.priceRows.length === 0 && (
                        <span className="text-xs text-[var(--color-muted)]">
                          No qty/price breaks on quote
                        </span>
                      )}
                      {partReport.priceRows.map((r) => (
                        <span
                          key={r.qty}
                          className="inline-flex items-center gap-1 rounded-md border border-[var(--color-border)] px-2 py-1 text-xs tabular"
                        >
                          qty {r.qty}
                          <span className="font-semibold">
                            {formatCurrency(r.each)}
                          </span>
                          <span className="text-[var(--color-subtle)]">ea</span>
                        </span>
                      ))}
                    </div>
                    <Link
                      to="/quoting"
                      className="text-xs text-[var(--color-primary)] font-medium"
                    >
                      Open in quoter →
                    </Link>
                  </>
                ) : (
                  <p className="text-sm text-[var(--color-muted)]">
                    No quote row for this part yet — complete runs still show
                    below; add a quote to lock prices.
                  </p>
                )}

                {partReport.firstVs && partReport.lastVs && partReport.stats.completedRuns >= 2 && (
                  <div className="flex items-center gap-2 text-xs pt-1 border-t border-[var(--color-border)] mt-2">
                    {partReport.lastVs.ratio > partReport.firstVs.ratio * 1.05 ? (
                      <>
                        <TrendingUp className="h-3.5 w-3.5 text-[var(--color-danger)]" />
                        <span>
                          Runs are taking longer than earlier jobs — consider
                          raising price or process time.
                        </span>
                      </>
                    ) : partReport.lastVs.ratio < partReport.firstVs.ratio * 0.95 ? (
                      <>
                        <TrendingDown className="h-3.5 w-3.5 text-[var(--color-success)]" />
                        <span>
                          Runs are faster than earlier jobs — room to sharpen
                          price if you want.
                        </span>
                      </>
                    ) : (
                      <>
                        <Minus className="h-3.5 w-3.5 text-[var(--color-muted)]" />
                        <span>Time is fairly steady across runs.</span>
                      </>
                    )}
                  </div>
                )}
              </div>

              {/* Shop average times now on quote */}
              <div>
                <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)] mb-1.5">
                  Shop average times (in part DB after completes)
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-[var(--color-muted)] border-b border-[var(--color-border)]">
                        <th className="py-1 text-left">Op</th>
                        <th className="py-1 text-right">Avg setup</th>
                        <th className="py-1 text-right">Avg run /pc</th>
                        <th className="py-1 text-right">Quote now</th>
                      </tr>
                    </thead>
                    <tbody>
                      {Array.from({ length: maxOps }).map((_, i) => {
                        const qs = partReport.stats.avgSetupMinutes[i] || 0;
                        const qr = partReport.stats.avgRunMinutesEach[i] || 0;
                        const cq = partReport.quote?.setupTimes?.[i] || 0;
                        const cr = partReport.quote?.runTimes?.[i] || 0;
                        if (qs <= 0 && qr <= 0 && cq <= 0 && cr <= 0)
                          return null;
                        return (
                          <tr
                            key={i}
                            className="border-b border-[var(--color-border)] last:border-0"
                          >
                            <td className="py-1 font-medium">OP{i + 1}</td>
                            <td className="py-1 text-right tabular">
                              {qs ? `${qs.toFixed(1)} min` : "—"}
                            </td>
                            <td className="py-1 text-right tabular">
                              {qr ? `${qr.toFixed(1)} min` : "—"}
                            </td>
                            <td className="py-1 text-right tabular text-[var(--color-muted)]">
                              {cq || cr
                                ? `${cq.toFixed(1)} / ${cr.toFixed(1)}`
                                : "—"}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Each run */}
              <div>
                <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)] mb-1.5">
                  Each job run
                </div>
                <div className="space-y-2">
                  {partReport.runs.map((j) => {
                    const vs = jobVsQuote(j);
                    const eff =
                      j.efficiency > 1 ? j.efficiency / 100 : j.efficiency;
                    const pct =
                      vs.quotedSeconds > 0
                        ? ((vs.actualSeconds - vs.quotedSeconds) /
                            vs.quotedSeconds) *
                          100
                        : 0;
                    return (
                      <div
                        key={j.id}
                        className="rounded-md border border-[var(--color-border)] px-2.5 py-2 text-xs space-y-1"
                      >
                        <div className="flex justify-between gap-2">
                          <span className="font-medium">
                            {formatDateTime(j.endTime || j.startTime)}
                          </span>
                          <Badge
                            tone={
                              pct > 5 ? "danger" : pct < -5 ? "success" : "neutral"
                            }
                          >
                            {pct > 0 ? "+" : ""}
                            {pct.toFixed(0)}% vs quote time
                          </Badge>
                        </div>
                        <div className="text-[var(--color-muted)]">
                          {j.operator || "—"} · {j.machine} · qty{" "}
                          {j.quantityCompleted}/{j.quantity}
                        </div>
                        <div className="tabular">
                          Quoted {formatSeconds(vs.quotedSeconds)} → Actual{" "}
                          <strong>{formatSeconds(vs.actualSeconds)}</strong> ·
                          Eff {formatPercent(eff)} · Bonus{" "}
                          {formatCurrency(j.bonus)}
                        </div>
                      </div>
                    );
                  })}
                  {partReport.runs.length === 0 && (
                    <p className="text-sm text-[var(--color-muted)]">
                      No completed runs for this part yet.
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
