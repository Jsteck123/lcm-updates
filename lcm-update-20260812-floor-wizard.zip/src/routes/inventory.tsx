import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Package, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { HelpTip } from "@/components/ui/help-tip";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  allMaterials,
  allMaterialTypes,
  allStockShapes,
} from "@/lib/lcm/lists";
import {
  emptyMaterial,
  emptyPart,
  isLowStock,
  materialLabel,
  partLabel,
  EMPTY_MAT_ON_HAND_FILTERS,
  type MaterialOnHandFilters,
} from "@/lib/lcm/inventory";
import type {
  InventoryTxnType,
  MaterialStock,
  PartStock,
} from "@/lib/lcm/types";
import { uid } from "@/lib/utils";
import { computeOrderNeeds } from "@/lib/lcm/po";
import {
  stockSizeNoteOptions,
} from "@/lib/lcm/stock-size-catalog";
import { cn } from "@/lib/utils";
import { VendorRfqPanel } from "@/components/vendor-rfq-panel";
import { sizesEquivalent } from "@/lib/lcm/po-material";
import {
  MaterialStockPanel,
  PartsStockPanel,
  PiecesPanel,
  OrderNeedsPanel,
  HistoryPanel,
  MaterialBuysPanel,
  StockMoveDialog,
  StockDeleteDialog,
  type DeleteTarget,
} from "@/components/lcm/inventory";

export const Route = createFileRoute("/inventory")({
  component: InventoryPage,
});

type Tab = "material" | "parts" | "pieces" | "needs" | "rfq" | "buys" | "history";

function fieldMatch(hay: string, needle: string): boolean {
  const n = needle.trim().toLowerCase();
  if (!n) return true;
  return (hay || "").toLowerCase().includes(n);
}

function sizeFieldMatch(hay: string, needle: string): boolean {
  const n = needle.trim();
  if (!n) return true;
  if (fieldMatch(hay, n)) return true;
  return sizesEquivalent(hay || "", n);
}

function InventoryPage() {
  const materialStock = useLcmStore((s) => s.materialStock || []);
  const partStock = useLcmStore((s) => s.partStock || []);
  const inventoryTxns = useLcmStore((s) => s.inventoryTxns || []);
  const stockPieces = useLcmStore((s) => s.stockPieces || []);
  const purchaseOrders = useLcmStore((s) => s.purchaseOrders || []);
  const shopOrders = useLcmStore((s) => s.shopOrders || []);
  const createPurchaseOrder = useLcmStore((s) => s.createPurchaseOrder);
  const upsertPurchaseOrder = useLcmStore((s) => s.upsertPurchaseOrder);
  const receivePoLine = useLcmStore((s) => s.receivePoLine);
  const jobs = useLcmStore((s) => s.jobs);
  const quotes = useLcmStore((s) => s.quotes);
  const settings = useLcmStore((s) => s.settings);
  const upsertMaterialStock = useLcmStore((s) => s.upsertMaterialStock);
  const removeMaterialStock = useLcmStore((s) => s.removeMaterialStock);
  const upsertPartStock = useLcmStore((s) => s.upsertPartStock);
  const removePartStock = useLcmStore((s) => s.removePartStock);
  const inventoryMove = useLcmStore((s) => s.inventoryMove);
  const partUnits = useLcmStore((s) => s.partUnits || []);
  const getPartUnitByUin = useLcmStore((s) => s.getPartUnitByUin);
  const issuePartUnit = useLcmStore((s) => s.issuePartUnit);
  const addCustomListItem = useLcmStore((s) => s.addCustomListItem);

  const [tab, setTab] = useState<Tab>("material");
  const [q, setQ] = useState("");
  const [showLowOnly, setShowLowOnly] = useState(false);
  const [matFilters, setMatFilters] =
    useState<MaterialOnHandFilters>(EMPTY_MAT_ON_HAND_FILTERS);

  const [matForm, setMatForm] = useState(() => emptyMaterial({ id: "" }));
  const [partForm, setPartForm] = useState(() => emptyPart({ id: "" }));
  const [editingMatId, setEditingMatId] = useState<string | null>(null);
  const [editingPartId, setEditingPartId] = useState<string | null>(null);

  const [move, setMove] = useState<{
    itemKind: "material" | "part";
    itemId: string;
    label: string;
    kind: InventoryTxnType;
  } | null>(null);
  const [moveQty, setMoveQty] = useState("");
  const [moveReason, setMoveReason] = useState("");
  const [moveRef, setMoveRef] = useState("");
  const [moveAbsolute, setMoveAbsolute] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<DeleteTarget>(null);
  const [uinLookup, setUinLookup] = useState("");
  const [uinHit, setUinHit] = useState<import("@/lib/lcm/types").PartUnit | null>(null);

  const materials = allMaterials(settings.customLists);
  const shapes = allStockShapes(settings.customLists);
  const matTypes = allMaterialTypes(matForm.material, settings.customLists);

  const sizeNoteOptions = useMemo(() => {
    const catalog = stockSizeNoteOptions({
      material: matForm.material,
      materialType: matForm.materialType,
      stockShape: matForm.stockShape,
      customNotes: settings.customLists?.sizeNotes || [],
    });
    const fromStock: string[] = [];
    for (const m of materialStock) {
      if (!m.sizeNote?.trim()) continue;
      const sameMat =
        !matForm.material ||
        m.material.toLowerCase() === matForm.material.toLowerCase();
      const sameShape =
        !matForm.stockShape ||
        m.stockShape.toLowerCase() === matForm.stockShape.toLowerCase();
      if (sameMat && sameShape) fromStock.push(m.sizeNote.trim());
    }
    const seen = new Set<string>();
    const out: string[] = [];
    for (const s of [...fromStock, ...catalog]) {
      const k = s.toLowerCase();
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(s);
    }
    return out;
  }, [
    matForm.material,
    matForm.materialType,
    matForm.stockShape,
    materialStock,
    settings.customLists,
  ]);

  const partNumbers = useMemo(() => {
    const set = new Set<string>();
    for (const quote of quotes) {
      if (quote.partNumber) set.add(quote.partNumber);
      for (const b of quote.bom || []) {
        if (b.partNumber) set.add(b.partNumber);
      }
    }
    for (const p of partStock) {
      if (p.partNumber) set.add(p.partNumber);
    }
    return [...set].sort();
  }, [quotes, partStock]);

  const vendorOptions = useMemo(() => {
    const set = new Set<string>();
    for (const m of materialStock) {
      if (m.vendor?.trim()) set.add(m.vendor.trim());
    }
    for (const p of partStock) {
      if (p.vendor?.trim()) set.add(p.vendor.trim());
    }
    for (const q of quotes) {
      if (q.materialVendor?.trim()) set.add(q.materialVendor.trim());
    }
    for (const po of purchaseOrders) {
      if (po.vendor?.trim()) set.add(po.vendor.trim());
    }
    for (const d of [
      "Metal Supermarkets",
      "Ryerson",
      "Online Metals",
      "McMaster-Carr",
      "Local Steel",
    ]) {
      set.add(d);
    }
    return [...set].sort((a, b) => a.localeCompare(b));
  }, [materialStock, partStock, quotes, purchaseOrders]);

  /** Distinct values from current stock for filter typeaheads */
  const matFilterOptions = useMemo(() => {
    const materials = new Set<string>();
    const types = new Set<string>();
    const shapes = new Set<string>();
    const sizes = new Set<string>();
    const locations = new Set<string>();
    const vendors = new Set<string>();
    const searchHints = new Set<string>();

    for (const m of materialStock) {
      if (m.material?.trim()) materials.add(m.material.trim());
      if (m.materialType?.trim()) types.add(m.materialType.trim());
      if (m.stockShape?.trim()) shapes.add(m.stockShape.trim());
      if (m.sizeNote?.trim()) sizes.add(m.sizeNote.trim());
      if (m.location?.trim()) locations.add(m.location.trim());
      if (m.vendor?.trim()) vendors.add(m.vendor.trim());
      const label = materialLabel(m);
      if (label) searchHints.add(label);
      if (m.sizeNote?.trim()) searchHints.add(m.sizeNote.trim());
      if (m.location?.trim()) searchHints.add(m.location.trim());
      if (m.vendor?.trim()) searchHints.add(m.vendor.trim());
      if (m.material?.trim() && m.materialType?.trim()) {
        searchHints.add(`${m.material.trim()} ${m.materialType.trim()}`);
      }
    }

    const sort = (s: Set<string>) =>
      [...s].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));

    // Types list can narrow when a material filter is active
    let typeList = sort(types);
    if (matFilters.material.trim()) {
      const want = matFilters.material.trim().toLowerCase();
      const narrowed = new Set<string>();
      for (const m of materialStock) {
        if (m.material.toLowerCase().includes(want) && m.materialType?.trim()) {
          narrowed.add(m.materialType.trim());
        }
      }
      typeList = sort(narrowed);
    }

    // Sizes narrow by material / shape when set
    let sizeList = sort(sizes);
    if (matFilters.material.trim() || matFilters.stockShape.trim()) {
      const wantMat = matFilters.material.trim().toLowerCase();
      const wantShape = matFilters.stockShape.trim().toLowerCase();
      const narrowed = new Set<string>();
      for (const m of materialStock) {
        if (wantMat && !m.material.toLowerCase().includes(wantMat)) continue;
        if (wantShape && !m.stockShape.toLowerCase().includes(wantShape)) continue;
        if (m.sizeNote?.trim()) narrowed.add(m.sizeNote.trim());
      }
      sizeList = sort(narrowed);
    }

    return {
      materials: sort(materials),
      materialTypes: typeList,
      stockShapes: sort(shapes),
      sizeNotes: sizeList,
      locations: sort(locations),
      vendors: sort(vendors),
      searchHints: sort(searchHints),
    };
  }, [materialStock, matFilters.material, matFilters.stockShape]);

  const lowMat = materialStock.filter((m) => isLowStock(m.onHand, m.minQty));
  const lowPart = partStock.filter((p) => isLowStock(p.onHand, p.minQty));
  const needs = useMemo(
    () =>
      computeOrderNeeds({
        materialStock,
        purchaseOrders,
        shopOrders,
        jobs,
        quotes,
      }),
    [materialStock, purchaseOrders, shopOrders, jobs, quotes],
  );

  const filteredMat = useMemo(() => {
    const f = matFilters;
    const term = f.search.trim().toLowerCase();
    return materialStock.filter((m) => {
      if (f.lowOnly && !isLowStock(m.onHand, m.minQty)) return false;
      if (!fieldMatch(m.material, f.material)) return false;
      if (!fieldMatch(m.materialType, f.materialType)) return false;
      if (!fieldMatch(m.stockShape, f.stockShape)) return false;
      if (!sizeFieldMatch(m.sizeNote, f.sizeNote)) return false;
      if (!fieldMatch(m.location, f.location)) return false;
      if (!fieldMatch(m.vendor, f.vendor)) return false;
      if (!term) return true;
      const blob = [
        materialLabel(m),
        m.material,
        m.materialType,
        m.stockShape,
        m.sizeNote,
        m.location,
        m.vendor,
        m.notes,
        m.unit,
      ]
        .join(" ")
        .toLowerCase();
      if (blob.includes(term)) return true;
      // size-aware match: user typed .75 finds 3/4"
      if (sizesEquivalent(m.sizeNote || "", f.search)) return true;
      return false;
    });
  }, [materialStock, matFilters]);

  const matFilterActiveCount = useMemo(() => {
    let n = 0;
    const f = matFilters;
    if (f.search.trim()) n++;
    if (f.material.trim()) n++;
    if (f.materialType.trim()) n++;
    if (f.stockShape.trim()) n++;
    if (f.sizeNote.trim()) n++;
    if (f.location.trim()) n++;
    if (f.vendor.trim()) n++;
    if (f.lowOnly) n++;
    return n;
  }, [matFilters]);

  const filteredParts = useMemo(() => {
    const term = q.trim().toLowerCase();
    return partStock.filter((p) => {
      if (showLowOnly && !isLowStock(p.onHand, p.minQty)) return false;
      if (!term) return true;
      return (
        partLabel(p).toLowerCase().includes(term) ||
        p.category.toLowerCase().includes(term) ||
        p.location.toLowerCase().includes(term) ||
        (p.notes || "").toLowerCase().includes(term) ||
        (p.vendor || "").toLowerCase().includes(term)
      );
    });
  }, [partStock, q, showLowOnly]);

  function saveMaterial() {
    if (!matForm.material.trim()) {
      toast.error("Material required");
      return;
    }
    const id = editingMatId || uid();
    upsertMaterialStock({
      ...matForm,
      id,
      onHand: Number(matForm.onHand) || 0,
      minQty: Number(matForm.minQty) || 0,
      costPerUnit: Number(matForm.costPerUnit) || 0,
    });
    toast.success(editingMatId ? "Material updated" : "Material added");
    setMatForm(emptyMaterial({ id: "" }));
    setEditingMatId(null);
  }

  function savePart() {
    if (!partForm.partNumber.trim()) {
      toast.error("Part number required");
      return;
    }
    const id = editingPartId || uid();
    upsertPartStock({
      ...partForm,
      id,
      onHand: Number(partForm.onHand) || 0,
      minQty: Number(partForm.minQty) || 0,
      costPerUnit: Number(partForm.costPerUnit) || 0,
    });
    toast.success(editingPartId ? "Part updated" : "Part added");
    setPartForm(emptyPart({ id: "" }));
    setEditingPartId(null);
  }

  function openMove(
    itemKind: "material" | "part",
    itemId: string,
    label: string,
    kind: InventoryTxnType,
  ) {
    setMove({ itemKind, itemId, label, kind });
    setMoveQty("");
    setMoveReason("");
    setMoveRef("");
    setMoveAbsolute(kind === "adjust");
  }

  function confirmMove() {
    if (!move) return;
    const res = inventoryMove({
      itemKind: move.itemKind,
      itemId: move.itemId,
      kind: move.kind,
      qty: Number(moveQty),
      reason: moveReason,
      ref: moveRef,
      setAbsolute: move.kind === "adjust" && moveAbsolute,
    });
    if (!res.ok) {
      toast.error(res.error || "Move failed");
      return;
    }
    toast.success(`${move.kind} · balance ${res.balance} · ${move.label}`);
    setMove(null);
  }

  function editMaterial(m: MaterialStock) {
    setEditingMatId(m.id);
    setMatForm({ ...m });
    setTab("material");
  }

  function editPart(p: PartStock) {
    setEditingPartId(p.id);
    setPartForm({ ...p });
    setTab("parts");
  }

  return (
    <div className="mx-auto max-w-7xl space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight flex items-center gap-2">
            <Package className="h-7 w-7 text-[var(--color-primary)]" />
            Inventory
            <HelpTip id="inventory-scan" />
          </h1>
          <p className="text-sm text-[var(--color-muted)] mt-1">
            Material stock and extra parts / hardware. Shared across every PC on
            the shop network.
          </p>
        </div>
        <div className="flex flex-wrap gap-2 items-center">
          {lowMat.length + lowPart.length > 0 && (
            <Badge tone="hold">
              <AlertTriangle className="h-3 w-3 mr-1" />
              {lowMat.length + lowPart.length} low stock
            </Badge>
          )}
          {needs.filter((n) => n.toOrder > 0).length > 0 && (
            <Badge tone="info">
              {needs.filter((n) => n.toOrder > 0).length} to order
            </Badge>
          )}
          <Link
            to="/scan"
            search={{ c: "" }}
            className="inline-flex items-center rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2 text-sm min-h-10"
          >
            Scan stock
          </Link>
          <Link
            to="/labels"
            search={{ ids: "" }}
            className="inline-flex items-center rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2 text-sm min-h-10"
          >
            Print labels
          </Link>
          <Link
            to="/sample-label"
            className="inline-flex items-center rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2 text-sm min-h-10"
          >
            Sample label
          </Link>
          <Link
            to="/po"
            className="inline-flex items-center rounded-[var(--radius-md)] bg-[var(--color-primary)] text-[var(--color-primary-fg)] px-3 py-2 text-sm min-h-10"
          >
            Shop orders
          </Link>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {(
          [
            ["material", "Material stock"],
            ["parts", "Parts & hardware"],
            ["pieces", "Barcoded pieces"],
            ["needs", "Order needs"],
            ["rfq", "Vendor RFQs"],
            ["buys", "Material buys"],
            ["history", "History"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={cn(
              "rounded-full px-4 py-2 text-sm font-medium border min-h-10",
              tab === id
                ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)] text-[var(--color-primary)]"
                : "border-[var(--color-border)] text-[var(--color-muted)]",
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "parts" && (
        <div className="flex flex-col sm:flex-row gap-2">
          <Input
            placeholder="Search part #, category, location…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="max-w-md"
          />
          <Button
            variant={showLowOnly ? "secondary" : "outline"}
            onClick={() => setShowLowOnly((v) => !v)}
          >
            <AlertTriangle className="h-4 w-4" />
            Low only
          </Button>
        </div>
      )}

      {tab === "material" && (
        <MaterialStockPanel
          matForm={matForm}
          setMatForm={setMatForm}
          editingMatId={editingMatId}
          setEditingMatId={setEditingMatId}
          materials={materials}
          shapes={shapes}
          matTypes={matTypes}
          sizeNoteOptions={sizeNoteOptions}
          vendorOptions={vendorOptions}
          settings={settings}
          filteredMat={filteredMat}
          totalMatCount={materialStock.length}
          matFilters={matFilters}
          setMatFilters={setMatFilters}
          matFilterOptions={matFilterOptions}
          matFilterActiveCount={matFilterActiveCount}
          clearMatFilters={() => setMatFilters(EMPTY_MAT_ON_HAND_FILTERS)}
          saveMaterial={saveMaterial}
          addCustomListItem={addCustomListItem}
          openMove={openMove}
          editMaterial={editMaterial}
          setDeleteTarget={setDeleteTarget}
        />
      )}

      {tab === "parts" && (
        <PartsStockPanel
          partForm={partForm}
          setPartForm={setPartForm}
          editingPartId={editingPartId}
          setEditingPartId={setEditingPartId}
          partNumbers={partNumbers}
          vendorOptions={vendorOptions}
          filteredParts={filteredParts}
          partUnits={partUnits}
          uinLookup={uinLookup}
          setUinLookup={setUinLookup}
          uinHit={uinHit}
          setUinHit={setUinHit}
          getPartUnitByUin={getPartUnitByUin}
          issuePartUnit={issuePartUnit}
          savePart={savePart}
          openMove={openMove}
          editPart={editPart}
          setDeleteTarget={setDeleteTarget}
        />
      )}

      {tab === "pieces" && <PiecesPanel stockPieces={stockPieces} />}

      {tab === "needs" && <OrderNeedsPanel needs={needs} />}

      {tab === "rfq" && <VendorRfqPanel />}

      {tab === "buys" && (
        <MaterialBuysPanel
          purchaseOrders={purchaseOrders}
          materials={allMaterials(settings.customLists)}
          shapes={allStockShapes(settings.customLists)}
          settings={settings}
          needs={needs}
          createPurchaseOrder={createPurchaseOrder}
          upsertPurchaseOrder={upsertPurchaseOrder}
          receivePoLine={receivePoLine}
          addCustomListItem={addCustomListItem}
        />
      )}

      {tab === "history" && <HistoryPanel inventoryTxns={inventoryTxns} />}

      {move && (
        <StockMoveDialog
          move={move}
          moveQty={moveQty}
          setMoveQty={setMoveQty}
          moveReason={moveReason}
          setMoveReason={setMoveReason}
          moveRef={moveRef}
          setMoveRef={setMoveRef}
          moveAbsolute={moveAbsolute}
          setMoveAbsolute={setMoveAbsolute}
          setMove={setMove}
          confirmMove={confirmMove}
        />
      )}

      {deleteTarget && (
        <StockDeleteDialog
          deleteTarget={deleteTarget}
          setDeleteTarget={setDeleteTarget}
          removeMaterialStock={removeMaterialStock}
          removePartStock={removePartStock}
        />
      )}
    </div>
  );
}
