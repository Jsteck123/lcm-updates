import type {
  BomLine,
  BonusTier,
  JobRun,
  MachineSession,
  Operation,
  OperatorTimeEntry,
  Quote,
  QuoteKind,
  TimerType,
} from "./types";
import { parseTimeToSeconds } from "../utils";
import {
  DEFAULT_OPERATIONS,
  clampOpCount,
  nulls,
  opIndex,
  opLabel,
  padSlots,
  zeros,
} from "./ops";
import { bomRollup } from "./assembly";
import { normalizeToolingCharges } from "./quote-tooling";
import { uid } from "@/lib/utils";

/**
 * Quoting formulas.
 * machineRate is a percentage multiplier like material %:
 *   1 = actual, 1.25 = 25% markup on run cost.
 * runCost = sum(run minutes) * 2 * machinePct
 *
 * Assemblies:
 *   price = BOM child costs + bench bolt-up + final machine ops (+ material if any)
 *   setupTimes/runTimes on an assembly quote = final ops on -01 after assemble.
 */
export function calculateQuoteCosts(input: {
  rawMaterialCost: number;
  totalSize: number;
  partSize: number;
  materialPercentage: number;
  machineRate: number;
  calculateMaterialDrop: boolean;
  setupTimes: number[];
  runTimesPerPart: number[];
  quantities: number[];
  /** Assembly BOM roll-up $ per finished unit */
  bomCostPerAssembly?: number;
  /** Bench bolt/fit minutes (same $2/min as setup) */
  benchAssembleMinutes?: number;
  kind?: QuoteKind;
}) {
  const {
    rawMaterialCost,
    totalSize,
    partSize,
    materialPercentage,
    machineRate,
    calculateMaterialDrop,
    setupTimes,
    runTimesPerPart,
    quantities,
    bomCostPerAssembly = 0,
    benchAssembleMinutes = 0,
    kind = "part",
  } = input;

  const machinePct = machineRate > 0 ? machineRate : 1;

  const materialCostWithPct =
    totalSize > 0 ? (rawMaterialCost / totalSize) * partSize * materialPercentage : 0;
  const materialCostRaw =
    totalSize > 0 ? (rawMaterialCost / totalSize) * partSize : 0;

  const sumSetup = setupTimes.reduce((a, b) => a + (b || 0), 0);
  const sumRun = runTimesPerPart.reduce((a, b) => a + (b || 0), 0);
  const setupCost = sumSetup * 2;
  const runCost = sumRun * 2 * machinePct;
  const benchCost = (benchAssembleMinutes || 0) * 2;
  const bomCost = kind === "assembly" ? bomCostPerAssembly || 0 : 0;

  const baseTotal =
    setupCost + materialCostWithPct + runCost + benchCost + bomCost;

  const dropMarkups: number[] = [];
  const prices: number[] = [];

  for (let i = 0; i < 6; i++) {
    const qty = quantities[i] || 0;
    if (qty > 0) {
      const sizeUsed = partSize * qty;
      const remainder = sizeUsed <= totalSize ? totalSize - sizeUsed : 0;
      const costOfRemainder =
        totalSize > 0 ? (rawMaterialCost / totalSize) * remainder : 0;
      const matDropMarkupPerPart = costOfRemainder / qty;
      dropMarkups.push(matDropMarkupPerPart);
      // BOM + bench + run are per-assembly; setup amortized over qty
      const baseCost =
        setupCost / qty +
        runCost +
        materialCostWithPct +
        benchCost +
        bomCost;
      prices.push(calculateMaterialDrop ? baseCost + matDropMarkupPerPart : baseCost);
    } else {
      dropMarkups.push(0);
      prices.push(0);
    }
  }

  return {
    materialCostWithPct,
    materialCostRaw,
    setupCost,
    runCost,
    benchCost,
    bomCost,
    baseTotal,
    dropMarkups,
    prices,
  };
}

export function pickBonusPercentage(efficiency: number, tiers: BonusTier[]): number {
  const sorted = [...tiers].sort((a, b) => b.minEff - a.minEff);
  const match = sorted.find((t) => efficiency >= t.minEff);
  return match?.percentage ?? 0;
}

function slotCount(...arrays: (unknown[] | undefined)[]): number {
  let n = 0;
  for (const a of arrays) {
    if (a && a.length > n) n = a.length;
  }
  return n || DEFAULT_OPERATIONS;
}

export function computeJobEfficiency(job: JobRun): number {
  let earnedHours = 0;
  const n = slotCount(job.setups, job.runtimes, job.quotedSetups, job.quotedRuntimes);
  for (let i = 0; i < n; i++) {
    const setupDone =
      job.setups[i] != null && job.setups[i] !== "STARTED" && Number(job.setups[i]) > 0;
    const runDone =
      job.runtimes[i] != null &&
      job.runtimes[i] !== "STARTED" &&
      Number(job.runtimes[i]) > 0;
    if (setupDone) earnedHours += (job.quotedSetups[i] || 0) / 3600;
    if (runDone) earnedHours += ((job.quotedRuntimes[i] || 0) / 3600) * (job.quantity || 0);
  }
  const actualHours = (job.actualTime || 0) / 3600;
  if (actualHours <= 0) return 0;
  return earnedHours / actualHours;
}

export function computeJobBonus(
  job: JobRun,
  tiers: BonusTier[],
  hourlyRate: number,
): number {
  const eff = job.efficiency > 1 ? job.efficiency / 100 : job.efficiency;
  if (eff < 0.7) return 0;
  let quotedSeconds = 0;
  const n = slotCount(job.quotedSetups, job.quotedRuntimes);
  for (let i = 0; i < n; i++) {
    quotedSeconds += job.quotedSetups[i] || 0;
    quotedSeconds += (job.quotedRuntimes[i] || 0) * (job.quantity || 0);
  }
  const value = (quotedSeconds / 3600) * hourlyRate;
  return value * pickBonusPercentage(eff, tiers);
}

export function computeSessionEfficiency(session: MachineSession): number {
  let earnedHours = 0;
  let actualSeconds = 0;
  const n = slotCount(
    session.setups,
    session.runtimes,
    session.quotedSetups,
    session.quotedRuntimes,
  );
  for (let i = 0; i < n; i++) {
    const setup = session.setups[i];
    const runtime = session.runtimes[i];
    if (typeof setup === "number" && setup > 0) {
      earnedHours += (session.quotedSetups[i] || 0) / 3600;
      actualSeconds += setup;
    }
    if (typeof runtime === "number" && runtime > 0) {
      earnedHours +=
        ((session.quotedRuntimes[i] || 0) / 3600) * (session.quantity || 0);
      actualSeconds += runtime;
    }
  }
  if (actualSeconds <= 0) return 0;
  return earnedHours / (actualSeconds / 3600);
}

export function computeSessionBonus(
  session: MachineSession,
  tiers: BonusTier[],
  hourlyRate: number,
): number {
  const eff = session.efficiency;
  if (eff < 0.7) return 0;
  let quotedSeconds = 0;
  const n = slotCount(session.quotedSetups, session.quotedRuntimes);
  for (let i = 0; i < n; i++) {
    quotedSeconds += session.quotedSetups[i] || 0;
    quotedSeconds += (session.quotedRuntimes[i] || 0) * (session.quantity || 0);
  }
  const value = (quotedSeconds / 3600) * hourlyRate;
  return value * pickBonusPercentage(eff, tiers);
}

export function computeShiftBonus(
  entries: OperatorTimeEntry[],
  session: MachineSession,
  tiers: BonusTier[],
  hourlyRate: number,
): { efficiency: number; bonus: number; earnedHours: number; workedHours: number } {
  let earned = 0;
  let worked = 0;
  for (const row of entries) {
    const idx = opIndex(row.operation);
    if (row.type === "Setup") {
      earned += (session.quotedSetups[idx] || 0) / 3600;
    } else if (row.type === "Runtime") {
      earned +=
        ((session.quotedRuntimes[idx] || 0) / 3600) * (row.unitsCompleted || 0);
    }
    worked += row.durationHours || 0;
  }
  const efficiency = worked > 0 ? earned / worked : 0;
  const value = earned * hourlyRate;
  const bonus = value * pickBonusPercentage(efficiency, tiers);
  return { efficiency, bonus, earnedHours: earned, workedHours: worked };
}

function normalizeBom(bom: BomLine[] | undefined): BomLine[] {
  if (!Array.isArray(bom)) return [];
  return bom
    .map((row) => ({
      partNumber: String(row.partNumber || "").trim().toUpperCase(),
      revision: String(row.revision || "A").toUpperCase(),
      qty: Number(row.qty) > 0 ? Number(row.qty) : 1,
      note: String(row.note || ""),
    }))
    .filter((row) => row.partNumber);
}

export function quoteFromForm(
  partial: Partial<Quote> & { partNumber: string },
  maxOps = DEFAULT_OPERATIONS,
): Quote {
  const n = clampOpCount(maxOps);
  const kind: QuoteKind = partial.kind === "assembly" ? "assembly" : "part";
  return {
    id: partial.id || uid(),
    date: partial.date || new Date().toISOString(),
    customer: partial.customer || "",
    partNumber: partial.partNumber,
    revision: partial.revision || "A",
    kind,
    bom: kind === "assembly" ? normalizeBom(partial.bom) : [],
    benchAssembleMinutes:
      kind === "assembly" ? Number(partial.benchAssembleMinutes) || 0 : 0,
    machines: partial.machines || [],
    machineRate: partial.machineRate ?? 1,
    material: partial.material || "",
    materialType: partial.materialType || "",
    materialPct: partial.materialPct ?? 1,
    materialVendor: partial.materialVendor || "",
    dimX: partial.dimX ?? 0,
    dimY: partial.dimY ?? 0,
    dimZ: partial.dimZ ?? 0,
    rawMaterialLength: partial.rawMaterialLength ?? 0,
    stockShape: partial.stockShape ?? "",
    rawMaterialCost: partial.rawMaterialCost ?? 0,
    calculateMaterialDrop: partial.calculateMaterialDrop ?? false,
    dropMultiplier: partial.dropMultiplier ?? 1,
    partLengthEach: partial.partLengthEach ?? 0,
    setupTimes: padSlots(partial.setupTimes, n, 0),
    runTimes: padSlots(partial.runTimes, n, 0),
    quantities: padSlots(partial.quantities, 6, 0),
    prices: padSlots(partial.prices, 6, 0),
    toolingCharges: normalizeToolingCharges(partial.toolingCharges),
  };
}

export function emptySession(
  machine: string,
  maxOps = DEFAULT_OPERATIONS,
): MachineSession {
  const n = clampOpCount(maxOps);
  return {
    machine,
    operatorId: null,
    operatorName: "",
    jobId: null,
    partNumber: "",
    revision: "",
    quantity: 0,
    customer: "",
    loginTime: null,
    shiftStart: null,
    notes: "",
    setups: nulls(n),
    runtimes: nulls(n),
    quotedSetups: zeros(n),
    quotedRuntimes: zeros(n),
    efficiency: 0,
    bonus: 0,
    quantityCompleted: 0,
    paused: false,
    pauseStart: null,
  };
}

/**
 * Next sequential setup/runtime.
 * Walks only ops that are planned (quoted > 0) or already started.
 * If nothing is quoted (free-form job), walks every slot on the session.
 */
export function findNextOperation(session: MachineSession): {
  operation: Operation;
  type: TimerType;
} | null {
  const n = slotCount(
    session.setups,
    session.runtimes,
    session.quotedSetups,
    session.quotedRuntimes,
  );

  let anyQuoted = false;
  for (let i = 0; i < n; i++) {
    if ((session.quotedSetups[i] || 0) > 0 || (session.quotedRuntimes[i] || 0) > 0) {
      anyQuoted = true;
      break;
    }
  }

  for (let i = 0; i < n; i++) {
    const planned =
      !anyQuoted ||
      (session.quotedSetups[i] || 0) > 0 ||
      (session.quotedRuntimes[i] || 0) > 0 ||
      session.setups[i] != null ||
      session.runtimes[i] != null;

    if (!planned) continue;

    if (session.setups[i] == null) {
      return { operation: opLabel(i), type: "Setup" };
    }
    if (session.runtimes[i] == null) {
      return { operation: opLabel(i), type: "Runtime" };
    }
  }
  return null;
}

export function quotedSecondsFromQuote(q: Quote, maxOps = DEFAULT_OPERATIONS) {
  const n = clampOpCount(
    Math.max(maxOps, q.setupTimes?.length || 0, q.runTimes?.length || 0),
  );
  const setupTimes = padSlots(q.setupTimes, n, 0);
  const runTimes = padSlots(q.runTimes, n, 0);
  // Bench time is not a machine timer op — shop floor tracks machine ops only
  return {
    setups: setupTimes.map((m) => Math.round((m || 0) * 60)),
    runtimes: runTimes.map((m) => Math.round((m || 0) * 60)),
  };
}

export function totalQuotedSeconds(job: {
  quotedSetups: number[];
  quotedRuntimes: number[];
  quantity: number;
}) {
  let s = 0;
  const n = slotCount(job.quotedSetups, job.quotedRuntimes);
  for (let i = 0; i < n; i++) {
    s += job.quotedSetups[i] || 0;
    s += (job.quotedRuntimes[i] || 0) * (job.quantity || 0);
  }
  return s;
}

export function padJobArrays<T extends {
  setups?: (number | "STARTED" | null)[];
  runtimes?: (number | "STARTED" | null)[];
  quotedSetups?: number[];
  quotedRuntimes?: number[];
}>(job: T, maxOps: number): T {
  const n = clampOpCount(maxOps);
  return {
    ...job,
    setups: padSlots(job.setups as (number | null)[], n, null) as T["setups"],
    runtimes: padSlots(job.runtimes as (number | null)[], n, null) as T["runtimes"],
    quotedSetups: padSlots(job.quotedSetups, n, 0),
    quotedRuntimes: padSlots(job.quotedRuntimes, n, 0),
  };
}

/** Recompute assembly prices from live BOM + form times */
export function calculateAssemblyAwareCosts(
  form: Partial<Quote>,
  allQuotes: Quote[],
) {
  const kind = form.kind === "assembly" ? "assembly" : "part";
  const roll = bomRollup(form.bom, allQuotes);
  return calculateQuoteCosts({
    rawMaterialCost: form.rawMaterialCost || 0,
    totalSize: form.rawMaterialLength || 0,
    partSize: form.partLengthEach || 0,
    materialPercentage: form.materialPct || 1,
    machineRate: form.machineRate || 1,
    calculateMaterialDrop: !!form.calculateMaterialDrop,
    setupTimes: form.setupTimes || [],
    runTimesPerPart: form.runTimes || [],
    quantities: form.quantities || [0, 0, 0, 0, 0, 0],
    bomCostPerAssembly: roll.total,
    benchAssembleMinutes: form.benchAssembleMinutes || 0,
    kind,
  });
}

export { parseTimeToSeconds, padSlots, zeros, nulls, clampOpCount, bomRollup };
