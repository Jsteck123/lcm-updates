import { useMemo, useState } from "react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatCurrency, formatPercent } from "@/lib/utils";
import {
  currentShiftContext,
  formatWeekLabel,
  localDateKey,
  resolveWorkShifts,
  weekKeyFromDate,
} from "@/lib/lcm/day-bonus";

export function DayBonusPanel({
  operatorName,
  compact = false,
}: {
  operatorName: string;
  compact?: boolean;
}) {
  const settings = useLcmStore((s) => s.settings);
  const getDayBonusLive = useLcmStore((s) => s.getDayBonusLive);
  const finalizeDayBonus = useLcmStore((s) => s.finalizeDayBonus);
  const betaMode = useLcmStore((s) => s.settings.betaMode !== false);
  const dayBonuses = useLcmStore((s) => s.dayBonuses);
  const weeklyPayouts = useLcmStore((s) => s.weeklyPayouts);
  const jobs = useLcmStore((s) => s.jobs);
  const operatorTimeLog = useLcmStore((s) => s.operatorTimeLog);
  const operators = useLcmStore((s) => s.operators);
  const currentEmail = useLcmStore((s) => s.currentUserEmail);
  const [busy, setBusy] = useState(false);

  const shifts = useMemo(
    () => resolveWorkShifts(settings).filter((s) => s.enabled),
    [settings],
  );
  const ctx = useMemo(() => currentShiftContext(settings), [settings, jobs]);
  const [shiftId, setShiftId] = useState<string | null>(null);
  const activeShiftId = shiftId || ctx.shift.id;
  const activeShift =
    shifts.find((s) => s.id === activeShiftId) || ctx.shift || shifts[0];

  const isAdmin = useMemo(() => {
    const op = operators.find(
      (o) => o.email.toLowerCase() === currentEmail.toLowerCase(),
    );
    return op?.role === "admin";
  }, [operators, currentEmail]);

  const dateKey =
    activeShiftId === ctx.shift.id ? ctx.dateKey : localDateKey();

  const live = useMemo(() => {
    if (!operatorName || !activeShift) return null;
    return getDayBonusLive(operatorName, dateKey, activeShift.id);
  }, [
    operatorName,
    getDayBonusLive,
    dayBonuses,
    settings,
    jobs,
    operatorTimeLog,
    dateKey,
    activeShift,
  ]);

  const weekKey = weekKeyFromDate(`${dateKey}T12:00:00`);
  const finalized = dayBonuses.find(
    (r) =>
      r.operatorName === operatorName &&
      r.dateKey === dateKey &&
      (r.shiftId || "day") === activeShift.id &&
      r.status === "finalized",
  );
  const week = weeklyPayouts.find(
    (w) => w.operatorName === operatorName && w.weekKey === weekKey,
  );

  if (!operatorName) {
    return (
      <Card>
        <CardContent className="py-6 text-sm text-[var(--color-muted)]">
          Select an operator to see shift bonus progress.
        </CardContent>
      </Card>
    );
  }

  function handleFinalize(force = false) {
    setBusy(true);
    const res = finalizeDayBonus(operatorName, dateKey, {
      force,
      shiftId: activeShift.id,
    });
    setBusy(false);
    if (!res.ok) {
      toast.error(res.error || "Could not finalize");
      return;
    }
    if (res.record?.eligible) {
      toast.success(
        `${activeShift.name} locked: ${formatCurrency(res.record.bonus)} → weekly payout`,
      );
    } else {
      toast.message(
        res.record?.eligibilityReason ||
          "Shift locked — not eligible for bonus",
      );
    }
  }

  const lunch = activeShift.lunchHours ?? 1;
  const eff = finalized?.efficiency ?? live?.efficiency ?? 0;
  const bonus = finalized?.bonus ?? live?.projectedBonus ?? 0;
  const eligible = finalized?.eligible ?? live?.eligible ?? false;
  const reason = finalized?.eligibilityReason ?? live?.eligibilityReason ?? "";
  const onShift = finalized?.onShiftHours ?? live?.onShiftHours ?? 0;
  const required =
    finalized?.requiredShiftHours ?? live?.requiredShiftHours ?? 8;
  const progress = required > 0 ? Math.min(1, onShift / required) : 0;
  const outside = live?.outsideShiftHours ?? 0;

  return (
    <Card>
      <CardHeader className={compact ? "pb-2" : undefined}>
        <CardTitle className="text-base flex flex-wrap items-center gap-2">
          Shift bonus · {operatorName}
          {finalized ? (
            <Badge tone="success">Finalized</Badge>
          ) : (
            <Badge tone="neutral">Live</Badge>
          )}
        </CardTitle>
        <div className="flex flex-wrap gap-1.5 mt-2">
          {shifts.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => setShiftId(s.id)}
              className={
                "rounded-full px-3 py-1 text-xs font-medium min-h-9 border " +
                (s.id === activeShift.id
                  ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_16%,transparent)] text-[var(--color-primary)]"
                  : "border-[var(--color-border)] text-[var(--color-muted)] hover:bg-[var(--color-surface-2)]")
              }
            >
              {s.name}
              {s.id === ctx.shift.id ? " · now" : ""}
            </button>
          ))}
        </div>
        <p className="text-xs text-[var(--color-muted)] mt-2">
          {activeShift.name}: only {activeShift.start}–{activeShift.end} counts
          · {lunch}h lunch excluded ({required.toFixed(1)}h required) · full
          shift required · paid weekly ({formatWeekLabel(weekKey)})
          {activeShift.end < activeShift.start ||
          (activeShift.id === "night" && activeShift.end <= "12:00")
            ? " · overnight OK (after midnight still this shift date)"
            : ""}
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <Metric label="Shift efficiency" value={formatPercent(eff)} />
          <Metric
            label="On shift (in window)"
            value={`${onShift.toFixed(1)} / ${required.toFixed(1)} h`}
          />
          <Metric
            label="Earned hours"
            value={`${(finalized?.earnedHours ?? live?.earnedHours ?? 0).toFixed(2)} h`}
          />
          <Metric
            label={finalized ? "Shift bonus" : "Projected"}
            value={formatCurrency(bonus)}
            strong={eligible}
          />
        </div>

        <div>
          <div className="flex justify-between text-xs text-[var(--color-muted)] mb-1">
            <span>Full {activeShift.name.toLowerCase()} progress</span>
            <span>{Math.round(progress * 100)}%</span>
          </div>
          <div className="h-2 rounded-full bg-[var(--color-surface-2)] overflow-hidden">
            <div
              className="h-full rounded-full bg-[var(--color-primary)] transition-all"
              style={{ width: `${progress * 100}%` }}
            />
          </div>
        </div>

        <p className="text-xs text-[var(--color-muted)] leading-relaxed">
          {reason}
          {/* Tier / rate math is office-only — operators see progress, not formula */}
          {isAdmin && live && live.tierPct > 0 && eligible
            ? ` · Tier ${(live.tierPct * 100).toFixed(0)}% of earned-hour pool`
            : ""}
        </p>

        {outside > 0.05 && (
          <p className="text-xs text-[var(--color-warn)]">
            {outside.toFixed(1)}h outside {activeShift.start}–{activeShift.end}{" "}
            — not counted for this shift.
          </p>
        )}

        <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 text-xs text-[var(--color-muted)] space-y-1">
          <p>
            Day and night each need a{" "}
            <strong className="text-[var(--color-fg)]">full shift</strong>{" "}
            inside their own window — you can't bank 2 hours day and collect
            as if you worked all night.
          </p>
          <p>
            End of shift: stop timers → pause (End of Shift) → save →{" "}
            <strong className="text-[var(--color-fg)]">
              Finalize {activeShift.name.toLowerCase()}
            </strong>{" "}
            after {activeShift.end}.
          </p>
          <p>
            This week so far:{" "}
            <strong className="text-[var(--color-fg)]">
              {formatCurrency(week?.totalBonus || 0)}
            </strong>
            {week?.status === "paid"
              ? " · paid"
              : betaMode
                ? " · open (beta — not payroll)"
                : " · open"}
          </p>
          {isAdmin && betaMode && (
            <p className="text-[var(--color-warn)]">
              Beta mode: amounts are for training only. Turn on Production in
              Settings when bonuses should be paid for real.
            </p>
          )}
        </div>

        {!finalized && (
          <div className="flex flex-wrap gap-2">
            <Button
              onClick={() => handleFinalize(false)}
              disabled={busy || !(live?.shiftEnded)}
            >
              Finalize {activeShift.name.toLowerCase()}
            </Button>
            {isAdmin && (
              <Button
                variant="outline"
                onClick={() => handleFinalize(true)}
                disabled={busy}
              >
                Admin force finalize
              </Button>
            )}
            {!live?.shiftEnded && (
              <span className="text-xs text-[var(--color-muted)] self-center">
                Available after {activeShift.end}
              </span>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function Metric({
  label,
  value,
  strong,
}: {
  label: string;
  value: string;
  strong?: boolean;
}) {
  return (
    <div>
      <div className="text-[11px] text-[var(--color-muted)]">{label}</div>
      <div
        className={
          "text-sm font-semibold tabular " +
          (strong ? "text-[var(--color-success)]" : "")
        }
      >
        {value}
      </div>
    </div>
  );
}
