import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  BookOpen,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  ListTree,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useLcmStore } from "@/store/lcm-store";
import { getOperatorByEmail, operatorCanAccessTab } from "@/lib/lcm/permissions";
import type { AppTab } from "@/lib/lcm/types";

export const Route = createFileRoute("/help")({
  component: HelpTutorialPage,
});

/** Who may see this page in How to use. Default all. */
type GuideAudience = "all" | "floor" | "admin";

type GuidePage = {
  id: string;
  title: string;
  path: string;
  image: string;
  summary: string;
  details: string[];
  tips?: string[];
  audience?: GuideAudience;
  /** If set, only show when the signed-in user can open this tab (admins always pass). */
  tab?: AppTab;
};

/**
 * Fresh screenshots from the live app (Aug 2026 rebuild).
 *
 * Audience rules:
 * - admin → office / management only (settings, rates, pricing, bonuses, quotes)
 * - floor → shop operators only
 * - all → both, but copy must stay free of rates, markups, and management steps
 */
const PAGES: GuidePage[] = [
  {
    id: "overview",
    title: "Big picture",
    path: "/",
    image: "/tutorial/01-overview.png",
    summary:
      "One shared shop system: job board → machine timers → pack → ship.",
    details: [
      "One host PC keeps the database. Every shop computer opens the same app and stays in sync live.",
      "Your path: Job Board (pull one line) → Shop Floor timers → Done → pack → Ship Calendar labels.",
      "Status colors mean the same everywhere (sidebar legend): Hold, Open, Due soon, Overdue, Active, Ready, Done, Problem.",
      "Chat (bottom right) is for shop ↔ office on your network only.",
      "Switch user is at the bottom of the left sidebar.",
      "Your login only shows the tabs you are allowed to use.",
    ],
    tips: [
      "If a tab is missing, you do not need it for your role — ask the office if something looks wrong.",
    ],
  },
  {
    id: "dashboard",
    title: "Dashboard",
    path: "/",
    image: "/tutorial/02-dashboard.png",
    summary:
      "Home screen — what needs eyes, live floor, and your shift progress.",
    details: [
      "Shows what needs eyes first: open work, material flags, machine status.",
      "Left sidebar only shows tabs your login is allowed to use.",
      "Use Shop floor for timers and Job Board to pull the next PO line.",
      "Customer Orders (if you have it) is work coming in — shop logins do not see prices.",
      "Your day strip shows efficiency and shift progress for the job you are running.",
    ],
  },
  {
    id: "colors",
    title: "Status colors",
    path: "/board",
    image: "/tutorial/03-colors.png",
    summary:
      "Soft color language on Job Board, Ship Calendar, floor, inventory, and orders.",
    details: [
      "Hold (amber) — blocked: rev/stock not confirmed, need pack, paused, low stock.",
      "Open (green) — available / released / material OK.",
      "Due soon — due within 2 days.",
      "Overdue (red) — past the due date.",
      "Active (blue) — pulled, timer running, or packed on cart.",
      "Ready (teal) — ready for the next step (pack or ship).",
      "Done (deep green) — closed / finished.",
      "Problem (red) — out of stock or material short.",
      "Legend is always at the bottom of the left sidebar, and repeated on Job Board and Ship Calendar.",
    ],
  },
  {
    id: "customer-orders",
    title: "Customer Orders",
    path: "/po",
    image: "/tutorial/04-customer-orders.png",
    tab: "po",
    summary:
      "Customer POs into the shop — lines, material match, release to the board.",
    details: [
      "This tab is for work COMING IN (customer PO), not vendor metal buys.",
      "On-screen: customer, PO #, dates, rating, line items. The PDF is the full document.",
      "Material column: match to quote DB + inventory. Expand a line to set stock size and release checks.",
      "Release to job board: PDF rev matches · stock size noted · CAD rev if CAD is attached. Until then = Hold.",
      "Shop logins do not see prices on orders.",
      "Delete uses the in-app confirm dialog.",
    ],
    tips: [
      "After import, fix every ? material flag before releasing lines to the floor.",
    ],
  },
  {
    id: "job-board",
    title: "Job Board",
    path: "/board",
    image: "/tutorial/05-job-board.png",
    tab: "board",
    summary:
      "Digital wall board — soonest due first. Pull ONE line; other PO lines stay available.",
    details: [
      "Each card is one PO line (part, rev, qty) — not the whole PO.",
      "Hold = office has not released the line. Open = free to pull.",
      "Pull line checks it out to you (optional machine). Remaining lines on that PO stay on the board.",
      "After you pull, Load puts that part on the machine and opens Shop Floor timers.",
      "Someone else’s pull is dimmed with their name.",
      "Shop WO = traveler. Labels = PO · P/N · Rev · Qty. Drawing opens the attached PDF.",
      "Done → pack (or complete on Shop Floor) sends the line to packing and off the board.",
      "Return puts a pulled line back if you are not running it.",
    ],
    tips: [
      "Use filter Available Jobs or My Jobs on busy days.",
      "Active Jobs shows every loaded machine and live timer in one place.",
    ],
  },
  {
    id: "active-jobs",
    title: "Active Jobs",
    path: "/active",
    image: "/tutorial/06-shop-floor.png",
    tab: "active",
    summary:
      "One screen for jobs on machines — live timers, start/stop, and pulled lines waiting to load.",
    details: [
      "Shows every machine that has a job loaded, paused, or a timer running.",
      "Open machine goes to the Shop Floor pad for that machine.",
      "Start / Stop run the same smart timer as the machine page.",
      "Pulled — not loaded yet lists Job Board checkouts that still need Load.",
    ],
    tips: [
      "Pick a machine at the top if you pulled a line without choosing one.",
    ],
  },
  {
    id: "shop-floor",
    title: "Shop Floor",
    path: "/machines",
    image: "/tutorial/06-shop-floor.png",
    tab: "machines",
    summary:
      "Machines, running order, setup/runtime timers. Completing a job flags Ready for pack.",
    details: [
      "Open a machine → load job by part # / rev / qty.",
      "Run Setup then Runtime. Stop the timer before saving complete.",
      "Use Soft jaws / other timer only when making jaws or extra tooling (separate from setup/run).",
      "Complete job marks matching Customer Order lines Ready for pack automatically.",
      "Cards use status colors: Live, Paused, On job, Idle.",
      "Job details and Notes collapse while a timer is running so the controls stay front and center.",
    ],
    tips: [
      "After an app update, yellow Refresh is safe for running timers — save open forms first.",
    ],
  },
  {
    id: "ship-calendar",
    title: "Ship Calendar",
    path: "/calendar",
    image: "/tutorial/07-ship-calendar.png",
    tab: "calendar",
    summary:
      "Due-date packing calendar — slips, labels, Friday run, deliver, signed slip.",
    details: [
      "Month grid shows PO #s on each due day. Click a day for lines and quantities.",
      "Friday delivery run strip = this week’s work for Thursday/Friday packing.",
      "Print Packing slip, Ship WO (no prices), and Labels.",
      "Shop packed → Office verified (your double-check).",
      "Mark Delivered after the truck. Attach signed packing slip when you have it.",
      "Filter Ready for pack only to hide unfinished machining.",
    ],
    tips: [
      "This replaces post-it notes for “what ships Friday.”",
    ],
  },
  {
    id: "inventory",
    title: "Inventory / Buy",
    path: "/inventory",
    image: "/tutorial/08-inventory.png",
    tab: "inventory",
    summary:
      "Material & extra parts on hand, receive stock, scan to deduct.",
    details: [
      "Material stock: material, type, shape, size note, vendor, on hand, min, location.",
      "Low = amber Hold. Zero = red Out / Problem.",
      "Extra parts inventory for surplus; second-quality can use short UIN + defect note.",
      "Scan barcodes on a phone to issue length/qty used.",
      "Customer Orders material match reads this inventory against planned material.",
    ],
  },
  {
    id: "quoting",
    audience: "admin",
    tab: "quoting",
    title: "Quoting",
    path: "/quoting",
    image: "/tutorial/09-quoting.png",
    summary:
      "Master quoter — type part # to load history; shop averages help reprice.",
    details: [
      "Type Part # to filter and fill the form from the database.",
      "Material family vs type (Aluminum / T6 6061). Shape drives size fields; change shape clears them.",
      "In-box math: type 12*12 in a size field.",
      "Machine % and Material %: 1 = actual, 1.25 = 25% markup (no mouse wheel).",
      "Special tools / soft jaws bill as separate lines — not buried in the part each.",
      "More than 6 ops supported. Assemblies: -01 assembly, -02/-03 pieces, then remaining ops.",
      "Submit/Update writes the live database used by floor, material match, and email.",
    ],
    tips: [
      "Keep this tab off operator accounts if the floor should not quote.",
    ],
  },
  {
    id: "parts-db",
    audience: "admin",
    tab: "database",
    title: "Parts & Quotes",
    path: "/database",
    image: "/tutorial/10-parts-db.png",
    summary: "Browse and search the full quote/part history.",
    details: [
      "Search by part number, customer, material.",
      "Same data the quoter saves and historical CSV import fills.",
      "Usually office / admin only.",
    ],
  },
  {
    id: "email",
    audience: "admin",
    tab: "email",
    title: "Email Quotes",
    path: "/email",
    image: "/tutorial/11-email.png",
    summary:
      "Batch quotes to a customer — part #, rev, qty, price each — familiar letter layout.",
    details: [
      "Filter by customer and date quoted.",
      "Select lines, pick recipient (recent first), preview, send.",
      "Uses company logo from Settings when uploaded.",
      "Special tooling charges appear as separate lines when present on the quote.",
    ],
  },
  {
    id: "reports",
    audience: "admin",
    tab: "reports",
    title: "Reports",
    path: "/reports",
    image: "/tutorial/12-reports.png",
    summary: "Efficiency, bonuses, and completed job history for management.",
    details: [
      "See who ran what and how they compared to quote.",
      "Weekly bonus closeout — live only when Beta mode is off.",
      "Use before requoting a customer so price follows real shop evidence.",
    ],
  },
  {
    id: "settings",
    audience: "admin",
    tab: "settings",
    title: "Settings",
    path: "/settings",
    image: "/tutorial/13-settings.png",
    summary:
      "People, PINs, tabs, shifts, beta, logo, updates, CSV import, backup.",
    details: [
      "Operators & access: who can open which tabs; PIN for admin.",
      "Beta mode: practice bonuses without paying them as real until you turn beta off.",
      "Day and night shift windows, lunch, rates, efficiency tiers.",
      "Company logo for packing slips, sales orders, emails.",
      "Update app: install a zip from development without wiping the database. Floor gets a yellow Refresh banner.",
      "Import historical quotes CSV from Google Sheets after go-live.",
      "Export JSON backup on a regular schedule on the host PC.",
    ],
  },
  {
    id: "full-loop",
    title: "End-to-end loop",
    path: "/calendar",
    image: "/tutorial/14-full-loop.png",
    summary:
      "Customer PO → board → machine → pack → Friday truck → signed slip.",
    details: [
      "1) Customer PO + drawings land on Customer Orders (office often imports).",
      "2) Confirm PDF rev, stock size, optional CAD; release the line.",
      "3) If short material → flag it; office / inventory handles buy-in.",
      "4) Line appears on Job Board by due date. Operator Pulls one line.",
      "5) Shop Floor timers → complete → Ready for pack.",
      "6) Ship Calendar: packing slip + labels → Shop packed → Office verified.",
      "7) Friday run → Delivered → attach signed slip.",
      "Paper travelers can coexist with digital timers until everyone is comfortable without them.",
    ],
  },
  {
    id: "chat",
    title: "Shop Chat",
    path: "/",
    image: "/tutorial/15-chat.png",
    summary:
      "Network chat for tool requests and job questions — yellow badge when unread.",
    details: [
      "Open Chat bottom-right. Badge shows unread without opening.",
      "Shop channel for general floor traffic; pick a person for a direct message.",
      "Only people signed into this app on your network — not the public internet.",
    ],
  },
];

/** Admin-only overview extras (never shown to operators). */
const ADMIN_OVERVIEW_EXTRA: string[] = [
  "Office path: customer PO → material → release → Friday delivery → invoice / QuickBooks flags.",
  "Quoting, Email Quotes, Reports, and Settings are management tabs — keep them off floor logins.",
];

function HelpTutorialPage() {
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  const me = useMemo(
    () => getOperatorByEmail(operators, email),
    [operators, email],
  );
  const isAdmin = me?.role === "admin";

  const pages = useMemo(() => {
    return PAGES.filter((p) => {
      const aud = p.audience || "all";
      if (aud === "admin" && !isAdmin) return false;
      if (aud === "floor" && isAdmin) return false;
      // Operators only see guides for tabs they can actually open
      if (!isAdmin && p.tab && me && !operatorCanAccessTab(me, p.tab)) {
        return false;
      }
      return true;
    }).map((p) => {
      if (p.id === "overview" && isAdmin) {
        return {
          ...p,
          summary:
            "One shared shop system: quote → customer order → material → job board → machine → pack → deliver → bill.",
          details: [...p.details, ...ADMIN_OVERVIEW_EXTRA],
        };
      }
      return p;
    });
  }, [isAdmin, me]);

  const [step, setStep] = useState(0);

  // Reset/clamp when role filter changes so we never land on a hidden admin page index
  useEffect(() => {
    setStep((s) => Math.min(s, Math.max(0, pages.length - 1)));
  }, [pages.length, isAdmin]);

  const safeStep = Math.min(step, Math.max(0, pages.length - 1));
  const page = pages[safeStep] || pages[0];
  const total = pages.length;

  const summaryItems = useMemo(
    () =>
      pages.map((p) => ({
        id: p.id,
        title: p.title,
        summary: p.summary,
      })),
    [pages],
  );

  function go(delta: number) {
    setStep((s) => Math.min(total - 1, Math.max(0, s + delta)));
  }

  if (!page) {
    return (
      <div className="mx-auto max-w-5xl py-10 text-sm text-[var(--color-muted)]">
        No help pages available for this login.
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl space-y-8 pb-10">
      <div>
        <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight flex items-center gap-2">
          <BookOpen className="h-7 w-7 text-[var(--color-primary)]" />
          How to use this system
        </h1>
        <p className="text-sm text-[var(--color-muted)] mt-1 max-w-2xl">
          {isAdmin
            ? "Full walkthrough for office and management — including quoting, rates, bonuses, and Settings."
            : "Shop floor guide only. Settings, pricing, markups, and how bonuses are calculated stay with office logins."}
        </p>
        {!isAdmin && (
          <p className="text-xs text-[var(--color-subtle)] mt-2 max-w-2xl">
            You will not see pages about Settings, Reports, Quoting, Email Quotes,
            or bonus/rate setup on this guide.
          </p>
        )}
        <div className="flex flex-wrap gap-1.5 mt-3">
          <Badge tone="hold">Hold</Badge>
          <Badge tone="open">Open</Badge>
          <Badge tone="soon">Due soon</Badge>
          <Badge tone="overdue">Overdue</Badge>
          <Badge tone="active">Active</Badge>
          <Badge tone="ready">Ready</Badge>
          <Badge tone="done">Done</Badge>
          <Badge tone="danger">Problem</Badge>
          {isAdmin && <Badge tone="office">Office</Badge>}
        </div>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <ListTree className="h-4 w-4 text-[var(--color-primary)]" />
            Summary
          </CardTitle>
          <CardDescription>
            Tap a row to jump. Full detail and screenshot are below.
            {!isAdmin ? " Floor topics only." : ""}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2.5">
            {summaryItems.map((item, i) => (
              <li key={item.id}>
                <button
                  type="button"
                  onClick={() => setStep(i)}
                  className={cn(
                    "w-full text-left rounded-[var(--radius-md)] border px-3 py-2.5 min-h-11 transition-colors",
                    safeStep === i
                      ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_12%,transparent)]"
                      : "border-[var(--color-border)] hover:bg-[var(--color-surface-2)]",
                  )}
                >
                  <div className="text-sm font-semibold">
                    {i + 1}. {item.title}
                  </div>
                  <div className="text-xs text-[var(--color-muted)] mt-0.5 leading-relaxed">
                    {item.summary}
                  </div>
                </button>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card className="overflow-hidden">
        <CardHeader className="pb-3 border-b border-[var(--color-border)]">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <CardTitle className="text-lg">
                {safeStep + 1}. {page.title}
              </CardTitle>
              <CardDescription className="mt-1">{page.summary}</CardDescription>
            </div>
            <div className="text-xs text-[var(--color-muted)] shrink-0 tabular">
              Page {safeStep + 1} of {total}
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-0">
          <div className="bg-[var(--color-bg)] border-b border-[var(--color-border)]">
            <img
              key={page.image}
              src={`${page.image}?v=2026-08-rebuild`}
              alt={page.title}
              className="w-full max-h-[min(56vh,520px)] object-contain object-top bg-[#0c0e12]"
            />
          </div>

          <div className="p-4 sm:p-5 space-y-4">
            <div>
              <h3 className="text-sm font-semibold mb-2">In detail</h3>
              <ul className="space-y-2.5 text-sm text-[var(--color-muted)] leading-relaxed">
                {page.details.map((d) => (
                  <li key={d} className="flex gap-2">
                    <span className="text-[var(--color-primary)] shrink-0 mt-1.5 h-1.5 w-1.5 rounded-full bg-[var(--color-primary)]" />
                    <span className="text-[var(--color-fg)]/90">{d}</span>
                  </li>
                ))}
              </ul>
            </div>

            {page.tips && page.tips.length > 0 && (
              <div className="rounded-[var(--radius-md)] border border-[color-mix(in_oklab,var(--color-status-hold)_35%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-status-hold)_10%,transparent)] px-3 py-2.5 text-sm">
                <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-status-hold)] mb-1">
                  Tip
                </div>
                {page.tips.map((t) => (
                  <p
                    key={t}
                    className="text-[var(--color-fg)]/90 leading-relaxed"
                  >
                    {t}
                  </p>
                ))}
              </div>
            )}

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <Link
                to={page.path as "/"}
                className="inline-flex items-center gap-1.5 text-sm text-[var(--color-primary)] font-medium hover:underline"
              >
                Open {page.title}
                <ExternalLink className="h-3.5 w-3.5" />
              </Link>
            </div>
          </div>

          <div className="flex items-center justify-between gap-2 border-t border-[var(--color-border)] px-4 py-3 bg-[var(--color-surface-2)]/40">
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={safeStep === 0}
              onClick={() => go(-1)}
            >
              <ChevronLeft className="h-4 w-4" />
              Back
            </Button>
            <div className="flex gap-1.5 flex-wrap justify-center max-w-[50%]">
              {pages.map((p, i) => (
                <button
                  key={p.id}
                  type="button"
                  aria-label={`Go to ${p.title}`}
                  onClick={() => setStep(i)}
                  className={cn(
                    "h-2 w-2 rounded-full transition-colors",
                    i === safeStep
                      ? "bg-[var(--color-primary)]"
                      : "bg-[var(--color-border-strong)] hover:bg-[var(--color-muted)]",
                  )}
                />
              ))}
            </div>
            <Button
              type="button"
              size="sm"
              disabled={safeStep >= total - 1}
              onClick={() => go(1)}
            >
              Next
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
