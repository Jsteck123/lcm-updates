import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Printer } from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { barcodeToDataUrl, scanUrlForBarcode } from "@/lib/lcm/barcode";
import {
  labelSizeLine,
  renderLabelMono,
  renderLabelPng,
  tapeById,
} from "@/lib/lcm/brother-label-print";
import { printLabelOnShopHost } from "@/lib/lcm/print-label-api";
import { loadQlPrinterIp } from "@/lib/lcm/ql-printer";
import { getShopToken, requestShopUnlock } from "@/lib/lcm/shop-sync";
import type { StockPiece } from "@/lib/lcm/types";

export const Route = createFileRoute("/labels")({
  validateSearch: (search: Record<string, unknown>) => ({
    ids: typeof search.ids === "string" ? search.ids : "",
  }),
  component: LabelsPage,
});

function sizeForLabel(p: Pick<StockPiece, "sizeNote" | "stockShape">) {
  return labelSizeLine({ sizeNote: p.sizeNote, stockShape: p.stockShape });
}

function LabelsPage() {
  const { ids } = Route.useSearch();
  const stockPiecesRaw = useLcmStore((s) => s.stockPieces);
  const stockPieces = stockPiecesRaw || [];
  const shopPublicUrl = useLcmStore((s) => s.settings.shopPublicUrl);
  const [qrMap, setQrMap] = useState<Record<string, string>>({});
  const [previewMap, setPreviewMap] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const tape = tapeById("dk2210");

  const selected = useMemo(() => {
    const idSet = new Set(
      ids
        .split(",")
        .map((x) => x.trim())
        .filter(Boolean),
    );
    if (idSet.size === 0) {
      const avail = stockPieces.filter((p) => p.status === "available");
      return avail.length ? avail : stockPieces;
    }
    return stockPieces.filter((p) => idSet.has(p.id) || idSet.has(p.barcode));
  }, [ids, stockPieces]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const next: Record<string, string> = {};
      await Promise.all(
        selected.map(async (p) => {
          const payload = scanUrlForBarcode(p.barcode, shopPublicUrl);
          next[p.id] = await barcodeToDataUrl(payload, 220);
        }),
      );
      if (!cancelled) setQrMap(next);
    })();
    return () => {
      cancelled = true;
    };
  }, [selected, shopPublicUrl]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const next: Record<string, string> = {};
      await Promise.all(
        selected.map(async (p) => {
          const qr = qrMap[p.id];
          if (!qr) return;
          next[p.id] = await renderLabelPng(
            {
              barcode: p.barcode,
              qrDataUrl: qr,
              line1: `${p.material} ${p.materialType}`.trim(),
              line2: sizeForLabel(p),
            },
            tape,
          );
        }),
      );
      if (!cancelled) setPreviewMap(next);
    })();
    return () => {
      cancelled = true;
    };
  }, [selected, qrMap, tape]);

  async function printAll() {
    const missing = selected.filter((p) => !qrMap[p.id]);
    if (missing.length) {
      toast.error("Wait for barcodes to finish drawing");
      return;
    }
    if (!getShopToken()) {
      requestShopUnlock();
      toast.error("Unlock this PC first, then print again.");
      return;
    }
    const ip = loadQlPrinterIp();
    if (!ip) {
      toast.error("Set the QL-810W Wi-Fi address on the sample label page first.");
      return;
    }
    setBusy(true);
    let last = "";
    try {
      for (const p of selected) {
        const mono = await renderLabelMono({
          tapeId: "dk2210",
          barcode: p.barcode,
          qrDataUrl: qrMap[p.id] || "",
          line1: `${p.material} ${p.materialType}`.trim(),
          line2: sizeForLabel(p),
        });
        const r = await printLabelOnShopHost({
          data: {
            token: getShopToken() || undefined,
            ip,
            width: mono.width,
            height: mono.height,
            pixelsB64: mono.pixelsB64,
          },
        });
        if (!r.ok) {
          toast.error(r.error || "Print failed");
          setBusy(false);
          return;
        }
        last = r.ip;
      }
      toast.success(
        `${selected.length} label${selected.length === 1 ? "" : "s"} sent to ${last}`,
      );
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Print failed");
    }
    setBusy(false);
  }

  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            Stock barcode labels
          </h1>
          <p className="text-sm text-[var(--color-muted)] mt-1">
            Same 1.1 × 0.6 sticker as the sample. Size prints as (4") or
            (2" x 4") — no “dia”.
          </p>
        </div>
        <div className="flex flex-wrap gap-2 items-end">
          <Button
            className="min-h-11"
            disabled={busy || selected.length === 0}
            onClick={() => void printAll()}
          >
            <Printer className="h-4 w-4" /> {busy ? "Sending…" : `Print ${selected.length} label${selected.length === 1 ? "" : "s"}`}
          </Button>
          <Link
            to="/sample-label"
            className="inline-flex items-center rounded-[var(--radius-md)] border border-[var(--color-border)] px-4 py-2.5 text-sm min-h-11"
          >
            Test print
          </Link>
        </div>
      </div>

      {selected.length === 0 ? (
        <p className="text-[var(--color-muted)]">
          No pieces to print. Receive material on a PO first, or add barcoded
          pieces under Inventory.
        </p>
      ) : (
        <div className="label-sheet">
          {selected.map((p) => (
            <div key={p.id}>
              {previewMap[p.id] ? (
                <img
                  src={previewMap[p.id]}
                  alt={p.barcode}
                  className="stock-label-preview"
                />
              ) : (
                <div className="stock-label-empty" />
              )}
            </div>
          ))}
        </div>
      )}

      <style>{`
        .label-sheet {
          display: flex;
          flex-wrap: wrap;
          gap: 12px;
        }
        .stock-label-preview {
          display: block;
          width: 0.6in;
          height: auto;
          border: 1px solid var(--color-border);
          background: #fff;
        }
        .stock-label-empty {
          width: 0.6in;
          height: 1.1in;
          background: #eee;
          border: 1px solid var(--color-border);
        }
      `}</style>
    </div>
  );
}
