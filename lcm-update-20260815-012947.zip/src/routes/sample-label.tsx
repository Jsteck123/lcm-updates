import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Printer, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { barcodeToDataUrl, scanUrlForBarcode } from "@/lib/lcm/barcode";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { useLcmStore } from "@/store/lcm-store";
import {
  downloadLabelPng,
  renderLabelMono,
  renderLabelPng,
  tapeById,
} from "@/lib/lcm/brother-label-print";
import {
  listShopLabelPrinters,
  printLabelOnShopHost,
} from "@/lib/lcm/print-label-api";
import { loadQlPrinterIp, saveQlPrinterIp } from "@/lib/lcm/ql-printer";
import { getShopToken, requestShopUnlock } from "@/lib/lcm/shop-sync";

export const SAMPLE_BARCODE = "LCM-SAMPLE-01";

const LOCAL_SAMPLE = {
  barcode: SAMPLE_BARCODE,
  material: "Aluminum",
  materialType: "T6 6061",
  stockShape: "Round Stock",
  sizeNote: '1.5" dia x 12 ft',
  remainingLength: 144,
  originalLength: 144,
  location: "Rack A-1",
  unit: "in" as const,
};

export const Route = createFileRoute("/sample-label")({
  component: SampleLabelPage,
});

function SampleLabelPage() {
  const stockPiecesRaw = useLcmStore((s) => s.stockPieces);
  const stockPieces = stockPiecesRaw || [];
  const shopPublicUrl = useLcmStore((s) => s.settings.shopPublicUrl);
  const [qr, setQr] = useState("");
  const [busy, setBusy] = useState(false);
  const [ip, setIp] = useState(() => loadQlPrinterIp());
  const [foundIps, setFoundIps] = useState<string[]>([]);
  const [preview, setPreview] = useState("");
  const tape = tapeById("dk2210");

  const piece =
    stockPieces.find((p) => p.barcode === SAMPLE_BARCODE) || LOCAL_SAMPLE;

  useEffect(() => {
    const url = scanUrlForBarcode(SAMPLE_BARCODE, shopPublicUrl);
    void barcodeToDataUrl(url, 220).then(setQr);
  }, [shopPublicUrl]);

  useEffect(() => {
    if (!qr) return;
    void renderLabelPng(
      {
        barcode: piece.barcode,
        qrDataUrl: qr,
        line1: `${piece.material} ${piece.materialType}`,
        line2: piece.sizeNote,
      },
      tape,
    ).then(setPreview);
  }, [qr, piece.barcode, piece.material, piece.materialType, piece.sizeNote, tape]);

  useEffect(() => {
    const token = getShopToken();
    if (!token) return;
    void listShopLabelPrinters({ data: { token } }).then((r) => {
      if (!r.ok) return;
      setFoundIps(r.ips);
      if (!ip && r.ips[0]) {
        setIp(r.ips[0]);
        saveQlPrinterIp(r.ips[0]);
      }
    });
  }, [ip]);

  async function printOnWifi() {
    if (!qr) {
      toast.error("Wait for the barcode to finish drawing");
      return;
    }
    if (!getShopToken()) {
      requestShopUnlock();
      toast.error("Unlock this PC first, then print again.");
      return;
    }
    const dest = ip.trim();
    if (!dest) {
      toast.error("Type the QL-810W Wi-Fi address first.");
      return;
    }
    saveQlPrinterIp(dest);
    setBusy(true);
    try {
      const mono = await renderLabelMono({
        tapeId: "dk2210",
        barcode: piece.barcode,
        qrDataUrl: qr,
        line1: `${piece.material} ${piece.materialType}`,
        line2: piece.sizeNote,
      });
      const r = await printLabelOnShopHost({
        data: {
          token: getShopToken() || undefined,
          ip: dest,
          width: mono.width,
          height: mono.height,
          pixelsB64: mono.pixelsB64,
        },
      });
      if (!r.ok) toast.error(r.error || "Print failed");
      else toast.success("Sent over Wi-Fi to " + r.ip);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Print failed");
    }
    setBusy(false);
  }

  async function savePng() {
    if (!qr) return;
    const r = await downloadLabelPng({
      tapeId: "dk2210",
      barcode: piece.barcode,
      qrDataUrl: qr,
      line1: `${piece.material} ${piece.materialType}`,
      line2: piece.sizeNote,
    });
    if (!r.ok) toast.error(r.error || "Could not save PNG");
  }

  return (
    <div className="mx-auto max-w-lg space-y-5 pb-10">
      <div className="flex items-center gap-2">
        <Link
          to="/inventory"
          className="inline-flex items-center justify-center gap-1.5 text-sm text-[var(--color-muted)] hover:text-[var(--color-fg)] min-h-11"
        >
          <ArrowLeft className="h-4 w-4" /> Inventory
        </Link>
      </div>

      <div className="space-y-2">
        <h1 className="text-2xl font-semibold tracking-tight">
          Sample barcode label
        </h1>
        <p className="text-sm text-[var(--color-muted)]">
          Goes to the QL-810W over Wi-Fi. No Edge. No Paint. No USB.
        </p>
      </div>

      <div className="space-y-1.5">
        <Label>QL-810W Wi-Fi address</Label>
        <Input
          className="h-11 font-mono"
          placeholder="10.200.1.50"
          value={ip}
          onChange={(e) => {
            setIp(e.target.value);
            saveQlPrinterIp(e.target.value);
          }}
        />
        {foundIps.length > 0 ? (
          <p className="text-xs text-[var(--color-muted)]">
            Found on this PC:{" "}
            {foundIps.map((x) => (
              <button
                key={x}
                type="button"
                className="underline mr-2"
                onClick={() => {
                  setIp(x);
                  saveQlPrinterIp(x);
                }}
              >
                {x}
              </button>
            ))}
          </p>
        ) : (
          <p className="text-xs text-[var(--color-muted)]">
            On the printer: Menu / Wi-Fi / TCP/IP — copy the IP here.
          </p>
        )}
      </div>

      {preview ? (
        <img
          src={preview}
          alt=""
          className="sample-ql-preview"
          style={{ width: "0.6in", height: "auto" }}
        />
      ) : (
        <div className="sample-ql-preview-empty" />
      )}

      <div className="flex flex-wrap gap-2">
        <Button
          type="button"
          className="min-h-11"
          disabled={busy}
          onClick={() => void printOnWifi()}
        >
          <Printer className="h-4 w-4" /> {busy ? "Sending…" : "Print on Wi-Fi"}
        </Button>
        <Button
          type="button"
          variant="secondary"
          className="min-h-11"
          onClick={() => void savePng()}
        >
          Save PNG
        </Button>
      </div>

      <style>{`
        .sample-ql-preview {
          display: block;
          border: 1px solid var(--color-border);
          background: #fff;
        }
        .sample-ql-preview-empty {
          width: 0.6in;
          height: 1.1in;
          background: #eee;
          border: 1px solid var(--color-border);
        }
      `}</style>
    </div>
  );
}
