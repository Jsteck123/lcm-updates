import { Link } from "@tanstack/react-router";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { StockPiece } from "@/lib/lcm/types";
import { formatDate } from "@/lib/utils";
import { statusToBadgeTone } from "@/lib/lcm/status-colors";

export function PiecesPanel({ stockPieces }: { stockPieces: StockPiece[] }) {
  return (
  <Card>
    <CardHeader>
      <CardTitle>Barcoded pieces ({stockPieces.length})</CardTitle>
      <CardDescription>
        Each received bar/sheet gets a sticker. Scan to cut length.
      </CardDescription>
    </CardHeader>
    <CardContent className="overflow-x-auto">
      <div className="flex gap-2 mb-3 print:hidden">
        <Link
          to="/labels"
          search={{ ids: "", kind: "pieces" }}
          className="text-sm text-[var(--color-primary)] underline"
        >
          Print all available labels
        </Link>
      </div>
      <table className="w-full text-sm min-w-[720px]">
        <thead>
          <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
            <th className="pb-2 font-medium">Barcode</th>
            <th className="pb-2 font-medium">Material</th>
            <th className="pb-2 font-medium">Remaining</th>
            <th className="pb-2 font-medium">Location</th>
            <th className="pb-2 font-medium">Status</th>
            <th className="pb-2 font-medium">Actions</th>
          </tr>
        </thead>
        <tbody>
          {stockPieces.map((p) => (
            <tr key={p.id} className="border-b border-[var(--color-border)]/60">
              <td className="py-2 font-mono text-xs">{p.barcode}</td>
              <td className="py-2">
                {p.material} {p.materialType}
                <div className="text-xs text-[var(--color-muted)]">{p.sizeNote}</div>
              </td>
              <td className="py-2 tabular">
                {p.remainingLength}" / {p.originalLength}"
              </td>
              <td className="py-2">{p.location}</td>
              <td className="py-2">
                <Badge tone={p.status === "available" ? "success" : "neutral"}>
                  {p.status}
                </Badge>
              </td>
              <td className="py-2">
                <div className="flex gap-2">
                  <Link
                    to="/scan"
                    search={{ c: p.barcode }}
                    className="text-xs text-[var(--color-primary)] underline"
                  >
                    Scan / cut
                  </Link>
                  <Link
                    to="/labels"
                    search={{ ids: p.id }}
                    className="text-xs text-[var(--color-primary)] underline"
                  >
                    Label
                  </Link>
                </div>
              </td>
            </tr>
          ))}
          {stockPieces.length === 0 && (
            <tr>
              <td colSpan={6} className="py-8 text-center text-[var(--color-muted)]">
                No barcoded pieces — receive a PO line to create them.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </CardContent>
  </Card>
  );
}
