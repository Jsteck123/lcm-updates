import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Printer } from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { barcodeToDataUrl, scanUrlForBarcode } from "@/lib/lcm/barcode";
import {
  labelSizeLine,
  materialLabelBarcode,
  renderLabelMono,
  renderLabelPng,
  tapeById,
} from "@/lib/lcm/brother-label-print";
import { printLabelOnShopHost } from "@/lib/lcm/print-label-api";
import { loadQlPrinterIp } from "@/lib/lcm/ql-printer";
import { getShopToken, requestShopUnlock } from "@/lib/lcm/shop-sync";

type LabelJob = {
  id: string;
  barcode: string;
  line1: string;
  line2: string;
};

export const Route = createFileRoute("/labels")({
  validateSearch: (search: Record<string, unknown>) => {
    const ids = typeof search.ids === "string" ? search.ids : "";
    const kind =
      search.kind === "pieces" || ids.trim()
        ? ("pieces" as const)
        : ("materials" as const);
    return { ids, kind };
  },
  component: LabelsPage,
});

function LabelsPage() {
  const { ids, kind } = Route.useSearch();
  const stockPiecesRaw = useLcmStore((s) => s.stockPieces);
  const stockPieces = stockPiecesRaw || [];
  const materialStockRaw = useLcmStore((s) => s.materialStock);
  const materialStock = materialStockRaw || [];
  const shopPublicUrl = useLcmStore((s) => s.settings.shopPublicUrl);
  const [qrMap, setQrMap] = useState<Record<string, string>>({});
  const [previewMap, setPreviewMap] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const tape = tapeById("dk2210");

  const jobs: LabelJob[] = useMemo(() => {
    if (kind === "pieces") {
      const idSet = new Set(
        ids
          .split(",")
          .map((x) => x.trim())
          .filter(Boolean),
      );
      const list = idSet.size
        ? stockPieces.filter((p) => idSet.has(p.id) || idSet.has(p.barcode))
        : stockPieces.filter((p) => p.status === "available");
      return list.map((p) => ({
        id: p.id,
        barcode: p.barcode,
        line1: `${p.material} ${p.materialType}`.trim(),
        line2: labelSizeLine({ sizeNote: p.sizeNote, stockShape: p.stockShape }),
      }));
    }
    return materialStock
      .filter((m) => Number(m.onHand) > 0)
      .map((m) => ({
        id: m.id,
        barcode: materialLabelBarcode(m.id),
        line1: `${m.material} ${m.materialType}`.trim(),
        line2: labelSizeLine({ sizeNote: m.sizeNote, stockShape: m.stockShape }),
      }));
  }, [kind, ids, stockPieces, materialStock]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const next: Record<string, string> = {};
      await Promise.all(
        jobs.map(async (j) => {
          next[j.id] = await barcodeToDataUrl(
            scanUrlForBarcode(j.barcode, shopPublicUrl),
            220,
          );
        }),
      );
      if (!cancelled) setQrMap(next);
    })();
    return () => {
      cancelled = true;
    };
  }, [jobs, shopPublicUrl]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const next: Record<string, string> = {};
      await Promise.all(
        jobs.map(async (j) => {
          const qr = qrMap[j.id];
          if (!qr) return;
          next[j.id] = await renderLabelPng(
            {
              barcode: j.barcode,
              qrDataUrl: qr,
              line1: j.line1,
              line2: j.line2,
            },
            tape,
          );
        }),
      );
      if (!cancelled) setPreviewMap(next);
    })();
    return () => {
      cancelled = true;
    };
  }, [jobs, qrMap, tape]);

  async function printAll() {
    const missing = jobs.filter((j) => !qrMap[j.id]);
    if (missing.length) {
      toast.error("Wait for barcodes to finish drawing");
      return;
    }
    if (!getShopToken()) {
      requestShopUnlock();
      toast.error("Unlock this PC first, then print again.");
      return;
    }
    const ip = loadQlPrinterIp();
    if (!ip) {
      toast.error("Set the QL-810W Wi-Fi address on the sample label page first.");
      return;
    }
    setBusy(true);
    let last = "";
    try {
      for (const j of jobs) {
        const mono = await renderLabelMono({
          tapeId: "dk2210",
          barcode: j.barcode,
          qrDataUrl: qrMap[j.id] || "",
          line1: j.line1,
          line2: j.line2,
        });
        const r = await printLabelOnShopHost({
          data: {
            token: getShopToken() || undefined,
            ip,
            width: mono.width,
            height: mono.height,
            pixelsB64: mono.pixelsB64,
          },
        });
        if (!r.ok) {
          toast.error(r.error || "Print failed");
          setBusy(false);
          return;
        }
        last = r.ip;
      }
      toast.success(
        `${jobs.length} label${jobs.length === 1 ? "" : "s"} sent to ${last}`,
      );
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Print failed");
    }
    setBusy(false);
  }

  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            Stock barcode labels
          </h1>
          <p className="text-sm text-[var(--color-muted)] mt-1">
            {kind === "materials"
              ? `One 1.1 × 0.6 sticker per material on hand (${jobs.length}).`
              : `Barcoded pieces (${jobs.length}).`}{" "}
            Size prints as (4") or (2" x 4").
          </p>
          <div className="flex gap-3 mt-2 text-sm">
            <Link
              to="/labels"
              search={{ ids: "", kind: "materials" }}
              className={
                kind === "materials"
                  ? "text-[var(--color-fg)] font-medium underline"
                  : "text-[var(--color-muted)] underline"
              }
            >
              Materials
            </Link>
            <Link
              to="/labels"
              search={{ ids: "", kind: "pieces" }}
              className={
                kind === "pieces"
                  ? "text-[var(--color-fg)] font-medium underline"
                  : "text-[var(--color-muted)] underline"
              }
            >
              Pieces
            </Link>
          </div>
        </div>
        <div className="flex flex-wrap gap-2 items-end">
          <Button
            className="min-h-11"
            disabled={busy || jobs.length === 0}
            onClick={() => void printAll()}
          >
            <Printer className="h-4 w-4" />{" "}
            {busy
              ? "Sending…"
              : `Print ${jobs.length} label${jobs.length === 1 ? "" : "s"}`}
          </Button>
          <Link
            to="/sample-label"
            className="inline-flex items-center rounded-[var(--radius-md)] border border-[var(--color-border)] px-4 py-2.5 text-sm min-h-11"
          >
            Test print
          </Link>
        </div>
      </div>

      {jobs.length === 0 ? (
        <p className="text-[var(--color-muted)]">
          {kind === "materials"
            ? "No material on hand to label."
            : "No barcoded pieces. Receive a PO line, or print from Materials."}
        </p>
      ) : (
        <div className="label-sheet">
          {jobs.map((j) => (
            <div key={j.id}>
              {previewMap[j.id] ? (
                <img
                  src={previewMap[j.id]}
                  alt={j.barcode}
                  className="stock-label-preview"
                />
              ) : (
                <div className="stock-label-empty" />
              )}
            </div>
          ))}
        </div>
      )}

      <style>{`
        .label-sheet {
          display: flex;
          flex-wrap: wrap;
          gap: 12px;
        }
        .stock-label-preview {
          display: block;
          width: 0.6in;
          height: auto;
          border: 1px solid var(--color-border);
          background: #fff;
        }
        .stock-label-empty {
          width: 0.6in;
          height: 1.1in;
          background: #eee;
          border: 1px solid var(--color-border);
        }
      `}</style>
    </div>
  );
}
