import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type {
  ActiveTimer,
  CustomLists,
  Customer,
  DayBonusRecord,
  DowntimeEntry,
  InventoryTxnType,
  JobRun,
  LcmState,
  MachineSession,
  MaterialStock,
  Operator,
  PartStock,
  PartUnit,
  PoLine,
  PurchaseOrder,
  VendorRfq,
  VendorBid,
  Quote,
  ShopOrder,
  ShopOrderLine,
  StockPiece,
  WeeklyPayout,
  WorkQueueItem,
  CutTicket,
  ChatMessage,
  ShopToolingLog,
  QuoteToolingKind,
  FeedbackTicket,
  FeedbackKind,
  FeedbackStatus,
  FeedbackAttachment,
} from "@/lib/lcm/types";
import { createSeedState } from "@/lib/lcm/seed";
import {
  ensureMachineSessions,
  maxOpsFrom,
  migrateOperators,
  operatorEmailMatch,
  isCurrentUserAdmin,
  canControlMachine,
  padJob,
  padQuote,
  padSession,
  withBetaDefault,
} from "@/store/session-pad";
import { mergeChatMessages } from "@/lib/lcm/chat";
import {
  computeSessionBonus,
  computeSessionEfficiency,
  emptySession,
  findNextOperation,
  quotedSecondsFromQuote,
  calculateAssemblyAwareCosts,
} from "@/lib/lcm/calculations";
import {
  DEFAULT_OPERATIONS,
  clampOpCount,
  nulls,
  opIndex,
  opLabel,
  padSlots,
  zeros,
} from "@/lib/lcm/ops";
import {
  EMPTY_CUSTOM_LISTS,
  allMachines,
  mergeUnique,
  normalizeCustomLists,
} from "@/lib/lcm/lists";
import { DEFAULT_OPERATOR_TABS, normalizeOperator } from "@/lib/lcm/permissions";
import { migrateCustomers, normalizeCustomer } from "@/lib/lcm/customers";
import {
  calculateDayBonus,
  calculateShiftBonus,
  currentShiftContext,
  getShiftById,
  resolveWorkShifts,
  localDateKey as dayLocalDateKey,
  rollupWeek,
  toDayBonusRecord,
} from "@/lib/lcm/day-bonus";
import { uid } from "@/lib/utils";
import {
  applyQtyChange,
  emptyMaterial,
  emptyPart, generatePartUin, normalizeUin,
  makeTxn,
  materialLabel,
  partLabel,
} from "@/lib/lcm/inventory";
import {
  derivePoStatus,
  emptyPoLine,
  emptyPurchaseOrder,
  emptyShopOrder,
  emptyShopOrderLine,
  deriveShopOrderStatus,
  findOrCreateStockId,
  generateBarcode,
  nextPoNumber,
  poLineOpenQty,
} from "@/lib/lcm/po";
import {
  emptyVendorRfq,
  emptyVendorBid,
  emptyVendorRfqLine,
  nextRfqNumber,
  defaultBidLinesForRfq,
  purchaseOrderFromAward,
} from "@/lib/lcm/vendor-rfq";
import {
  emptyWorkQueueItem,
  nextSortOrder,
  queueForMachine,
} from "@/lib/lcm/work-queue";
import {
  emptyShopToolingLog,
  liveToolingMinutes,
  normalizeShopToolingLogs,
  toolingChargeFromShopLog,
} from "@/lib/lcm/shop-tooling-log";
import {
  enrichShopOrderLines,
  findQuoteForPart,
  mergeQuoteLists,
  normalizePartNumber,
  quoteKey,
} from "@/lib/lcm/po-material";
import {
  emptyCutTicket,
  deriveCutStatus,
  qtyAvailable,
  applyTicketToQuote,
  sizeNoteFromTicket,
  ticketFromLine,
} from "@/lib/lcm/cut-tickets";

import {
  allComponentsComplete,
  lineHasCad,
  normalizeComponents,
  patchComponent,
  promoteRelatedFilesToComponents,
} from "@/lib/lcm/line-files";
import {
  mergeQuotes,
  parseQuoteCsv,
  type QuoteImportMode,
} from "@/lib/lcm/quote-import";
import {
  applyAveragesToQuote,
  computePartRunStats,
  freezeQuoteSnapshot,
} from "@/lib/lcm/job-averages";
import type { ShopSharedState } from "@/lib/lcm/shop-types";

type LcmActions = {
  setCurrentUserEmail: (email: string) => void;
  addAudit: (user: string, action: string, details: string) => void;
  upsertOperator: (op: Operator) => void;
  removeOperator: (id: string) => void;
  upsertCustomer: (c: Customer) => void;
  removeCustomer: (id: string) => void;
  saveQuote: (q: Quote, mode: "submit" | "update") => { ok: boolean; error?: string };
  /** Bulk import from Google Sheets DATABASE / Historical Quotes CSV */
  importHistoricalQuotes: (
    csvText: string,
    mode: QuoteImportMode,
  ) => {
    ok: boolean;
    created: number;
    updated: number;
    skipped: number;
    total: number;
    errors: string[];
    preview: Array<{
      partNumber: string;
      revision: string;
      customer: string;
      action: string;
      note?: string;
    }>;
    error?: string;
  };
  deleteQuote: (partNumber: string) => void;
  getQuoteByPart: (partNumber: string) => Quote | undefined;
  setOperatorOnMachine: (machine: string, operatorName: string) => void;
  loadJobOnMachine: (
    machine: string,
    opts: {
      partNumber: string;
      revision: string;
      quantity: number;
      customer: string;
      existingJobId?: string;
      /** Optional cousin job on the same machine (one clock). */
      pair?: {
        partNumber: string;
        revision: string;
        quantity: number;
        customer?: string;
        existingJobId?: string;
      };
    },
  ) => { ok: boolean; error?: string };
  /** Floor: nest a second P/N on this machine. Does not stop the timer. */
  attachPairOnMachine: (
    machine: string,
    opts: {
      partNumber: string;
      revision?: string;
      quantity?: number;
      customer?: string;
      existingJobId?: string;
    },
  ) => { ok: boolean; error?: string };
  /** Floor: drop the nested part. Primary job and timer stay. */
  clearPairOnMachine: (machine: string) => { ok: boolean; error?: string };
  clearMachineSession: (machine: string) => void;
  updateSessionNotes: (machine: string, notes: string) => void;

  /** Soft jaws / special tools — floor log + timer (not part cycle ops). */
  startShopToolingLog: (opts: {
    machine: string;
    kind?: QuoteToolingKind;
    description?: string;
    notes?: string;
    billRequest?: boolean;
    suggestedBillAmount?: number;
  }) => { ok: boolean; error?: string; id?: string };
  stopShopToolingTimer: (id: string) => { ok: boolean; error?: string };
  upsertShopToolingLog: (log: ShopToolingLog) => { ok: boolean; error?: string };
  resolveShopToolingLog: (
    id: string,
    status: "no_charge" | "dismissed" | "applied_to_quote",
    extra?: { quoteId?: string; toolingChargeId?: string },
  ) => { ok: boolean; error?: string };
  /** Push floor log onto quote as separate tooling charge (optional bill). */
  applyShopToolingLogToQuote: (
    logId: string,
    quoteId?: string,
    opts?: {
      minutes?: number;
      billUnitPrice?: number;
      shopCost?: number;
      billCustomer?: boolean;
      description?: string;
    },
  ) => { ok: boolean; error?: string };

  updateSessionField: (
    machine: string,
    patch: Partial<
      Pick<
        MachineSession,
        | "revision"
        | "quantity"
        | "customer"
        | "quantityCompleted"
        | "pairQuantity"
        | "pairQuantityCompleted"
      >
    >,
  ) => void;
  smartStart: (machine: string) => { ok: boolean; error?: string; message?: string };
  smartStop: (
    machine: string,
    unitsCompleted?: number,
  ) => { ok: boolean; error?: string; needsUnits?: boolean };
  pauseJob: (machine: string, reason: string) => { ok: boolean; error?: string };
  resumeJob: (machine: string) => { ok: boolean; error?: string; message?: string };
  /** Admin: set setup/runtime seconds (running clock or recorded). */
  adjustOpTime: (
    machine: string,
    opIndex: number,
    type: "Setup" | "Runtime",
    seconds: number,
  ) => { ok: boolean; error?: string };
  /** Admin: reopen a stopped setup/runtime so the operator is back on that clock. */
  reopenOpTimer: (
    machine: string,
    opIndex: number,
    type: "Setup" | "Runtime",
    seconds?: number,
  ) => { ok: boolean; error?: string; message?: string };
  saveJob: (
    machine: string,
    mode: "in-progress" | "completed",
    qtyCompleted?: number,
    opts?: { countInAverage?: boolean },
  ) => { ok: boolean; error?: string };
  freezeQuotePrices: (
    quoteId: string,
    reason?: "manual_lock" | "submit",
  ) => { ok: boolean; error?: string };
  logEmailSend: (entry: {
    customer: string;
    toEmail: string;
    subject: string;
    quoteIds: string[];
    partNumbers: string[];
    method: "mailto" | "copy" | "print";
  }) => void;
  updateSettings: (patch: Partial<LcmState["settings"]>) => void;
  verifyPassword: (pw: string) => boolean;
  resetToSeed: () => void;
  exportJson: () => string;
  importJson: (raw: string) => { ok: boolean; error?: string };
  getLiveElapsedSeconds: (machine: string, nowMs?: number) => number | null;
  getCurrentOperator: () => Operator | undefined;
  getMaxOps: () => number;
  getMachineList: () => string[];
  getCustomLists: () => CustomLists;
  addCustomListItem: (
    kind:
      | "materials"
      | "machines"
      | "stockShapes"
      | "pauseReasons"
      | "materialTypes"
      | "sizeNotes",
    value: string,
    materialForType?: string,
  ) => { ok: boolean; error?: string };
  addCustomerQuick: (name: string) => { ok: boolean; error?: string };
  addOperatorQuick: (name: string) => { ok: boolean; error?: string };
  markCustomerEmailed: (customerId: string, emailUsed: string) => void;
  syncDayBonus: (
    operatorName: string,
    dateKey?: string,
    shiftId?: string,
  ) => DayBonusRecord | null;
  /** Sync all enabled shifts for the operator (day + night) */
  syncAllShiftBonuses: (operatorName: string, dateKey?: string) => void;
  finalizeDayBonus: (
    operatorName: string,
    dateKey?: string,
    opts?: { force?: boolean; shiftId?: string },
  ) => { ok: boolean; error?: string; record?: DayBonusRecord };
  markWeekPaid: (operatorName: string, weekKey: string) => { ok: boolean; error?: string };
  sendChatMessage: (opts: {
    body: string;
    /** empty / omit = shop channel */
    toEmail?: string;
    context?: string;
    attachments?: import("@/lib/lcm/types").ChatAttachment[];
  }) => { ok: boolean; error?: string; id?: string };
  markChatRead: (messageIds: string[]) => void;
  addFeedbackTicket: (opts: {
    kind: FeedbackKind;
    title: string;
    body: string;
    page?: string;
    machine?: string;
    attachments?: FeedbackAttachment[];
  }) => { ok: boolean; error?: string; id?: string };
  addFeedbackComment: (
    ticketId: string,
    body: string,
  ) => { ok: boolean; error?: string };
  setFeedbackStatus: (
    ticketId: string,
    status: FeedbackStatus,
  ) => { ok: boolean; error?: string };
  getDayBonusLive: (
    operatorName: string,
    dateKey?: string,
    shiftId?: string,
  ) => ReturnType<typeof calculateDayBonus> | null;
  getSharedState: () => ShopSharedState;
  replaceSharedState: (shared: ShopSharedState) => void;
  upsertMaterialStock: (item: MaterialStock) => void;
  removeMaterialStock: (id: string) => void;
  upsertPartStock: (item: PartStock) => void;
  removePartStock: (id: string) => void;
  /** Create individual sharpied-UIN part units (extras / second quality) */
  stockPartUnits: (opts: {
    partNumber: string;
    revision: string;
    qty: number;
    quality: "good" | "second";
    defectNote?: string;
    location?: string;
    jobRef?: string;
  }) => { ok: boolean; error?: string; units?: PartUnit[] };
  getPartUnitByUin: (uin: string) => PartUnit | undefined;
  issuePartUnit: (
    uin: string,
    opts?: { reason?: string },
  ) => { ok: boolean; error?: string };
  inventoryMove: (opts: {
    itemKind: "material" | "part";
    itemId: string;
    kind: InventoryTxnType;
    qty: number;
    reason?: string;
    ref?: string;
    /** For adjust: set absolute on-hand instead of delta */
    setAbsolute?: boolean;
  }) => { ok: boolean; error?: string; balance?: number };
  upsertPurchaseOrder: (po: PurchaseOrder) => void;
  removePurchaseOrder: (id: string) => void;
  createPurchaseOrder: (partial?: Partial<PurchaseOrder>) => PurchaseOrder;
  createVendorRfq: (partial?: Partial<VendorRfq>) => VendorRfq;
  upsertVendorRfq: (rfq: VendorRfq) => void;
  removeVendorRfq: (id: string) => void;
  addVendorBid: (
    rfqId: string,
    bid: Partial<VendorBid>,
  ) => { ok: boolean; error?: string; bid?: VendorBid };
  acceptVendorBid: (
    rfqId: string,
    bidId: string,
  ) => { ok: boolean; error?: string; po?: PurchaseOrder };
  receivePoLine: (opts: {
    poId: string;
    lineId: string;
    qty: number;
    location?: string;
  }) => { ok: boolean; error?: string; pieceIds?: string[] };
  consumePiece: (opts: {
    barcode: string;
    lengthUsed: number;
    qty?: number;
    reason?: string;
    jobRef?: string;
  }) => { ok: boolean; error?: string; piece?: StockPiece };
  getPieceByBarcode: (barcode: string) => StockPiece | undefined;
  createShopOrder: (partial?: Partial<ShopOrder>) => ShopOrder;
  upsertShopOrder: (order: ShopOrder) => void;
  setShopOrderPackStatus: (
    orderId: string,
    status: "pending" | "packed" | "verified",
    byName: string,
  ) => { ok: boolean; error?: string };
  patchShopOrderLine: (
    orderId: string,
    lineId: string,
    patch: Partial<ShopOrderLine>,
  ) => { ok: boolean; error?: string };
  /** Pull ONE line or assembly component from the job board. */
  pullJobBoardLine: (
    orderId: string,
    lineId: string,
    byName: string,
    machine?: string,
    componentId?: string,
  ) => { ok: boolean; error?: string };
  returnJobBoardLine: (
    orderId: string,
    lineId: string,
    componentId?: string,
  ) => { ok: boolean; error?: string };
  markLineReadyForPack: (
    orderId: string,
    lineId: string,
    byName: string,
    componentId?: string,
  ) => { ok: boolean; error?: string };
  setOrderDelivery: (
    orderId: string,
    patch: {
      delivered?: boolean;
      deliveredBy?: string;
      signedSlipFileId?: string;
      signedSlipName?: string;
      signedSlipMime?: string;
      invoicedInQb?: boolean;
      paymentReceived?: boolean;
      closed?: boolean;
    },
  ) => { ok: boolean; error?: string };
  removeShopOrder: (id: string) => void;
  /** Match lines to quote DB + inventory; fill material / flag attention */
  enrichShopOrderMaterial: (orderId: string) => void;
  /** Write line material recipe into part DB so next import auto-fills */
  syncPartMaterialRecipe: (line: ShopOrderLine) => void;
  setShopLineMaterialReviewed: (
    orderId: string,
    lineId: string,
    reviewed: boolean,
  ) => void;
  updateShopOrderLineProgress: (
    orderId: string,
    lineId: string,
    qtyCompleted: number,
  ) => void;
  assignShopOrderLine: (opts: {
    orderId: string;
    lineId: string;
    machine: string;
    operatorName?: string;
    qty?: number;
    notes?: string;
  }) => { ok: boolean; error?: string; itemId?: string };
  /** Office desk: assign a part/component to an operator (machine optional). */
  officeAssignPart: (opts: {
    orderId: string;
    lineId: string;
    componentId?: string;
    operatorName: string;
    machine?: string;
    notes?: string;
  }) => { ok: boolean; error?: string };
  /** Apply a floor material count plan (adjust / create stock rows). */
  applyMaterialCount: (
    plan: import("@/lib/lcm/material-count").CountApplyPlan,
  ) => { ok: boolean; error?: string; adjusted: number; created: number };
  updateWorkQueueItem: (id: string, patch: Partial<WorkQueueItem>) => void;
  removeWorkQueueItem: (id: string) => void;
  moveWorkQueueItem: (id: string, direction: "up" | "down") => void;
  /** Load queue item onto its machine and mark active */
  startWorkQueueItem: (id: string) => { ok: boolean; error?: string };
  completeWorkQueueItem: (id: string) => void;

  /** Create / update saw cut ticket (CAD actuals, progressive qty) */
  upsertCutTicket: (ticket: CutTicket) => { ok: boolean; error?: string };
  createCutTicketFromLine: (opts: {
    orderId: string;
    lineId: string;
    byName: string;
    machine?: string;
    componentId?: string;
    process?: import("@/lib/lcm/types").CutProcess;
    dimX?: number;
    dimY?: number;
    dimZ?: number;
    diameter?: number;
    locAxis?: import("@/lib/lcm/types").LocAxis;
    locValue?: number;
    qtyRequested?: number;
    notes?: string;
    writeBackToQuote?: boolean;
  }) => { ok: boolean; error?: string; ticket?: CutTicket };
  /** Saw marks additional blanks cut (progressive) */
  recordCutProgress: (
    ticketId: string,
    qtyDelta: number,
    sawOperator?: string,
  ) => { ok: boolean; error?: string; ticket?: CutTicket };
  /** Machine claims available blanks to start work */
  claimCutStock: (
    ticketId: string,
    qty: number,
    machine?: string,
  ) => { ok: boolean; error?: string; available?: number };
  skipCutTicket: (
    ticketId: string,
    byName?: string,
  ) => { ok: boolean; error?: string };
  cancelCutTicket: (ticketId: string) => { ok: boolean; error?: string };
  /** Write actual cut dims to matching quote (size recipe only — never prices) */
  writeCutActualsToQuote: (
    ticketId: string,
  ) => { ok: boolean; error?: string };
};


export type LcmStore = LcmState & LcmActions;

function refreshEfficiency(session: MachineSession, settings: LcmState["settings"]) {
  const efficiency = computeSessionEfficiency(session);
  const bonus = computeSessionBonus(session, settings.bonusTiers, settings.hourlyRate);
  return { ...session, efficiency, bonus };
}

const seed = createSeedState();

export const useLcmStore = create<LcmStore>()(
  persist(
    (set, get) => ({
      ...seed,
      dayBonuses: seed.dayBonuses || [],
      weeklyPayouts: seed.weeklyPayouts || [],
      materialStock: seed.materialStock || [],
      partStock: seed.partStock || [],
      partUnits: seed.partUnits || [],
      inventoryTxns: seed.inventoryTxns || [],
      purchaseOrders: seed.purchaseOrders || [],
      vendorRfqs: seed.vendorRfqs || [],
      shopOrders: seed.shopOrders || [],
      workQueue: seed.workQueue || [],
      cutTickets: seed.cutTickets || [],
      stockPieces: seed.stockPieces || [],
      chatMessages: seed.chatMessages || [],
      shopToolingLogs: seed.shopToolingLogs || [],
      feedbackTickets: seed.feedbackTickets || [],

      setCurrentUserEmail: (email) => set({ currentUserEmail: email }),

      getMaxOps: () => maxOpsFrom(get().settings),

      getCustomLists: () =>
        normalizeCustomLists(get().settings.customLists || EMPTY_CUSTOM_LISTS),

      getMachineList: () => {
        const list = allMachines(get().getCustomLists());
        const n = maxOpsFrom(get().settings);
        const s = get();
        const needs = list.some((m) => !s.sessions[m]);
        if (needs) {
          const { sessions, activeTimers } = ensureMachineSessions(
            s.sessions,
            s.activeTimers,
            list,
            n,
          );
          set({ sessions, activeTimers });
        }
        return list;
      },

      addCustomListItem: (kind, value, materialForType) => {
        const v = value.trim();
        if (!v) return { ok: false, error: "Value required" };
        set((s) => {
          const lists = normalizeCustomLists(s.settings.customLists);
          const n = maxOpsFrom(s.settings);
          if (kind === "materialTypes") {
            const mat = (materialForType || "").trim() || "Other";
            const existing = lists.materialTypes[mat] || [];
            const nextTypes = {
              ...lists.materialTypes,
              [mat]: mergeUnique(existing, [v]),
            };
            return {
              settings: {
                ...s.settings,
                customLists: { ...lists, materialTypes: nextTypes },
              },
            };
          }
          const key = kind;
          const arr = mergeUnique(lists[key], [v]);
          const nextLists = { ...lists, [key]: arr };
          if (kind === "machines") {
            const { sessions, activeTimers } = ensureMachineSessions(
              s.sessions,
              s.activeTimers,
              [v],
              n,
            );
            return {
              settings: { ...s.settings, customLists: nextLists },
              sessions,
              activeTimers,
            };
          }
          return {
            settings: { ...s.settings, customLists: nextLists },
          };
        });
        get().addAudit(get().currentUserEmail, "Add list item", `${kind}: ${v}`);
        return { ok: true };
      },

      addCustomerQuick: (name) => {
        const n = name.trim();
        if (!n) return { ok: false, error: "Name required" };
        const exists = get().customers.some(
          (c) => c.name.toLowerCase() === n.toLowerCase(),
        );
        if (exists) return { ok: true };
        get().upsertCustomer(
          normalizeCustomer({
            id: uid(),
            name: n,
            email: "",
            emails: [],
            lastEmailedAt: null,
          }),
        );
        return { ok: true };
      },

      addOperatorQuick: (name) => {
        const n = name.trim();
        if (!n) return { ok: false, error: "Name required" };
        const exists = get().operators.some(
          (o) => o.name.toLowerCase() === n.toLowerCase(),
        );
        if (exists) return { ok: true };
        const slug = n
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, ".")
          .replace(/^\.|\.$/g, "");
        const email = `${slug || "operator"}@lakecountrymachine.com`;
        get().upsertOperator(
          normalizeOperator({
            id: uid(),
            name: n,
            email,
            active: true,
            role: "operator",
            tabs: [...DEFAULT_OPERATOR_TABS],
            pin: "",
          }),
        );
        return { ok: true };
      },

      getCurrentOperator: () => {
        const s = get();
        return s.operators.find(
          (o) => o.email.toLowerCase() === s.currentUserEmail.toLowerCase(),
        );
      },

      addAudit: (user, action, details) =>
        set((s) => ({
          auditLog: [
            {
              id: uid(),
              timestamp: new Date().toISOString(),
              user,
              action,
              details,
            },
            ...s.auditLog,
          ].slice(0, 500),
        })),

      upsertOperator: (op) =>
        set((s) => {
          const normalized = normalizeOperator(op);
          const i = s.operators.findIndex((o) => o.id === normalized.id);
          const operators = [...s.operators];
          if (i >= 0) operators[i] = normalized;
          else operators.push(normalized);
          return { operators };
        }),

      removeOperator: (id) =>
        set((s) => ({ operators: s.operators.filter((o) => o.id !== id) })),

      upsertCustomer: (c) =>
        set((s) => {
          const normalized = normalizeCustomer(c);
          const i = s.customers.findIndex((x) => x.id === normalized.id);
          const customers = [...s.customers];
          if (i >= 0) customers[i] = { ...customers[i], ...normalized };
          else customers.push(normalized);
          return { customers };
        }),

      markCustomerEmailed: (customerId, emailUsed) =>
        set((s) => {
          const now = new Date().toISOString();
          const customers = s.customers.map((c) => {
            if (c.id !== customerId) return c;
            const emails = [...(c.emails || [])];
            const primary = c.email || emailUsed;
            if (
              emailUsed &&
              emailUsed.toLowerCase() !== primary.toLowerCase() &&
              !emails.some((e) => e.toLowerCase() === emailUsed.toLowerCase())
            ) {
              emails.push(emailUsed);
            }
            return normalizeCustomer({
              ...c,
              email: primary || emailUsed,
              emails,
              lastEmailedAt: now,
            });
          });
          return { customers };
        }),

      getDayBonusLive: (operatorName, dateKey, shiftId) => {
        const s = get();
        const name = (operatorName || "").trim();
        if (!name) return null;
        const ctx = currentShiftContext(s.settings);
        const shift = getShiftById(s.settings, shiftId || ctx.shift.id);
        const dk = dateKey || (shiftId ? dayLocalDateKey() : ctx.dateKey);
        return calculateShiftBonus({
          operatorName: name,
          dateKey: dk,
          shift,
          jobs: s.jobs,
          operatorTimeLog: s.operatorTimeLog,
          downtimes: s.downtimes,
          bonusTiers: s.settings.bonusTiers,
          hourlyRate: s.settings.hourlyRate,
        });
      },

      syncDayBonus: (operatorName, dateKey, shiftId) => {
        const name = (operatorName || "").trim();
        if (!name) return null;
        const s = get();
        const ctx = currentShiftContext(s.settings);
        const shift = getShiftById(s.settings, shiftId || ctx.shift.id);
        const dk =
          dateKey ||
          (shiftId && shiftId !== ctx.shift.id ? dayLocalDateKey() : ctx.dateKey);
        const sid = shift.id;
        const existing = (s.dayBonuses || []).find(
          (r) =>
            r.operatorName === name &&
            r.dateKey === dk &&
            (r.shiftId || "day") === sid,
        );
        if (existing?.status === "finalized") return existing;

        const calc = calculateShiftBonus({
          operatorName: name,
          dateKey: dk,
          shift,
          jobs: s.jobs,
          operatorTimeLog: s.operatorTimeLog,
          downtimes: s.downtimes,
          bonusTiers: s.settings.bonusTiers,
          hourlyRate: s.settings.hourlyRate,
        });
        const rec = toDayBonusRecord(calc, "open", existing);
        set((st) => {
          const list = [...(st.dayBonuses || [])];
          const i = list.findIndex(
            (r) =>
              r.id === rec.id ||
              (r.operatorName === name &&
                r.dateKey === dk &&
                (r.shiftId || "day") === sid),
          );
          if (i >= 0) {
            if (list[i].status === "finalized") return { dayBonuses: list };
            list[i] = rec;
          } else list.push(rec);
          return { dayBonuses: list };
        });
        return (
          get().dayBonuses.find(
            (r) =>
              r.operatorName === name &&
              r.dateKey === dk &&
              (r.shiftId || "day") === sid,
          ) || rec
        );
      },

      syncAllShiftBonuses: (operatorName, dateKey) => {
        const name = (operatorName || "").trim();
        if (!name) return;
        const s = get();
        const shifts = resolveWorkShifts(s.settings).filter((x) => x.enabled);
        const ctx = currentShiftContext(s.settings);
        for (const shift of shifts) {
          // Night shift dateKey is "shift start date" when current; else use provided/today
          let dk = dateKey;
          if (!dk) {
            if (shift.id === ctx.shift.id) dk = ctx.dateKey;
            else dk = dayLocalDateKey();
          }
          get().syncDayBonus(name, dk, shift.id);
        }
      },

      finalizeDayBonus: (operatorName, dateKey, opts) => {
        const name = (operatorName || "").trim();
        if (!name) return { ok: false, error: "Operator required" };
        const s = get();
        const ctx = currentShiftContext(s.settings);
        const shift = getShiftById(s.settings, opts?.shiftId || ctx.shift.id);
        const dk =
          dateKey ||
          (opts?.shiftId && opts.shiftId !== ctx.shift.id
            ? dayLocalDateKey()
            : ctx.dateKey);
        const sid = shift.id;
        const calc = calculateShiftBonus({
          operatorName: name,
          dateKey: dk,
          shift,
          jobs: s.jobs,
          operatorTimeLog: s.operatorTimeLog,
          downtimes: s.downtimes,
          bonusTiers: s.settings.bonusTiers,
          hourlyRate: s.settings.hourlyRate,
        });

        if (!opts?.force && !calc.shiftEnded) {
          return {
            ok: false,
            error: `${shift.name} shift ends at ${shift.end}. Pause/save jobs, then finalize after end of shift.`,
          };
        }

        const existing = (s.dayBonuses || []).find(
          (r) =>
            r.operatorName === name &&
            r.dateKey === dk &&
            (r.shiftId || "day") === sid,
        );
        if (existing?.status === "finalized") {
          return { ok: true, record: existing };
        }

        const rec = toDayBonusRecord(calc, "finalized", existing);
        if (!calc.eligible) {
          rec.bonus = 0;
          rec.eligible = false;
        }

        set((st) => {
          const list = [...(st.dayBonuses || [])];
          const i = list.findIndex(
            (r) =>
              r.operatorName === name &&
              r.dateKey === dk &&
              (r.shiftId || "day") === sid,
          );
          if (i >= 0) list[i] = rec;
          else list.push(rec);

          const weeks = [...(st.weeklyPayouts || [])];
          const prevW = weeks.find(
            (w) => w.operatorName === name && w.weekKey === rec.weekKey,
          );
          const wk = rollupWeek(list, name, rec.weekKey, prevW);
          const wi = weeks.findIndex(
            (w) => w.operatorName === name && w.weekKey === rec.weekKey,
          );
          if (wi >= 0) {
            weeks[wi] = {
              ...wk,
              status: weeks[wi].status === "paid" ? "paid" : wk.status,
              paidAt:
                weeks[wi].status === "paid" ? weeks[wi].paidAt : wk.paidAt,
            };
          } else weeks.push(wk);

          return { dayBonuses: list, weeklyPayouts: weeks };
        });

        const beta = get().settings.betaMode;
        get().addAudit(
          get().currentUserEmail,
          "Finalize Day Bonus",
          `${name} ${dk}: ${rec.eligible ? `$${rec.bonus.toFixed(2)}` : "not eligible"} (${(rec.efficiency * 100).toFixed(0)}%)${beta ? " [BETA — not for payroll]" : ""}`,
        );
        return { ok: true, record: rec };
      },

      markWeekPaid: (operatorName, weekKey) => {
        const name = operatorName.trim();
        if (!name || !weekKey) return { ok: false, error: "Missing operator or week" };
        if (get().settings.betaMode) {
          return {
            ok: false,
            error:
              "Beta mode is on — bonuses are practice only. Turn off Beta in Settings when you're ready to pay for real.",
          };
        }
        set((s) => {
          const weeks = [...(s.weeklyPayouts || [])];
          const list = s.dayBonuses || [];
          const prev = weeks.find(
            (x) => x.operatorName === name && x.weekKey === weekKey,
          );
          const rolled = rollupWeek(list, name, weekKey, prev);
          rolled.status = "paid";
          rolled.paidAt = new Date().toISOString();
          const wi = weeks.findIndex(
            (x) => x.operatorName === name && x.weekKey === weekKey,
          );
          if (wi >= 0) weeks[wi] = rolled;
          else weeks.push(rolled);
          return { weeklyPayouts: weeks };
        });
        get().addAudit(
          get().currentUserEmail,
          "Week Bonus Paid",
          `${name} ${weekKey}`,
        );
        return { ok: true };
      },

      sendChatMessage: (opts) => {
        const body = (opts.body || "").trim();
        const attachments = (opts.attachments || [])
          .filter((a) => a && a.id && a.name)
          .slice(0, 5)
          .map((a) => ({
            id: String(a.id).slice(0, 64),
            name: String(a.name).slice(0, 120),
            mime: String(a.mime || "application/octet-stream").slice(0, 80),
            size: Math.max(0, Number(a.size) || 0),
          }));
        if (!body && !attachments.length) {
          return { ok: false, error: "Type a message or attach a file" };
        }
        if (body.length > 2000) {
          return { ok: false, error: "Message too long (max 2000 characters)" };
        }
        const s = get();
        const me = s.operators.find(
          (o) => o.email.toLowerCase() === s.currentUserEmail.toLowerCase(),
        );
        const fromEmail = s.currentUserEmail;
        if (!fromEmail) return { ok: false, error: "Not signed in" };
        const toEmail = (opts.toEmail || "").trim();
        const channel = toEmail ? "dm" : "shop";
        if (channel === "dm") {
          const dest = s.operators.find(
            (o) =>
              o.email.toLowerCase() === toEmail.toLowerCase() && o.active,
          );
          if (!dest)
            return { ok: false, error: "Pick an active person to message" };
          if (dest.email.toLowerCase() === fromEmail.toLowerCase()) {
            return { ok: false, error: "Use Shop chat for group messages" };
          }
        }
        const msg: ChatMessage = {
          id: uid(),
          channel: channel as "shop" | "dm",
          fromEmail,
          fromName: me?.name || fromEmail.split("@")[0] || "User",
          toEmail: channel === "dm" ? toEmail : "",
          body: body || (attachments.length ? "(attachment)" : ""),
          createdAt: new Date().toISOString(),
          context: (opts.context || "").trim().slice(0, 120),
          readBy: [fromEmail],
          attachments,
        };
        set((st) => ({
          chatMessages: mergeChatMessages(st.chatMessages || [], [msg]),
        }));
        return { ok: true, id: msg.id };
      },

      markChatRead: (messageIds) => {
        const me = get().currentUserEmail;
        if (!me || !messageIds?.length) return;
        const idSet = new Set(messageIds);
        set((st) => ({
          chatMessages: (st.chatMessages || []).map((m) => {
            if (!idSet.has(m.id)) return m;
            if (
              (m.readBy || []).some(
                (e) => e.toLowerCase() === me.toLowerCase(),
              )
            ) {
              return m;
            }
            return { ...m, readBy: [...(m.readBy || []), me] };
          }),
        }));
      },

      addFeedbackTicket: (opts) => {
        const s = get();
        const me = s.operators.find(
          (o) => o.email.toLowerCase() === s.currentUserEmail.toLowerCase(),
        );
        const title = (opts.title || "").trim();
        const body = (opts.body || "").trim();
        if (!title) return { ok: false, error: "Say what happened in a short title." };
        if (!body) return { ok: false, error: "Add a little more detail." };
        const now = new Date().toISOString();
        const ticket: FeedbackTicket = {
          id: uid(),
          kind: opts.kind === "feature" ? "feature" : "bug",
          status: "new",
          title: title.slice(0, 160),
          body: body.slice(0, 4000),
          page: (opts.page || "").trim().slice(0, 80),
          machine: (opts.machine || "").trim().slice(0, 40),
          createdAt: now,
          updatedAt: now,
          createdByName: me?.name || s.currentUserEmail || "Shop",
          createdByEmail: s.currentUserEmail || "",
          attachments: Array.isArray(opts.attachments) ? opts.attachments : [],
          comments: [],
        };
        set({
          feedbackTickets: [ticket, ...(s.feedbackTickets || [])].slice(0, 400),
        });
        get().addAudit(
          s.currentUserEmail,
          opts.kind === "feature" ? "Feature request" : "Bug report",
          title,
        );
        return { ok: true, id: ticket.id };
      },

      addFeedbackComment: (ticketId, body) => {
        const s = get();
        const text = (body || "").trim();
        if (!text) return { ok: false, error: "Type a reply first." };
        const me = s.operators.find(
          (o) => o.email.toLowerCase() === s.currentUserEmail.toLowerCase(),
        );
        const now = new Date().toISOString();
        let found = false;
        set({
          feedbackTickets: (s.feedbackTickets || []).map((t) => {
            if (t.id !== ticketId) return t;
            found = true;
            return {
              ...t,
              updatedAt: now,
              comments: [
                ...(t.comments || []),
                {
                  id: uid(),
                  at: now,
                  byName: me?.name || s.currentUserEmail || "Shop",
                  byEmail: s.currentUserEmail || "",
                  body: text.slice(0, 2000),
                },
              ],
            };
          }),
        });
        if (!found) return { ok: false, error: "Report not found." };
        return { ok: true };
      },

      setFeedbackStatus: (ticketId, status) => {
        const s = get();
        const me = s.operators.find(
          (o) => o.email.toLowerCase() === s.currentUserEmail.toLowerCase(),
        );
        if (me?.role !== "admin") {
          return { ok: false, error: "Only admin can change status." };
        }
        const allowed: FeedbackStatus[] = [
          "new",
          "looking",
          "planned",
          "done",
          "wont",
        ];
        if (!allowed.includes(status)) {
          return { ok: false, error: "Unknown status." };
        }
        const now = new Date().toISOString();
        let found = false;
        set({
          feedbackTickets: (s.feedbackTickets || []).map((t) => {
            if (t.id !== ticketId) return t;
            found = true;
            return { ...t, status, updatedAt: now };
          }),
        });
        if (!found) return { ok: false, error: "Report not found." };
        get().addAudit(s.currentUserEmail, "Feedback status", status);
        return { ok: true };
      },

      removeCustomer: (id) =>
        set((s) => ({ customers: s.customers.filter((c) => c.id !== id) })),

      importHistoricalQuotes: (csvText, mode) => {
        const s = get();
        const opCount = s.settings.maxOperations || 6;
        const parsed = parseQuoteCsv(csvText, opCount);
        if (!parsed.quotes.length) {
          return {
            ok: false,
            created: 0,
            updated: 0,
            skipped: 0,
            total: 0,
            errors: parsed.errors,
            preview: [],
            error: parsed.errors[0] || "No quotes found",
          };
        }
        const merged = mergeQuotes({
          existing: s.quotes || [],
          incoming: parsed.quotes,
          mode,
        });
        for (const name of merged.customerNames || []) {
          get().addCustomerQuick(name);
        }
        set({
          quotes: merged.quotes.map((q) => padQuote(q, opCount)),
        });
        get().addAudit(
          s.currentUserEmail,
          "Import quotes",
          `${merged.created} new, ${merged.updated} updated, ${merged.skipped} skipped (${parsed.quotes.length} rows)`,
        );
        return {
          ok: true,
          created: merged.created,
          updated: merged.updated,
          skipped: merged.skipped,
          total: parsed.quotes.length,
          errors: [...parsed.errors, ...merged.errors],
          preview: merged.preview.slice(0, 50),
        };
      },

      getQuoteByPart: (partNumber) =>
        get().quotes.find(
          (q) => q.partNumber.toLowerCase() === partNumber.trim().toLowerCase(),
        ),

      saveQuote: (q, mode) => {
        const n = maxOpsFrom(get().settings);
        const quote = padQuote(
          {
            ...q,
            partNumber: normalizePartNumber(q.partNumber) || q.partNumber,
            revision: (q.revision || "A").toString().trim().toUpperCase(),
          },
          n,
        );
        // Match P/N + rev (not P/N only) so material recipes stick per revision
        const existing = get().quotes.find(
          (x) => quoteKey(x) === quoteKey(quote),
        );
        // Upsert: Submit creates or overwrites; Update creates if missing
        // (sandbox users often hit the wrong button — never lose material)
        set((s) => {
          let quotes = [...s.quotes];
          let saved: typeof quote | null = null;
          if (existing) {
            saved = {
              ...existing,
              ...quote,
              id: existing.id,
              date: new Date().toISOString(),
              // never blank out material if form sent empty by mistake
              material: quote.material || existing.material,
              materialType: quote.materialType || existing.materialType,
              stockShape: quote.stockShape || existing.stockShape,
              dimX: Number(quote.dimX) || Number(existing.dimX) || 0,
              dimY: Number(quote.dimY) || Number(existing.dimY) || 0,
              dimZ: Number(quote.dimZ) || Number(existing.dimZ) || 0,
              partLengthEach:
                Number(quote.partLengthEach) ||
                Number(existing.partLengthEach) ||
                0,
              rawMaterialLength:
                Number(quote.rawMaterialLength) ||
                Number(existing.rawMaterialLength) ||
                0,
            };
            quotes = quotes.map((x) =>
              quoteKey(x) === quoteKey(quote) ? saved! : x,
            );
          } else {
            saved = { ...quote, id: uid(), date: new Date().toISOString() };
            quotes = [saved, ...s.quotes];
          }
          // Freeze LIVE calculated prices (from recipe + qty breaks) for history
          const live = calculateAssemblyAwareCosts(saved, quotes);
          const pricedSaved = { ...saved, prices: live.prices };
          const snap = freezeQuoteSnapshot(pricedSaved, {
            id: uid(),
            reason: "submit",
          });
          saved = pricedSaved;
          quotes = quotes.map((x) =>
            x.id === saved!.id
              ? { ...saved!, lastSnapshotId: snap.id }
              : x,
          );
          return {
            quotes,
            quoteHistory: [snap, ...(s.quoteHistory || [])].slice(0, 500),
          };
        });
        get().addAudit(
          get().currentUserEmail,
          mode === "submit" ? "Submit Quote" : "Update Quote",
          `${quote.partNumber}${quote.kind === "assembly" ? " (assembly)" : ""}`,
        );
        return { ok: true };
      },

      deleteQuote: (partNumber) => {
        set((s) => ({
          quotes: s.quotes.filter(
            (q) => q.partNumber.toLowerCase() !== partNumber.toLowerCase(),
          ),
        }));
        get().addAudit(get().currentUserEmail, "Delete Quote", partNumber);
      },

      setOperatorOnMachine: (machine, operatorName) =>
        set((s) => {
          const n = maxOpsFrom(s.settings);
          const prev = s.sessions[machine] || emptySession(machine, n);
          return {
            sessions: {
              ...s.sessions,
              [machine]: {
                ...prev,
                operatorName,
                operatorId:
                  s.operators.find((o) => o.name === operatorName)?.id ?? null,
                loginTime: operatorName ? new Date().toISOString() : null,
                shiftStart: operatorName
                  ? new Date().toISOString()
                  : prev.shiftStart,
              },
            },
          };
        }),

      loadJobOnMachine: (machine, opts) => {
        const state = get();
        const n = maxOpsFrom(state.settings);
        const quote = state.getQuoteByPart(opts.partNumber);
        let job: JobRun | undefined;
        if (opts.existingJobId) {
          job = state.jobs.find((j) => j.id === opts.existingJobId);
        }

        const quoted = quote
          ? quotedSecondsFromQuote(quote, n)
          : job
            ? {
                setups: padSlots(job.quotedSetups, n, 0),
                runtimes: padSlots(job.quotedRuntimes, n, 0),
              }
            : { setups: zeros(n), runtimes: zeros(n) };

        const now = new Date().toISOString();
        const jobId = job?.id || uid();

        set((s) => {
          let jobs = [...s.jobs];
          if (!job) {
            const newJob: JobRun = {
              id: jobId,
              partNumber: opts.partNumber.toUpperCase(),
              startTime: now,
              endTime: null,
              setups: nulls(n),
              runtimes: nulls(n),
              quotedSetups: quoted.setups,
              quotedRuntimes: quoted.runtimes,
              status: "In Progress",
              saveTime: null,
              operator: s.sessions[machine]?.operatorName || "",
              efficiency: 0,
              bonus: 0,
              totalElapsed: 0,
              actualTime: 0,
              totalPaused: 0,
              machine,
              revision: opts.revision,
              quantity: opts.quantity,
              customer: opts.customer || quote?.customer || "",
              pauseReason: "",
              machinesUsed: [machine],
              quantityCompleted: 0,
              countInAverage: true,
            };
            jobs = [newJob, ...jobs];
            job = newJob;
          } else {
            jobs = jobs.map((j) =>
              j.id === job!.id
                ? {
                    ...padJob(j, n),
                    machinesUsed: Array.from(
                      new Set([...j.machinesUsed, machine]),
                    ),
                    quotedSetups: quoted.setups,
                    quotedRuntimes: quoted.runtimes,
                  }
                : j,
            );
            job = jobs.find((j) => j.id === jobId)!;
          }

          const prev = s.sessions[machine] || emptySession(machine, n);
          const pairIn = opts.pair;
          const pairPn = (pairIn?.partNumber || "").trim().toUpperCase();
          const skipPair =
            !pairPn || pairPn === String(job?.partNumber || opts.partNumber).toUpperCase();

          let pairJob: JobRun | undefined;
          if (!skipPair && pairIn) {
            if (pairIn.existingJobId) {
              pairJob = jobs.find((j) => j.id === pairIn.existingJobId);
            }
            const pq = s.quotes.find(
              (q) => q.partNumber.toUpperCase() === pairPn,
            );
            const pQuoted = pq
              ? quotedSecondsFromQuote(pq, n)
              : pairJob
                ? {
                    setups: padSlots(pairJob.quotedSetups, n, 0),
                    runtimes: padSlots(pairJob.quotedRuntimes, n, 0),
                  }
                : { setups: zeros(n), runtimes: zeros(n) };
            if (!pairJob) {
              pairJob = {
                id: uid(),
                partNumber: pairPn,
                startTime: now,
                endTime: null,
                setups: nulls(n),
                runtimes: nulls(n),
                quotedSetups: pQuoted.setups,
                quotedRuntimes: pQuoted.runtimes,
                status: "In Progress",
                saveTime: null,
                operator: prev.operatorName || "",
                efficiency: 0,
                bonus: 0,
                totalElapsed: 0,
                actualTime: 0,
                totalPaused: 0,
                machine,
                revision: pairIn.revision || "A",
                quantity: pairIn.quantity || 1,
                customer: pairIn.customer || pq?.customer || "",
                pauseReason: "",
                machinesUsed: [machine],
                quantityCompleted: 0,
                countInAverage: true,
              };
              jobs = [pairJob, ...jobs];
            } else {
              jobs = jobs.map((j) =>
                j.id === pairJob!.id
                  ? {
                      ...padJob(j, n),
                      machinesUsed: Array.from(
                        new Set([...j.machinesUsed, machine]),
                      ),
                    }
                  : j,
              );
              pairJob = jobs.find((j) => j.id === pairJob!.id);
            }
          }

          const session: MachineSession = {
            ...padSession(prev, n),
            jobId,
            partNumber: String(job?.partNumber || opts.partNumber).toUpperCase(),
            revision: job?.revision || opts.revision,
            quantity: job?.quantity || opts.quantity,
            customer: job?.customer || opts.customer || quote?.customer || "",
            setups: job ? padSlots(job.setups, n, null) : nulls(n),
            runtimes: job ? padSlots(job.runtimes, n, null) : nulls(n),
            quotedSetups: quoted.setups,
            quotedRuntimes: quoted.runtimes,
            quantityCompleted: job?.quantityCompleted || 0,
            paused: false,
            pauseStart: null,
            loginTime: prev.loginTime || now,
            operatorName: prev.operatorName || "",
            operatorId: prev.operatorId || null,
            pairJobId: pairJob?.id || "",
            pairPartNumber: pairJob?.partNumber || "",
            pairRevision: pairJob?.revision || "",
            pairQuantity: pairJob?.quantity || 0,
            pairQuantityCompleted: pairJob?.quantityCompleted || 0,
            pairCustomer: pairJob?.customer || "",
          };

          return {
            jobs,
            sessions: { ...s.sessions, [machine]: session },
            activeTimers: { ...s.activeTimers, [machine]: null },
          };
        });

        get().addAudit(
          state.currentUserEmail,
          "Load Job",
          `${opts.partNumber} on ${machine}` +
            (opts.pair?.partNumber ? ` + ${opts.pair.partNumber}` : ""),
        );
        return { ok: true };
      },

      attachPairOnMachine: (machine, opts) => {
        const state = get();
        const n = maxOpsFrom(state.settings);
        const sess = state.sessions[machine];
        if (!sess?.jobId) return { ok: false, error: "Load a job first" };
        const pairPn = (opts.partNumber || "").trim().toUpperCase();
        if (!pairPn) return { ok: false, error: "Enter the nested part number" };
        if (pairPn === (sess.partNumber || "").toUpperCase()) {
          return { ok: false, error: "Nested part has to be a different P/N" };
        }

        const now = new Date().toISOString();
        const pq = state.quotes.find(
          (q) => q.partNumber.toUpperCase() === pairPn,
        );
        let pairJob: JobRun | undefined;
        if (opts.existingJobId) {
          pairJob = state.jobs.find((j) => j.id === opts.existingJobId);
        }

        set((s) => {
          let jobs = [...s.jobs];
          if (!pairJob) {
            const pQuoted = pq
              ? quotedSecondsFromQuote(pq, n)
              : { setups: zeros(n), runtimes: zeros(n) };
            pairJob = {
              id: uid(),
              partNumber: pairPn,
              startTime: now,
              endTime: null,
              setups: nulls(n),
              runtimes: nulls(n),
              quotedSetups: pQuoted.setups,
              quotedRuntimes: pQuoted.runtimes,
              status: "In Progress",
              saveTime: null,
              operator: sess.operatorName || "",
              efficiency: 0,
              bonus: 0,
              totalElapsed: 0,
              actualTime: 0,
              totalPaused: 0,
              machine,
              revision: (opts.revision || pq?.revision || "A").toUpperCase(),
              quantity: opts.quantity || pq?.quantities?.find((q) => q > 0) || sess.quantity || 1,
              customer: opts.customer || pq?.customer || sess.customer || "",
              pauseReason: "",
              machinesUsed: [machine],
              quantityCompleted: 0,
              countInAverage: true,
            };
            jobs = [pairJob, ...jobs];
          } else {
            jobs = jobs.map((j) =>
              j.id === pairJob!.id
                ? {
                    ...padJob(j, n),
                    machinesUsed: Array.from(
                      new Set([...j.machinesUsed, machine]),
                    ),
                  }
                : j,
            );
            pairJob = jobs.find((j) => j.id === pairJob!.id);
          }

          const prev = s.sessions[machine] || sess;
          return {
            jobs,
            sessions: {
              ...s.sessions,
              [machine]: {
                ...padSession(prev, n),
                pairJobId: pairJob?.id || "",
                pairPartNumber: pairJob?.partNumber || pairPn,
                pairRevision: pairJob?.revision || opts.revision || "A",
                pairQuantity: pairJob?.quantity || opts.quantity || 1,
                pairQuantityCompleted: pairJob?.quantityCompleted || 0,
                pairCustomer: pairJob?.customer || "",
              },
            },
          };
        });

        get().addAudit(
          state.currentUserEmail,
          "Nest pair on machine",
          `${sess.partNumber} + ${pairPn} on ${machine}`,
        );
        return { ok: true };
      },

      clearPairOnMachine: (machine) => {
        const state = get();
        const sess = state.sessions[machine];
        if (!sess?.jobId) return { ok: false, error: "No job loaded" };
        if (!sess.pairJobId && !sess.pairPartNumber) {
          return { ok: false, error: "No nested part on this machine" };
        }
        const n = maxOpsFrom(state.settings);
        const dropped = sess.pairPartNumber;
        set((s) => {
          const prev = s.sessions[machine] || emptySession(machine, n);
          return {
            sessions: {
              ...s.sessions,
              [machine]: {
                ...padSession(prev, n),
                pairJobId: "",
                pairPartNumber: "",
                pairRevision: "",
                pairQuantity: 0,
                pairQuantityCompleted: 0,
                pairCustomer: "",
              },
            },
          };
        });
        get().addAudit(
          state.currentUserEmail,
          "Drop nested part",
          `${dropped} off ${machine} · ${sess.partNumber} still loaded`,
        );
        return { ok: true };
      },

      clearMachineSession: (machine) =>
        set((s) => {
          const n = maxOpsFrom(s.settings);
          return {
            sessions: { ...s.sessions, [machine]: emptySession(machine, n) },
            activeTimers: { ...s.activeTimers, [machine]: null },
          };
        }),

      updateSessionNotes: (machine, notes) =>
        set((s) => {
          const n = maxOpsFrom(s.settings);
          return {
            sessions: {
              ...s.sessions,
              [machine]: {
                ...(s.sessions[machine] || emptySession(machine, n)),
                notes,
              },
            },
          };
        }),


      startShopToolingLog: (opts) => {
        const s = get();
        const machine = opts.machine;
        const session = s.sessions[machine];
        if (!session?.operatorName) {
          return { ok: false, error: "Sign in an operator first" };
        }
        if (!session.partNumber?.trim()) {
          return { ok: false, error: "Load a job / part first" };
        }
        const running = (s.shopToolingLogs || []).find(
          (l) =>
            l.machine === machine && l.status === "open" && l.timerStartedAt,
        );
        if (running) {
          return {
            ok: false,
            error: "Stop the current soft jaws / tooling timer first",
          };
        }
        const log = emptyShopToolingLog({
          machine,
          operator: session.operatorName,
          jobId: session.jobId,
          partNumber: session.partNumber,
          revision: session.revision || "",
          customer: session.customer || "",
          kind: opts.kind || "soft_jaws",
          description: opts.description,
          notes: opts.notes || "",
          billRequest: Boolean(opts.billRequest),
          suggestedBillAmount: Number(opts.suggestedBillAmount) || 0,
          minutes: 0,
          timerStartedAt: new Date().toISOString(),
          status: "open",
        });
        set({
          shopToolingLogs: [log, ...(s.shopToolingLogs || [])].slice(0, 500),
        });
        get().addAudit(
          s.currentUserEmail,
          "Tooling timer start",
          `${log.kind} · ${log.partNumber} on ${machine}`,
        );
        return { ok: true, id: log.id };
      },

      stopShopToolingTimer: (id) => {
        const s = get();
        const log = (s.shopToolingLogs || []).find((l) => l.id === id);
        if (!log) return { ok: false, error: "Log not found" };
        if (!log.timerStartedAt)
          return { ok: false, error: "Timer not running" };
        const minutes = liveToolingMinutes(log);
        const next = {
          ...log,
          minutes,
          timerStartedAt: null as string | null,
          updatedAt: new Date().toISOString(),
        };
        set({
          shopToolingLogs: (s.shopToolingLogs || []).map((l) =>
            l.id === id ? next : l,
          ),
        });
        get().addAudit(
          s.currentUserEmail,
          "Tooling timer stop",
          `${next.partNumber} · ${minutes} min`,
        );
        return { ok: true };
      },

      upsertShopToolingLog: (log) => {
        const s = get();
        const normalized = emptyShopToolingLog({
          ...log,
          updatedAt: new Date().toISOString(),
        });
        if (!normalized.partNumber.trim()) {
          return { ok: false, error: "Part number required" };
        }
        const list = [...(s.shopToolingLogs || [])];
        const idx = list.findIndex((l) => l.id === normalized.id);
        if (idx >= 0) list[idx] = normalized;
        else list.unshift(normalized);
        set({ shopToolingLogs: list.slice(0, 500) });
        return { ok: true };
      },

      resolveShopToolingLog: (id, status, extra) => {
        const s = get();
        const log = (s.shopToolingLogs || []).find((l) => l.id === id);
        if (!log) return { ok: false, error: "Log not found" };
        let minutes = log.minutes;
        let timerStartedAt = log.timerStartedAt;
        if (timerStartedAt) {
          minutes = liveToolingMinutes(log);
          timerStartedAt = null;
        }
        set({
          shopToolingLogs: (s.shopToolingLogs || []).map((l) =>
            l.id === id
              ? {
                  ...l,
                  minutes,
                  timerStartedAt,
                  status,
                  quoteId: extra?.quoteId ?? l.quoteId,
                  toolingChargeId: extra?.toolingChargeId ?? l.toolingChargeId,
                  updatedAt: new Date().toISOString(),
                }
              : l,
          ),
        });
        return { ok: true };
      },

      applyShopToolingLogToQuote: (logId, quoteId, opts) => {
        const s = get();
        const log = (s.shopToolingLogs || []).find((l) => l.id === logId);
        if (!log) return { ok: false, error: "Log not found" };
        let working = log;
        if (log.timerStartedAt) {
          const minutes = liveToolingMinutes(log);
          working = { ...log, minutes, timerStartedAt: null };
        }
        if (opts?.minutes != null && Number.isFinite(opts.minutes)) {
          working = {
            ...working,
            minutes: Math.max(0, Number(opts.minutes)),
            timerStartedAt: null,
          };
        }
        if (opts?.billUnitPrice != null && Number.isFinite(opts.billUnitPrice)) {
          working = {
            ...working,
            suggestedBillAmount: Math.max(0, Number(opts.billUnitPrice)),
          };
        }
        if (opts?.billCustomer != null) {
          working = { ...working, billRequest: Boolean(opts.billCustomer) };
        }
        if (opts?.description != null) {
          working = { ...working, description: opts.description };
        }
        const q =
          (quoteId && s.quotes.find((x) => x.id === quoteId)) ||
          s.quotes.find(
            (x) =>
              x.partNumber.toUpperCase() === working.partNumber.toUpperCase() &&
              (!working.revision ||
                x.revision.toUpperCase() === working.revision.toUpperCase()),
          ) ||
          s.quotes.find(
            (x) =>
              x.partNumber.toUpperCase() === working.partNumber.toUpperCase(),
          );
        if (!q) {
          return {
            ok: false,
            error:
              "No quote for this part — open Master Quoter and save the part first",
          };
        }
        const charge = toolingChargeFromShopLog(working, {
          minutes: working.minutes,
          billUnitPrice: opts?.billUnitPrice,
          shopCost: opts?.shopCost,
          billCustomer: opts?.billCustomer ?? working.billRequest,
          description: opts?.description ?? working.description,
        });
        const toolingCharges = [...(q.toolingCharges || []), charge];
        const nextQ = { ...q, toolingCharges };
        set({
          quotes: s.quotes.map((x) => (x.id === q.id ? nextQ : x)),
          shopToolingLogs: (s.shopToolingLogs || []).map((l) =>
            l.id === logId
              ? {
                  ...working,
                  status: "applied_to_quote" as const,
                  quoteId: q.id,
                  toolingChargeId: charge.id,
                  updatedAt: new Date().toISOString(),
                }
              : l,
          ),
        });
        get().addAudit(
          s.currentUserEmail,
          "Tooling → quote",
          `${working.partNumber} · ${charge.description}`,
        );
        return { ok: true };
      },


      updateSessionField: (machine, patch) =>
        set((s) => {
          const n = maxOpsFrom(s.settings);
          return {
            sessions: {
              ...s.sessions,
              [machine]: {
                ...(s.sessions[machine] || emptySession(machine, n)),
                ...patch,
              },
            },
          };
        }),

      smartStart: (machine) => {
        const state = get();
        const n = maxOpsFrom(state.settings);
        const session = padSession(
          state.sessions[machine] || emptySession(machine, n),
          n,
        );
        if (!session?.jobId) return { ok: false, error: "Load a job first." };
        if (!session.operatorName)
          return { ok: false, error: "Select an operator." };
        if (!canControlMachine(state, session.operatorName)) {
          return {
            ok: false,
            error: "Switch to this operator, or sign in as admin, to run the timer.",
          };
        }
        if (state.activeTimers[machine]) {
          return { ok: false, error: "A timer is already running. Stop it first." };
        }
        if (session.paused) {
          return { ok: false, error: "Job is paused. Resume before starting." };
        }

        const next = findNextOperation(session);
        if (!next) return { ok: false, error: "All operations are complete." };

        const idx = opIndex(next.operation);
        const cell =
          next.type === "Setup" ? session.setups[idx] : session.runtimes[idx];
        const accumulated = typeof cell === "number" && cell > 0 ? cell : 0;

        const timer: ActiveTimer = {
          jobId: session.jobId,
          machine,
          operation: next.operation,
          type: next.type,
          startIso: new Date().toISOString(),
          accumulatedSeconds: accumulated,
        };

        set((s) => {
          const sess = padSession(
            s.sessions[machine] || emptySession(machine, n),
            n,
          );
          const setups = [...sess.setups];
          const runtimes = [...sess.runtimes];
          if (next.type === "Setup") setups[idx] = "STARTED";
          else runtimes[idx] = "STARTED";
          sess.setups = setups;
          sess.runtimes = runtimes;

          const jobs = s.jobs.map((j) => {
            if (j.id !== session.jobId) return j;
            const padded = padJob(j, n);
            const js = [...padded.setups];
            const jr = [...padded.runtimes];
            if (next.type === "Setup") js[idx] = "STARTED";
            else jr[idx] = "STARTED";
            return { ...padded, setups: js, runtimes: jr };
          });

          return {
            activeTimers: { ...s.activeTimers, [machine]: timer },
            sessions: { ...s.sessions, [machine]: sess },
            jobs,
            operatorTimeLog: [
              {
                id: uid(),
                jobId: session.jobId!,
                machine,
                operation: next.operation,
                type: next.type,
                operator: session.operatorName,
                startTime: timer.startIso,
                endTime: null,
                durationHours: 0,
                unitsCompleted: null,
              },
              ...s.operatorTimeLog,
            ],
          };
        });

        return {
          ok: true,
          message: `Started ${next.type} ${next.operation}`,
        };
      },

      smartStop: (machine, unitsCompleted) => {
        const state = get();
        const n = maxOpsFrom(state.settings);
        const timer = state.activeTimers[machine];
        if (!timer) return { ok: false, error: "No timer running." };
        if (
          !canControlMachine(
            state,
            state.sessions[machine]?.operatorName || "",
          )
        ) {
          return {
            ok: false,
            error: "Switch to this operator, or sign in as admin, to stop the timer.",
          };
        }

        if (timer.type === "Runtime" && unitsCompleted === undefined) {
          return { ok: false, needsUnits: true };
        }

        const now = Date.now();
        const elapsed = Math.floor(
          (now - new Date(timer.startIso).getTime()) / 1000,
        );
        const total = timer.accumulatedSeconds + Math.max(0, elapsed);
        const idx = opIndex(timer.operation);

        set((s) => {
          const sess = padSession(
            s.sessions[machine] || emptySession(machine, n),
            n,
          );
          const setups = [...sess.setups];
          const runtimes = [...sess.runtimes];
          if (timer.type === "Setup") setups[idx] = total;
          else {
            runtimes[idx] = total;
            if (unitsCompleted != null) {
              sess.quantityCompleted =
                (sess.quantityCompleted || 0) + (Number(unitsCompleted) || 0);
              if (sess.pairJobId) {
                sess.pairQuantityCompleted =
                  (sess.pairQuantityCompleted || 0) +
                  (Number(unitsCompleted) || 0);
              }
            }
          }
          sess.setups = setups;
          sess.runtimes = runtimes;
          const refreshed = refreshEfficiency(sess, s.settings);

          const jobs = s.jobs.map((j) => {
            const addQty =
              timer.type === "Runtime" && unitsCompleted != null
                ? Number(unitsCompleted) || 0
                : 0;
            if (j.id === timer.jobId) {
              const padded = padJob(j, n);
              const js = [...padded.setups];
              const jr = [...padded.runtimes];
              if (timer.type === "Setup") js[idx] = total;
              else jr[idx] = total;
              return {
                ...padded,
                setups: js,
                runtimes: jr,
                quantityCompleted: (j.quantityCompleted || 0) + addQty,
                efficiency: refreshed.efficiency,
                bonus: refreshed.bonus,
              };
            }
            if (sess.pairJobId && j.id === sess.pairJobId && addQty) {
              return {
                ...padJob(j, n),
                quantityCompleted: (j.quantityCompleted || 0) + addQty,
              };
            }
            return j;
          });

          const log = s.operatorTimeLog.map((row) => {
            if (
              row.jobId === timer.jobId &&
              row.machine === machine &&
              row.operation === timer.operation &&
              row.type === timer.type &&
              !row.endTime
            ) {
              const end = new Date().toISOString();
              const durationHours =
                (new Date(end).getTime() - new Date(row.startTime).getTime()) /
                3600000;
              return {
                ...row,
                endTime: end,
                durationHours,
                unitsCompleted:
                  timer.type === "Runtime" ? Number(unitsCompleted) || 0 : null,
              };
            }
            return row;
          });

          return {
            sessions: { ...s.sessions, [machine]: refreshed },
            jobs,
            activeTimers: { ...s.activeTimers, [machine]: null },
            operatorTimeLog: log,
          };
        });

        const opName = get().sessions[machine]?.operatorName;
        if (opName) get().syncAllShiftBonuses(opName);
        return { ok: true };
      },

      pauseJob: (machine, reason) => {
        const state = get();
        const session = state.sessions[machine];
        if (!session?.jobId) return { ok: false, error: "No active job." };
        if (session.paused) return { ok: false, error: "Job is already paused." };

        const timer = state.activeTimers[machine];
        const startIso = new Date().toISOString();
        let pausedTimer = session.pausedTimer || null;
        if (timer) {
          const elapsed = Math.floor(
            (Date.now() - new Date(timer.startIso).getTime()) / 1000,
          );
          pausedTimer = {
            operation: timer.operation,
            type: timer.type,
            accumulatedSeconds: timer.accumulatedSeconds + Math.max(0, elapsed),
          };
        }

        const downtime: DowntimeEntry = {
          id: uid(),
          jobId: session.jobId,
          machine,
          operator: session.operatorName,
          reason,
          startTime: startIso,
          endTime: null,
        };

        set((s) => {
          const log = timer
            ? s.operatorTimeLog.map((row) => {
                if (
                  row.jobId === timer.jobId &&
                  row.machine === machine &&
                  row.operation === timer.operation &&
                  row.type === timer.type &&
                  !row.endTime
                ) {
                  const end = startIso;
                  const durationHours =
                    (new Date(end).getTime() -
                      new Date(row.startTime).getTime()) /
                    3600000;
                  return { ...row, endTime: end, durationHours };
                }
                return row;
              })
            : s.operatorTimeLog;

          return {
            sessions: {
              ...s.sessions,
              [machine]: {
                ...session,
                paused: true,
                pauseStart: startIso,
                pausedTimer,
              },
            },
            activeTimers: timer
              ? { ...s.activeTimers, [machine]: null }
              : s.activeTimers,
            operatorTimeLog: log,
            downtimes: [downtime, ...s.downtimes],
            jobs: s.jobs.map((j) =>
              j.id === session.jobId ? { ...j, pauseReason: reason } : j,
            ),
          };
        });

        get().addAudit(
          session.operatorName,
          "Pause",
          timer
            ? `${session.partNumber}: ${reason} · froze ${timer.type} ${timer.operation}`
            : `${session.partNumber}: ${reason}`,
        );
        return { ok: true };
      },

      resumeJob: (machine) => {
        const state = get();
        const session = state.sessions[machine];
        if (!session?.paused) return { ok: false, error: "Job is not paused." };
        const endIso = new Date().toISOString();
        const snapshot = session.pausedTimer || null;
        const n = maxOpsFrom(state.settings);

        set((s) => {
          const downtimes = s.downtimes.map((d) =>
            d.jobId === session.jobId && !d.endTime
              ? { ...d, endTime: endIso }
              : d,
          );
          const nextSess = {
            ...session,
            paused: false,
            pauseStart: null,
            pausedTimer: null,
          };
          if (!snapshot || !session.jobId) {
            return {
              downtimes,
              sessions: { ...s.sessions, [machine]: nextSess },
            };
          }

          const timer: ActiveTimer = {
            jobId: session.jobId,
            machine,
            operation: snapshot.operation,
            type: snapshot.type,
            startIso: endIso,
            accumulatedSeconds: snapshot.accumulatedSeconds,
          };
          const sess = padSession(nextSess, n);
          const idx = opIndex(snapshot.operation);
          const setups = [...sess.setups];
          const runtimes = [...sess.runtimes];
          if (snapshot.type === "Setup") setups[idx] = "STARTED";
          else runtimes[idx] = "STARTED";
          sess.setups = setups;
          sess.runtimes = runtimes;

          return {
            downtimes,
            sessions: { ...s.sessions, [machine]: sess },
            activeTimers: { ...s.activeTimers, [machine]: timer },
            operatorTimeLog: [
              {
                id: uid(),
                jobId: session.jobId,
                machine,
                operation: snapshot.operation,
                type: snapshot.type,
                operator: session.operatorName,
                startTime: endIso,
                endTime: null,
                durationHours: 0,
                unitsCompleted: null,
              },
              ...s.operatorTimeLog,
            ],
          };
        });

        get().addAudit(
          session.operatorName || get().currentUserEmail,
          "Resume",
          snapshot
            ? `${session.partNumber || machine} · ${snapshot.type} ${snapshot.operation}`
            : session.partNumber || machine,
        );
        return {
          ok: true,
          message: snapshot
            ? `Resumed ${snapshot.type} ${snapshot.operation}`
            : "Resumed",
        };
      },

      adjustOpTime: (machine, opIndexArg, type, seconds) => {
        const state = get();
        if (!isCurrentUserAdmin(state)) {
          return { ok: false, error: "Only an admin can correct timer times." };
        }
        const n = maxOpsFrom(state.settings);
        const session = padSession(
          state.sessions[machine] || emptySession(machine, n),
          n,
        );
        if (!session.jobId) return { ok: false, error: "No job loaded." };
        const idx = Math.max(0, Math.min(n - 1, Math.floor(opIndexArg)));
        const sec = Math.max(0, Math.round(Number(seconds) || 0));
        const operation = opLabel(idx);
        const timer = state.activeTimers[machine];
        const nowIso = new Date().toISOString();

        set((s) => {
          const sess = padSession(
            s.sessions[machine] || emptySession(machine, n),
            n,
          );
          const setups = [...sess.setups];
          const runtimes = [...sess.runtimes];
          let nextTimers = s.activeTimers;
          let pausedTimer = sess.pausedTimer || null;

          const runningThis =
            timer &&
            timer.operation === operation &&
            timer.type === type;

          if (runningThis && timer) {
            nextTimers = {
              ...s.activeTimers,
              [machine]: {
                ...timer,
                accumulatedSeconds: sec,
                startIso: nowIso,
              },
            };
            if (type === "Setup") setups[idx] = "STARTED";
            else runtimes[idx] = "STARTED";
          } else if (
            pausedTimer &&
            pausedTimer.operation === operation &&
            pausedTimer.type === type
          ) {
            pausedTimer = { ...pausedTimer, accumulatedSeconds: sec };
            if (type === "Setup") setups[idx] = "STARTED";
            else runtimes[idx] = "STARTED";
          } else {
            if (type === "Setup") setups[idx] = sec;
            else runtimes[idx] = sec;
          }

          sess.setups = setups;
          sess.runtimes = runtimes;
          sess.pausedTimer = pausedTimer;
          const refreshed = refreshEfficiency(sess, s.settings);

          const jobs = s.jobs.map((j) => {
            if (j.id !== session.jobId) return j;
            const padded = padJob(j, n);
            const js = [...padded.setups];
            const jr = [...padded.runtimes];
            if (!runningThis) {
              if (type === "Setup") js[idx] = setups[idx];
              else jr[idx] = runtimes[idx];
            }
            return {
              ...padded,
              setups: js,
              runtimes: jr,
              efficiency: refreshed.efficiency,
              bonus: refreshed.bonus,
            };
          });

          return {
            sessions: { ...s.sessions, [machine]: refreshed },
            activeTimers: nextTimers,
            jobs,
          };
        });

        get().addAudit(
          get().currentUserEmail,
          "Adjust time",
          `${session.partNumber || machine} · ${type} ${operation} → ${sec}s`,
        );
        return { ok: true };
      },

      reopenOpTimer: (machine, opIndexArg, type, seconds) => {
        const state = get();
        if (!isCurrentUserAdmin(state)) {
          return {
            ok: false,
            error: "Only an admin can put an operator back on a timer.",
          };
        }
        const n = maxOpsFrom(state.settings);
        const session = padSession(
          state.sessions[machine] || emptySession(machine, n),
          n,
        );
        if (!session.jobId) return { ok: false, error: "No job loaded." };
        const idx = Math.max(0, Math.min(n - 1, Math.floor(opIndexArg)));
        const operation = opLabel(idx);
        const running = state.activeTimers[machine];
        if (
          running &&
          running.operation === operation &&
          running.type === type
        ) {
          if (seconds != null) {
            return get().adjustOpTime(machine, idx, type, seconds);
          }
          return { ok: true, message: `Already on ${type} ${operation}` };
        }

        const cell =
          type === "Setup" ? session.setups[idx] : session.runtimes[idx];
        const fromCell = typeof cell === "number" ? cell : 0;
        const acc =
          seconds != null
            ? Math.max(0, Math.round(Number(seconds) || 0))
            : fromCell;
        const nowIso = new Date().toISOString();

        const lastClosed = (state.operatorTimeLog || []).find(
          (row) =>
            row.jobId === session.jobId &&
            row.machine === machine &&
            row.operation === operation &&
            row.type === type &&
            row.endTime,
        );
        const unitsToUnwind =
          type === "Runtime" && lastClosed?.unitsCompleted
            ? Number(lastClosed.unitsCompleted) || 0
            : 0;

        set((s) => {
          const sess = padSession(
            s.sessions[machine] || emptySession(machine, n),
            n,
          );
          const setups = [...sess.setups];
          const runtimes = [...sess.runtimes];
          const other = s.activeTimers[machine];

          if (
            other &&
            (other.operation !== operation || other.type !== type)
          ) {
            const oIdx = opIndex(other.operation);
            if (other.type === "Setup" && setups[oIdx] === "STARTED") {
              setups[oIdx] = null;
            }
            if (other.type === "Runtime" && runtimes[oIdx] === "STARTED") {
              runtimes[oIdx] = null;
            }
          }

          if (type === "Setup") setups[idx] = "STARTED";
          else runtimes[idx] = "STARTED";

          sess.setups = setups;
          sess.runtimes = runtimes;
          sess.paused = false;
          sess.pauseStart = null;
          sess.pausedTimer = null;
          if (unitsToUnwind > 0) {
            sess.quantityCompleted = Math.max(
              0,
              (sess.quantityCompleted || 0) - unitsToUnwind,
            );
          }

          const timer: ActiveTimer = {
            jobId: session.jobId!,
            machine,
            operation,
            type,
            startIso: nowIso,
            accumulatedSeconds: acc,
          };

          const jobs = s.jobs.map((j) => {
            if (j.id !== session.jobId) return j;
            const padded = padJob(j, n);
            const js = [...padded.setups];
            const jr = [...padded.runtimes];
            if (
              other &&
              (other.operation !== operation || other.type !== type)
            ) {
              const oIdx = opIndex(other.operation);
              if (other.type === "Setup" && js[oIdx] === "STARTED") js[oIdx] = null;
              if (other.type === "Runtime" && jr[oIdx] === "STARTED") jr[oIdx] = null;
            }
            if (type === "Setup") js[idx] = "STARTED";
            else jr[idx] = "STARTED";
            return {
              ...padded,
              setups: js,
              runtimes: jr,
              quantityCompleted:
                unitsToUnwind > 0
                  ? Math.max(0, (j.quantityCompleted || 0) - unitsToUnwind)
                  : j.quantityCompleted,
            };
          });

          const log = (s.operatorTimeLog || []).filter((row) => {
            if (!other) return true;
            if (
              row.jobId === other.jobId &&
              row.machine === machine &&
              row.operation === other.operation &&
              row.type === other.type &&
              !row.endTime
            ) {
              return false;
            }
            return true;
          });

          return {
            sessions: { ...s.sessions, [machine]: sess },
            activeTimers: { ...s.activeTimers, [machine]: timer },
            jobs,
            operatorTimeLog: [
              {
                id: uid(),
                jobId: session.jobId!,
                machine,
                operation,
                type,
                operator: session.operatorName,
                startTime: nowIso,
                endTime: null,
                durationHours: 0,
                unitsCompleted: null,
              },
              ...log,
            ],
          };
        });

        get().addAudit(
          get().currentUserEmail,
          "Reopen timer",
          `${session.partNumber || machine} · ${type} ${operation} @ ${acc}s`,
        );
        return {
          ok: true,
          message: `Back on ${type} ${operation} · ${Math.floor(acc / 60)}m ${acc % 60}s`,
        };
      },

      saveJob: (machine, mode, qtyCompleted, opts) => {
        const state = get();
        const n = maxOpsFrom(state.settings);
        const session = state.sessions[machine];
        if (!session?.jobId) return { ok: false, error: "No job loaded." };
        if (state.activeTimers[machine]) {
          return { ok: false, error: "Stop the timer before saving." };
        }
        if (mode === "in-progress" && !session.paused) {
          return {
            ok: false,
            error: "Pause the job before saving as In Progress.",
          };
        }

        const now = new Date().toISOString();
        set((s) => {
          const sess = refreshEfficiency(
            {
              ...padSession(session, n),
              quantityCompleted:
                qtyCompleted != null ? qtyCompleted : session.quantityCompleted,
            },
            s.settings,
          );

          const jobs = s.jobs.map((j) => {
            const isPrimary = j.id === session.jobId;
            const isPair = Boolean(session.pairJobId) && j.id === session.pairJobId;
            if (!isPrimary && !isPair) return j;
            let totalPaused = j.totalPaused || 0;
            for (const d of s.downtimes) {
              if (d.jobId === j.id && d.endTime) {
                const a = new Date(d.startTime).getTime();
                const b = new Date(d.endTime!).getTime();
                totalPaused += Math.max(0, (b - a) / 1000);
              }
            }
            let actual = 0;
            for (let i = 0; i < sess.setups.length; i++) {
              if (typeof sess.setups[i] === "number")
                actual += Number(sess.setups[i]);
              if (typeof sess.runtimes[i] === "number")
                actual += Number(sess.runtimes[i]);
            }
            return {
              ...padJob(j, n),
              setups: isPrimary ? [...sess.setups] : j.setups,
              runtimes: isPrimary ? [...sess.runtimes] : j.runtimes,
              quantityCompleted: isPair
                ? sess.pairQuantityCompleted || j.quantityCompleted
                : sess.quantityCompleted,
              efficiency: isPrimary ? sess.efficiency : j.efficiency,
              bonus: isPrimary ? sess.bonus : j.bonus,
              actualTime: isPrimary ? actual : j.actualTime,
              totalPaused: isPrimary ? totalPaused : j.totalPaused,
              totalElapsed: isPrimary ? actual + totalPaused : j.totalElapsed,
              status:
                mode === "completed"
                  ? ("Completed" as const)
                  : ("In Progress" as const),
              saveTime: now,
              endTime: mode === "completed" ? now : null,
              operator: sess.operatorName || j.operator,
              countInAverage:
                mode === "completed"
                  ? opts?.countInAverage !== false
                  : j.countInAverage !== false,
            };
          });

          // On complete: roll shop averages into matching quote recipe (not prices)
          let quotes = s.quotes;
          if (mode === "completed" && opts?.countInAverage !== false) {
            const saved = jobs.find((j) => j.id === session.jobId);
            if (saved?.partNumber) {
              const stats = computePartRunStats(
                jobs,
                saved.partNumber,
                saved.revision || sess.revision || "",
                n,
                {
                  averageMaxRuns: s.settings.averageMaxRuns ?? 10,
                  averageOutlierRatio: s.settings.averageOutlierRatio ?? 1.5,
                },
              );
              if (stats.averagedRuns > 0) {
                const weight = s.settings.averageShopWeight ?? 0.7;
                quotes = s.quotes.map((q) => {
                  const samePn =
                    q.partNumber.toUpperCase() ===
                    saved.partNumber.toUpperCase();
                  if (!samePn) return q;
                  const sameRev =
                    !saved.revision ||
                    !q.revision ||
                    q.revision.toUpperCase() === saved.revision.toUpperCase();
                  if (!sameRev) return q;
                  return padQuote(
                    applyAveragesToQuote(q, stats, {
                      weightShop: weight,
                      opCount: n,
                    }),
                    n,
                  );
                });
              }
            }
          }

          const sessions = {
            ...s.sessions,
            [machine]:
              mode === "completed"
                ? {
                    ...emptySession(machine, n),
                    operatorName: sess.operatorName,
                    operatorId: sess.operatorId,
                    loginTime: new Date().toISOString(),
                  }
                : { ...sess, paused: false, pauseStart: null },
          };

          return { jobs, sessions, quotes };
        });

        get().addAudit(
          session.operatorName,
          mode === "completed" ? "Complete Job" : "Save In Progress",
          mode === "completed"
            ? `${session.partNumber} on ${machine} · part DB times averaged`
            : `${session.partNumber} on ${machine}`,
        );
        if (session.operatorName) get().syncAllShiftBonuses(session.operatorName);

        // Complete → mark matching PO line(s) ready for packing
        if (mode === "completed" && session.partNumber) {
          const targets = [
            {
              pn: session.partNumber.toUpperCase(),
              rev: (session.revision || "").toUpperCase(),
              qty: session.quantityCompleted || 0,
            },
          ];
          if (session.pairPartNumber) {
            targets.push({
              pn: session.pairPartNumber.toUpperCase(),
              rev: (session.pairRevision || "").toUpperCase(),
              qty: session.pairQuantityCompleted || 0,
            });
          }
          const by = session.operatorName || "Shop";
          const now = new Date().toISOString();
          set((st) => {
            let changed = false;
            const shopOrders = (st.shopOrders || []).map((o) => {
              let lineHit = false;
              const lines = (o.lines || []).map((l) => {
                const match = targets.find((t) => {
                  if ((l.partNumber || "").toUpperCase() !== t.pn) return false;
                  if (t.rev && l.revision && l.revision.toUpperCase() !== t.rev)
                    return false;
                  return true;
                });
                if (!match) {
                  const comps = (l.components || []).map((c) => {
                    const cm = targets.find(
                      (t) => (c.partNumber || "").toUpperCase() === t.pn,
                    );
                    if (!cm || c.complete) return c;
                    lineHit = true;
                    changed = true;
                    return {
                      ...c,
                      complete: true,
                      completedAt: now,
                      completedBy: by,
                      checkedOutBy: "",
                      checkedOutAt: "",
                      checkedOutMachine: "",
                    };
                  });
                  if (comps !== l.components && lineHit) {
                    return { ...l, components: comps };
                  }
                  return l;
                }
                if (l.readyForPack || l.linePacked) return l;
                lineHit = true;
                changed = true;
                return emptyShopOrderLine({
                  ...l,
                  readyForPack: true,
                  readyForPackAt: now,
                  readyForPackBy: by,
                  checkedOutBy: "",
                  checkedOutAt: "",
                  checkedOutMachine: "",
                  qtyCompleted: Math.max(l.qtyCompleted || 0, match.qty || l.qty || 0),
                });
              });
              if (!lineHit) return o;
              return { ...o, lines, updatedAt: now };
            });
            return changed ? { shopOrders } : {};
          });
        }
        return { ok: true };
      },

      updateSettings: (patch) =>
        set((s) => {
          const next = {
            ...s.settings,
            ...patch,
            betaMode:
              patch.betaMode != null
                ? Boolean(patch.betaMode)
                : s.settings.betaMode != null
                  ? Boolean(s.settings.betaMode)
                  : true,
            customLists: normalizeCustomLists(
              patch.customLists ?? s.settings.customLists,
            ),
          };
          // Keep legacy workDay* and shifts[] aligned
          let shifts = resolveWorkShifts(next);
          if (patch.shifts) {
            shifts = resolveWorkShifts({ ...next, shifts: patch.shifts });
          } else if (
            patch.workDayStart != null ||
            patch.workDayEnd != null ||
            patch.lunchHours != null
          ) {
            shifts = shifts.map((sh) =>
              sh.id === "day"
                ? {
                    ...sh,
                    start: next.workDayStart || sh.start,
                    end: next.workDayEnd || sh.end,
                    lunchHours:
                      next.lunchHours != null ? next.lunchHours : sh.lunchHours,
                  }
                : sh,
            );
          }
          const day = shifts.find((x) => x.id === "day") || shifts[0];
          if (day) {
            next.workDayStart = day.start;
            next.workDayEnd = day.end;
            next.lunchHours = day.lunchHours;
          }
          next.shifts = shifts;
          if (patch.maxOperations != null) {
            next.maxOperations = clampOpCount(patch.maxOperations);
            const n = next.maxOperations;
            const sessions: LcmState["sessions"] = {};
            for (const m of Object.keys(s.sessions)) {
              sessions[m] = padSession(s.sessions[m], n);
            }
            return {
              settings: next,
              sessions,
              quotes: s.quotes.map((q) => padQuote(q, n)),
              jobs: s.jobs.map((j) => padJob(j, n)),
            };
          }
          return { settings: next };
        }),

      verifyPassword: (pw) => {
        const stored = get().settings.editPassword || "";
        if (!stored || stored === "••••" || stored.startsWith("v1$")) {
          // Client no longer holds a usable secret — callers should use verifyEditPassword server fn
          return false;
        }
        return stored === pw;
      },

      resetToSeed: () => set({ ...createSeedState() }),

      exportJson: () => {
        const s = get();
        return JSON.stringify(
          {
            format: "lcm-shared-state-v1",
            exportedAt: new Date().toISOString(),
            currentUserEmail: s.currentUserEmail,
            ...s.getSharedState(),
          },
          null,
          2,
        );
      },

      importJson: (raw) => {
        try {
          const data = JSON.parse(raw) as Partial<LcmState>;
          if (!data.quotes || !data.jobs) {
            return { ok: false, error: "Invalid backup file." };
          }
          const settings = {
            ...get().settings,
            ...(data.settings || {}),
            maxOperations: clampOpCount(
              data.settings?.maxOperations ?? get().settings.maxOperations,
            ),
            customLists: normalizeCustomLists(
              data.settings?.customLists ?? get().settings.customLists,
            ),
          };
          const n = maxOpsFrom(settings);
          const machines = allMachines(settings.customLists);
          set((s) => {
            const baseSessions = data.sessions
              ? Object.fromEntries(
                  Object.entries(data.sessions).map(([k, v]) => [
                    k,
                    padSession(v as MachineSession, n),
                  ]),
                )
              : s.sessions;
            const ensured = ensureMachineSessions(
              baseSessions,
              data.activeTimers || s.activeTimers,
              machines,
              n,
            );
            return {
              operators: migrateOperators(
                (data.operators as Operator[]) || s.operators,
              ),
              customers:
                migrateCustomers(data.customers as Customer[]) || s.customers,
              quotes: (data.quotes || []).map((q) => padQuote(q as Quote, n)),
              jobs: (data.jobs || []).map((j) => padJob(j as JobRun, n)),
              downtimes: data.downtimes ?? s.downtimes,
              operatorTimeLog: data.operatorTimeLog ?? s.operatorTimeLog,
              auditLog: data.auditLog ?? s.auditLog,
              sessions: ensured.sessions,
              activeTimers: ensured.activeTimers,
              settings,
              currentUserEmail: data.currentUserEmail || s.currentUserEmail,
              dayBonuses: data.dayBonuses ?? s.dayBonuses,
              weeklyPayouts: data.weeklyPayouts ?? s.weeklyPayouts,
              materialStock: data.materialStock ?? s.materialStock,
              partStock: data.partStock ?? s.partStock,
              partUnits: data.partUnits ?? s.partUnits,
              inventoryTxns: data.inventoryTxns ?? s.inventoryTxns,
              purchaseOrders: data.purchaseOrders ?? s.purchaseOrders,
              vendorRfqs: data.vendorRfqs ?? s.vendorRfqs,
              shopOrders: data.shopOrders ?? s.shopOrders,
              workQueue: data.workQueue ?? s.workQueue,
              cutTickets: data.cutTickets ?? s.cutTickets,
              stockPieces: data.stockPieces ?? s.stockPieces,
              quoteHistory: data.quoteHistory ?? s.quoteHistory,
              emailLog: data.emailLog ?? s.emailLog,
              chatMessages: data.chatMessages ?? s.chatMessages,
              shopToolingLogs: data.shopToolingLogs ?? s.shopToolingLogs,
              feedbackTickets: data.feedbackTickets ?? s.feedbackTickets,
            };
          });
          return { ok: true };
        } catch {
          return { ok: false, error: "Could not parse JSON." };
        }
      },


      upsertMaterialStock: (item) => {
        const now = new Date().toISOString();
        const row = emptyMaterial({
          ...item,
          id: item.id || uid(),
          updatedAt: now,
        });
        set((s) => {
          const list = [...(s.materialStock || [])];
          const i = list.findIndex((x) => x.id === row.id);
          if (i >= 0) list[i] = row;
          else list.unshift(row);
          return { materialStock: list };
        });
        get().addAudit(
          get().currentUserEmail,
          "Inventory",
          `Material stock: ${materialLabel(row)}`,
        );
      },

      removeMaterialStock: (id) => {
        const row = (get().materialStock || []).find((x) => x.id === id);
        set((s) => ({
          materialStock: (s.materialStock || []).filter((x) => x.id !== id),
        }));
        if (row) {
          get().addAudit(
            get().currentUserEmail,
            "Inventory",
            `Deleted material: ${materialLabel(row)}`,
          );
        }
      },

      upsertPartStock: (item) => {
        const now = new Date().toISOString();
        const row = emptyPart({
          ...item,
          id: item.id || uid(),
          partNumber: (item.partNumber || "").trim(),
          updatedAt: now,
        });
        if (!row.partNumber) return;
        set((s) => {
          const list = [...(s.partStock || [])];
          const i = list.findIndex((x) => x.id === row.id);
          if (i >= 0) list[i] = row;
          else list.unshift(row);
          return { partStock: list };
        });
        get().addAudit(
          get().currentUserEmail,
          "Inventory",
          `Part stock: ${partLabel(row)}`,
        );
      },

      removePartStock: (id) => {
        const row = (get().partStock || []).find((x) => x.id === id);
        set((s) => ({
          partStock: (s.partStock || []).filter((x) => x.id !== id),
        }));
        if (row) {
          get().addAudit(
            get().currentUserEmail,
            "Inventory",
            `Deleted part stock: ${partLabel(row)}`,
          );
        }
      },

      stockPartUnits: (opts) => {
        const pn = (opts.partNumber || "").trim();
        if (!pn) return { ok: false, error: "Part number required" };
        const qty = Math.max(0, Math.floor(Number(opts.qty) || 0));
        if (qty <= 0) return { ok: false, error: "Quantity must be > 0" };
        const quality = opts.quality === "second" ? "second" : "good";
        const defect = (opts.defectNote || "").trim();
        if (quality === "second" && !defect) {
          return {
            ok: false,
            error: "Describe the potential defect for second-quality parts",
          };
        }

        const s0 = get();
        const existingCodes = (s0.partUnits || []).map((u) => u.uin);
        const units: PartUnit[] = [];
        for (let i = 0; i < qty; i++) {
          const uin = generatePartUin(
            existingCodes.concat(units.map((u) => u.uin)),
          );
          units.push({
            id: uid(),
            uin,
            partNumber: pn,
            revision: (opts.revision || "").trim() || "A",
            quality,
            defectNote: quality === "second" ? defect : "",
            location: (opts.location || "").trim(),
            status: "available",
            jobRef: opts.jobRef || "",
            stockedBy: s0.currentUserEmail,
            stockedAt: new Date().toISOString(),
            notes:
              quality === "second"
                ? `Second quality: ${defect}`
                : "Good finished extra",
          });
        }

        const isSecond = quality === "second";
        const category = isSecond
          ? "Second quality / blemish"
          : "Finished part";
        const list = [...(s0.partStock || [])];
        const rev = (opts.revision || "").trim();
        const idx = list.findIndex((p) => {
          if (p.partNumber.toLowerCase() !== pn.toLowerCase()) return false;
          if ((p.revision || "").toLowerCase() !== rev.toLowerCase()) return false;
          const second =
            (p.category || "").toLowerCase().includes("second") ||
            (p.category || "").toLowerCase().includes("blemish");
          return isSecond ? second : !second;
        });
        const stamp = new Date().toLocaleString();
        const uinList = units.map((u) => u.uin).join(", ");
        const noteLine = isSecond
          ? `${stamp}: +${qty} pcs UINs ${uinList} — DEFECT: ${defect}`
          : `${stamp}: +${qty} good extras UINs ${uinList}`;

        let stockRow: PartStock;
        if (idx >= 0) {
          const prev = list[idx];
          stockRow = {
            ...prev,
            onHand: (prev.onHand || 0) + qty,
            location: (opts.location || "").trim() || prev.location,
            category,
            notes: prev.notes ? `${noteLine}\n${prev.notes}` : noteLine,
            updatedAt: new Date().toISOString(),
          };
          list[idx] = stockRow;
        } else {
          stockRow = emptyPart({
            id: uid(),
            partNumber: pn,
            revision: rev || "A",
            description: isSecond
              ? "Second quality / sellable with note"
              : "Finished extras from job",
            category,
            onHand: qty,
            location: (opts.location || "").trim(),
            notes: noteLine,
          });
          list.unshift(stockRow);
        }

        const txn = makeTxn({
          id: uid(),
          by: s0.currentUserEmail,
          kind: "receive",
          itemKind: "part",
          itemId: stockRow.id,
          label: `${pn} · UINs ${uinList}`,
          qty,
          balanceAfter: stockRow.onHand,
          reason: isSecond
            ? `Job extras · second quality: ${defect}`
            : "Job over-run extras (good)",
          ref: opts.jobRef || "",
        });

        set({
          partUnits: [...units, ...(s0.partUnits || [])],
          partStock: list,
          inventoryTxns: [txn, ...(s0.inventoryTxns || [])].slice(0, 2000),
        });
        get().addAudit(
          s0.currentUserEmail,
          "Part UINs",
          `${pn} +${qty} · ${uinList}`,
        );
        return { ok: true, units };
      },

      getPartUnitByUin: (uin) => {
        const code = normalizeUin(uin);
        if (!code) return undefined;
        return (get().partUnits || []).find(
          (u) => normalizeUin(u.uin) === code,
        );
      },

      issuePartUnit: (uin, opts) => {
        const code = normalizeUin(uin);
        const s = get();
        const units = [...(s.partUnits || [])];
        const i = units.findIndex((u) => normalizeUin(u.uin) === code);
        if (i < 0) return { ok: false, error: "UIN not found" };
        if (units[i].status !== "available") {
          return { ok: false, error: `Already ${units[i].status}` };
        }
        units[i] = { ...units[i], status: "issued" };
        const row = units[i];
        const list = [...(s.partStock || [])];
        const pi = list.findIndex((p) => {
          if (p.partNumber.toLowerCase() !== row.partNumber.toLowerCase())
            return false;
          if (
            (p.revision || "").toLowerCase() !==
            (row.revision || "").toLowerCase()
          )
            return false;
          const second =
            (p.category || "").toLowerCase().includes("second") ||
            (p.category || "").toLowerCase().includes("blemish");
          return row.quality === "second" ? second : !second;
        });
        if (pi >= 0) {
          list[pi] = {
            ...list[pi],
            onHand: Math.max(0, (list[pi].onHand || 0) - 1),
            updatedAt: new Date().toISOString(),
          };
        }
        set({
          partUnits: units,
          partStock: list,
        });
        get().addAudit(
          s.currentUserEmail,
          "Issue part UIN",
          `${code} · ${opts?.reason || ""}`.trim(),
        );
        return { ok: true };
      },

      inventoryMove: (opts) => {
        const s = get();
        const qtyIn = Number(opts.qty);
        if (!Number.isFinite(qtyIn)) {
          return { ok: false, error: "Invalid quantity" };
        }
        if (opts.kind !== "adjust" && qtyIn <= 0) {
          return { ok: false, error: "Quantity must be greater than zero" };
        }

        if (opts.itemKind === "material") {
          const list = [...(s.materialStock || [])];
          const i = list.findIndex((x) => x.id === opts.itemId);
          if (i < 0) return { ok: false, error: "Material not found" };
          const row = { ...list[i] };
          let next = row.onHand;
          let txnQty = qtyIn;
          if (opts.kind === "adjust" && opts.setAbsolute) {
            next = qtyIn;
            txnQty = next - row.onHand;
          } else {
            next = applyQtyChange(row.onHand, opts.kind, qtyIn);
          }
          if (next < 0) return { ok: false, error: "Not enough on hand" };
          row.onHand = next;
          row.updatedAt = new Date().toISOString();
          list[i] = row;
          const txn = makeTxn({
            id: uid(),
            by: s.currentUserEmail,
            kind: opts.kind,
            itemKind: "material",
            itemId: row.id,
            label: materialLabel(row),
            qty: txnQty,
            balanceAfter: next,
            reason: opts.reason,
            ref: opts.ref,
          });
          set({
            materialStock: list,
            inventoryTxns: [txn, ...(s.inventoryTxns || [])].slice(0, 500),
          });
          return { ok: true, balance: next };
        }

        const list = [...(s.partStock || [])];
        const i = list.findIndex((x) => x.id === opts.itemId);
        if (i < 0) return { ok: false, error: "Part not found" };
        const row = { ...list[i] };
        let next = row.onHand;
        let txnQty = qtyIn;
        if (opts.kind === "adjust" && opts.setAbsolute) {
          next = qtyIn;
          txnQty = next - row.onHand;
        } else {
          next = applyQtyChange(row.onHand, opts.kind, qtyIn);
        }
        if (next < 0) return { ok: false, error: "Not enough on hand" };
        row.onHand = next;
        row.updatedAt = new Date().toISOString();
        list[i] = row;
        const txn = makeTxn({
          id: uid(),
          by: s.currentUserEmail,
          kind: opts.kind,
          itemKind: "part",
          itemId: row.id,
          label: partLabel(row),
          qty: txnQty,
          balanceAfter: next,
          reason: opts.reason,
          ref: opts.ref,
        });
        set({
          partStock: list,
          inventoryTxns: [txn, ...(s.inventoryTxns || [])].slice(0, 500),
        });
        return { ok: true, balance: next };
      },




      assignShopOrderLine: (opts) => {
        const s = get();
        const order = (s.shopOrders || []).find((o) => o.id === opts.orderId);
        if (!order) return { ok: false, error: "Shop order not found" };
        const line = order.lines.find((l) => l.id === opts.lineId);
        if (!line) return { ok: false, error: "Line not found" };
        const machine = (opts.machine || "").trim();
        if (!machine) return { ok: false, error: "Pick a machine" };
        const open = Math.max(0, (line.qty || 0) - (line.qtyCompleted || 0));
        const qty = opts.qty != null ? Number(opts.qty) : open;
        if (!Number.isFinite(qty) || qty <= 0) {
          return { ok: false, error: "Qty must be > 0" };
        }
        if (!line.partNumber.trim()) {
          return { ok: false, error: "Line needs a part number" };
        }

        const id = uid();
        const item = emptyWorkQueueItem({
          id,
          shopOrderId: order.id,
          shopOrderLineId: line.id,
          poNumber: order.poNumber,
          customer: order.customer,
          partNumber: line.partNumber,
          revision: line.revision,
          description: line.description,
          qty,
          machine,
          operatorName: (opts.operatorName || "").trim(),
          sortOrder: nextSortOrder(s.workQueue || [], machine),
          status: "queued",
          notes: opts.notes || "",
          createdBy: s.currentUserEmail,
        });

        set((st) => ({
          workQueue: [...(st.workQueue || []), item],
        }));
        get().addAudit(
          s.currentUserEmail,
          "Queue",
          `${line.partNumber} ×${qty} → ${machine}` +
            (opts.operatorName ? ` (${opts.operatorName})` : "") +
            ` PO ${order.poNumber}`,
        );
        return { ok: true, itemId: id };
      },

      officeAssignPart: (opts) => {
        const s = get();
        const who = (opts.operatorName || "").trim();
        if (!who) return { ok: false, error: "Pick who this part is for" };
        const order = (s.shopOrders || []).find((o) => o.id === opts.orderId);
        if (!order) return { ok: false, error: "Order not found" };
        const line = (order.lines || []).find((l) => l.id === opts.lineId);
        if (!line) return { ok: false, error: "Line not found" };
        const now = new Date().toISOString();
        const mach = (opts.machine || "").trim();
        const notes = (opts.notes || "").trim();
        if (opts.componentId) {
          const comps = line.components || [];
          const comp = comps.find((c) => c.id === opts.componentId);
          if (!comp) return { ok: false, error: "Component not found" };
          get().patchShopOrderLine(
            opts.orderId,
            opts.lineId,
            patchComponent(line, opts.componentId, {
              officeAssignedTo: who,
              officeAssignedMachine: mach,
              officeAssignedAt: now,
              officeAssignNotes: notes,
            }),
          );
          get().addAudit(
            s.currentUserEmail,
            "Office assign",
            `${order.poNumber} ${comp.partNumber} → ${who}` +
              (mach ? ` @ ${mach}` : ""),
          );
          return { ok: true };
        }
        get().patchShopOrderLine(opts.orderId, opts.lineId, {
          officeAssignedTo: who,
          officeAssignedMachine: mach,
          officeAssignedAt: now,
          officeAssignNotes: notes,
        });
        get().addAudit(
          s.currentUserEmail,
          "Office assign",
          `${order.poNumber} ${line.partNumber} → ${who}` +
            (mach ? ` @ ${mach}` : ""),
        );
        return { ok: true };
      },

      applyMaterialCount: (plan) => {
        if (!plan) return { ok: false, error: "No count plan", adjusted: 0, created: 0 };
        if (plan.errorCount > 0) {
          return {
            ok: false,
            error: `Fix ${plan.errorCount} error(s) first`,
            adjusted: 0,
            created: 0,
          };
        }
        let adjusted = 0;
        let created = 0;
        for (const action of plan.actions) {
          if (action.kind === "adjust") {
            const r = get().inventoryMove({
              itemKind: "material",
              itemId: action.stockId,
              kind: "adjust",
              qty: action.toQty,
              setAbsolute: true,
              reason: action.notes || "Floor count",
              ref: "material-count",
            });
            if (!r.ok) {
              return {
                ok: false,
                error: r.error || "Adjust failed",
                adjusted,
                created,
              };
            }
            if (action.sizeNote) {
              const item = get().materialStock.find((m) => m.id === action.stockId);
              if (item) {
                get().upsertMaterialStock({
                  ...item,
                  sizeNote: action.sizeNote,
                  updatedAt: new Date().toISOString(),
                });
              }
            }
            adjusted++;
          } else if (action.kind === "create") {
            get().upsertMaterialStock(
              emptyMaterial({
                id: uid(),
                material: action.material,
                materialType: action.materialType,
                stockShape: action.stockShape,
                sizeNote: action.sizeNote,
                location: action.location,
                unit: (action.unit as MaterialStock["unit"]) || "pcs",
                onHand: action.toQty,
                notes: action.notes || "Created from floor count",
              }),
            );
            created++;
          }
        }
        get().addAudit(
          get().currentUserEmail,
          "Material floor count",
          `${adjusted} adjusted · ${created} new`,
        );
        return { ok: true, adjusted, created };
      },

      updateWorkQueueItem: (id, patch) => {
        set((s) => ({
          workQueue: (s.workQueue || []).map((q) =>
            q.id === id
              ? emptyWorkQueueItem({
                  ...q,
                  ...patch,
                  id: q.id,
                  updatedAt: new Date().toISOString(),
                })
              : q,
          ),
        }));
      },

      removeWorkQueueItem: (id) => {
        set((s) => ({
          workQueue: (s.workQueue || []).filter((q) => q.id !== id),
        }));
      },

      moveWorkQueueItem: (id, direction) => {
        const s = get();
        const list = [...(s.workQueue || [])];
        const item = list.find((q) => q.id === id);
        if (!item || !item.machine) return;
        const peers = list
          .filter(
            (q) =>
              q.machine === item.machine &&
              (q.status === "queued" ||
                q.status === "held" ||
                q.status === "active"),
          )
          .sort((a, b) => a.sortOrder - b.sortOrder);
        const idx = peers.findIndex((q) => q.id === id);
        if (idx < 0) return;
        const swapWith = direction === "up" ? idx - 1 : idx + 1;
        if (swapWith < 0 || swapWith >= peers.length) return;
        const a = peers[idx];
        const b = peers[swapWith];
        const orderA = a.sortOrder;
        const orderB = b.sortOrder;
        set({
          workQueue: list.map((q) => {
            if (q.id === a.id)
              return { ...q, sortOrder: orderB, updatedAt: new Date().toISOString() };
            if (q.id === b.id)
              return { ...q, sortOrder: orderA, updatedAt: new Date().toISOString() };
            return q;
          }),
        });
      },

      startWorkQueueItem: (id) => {
        const s = get();
        const item = (s.workQueue || []).find((q) => q.id === id);
        if (!item) return { ok: false, error: "Queue item not found" };
        if (!item.machine) return { ok: false, error: "No machine assigned" };
        if (item.status === "done" || item.status === "cancelled") {
          return { ok: false, error: "Item is closed" };
        }

        // If someone else is running on that machine, still allow load (same as manual)
        const load = get().loadJobOnMachine(item.machine, {
          partNumber: item.partNumber,
          revision: item.revision,
          quantity: item.qty,
          customer: item.customer,
          existingJobId: item.jobId || undefined,
        });
        if (!load.ok) return { ok: false, error: load.error || "Could not load job" };

        const session = get().sessions[item.machine];
        const jobId = session?.jobId || item.jobId;

        // Optional: set session operator from queue assignment
        if (item.operatorName) {
          const op = s.operators.find(
            (o) =>
              o.name.toLowerCase() === item.operatorName.toLowerCase() ||
              o.email.toLowerCase() === item.operatorName.toLowerCase(),
          );
          set((st) => {
            const n = maxOpsFrom(st.settings);
            const prev = st.sessions[item.machine] || emptySession(item.machine, n);
            return {
              sessions: {
                ...st.sessions,
                [item.machine]: {
                  ...prev,
                  operatorName: item.operatorName,
                  operatorId: op?.id || prev.operatorId,
                },
              },
            };
          });
        }

        set((st) => ({
          workQueue: (st.workQueue || []).map((q) => {
            if (q.id === id) {
              return {
                ...q,
                status: "active" as const,
                jobId: jobId || q.jobId,
                updatedAt: new Date().toISOString(),
              };
            }
            // only one active per machine
            if (
              q.machine === item.machine &&
              q.id !== id &&
              q.status === "active"
            ) {
              return {
                ...q,
                status: "queued" as const,
                updatedAt: new Date().toISOString(),
              };
            }
            return q;
          }),
        }));

        get().addAudit(
          s.currentUserEmail,
          "Start queue",
          `${item.partNumber} on ${item.machine}`,
        );
        return { ok: true };
      },

      completeWorkQueueItem: (id) => {
        set((s) => ({
          workQueue: (s.workQueue || []).map((q) =>
            q.id === id
              ? {
                  ...q,
                  status: "done" as const,
                  qtyCompleted: q.qty,
                  updatedAt: new Date().toISOString(),
                }
              : q,
          ),
        }));
      },

      createShopOrder: (partial) => {
        const s = get();
        const order = emptyShopOrder({
          ...partial,
          id: partial?.id || uid(),
          createdBy: partial?.createdBy || s.currentUserEmail,
          lines: enrichShopOrderLines(
            (partial?.lines || []).map((l) =>
              emptyShopOrderLine({ ...l, id: l.id || uid() }),
            ),
            s.quotes || [],
            s.materialStock || [],
            s.partStock || [],
            { shopOrders: s.shopOrders || [], recomputeNeed: true },
          ),
        });
        order.status = deriveShopOrderStatus(order);
        set((st) => ({
          shopOrders: [order, ...(st.shopOrders || [])],
        }));
        get().addAudit(
          s.currentUserEmail,
          "Shop order",
          `Created customer PO ${order.poNumber || order.id}`,
        );
        return order;
      },

      upsertShopOrder: (order) => {
        const row = emptyShopOrder({
          ...order,
          status: deriveShopOrderStatus(order),
          updatedAt: new Date().toISOString(),
          lines: (order.lines || []).map((l, idx) =>
            emptyShopOrderLine({
              ...l,
              id: l.id || uid(),
              itemNo: l.itemNo || idx + 1,
            }),
          ),
        });
        set((s) => {
          const list = [...(s.shopOrders || [])];
          const i = list.findIndex((x) => x.id === row.id);
          if (i >= 0) list[i] = row;
          else list.unshift(row);
          return { shopOrders: list };
        });
      },


      enrichShopOrderMaterial: (orderId) => {
        set((s) => {
          const list = [...(s.shopOrders || [])];
          const i = list.findIndex((o) => o.id === orderId);
          if (i < 0) return {};
          const order = list[i];
          const lines = enrichShopOrderLines(
            order.lines || [],
            s.quotes || [],
            s.materialStock || [],
            s.partStock || [],
            {
              preserveReviewed: true,
              recomputeNeed: true,
              shopOrders: s.shopOrders || [],
            },
          );
          list[i] = {
            ...order,
            lines,
            updatedAt: new Date().toISOString(),
          };
          return { shopOrders: list };
        });
      },

      setShopLineMaterialReviewed: (orderId, lineId, reviewed) => {
        const s0 = get();
        const order0 = (s0.shopOrders || []).find((o) => o.id === orderId);
        const line0 = order0?.lines.find((l) => l.id === lineId);
        if (reviewed && line0) {
          get().syncPartMaterialRecipe(line0);
        }
        set((s) => {
          const list = [...(s.shopOrders || [])];
          const i = list.findIndex((o) => o.id === orderId);
          if (i < 0) return {};
          const order = list[i];
          const lines = order.lines.map((l) =>
            l.id === lineId
              ? {
                  ...l,
                  materialReviewed: reviewed,
                  materialStatus: reviewed ? ("ok" as const) : l.materialStatus,
                  attentionReason: reviewed ? "" : l.attentionReason,
                }
              : l,
          );
          const next = reviewed
            ? lines
            : enrichShopOrderLines(
                lines,
                s.quotes || [],
                s.materialStock || [],
                s.partStock || [],
                {
                  preserveReviewed: true,
                  shopOrders: s.shopOrders || [],
                },
              );
          list[i] = {
            ...order,
            lines: next,
            updatedAt: new Date().toISOString(),
          };
          return { shopOrders: list };
        });
      },

      syncPartMaterialRecipe: (line) => {
        const pn = (line.partNumber || "").trim();
        if (!pn) return;
        if (!(line.material || "").trim() && !line.dimX && !line.sizeNote) return;
        const s = get();
        const n = maxOpsFrom(s.settings);
        const { quote } = findQuoteForPart(
          s.quotes || [],
          pn,
          line.revision || "",
        );
        const materialFields = {
          material: line.material || "",
          materialType: line.materialType || "",
          stockShape: line.stockShape || "",
          dimX: line.dimX || 0,
          dimY: line.dimY || 0,
          dimZ: line.dimZ || 0,
          partLengthEach: line.partLengthEach || 0,
          rawMaterialLength: line.rawMaterialLength || 0,
          materialVendor: line.materialVendor || "",
        };
        const rev = line.revision || quote?.revision || "";
        if (quote) {
          const saved = padQuote(
            {
              ...quote,
              ...materialFields,
              revision: rev || quote.revision,
              date: new Date().toISOString(),
            },
            n,
          );
          set((st) => ({
            quotes: (st.quotes || []).map((q) =>
              q.id === quote.id ? saved : q,
            ),
          }));
          get().addAudit(
            s.currentUserEmail,
            "Part material",
            `Saved recipe for ${pn} rev ${rev || "—"}`,
          );
          return;
        }
        // Create a minimal part-DB record so next import auto-fills
        const created = padQuote(
          {
            id: uid(),
            date: new Date().toISOString(),
            customer: "",
            partNumber: pn,
            revision: rev,
            kind: "part",
            bom: [],
            benchAssembleMinutes: 0,
            machines: [],
            machineRate: 1,
            materialPct: 1.15,
            rawMaterialCost: 0,
            calculateMaterialDrop: false,
            dropMultiplier: 1,
            setupTimes: [],
            runTimes: [],
            quantities: [1, 5, 10, 25],
            prices: [0, 0, 0, 0],
            toolingCharges: [],
            ...materialFields,
          } as Quote,
          n,
        );
        set((st) => ({
          quotes: [created, ...(st.quotes || [])],
        }));
        get().addAudit(
          s.currentUserEmail,
          "Part material",
          `Created part DB recipe for ${pn}`,
        );
      },

      removeShopOrder: (id) => {
        set((s) => ({
          shopOrders: (s.shopOrders || []).filter((x) => x.id !== id),
          workQueue: (s.workQueue || []).filter((q) => q.shopOrderId !== id),
        }));
        get().addAudit(get().currentUserEmail, "Delete PO", id);
      },

      setShopOrderPackStatus: (orderId, status, byName) => {
        const s = get();
        const order = (s.shopOrders || []).find((o) => o.id === orderId);
        if (!order) return { ok: false, error: "Order not found" };
        const now = new Date().toISOString();
        const name = (byName || "").trim() || "User";
        let patch: Partial<ShopOrder> = { packStatus: status, updatedAt: now };
        if (status === "pending") {
          patch = {
            packStatus: "pending",
            packedBy: "",
            packedAt: "",
            verifiedBy: "",
            verifiedAt: "",
            updatedAt: now,
          };
        } else if (status === "packed") {
          patch = {
            packStatus: "packed",
            packedBy: name,
            packedAt: now,
            verifiedBy: "",
            verifiedAt: "",
            updatedAt: now,
          };
        } else {
          patch = {
            packStatus: "verified",
            packedBy: order.packedBy || name,
            packedAt: order.packedAt || now,
            verifiedBy: name,
            verifiedAt: now,
            updatedAt: now,
          };
        }
        const next: ShopOrder = {
          ...order,
          packStatus: patch.packStatus || "pending",
          packedBy: patch.packedBy ?? order.packedBy ?? "",
          packedAt: patch.packedAt ?? order.packedAt ?? "",
          verifiedBy: patch.verifiedBy ?? order.verifiedBy ?? "",
          verifiedAt: patch.verifiedAt ?? order.verifiedAt ?? "",
          updatedAt: now,
        };
        get().upsertShopOrder(next);
        get().addAudit(
          get().currentUserEmail,
          "Ship pack",
          `${order.poNumber || orderId}: ${status} by ${name}`,
        );
        return { ok: true };
      },

      patchShopOrderLine: (orderId, lineId, patch) => {
        const s = get();
        const order = (s.shopOrders || []).find((o) => o.id === orderId);
        if (!order) return { ok: false, error: "Order not found" };
        const lines = (order.lines || []).map((l) =>
          l.id === lineId ? emptyShopOrderLine({ ...l, ...patch }) : l,
        );
        if (!lines.some((l) => l.id === lineId))
          return { ok: false, error: "Line not found" };
        get().upsertShopOrder({
          ...order,
          lines,
          updatedAt: new Date().toISOString(),
        });
        return { ok: true };
      },

      pullJobBoardLine: (orderId, lineId, byName, machine, componentId) => {
        const s = get();
        const order = (s.shopOrders || []).find((o) => o.id === orderId);
        if (!order) return { ok: false, error: "Order not found" };
        let line = (order.lines || []).find((l) => l.id === lineId);
        if (!line) return { ok: false, error: "Line not found" };
        // Promote related files → components so pull targets exist
        const promoted = promoteRelatedFilesToComponents(line);
        if ((promoted.components || []).length && !(line.components || []).length) {
          get().patchShopOrderLine(orderId, lineId, promoted);
          line = {
            ...line,
            ...promoted,
            components: promoted.components || [],
          } as typeof line;
        }
        if (line.readyForPack || line.linePacked)
          return { ok: false, error: "Line already done / at packing" };
        if (!line.revPdfOk || !line.stockNoted)
          return {
            ok: false,
            error: "Office must confirm PDF rev + stock note before this job",
          };
        if (lineHasCad(line) && !line.revCadOk)
          return { ok: false, error: "CAD rev not confirmed yet" };
        const comps = normalizeComponents(line);
        const anyCompCad = comps.some((c) => (c.cadFiles || []).length > 0);
        if (anyCompCad && !line.revCadOk)
          return { ok: false, error: "CAD rev not confirmed yet" };

        const now = new Date().toISOString();
        const who = byName.trim() || "User";
        const mach = (machine || "").trim();

        if (componentId) {
          const comp = comps.find((c) => c.id === componentId);
          if (!comp) return { ok: false, error: "Component not found" };
          if (comp.complete)
            return { ok: false, error: "Component already complete" };
          if (comp.checkedOutBy && comp.checkedOutBy !== who)
            return {
              ok: false,
              error: `Already taken — ${comp.checkedOutBy}'s job`,
            };
          get().patchShopOrderLine(
            orderId,
            lineId,
            patchComponent(line, componentId, {
              checkedOutBy: who,
              checkedOutAt: now,
              checkedOutMachine: mach,
            }),
          );
          get().addAudit(
            get().currentUserEmail,
            "Take job (component)",
            `${order.poNumber} ${comp.partNumber} by ${who}`,
          );
          return { ok: true };
        }

        // Assembly / simple line pull
        if (comps.length && !allComponentsComplete(line)) {
          const open = comps
            .filter((c) => !c.complete)
            .map((c) => c.partNumber)
            .join(", ");
          return {
            ok: false,
            error: `Finish components first: ${open}`,
          };
        }
        if (line.checkedOutBy && line.checkedOutBy !== who)
          return {
            ok: false,
            error: `Already taken — ${line.checkedOutBy}'s job`,
          };
        get().patchShopOrderLine(orderId, lineId, {
          checkedOutBy: who,
          checkedOutAt: now,
          checkedOutMachine: mach,
        });
        get().addAudit(
          get().currentUserEmail,
          "Take job",
          `${order.poNumber} ${line.partNumber} by ${who}`,
        );
        return { ok: true };
      },

      returnJobBoardLine: (orderId, lineId, componentId) => {
        const s = get();
        const order = (s.shopOrders || []).find((o) => o.id === orderId);
        const line = order?.lines?.find((l) => l.id === lineId);
        if (componentId && line) {
          get().patchShopOrderLine(
            orderId,
            lineId,
            patchComponent(line, componentId, {
              checkedOutBy: "",
              checkedOutAt: "",
              checkedOutMachine: "",
            }),
          );
          return { ok: true };
        }
        get().patchShopOrderLine(orderId, lineId, {
          checkedOutBy: "",
          checkedOutAt: "",
          checkedOutMachine: "",
        });
        return { ok: true };
      },

      markLineReadyForPack: (orderId, lineId, byName, componentId) => {
        const s = get();
        const order = (s.shopOrders || []).find((o) => o.id === orderId);
        if (!order) return { ok: false, error: "Order not found" };
        const line = (order.lines || []).find((l) => l.id === lineId);
        if (!line) return { ok: false, error: "Line not found" };
        const now = new Date().toISOString();
        const who = byName.trim() || "User";

        if (componentId) {
          // Component machining done — not packing yet
          get().patchShopOrderLine(
            orderId,
            lineId,
            patchComponent(line, componentId, {
              complete: true,
              completedAt: now,
              completedBy: who,
              checkedOutBy: "",
              checkedOutAt: "",
              checkedOutMachine: "",
            }),
          );
          get().addAudit(
            get().currentUserEmail,
            "Component complete",
            `${order.poNumber} component ${componentId} by ${who}`,
          );
          return { ok: true };
        }

        const comps = normalizeComponents(line);
        if (comps.length && !allComponentsComplete(line)) {
          const open = comps
            .filter((c) => !c.complete)
            .map((c) => c.partNumber)
            .join(", ");
          return {
            ok: false,
            error: `Cannot pack assembly until components done: ${open}`,
          };
        }
        get().patchShopOrderLine(orderId, lineId, {
          readyForPack: true,
          readyForPackAt: now,
          readyForPackBy: who,
          checkedOutBy: "",
          checkedOutAt: "",
          checkedOutMachine: "",
        });
        get().addAudit(
          get().currentUserEmail,
          "Ready for pack",
          `${orderId} ${lineId}`,
        );
        return { ok: true };
      },

      setOrderDelivery: (orderId, patch) => {
        const s = get();
        const order = (s.shopOrders || []).find((o) => o.id === orderId);
        if (!order) return { ok: false, error: "Order not found" };
        const now = new Date().toISOString();
        const next = { ...order, updatedAt: now };
        if (patch.delivered === true) {
          next.deliveredAt = now;
          next.deliveredBy = patch.deliveredBy || next.deliveredBy || "";
          if (next.status !== "cancelled") next.status = "complete";
        }
        if (patch.delivered === false) {
          next.deliveredAt = "";
          next.deliveredBy = "";
        }
        if (patch.deliveredBy) next.deliveredBy = patch.deliveredBy;
        if (patch.signedSlipFileId != null) {
          next.signedSlipFileId = patch.signedSlipFileId;
          next.signedSlipName = patch.signedSlipName || "";
          next.signedSlipMime = patch.signedSlipMime || "";
        }
        if (patch.invoicedInQb === true) {
          next.invoicedInQb = true;
          next.invoicedAt = now;
        }
        if (patch.invoicedInQb === false) {
          next.invoicedInQb = false;
          next.invoicedAt = "";
        }
        if (patch.paymentReceived === true) {
          next.paymentReceived = true;
          next.paymentReceivedAt = now;
          next.closedAt = now;
        }
        if (patch.paymentReceived === false) {
          next.paymentReceived = false;
          next.paymentReceivedAt = "";
          next.closedAt = "";
        }
        if (patch.closed === true) next.closedAt = now;
        get().upsertShopOrder(next);
        return { ok: true };
      },


      updateShopOrderLineProgress: (orderId, lineId, qtyCompleted) => {
        const s = get();
        const list = [...(s.shopOrders || [])];
        const i = list.findIndex((o) => o.id === orderId);
        if (i < 0) return;
        const order = {
          ...list[i],
          lines: list[i].lines.map((l) =>
            l.id === lineId
              ? {
                  ...l,
                  qtyCompleted: Math.max(0, Math.min(l.qty, qtyCompleted)),
                }
              : l,
          ),
        };
        order.status = deriveShopOrderStatus(order);
        order.updatedAt = new Date().toISOString();
        list[i] = order;
        set({ shopOrders: list });
      },


      createVendorRfq: (partial) => {
        const s = get();
        const rfq = emptyVendorRfq({
          ...partial,
          id: partial?.id || uid(),
          rfqNumber: partial?.rfqNumber || nextRfqNumber(s.vendorRfqs || []),
          createdBy: partial?.createdBy || s.currentUserEmail,
          lines: partial?.lines?.length
            ? partial.lines
            : [emptyVendorRfqLine()],
        });
        set((st) => ({
          vendorRfqs: [rfq, ...(st.vendorRfqs || [])],
        }));
        get().addAudit(
          s.currentUserEmail,
          "Vendor RFQ",
          `Created ${rfq.rfqNumber}`,
        );
        return rfq;
      },

      upsertVendorRfq: (rfq) => {
        const now = new Date().toISOString();
        set((s) => {
          const list = [...(s.vendorRfqs || [])];
          const i = list.findIndex((x) => x.id === rfq.id);
          const row = { ...rfq, updatedAt: now };
          if (i >= 0) list[i] = row;
          else list.unshift(row);
          return { vendorRfqs: list };
        });
      },

      removeVendorRfq: (id) => {
        set((s) => ({
          vendorRfqs: (s.vendorRfqs || []).filter((x) => x.id !== id),
        }));
      },

      addVendorBid: (rfqId, bidPartial) => {
        const s = get();
        const list = [...(s.vendorRfqs || [])];
        const i = list.findIndex((x) => x.id === rfqId);
        if (i < 0) return { ok: false, error: "RFQ not found" };
        const rfq = list[i];
        const vendor = (bidPartial.vendor || "").trim();
        if (!vendor) return { ok: false, error: "Vendor name required" };

        const bid = emptyVendorBid({
          ...bidPartial,
          id: bidPartial.id || uid(),
          vendor,
          lines:
            bidPartial.lines && bidPartial.lines.length
              ? bidPartial.lines
              : defaultBidLinesForRfq(rfq),
        });

        const bids = [...(rfq.bids || []), bid];
        const status =
          rfq.status === "awarded"
            ? rfq.status
            : bids.length > 0
              ? "quoted"
              : rfq.status;
        list[i] = {
          ...rfq,
          bids,
          status,
          updatedAt: new Date().toISOString(),
        };
        set({ vendorRfqs: list });
        get().addAudit(
          s.currentUserEmail,
          "Vendor bid",
          `${rfq.rfqNumber} · ${vendor}`,
        );
        return { ok: true, bid };
      },

      acceptVendorBid: (rfqId, bidId) => {
        const s = get();
        const list = [...(s.vendorRfqs || [])];
        const i = list.findIndex((x) => x.id === rfqId);
        if (i < 0) return { ok: false, error: "RFQ not found" };
        const rfq = list[i];
        const bid = (rfq.bids || []).find((b) => b.id === bidId);
        if (!bid) return { ok: false, error: "Bid not found" };
        if (!bid.vendor?.trim()) {
          return { ok: false, error: "Bid has no vendor name" };
        }
        if (rfq.purchaseOrderId) {
          return {
            ok: false,
            error: "This RFQ already has a material PO — open Material buys",
          };
        }
        if (rfq.status === "awarded" && rfq.purchaseOrderId) {
          return { ok: false, error: "Already awarded" };
        }

        let po;
        try {
          po = purchaseOrderFromAward({
            rfq,
            bid,
            poNumber: nextPoNumber(s.purchaseOrders || []),
            createdBy: s.currentUserEmail,
          });
        } catch (err) {
          return {
            ok: false,
            error:
              err instanceof Error
                ? err.message
                : "Failed to build material PO",
          };
        }
        if (!po?.id || !po.poNumber) {
          return { ok: false, error: "PO was not created" };
        }

        const bids = (rfq.bids || []).map((b) => ({
          ...b,
          status:
            b.id === bidId
              ? ("accepted" as const)
              : b.status === "accepted"
                ? ("rejected" as const)
                : ("rejected" as const),
        }));

        list[i] = {
          ...rfq,
          bids,
          awardedBidId: bidId,
          purchaseOrderId: po.id,
          status: "awarded",
          updatedAt: new Date().toISOString(),
        };

        set({
          vendorRfqs: list,
          purchaseOrders: [po, ...(s.purchaseOrders || [])],
        });
        get().addAudit(
          s.currentUserEmail,
          "Award RFQ",
          `${rfq.rfqNumber} → ${po.poNumber} (${bid.vendor})`,
        );
        return { ok: true, po };
      },


      createPurchaseOrder: (partial) => {
        const s = get();
        const po = emptyPurchaseOrder({
          ...partial,
          id: partial?.id || uid(),
          poNumber: partial?.poNumber || nextPoNumber(s.purchaseOrders || []),
          createdBy: partial?.createdBy || s.currentUserEmail,
          lines: (partial?.lines || []).map((l) =>
            emptyPoLine({ ...l, id: l.id || uid() }),
          ),
        });
        set((st) => ({
          purchaseOrders: [po, ...(st.purchaseOrders || [])],
        }));
        get().addAudit(s.currentUserEmail, "PO", `Created ${po.poNumber}`);
        return po;
      },

      upsertPurchaseOrder: (po) => {
        const row = {
          ...po,
          status: derivePoStatus(po),
          updatedAt: new Date().toISOString(),
          lines: (po.lines || []).map((l) =>
            emptyPoLine({ ...l, id: l.id || uid() }),
          ),
        };
        set((s) => {
          const list = [...(s.purchaseOrders || [])];
          const i = list.findIndex((x) => x.id === row.id);
          if (i >= 0) list[i] = row;
          else list.unshift(row);
          return { purchaseOrders: list };
        });
      },

      removePurchaseOrder: (id) => {
        set((s) => ({
          purchaseOrders: (s.purchaseOrders || []).filter((x) => x.id !== id),
        }));
      },

      receivePoLine: (opts) => {
        const s = get();
        const poList = [...(s.purchaseOrders || [])];
        const pi = poList.findIndex((p) => p.id === opts.poId);
        if (pi < 0) return { ok: false, error: "PO not found" };
        const po = { ...poList[pi], lines: [...poList[pi].lines] };
        const li = po.lines.findIndex((l) => l.id === opts.lineId);
        if (li < 0) return { ok: false, error: "Line not found" };
        const line = { ...po.lines[li] };
        const qty = Math.floor(Number(opts.qty) || 0);
        if (qty <= 0) return { ok: false, error: "Qty must be > 0" };
        const open = poLineOpenQty(line);
        if (qty > open) return { ok: false, error: `Only ${open} open on this line` };

        let stockList = [...(s.materialStock || [])];
        const { stockId, created } = findOrCreateStockId(
          stockList,
          { ...line, vendor: po.vendor, location: opts.location || "Receiving" },
          uid(),
        );
        if (created) stockList = [created, ...stockList];
        const si = stockList.findIndex((x) => x.id === stockId);
        if (si < 0) return { ok: false, error: "Stock line missing" };
        const stock = { ...stockList[si] };
        stock.onHand = (stock.onHand || 0) + qty;
        stock.vendor = stock.vendor || po.vendor;
        if (opts.location) stock.location = opts.location;
        stock.updatedAt = new Date().toISOString();
        stockList[si] = stock;

        const lengthEach = line.lengthEach > 0 ? line.lengthEach : 1;
        const pieces: StockPiece[] = [];
        for (let n = 0; n < qty; n++) {
          const id = uid();
          pieces.push({
            id,
            barcode: generateBarcode(id),
            stockId,
            material: line.material,
            materialType: line.materialType,
            stockShape: line.stockShape,
            sizeNote: line.sizeNote,
            originalLength: lengthEach,
            remainingLength: lengthEach,
            unit: line.unit,
            location: opts.location || stock.location || "Receiving",
            status: "available",
            poId: po.id,
            poLineId: line.id,
            receivedAt: new Date().toISOString(),
            notes: "",
          });
        }

        line.qtyReceived = (line.qtyReceived || 0) + qty;
        po.lines[li] = line;
        po.status = derivePoStatus(po);
        po.updatedAt = new Date().toISOString();
        poList[pi] = po;

        const txn = makeTxn({
          id: uid(),
          by: s.currentUserEmail,
          kind: "receive",
          itemKind: "material",
          itemId: stockId,
          label: materialLabel(stock),
          qty,
          balanceAfter: stock.onHand,
          reason: `PO ${po.poNumber}`,
          ref: po.poNumber,
        });

        set({
          purchaseOrders: poList,
          materialStock: stockList,
          stockPieces: [...pieces, ...(s.stockPieces || [])],
          inventoryTxns: [txn, ...(s.inventoryTxns || [])].slice(0, 500),
        });
        get().addAudit(
          s.currentUserEmail,
          "PO receive",
          `${po.poNumber} +${qty} ${line.material} → ${pieces.length} barcodes`,
        );
        return { ok: true, pieceIds: pieces.map((x) => x.id) };
      },

      getPieceByBarcode: (barcode) => {
        const code = barcode.trim().toUpperCase();
        return (get().stockPieces || []).find(
          (p) => p.barcode.toUpperCase() === code || p.id === barcode.trim(),
        );
      },

      consumePiece: (opts) => {
        const s = get();
        const code = opts.barcode.trim().toUpperCase();
        const pieces = [...(s.stockPieces || [])];
        const i = pieces.findIndex(
          (p) => p.barcode.toUpperCase() === code || p.id === opts.barcode.trim(),
        );
        if (i < 0) return { ok: false, error: "Barcode not found" };
        const piece = { ...pieces[i] };
        if (piece.status === "consumed") {
          return { ok: false, error: "This piece is already fully used" };
        }
        const lengthUsed = Math.abs(Number(opts.lengthUsed) || 0);
        const qty = Math.max(1, Math.floor(Number(opts.qty) || 1));
        const totalUse = lengthUsed * qty;
        if (totalUse <= 0) return { ok: false, error: "Enter length used" };
        if (totalUse > piece.remainingLength + 0.001) {
          return {
            ok: false,
            error: `Only ${piece.remainingLength}" remaining on this piece`,
          };
        }
        piece.remainingLength =
          Math.round((piece.remainingLength - totalUse) * 1000) / 1000;
        if (piece.remainingLength <= 0.01) {
          piece.remainingLength = 0;
          piece.status = "consumed";
        }
        pieces[i] = piece;

        let stockList = [...(s.materialStock || [])];
        const si = stockList.findIndex((x) => x.id === piece.stockId);
        let balance = 0;
        if (si >= 0) {
          const stock = { ...stockList[si] };
          if (piece.status === "consumed") {
            stock.onHand = Math.max(0, (stock.onHand || 0) - 1);
          }
          stock.updatedAt = new Date().toISOString();
          stockList[si] = stock;
          balance = stock.onHand;
        }

        const txn = makeTxn({
          id: uid(),
          by: s.currentUserEmail,
          kind: "issue",
          itemKind: "piece",
          itemId: piece.id,
          label: `${piece.barcode} ${piece.material} ${piece.materialType}`,
          qty: totalUse,
          balanceAfter: piece.remainingLength,
          reason: opts.reason || "Cut / use",
          ref: opts.jobRef || "",
        });

        set({
          stockPieces: pieces,
          materialStock: stockList,
          inventoryTxns: [txn, ...(s.inventoryTxns || [])].slice(0, 500),
        });
        return { ok: true, piece };
      },


      upsertCutTicket: (ticket) => {
        const s = get();
        if (!ticket?.id) return { ok: false, error: "Missing ticket id" };
        const list = [...(s.cutTickets || [])];
        const i = list.findIndex((x) => x.id === ticket.id);
        const next = {
          ...ticket,
          status: deriveCutStatus(ticket),
        };
        if (i >= 0) list[i] = next;
        else list.unshift(next);
        set({ cutTickets: list.slice(0, 500) });
        return { ok: true };
      },

      createCutTicketFromLine: (opts) => {
        const s = get();
        const order = (s.shopOrders || []).find((o) => o.id === opts.orderId);
        if (!order) return { ok: false, error: "Order not found" };
        const line = (order.lines || []).find((l) => l.id === opts.lineId);
        if (!line) return { ok: false, error: "Line not found" };
        const quote =
          (line.quoteId && s.quotes.find((q) => q.id === line.quoteId)) ||
          s.quotes.find(
            (q) =>
              q.partNumber.toLowerCase() ===
                (line.partNumber || "").toLowerCase() &&
              (!line.revision ||
                q.revision.toLowerCase() === line.revision.toLowerCase()),
          ) ||
          null;
        let ticket = ticketFromLine({
          order,
          line,
          byName: opts.byName,
          machine: opts.machine,
          componentId: opts.componentId,
          process: opts.process,
          quote,
        });
        if (opts.dimX != null) ticket = { ...ticket, dimX: opts.dimX };
        if (opts.dimY != null) ticket = { ...ticket, dimY: opts.dimY };
        if (opts.dimZ != null) ticket = { ...ticket, dimZ: opts.dimZ };
        if (opts.diameter != null) ticket = { ...ticket, diameter: opts.diameter };
        if (opts.locAxis) ticket = { ...ticket, locAxis: opts.locAxis };
        if (opts.locValue != null) ticket = { ...ticket, locValue: opts.locValue };
        if (opts.qtyRequested != null)
          ticket = { ...ticket, qtyRequested: opts.qtyRequested };
        if (opts.notes != null) ticket = { ...ticket, notes: opts.notes };
        if (opts.writeBackToQuote != null)
          ticket = { ...ticket, writeBackToQuote: opts.writeBackToQuote };
        ticket = { ...ticket, status: "requested" };
        const list = [ticket, ...(s.cutTickets || [])].slice(0, 500);
        set({ cutTickets: list });
        get().addAudit(
          s.currentUserEmail || opts.byName,
          "Cut ticket created",
          `${ticket.partNumber} · qty ${ticket.qtyRequested} · ${ticket.locValue}" LOC`,
        );
        return { ok: true, ticket };
      },

      recordCutProgress: (ticketId, qtyDelta, sawOperator) => {
        const s = get();
        const list = [...(s.cutTickets || [])];
        const i = list.findIndex((x) => x.id === ticketId);
        if (i < 0) return { ok: false, error: "Ticket not found" };
        const t = { ...list[i]! };
        const delta = Math.max(0, Number(qtyDelta) || 0);
        if (delta <= 0) return { ok: false, error: "Qty must be > 0" };
        const req = Number(t.qtyRequested) || 0;
        t.qtyCut = Math.min(req || (Number(t.qtyCut) || 0) + delta, (Number(t.qtyCut) || 0) + delta);
        if (req > 0) t.qtyCut = Math.min(req, t.qtyCut);
        if (sawOperator) t.sawOperator = sawOperator;
        t.status = deriveCutStatus(t);
        if (t.status === "done") t.completedAt = new Date().toISOString();
        list[i] = t;
        set({ cutTickets: list });
        if (t.writeBackToQuote && t.status === "done" && !t.writtenBackAt) {
          get().writeCutActualsToQuote(t.id);
        }
        return { ok: true, ticket: t };
      },

      claimCutStock: (ticketId, qty, _machine) => {
        const s = get();
        const list = [...(s.cutTickets || [])];
        const i = list.findIndex((x) => x.id === ticketId);
        if (i < 0) return { ok: false, error: "Ticket not found" };
        const t = { ...list[i]! };
        const need = Math.max(0, Number(qty) || 0);
        if (need <= 0) return { ok: false, error: "Qty must be > 0" };
        if (t.status === "skipped") {
          t.qtyClaimed = (Number(t.qtyClaimed) || 0) + need;
          list[i] = t;
          set({ cutTickets: list });
          return { ok: true, available: 999 };
        }
        const avail = qtyAvailable(t);
        if (need > avail) {
          return {
            ok: false,
            error: `Only ${avail} blank(s) available from saw`,
            available: avail,
          };
        }
        t.qtyClaimed = (Number(t.qtyClaimed) || 0) + need;
        list[i] = t;
        set({ cutTickets: list });
        return { ok: true, available: qtyAvailable(t) };
      },

      skipCutTicket: (ticketId, byName) => {
        const s = get();
        const list = [...(s.cutTickets || [])];
        const i = list.findIndex((x) => x.id === ticketId);
        if (i < 0) return { ok: false, error: "Ticket not found" };
        const t = { ...list[i]! };
        t.status = "skipped";
        t.qtyCut = Number(t.qtyRequested) || t.qtyCut;
        t.notes = [t.notes, "Skipped saw — stock on hand"]
          .filter(Boolean)
          .join(" · ");
        if (byName) t.sawOperator = byName;
        t.completedAt = new Date().toISOString();
        list[i] = t;
        set({ cutTickets: list });
        return { ok: true };
      },

      cancelCutTicket: (ticketId) => {
        const s = get();
        const list = [...(s.cutTickets || [])];
        const i = list.findIndex((x) => x.id === ticketId);
        if (i < 0) return { ok: false, error: "Ticket not found" };
        list[i] = { ...list[i]!, status: "cancelled" };
        set({ cutTickets: list });
        return { ok: true };
      },

      writeCutActualsToQuote: (ticketId) => {
        const s = get();
        const t = (s.cutTickets || []).find((x) => x.id === ticketId);
        if (!t) return { ok: false, error: "Ticket not found" };
        const qi = s.quotes.findIndex(
          (q) =>
            q.partNumber.toLowerCase() === t.partNumber.toLowerCase() &&
            (!t.revision ||
              q.revision.toLowerCase() === t.revision.toLowerCase()),
        );
        if (qi < 0) {
          return { ok: false, error: "No matching quote for this part/rev" };
        }
        const quotes = [...s.quotes];
        quotes[qi] = applyTicketToQuote(quotes[qi]!, t);
        const list = [...(s.cutTickets || [])];
        const ti = list.findIndex((x) => x.id === ticketId);
        if (ti >= 0) {
          list[ti] = {
            ...list[ti]!,
            writtenBackAt: new Date().toISOString(),
            writeBackToQuote: true,
          };
        }
        set({ quotes, cutTickets: list });
        get().addAudit(
          s.currentUserEmail || "shop",
          "Quote stock recipe from cut",
          `${t.partNumber} · ${sizeNoteFromTicket(t)}`,
        );
        return { ok: true };
      },

      getSharedState: () => {
        const s = get();
        return {
          operators: s.operators,
          customers: s.customers,
          quotes: s.quotes,
          jobs: s.jobs,
          downtimes: s.downtimes,
          operatorTimeLog: s.operatorTimeLog,
          auditLog: s.auditLog,
          sessions: s.sessions,
          activeTimers: s.activeTimers,
          dayBonuses: s.dayBonuses || [],
          weeklyPayouts: s.weeklyPayouts || [],
          materialStock: s.materialStock || [],
          partStock: s.partStock || [],
          partUnits: s.partUnits || [],
          inventoryTxns: s.inventoryTxns || [],
          purchaseOrders: s.purchaseOrders || [],
          vendorRfqs: s.vendorRfqs || [],
          shopOrders: s.shopOrders || [],
          workQueue: s.workQueue || [],
          cutTickets: s.cutTickets || [],
          stockPieces: s.stockPieces || [],
          quoteHistory: s.quoteHistory || [],
          emailLog: s.emailLog || [],
          chatMessages: s.chatMessages || [],
          shopToolingLogs: s.shopToolingLogs || [],
          feedbackTickets: s.feedbackTickets || [],
          settings: s.settings,
        };
      },

      replaceSharedState: (shared) => {
        const s = get();
        const n = maxOpsFrom(shared.settings || s.settings);
        const machines = allMachines(
          normalizeCustomLists(shared.settings?.customLists || s.settings.customLists),
        );
        const baseSessions = shared.sessions
          ? Object.fromEntries(
              Object.entries(shared.sessions).map(([k, v]) => [
                k,
                padSession(v as MachineSession, n),
              ]),
            )
          : s.sessions;
        const ensured = ensureMachineSessions(
          baseSessions,
          shared.activeTimers || s.activeTimers,
          machines,
          n,
        );
        set({
          operators: migrateOperators(shared.operators as Operator[]),
          customers:
            migrateCustomers(shared.customers as Customer[]) || s.customers,
          quotes: mergeQuoteLists(
            s.quotes,
            (shared.quotes || []).map((q) => padQuote(q as Quote, n)),
          ),
          jobs: (shared.jobs || []).map((j) => padJob(j as JobRun, n)),
          downtimes: shared.downtimes || [],
          operatorTimeLog: shared.operatorTimeLog || [],
          auditLog: shared.auditLog || [],
          sessions: ensured.sessions,
          activeTimers: ensured.activeTimers,
          dayBonuses: shared.dayBonuses || [],
          weeklyPayouts: shared.weeklyPayouts || [],
          materialStock: shared.materialStock || [],
          partStock: shared.partStock || [],
          partUnits: shared.partUnits ?? s.partUnits ?? [],
          inventoryTxns: shared.inventoryTxns || [],
          purchaseOrders: shared.purchaseOrders ?? s.purchaseOrders ?? [],
          vendorRfqs: shared.vendorRfqs ?? s.vendorRfqs ?? [],
          shopOrders: shared.shopOrders ?? s.shopOrders ?? [],
          workQueue: shared.workQueue ?? s.workQueue ?? [],
          cutTickets: shared.cutTickets ?? s.cutTickets ?? [],
          stockPieces: shared.stockPieces ?? s.stockPieces ?? [],
          quoteHistory: shared.quoteHistory ?? s.quoteHistory ?? [],
          emailLog: shared.emailLog ?? s.emailLog ?? [],
          chatMessages: mergeChatMessages(
            s.chatMessages,
            shared.chatMessages,
          ),
          shopToolingLogs: normalizeShopToolingLogs(
            shared.shopToolingLogs ?? s.shopToolingLogs ?? [],
          ),
          feedbackTickets: shared.feedbackTickets ?? s.feedbackTickets ?? [],
          settings: {
            ...s.settings,
            ...shared.settings,
            maxOperations: clampOpCount(
              shared.settings?.maxOperations ?? s.settings.maxOperations,
            ),
            customLists: normalizeCustomLists(
              shared.settings?.customLists ?? s.settings.customLists,
            ),
            lunchHours: shared.settings?.lunchHours ?? s.settings.lunchHours ?? 1,
            shifts: resolveWorkShifts({
              workDayStart:
                shared.settings?.workDayStart ?? s.settings.workDayStart,
              workDayEnd: shared.settings?.workDayEnd ?? s.settings.workDayEnd,
              lunchHours:
                shared.settings?.lunchHours ?? s.settings.lunchHours ?? 1,
              shifts: (shared.settings as { shifts?: typeof s.settings.shifts })
                ?.shifts ?? s.settings.shifts,
            }),
            quoteFromEmail:
              shared.settings?.quoteFromEmail ?? s.settings.quoteFromEmail ?? "",
            averageMaxRuns:
              shared.settings?.averageMaxRuns ?? s.settings.averageMaxRuns ?? 10,
            averageShopWeight:
              shared.settings?.averageShopWeight ??
              s.settings.averageShopWeight ??
              0.7,
            averageOutlierRatio:
              shared.settings?.averageOutlierRatio ??
              s.settings.averageOutlierRatio ??
              1.5,
          },
          // keep currentUserEmail local to this PC
        });
      },


      freezeQuotePrices: (quoteId, reason = "manual_lock") => {
        const s = get();
        const q = s.quotes.find((x) => x.id === quoteId);
        if (!q) return { ok: false, error: "Quote not found" };
        // Always snapshot the LIVE calculated price each — never stale stored $
        const live = calculateAssemblyAwareCosts(q, s.quotes);
        const priced = {
          ...q,
          prices: live.prices,
          quantities: padSlots(q.quantities, 6, 0),
        };
        const snap = freezeQuoteSnapshot(priced, {
          id: uid(),
          reason,
        });
        set({
          quoteHistory: [snap, ...(s.quoteHistory || [])].slice(0, 500),
          quotes: s.quotes.map((x) =>
            x.id === quoteId
              ? { ...priced, lastSnapshotId: snap.id }
              : x,
          ),
        });
        get().addAudit(
          s.currentUserEmail,
          "Freeze quote",
          `${q.partNumber} rev ${q.revision} · live calc`,
        );
        return { ok: true };
      },

      logEmailSend: (entry) => {
        const s = get();
        const row = {
          id: uid(),
          sentAt: new Date().toISOString(),
          by: s.currentUserEmail,
          customer: entry.customer,
          toEmail: entry.toEmail,
          subject: entry.subject,
          quoteIds: entry.quoteIds,
          partNumbers: entry.partNumbers,
          method: entry.method,
        };
        const history = [...(s.quoteHistory || [])];
        let quotes = [...s.quotes];
        for (const qid of entry.quoteIds) {
          const q = quotes.find((x) => x.id === qid);
          if (!q) continue;
          const live = calculateAssemblyAwareCosts(q, quotes);
          const priced = { ...q, prices: live.prices };
          const snap = freezeQuoteSnapshot(priced, {
            id: uid(),
            reason: "email",
            emailedTo: entry.toEmail,
            notes: entry.subject,
          });
          history.unshift(snap);
          quotes = quotes.map((x) =>
            x.id === qid ? { ...x, lastSnapshotId: snap.id } : x,
          );
        }
        set({
          emailLog: [row, ...(s.emailLog || [])].slice(0, 300),
          quoteHistory: history.slice(0, 500),
          quotes,
        });
        get().addAudit(
          s.currentUserEmail,
          "Email quotes",
          `${entry.toEmail} · ${entry.partNumbers.join(", ")}`,
        );
      },

      getLiveElapsedSeconds: (machine, nowMs = Date.now()) => {
        const timer = get().activeTimers[machine];
        if (!timer) return null;
        const elapsed = Math.floor(
          (nowMs - new Date(timer.startIso).getTime()) / 1000,
        );
        return timer.accumulatedSeconds + Math.max(0, elapsed);
      },
    }),
    {
      name: "lcm-data-management-v14",
      version: 13,
      storage: createJSONStorage(() => {
        if (typeof window === "undefined") {
          return {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
          };
        }
        return localStorage;
      }),
      migrate: (persisted) => {
        const p = (persisted || {}) as Partial<LcmState>;
        const seedState = createSeedState();
        const settings = {
          ...seedState.settings,
          ...(p.settings || {}),
          maxOperations: clampOpCount(
            p.settings?.maxOperations ?? DEFAULT_OPERATIONS,
          ),
          customLists: normalizeCustomLists(
            p.settings?.customLists ?? seedState.settings.customLists,
          ),
          quoteFromEmail:
            p.settings?.quoteFromEmail ?? seedState.settings.quoteFromEmail ?? "",
        };
        const n = maxOpsFrom(settings);
        const machines = allMachines(settings.customLists);
        const baseSessions = p.sessions
          ? Object.fromEntries(
              Object.entries(p.sessions).map(([k, v]) => [
                k,
                padSession(v as MachineSession, n),
              ]),
            )
          : seedState.sessions;
        const ensured = ensureMachineSessions(
          baseSessions,
          p.activeTimers || seedState.activeTimers,
          machines,
          n,
        );
        return {
          ...seedState,
          ...p,
          settings,
          operators: migrateOperators(p.operators as Operator[] | undefined),
          customers:
            migrateCustomers(p.customers as Customer[] | undefined) ||
            seedState.customers,
          quotes: (p.quotes || seedState.quotes).map((q) =>
            padQuote(q as Quote, n),
          ),
          jobs: (p.jobs || seedState.jobs).map((j) => padJob(j as JobRun, n)),
          sessions: ensured.sessions,
          activeTimers: ensured.activeTimers,
          dayBonuses: p.dayBonuses || [],
          weeklyPayouts: p.weeklyPayouts || [],
          materialStock: p.materialStock || seedState.materialStock || [],
          partStock: p.partStock || seedState.partStock || [],
          partUnits: (p as { partUnits?: PartUnit[] }).partUnits || seedState.partUnits || [],
          inventoryTxns: p.inventoryTxns || [],
          purchaseOrders: p.purchaseOrders || seedState.purchaseOrders || [],
          vendorRfqs: (p as { vendorRfqs?: VendorRfq[] }).vendorRfqs || seedState.vendorRfqs || [],
          shopOrders: p.shopOrders || seedState.shopOrders || [],
          workQueue: p.workQueue || seedState.workQueue || [],
          cutTickets: p.cutTickets || seedState.cutTickets || [],
          stockPieces: p.stockPieces || seedState.stockPieces || [],
          feedbackTickets:
            (p as { feedbackTickets?: FeedbackTicket[] }).feedbackTickets ||
            seedState.feedbackTickets ||
            [],
        };
      },
      partialize: (s) => ({
        operators: s.operators,
        customers: s.customers,
        quotes: s.quotes,
        jobs: s.jobs,
        downtimes: s.downtimes,
        operatorTimeLog: s.operatorTimeLog,
        auditLog: s.auditLog,
        sessions: s.sessions,
        activeTimers: s.activeTimers,
        settings: s.settings,
        currentUserEmail: s.currentUserEmail,
        dayBonuses: s.dayBonuses || [],
        weeklyPayouts: s.weeklyPayouts || [],
      }),
    },
  ),
);

export function getInProgressJobsForPart(partNumber: string) {
  return useLcmStore
    .getState()
    .jobs.filter(
      (j) =>
        j.partNumber.toLowerCase() === partNumber.toLowerCase() &&
        j.status === "In Progress",
    );
}
