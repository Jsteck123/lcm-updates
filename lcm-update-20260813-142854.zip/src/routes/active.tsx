import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  Factory,
  Pause,
  Play,
  Square,
  Timer,
  Hand,
} from "lucide-react";
import { toast } from "sonner";
import { useLcmStore, getInProgressJobsForPart } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select } from "@/components/ui/input";
import { allMachines, normalizeCustomLists } from "@/lib/lcm/lists";
import { machineToSlug } from "@/lib/lcm/machines";
import { getOperatorByEmail } from "@/lib/lcm/permissions";
import { buildJobBoard } from "@/lib/lcm/job-board";
import { listMyActiveJobs, sameOperatorName } from "@/lib/lcm/active-jobs";
import { formatSeconds } from "@/lib/utils";
import { opLabel } from "@/lib/lcm/ops";
import {
  machineSessionStatus,
  statusSurfaceClass,
  statusToBadgeTone,
} from "@/lib/lcm/status-colors";
import { cn } from "@/lib/utils";
import type { ActiveTimer } from "@/lib/lcm/types";

export const Route = createFileRoute("/active")({
  component: ActiveJobsPage,
});

function timerLabel(timer: ActiveTimer | null, live: number | null) {
  if (!timer) return "Timer off";
  const op = timer.operation != null ? opLabel(Number(timer.operation)) : "";
  return `${timer.type}${op ? ` · ${op}` : ""} · ${formatSeconds(live || 0)}`;
}

function ActiveJobsPage() {
  const sessions = useLcmStore((s) => s.sessions);
  const activeTimers = useLcmStore((s) => s.activeTimers);
  const customLists = useLcmStore((s) => s.settings.customLists);
  const shopOrders = useLcmStore((s) => s.shopOrders);
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  const getLive = useLcmStore((s) => s.getLiveElapsedSeconds);
  const smartStart = useLcmStore((s) => s.smartStart);
  const smartStop = useLcmStore((s) => s.smartStop);
  const loadJob = useLcmStore((s) => s.loadJobOnMachine);
  const setOperatorOnMachine = useLcmStore((s) => s.setOperatorOnMachine);
  const navigate = useNavigate();
  const [, tick] = useState(0);
  const [loadMachine, setLoadMachine] = useState("");

  const me = useMemo(
    () => getOperatorByEmail(operators, email),
    [operators, email],
  );
  const myName = me?.name || email.split("@")[0] || "";
  const machines = useMemo(
    () => allMachines(normalizeCustomLists(customLists)),
    [customLists],
  );

  useEffect(() => {
    const id = window.setInterval(() => tick((n) => n + 1), 1000);
    return () => window.clearInterval(id);
  }, []);

  const mine = useMemo(
    () => listMyActiveJobs(machines, sessions, activeTimers, myName),
    [machines, sessions, activeTimers, myName],
  );

  const loadedParts = useMemo(() => {
    const set = new Set<string>();
    for (const row of mine) {
      const pn = (row.session.partNumber || "").toUpperCase();
      if (pn) set.add(pn);
    }
    return set;
  }, [mine]);

  const pulledOpen = useMemo(() => {
    if (!myName) return [];
    return buildJobBoard(shopOrders || []).filter((c) => {
      if (!sameOperatorName(c.checkedOutBy, myName)) return false;
      if (loadedParts.has((c.partNumber || "").toUpperCase())) return false;
      return true;
    });
  }, [shopOrders, loadedParts, myName]);

  function goMachine(machine: string) {
    void navigate({
      to: "/machines/$machineId",
      params: { machineId: machineToSlug(machine) },
    });
  }

  function loadPulled(
    partNumber: string,
    revision: string,
    qty: number,
    customer: string,
    hintedMachine: string,
  ) {
    const target = (hintedMachine || loadMachine).trim();
    if (!target) {
      toast.error("Pick a machine, then Load");
      return;
    }
    const sess = sessions[target];
    if (
      sess?.jobId &&
      (sess.partNumber || "").toUpperCase() !== partNumber.toUpperCase()
    ) {
      toast.error(`${target} already has ${sess.partNumber} loaded`);
      return;
    }
    if (myName) setOperatorOnMachine(target, myName);
    const open = getInProgressJobsForPart(partNumber);
    const r = loadJob(target, {
      partNumber,
      revision: revision || "A",
      quantity: qty || 1,
      customer,
      existingJobId: open[0]?.id,
    });
    if (!r.ok) {
      toast.error(r.error || "Could not load");
      return;
    }
    toast.success(`Loaded ${partNumber} on ${target}`);
    goMachine(target);
  }

  return (
    <div className="p-3 sm:p-5 space-y-4 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold tracking-tight">
            My Active Jobs
          </h1>
          <p className="text-sm text-[var(--color-muted)] mt-0.5">
            Only the jobs {myName || "you"} have running. Open a machine to run
            its timer, or switch machines from that page.
          </p>
        </div>
        <Select
          className="h-11 w-auto min-w-[10rem]"
          value={loadMachine}
          onChange={(e) => setLoadMachine(e.target.value)}
        >
          <option value="">Machine for Load</option>
          {machines.map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </Select>
      </div>

      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
        {mine.map((row) => {
          const live = getLive(row.machine);
          const st = machineSessionStatus({
            hasJob: Boolean(row.session.jobId),
            running: Boolean(row.timer),
            paused: Boolean(row.session.paused),
          });
          return (
            <Card
              key={row.machine}
              className={cn("border", statusSurfaceClass(st))}
            >
              <CardHeader className="pb-2 space-y-1">
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Factory className="h-4 w-4 shrink-0" />
                    {row.machine}
                  </CardTitle>
                  <Badge tone={statusToBadgeTone(st)}>
                    {row.timer ? (
                      <>
                        <Play className="h-3 w-3 mr-1" /> Live
                      </>
                    ) : row.session.paused ? (
                      <>
                        <Pause className="h-3 w-3 mr-1" /> Paused
                      </>
                    ) : (
                      "Loaded"
                    )}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <div className="font-mono font-semibold text-base">
                    {row.session.partNumber || "—"}{" "}
                    <span className="text-xs font-normal">
                      Rev {row.session.revision || "—"}
                    </span>
                  </div>
                  <div className="text-xs text-[var(--color-muted)]">
                    Qty {row.session.quantity || 0}
                    {row.session.customer ? ` · ${row.session.customer}` : ""}
                  </div>
                </div>
                <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 flex items-center gap-2">
                  <Timer className="h-4 w-4 text-[var(--color-status-active)] shrink-0" />
                  <span className="text-sm tabular font-medium">
                    {timerLabel(row.timer, live)}
                  </span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  <Button
                    size="sm"
                    type="button"
                    className="min-h-11"
                    onClick={() => goMachine(row.machine)}
                  >
                    Open machine
                  </Button>
                  {!row.timer ? (
                    <Button
                      size="sm"
                      variant="secondary"
                      type="button"
                      className="min-h-11"
                      onClick={() => {
                        const r = smartStart(row.machine);
                        if (!r.ok) toast.error(r.error || "Cannot start");
                        else toast.success(r.message || "Started");
                      }}
                    >
                      <Play className="h-3.5 w-3.5" /> Start
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      variant="outline"
                      type="button"
                      className="min-h-11"
                      onClick={() => {
                        const r = smartStop(row.machine);
                        if (r.needsUnits) {
                          toast.message("Enter completed qty on the machine");
                          goMachine(row.machine);
                          return;
                        }
                        if (!r.ok) toast.error(r.error || "Cannot stop");
                        else toast.success("Timer stopped");
                      }}
                    >
                      <Square className="h-3.5 w-3.5" /> Stop
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {mine.length === 0 && (
        <p className="text-sm text-[var(--color-muted)] text-center py-8">
          You have no jobs loaded. Pull a line on the Job Board, pick a
          machine, then Load — it will show here even if you run more than one
          machine.
        </p>
      )}

      {pulledOpen.length > 0 && (
        <div className="space-y-2">
          <h2 className="text-sm font-semibold">Pulled — not loaded yet</h2>
          <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
            {pulledOpen.map((c) => (
              <Card
                key={`${c.orderId}-${c.lineId}-${c.componentId || "line"}`}
              >
                <CardContent className="p-4 space-y-2">
                  <div className="flex justify-between gap-2">
                    <div className="font-mono font-semibold">
                      {c.partNumber}{" "}
                      <span className="text-xs font-normal">
                        Rev {c.revision || "—"}
                      </span>
                    </div>
                    <Badge tone="active">Yours</Badge>
                  </div>
                  <div className="text-xs text-[var(--color-muted)]">
                    PO {c.poNumber} · qty {c.qty}
                    {c.checkedOutMachine ? ` · ${c.checkedOutMachine}` : ""}
                  </div>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    <Button
                      size="sm"
                      type="button"
                      className="min-h-11"
                      onClick={() =>
                        loadPulled(
                          c.partNumber,
                          c.revision,
                          c.qty,
                          c.customer,
                          c.checkedOutMachine,
                        )
                      }
                    >
                      <Hand className="h-3.5 w-3.5" /> Load
                    </Button>
                    <Link
                      to="/board"
                      className="inline-flex items-center justify-center rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 text-xs min-h-11"
                    >
                      Job Board
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
