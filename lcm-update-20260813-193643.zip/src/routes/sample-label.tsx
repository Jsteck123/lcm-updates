import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Printer, ArrowLeft } from "lucide-react";
import { barcodeToDataUrl, scanUrlForBarcode } from "@/lib/lcm/barcode";
import { Button } from "@/components/ui/button";
import { useLcmStore } from "@/store/lcm-store";

/** Practice barcode for printing a test label — not auto-written into live inventory */
export const SAMPLE_BARCODE = "LCM-SAMPLE-01";

/** Brother QL-810W die-cut they selected in the print dialog */
const LABEL_W = "1.1in";
const LABEL_H = "1.6in";

const LOCAL_SAMPLE = {
  barcode: SAMPLE_BARCODE,
  material: "Aluminum",
  materialType: "T6 6061",
  stockShape: "Round Stock",
  sizeNote: '1.5" dia x 12 ft',
  remainingLength: 144,
  originalLength: 144,
  location: "Rack A-1",
  unit: "in" as const,
};

export const Route = createFileRoute("/sample-label")({
  component: SampleLabelPage,
});

function SampleLabelPage() {
  const stockPieces = useLcmStore((s) => s.stockPieces || []);
  const [qr, setQr] = useState("");

  const piece =
    stockPieces.find((p) => p.barcode === SAMPLE_BARCODE) || LOCAL_SAMPLE;

  useEffect(() => {
    const url = scanUrlForBarcode(SAMPLE_BARCODE, window.location.origin);
    void barcodeToDataUrl(url, 180).then(setQr);
  }, []);

  return (
    <div className="mx-auto max-w-lg space-y-5 pb-10">
      <div className="print:hidden flex items-center gap-2">
        <Link
          to="/inventory"
          className="inline-flex items-center justify-center gap-1.5 text-sm text-[var(--color-muted)] hover:text-[var(--color-fg)] min-h-11"
        >
          <ArrowLeft className="h-4 w-4" /> Inventory
        </Link>
      </div>

      <div className="print:hidden space-y-2">
        <h1 className="text-2xl font-semibold tracking-tight">
          Sample barcode label
        </h1>
        <p className="text-sm text-[var(--color-muted)]">
          Sized for one Brother QL-810W label:{" "}
          <strong>1.1" × 1.6"</strong>. Does not add stock.
        </p>
        <ol className="text-sm text-[var(--color-muted)] list-decimal pl-5 space-y-1">
          <li>Printer: Brother QL-810W</li>
          <li>Layout: Portrait (not Landscape)</li>
          <li>Paper size: 1.1" × 1.6"</li>
          <li>Margins: None</li>
          <li>Headers and footers: Off</li>
          <li>You should see 1 page, not 17</li>
        </ol>
      </div>

      <div id="lcm-sample-label-print" className="sample-ql-label">
        <div className="sample-ql-name">LAKE COUNTRY MACHINE</div>
        <div className="sample-ql-code">{piece.barcode}</div>
        {qr ? (
          <img src={qr} alt="" className="sample-ql-qr" />
        ) : (
          <div className="sample-ql-qr sample-ql-qr-empty" />
        )}
        <div className="sample-ql-mat">
          {piece.material} {piece.materialType}
        </div>
        <div className="sample-ql-size">{piece.sizeNote}</div>
      </div>

      <div className="print:hidden flex gap-2">
        <Button type="button" onClick={() => window.print()}>
          <Printer className="h-4 w-4" /> Print 1 label
        </Button>
      </div>

      <style>{`
        .sample-ql-label {
          width: ${LABEL_W};
          height: ${LABEL_H};
          box-sizing: border-box;
          padding: 0.06in 0.05in;
          border: 1px solid var(--color-border);
          background: #fff;
          color: #000;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          text-align: center;
          overflow: hidden;
        }
        .sample-ql-name {
          font-size: 6px;
          font-weight: 700;
          letter-spacing: 0.04em;
          line-height: 1.1;
        }
        .sample-ql-code {
          font-family: ui-monospace, monospace;
          font-size: 8px;
          font-weight: 700;
          line-height: 1.15;
          margin-top: 0.03in;
        }
        .sample-ql-qr {
          width: 0.78in;
          height: 0.78in;
          object-fit: contain;
          margin: 0.04in 0;
        }
        .sample-ql-qr-empty {
          background: #eee;
        }
        .sample-ql-mat {
          font-size: 6.5px;
          font-weight: 600;
          line-height: 1.1;
          max-width: 100%;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .sample-ql-size {
          font-size: 5.5px;
          line-height: 1.1;
          max-width: 100%;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        @page {
          size: ${LABEL_W} ${LABEL_H};
          margin: 0;
        }
        @media print {
          html, body {
            margin: 0 !important;
            padding: 0 !important;
            background: #fff !important;
          }
          body * { visibility: hidden !important; }
          #lcm-sample-label-print,
          #lcm-sample-label-print * {
            visibility: visible !important;
          }
          #lcm-sample-label-print {
            position: absolute;
            left: 0;
            top: 0;
            width: ${LABEL_W} !important;
            height: ${LABEL_H} !important;
            border: 0 !important;
            margin: 0 !important;
          }
        }
      `}</style>
    </div>
  );
}
