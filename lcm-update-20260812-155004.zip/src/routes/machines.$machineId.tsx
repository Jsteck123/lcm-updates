import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  Play,
  Square,
  Pause,
  Save,
  Search,
  Eraser,
  Database,
} from "lucide-react";
import { toast } from "sonner";
import { queueForMachine } from "@/lib/lcm/work-queue";
import { useLcmStore, getInProgressJobsForPart } from "@/store/lcm-store";
import { slugToMachine } from "@/lib/lcm/machines";
import { clampOpCount, makeOpLabels, opLabel, zeros } from "@/lib/lcm/ops";
import {
  allMaterials,
  allMaterialTypes,
  allPauseReasons,
  allStockShapes,
} from "@/lib/lcm/lists";
import { quoteFromForm } from "@/lib/lcm/calculations";
import { Button } from "@/components/ui/button";
import { HelpTip, WithHelp } from "@/components/ui/help-tip";
import { Input, Label, Textarea } from "@/components/ui/input";
import { CreatableSelect } from "@/components/ui/creatable-select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DayBonusPanel } from "@/components/day-bonus-panel";
import { ShopToolingFloorPanel } from "@/components/lcm/shop-tooling-panel";
import {
  ticketsForPart,
  qtyAvailable,
  statusLabel,
  cutTicketLabel,
} from "@/lib/lcm/cut-tickets";
import {
  formatCurrency,
  formatPercent,
  formatSeconds,
  formatDateTime,
} from "@/lib/utils";

export const Route = createFileRoute("/machines/$machineId")({
  component: MachineDetailPage,
});

type NewPartDraft = {
  partNumber: string;
  revision: string;
  quantity: string;
  customer: string;
  material: string;
  materialType: string;
  stockShape: string;
  /** OP1 setup minutes (optional but recommended) */
  setupMin: string;
  /** OP1 run minutes per piece (optional but recommended) */
  runMin: string;
  notes: string;
};

const emptyNewPart = (partial?: Partial<NewPartDraft>): NewPartDraft => ({
  partNumber: "",
  revision: "A",
  quantity: "10",
  customer: "",
  material: "Aluminum",
  materialType: "T6 6061",
  stockShape: "Round Stock",
  setupMin: "",
  runMin: "",
  notes: "",
  ...partial,
});

function MachineDetailPage() {
  const { machineId } = Route.useParams();
  const operators = useLcmStore((s) => s.operators);
  const quotes = useLcmStore((s) => s.quotes);
  const customers = useLcmStore((s) => s.customers);
  const cutTicketsRaw = useLcmStore((s) => s.cutTickets);
  const cutTickets = cutTicketsRaw || [];
  const claimCutStock = useLcmStore((s) => s.claimCutStock);
  const maxOps = useLcmStore((s) => clampOpCount(s.settings.maxOperations));
  const customLists = useLcmStore((s) => s.settings.customLists);
  const addCustomListItem = useLcmStore((s) => s.addCustomListItem);
  const addCustomerQuick = useLcmStore((s) => s.addCustomerQuick);
  const addOperatorQuick = useLcmStore((s) => s.addOperatorQuick);
  const saveQuote = useLcmStore((s) => s.saveQuote);

  const machine = useMemo(
    () => slugToMachine(machineId, customLists),
    [machineId, customLists],
  );

  const pauseReasonOptions = useMemo(
    () => allPauseReasons(customLists),
    [customLists],
  );
  const customerOptions = useMemo(
    () => customers.map((c) => c.name),
    [customers],
  );
  const operatorOptions = useMemo(
    () => operators.filter((o) => o.active).map((o) => o.name),
    [operators],
  );
  const materialOptions = useMemo(
    () => allMaterials(customLists),
    [customLists],
  );
  const stockShapeOptions = useMemo(
    () => allStockShapes(customLists),
    [customLists],
  );
  const opLabels = useMemo(() => makeOpLabels(maxOps), [maxOps]);
  const session = useLcmStore((s) => (machine ? s.sessions[machine] : undefined));
  const timer = useLcmStore((s) => (machine ? s.activeTimers[machine] : null));
  const setOperator = useLcmStore((s) => s.setOperatorOnMachine);
  const loadJob = useLcmStore((s) => s.loadJobOnMachine);
  const smartStart = useLcmStore((s) => s.smartStart);
  const smartStop = useLcmStore((s) => s.smartStop);
  const pauseJob = useLcmStore((s) => s.pauseJob);
  const resumeJob = useLcmStore((s) => s.resumeJob);
  const saveJob = useLcmStore((s) => s.saveJob);
  const stockPartUnits = useLcmStore((s) => s.stockPartUnits);
  const clearSession = useLcmStore((s) => s.clearMachineSession);
  const updateNotes = useLcmStore((s) => s.updateSessionNotes);
  const updateField = useLcmStore((s) => s.updateSessionField);
  const getLive = useLcmStore((s) => s.getLiveElapsedSeconds);
  const currentEmail = useLcmStore((s) => s.currentUserEmail);
  const workQueue = useLcmStore((s) => s.workQueue || []);
  const startWorkQueueItem = useLcmStore((s) => s.startWorkQueueItem);
  const moveWorkQueueItem = useLcmStore((s) => s.moveWorkQueueItem);
  const removeWorkQueueItem = useLcmStore((s) => s.removeWorkQueueItem);
  const completeWorkQueueItem = useLcmStore((s) => s.completeWorkQueueItem);
  const machineQueue = useMemo(
    () => (machine ? queueForMachine(workQueue, machine) : []),
    [workQueue, machine],
  );

  const [partSearch, setPartSearch] = useState("");
  const [rev, setRev] = useState("A");
  const [qty, setQty] = useState("10");
  const [customer, setCustomer] = useState("");
  const [unitsPrompt, setUnitsPrompt] = useState(false);
  const [units, setUnits] = useState("0");
  const [pauseOpen, setPauseOpen] = useState(false);
  const [pauseReason, setPauseReason] = useState("Lunch");
  const [saveOpen, setSaveOpen] = useState(false);
  const [saveQty, setSaveQty] = useState("0");
  const [countInAverage, setCountInAverage] = useState(true);
  const [extraStockOpen, setExtraStockOpen] = useState(false);
  const [extraQty, setExtraQty] = useState("");
  const [extraLocation, setExtraLocation] = useState("");
  const [extraQuality, setExtraQuality] = useState<"good" | "second">("good");
  const [extraDefectNote, setExtraDefectNote] = useState("");
  const [pendingCompleteQty, setPendingCompleteQty] = useState<number | null>(null);
  const [extraUins, setExtraUins] = useState<string[]>([]);
  const [uinWriteOpen, setUinWriteOpen] = useState(false);
  const [newPartOpen, setNewPartOpen] = useState(false);
  const [newPart, setNewPart] = useState<NewPartDraft>(emptyNewPart());
  const [pendingExistingJobId, setPendingExistingJobId] = useState<
    string | undefined
  >();
  const [tick, setTick] = useState(0);

  const typeOptions = useMemo(
    () => allMaterialTypes(newPart.material || "Aluminum", customLists),
    [newPart.material, customLists],
  );

  useEffect(() => {
    const id = setInterval(() => setTick((n) => n + 1), 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (session?.partNumber) {
      setPartSearch(session.partNumber);
      setRev(session.revision || "A");
      setQty(String(session.quantity || 0));
      setCustomer(session.customer || "");
    }
  }, [session?.jobId]);

  const liveSeconds = machine ? getLive(machine) : null;

  const nextHint = useMemo(() => {
    if (!session) return "—";
    const n = Math.max(session.setups?.length || 0, maxOps);
    const anyQuoted =
      session.quotedSetups?.some((v) => (v || 0) > 0) ||
      session.quotedRuntimes?.some((v) => (v || 0) > 0);
    for (let i = 0; i < n; i++) {
      const planned =
        !anyQuoted ||
        (session.quotedSetups[i] || 0) > 0 ||
        (session.quotedRuntimes[i] || 0) > 0 ||
        session.setups[i] != null ||
        session.runtimes[i] != null;
      if (!planned) continue;
      if (session.setups[i] == null) return `Next: ${opLabel(i)} Setup`;
      if (session.runtimes[i] == null) return `Next: ${opLabel(i)} Runtime`;
    }
    return "All operations complete";
  }, [session, maxOps]);

  if (!machine) {
    return (
      <div className="max-w-lg mx-auto text-center space-y-4 py-16">
        <p className="text-[var(--color-muted)]">Unknown machine.</p>
        <Link to="/machines" className="text-[var(--color-primary)]">
          Back to shop floor
        </Link>
      </div>
    );
  }

  function doLoadJob(opts: {
    partNumber: string;
    revision: string;
    quantity: number;
    customer: string;
    existingJobId?: string;
    fromDb: boolean;
  }) {
    if (!machine) return;
    const result = loadJob(machine, {
      partNumber: opts.partNumber,
      revision: opts.revision,
      quantity: opts.quantity,
      customer: opts.customer,
      existingJobId: opts.existingJobId,
    });
    if (!result.ok) {
      toast.error(result.error);
      return;
    }
    setRev(opts.revision);
    setCustomer(opts.customer);
    setQty(String(opts.quantity));
    setPartSearch(opts.partNumber.toUpperCase());
    toast.success(
      opts.existingJobId
        ? `Resumed in-progress job for ${opts.partNumber}`
        : opts.fromDb
          ? `Loaded ${opts.partNumber} from database`
          : `Saved ${opts.partNumber} to database and loaded job`,
    );
  }

  function handleSearchLoad() {
    const pn = partSearch.trim().toUpperCase();
    if (!pn || !machine) {
      toast.error("Enter a part number");
      return;
    }
    const open = getInProgressJobsForPart(pn);
    const existingJobId = open[0]?.id;
    const quote = quotes.find(
      (q) => q.partNumber.toLowerCase() === pn.toLowerCase(),
    );

    // Known part → load immediately
    if (quote) {
      doLoadJob({
        partNumber: pn,
        revision: rev || quote.revision || "A",
        quantity: Number(qty) || quote.quantities.find((q) => q > 0) || 1,
        customer: customer || quote.customer || open[0]?.customer || "",
        existingJobId,
        fromDb: true,
      });
      return;
    }

    // Unknown part → capture database fields first
    setPendingExistingJobId(existingJobId);
    setNewPart(
      emptyNewPart({
        partNumber: pn,
        revision: rev || "A",
        quantity: qty || "10",
        customer: customer || open[0]?.customer || "",
        material: "Aluminum",
        materialType: "T6 6061",
        stockShape: "Round Stock",
      }),
    );
    setNewPartOpen(true);
  }

  function onNewPartMaterialChange(material: string) {
    const types = allMaterialTypes(material, customLists);
    setNewPart((f) => {
      const stillValid = types.some(
        (t) => t.toLowerCase() === (f.materialType || "").toLowerCase(),
      );
      return {
        ...f,
        material,
        materialType: stillValid ? f.materialType : types[0] || "",
      };
    });
  }

  function confirmNewPart() {
    if (!machine) return;
    const pn = newPart.partNumber.trim().toUpperCase();
    if (!pn) {
      toast.error("Part number required");
      return;
    }
    if (!newPart.material.trim()) {
      toast.error("Select a material");
      return;
    }
    if (!newPart.materialType.trim()) {
      toast.error("Select a material type");
      return;
    }
    if (!newPart.customer.trim()) {
      toast.error("Select or add a customer");
      return;
    }

    const setup = Number(newPart.setupMin) || 0;
    const run = Number(newPart.runMin) || 0;
    const setupTimes = zeros(maxOps);
    const runTimes = zeros(maxOps);
    setupTimes[0] = setup;
    runTimes[0] = run;
    const quantities = [Number(newPart.quantity) || 1, 0, 0, 0, 0, 0];

    const quote = quoteFromForm(
      {
        partNumber: pn,
        revision: (newPart.revision || "A").toUpperCase(),
        customer: newPart.customer.trim(),
        machines: [machine],
        material: newPart.material.trim(),
        materialType: newPart.materialType.trim(),
        stockShape: newPart.stockShape || "Round Stock",
        machineRate: 1,
        materialPct: 1.15,
        setupTimes,
        runTimes,
        quantities,
        prices: [0, 0, 0, 0, 0, 0],
      },
      maxOps,
    );

    const saved = saveQuote(quote, "submit");
    if (!saved.ok) {
      // If somehow created between open and confirm, try update
      const updated = saveQuote(quote, "update");
      if (!updated.ok) {
        toast.error(saved.error || updated.error || "Could not save part");
        return;
      }
    }

    // Stash shop note onto machine session after load
    const noteLine = newPart.notes.trim();
    doLoadJob({
      partNumber: pn,
      revision: quote.revision,
      quantity: Number(newPart.quantity) || 1,
      customer: quote.customer,
      existingJobId: pendingExistingJobId,
      fromDb: false,
    });
    if (noteLine) {
      updateNotes(machine, noteLine);
    }
    setNewPartOpen(false);
    setPendingExistingJobId(undefined);
  }

  function handleStart() {
    if (!machine) return;
    const r = smartStart(machine);
    if (!r.ok) toast.error(r.error);
    else toast.success(r.message || "Started");
  }

  function handleStop() {
    if (!machine) return;
    const r = smartStop(machine);
    if (r.needsUnits) {
      setUnitsPrompt(true);
      return;
    }
    if (!r.ok) toast.error(r.error);
    else toast.success("Timer stopped");
  }

  function confirmUnits() {
    if (!machine) return;
    const r = smartStop(machine, Number(units) || 0);
    if (!r.ok) toast.error(r.error);
    else {
      toast.success("Runtime stopped");
      setUnitsPrompt(false);
    }
  }

  function handlePause() {
    if (!machine) return;
    const r = pauseJob(machine, pauseReason);
    if (!r.ok) toast.error(r.error);
    else {
      toast.success(`Paused: ${pauseReason}`);
      setPauseOpen(false);
    }
  }

  function handleResume() {
    if (!machine) return;
    const r = resumeJob(machine);
    if (!r.ok) toast.error(r.error);
    else toast.success(r.message || "Job resumed");
  }

  function finishJobComplete(qtyDone: number) {
    if (!machine) return;
    const r = saveJob(machine, "completed", qtyDone, { countInAverage });
    if (!r.ok) {
      toast.error(r.error);
      return;
    }
    toast.success(
      countInAverage
        ? "Job completed · shop average updated (recipe times)"
        : "Job completed · excluded from averages (history only)",
    );
    setSaveOpen(false);
    setExtraStockOpen(false);
    setPendingCompleteQty(null);
    setCountInAverage(true);
  }

  function handleSave(mode: "in-progress" | "completed") {
    if (!machine) return;
    const qtyDone = Number(saveQty);
    const planned = Number(session?.quantity) || 0;

    if (mode === "in-progress") {
      const r = saveJob(machine, mode, Number.isFinite(qtyDone) ? qtyDone : 0);
      if (!r.ok) toast.error(r.error);
      else {
        toast.success("Saved in progress");
        setSaveOpen(false);
        setCountInAverage(true);
      }
      return;
    }

    // Completed — if they made more than the job qty, ask about stock
    const done = Number.isFinite(qtyDone) ? qtyDone : planned;
    const extras = Math.max(0, Math.floor(done - planned));
    if (extras > 0 && (session?.partNumber || "").trim()) {
      setPendingCompleteQty(done);
      setExtraQty(String(extras));
      setExtraLocation("");
      setExtraQuality("good");
      setExtraDefectNote("");
      setExtraStockOpen(true);
      return;
    }
    finishJobComplete(done);
  }

  function handleExtraStockDecision(stockThem: boolean) {
    const done = pendingCompleteQty ?? (Number(saveQty) || 0);
    const pn = session?.partNumber || "";
    const rev = session?.revision || "";
    const jobRef = session?.jobId || "";

    if (stockThem) {
      const n = Math.max(0, Math.floor(Number(extraQty) || 0));
      if (n <= 0) {
        toast.error("Enter how many extras go to stock (or choose No)");
        return;
      }
      const r = stockPartUnits({
        partNumber: pn,
        revision: rev,
        qty: n,
        location: extraLocation,
        jobRef,
        quality: extraQuality,
        defectNote: extraDefectNote,
      });
      if (!r.ok) {
        toast.error(r.error || "Could not update stock");
        return;
      }
      const codes = (r.units || []).map((u) => u.uin);
      setExtraUins(codes);
      setExtraStockOpen(false);
      setUinWriteOpen(true);
      // complete job after they dismiss UIN card — keep pending qty
      return;
    }

    finishJobComplete(done);
  }

  function confirmUinsWritten() {
    const done = pendingCompleteQty ?? (Number(saveQty) || 0);
    setUinWriteOpen(false);
    setExtraUins([]);
    toast.success(
      extraQuality === "second"
        ? "Second-quality parts stocked — write UINs on each part"
        : "Extras stocked — write UINs on each part",
    );
    finishJobComplete(done);
  }

  const displayOps = useMemo(() => {
    if (!session?.jobId) return opLabels;
    const anyQuoted =
      session.quotedSetups?.some((v) => (v || 0) > 0) ||
      session.quotedRuntimes?.some((v) => (v || 0) > 0);
    if (!anyQuoted) return opLabels;
    let last = 0;
    for (let i = 0; i < maxOps; i++) {
      if (
        (session.quotedSetups[i] || 0) > 0 ||
        (session.quotedRuntimes[i] || 0) > 0 ||
        session.setups[i] != null ||
        session.runtimes[i] != null
      ) {
        last = i;
      }
    }
    return makeOpLabels(Math.min(maxOps, Math.max(last + 1, 1)));
  }, [session, opLabels, maxOps]);

  return (
    <div className="mx-auto max-w-6xl space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
        <div className="flex items-start gap-3 min-w-0">
          <Link
            to="/machines"
            className="inline-flex h-11 w-11 items-center justify-center rounded-[var(--radius-md)] border border-[var(--color-border)] shrink-0 hover:bg-[var(--color-surface-2)]"
          >
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <div className="min-w-0">
            <h1 className="text-xl sm:text-2xl font-semibold tracking-tight truncate">
              {machine}
             <HelpTip id="shop-floor-load" /></h1>
            <p className="text-xs text-[var(--color-muted)] mt-0.5">
              Signed-in user: {currentEmail} · up to {maxOps} ops
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {timer && (
            <Badge tone="running">
              <span className="live-dot mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-current" />
              {timer.type} {timer.operation} · {formatSeconds(liveSeconds || 0)}
            </Badge>
          )}
          {session?.paused && <Badge tone="paused">PAUSED</Badge>}
        </div>
      </div>

      {machineQueue.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Machine running order</CardTitle>
            <CardDescription>
              Expected work for this machine. Load starts the job on the session below.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {machineQueue.map((q, i) => (
              <div
                key={q.id}
                className="flex flex-col sm:flex-row sm:items-center gap-2 rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2 text-sm"
              >
                <div className="flex-1 min-w-0">
                  <div className="font-medium">
                    {i + 1}. {q.partNumber}{" "}
                    <span className="text-[var(--color-muted)] font-normal">
                      x{q.qty} · rev {q.revision || "—"}
                    </span>
                  </div>
                  <div className="text-xs text-[var(--color-muted)]">
                    PO {q.poNumber || "—"}
                    {q.operatorName ? ` · ${q.operatorName}` : ""}
                    {" · "}
                    {q.status}
                    {q.customer ? ` · ${q.customer}` : ""}
                  </div>
                </div>
                <div className="flex flex-wrap gap-1">
                  <Button size="sm" variant="ghost" onClick={() => moveWorkQueueItem(q.id, "up")}>
                    Up
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => moveWorkQueueItem(q.id, "down")}>
                    Down
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => {
                      const r = startWorkQueueItem(q.id);
                      if (!r.ok) toast.error(r.error || "Failed");
                      else toast.success(`Loaded ${q.partNumber}`);
                    }}
                  >
                    Load job
                  </Button>
                  <Button size="sm" variant="secondary" onClick={() => completeWorkQueueItem(q.id)}>
                    Done
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => removeWorkQueueItem(q.id)}>
                    Remove
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}


      <div className="grid lg:grid-cols-3 gap-4">
        <div className="space-y-4 lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Operator</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1.5">
                <Label>Select operator</Label>
                <CreatableSelect
                  value={session?.operatorName || ""}
                  options={operatorOptions}
                  onChange={(v) => setOperator(machine, v)}
                  onCreate={(v) => {
                    const r = addOperatorQuick(v);
                    if (!r.ok) {
                      toast.error(r.error);
                      return false;
                    }
                    toast.success(`Added operator ${v}`);
                  }}
                  createTitle="Add operator"
                  createHint="Creates an operator account (shop-floor tabs, no PIN)."
                />
              </div>
              <div className="text-xs text-[var(--color-muted)]">
                Login: {formatDateTime(session?.loginTime)}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Part search</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1.5">
                <Label>Part number</Label>
                <Input
                  value={partSearch}
                  onChange={(e) => setPartSearch(e.target.value)}
                  placeholder="e.g. AF-4421"
                  list="part-suggestions"
                />
                <datalist id="part-suggestions">
                  {quotes.map((q) => (
                    <option key={q.id} value={q.partNumber} />
                  ))}
                </datalist>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1.5">
                  <Label>Revision</Label>
                  <Input value={rev} onChange={(e) => setRev(e.target.value.toUpperCase())} />
                </div>
                <div className="space-y-1.5">
                  <Label>Quantity</Label>
                  <Input
                    type="number"
                    min={1}
                    value={qty}
                    onChange={(e) => setQty(e.target.value)}
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Customer</Label>
                <CreatableSelect
                  value={customer}
                  options={customerOptions}
                  onChange={setCustomer}
                  onCreate={(v) => {
                    const r = addCustomerQuick(v);
                    if (!r.ok) {
                      toast.error(r.error);
                      return false;
                    }
                    toast.success(`Added customer ${v}`);
                  }}
                  createTitle="Add customer"
                />
              </div>
              <Button className="w-full" onClick={handleSearchLoad}>
                <Search className="h-4 w-4" /> Search / Load job
              </Button>
              <p className="text-[11px] text-[var(--color-subtle)]">
                New parts not in the database open a short form (material, etc.) before loading.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>This job (progress only)</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-3">
              <div className="panel-inset p-3">
                <div className="text-xs text-[var(--color-muted)]">Job efficiency</div>
                <div className="text-2xl font-semibold tabular mt-1">
                  {formatPercent(session?.efficiency || 0)}
                </div>
              </div>
              <div className="panel-inset p-3">
                <div className="text-xs text-[var(--color-muted)]">Not paid here</div>
                <div className="text-sm font-medium mt-2 text-[var(--color-muted)] leading-snug">
                  Cash bonus = full-day average (below)
                </div>
              </div>
            </CardContent>
          </Card>


          {session?.partNumber && (() => {
            const tks = ticketsForPart(cutTickets, session.partNumber);
            if (!tks.length) return null;
            return (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Saw / stock cut</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {tks.slice(0, 3).map((tk) => {
                    const avail = qtyAvailable(tk);
                    return (
                      <div
                        key={tk.id}
                        className="rounded-[var(--radius-md)] border border-[var(--color-border)] p-3 text-sm space-y-1"
                      >
                        <div className="font-medium">{statusLabel(tk.status)}</div>
                        <div className="text-[var(--color-muted)] text-xs">
                          {cutTicketLabel(tk)} · cut {tk.qtyCut}/{tk.qtyRequested} ·{" "}
                          {avail} available
                        </div>
                        {avail > 0 && (
                          <Button
                            size="sm"
                            type="button"
                            className="mt-1"
                            onClick={() => {
                              const r = claimCutStock(tk.id, Math.min(avail, 1), machine);
                              if (r.ok)
                                toast.success(`Claimed 1 blank · ${r.available} still available`);
                              else toast.error(r.error || "Cannot claim");
                            }}
                          >
                            Claim 1 blank
                          </Button>
                        )}
                        {tk.status === "requested" && (
                          <p className="text-[11px] text-[var(--color-muted)]">
                            Waiting on saw — you can start setup; claim blanks as they come off.
                          </p>
                        )}
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            );
          })()}

          <DayBonusPanel operatorName={session?.operatorName || ""} compact />
        </div>

        <div className="space-y-4 lg:col-span-2">
          <Card>
            <CardHeader className="flex-row items-center justify-between gap-2">
              <div>
                <CardTitle>Timer controls</CardTitle>
                <p className="text-xs text-[var(--color-muted)] mt-1">{nextHint}</p>
              </div>
              {session?.jobId && (
                <Badge tone="info" className="font-mono text-[10px]">
                  {session.jobId.slice(0, 8)}
                </Badge>
              )}
            </CardHeader>
            <CardContent className="space-y-4">
              {session?.paused && (
                <div className="rounded-[var(--radius-lg)] border border-[color-mix(in_oklab,var(--color-warn)_45%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-warn)_10%,var(--color-surface-2))] p-4 flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
                  <div className="min-w-0">
                    <div className="text-xs uppercase tracking-wide text-[var(--color-warn)] font-semibold">
                      Job paused
                    </div>
                    <div className="text-sm font-medium mt-0.5">
                      {session.partNumber || "This job"} is on hold
                      {session.pauseStart
                        ? ` · since ${formatDateTime(session.pauseStart)}`
                        : ""}
                    </div>
                    <p className="text-xs text-[var(--color-muted)] mt-1">
                      Resume to start the next setup or runtime.
                    </p>
                  </div>
                  <Button
                    size="lg"
                    variant="success"
                    className="shrink-0 min-h-12"
                    onClick={handleResume}
                  >
                    <Play className="h-4 w-4" /> Resume job
                  </Button>
                </div>
              )}

              {session?.jobId && !timer && !session?.paused && String(nextHint).startsWith("Next:") && (
                <Button
                  size="lg"
                  className="w-full min-h-14 text-base"
                  onClick={handleStart}
                >
                  <Play className="h-5 w-5" />
                  {nextHint}
                </Button>
              )}

              {machineQueue.length > 0 && (
                <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-2">
                  <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">
                    Queue for this machine
                  </div>
                  {machineQueue.slice(0, 6).map((item, idx) => (
                    <div
                      key={item.id}
                      className="flex items-center justify-between gap-2 text-sm"
                    >
                      <div className="min-w-0 truncate">
                        <span className="text-[var(--color-subtle)] mr-1">{idx + 1}.</span>
                        <span className="font-mono font-medium">{item.partNumber}</span>
                        <span className="text-xs text-[var(--color-muted)] ml-1">
                          rev {item.revision || "—"} · qty {item.qty}
                        </span>
                      </div>
                      <Button
                        size="sm"
                        variant="secondary"
                        type="button"
                        disabled={!!session?.jobId}
                        onClick={() => {
                          const r = startWorkQueueItem(item.id);
                          if (!r.ok) toast.error(r.error || "Could not start queue item");
                          else toast.success(`Loaded ${item.partNumber} from queue`);
                        }}
                      >
                        Load
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <Button
                  size="lg"
                  variant="success"
                  onClick={handleStart}
                  disabled={!session?.jobId || !!timer || !!session?.paused}
                >
                  <Play className="h-4 w-4" /> Start
                </Button>
                <Button size="lg" variant="danger" onClick={handleStop} disabled={!timer}>
                  <Square className="h-4 w-4" /> Stop
                </Button>
                {session?.paused ? (
                  <Button size="lg" variant="success" onClick={handleResume}>
                    <Play className="h-4 w-4" /> Resume
                  </Button>
                ) : (
                  <Button
                    size="lg"
                    variant="warn"
                    onClick={() => setPauseOpen(true)}
                    disabled={!session?.jobId || !!timer}
                  >
                    <Pause className="h-4 w-4" /> Pause
                  </Button>
                )}
                <Button
                  size="lg"
                  variant="secondary"
                  onClick={() => {
                    setSaveQty(String(session?.quantityCompleted || 0));
                    setSaveOpen(true);
                  }}
                  disabled={!session?.jobId}
                >
                  <Save className="h-4 w-4" /> Save
                </Button>
              </div>

              {timer && (
                <div className="rounded-[var(--radius-lg)] border border-[color-mix(in_oklab,var(--color-running)_40%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-running)_8%,var(--color-surface-2))] p-4 flex items-center justify-between">
                  <div>
                    <div className="text-xs text-[var(--color-muted)] uppercase tracking-wide">
                      Running {timer.type}
                    </div>
                    <div className="text-lg font-semibold">{timer.operation}</div>
                  </div>
                  <div className="text-3xl font-semibold tabular tracking-tight">
                    {formatSeconds(liveSeconds || 0)}
                  </div>
                </div>
              )}

              <div className="overflow-x-auto -mx-1">
                <table className="w-full text-xs sm:text-sm table-fixed">
                  <colgroup>
                    <col className="w-[3.25rem]" />
                    <col />
                    <col />
                  </colgroup>
                  <thead>
                    <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
                      <th className="py-1.5 pr-1 font-medium">Op</th>
                      <th className="py-1.5 px-1 font-medium">
                        Setup{" "}
                        <span className="font-normal text-[10px] text-[var(--color-subtle)]">
                          Q → A
                        </span>
                      </th>
                      <th className="py-1.5 pl-1 font-medium">
                        Run{" "}
                        <span className="font-normal text-[10px] text-[var(--color-subtle)]">
                          Q → A /pc
                        </span>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {displayOps.map((op, i) => {
                      const setup = session?.setups[i];
                      const runtime = session?.runtimes[i];
                      const setupLive =
                        timer?.operation === op && timer.type === "Setup"
                          ? liveSeconds
                          : null;
                      const runLive =
                        timer?.operation === op && timer.type === "Runtime"
                          ? liveSeconds
                          : null;
                      const setupActual =
                        setup === "STARTED" || setupLive != null ? (
                          <span className="text-[var(--color-running)] font-semibold tabular">
                            {formatSeconds(setupLive ?? 0)}
                          </span>
                        ) : setup != null ? (
                          <span className="tabular font-medium">
                            {formatSeconds(Number(setup))}
                          </span>
                        ) : (
                          <span className="text-[var(--color-subtle)]">—</span>
                        );
                      const runActual =
                        runtime === "STARTED" || runLive != null ? (
                          <span className="text-[var(--color-running)] font-semibold tabular">
                            {formatSeconds(runLive ?? 0)}
                          </span>
                        ) : runtime != null ? (
                          <span className="tabular font-medium">
                            {formatSeconds(Number(runtime))}
                          </span>
                        ) : (
                          <span className="text-[var(--color-subtle)]">—</span>
                        );
                      return (
                        <tr
                          key={op}
                          className="border-b border-[var(--color-border)] last:border-0"
                        >
                          <td className="py-1.5 pr-1 font-semibold text-[11px] sm:text-xs">
                            {op}
                          </td>
                          <td className="py-1.5 px-1">
                            <div className="flex flex-wrap items-baseline gap-x-1.5 gap-y-0 leading-tight">
                              <span className="tabular text-[var(--color-muted)]">
                                {formatSeconds(session?.quotedSetups[i] || 0)}
                              </span>
                              <span className="text-[var(--color-subtle)] text-[10px]">
                                →
                              </span>
                              {setupActual}
                            </div>
                          </td>
                          <td className="py-1.5 pl-1">
                            <div className="flex flex-wrap items-baseline gap-x-1.5 gap-y-0 leading-tight">
                              <span className="tabular text-[var(--color-muted)]">
                                {formatSeconds(session?.quotedRuntimes[i] || 0)}
                              </span>
                              <span className="text-[var(--color-subtle)] text-[10px]">
                                →
                              </span>
                              {runActual}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          <div className="grid sm:grid-cols-2 gap-4">
            <details
              className="rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-surface)]"
              open={!timer}
            >
              <summary className="cursor-pointer list-none px-4 py-3 font-semibold text-base select-none [&::-webkit-details-marker]:hidden">
                Job details
                <span className="ml-2 text-xs font-normal text-[var(--color-muted)]">
                  {timer
                    ? "collapsed while timer runs — tap to expand"
                    : "part · rev · qty"}
                </span>
              </summary>
              <div className="space-y-3 px-4 pb-4 pt-3 text-sm border-t border-[var(--color-border)]">
                <Detail label="Part #" value={session?.partNumber || "—"} />
                <Detail label="Customer" value={session?.customer || "—"} />
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <Label>Revision</Label>
                    <Input
                      value={session?.revision || ""}
                      onChange={(e) =>
                        updateField(machine, {
                          revision: e.target.value.toUpperCase(),
                        })
                      }
                    />
                  </div>
                  <div className="space-y-1">
                    <Label>Quantity</Label>
                    <Input
                      type="number"
                      value={session?.quantity || 0}
                      onChange={(e) =>
                        updateField(machine, {
                          quantity: Number(e.target.value) || 0,
                        })
                      }
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <Label>Qty completed</Label>
                  <Input
                    type="number"
                    value={session?.quantityCompleted || 0}
                    onChange={(e) =>
                      updateField(machine, {
                        quantityCompleted: Number(e.target.value) || 0,
                      })
                    }
                  />
                </div>
              </div>
            </details>

            {machine ? (
              <ShopToolingFloorPanel machine={machine} tick={tick} />
            ) : null}

            <details
              className="rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-surface)] sm:col-span-2"
              open={!timer}
            >
              <summary className="cursor-pointer list-none px-4 py-3 font-semibold text-base select-none [&::-webkit-details-marker]:hidden">
                Notes
                <span className="ml-2 text-xs font-normal text-[var(--color-muted)]">
                  {timer
                    ? "collapsed while timer runs — tap to expand"
                    : "job notes · clear station"}
                </span>
              </summary>
              <div className="space-y-3 px-4 pb-4 pt-3 border-t border-[var(--color-border)]">
                <Textarea
                  value={session?.notes || ""}
                  onChange={(e) => updateNotes(machine, e.target.value)}
                  placeholder="Job notes"
                  className="min-h-28"
                />
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    clearSession(machine);
                    toast.message("Session cleared");
                  }}
                >
                  <Eraser className="h-4 w-4" /> Clear station
                </Button>
              </div>
            </details>
          </div>
        </div>
      </div>

      {newPartOpen && (
        <Modal
          title="New part — add to database"
          onClose={() => {
            setNewPartOpen(false);
            setPendingExistingJobId(undefined);
          }}
          wide
        >
          <div className="flex items-start gap-2 rounded-[var(--radius-md)] border border-[color-mix(in_oklab,var(--color-accent)_35%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-accent)_8%,var(--color-surface))] px-3 py-2 text-sm mb-4">
            <Database className="h-4 w-4 mt-0.5 text-[var(--color-accent)] shrink-0" />
            <p>
              <strong className="text-[var(--color-fg)]">{newPart.partNumber}</strong> is not in
              the parts database. Enter material and basics so the shop has a record, then the job
              will load on this machine.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Part #</Label>
              <Input value={newPart.partNumber} disabled className="font-semibold" />
            </div>
            <div className="space-y-1.5">
              <Label>Revision *</Label>
              <Input
                value={newPart.revision}
                onChange={(e) =>
                  setNewPart((f) => ({ ...f, revision: e.target.value.toUpperCase() }))
                }
              />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Customer *</Label>
              <CreatableSelect
                value={newPart.customer}
                options={customerOptions}
                onChange={(v) => setNewPart((f) => ({ ...f, customer: v }))}
                onCreate={(v) => {
                  const r = addCustomerQuick(v);
                  if (!r.ok) {
                    toast.error(r.error);
                    return false;
                  }
                  toast.success(`Added customer ${v}`);
                }}
                createTitle="Add customer"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Quantity *</Label>
              <Input
                type="number"
                min={1}
                value={newPart.quantity}
                onChange={(e) => setNewPart((f) => ({ ...f, quantity: e.target.value }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Stock shape</Label>
              <CreatableSelect
                allowEmpty={false}
                value={newPart.stockShape}
                options={stockShapeOptions}
                onChange={(v) => setNewPart((f) => ({ ...f, stockShape: v }))}
                onCreate={(v) => {
                  const r = addCustomListItem("stockShapes", v);
                  if (!r.ok) {
                    toast.error(r.error);
                    return false;
                  }
                  toast.success(`Added stock shape ${v}`);
                }}
                createTitle="Add stock shape"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Material *</Label>
              <CreatableSelect
                allowEmpty={false}
                value={newPart.material}
                options={materialOptions}
                onChange={onNewPartMaterialChange}
                onCreate={(v) => {
                  const r = addCustomListItem("materials", v);
                  if (!r.ok) {
                    toast.error(r.error);
                    return false;
                  }
                  toast.success(`Added material ${v}`);
                }}
                createTitle="Add material"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Material type *</Label>
              <CreatableSelect
                allowEmpty={false}
                value={newPart.materialType}
                options={typeOptions}
                onChange={(v) => setNewPart((f) => ({ ...f, materialType: v }))}
                onCreate={(v) => {
                  const mat = newPart.material || "Other";
                  const r = addCustomListItem("materialTypes", v, mat);
                  if (!r.ok) {
                    toast.error(r.error);
                    return false;
                  }
                  toast.success(`Added ${v} under ${mat}`);
                }}
                createTitle={`Add type for ${newPart.material}`}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Est. OP1 setup (min)</Label>
              <Input
                type="number"
                step="0.1"
                min={0}
                value={newPart.setupMin}
                onChange={(e) => setNewPart((f) => ({ ...f, setupMin: e.target.value }))}
                placeholder="Optional"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Est. OP1 run (min/pc)</Label>
              <Input
                type="number"
                step="0.1"
                min={0}
                value={newPart.runMin}
                onChange={(e) => setNewPart((f) => ({ ...f, runMin: e.target.value }))}
                placeholder="Optional"
              />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Notes</Label>
              <Textarea
                value={newPart.notes}
                onChange={(e) => setNewPart((f) => ({ ...f, notes: e.target.value }))}
                placeholder="Anything the next person should know"
                className="min-h-20"
              />
            </div>
          </div>

          <p className="text-[11px] text-[var(--color-subtle)] mt-3">
            Machine is set to <strong className="text-[var(--color-fg)]">{machine}</strong>. You
            can refine pricing later in Master Quoter.
          </p>

          <div className="flex flex-col-reverse sm:flex-row gap-2 mt-4 justify-end">
            <Button
              variant="ghost"
              onClick={() => {
                setNewPartOpen(false);
                setPendingExistingJobId(undefined);
              }}
            >
              Cancel
            </Button>
            <Button onClick={confirmNewPart}>
              <Database className="h-4 w-4" /> Save to database & load job
            </Button>
          </div>
        </Modal>
      )}

      {unitsPrompt && (
        <Modal title="Units completed" onClose={() => setUnitsPrompt(false)}>
          <p className="text-sm text-[var(--color-muted)] mb-3">
            Enter number of units completed during this runtime session.
          </p>
          <Input
            type="number"
            min={0}
            value={units}
            onChange={(e) => setUnits(e.target.value)}
            autoFocus
          />
          <div className="flex gap-2 mt-4 justify-end">
            <Button variant="ghost" onClick={() => setUnitsPrompt(false)}>
              Cancel
            </Button>
            <Button onClick={confirmUnits}>Confirm stop</Button>
          </div>
        </Modal>
      )}

      {pauseOpen && (
        <Modal title="Pause reason" onClose={() => setPauseOpen(false)}>
          <CreatableSelect
            allowEmpty={false}
            value={pauseReason}
            options={pauseReasonOptions}
            onChange={setPauseReason}
            onCreate={(v) => {
              const r = addCustomListItem("pauseReasons", v);
              if (!r.ok) {
                toast.error(r.error);
                return false;
              }
              toast.success(`Added pause reason ${v}`);
            }}
            createTitle="Add pause reason"
          />
          <div className="flex gap-2 mt-4 justify-end">
            <Button variant="ghost" onClick={() => setPauseOpen(false)}>
              Cancel
            </Button>
            <Button variant="warn" onClick={handlePause}>
              Pause job
            </Button>
          </div>
        </Modal>
      )}

      {saveOpen && (
        <Modal title="Save job" onClose={() => setSaveOpen(false)}>
          <p className="text-sm text-[var(--color-muted)] mb-3">
            Efficiency: {formatPercent(session?.efficiency || 0)} · Bonus:{" "}
            {formatCurrency(session?.bonus || 0)}
          </p>
          <div className="space-y-1.5 mb-2">
            <Label>Qty completed (good parts finished)</Label>
            <Input
              type="number"
              min={0}
              value={saveQty}
              onChange={(e) => setSaveQty(e.target.value)}
            />
            <p className="text-[11px] text-[var(--color-subtle)]">
              Job qty: {session?.quantity || 0}
              {Number(saveQty) > (session?.quantity || 0) ? (
                <span className="text-[var(--color-warn)] font-medium">
                  {" "}
                  · {Math.floor(Number(saveQty) - (session?.quantity || 0))} over
                  job qty — we'll ask about stocking extras on complete
                </span>
              ) : null}
            </p>
          </div>
          <label className="flex items-start gap-2 text-sm mb-4 min-h-11 cursor-pointer">
            <input
              type="checkbox"
              className="mt-1 h-4 w-4 accent-[var(--color-primary)]"
              checked={countInAverage}
              onChange={(e) => setCountInAverage(e.target.checked)}
            />
            <span>
              <span className="font-medium">Use this run in shop averages</span>
              <span className="block text-xs text-[var(--color-muted)] mt-0.5">
                Uncheck for training/scrap/one-offs. History is always kept. Extreme
                outliers are auto-excluded.
              </span>
            </span>
          </label>
          <div className="flex flex-col sm:flex-row gap-2">
            <Button
              variant="secondary"
              className="flex-1"
              onClick={() => handleSave("in-progress")}
            >
              Save in progress
            </Button>
            <Button className="flex-1" onClick={() => handleSave("completed")}>
              Mark completed
            </Button>
          </div>
          <p className="text-xs text-[var(--color-subtle)] mt-3">
            In Progress requires the job to be paused first. Completing updates recipe
            times only — not customer prices.
          </p>
        </Modal>
      )}

      {extraStockOpen && (
        <Modal
          title="Extra parts — stock them?"
          onClose={() => handleExtraStockDecision(false)}
        >
          <p className="text-sm text-[var(--color-muted)] mb-3 leading-relaxed">
            Job was for{" "}
            <strong className="text-[var(--color-fg)]">
              {session?.quantity || 0}
            </strong>{" "}
            and you finished{" "}
            <strong className="text-[var(--color-fg)]">
              {pendingCompleteQty ?? saveQty}
            </strong>
            . Should any of the extras go into{" "}
            <strong className="text-[var(--color-fg)]">Parts inventory</strong>{" "}
            (on-hand stock)?
          </p>
          <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)]/50 px-3 py-2 text-xs text-[var(--color-muted)] mb-4">
            Part{" "}
            <span className="font-mono text-[var(--color-fg)]">
              {session?.partNumber || "—"}
            </span>
            {session?.revision ? ` · Rev ${session.revision}` : ""}
          </div>
          <div className="space-y-1.5 mb-3">
            <Label>How many extras to stock?</Label>
            <Input
              type="number"
              min={0}
              value={extraQty}
              onChange={(e) => setExtraQty(e.target.value)}
            />
            <p className="text-[11px] text-[var(--color-subtle)]">
              Default is the over-run amount. Use less if some were scrap / hold.
            </p>
          </div>
          <div className="space-y-1.5 mb-3">
            <Label>Quality</Label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                className={`rounded-[var(--radius-md)] border px-3 py-2.5 text-sm min-h-11 text-left ${
                  extraQuality === "good"
                    ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)]"
                    : "border-[var(--color-border)] hover:bg-[var(--color-surface-2)]"
                }`}
                onClick={() => setExtraQuality("good")}
              >
                <span className="font-medium">Good</span>
                <span className="block text-[11px] text-[var(--color-muted)]">
                  Sellable as normal stock
                </span>
              </button>
              <button
                type="button"
                className={`rounded-[var(--radius-md)] border px-3 py-2.5 text-sm min-h-11 text-left ${
                  extraQuality === "second"
                    ? "border-[var(--color-warn)] bg-[color-mix(in_oklab,var(--color-warn)_14%,transparent)]"
                    : "border-[var(--color-border)] hover:bg-[var(--color-surface-2)]"
                }`}
                onClick={() => setExtraQuality("second")}
              >
                <span className="font-medium">Second quality</span>
                <span className="block text-[11px] text-[var(--color-muted)]">
                  Slight defect — keep, note it
                </span>
              </button>
            </div>
          </div>
          {extraQuality === "second" && (
            <div className="space-y-1.5 mb-3">
              <Label>Potential defect / note (required)</Label>
              <Textarea
                rows={3}
                placeholder="e.g. Light tool mark on non-critical face · OK for spare / rework / discount sale"
                value={extraDefectNote}
                onChange={(e) => setExtraDefectNote(e.target.value)}
              />
              <p className="text-[11px] text-[var(--color-subtle)]">
                Stays on the Parts inventory row so anyone pulling stock sees the
                issue. Second-quality is kept separate from good stock of the
                same part #.
              </p>
            </div>
          )}
          <div className="space-y-1.5 mb-4">
            <Label>Location (optional)</Label>
            <Input
              placeholder="Shelf / bin"
              value={extraLocation}
              onChange={(e) => setExtraLocation(e.target.value)}
            />
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            <Button
              variant="secondary"
              className="flex-1"
              onClick={() => handleExtraStockDecision(false)}
            >
              No — don't stock
            </Button>
            <Button
              className="flex-1"
              onClick={() => handleExtraStockDecision(true)}
            >
              Yes — add to stock
            </Button>
          </div>
          <p className="text-xs text-[var(--color-subtle)] mt-3">
            Stocked extras show under Inventory → Parts. Each part gets a short
            UIN to write on with a sharpie so notes can be matched later.
          </p>
        </Modal>
      )}

      {uinWriteOpen && (
        <Modal title="Write UIN on each part" onClose={confirmUinsWritten}>
          <p className="text-sm text-[var(--color-muted)] mb-3 leading-relaxed">
            Mark each physical part with a{" "}
            <strong className="text-[var(--color-fg)]">sharpie</strong> using
            the code below. When someone pulls it off the shelf, look up the UIN
            under Inventory → Parts to see quality and defect notes.
          </p>
          <div className="space-y-2 mb-4">
            {extraUins.map((code, i) => (
              <div
                key={code}
                className="rounded-[var(--radius-md)] border-2 border-[var(--color-border-strong)] bg-[var(--color-surface-2)] px-4 py-3 flex items-center justify-between gap-3"
              >
                <span className="text-xs text-[var(--color-muted)]">
                  Part {i + 1} of {extraUins.length}
                </span>
                <span className="font-mono text-3xl sm:text-4xl font-bold tracking-[0.2em] text-[var(--color-fg)]">
                  {code}
                </span>
              </div>
            ))}
          </div>
          {extraQuality === "second" && extraDefectNote.trim() ? (
            <div className="rounded-[var(--radius-md)] border border-[var(--color-warn)]/50 bg-[color-mix(in_oklab,var(--color-warn)_10%,transparent)] px-3 py-2 text-sm mb-4">
              <div className="text-xs font-semibold text-[var(--color-warn)] mb-0.5">
                Defect note saved with each UIN
              </div>
              {extraDefectNote.trim()}
            </div>
          ) : null}
          <Button className="w-full" onClick={confirmUinsWritten}>
            Done — UINs written on parts
          </Button>
        </Modal>
      )}

    </div>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-3 border-b border-[var(--color-border)] pb-2">
      <span className="text-[var(--color-muted)]">{label}</span>
      <span className="font-medium text-right truncate">{value}</span>
    </div>
  );
}

function Modal({
  title,
  children,
  onClose,
  wide,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-4"
      onClick={onClose}
    >
      <div
        className={`w-full ${wide ? "max-w-lg" : "max-w-md"} max-h-[90vh] overflow-y-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 shadow-xl`}
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-lg font-semibold mb-3">{title}</h2>
        {children}
      </div>
    </div>
  );
}
