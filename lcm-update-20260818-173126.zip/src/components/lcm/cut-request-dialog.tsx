import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { SmartNumberInput } from "@/components/ui/smart-number-input";
import { useLcmStore } from "@/store/lcm-store";
import type { CutProcess, LocAxis, MaterialStock } from "@/lib/lcm/types";
import { cutTicketLabel, locValueFromDims } from "@/lib/lcm/cut-tickets";
import { materialLabel } from "@/lib/lcm/inventory";
import { canonicalizeShape } from "@/lib/lcm/stock-standard";

type Props = {
  open: boolean;
  onClose: () => void;
  orderId: string;
  lineId: string;
  componentId?: string;
  byName: string;
  machine?: string;
};

function norm(s: string) {
  return (s || "").trim().toLowerCase();
}

function rankStockForCut(
  stock: MaterialStock[],
  want: {
    material?: string;
    materialType?: string;
    stockShape?: string;
    locValue: number;
    qty: number;
    dimX: number;
    dimY: number;
    dimZ: number;
    diameter: number;
  },
): { row: MaterialStock; suggested: boolean }[] {
  const mat = norm(want.material || "");
  if (!mat) return [];
  const needIn = Math.max(0, Number(want.locValue) || 0) * Math.max(1, Number(want.qty) || 1);
  const typed = [want.dimX, want.dimY, want.dimZ, want.diameter].filter((n) => n > 0);
  const hits = (stock || [])
    .filter((s) => s.onHand > 0 && norm(s.material) === mat)
    .map((row) => {
      let score = 0;
      if (want.materialType && norm(row.materialType) === norm(want.materialType))
        score += 4;
      if (
        want.stockShape &&
        canonicalizeShape(row.stockShape) === canonicalizeShape(want.stockShape)
      )
        score += 3;
      if (needIn > 0 && row.onHand + 0.01 >= needIn) score += 5;
      if (typed.length) {
        const nums = [row.dimX, row.dimY, row.dimZ].filter((n) => n > 0);
        const close = typed.some((t) =>
          nums.some((n) => Math.abs(n - t) <= 0.05),
        );
        if (close) score += 2;
        const note = (row.sizeNote || "").toLowerCase();
        if (typed.some((t) => note.includes(String(t)))) score += 1;
      }
      return { row, score };
    })
    .sort((a, b) => b.score - a.score || b.row.onHand - a.row.onHand);
  const best = hits[0]?.score ?? 0;
  return hits.slice(0, 6).map((h, i) => ({
    row: h.row,
    suggested: i === 0 && best >= 4,
  }));
}

export function CutRequestDialog({
  open,
  onClose,
  orderId,
  lineId,
  componentId,
  byName,
  machine,
}: Props) {
  const shopOrders = useLcmStore((s) => s.shopOrders || []);
  const materialStock = useLcmStore((s) => s.materialStock || []);
  const createCutTicketFromLine = useLcmStore((s) => s.createCutTicketFromLine);

  const order = shopOrders.find((o) => o.id === orderId);
  const line = order?.lines?.find((l) => l.id === lineId);

  const [process, setProcess] = useState<CutProcess>("mill");
  const [dimX, setDimX] = useState(0);
  const [dimY, setDimY] = useState(0);
  const [dimZ, setDimZ] = useState(0);
  const [diameter, setDiameter] = useState(0);
  const [locAxis, setLocAxis] = useState<LocAxis | "">("");
  const [locValue, setLocValue] = useState(0);
  const [qty, setQty] = useState(1);
  const [notes, setNotes] = useState("");
  const [writeBack, setWriteBack] = useState(false);
  const seededKey = useRef("");

  useEffect(() => {
    if (!open) {
      seededKey.current = "";
      return;
    }
    const key = `${orderId}:${lineId}:${componentId || ""}`;
    if (seededKey.current === key) return;
    const s = useLcmStore.getState();
    const ord = (s.shopOrders || []).find((o) => o.id === orderId);
    const ln = ord?.lines?.find((l) => l.id === lineId);
    if (!ord || !ln) return;
    const m = (machine || ln.checkedOutMachine || "").toLowerCase();
    const lathe =
      m.includes("lathe") ||
      /round|bar|dia/.test((ln.stockShape || "").toLowerCase());
    seededKey.current = key;
    setProcess(lathe ? "lathe" : "mill");
    setDimX(0);
    setDimY(0);
    setDimZ(0);
    setDiameter(0);
    setLocAxis("");
    setLocValue(0);
    const leftover =
      Math.max(0, (Number(ln.qty) || 0) - (Number(ln.qtyCompleted) || 0)) ||
      Number(ln.qty) ||
      1;
    setQty(leftover);
    setNotes("");
    setWriteBack(false);
  }, [open, orderId, lineId, componentId, machine]);

  useEffect(() => {
    if (process === "lathe" || !locAxis || locAxis === "dia") return;
    const v = locValueFromDims(process, locAxis, {
      dimX,
      dimY,
      dimZ,
      diameter,
    });
    if (v > 0) setLocValue(v);
  }, [locAxis, dimX, dimY, dimZ, process, diameter]);

  const rackHits = useMemo(() => {
    if (!line) return [];
    return rankStockForCut(materialStock, {
      material: line.material,
      materialType: line.materialType,
      stockShape: line.stockShape,
      locValue,
      qty,
      dimX,
      dimY,
      dimZ,
      diameter,
    });
  }, [line, materialStock, locValue, qty, dimX, dimY, dimZ, diameter]);

  if (!open || !order || !line) return null;

  function submit() {
    if (process !== "lathe" && !locAxis) {
      toast.error("Pick which axis is LOC");
      return;
    }
    if (!(Number(locValue) > 0)) {
      toast.error("Enter LOC (length of cut)");
      return;
    }
    const r = createCutTicketFromLine({
      orderId,
      lineId,
      componentId,
      byName,
      machine,
      process,
      dimX,
      dimY,
      dimZ,
      diameter,
      locAxis: process === "lathe" ? "dia" : (locAxis as LocAxis),
      locValue,
      qtyRequested: qty,
      notes,
      writeBackToQuote: writeBack,
    });
    if (!r.ok) {
      toast.error(r.error || "Could not create ticket");
      return;
    }
    toast.success(
      `Cut ticket sent · ${r.ticket?.partNumber} · ${cutTicketLabel(r.ticket!)} · qty ${qty}`,
    );
    onClose();
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-3 print:hidden"
      role="dialog"
      aria-modal="true"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md max-h-[92vh] overflow-y-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] shadow-xl p-4 space-y-3"
        onClick={(e) => e.stopPropagation()}
      >
        <div>
          <h2 className="text-lg font-semibold">Request saw cut</h2>
          <p className="text-xs text-[var(--color-muted)] mt-0.5">
            {line.partNumber} Rev {line.revision || "—"} · type CAD actuals.
            Sizes start blank.
          </p>
        </div>

        <div className="space-y-1.5">
          <Label>On the rack</Label>
          {line.material ? (
            rackHits.length ? (
              <div className="space-y-1.5">
                {rackHits.map(({ row, suggested }) => (
                  <div
                    key={row.id}
                    className={
                      "rounded-[var(--radius-md)] border px-3 py-2 text-sm " +
                      (suggested
                        ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_10%,transparent)]"
                        : "border-[var(--color-border)]")
                    }
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="font-medium">{materialLabel(row)}</div>
                        <div className="text-xs text-[var(--color-muted)]">
                          {row.location || "no loc"} · {row.vendor || "—"}
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="tabular font-semibold">
                          {row.onHand} {row.unit}
                        </div>
                        {suggested ? (
                          <Badge tone="active" className="mt-0.5">
                            suggested
                          </Badge>
                        ) : null}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-[var(--color-warn)]">
                No {line.material} {line.materialType} on hand.
              </p>
            )
          ) : (
            <p className="text-xs text-[var(--color-muted)]">
              This line has no material — rack list needs a material on the PO.
            </p>
          )}
        </div>

        <div className="space-y-1.5">
          <Label>Process</Label>
          <Select
            value={process}
            onChange={(e) => {
              const p = e.target.value as CutProcess;
              setProcess(p);
              if (p === "lathe") setLocAxis("dia");
              else if (locAxis === "dia") setLocAxis("");
            }}
          >
            <option value="mill">Mill (X / Y / Z · pick LOC axis)</option>
            <option value="lathe">Lathe (diameter + LOC)</option>
            <option value="other">Other</option>
          </Select>
        </div>

        {process === "lathe" ? (
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Diameter</Label>
              <SmartNumberInput
                value={diameter}
                onValueChange={setDiameter}
                format="inches"
              />
            </div>
            <div className="space-y-1">
              <Label>LOC (length of cut)</Label>
              <SmartNumberInput
                value={locValue}
                onValueChange={setLocValue}
                format="inches"
              />
            </div>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-3 gap-2">
              <div className="space-y-1">
                <Label>X</Label>
                <SmartNumberInput
                  value={dimX}
                  onValueChange={setDimX}
                  format="inches"
                />
              </div>
              <div className="space-y-1">
                <Label>Y</Label>
                <SmartNumberInput
                  value={dimY}
                  onValueChange={setDimY}
                  format="inches"
                />
              </div>
              <div className="space-y-1">
                <Label>Z</Label>
                <SmartNumberInput
                  value={dimZ}
                  onValueChange={setDimZ}
                  format="inches"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>LOC is which axis?</Label>
              <div className="flex gap-2">
                {(["x", "y", "z"] as const).map((a) => (
                  <button
                    key={a}
                    type="button"
                    className={
                      "flex-1 rounded-[var(--radius-md)] border px-3 py-2.5 text-sm font-semibold min-h-11 " +
                      (locAxis === a
                        ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)]"
                        : "border-[var(--color-border)]")
                    }
                    onClick={() => setLocAxis(a)}
                  >
                    {a.toUpperCase()}
                  </button>
                ))}
              </div>
              <div className="space-y-1">
                <Label>
                  LOC value
                  {locAxis && locAxis !== "dia"
                    ? ` (from ${locAxis.toUpperCase()}, editable)`
                    : ""}
                </Label>
                <SmartNumberInput
                  value={locValue}
                  onValueChange={setLocValue}
                  format="inches"
                />
              </div>
            </div>
          </>
        )}

        <div className="space-y-1">
          <Label>Qty to cut</Label>
          <SmartNumberInput value={qty} onValueChange={setQty} format="plain" />
        </div>

        <div className="space-y-1">
          <Label>Notes for saw</Label>
          <Input
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            onFocus={(e) => e.currentTarget.select()}
            placeholder="Leave 0.05 for face, grain, etc."
          />
        </div>

        <label className="flex items-start gap-2 text-sm cursor-pointer">
          <input
            type="checkbox"
            className="mt-1"
            checked={writeBack}
            onChange={(e) => setWriteBack(e.target.checked)}
          />
          <span>
            When cut is done, write actual size back to quote recipe
            <span className="block text-[11px] text-[var(--color-muted)]">
              Size only — never changes quoted prices
            </span>
          </span>
        </label>

        <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 text-xs text-[var(--color-muted)]">
          Preview:{" "}
          <strong className="text-[var(--color-fg)]">
            {locAxis || process === "lathe"
              ? cutTicketLabel({
                  process,
                  locAxis: process === "lathe" ? "dia" : (locAxis as LocAxis),
                  locValue,
                  dimX,
                  dimY,
                  dimZ,
                  diameter,
                })
              : "pick LOC axis"}
          </strong>{" "}
          · qty {qty}
        </div>

        <div className="flex gap-2 pt-1">
          <Button type="button" className="flex-1 min-h-11" onClick={submit}>
            Send to saw
          </Button>
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
        </div>
      </div>
    </div>
  );
}
