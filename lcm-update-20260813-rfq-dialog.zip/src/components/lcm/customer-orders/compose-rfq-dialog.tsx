import { useMemo, useState } from "react";
import { Plus, Send, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { SmartNumberInput } from "@/components/ui/smart-number-input";
import type { VendorRfq, VendorRfqLine } from "@/lib/lcm/types";
import { emptyVendorRfqLine, rfqEmailBody } from "@/lib/lcm/vendor-rfq";

export function ComposeRfqDialog({
  company,
  rfqNumber,
  vendorOptions,
  initialVendors,
  initialLines,
  onCancel,
  onSend,
}: {
  company: string;
  rfqNumber: string;
  vendorOptions: string[];
  initialVendors: string[];
  initialLines: VendorRfqLine[];
  onCancel: () => void;
  onSend: (opts: { vendors: string[]; lines: VendorRfqLine[] }) => void;
}) {
  const [picked, setPicked] = useState<string[]>(
    initialVendors.length ? initialVendors : vendorOptions,
  );
  const [extraVendors, setExtraVendors] = useState<string[]>([]);
  const [newVendor, setNewVendor] = useState("");
  const [lines, setLines] = useState<VendorRfqLine[]>(
    initialLines.length ? initialLines : [emptyVendorRfqLine()],
  );

  const allVendors = useMemo(() => {
    const set = new Set(
      [...vendorOptions, ...extraVendors].map((v) => v.trim()).filter(Boolean),
    );
    return [...set].sort((a, b) => a.localeCompare(b));
  }, [vendorOptions, extraVendors]);

  const draft: VendorRfq = {
    id: "",
    rfqNumber,
    date: new Date().toISOString().slice(0, 10),
    neededBy: "",
    status: "draft",
    customerQuoteRef: "",
    shopOrderRef: "",
    notes: "",
    lines,
    vendorsRequested: picked,
    bids: [],
    awardedBidId: "",
    purchaseOrderId: "",
    createdAt: "",
    updatedAt: "",
    createdBy: "",
  };
  const preview = rfqEmailBody({ companyName: company, rfq: draft });

  function patchLine(id: string, patch: Partial<VendorRfqLine>) {
    setLines((prev) => prev.map((l) => (l.id === id ? { ...l, ...patch } : l)));
  }

  function toggleVendor(name: string) {
    setPicked((prev) =>
      prev.includes(name) ? prev.filter((v) => v !== name) : [...prev, name],
    );
  }

  function addVendor() {
    const name = newVendor.trim();
    if (!name) return;
    setExtraVendors((prev) => (prev.includes(name) ? prev : [...prev, name]));
    setPicked((prev) => (prev.includes(name) ? prev : [...prev, name]));
    setNewVendor("");
  }

  return (
    <div
      className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-black/60 p-4 print:hidden"
      onClick={onCancel}
    >
      <div
        className="relative z-[71] w-full max-w-2xl max-h-[92vh] overflow-y-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 space-y-4 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div>
          <h2 className="text-lg font-semibold">Send RFQ · {rfqNumber}</h2>
          <p className="text-sm text-[var(--color-muted)]">
            Pick vendors and fix the lines. Then send — the email stays
            plain so they can quote it.
          </p>
        </div>

        <div className="space-y-2">
          <Label>Vendors</Label>
          {allVendors.length === 0 && (
            <p className="text-sm text-[var(--color-muted)]">
              No vendors on file yet — type one below.
            </p>
          )}
          <div className="flex flex-wrap gap-2">
            {allVendors.map((name) => {
              const on = picked.includes(name);
              return (
                <button
                  key={name}
                  type="button"
                  onClick={() => toggleVendor(name)}
                  className={
                    "min-h-10 rounded-md border px-3 text-sm " +
                    (on
                      ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_18%,transparent)] text-[var(--color-fg)]"
                      : "border-[var(--color-border)] text-[var(--color-muted)]")
                  }
                >
                  {on ? "✓ " : ""}
                  {name}
                </button>
              );
            })}
          </div>
          <div className="flex gap-2">
            <Input
              value={newVendor}
              placeholder="Add a vendor"
              onChange={(e) => setNewVendor(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  addVendor();
                }
              }}
            />
            <Button type="button" variant="secondary" onClick={addVendor}>
              <Plus className="h-4 w-4" />
              Add
            </Button>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between gap-2">
            <Label>Lines</Label>
            <Button
              type="button"
              variant="ghost"
              onClick={() =>
                setLines((prev) => [...prev, emptyVendorRfqLine()])
              }
            >
              <Plus className="h-4 w-4" />
              Line
            </Button>
          </div>
          <div className="space-y-3">
            {lines.map((l, i) => (
              <div
                key={l.id}
                className="rounded-md border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-2"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-[var(--color-muted)]">
                    {i + 1}.
                  </span>
                  {lines.length > 1 && (
                    <button
                      type="button"
                      className="text-[var(--color-muted)] hover:text-[var(--color-danger)]"
                      title="Remove line"
                      onClick={() =>
                        setLines((prev) => prev.filter((x) => x.id !== l.id))
                      }
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
                <div className="grid sm:grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <Label className="text-[10px]">Material</Label>
                    <Input
                      value={l.material}
                      onChange={(e) =>
                        patchLine(l.id, { material: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-[10px]">Type</Label>
                    <Input
                      value={l.materialType}
                      onChange={(e) =>
                        patchLine(l.id, { materialType: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-[10px]">Shape</Label>
                    <Input
                      value={l.stockShape}
                      onChange={(e) =>
                        patchLine(l.id, { stockShape: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-[10px]">Size</Label>
                    <Input
                      value={l.sizeNote}
                      onChange={(e) =>
                        patchLine(l.id, { sizeNote: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-[10px]">Qty</Label>
                    <SmartNumberInput
                      value={l.qty}
                      onValueChange={(qty) => patchLine(l.id, { qty })}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-[10px]">Unit</Label>
                    <Input
                      value={l.unit}
                      onChange={(e) =>
                        patchLine(l.id, {
                          unit: e.target.value as VendorRfqLine["unit"],
                        })
                      }
                    />
                  </div>
                  <div className="space-y-1 sm:col-span-2">
                    <Label className="text-[10px]">Part</Label>
                    <Input
                      value={l.partNumber}
                      onChange={(e) =>
                        patchLine(l.id, { partNumber: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-1 sm:col-span-2">
                    <Label className="text-[10px]">Note</Label>
                    <Input
                      value={l.notes}
                      onChange={(e) =>
                        patchLine(l.id, { notes: e.target.value })
                      }
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-1">
          <Label>Email they will see</Label>
          <pre className="whitespace-pre-wrap rounded-md border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 text-sm font-sans text-[var(--color-fg)]">
            {preview}
          </pre>
        </div>

        <div className="flex flex-wrap justify-end gap-2">
          <Button variant="ghost" type="button" onClick={onCancel}>
            Cancel
          </Button>
          <Button
            type="button"
            onClick={() => {
              if (!picked.length) {
                toast.error("Pick at least one vendor");
                return;
              }
              if (!lines.some((l) => l.material.trim())) {
                toast.error("Need at least one material line");
                return;
              }
              onSend({
                vendors: picked,
                lines: lines.filter((l) => l.material.trim()),
              });
            }}
          >
            <Send className="h-4 w-4" />
            Send RFQ
          </Button>
        </div>
      </div>
    </div>
  );
}
