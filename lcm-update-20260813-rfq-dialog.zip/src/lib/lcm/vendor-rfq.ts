import type {
  PoLine,
  PurchaseOrder,
  VendorBid,
  VendorBidLine,
  VendorRfq,
  VendorRfqLine,
} from "./types";
import { emptyPurchaseOrder } from "./po";
import { uid } from "@/lib/utils";

export function emptyVendorRfqLine(
  partial?: Partial<VendorRfqLine>,
): VendorRfqLine {
  return {
    id: partial?.id || uid(),
    material: partial?.material || "",
    materialType: partial?.materialType || "",
    stockShape: partial?.stockShape || "Round Stock",
    sizeNote: partial?.sizeNote || "",
    unit: partial?.unit || "bar",
    qty: partial?.qty ?? 1,
    lengthEach: partial?.lengthEach ?? 144,
    partNumber: partial?.partNumber || "",
    jobRef: partial?.jobRef || "",
    notes: partial?.notes || "",
  };
}

export function emptyVendorBid(partial?: Partial<VendorBid>): VendorBid {
  return {
    id: partial?.id || uid(),
    vendor: partial?.vendor || "",
    vendorQuoteNumber: partial?.vendorQuoteNumber || "",
    date: partial?.date || new Date().toISOString().slice(0, 10),
    status: partial?.status || "open",
    lines: partial?.lines || [],
    notes: partial?.notes || "",
    freight: partial?.freight ?? 0,
    validUntil: partial?.validUntil || "",
    createdAt: partial?.createdAt || new Date().toISOString(),
  };
}

export function emptyVendorRfq(partial?: Partial<VendorRfq>): VendorRfq {
  const now = new Date().toISOString();
  return {
    id: partial?.id || uid(),
    rfqNumber: partial?.rfqNumber || "",
    date: partial?.date || now.slice(0, 10),
    neededBy: partial?.neededBy || "",
    status: partial?.status || "draft",
    customerQuoteRef: partial?.customerQuoteRef || "",
    shopOrderRef: partial?.shopOrderRef || "",
    notes: partial?.notes || "",
    lines: partial?.lines || [],
    vendorsRequested: partial?.vendorsRequested || [],
    bids: partial?.bids || [],
    awardedBidId: partial?.awardedBidId || "",
    purchaseOrderId: partial?.purchaseOrderId || "",
    createdAt: partial?.createdAt || now,
    updatedAt: partial?.updatedAt || now,
    createdBy: partial?.createdBy || "",
  };
}

export function nextRfqNumber(existing: VendorRfq[]): string {
  const year = new Date().getFullYear().toString().slice(-2);
  let max = 0;
  for (const r of existing || []) {
    const m = String(r.rfqNumber || "").match(/RFQ-?(\d{2})-?(\d+)/i);
    if (m) {
      const n = Number(m[2]);
      if (Number.isFinite(n) && n > max) max = n;
    }
  }
  return `RFQ-${year}-${String(max + 1).padStart(4, "0")}`;
}

export function bidLineTotal(
  rfq: VendorRfq,
  bid: VendorBid,
): { material: number; freight: number; total: number } {
  let material = 0;
  for (const bl of bid.lines || []) {
    const line = rfq.lines.find((l) => l.id === bl.rfqLineId);
    if (!line) continue;
    material += (Number(line.qty) || 0) * (Number(bl.unitCost) || 0);
  }
  const freight = Number(bid.freight) || 0;
  return { material, freight, total: material + freight };
}

/** Build PO lines from awarded bid */
export function poLinesFromAwardedBid(
  rfq: VendorRfq,
  bid: VendorBid,
): PoLine[] {
  return (rfq.lines || []).map((line) => {
    const bl = (bid.lines || []).find((x) => x.rfqLineId === line.id);
    return {
      id: uid(),
      material: line.material,
      materialType: line.materialType,
      stockShape: line.stockShape,
      sizeNote: line.sizeNote,
      unit: line.unit,
      qtyOrdered: line.qty,
      qtyReceived: 0,
      lengthEach: line.lengthEach,
      unitCost: bl?.unitCost ?? 0,
      partNumber: line.partNumber,
      jobRef: line.jobRef || rfq.shopOrderRef || rfq.customerQuoteRef,
      notes: [line.notes, bl?.notes, `From ${rfq.rfqNumber}`]
        .filter(Boolean)
        .join(" · "),
    };
  });
}

export function purchaseOrderFromAward(opts: {
  rfq: VendorRfq;
  bid: VendorBid;
  poNumber: string;
  createdBy: string;
}): PurchaseOrder {
  const { rfq, bid, poNumber, createdBy } = opts;
  const now = new Date().toISOString();
  return emptyPurchaseOrder({
    id: uid(),
    poNumber,
    vendor: bid.vendor,
    date: now.slice(0, 10),
    status: "ordered",
    notes: [
      `Awarded from ${rfq.rfqNumber}`,
      bid.vendorQuoteNumber ? `Vendor quote ${bid.vendorQuoteNumber}` : "",
      rfq.customerQuoteRef ? `Cust quote ref ${rfq.customerQuoteRef}` : "",
      bid.notes,
      rfq.notes,
    ]
      .filter(Boolean)
      .join(" · "),
    lines: poLinesFromAwardedBid(rfq, bid),
    createdAt: now,
    updatedAt: now,
    createdBy,
  });
}

export function rfqEmailBody(opts: {
  companyName: string;
  rfq: VendorRfq;
}): string {
  const { companyName, rfq } = opts;
  const lines = ["Please quote the following:", ""];
  rfq.lines.forEach((l, i) => {
    const stock = [l.material, l.materialType, l.stockShape, l.sizeNote || ""]
      .map((s) => (s || "").trim())
      .filter(Boolean)
      .join(" · ");
    lines.push(`${i + 1}. ${stock || "Material"}`);
    const qtyBits = [
      `Qty: ${l.qty} ${l.unit}`.trim(),
      l.partNumber ? `Part ${l.partNumber}` : "",
    ].filter(Boolean);
    lines.push(`   ${qtyBits.join(" · ")}`);
    if (l.notes) lines.push(`   Note: ${l.notes}`);
    lines.push("");
  });
  lines.push("Please reply with unit price, lead time, and your quote number.");
  lines.push(`Reference our RFQ # ${rfq.rfqNumber} on your response.`);
  lines.push("");
  lines.push(`— ${companyName}`);
  return lines.filter((x, i, a) => x !== "" || a[i - 1] !== "").join("\n");
}

export function defaultBidLinesForRfq(rfq: VendorRfq): VendorBidLine[] {
  return (rfq.lines || []).map((l) => ({
    rfqLineId: l.id,
    unitCost: 0,
    leadDays: 0,
    notes: "",
  }));
}
