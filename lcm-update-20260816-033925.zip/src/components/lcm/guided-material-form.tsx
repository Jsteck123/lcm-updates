import { useId, useState, type ComponentProps } from "react";
import { Label } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { CreatableSelect } from "@/components/ui/creatable-select";
import { SmartNumberInput } from "@/components/ui/smart-number-input";
import type { LocAxis } from "@/lib/lcm/types";
import {
  axisLabels,
  canonicalizeShape,
  defaultLocAxis,
  describeStock,
  guessProcess,
  locChoices,
  locValue,
  type StockProcess,
} from "@/lib/lcm/stock-standard";
import { isSheetOrPlate } from "@/lib/lcm/stock-shapes";
import { formatSizeNote, parseShopSize } from "@/lib/lcm/po-material";
import { allMaterials, allMaterialTypes, allStockShapes } from "@/lib/lcm/lists";
import { useLcmStore } from "@/store/lcm-store";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export type GuidedMaterialValue = {
  material: string;
  materialType: string;
  stockShape: string;
  stockProcess: StockProcess;
  dimX: number;
  dimY: number;
  dimZ: number;
  locAxis: LocAxis | "";
  rawMaterialLength: number;
  partLengthEach: number;
};

export const EMPTY_GUIDED_MATERIAL: GuidedMaterialValue = {
  material: "",
  materialType: "",
  stockShape: "",
  stockProcess: "",
  dimX: 0,
  dimY: 0,
  dimZ: 0,
  locAxis: "",
  rawMaterialLength: 0,
  partLengthEach: 0,
};

/** Any screen's material row — RFQ, buy PO, job, quote. */
export type MaterialGuideStock = {
  material?: string;
  materialType?: string;
  stockShape?: string;
  sizeNote?: string;
  lengthEach?: number;
  dimX?: number;
  dimY?: number;
  dimZ?: number;
  locAxis?: string;
  stockProcess?: string;
  rawMaterialLength?: number;
  partLengthEach?: number;
};

export function guidedFromStock(row: MaterialGuideStock): GuidedMaterialValue {
  const parsed = parseShopSize({
    stockShape: row.stockShape,
    sizeNote: row.sizeNote,
    dimX: row.dimX,
    dimY: row.dimY,
    dimZ: row.dimZ,
    partLengthEach: row.partLengthEach ?? row.lengthEach,
    locAxis: row.locAxis,
  });
  const dimX = Number(row.dimX) || parsed.section[0] || 0;
  const dimY =
    Number(row.dimY) || (parsed.kind === "round" ? 0 : parsed.section[1] || 0);
  const dimZ =
    Number(row.dimZ) ||
    parsed.bar ||
    (parsed.kind === "sheet" ? parsed.section[0] || 0 : 0);
  const partLengthEach =
    Number(row.partLengthEach) || parsed.loc || Number(row.lengthEach) || 0;
  return {
    material: row.material || "",
    materialType: row.materialType || "",
    stockShape: canonicalizeShape(row.stockShape || ""),
    stockProcess: (row.stockProcess as StockProcess) || "",
    dimX,
    dimY,
    dimZ,
    locAxis: (row.locAxis as LocAxis) || "",
    rawMaterialLength: Number(row.rawMaterialLength) || parsed.bar || 0,
    partLengthEach,
  };
}

export function stockFromGuided(next: GuidedMaterialValue) {
  return {
    material: next.material,
    materialType: next.materialType,
    stockShape: canonicalizeShape(next.stockShape),
    sizeNote: formatSizeNote({
      sizeNote: "",
      dimX: next.dimX,
      dimY: next.dimY,
      dimZ: next.dimZ,
      stockShape: next.stockShape,
    }),
    lengthEach: next.partLengthEach || next.rawMaterialLength || next.dimZ || 0,
    dimX: next.dimX,
    dimY: next.dimY,
    dimZ: next.dimZ,
    locAxis: next.locAxis,
    stockProcess: next.stockProcess,
    rawMaterialLength: next.rawMaterialLength,
    partLengthEach: next.partLengthEach,
  };
}

export function stockSummary(row: MaterialGuideStock): string {
  if (!String(row.material || "").trim()) return "Stock not entered";
  const bits = [
    row.material,
    row.materialType,
    row.stockShape,
    row.sizeNote,
  ].filter((s) => String(s || "").trim());
  return bits.join(" · ");
}

export function GuidedMaterialForm({
  value,
  onChange,
  materialOptions,
  typeOptions,
  shapeOptions,
  onCreateMaterial,
  onCreateType,
  onCreateShape,
  machines,
  mode = "job",
}: {
  value: GuidedMaterialValue;
  onChange: (next: GuidedMaterialValue) => void;
  materialOptions: string[];
  typeOptions: string[];
  shapeOptions: string[];
  onCreateMaterial?: (name: string) => boolean | void;
  onCreateType?: (name: string) => boolean | void;
  onCreateShape?: (name: string) => boolean | void;
  machines?: string[];
  /** inventory = rack piece (no LOC). job/quote = include LOC. */
  mode?: "job" | "quote" | "inventory";
}) {
  const locGroup = useId();
  const shape = canonicalizeShape(value.stockShape);
  const process =
    value.stockProcess ||
    guessProcess({
      process: value.stockProcess,
      machines,
      stockShape: shape,
    });
  const labels = axisLabels(shape, process);
  const loc = (value.locAxis || defaultLocAxis(shape, process)) as LocAxis;
  const sheet = isSheetOrPlate(shape);
  const locIn = locValue(loc, value);
  const lathe = process === "lathe";
  const showLoc = mode !== "inventory" && !sheet;

  function patch(p: Partial<GuidedMaterialValue>) {
    const next = { ...value, ...p };
    if (p.stockShape != null) {
      next.stockShape = canonicalizeShape(p.stockShape);
    }
    if (p.stockProcess != null || p.stockShape != null) {
      const proc =
        next.stockProcess ||
        guessProcess({
          process: next.stockProcess,
          machines,
          stockShape: next.stockShape,
        });
      if (proc && !next.locAxis) next.locAxis = defaultLocAxis(next.stockShape, proc);
      if (proc === "lathe") next.dimY = 0;
    }
    if (showLoc) {
      const axis = (next.locAxis || loc) as LocAxis;
      if (p.partLengthEach != null && p.partLengthEach > 0) {
        if (axis === "x") next.dimX = p.partLengthEach;
        if (axis === "y") next.dimY = p.partLengthEach;
        if (axis === "z") next.dimZ = p.partLengthEach;
      } else if (p.locAxis || p.dimX != null || p.dimY != null || p.dimZ != null) {
        const v = locValue(axis, next);
        if (v > 0 && (!(Number(value.partLengthEach) > 0) || p.locAxis)) {
          next.partLengthEach = v;
        }
      }
    }
    onChange(next);
  }

  const axes: ("x" | "y" | "z")[] = lathe ? ["x", "z"] : ["x", "y", "z"];

  return (
    <div className="space-y-3">
      <div className="grid sm:grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label>Material</Label>
          <CreatableSelect
            value={value.material}
            options={materialOptions}
            onChange={(v) =>
              patch({
                material: v,
                materialType: v !== value.material ? "" : value.materialType,
              })
            }
            onCreate={(v) => {
              if (onCreateMaterial?.(v) === false) return false;
              patch({ material: v, materialType: "" });
              return true;
            }}
            createTitle="Add material"
          />
        </div>
        <div className="space-y-1.5">
          <Label>Material type</Label>
          <CreatableSelect
            value={value.materialType}
            options={typeOptions}
            onChange={(v) => patch({ materialType: v })}
            onCreate={(v) => {
              if (onCreateType?.(v) === false) return false;
              patch({ materialType: v });
              return true;
            }}
            createTitle="Add type"
          />
        </div>
      </div>

      <div className="space-y-1.5">
        <Label>Stock shape</Label>
        <CreatableSelect
          value={shape}
          options={shapeOptions}
          onChange={(v) => patch({ stockShape: v })}
          onCreate={(v) => {
            if (onCreateShape?.(v) === false) return false;
            patch({ stockShape: v });
            return true;
          }}
          createTitle="Add shape"
        />
      </div>

      <div className="space-y-1.5">
        <Label>How it sits</Label>
        <div className="grid grid-cols-2 gap-2">
          {(
            [
              ["mill", "Mill — X Y Z in the vise"],
              ["lathe", "Lathe — X diameter, Z length"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              className={cn(
                "min-h-11 rounded-[var(--radius-md)] border px-3 py-2 text-sm text-left",
                process === id
                  ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_10%,transparent)]"
                  : "border-[var(--color-border)]",
              )}
              onClick={() =>
                patch({
                  stockProcess: id,
                  locAxis: id === "lathe" ? "z" : value.locAxis || "z",
                })
              }
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-2">
        <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">
          Size in the machine
        </div>
        <p className="text-[11px] text-[var(--color-muted)] leading-snug">
          These numbers are the{" "}
          <strong className="text-[var(--color-fg)]">stock blank</strong> as it
          sits in the machine. The highlighted axis is LOC — the one the saw
          cuts.
          {lathe
            ? " Lathe: X is diameter (stays stock). Z is length of cut."
            : " Mill: pick which axis is the cut. The other faces stay stock."}
        </p>
        <div className={lathe ? "grid grid-cols-2 gap-2" : "grid grid-cols-3 gap-2"}>
          {axes.map((axis) => {
            const key = axis === "x" ? "dimX" : axis === "y" ? "dimY" : "dimZ";
            const isLoc = showLoc && loc === axis;
            return (
              <div key={axis} className="space-y-1">
                <Label className="text-[10px] leading-tight">{labels[axis]}</Label>
                <SmartNumberInput
                  format="inches"
                  value={Number(value[key]) || 0}
                  placeholder="—"
                  className={cn(isLoc && "ring-1 ring-[var(--color-primary)]")}
                  onValueChange={(n) => patch({ [key]: n })}
                />
              </div>
            );
          })}
        </div>
      </div>

      {showLoc && (
        <div className="space-y-1.5">
          <Label>LOC — length of cut</Label>
          <p className="text-[11px] text-[var(--color-muted)] leading-snug">
            The axis being sawed, and how long that cut is. If the model is 3",
            cut 3.1" so you can machine .05" off each end. Do not pick an axis
            that must stay stock (a model surface).
          </p>
          {!lathe && (
            <div className="grid gap-1.5">
              {locChoices(shape, process).map((c) => (
                <label
                  key={c.axis}
                  className={cn(
                    "flex items-start gap-2 rounded-[var(--radius-md)] border px-2.5 py-2 text-sm min-h-11 cursor-pointer",
                    loc === c.axis
                      ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_10%,transparent)]"
                      : "border-[var(--color-border)]",
                  )}
                >
                  <input
                    type="radio"
                    className="mt-1"
                    name={locGroup}
                    checked={loc === c.axis}
                    onChange={() =>
                      patch({
                        locAxis: c.axis,
                        partLengthEach: locValue(c.axis, value) || value.partLengthEach,
                      })
                    }
                  />
                  <span>{c.label}</span>
                </label>
              ))}
            </div>
          )}
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <Label className="text-[10px]">
                Length of cut {loc && loc !== "dia" ? `(${loc.toUpperCase()})` : ""} "
              </Label>
              <SmartNumberInput
                format="inches"
                value={value.partLengthEach || locIn || 0}
                placeholder="e.g. 3.1"
                onValueChange={(partLengthEach) => patch({ partLengthEach })}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-[10px]">Full bar on the rack (")</Label>
              <SmartNumberInput
                format="inches"
                value={value.rawMaterialLength || 0}
                placeholder="144"
                onValueChange={(rawMaterialLength) =>
                  patch({ rawMaterialLength })
                }
              />
            </div>
          </div>
        </div>
      )}

      <p className="text-xs rounded-[var(--radius-md)] border border-[var(--color-border)] px-2.5 py-2">
        {describeStock({
          ...value,
          locAxis: loc,
          stockProcess: process,
        }) || "Fill material, shape, and size."}
      </p>
    </div>
  );
}

export function GuidedMaterialDialog({
  open,
  title,
  hint,
  value,
  onChange,
  onClose,
  onDone,
  ...formProps
}: {
  open: boolean;
  title: string;
  hint?: string;
  value: GuidedMaterialValue;
  onChange: (next: GuidedMaterialValue) => void;
  onClose: () => void;
  onDone?: () => void;
} & Omit<ComponentProps<typeof GuidedMaterialForm>, "value" | "onChange">) {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[80] flex items-end sm:items-center justify-center bg-black/60 p-3 sm:p-4 print:hidden"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg max-h-[92vh] overflow-y-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 space-y-3 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div>
          <h2 className="text-lg font-semibold">{title}</h2>
          {hint ? (
            <p className="text-sm text-[var(--color-muted)] mt-1">{hint}</p>
          ) : null}
        </div>
        <GuidedMaterialForm value={value} onChange={onChange} {...formProps} />
        <div className="flex justify-end gap-2 pt-1">
          <Button type="button" variant="ghost" onClick={onClose}>
            Close
          </Button>
          <Button
            type="button"
            onClick={() => {
              onDone?.();
              onClose();
            }}
          >
            Done
          </Button>
        </div>
      </div>
    </div>
  );
}

const GUIDE_HINT =
  "Same mill / lathe layout on every screen. LOC is length of cut — the saw axis (model 3\", cut 3.1\").";

/**
 * Compact stock row + the shop-wide guided popup.
 * Use this anywhere someone would otherwise type material freehand.
 */
export function MaterialGuideField({
  stock,
  onApply,
  title = "Enter stock",
  hint = GUIDE_HINT,
  mode = "job",
  machines,
  autoOpen = false,
}: {
  stock: MaterialGuideStock;
  onApply: (next: ReturnType<typeof stockFromGuided>) => void;
  title?: string;
  hint?: string;
  mode?: "job" | "quote" | "inventory";
  machines?: string[];
  autoOpen?: boolean;
}) {
  const customLists = useLcmStore((s) => s.settings.customLists);
  const addCustomListItem = useLcmStore((s) => s.addCustomListItem);
  const [open, setOpen] = useState(autoOpen);
  const [draft, setDraft] = useState(() => guidedFromStock(stock));

  const materialOptions = allMaterials(customLists);
  const typeOptions = allMaterialTypes(
    draft.material || stock.material || "Aluminum",
    customLists,
  );
  const shapeOptions = allStockShapes(customLists);

  function openGuide() {
    setDraft(guidedFromStock(stock));
    setOpen(true);
  }

  function apply(next: GuidedMaterialValue) {
    setDraft(next);
    onApply(stockFromGuided(next));
  }

  return (
    <div className="space-y-1.5">
      <Label>Stock</Label>
      <div className="flex items-center justify-between gap-2 rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 min-h-11">
        <p className="text-sm leading-snug min-w-0">
          {stockSummary(stock)}
        </p>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="shrink-0"
          onClick={openGuide}
        >
          {stock.material ? "Edit stock" : "Enter stock"}
        </Button>
      </div>
      <GuidedMaterialDialog
        open={open}
        title={title}
        hint={hint}
        value={draft}
        onChange={apply}
        onClose={() => setOpen(false)}
        mode={mode}
        machines={machines}
        materialOptions={materialOptions}
        typeOptions={typeOptions}
        shapeOptions={shapeOptions}
        onCreateMaterial={(v) => {
          const r = addCustomListItem("materials", v);
          if (!r.ok) {
            toast.error(r.error || "Could not add material");
            return false;
          }
          toast.success(`Added material ${v}`);
        }}
        onCreateType={(v) => {
          const mat = draft.material || stock.material;
          if (!mat) {
            toast.error("Set material first");
            return false;
          }
          const r = addCustomListItem("materialTypes", v, mat);
          if (!r.ok) {
            toast.error(r.error || "Could not add type");
            return false;
          }
          toast.success(`Added ${v}`);
        }}
        onCreateShape={(v) => {
          const r = addCustomListItem("stockShapes", v);
          if (!r.ok) {
            toast.error(r.error || "Could not add shape");
            return false;
          }
          toast.success(`Added shape ${v}`);
        }}
      />
    </div>
  );
}
