#!/usr/bin/env node
/**
 * Pull the last shipped program from GitHub (not the USB).
 *
 *   node scripts/restore-from-github-latest.mjs
 *     → downloads zip to artifacts/lcm-github-latest.zip and lists it
 *   node scripts/restore-from-github-latest.mjs src/routes/board.tsx
 *     → copies that one file from the zip over this workspace
 *
 * Shop data is not in the zip. Do not use USB for this.
 */
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

const root = process.cwd();
const url =
  "https://github.com/Jsteck123/lcm-updates/raw/main/lcm-update-latest.zip";
const zipPath = path.join(root, "artifacts", "lcm-github-latest.zip");
const extract = path.join(root, "artifacts", "lcm-github-latest");

fs.mkdirSync(path.dirname(zipPath), { recursive: true });
const curl = spawnSync("curl", ["-fsSL", "-o", zipPath, url], { encoding: "utf8" });
if (curl.status !== 0) {
  console.error("Could not download GitHub latest:", curl.stderr || curl.stdout);
  process.exit(1);
}

fs.rmSync(extract, { recursive: true, force: true });
fs.mkdirSync(extract, { recursive: true });
const unzip = spawnSync("unzip", ["-q", "-o", zipPath, "-d", extract], {
  encoding: "utf8",
});
if (unzip.status !== 0) {
  console.error("Could not unzip:", unzip.stderr || unzip.stdout);
  process.exit(1);
}

const rel = process.argv[2];
if (!rel) {
  console.log(
    JSON.stringify(
      { ok: true, zip: zipPath, extracted: extract, hint: "pass a path to restore one file" },
      null,
      2,
    ),
  );
  process.exit(0);
}

const from = path.join(extract, rel);
const to = path.join(root, rel);
if (!fs.existsSync(from)) {
  console.error("Not in GitHub latest zip:", rel);
  process.exit(1);
}
fs.mkdirSync(path.dirname(to), { recursive: true });
fs.copyFileSync(from, to);
console.log(JSON.stringify({ ok: true, restored: rel, from: url }, null, 2));
