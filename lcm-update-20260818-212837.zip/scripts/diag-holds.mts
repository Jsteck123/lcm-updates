import { readFileSync } from "node:fs";
import { normalizeComponents } from "../src/lib/lcm/line-files.ts";
import type { ShopOrder } from "../src/lib/lcm/types.ts";

const raw = JSON.parse(readFileSync("data/lcm-shop.json", "utf8"));
const orders: ShopOrder[] = raw?.state?.shopOrders || raw?.shopOrders || [];

type Row = {
  po: string;
  pn: string;
  kind: string;
  office: string;
  checkout: string;
  officeMach: string;
  checkMach: string;
  complete: boolean;
  pack: boolean;
};
const rows: Row[] = [];
for (const o of orders) {
  for (const line of o.lines || []) {
    const comps = normalizeComponents(line);
    if (comps.length) {
      for (const c of comps) {
        rows.push({
          po: o.poNumber,
          pn: c.partNumber,
          kind: "comp",
          office: c.officeAssignedTo || "",
          checkout: c.checkedOutBy || "",
          officeMach: c.officeAssignedMachine || "",
          checkMach: c.checkedOutMachine || "",
          complete: Boolean(c.complete),
          pack: Boolean(line.readyForPack || line.linePacked),
        });
      }
    }
    rows.push({
      po: o.poNumber,
      pn: line.partNumber,
      kind: "line",
      office: line.officeAssignedTo || "",
      checkout: line.checkedOutBy || "",
      officeMach: line.officeAssignedMachine || "",
      checkMach: line.checkedOutMachine || "",
      complete: Boolean(line.readyForPack),
      pack: Boolean(line.readyForPack || line.linePacked),
    });
  }
}

const held = rows.filter((r) => r.office || r.checkout);
const officeOnly = held.filter((r) => r.office && !r.checkout);
const checkOnly = held.filter((r) => r.checkout && !r.office);
const both = held.filter((r) => r.office && r.checkout);
const mismatch = held.filter(
  (r) => r.office && r.checkout && r.office.toLowerCase() !== r.checkout.toLowerCase(),
);
console.log(
  JSON.stringify(
    {
      held: held.length,
      officeOnly: officeOnly.length,
      checkOnly: checkOnly.length,
      both: both.length,
      mismatch,
      officeOnlySample: officeOnly.slice(0, 20),
      bothSample: both.slice(0, 8),
    },
    null,
    2,
  ),
);
