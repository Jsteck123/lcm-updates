#!/usr/bin/env node
/**
 * Copy the live program (src + scripts + configs) to artifacts/lcm-live-src.
 * That snapshot is newer than any USB backup. If a file is destroyed,
 * restore from here — never from the old USB zip.
 *
 *   node scripts/snapshot-live-src.mjs
 *   node scripts/snapshot-live-src.mjs restore src/routes/board.tsx
 */
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const dest = path.join(root, "artifacts", "lcm-live-src");
const INCLUDE = [
  "src",
  "scripts",
  "package.json",
  "package-lock.json",
  "vite.config.ts",
  "tsconfig.json",
  "startup.sh",
  "eslint.config.mjs",
  ".prettierrc",
  "HOW-TO-UPDATE.txt",
];

function copyRecursive(src, out) {
  const st = fs.statSync(src);
  if (st.isDirectory()) {
    fs.mkdirSync(out, { recursive: true });
    for (const name of fs.readdirSync(src)) {
      if (name === "node_modules" || name === ".git" || name === "data") continue;
      copyRecursive(path.join(src, name), path.join(out, name));
    }
    return;
  }
  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.copyFileSync(src, out);
}

const cmd = process.argv[2] || "save";

if (cmd === "restore") {
  const rel = process.argv[3];
  if (!rel) {
    console.error("Usage: node scripts/snapshot-live-src.mjs restore <relative-path>");
    process.exit(1);
  }
  const from = path.join(dest, rel);
  const to = path.join(root, rel);
  if (!fs.existsSync(from)) {
    console.error("Not in live snapshot:", rel);
    process.exit(1);
  }
  copyRecursive(from, to);
  console.log(JSON.stringify({ ok: true, restored: rel, from: dest }, null, 2));
  process.exit(0);
}

fs.rmSync(dest, { recursive: true, force: true });
fs.mkdirSync(dest, { recursive: true });
for (const rel of INCLUDE) {
  const abs = path.join(root, rel);
  if (!fs.existsSync(abs)) continue;
  copyRecursive(abs, path.join(dest, rel));
}
const n = (function count(dir) {
  if (!fs.existsSync(dir)) return 0;
  let c = 0;
  for (const name of fs.readdirSync(dir)) {
    const p = path.join(dir, name);
    c += fs.statSync(p).isDirectory() ? count(p) : 1;
  }
  return c;
})(path.join(dest, "src"));
const stamp = new Date().toISOString();
fs.writeFileSync(
  path.join(dest, "SNAPSHOT.json"),
  JSON.stringify(
    {
      createdAt: stamp,
      srcFiles: n,
      note: "Live program snapshot. Newer than USB. Restore files from here, never from the USB zip.",
    },
    null,
    2,
  ),
);
console.log(JSON.stringify({ ok: true, dest, srcFiles: n, createdAt: stamp }, null, 2));
