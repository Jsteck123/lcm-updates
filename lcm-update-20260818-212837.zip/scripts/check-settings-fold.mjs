import { mkdirSync } from "node:fs";
import { chromium } from "playwright";

const base = "http://127.0.0.1:8080";
mkdirSync("/workspace/screenshots", { recursive: true });

const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
const page = await browser.newPage({ viewport: { width: 1400, height: 900 } });
const errors = [];
page.on("pageerror", (err) => errors.push(String(err?.message || err)));

async function dismiss() {
  const pin = page.locator("#switch-pin");
  if (await pin.count()) {
    await pin.fill("6283");
    await page.getByRole("button", { name: /^Unlock$/ }).click();
    await page.waitForTimeout(600);
  }
  await page.evaluate(() => {
    document.querySelectorAll(".fixed.inset-0.z-50").forEach((el) => el.remove());
  });
}

await page.goto(`${base}/settings`, { waitUntil: "networkidle", timeout: 45000 });
await dismiss();
await page.waitForTimeout(800);

const titles = await page.locator("button[aria-expanded]").allTextContents();
const openBefore = await page.locator("button[aria-expanded=true]").count();
const updateZipVisibleBefore = await page.getByRole("button", { name: /Update app/ }).count();

await page.screenshot({
  path: "/workspace/screenshots/settings-collapsed.png",
  fullPage: false,
});

const updateTitle = page.locator("button[aria-expanded]").filter({ hasText: "Update app" });
await updateTitle.click();
await page.waitForTimeout(400);
const updateOpen = await updateTitle.getAttribute("aria-expanded");
const restartVisible = await page.getByRole("button", { name: /Restart LCM/ }).isVisible();

await page.screenshot({
  path: "/workspace/screenshots/settings-update-open.png",
  fullPage: false,
});

const opsTitle = page.locator("button[aria-expanded]").filter({ hasText: "Operators" });
await opsTitle.click();
await page.waitForTimeout(400);
const updateStillOpen = await updateTitle.getAttribute("aria-expanded");
const opsOpen = await opsTitle.getAttribute("aria-expanded");
const restartStill = await page.getByRole("button", { name: /Restart LCM/ }).isVisible().catch(() => false);

await page.screenshot({
  path: "/workspace/screenshots/settings-operators-open.png",
  fullPage: false,
});

await page.setViewportSize({ width: 390, height: 844 });
await page.waitForTimeout(400);
const overflow = await page.evaluate(
  () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 2,
);
await page.screenshot({
  path: "/workspace/screenshots/settings-mobile.png",
  fullPage: false,
});

console.log(
  JSON.stringify(
    {
      titleCount: titles.length,
      titles: titles.map((t) => t.replace(/\s+/g, " ").trim()).slice(0, 20),
      openBefore,
      updateOpen,
      restartVisible,
      updateStillOpen,
      opsOpen,
      restartStill,
      overflow,
      errors: errors.slice(0, 8),
    },
    null,
    2,
  ),
);

await browser.close();
if (errors.length) process.exit(2);
if (openBefore !== 0) process.exit(3);
if (updateOpen !== "true" || !restartVisible) process.exit(4);
if (updateStillOpen !== "false" || opsOpen !== "true" || restartStill) process.exit(5);
