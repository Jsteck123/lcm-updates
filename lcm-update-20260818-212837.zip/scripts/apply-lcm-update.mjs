#!/usr/bin/env node
/**
 * Apply an LCM update zip on the shop host (Windows or Linux).
 * Does NOT need system "unzip". Safe: never touches data/.
 *
 * Usage (from the app folder):
 *   node scripts/apply-lcm-update.mjs path\to\lcm-update-XXXX.zip
 *
 * This same file is also kept at the app-folder root as apply-lcm-update.mjs
 * so APPLY-UPDATE-DOUBLE-CLICK-ME.bat can copy it into scripts/ before running.
 * Keep those two files identical — the bat overwrites scripts/ from the root copy.
 */
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// File may live in scripts/ (normal) or at app root (USB / easy-install payload).
const ROOT = path.basename(__dirname) === "scripts" ? path.resolve(__dirname, "..") : __dirname;
const APP_ID = "lcm-data-management";

const ALLOWED_PREFIXES = [
  "src/",
  "public/",
  "scripts/",
  "package.json",
  "package-lock.json",
  "vite.config.ts",
  "tsconfig.json",
  "startup.sh",
  "eslint.config.mjs",
  ".prettierrc",
  "AGENTS.project.md",
  "HOW-TO-UPDATE.txt",
];
const BLOCKED = ["data/", "node_modules/", ".git/", ".env", "attachments/", "screenshots/"];

function ensureDir(p) {
  fs.mkdirSync(p, { recursive: true });
}
function readU16(b, o) {
  return b.readUInt16LE(o);
}
function readU32(b, o) {
  return b.readUInt32LE(o);
}

function extractZipBuffer(buf, destDir) {
  if (buf.length < 22 || buf[0] !== 0x50 || buf[1] !== 0x4b) {
    throw new Error("Not a zip file");
  }
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0 && i >= buf.length - 22 - 0xffff; i--) {
    if (buf[i] === 0x50 && buf[i + 1] === 0x4b && buf[i + 2] === 0x05 && buf[i + 3] === 0x06) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new Error("Invalid zip (no EOCD)");
  const totalEntries = readU16(buf, eocd + 10);
  let cdOffset = readU32(buf, eocd + 16);
  ensureDir(destDir);
  let files = 0;
  let pos = cdOffset;
  for (let n = 0; n < totalEntries; n++) {
    if (pos + 46 > buf.length) break;
    if (buf[pos] !== 0x50 || buf[pos + 1] !== 0x4b || buf[pos + 2] !== 0x01 || buf[pos + 3] !== 0x02) {
      throw new Error(`Bad central directory at ${pos}`);
    }
    const method = readU16(buf, pos + 10);
    const compSize = readU32(buf, pos + 20);
    const nameLen = readU16(buf, pos + 28);
    const extraLen = readU16(buf, pos + 30);
    const commentLen = readU16(buf, pos + 32);
    const localHeaderOffset = readU32(buf, pos + 42);
    const name = buf.subarray(pos + 46, pos + 46 + nameLen).toString("utf8");
    pos = pos + 46 + nameLen + extraLen + commentLen;
    if (name.endsWith("/")) continue;
    const norm = name.replace(/\\/g, "/");
    if (norm.includes("..") || path.isAbsolute(norm)) continue;
    const lh = localHeaderOffset;
    const localNameLen = readU16(buf, lh + 26);
    const localExtraLen = readU16(buf, lh + 28);
    const dataStart = lh + 30 + localNameLen + localExtraLen;
    const compressed = buf.subarray(dataStart, dataStart + compSize);
    let out;
    if (method === 0) out = Buffer.from(compressed);
    else if (method === 8) out = zlib.inflateRawSync(compressed);
    else throw new Error(`Unsupported compression ${method} for ${name}`);
    const dest = path.join(destDir, ...norm.split("/"));
    ensureDir(path.dirname(dest));
    fs.writeFileSync(dest, out);
    files++;
  }
  return files;
}

function isBlocked(rel) {
  const n = rel.replace(/\\/g, "/");
  if (n.includes("..")) return true;
  return BLOCKED.some((b) => n === b.replace(/\/$/, "") || n.startsWith(b));
}
function isAllowed(rel) {
  const n = rel.replace(/\\/g, "/");
  if (isBlocked(n)) return false;
  if (/\.(zip|7z|rar|tar|gz)$/i.test(n)) return false;
  return ALLOWED_PREFIXES.some((a) =>
    a.endsWith("/") ? n === a.slice(0, -1) || n.startsWith(a) : n === a,
  );
}
function walk(dir, base = dir) {
  const out = [];
  if (!fs.existsSync(dir)) return out;
  for (const name of fs.readdirSync(dir)) {
    const abs = path.join(dir, name);
    if (fs.statSync(abs).isDirectory()) out.push(...walk(abs, base));
    else out.push(path.relative(base, abs));
  }
  return out;
}

function appendChangelog(entry) {
  const logP = path.join(ROOT, "data", "updates", "changelog.json");
  ensureDir(path.dirname(logP));
  let list = [];
  try {
    if (fs.existsSync(logP)) {
      const raw = JSON.parse(fs.readFileSync(logP, "utf8"));
      if (Array.isArray(raw)) list = raw;
    }
  } catch {
    list = [];
  }
  list = [entry, ...list.filter((x) => x.version !== entry.version)].slice(0, 40);
  fs.writeFileSync(logP, JSON.stringify(list, null, 2));
}

const zipArg = process.argv[2];
if (!zipArg) {
  console.error("Usage: node scripts/apply-lcm-update.mjs <lcm-update-*.zip>");
  process.exit(1);
}
const zipPath = path.resolve(zipArg);
if (!fs.existsSync(zipPath)) {
  console.error("Zip not found:", zipPath);
  process.exit(1);
}

const stamp = Date.now().toString(36);
const extractDir = path.join(ROOT, "data", "updates", `manual-extract-${stamp}`);
ensureDir(path.join(ROOT, "data", "updates"));
console.log("App root:", ROOT);
console.log("Zip:", zipPath);

// Safety snapshot of shop DB before replacing program files
try {
  const dataFile = path.join(ROOT, "data", "lcm-shop.json");
  if (fs.existsSync(dataFile)) {
    const backupDir = path.join(ROOT, "data", "backups");
    ensureDir(backupDir);
    const stampIso = new Date().toISOString().replace(/[:.]/g, "-");
    const dest = path.join(backupDir, `backup-${stampIso}.json`);
    const raw = fs.readFileSync(dataFile, "utf8");
    let parsed = {};
    try {
      parsed = JSON.parse(raw);
    } catch {
      parsed = { raw: true };
    }
    fs.writeFileSync(
      dest,
      JSON.stringify({
        ...parsed,
        backupMeta: {
          id: `backup-${stampIso}`,
          createdAt: new Date().toISOString(),
          label: "pre-update",
        },
      }),
    );
    console.log("Safety backup:", dest);
  }
} catch (e) {
  console.warn("Safety backup skipped:", e instanceof Error ? e.message : e);
}

console.log("Extracting…");
const count = extractZipBuffer(fs.readFileSync(zipPath), extractDir);
console.log("Extracted", count, "files");

let rootDir = extractDir;
const top = fs.readdirSync(extractDir);
if (
  top.length === 1 &&
  fs.statSync(path.join(extractDir, top[0])).isDirectory() &&
  !fs.existsSync(path.join(extractDir, "lcm-update.json"))
) {
  rootDir = path.join(extractDir, top[0]);
}

const manPath = path.join(rootDir, "lcm-update.json");
if (!fs.existsSync(manPath)) {
  console.error("Missing lcm-update.json — not an LCM update package");
  process.exit(1);
}
const manifest = JSON.parse(fs.readFileSync(manPath, "utf8"));
if (manifest.appId !== APP_ID) {
  console.error("Wrong appId:", manifest.appId);
  process.exit(1);
}

let applied = 0;
const paths = [];
for (const rel of walk(rootDir)) {
  const norm = rel.replace(/\\/g, "/");
  if (norm === "lcm-update.json") continue;
  if (!isAllowed(norm)) continue;
  const from = path.join(rootDir, rel);
  const to = path.join(ROOT, rel);
  ensureDir(path.dirname(to));
  fs.copyFileSync(from, to);
  applied++;
  paths.push(norm);
}

const installed = {
  version: manifest.version,
  appliedAt: new Date().toISOString(),
  note: manifest.note || "",
  fileName: path.basename(zipPath),
  filesUpdated: applied,
  paths: paths.slice(0, 200),
  method: "manual-script",
};
fs.writeFileSync(
  path.join(ROOT, "data", "updates", "installed.json"),
  JSON.stringify(installed, null, 2),
);
appendChangelog({
  version: installed.version,
  note: installed.note || "",
  appliedAt: installed.appliedAt,
  fileName: installed.fileName,
});

try {
  const pub = path.join(ROOT, "public");
  ensureDir(pub);
  fs.copyFileSync(zipPath, path.join(pub, "lcm-update-latest.zip"));
} catch {
  /* optional */
}

try {
  fs.rmSync(extractDir, { recursive: true, force: true });
} catch {
  /* ignore */
}

console.log(`OK — applied ${applied} files, version ${manifest.version}`);
console.log("Restart the app on this PC, then refresh every browser/phone.");
if (paths.includes("package.json") || paths.includes("package-lock.json")) {
  console.log("NOTE: package.json changed — run: npm install");
}
