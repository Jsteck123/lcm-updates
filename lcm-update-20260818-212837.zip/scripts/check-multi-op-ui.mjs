import { mkdirSync } from "node:fs";
import { chromium } from "playwright";

const base = "http://127.0.0.1:8080";
mkdirSync("/workspace/screenshots", { recursive: true });

const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
const page = await browser.newPage({ viewport: { width: 1400, height: 900 } });
const errors = [];
page.on("pageerror", (err) => errors.push(String(err?.message || err)));
page.on("console", (msg) => {
  if (msg.type() === "error") errors.push(msg.text());
});

async function unlock() {
  const pin = page.locator("#switch-pin");
  if (await pin.count()) {
    await pin.fill("6283");
    await page.getByRole("button", { name: /^Unlock$/ }).click();
    await page.waitForTimeout(800);
  }
}

await page.goto(`${base}/assign`, { waitUntil: "networkidle", timeout: 45000 });
await unlock();
await page.waitForTimeout(1200);
const assignText = await page.locator("body").innerText();
await page.screenshot({
  path: "/workspace/screenshots/assign-multi-op.png",
  fullPage: false,
});

await page.goto(`${base}/board`, { waitUntil: "networkidle", timeout: 45000 });
await page.waitForTimeout(1000);
const boardText = await page.locator("body").innerText();
await page.screenshot({
  path: "/workspace/screenshots/board-multi-op.png",
  fullPage: false,
});

await page.goto(`${base}/quoting`, { waitUntil: "networkidle", timeout: 45000 });
await page.waitForTimeout(800);
const quoteText = await page.locator("body").innerText();
await page.screenshot({
  path: "/workspace/screenshots/quoting-machine-row.png",
  fullPage: false,
});

await page.goto(`${base}/lanes`, { waitUntil: "networkidle", timeout: 45000 });
await page.waitForTimeout(800);
const lanesText = await page.locator("body").innerText();
await page.screenshot({
  path: "/workspace/screenshots/lanes-multi-op.png",
  fullPage: false,
});

await page.setViewportSize({ width: 390, height: 844 });
await page.goto(`${base}/board`, { waitUntil: "networkidle", timeout: 45000 });
await page.waitForTimeout(600);
const overflow = await page.evaluate(
  () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 2,
);
await page.screenshot({
  path: "/workspace/screenshots/board-mobile.png",
  fullPage: false,
});

console.log(
  JSON.stringify(
    {
      assignHasQueue: /Assign queue|Parts to assign/i.test(assignText),
      assignHasOp: /\bOP[1-9]\b/.test(assignText),
      boardHasCards: /Job Board|Take job|My Job/i.test(boardText),
      boardHasOp: /\bOP[1-9]\b/.test(boardText),
      quotingHasMachineRow: /Machine/.test(quoteText) && /Setup min/.test(quoteText),
      lanesOk: /Load lanes|booked/i.test(lanesText),
      mobileOverflow: overflow,
      errors: errors.slice(0, 12),
    },
    null,
    2,
  ),
);

await browser.close();
if (errors.length) process.exit(2);
