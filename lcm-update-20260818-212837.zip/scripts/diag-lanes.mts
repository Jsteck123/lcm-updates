import { readFileSync } from "node:fs";
import { collectLoadJobs } from "../src/lib/lcm/load-lanes.ts";
import { workQueueItemStillAssigned, findQueueOrderLine } from "../src/lib/lcm/queue-display.ts";
import type { Quote, ShopOrder, WorkQueueItem, MachineSession } from "../src/lib/lcm/types.ts";

const raw = JSON.parse(readFileSync("data/lcm-shop.json", "utf8"));
const state = raw?.state || raw;
const quotes: Quote[] = state.quotes || [];
const orders: ShopOrder[] = state.shopOrders || [];
const workQueue: WorkQueueItem[] = state.workQueue || [];
const sessions: Record<string, MachineSession> = state.sessions || {};

const jobs = collectLoadJobs({ shopOrders: orders, workQueue, quotes, sessions });

const qOpen = workQueue.filter((q) =>
  ["queued", "active", "held"].includes(q.status),
);
const qOrphan = qOpen.filter((q) => {
  const { order, line } = findQueueOrderLine(q, orders);
  return !order || !line;
});
const qStaleAssign = qOpen.filter((q) => !workQueueItemStillAssigned(q, orders));
const qWouldBook = qOpen.filter((q) => workQueueItemStillAssigned(q, orders));

console.log(
  JSON.stringify(
    {
      orders: orders.length,
      queue: workQueue.length,
      queueOpen: qOpen.length,
      queueOrphan: qOrphan.map((q) => ({
        id: q.id,
        pn: q.partNumber,
        op: q.operatorName,
        machine: q.machine,
        status: q.status,
        po: q.poNumber,
        orderId: q.shopOrderId,
        lineId: q.shopOrderLineId,
      })),
      queueStaleAssign: qStaleAssign.length,
      queueWouldBook: qWouldBook.map((q) => ({
        pn: q.partNumber,
        op: q.operatorName,
        machine: q.machine,
        status: q.status,
        po: q.poNumber,
        opIndex: q.opIndex,
      })),
      sessions: Object.entries(sessions)
        .filter(([, s]) => s?.partNumber)
        .map(([m, s]) => ({
          m,
          pn: s.partNumber,
          op: s.operatorName,
          focus: s.focusOpIndex,
        })),
      laneJobs: jobs.map((j) => ({
        key: j.key,
        pn: j.partNumber,
        op: j.operator,
        machine: j.machine,
        hours: j.hours,
        due: j.dueDate,
        live: j.live,
        pulled: j.pulled,
        opIndex: j.opIndex,
        po: j.poNumber,
      })),
      byOp: Object.entries(
        jobs.reduce((acc: Record<string, number>, j) => {
          acc[j.operator || "(none)"] =
            (acc[j.operator || "(none)"] || 0) + (j.hours || 0);
          return acc;
        }, {}),
      ),
    },
    null,
    2,
  ),
);
