@echo off
REM Start LCM shop app on THIS PC (port 8080). Safe to run again if already up.
setlocal EnableExtensions
cd /d "%~dp0..\.."

if not exist "data\logs" mkdir "data\logs"
if not exist "data\backups" mkdir "data\backups"
if not exist "data\po-files" mkdir "data\po-files"
if not exist "data\branding" mkdir "data\branding"

set PORT=8080
set HOST=0.0.0.0
set LCM_HMR=0
set LOG=%cd%\data\logs\host.log

curl.exe -sf -o NUL --max-time 2 http://127.0.0.1:%PORT%/ >NUL 2>&1
if %ERRORLEVEL%==0 (
  echo [lcm] Shop app already running — open http://127.0.0.1:%PORT%
  exit /b 0
)

where node >NUL 2>&1
if errorlevel 1 (
  echo [lcm] Node.js not found. Install Node 22 LTS from https://nodejs.org
  echo [lcm] Node missing %DATE% %TIME%>> "%LOG%"
  exit /b 1
)

where npm >NUL 2>&1
if errorlevel 1 (
  echo [lcm] npm not found. Reinstall Node and reopen the terminal.
  exit /b 1
)

if not exist "node_modules\" (
  echo [lcm] First-time package install...
  call npm install >> "%LOG%" 2>&1
  if errorlevel 1 (
    echo [lcm] npm install failed — see data\logs\host.log
    exit /b 1
  )
)

echo [lcm] Starting %DATE% %TIME%>> "%LOG%"
echo [lcm] Starting Lake Country Machine shop app...
echo [lcm] On this PC:     http://127.0.0.1:%PORT%
echo [lcm] On other PCs:   http://THIS-PC-IP:%PORT%
echo [lcm] Leave this window open while the shop is working.
echo.

REM Dev server is the reliable host mode for office PC (full app + live data).
REM "vite preview" expects a server layout this Vercel build does not produce.
call npm run dev >> "%LOG%" 2>&1

echo [lcm] stopped %DATE% %TIME%>> "%LOG%"
exit /b 0
