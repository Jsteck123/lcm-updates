import { pathToFileURL, fileURLToPath } from "node:url";
import { dirname, resolve as pathResolve } from "node:path";
import { existsSync } from "node:fs";

const srcRoot = pathResolve("/workspace/lcm/src");

function candidatesFor(absWithoutExt) {
  return [
    absWithoutExt,
    absWithoutExt + ".ts",
    absWithoutExt + ".tsx",
    absWithoutExt + ".js",
    pathResolve(absWithoutExt, "index.ts"),
  ];
}

export async function resolve(specifier, context, nextResolve) {
  if (specifier.startsWith("@/")) {
    const bare = specifier.slice(2);
    for (const c of candidatesFor(pathResolve(srcRoot, bare))) {
      if (existsSync(c) && !c.endsWith("/")) {
        try {
          const st = await import("node:fs").then((fs) => fs.statSync(c));
          if (st.isFile()) return { url: pathToFileURL(c).href, shortCircuit: true };
        } catch {
          /* continue */
        }
      }
    }
  }
  if (
    (specifier.startsWith("./") || specifier.startsWith("../")) &&
    context.parentURL
  ) {
    const parent = dirname(fileURLToPath(context.parentURL));
    const abs = pathResolve(parent, specifier);
    for (const c of candidatesFor(abs)) {
      if (existsSync(c)) {
        try {
          const { statSync } = await import("node:fs");
          if (statSync(c).isFile()) {
            return { url: pathToFileURL(c).href, shortCircuit: true };
          }
        } catch {
          /* continue */
        }
      }
    }
  }
  return nextResolve(specifier, context);
}
