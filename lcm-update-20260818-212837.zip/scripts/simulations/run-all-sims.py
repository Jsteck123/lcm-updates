#!/usr/bin/env python3
"""
LCM system simulations — formula edge cases + live shop-data invariants.
Stay inside this USB dump. Do not touch other projects.
"""
from __future__ import annotations

import json
import math
import os
import sys
from collections import Counter, defaultdict
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path("/workspace/lcm")
DATA = ROOT / "data" / "lcm-shop.json"
OUT = ROOT / "sim-results"
OUT.mkdir(parents=True, exist_ok=True)

FINDINGS: list[dict] = []
PASS = 0
FAIL = 0
SIMS = 0


def rec(sim: str, severity: str, title: str, detail: str, evidence=None, fix=None):
    global SIMS
    SIMS += 1
    FINDINGS.append(
        {
            "sim": sim,
            "severity": severity,
            "title": title,
            "detail": detail,
            "evidence": evidence,
            "fix": fix,
        }
    )


def ok(sim: str, title: str, detail=""):
    global PASS, SIMS
    PASS += 1
    SIMS += 1
    FINDINGS.append(
        {"sim": sim, "severity": "pass", "title": title, "detail": detail}
    )


def bad(sim: str, title: str, detail=""):
    global FAIL, SIMS
    FAIL += 1
    SIMS += 1
    FINDINGS.append(
        {"sim": sim, "severity": "fail", "title": title, "detail": detail}
    )


# ---------------------------------------------------------------------------
# Reimplement core formulas (mirrors src/lib/lcm/*.ts)
# ---------------------------------------------------------------------------

def calculate_quote_costs(
    raw_material_cost,
    total_size,
    part_size,
    material_percentage,
    machine_rate,
    calculate_material_drop,
    setup_times,
    run_times,
    quantities,
    bom_cost=0,
    bench_minutes=0,
    kind="part",
    drop_multiplier=1,
):
    machine_pct = machine_rate if machine_rate > 0 else 1
    material_with = (
        (raw_material_cost / total_size) * part_size * material_percentage
        if total_size > 0
        else 0
    )
    material_raw = (
        (raw_material_cost / total_size) * part_size if total_size > 0 else 0
    )
    sum_setup = sum(t or 0 for t in setup_times)
    sum_run = sum(t or 0 for t in run_times)
    setup_cost = sum_setup * 2
    run_cost = sum_run * 2 * machine_pct
    bench_cost = (bench_minutes or 0) * 2
    bom = bom_cost if kind == "assembly" else 0
    prices = []
    drops = []
    for i in range(6):
        qty = quantities[i] if i < len(quantities) else 0
        qty = qty or 0
        if qty > 0:
            size_used = part_size * qty
            remainder = total_size - size_used if size_used <= total_size else 0
            cost_rem = (
                (raw_material_cost / total_size) * remainder if total_size > 0 else 0
            )
            drop = cost_rem / qty
            drops.append(drop)
            base = setup_cost / qty + run_cost + material_with + bench_cost + bom
            # NOTE: live code never applies dropMultiplier
            prices.append(base + drop if calculate_material_drop else base)
        else:
            drops.append(0)
            prices.append(0)
    return {
        "materialCostWithPct": material_with,
        "materialCostRaw": material_raw,
        "setupCost": setup_cost,
        "runCost": run_cost,
        "prices": prices,
        "dropMarkups": drops,
    }


def pick_bonus(efficiency, tiers):
    for t in sorted(tiers, key=lambda x: -x["minEff"]):
        if efficiency >= t["minEff"]:
            return t["percentage"]
    return 0


def compute_job_efficiency(job):
    earned = 0
    n = max(
        len(job.get("setups") or []),
        len(job.get("runtimes") or []),
        len(job.get("quotedSetups") or []),
        len(job.get("quotedRuntimes") or []),
        6,
    )
    for i in range(n):
        setup = (job.get("setups") or [None] * n)
        run = (job.get("runtimes") or [None] * n)
        qs = (job.get("quotedSetups") or [0] * n)
        qr = (job.get("quotedRuntimes") or [0] * n)
        s = setup[i] if i < len(setup) else None
        r = run[i] if i < len(run) else None
        setup_done = s is not None and s != "STARTED" and isinstance(s, (int, float)) and s > 0
        run_done = r is not None and r != "STARTED" and isinstance(r, (int, float)) and r > 0
        if setup_done:
            earned += (qs[i] if i < len(qs) else 0 or 0) / 3600
        if run_done:
            earned += ((qr[i] if i < len(qr) else 0 or 0) / 3600) * (job.get("quantity") or 0)
    if job.get("pairTwoVise"):
        s0 = (job.get("setups") or [None])[0]
        r0 = (job.get("runtimes") or [None])[0]
        qs = job.get("quotedSetups") or []
        qr = job.get("quotedRuntimes") or []
        if isinstance(s0, (int, float)) and s0 > 0 and len(qs) > 1:
            earned += (qs[1] or 0) / 3600
        if isinstance(r0, (int, float)) and r0 > 0 and len(qr) > 1:
            earned += ((qr[1] or 0) / 3600) * (job.get("quantity") or 0)
    actual_h = (job.get("actualTime") or 0) / 3600
    if actual_h <= 0:
        return 0
    return earned / actual_h


def compute_job_bonus_as_written(job, tiers, hourly):
    """Mirrors calculations.ts computeJobBonus — includes the >1 /100 bug."""
    eff = job.get("efficiency") or 0
    if eff > 1:
        eff = eff / 100
    if eff < 0.7:
        return 0
    quoted = 0
    n = max(len(job.get("quotedSetups") or []), len(job.get("quotedRuntimes") or []))
    for i in range(n):
        quoted += (job.get("quotedSetups") or [0])[i] if i < len(job.get("quotedSetups") or []) else 0
        quoted += ((job.get("quotedRuntimes") or [0])[i] if i < len(job.get("quotedRuntimes") or []) else 0) * (
            job.get("quantity") or 0
        )
    return (quoted / 3600) * hourly * pick_bonus(eff, tiers)


def compute_session_bonus(eff, quoted_setups, quoted_runtimes, qty, tiers, hourly):
    if eff < 0.7:
        return 0
    quoted = 0
    n = max(len(quoted_setups), len(quoted_runtimes))
    for i in range(n):
        quoted += quoted_setups[i] if i < len(quoted_setups) else 0
        quoted += (quoted_runtimes[i] if i < len(quoted_runtimes) else 0) * qty
    return (quoted / 3600) * hourly * pick_bonus(eff, tiers)


def apply_qty(on_hand, kind, qty):
    q = abs(float(qty) or 0)
    if kind in ("receive", "return"):
        return on_hand + q
    if kind in ("issue", "scrap"):
        return on_hand - q
    if kind == "adjust":
        return on_hand + (float(qty) or 0)
    return on_hand


def derive_cut_status(t):
    if t.get("status") in ("cancelled", "skipped"):
        return t["status"]
    req = t.get("qtyRequested") or 0
    cut = t.get("qtyCut") or 0
    if cut <= 0:
        return "requested"
    if req > 0 and cut >= req:
        return "done"
    if cut > 0 and cut < req:
        return "partial"
    return "partial" if t.get("status") != "cutting" else "cutting"


def shop_line_open(line):
    if line.get("lineStatus") == "cancelled":
        return 0
    return max(0, (line.get("qty") or 0) - (line.get("qtyCompleted") or 0))


def line_released(line):
    if not line.get("revPdfOk") or not line.get("stockNoted"):
        return False
    has_cad = bool(line.get("cadFileId") or (line.get("cadFiles") or []))
    if has_cad and not line.get("revCadOk"):
        return False
    return True


def sales_order_totals(lines, tax_rate=0.0825):
    subtotal = sum(l["amount"] for l in lines)
    taxable = sum(l["amount"] for l in lines if l.get("taxable"))
    base = taxable if taxable > 0 else subtotal
    tax = round(base * tax_rate * 100) / 100
    total = round((subtotal + tax) * 100) / 100
    return {"subtotal": subtotal, "tax": tax, "total": total, "taxBase": base}


def three_way_merge_value(base, local, remote):
    if local == remote:
        return local if local is not None else remote
    if local == base:
        return remote
    if remote == base:
        return local
    return local if local is not None else remote


def merge_by_id(base, local, remote):
    b = {x["id"]: x for x in (base or []) if x.get("id")}
    l = {x["id"]: x for x in (local or []) if x.get("id")}
    r = {x["id"]: x for x in (remote or []) if x.get("id")}
    order = list(r.keys()) + [i for i in l if i not in r]
    out = []
    for i in order:
        bb, ll, rr = b.get(i), l.get(i), r.get(i)
        if ll and rr:
            if ll == rr:
                out.append(ll)
            elif bb and ll == bb:
                out.append(rr)
            elif bb and rr == bb:
                out.append(ll)
            else:
                out.append(ll)  # conflict → local wins at item level for this sim
        elif ll and not rr:
            if not bb or ll != bb:
                out.append(ll)
        elif rr and not ll:
            if not bb or rr != bb:
                out.append(rr)
    return out


def shift_hours_required(start, end, lunch=1):
    def hh(s):
        h, m = (s or "0:0").split(":")
        return int(h) + int(m) / 60

    a, b = hh(start), hh(end)
    if b <= a:
        b += 24
    window = max(0.5, b - a)
    return max(0.5, window - max(0, lunch))


def overlap_hours(a0, a1, w0, w1):
    s = max(a0, w0)
    e = min(a1, w1)
    return max(0, (e - s) / 3600000)


# ---------------------------------------------------------------------------
# Simulations
# ---------------------------------------------------------------------------

def sim_quote_formulas():
    # Happy path: 12" bar, $24, 3" part, 25% mat markup, 2 ops
    r = calculate_quote_costs(
        raw_material_cost=24,
        total_size=12,
        part_size=3,
        material_percentage=1.25,
        machine_rate=1,
        calculate_material_drop=False,
        setup_times=[15, 10],
        run_times=[5, 2],
        quantities=[1, 4, 10, 0, 0, 0],
    )
    # setup $50, run $14, mat = (24/12)*3*1.25 = 7.5
    # qty1: 50+14+7.5=71.5
    # qty4: 50/4+14+7.5=34
    if abs(r["prices"][0] - 71.5) < 1e-9 and abs(r["prices"][1] - 34) < 1e-9:
        ok("quote", "Standard bar quote prices", f"{r['prices'][:3]}")
    else:
        bad("quote", "Standard bar quote prices", str(r))

    # machineRate 0 is coerced to 1 — cannot quote $0 machine
    r0 = calculate_quote_costs(24, 12, 3, 1, 0, False, [10], [5], [1, 0, 0, 0, 0, 0])
    r1 = calculate_quote_costs(24, 12, 3, 1, 1, False, [10], [5], [1, 0, 0, 0, 0, 0])
    if r0["runCost"] == r1["runCost"]:
        rec(
            "quote",
            "high",
            "machineRate of 0 is treated as 1.0",
            "calculations.ts uses `machineRate > 0 ? machineRate : 1`. "
            "A zero or missing rate silently bills full $2/min. Cannot quote a no-machine / bench-only job at $0 run.",
            {"runCost0": r0["runCost"], "runCost1": r1["runCost"]},
            "Treat missing as 1, but honor an explicit 0. Distinguish undefined vs 0.",
        )
    else:
        ok("quote", "machineRate 0 honored")

    # Drop markup: leftover of one bar split across qty. Extra bars not costed.
    rd = calculate_quote_costs(24, 12, 3, 1, 1, True, [0], [0], [1, 4, 5, 0, 0, 0])
    # qty1: used 3, rem 9, remCost=18, drop=18, mat=6, total=24 (whole bar on 1 pc)
    # qty4: used 12, rem 0, drop=0, mat=6, total=6
    # qty5: used 15 > 12, rem forced 0 — second bar free
    rec(
        "quote",
        "high",
        "Material drop ignores extra bars when qty*partSize > bar length",
        "If 5 parts × 3\" need 15\" from a 12\" bar, remainder is set to 0. "
        "Customer is not charged for the second stick. dropMultiplier is stored on every quote but never applied.",
        {
            "qty1": rd["prices"][0],
            "qty4": rd["prices"][1],
            "qty5_over_bar": rd["prices"][2],
            "dropMarkups": rd["dropMarkups"],
        },
        "Cost ceil(sizeUsed/totalSize) bars. Apply dropMultiplier. Do not zero remainder when over one bar.",
    )

    # Negative / NaN inputs
    rn = calculate_quote_costs(-10, 12, 3, 1, 1, False, [-5], [2], [1, 0, 0, 0, 0, 0])
    if rn["prices"][0] < 0:
        rec(
            "quote",
            "medium",
            "Negative material or setup times produce negative prices",
            f"price[0]={rn['prices'][0]}. No clamp on rawMaterialCost, times, or qty.",
            rn,
            "Clamp costs/times/qty to >= 0 before pricing.",
        )

    # Zero totalSize → material $0 silently
    rz = calculate_quote_costs(100, 0, 3, 1.25, 1, False, [10], [5], [1, 0, 0, 0, 0, 0])
    if rz["materialCostWithPct"] == 0:
        rec(
            "quote",
            "medium",
            "Missing bar length silently zeros material cost",
            "totalSize=0 → materialCost=0 even if rawMaterialCost=$100 and partSize=3. Easy to underquote.",
            rz,
            "Warn in the quoter when material $ is entered but bar length is 0.",
        )

    # Assembly: BOM uses first non-zero price break (not qty-matched)
    rec(
        "quote",
        "high",
        "Assembly BOM uses the first non-zero child price break",
        "childUnitCost() takes prices.find(p => p > 0). A child quoted at $80/1 and $12/50 "
        "rolls $80 into every assembly, regardless of assembly qty. Also ignores child revision.",
        None,
        "Match child price to the assembly qty break. Match PN+rev, not PN only. Guard circular BOMs.",
    )


def sim_bonus_formulas(st):
    tiers = st["settings"]["bonusTiers"]
    hourly = st["settings"]["hourlyRate"]

    # 115% session (ratio 1.15) should hit 10% tier
    b_ok = compute_session_bonus(1.15, [1800], [300], 10, tiers, hourly)
    # quoted = 1800 + 300*10 = 4800s = 1.333h * 120 * 0.10 = 16
    if abs(b_ok - 16) < 0.01:
        ok("bonus", "Session bonus at 115% uses 10% tier", f"${b_ok}")
    else:
        bad("bonus", "Session bonus 115%", str(b_ok))

    # computeJobBonus with stored ratio 1.15 → divided by 100 → 0.0115 → $0
    job = {
        "efficiency": 1.15,
        "quotedSetups": [1800],
        "quotedRuntimes": [300],
        "quantity": 10,
    }
    jb = compute_job_bonus_as_written(job, tiers, hourly)
    if jb == 0:
        rec(
            "bonus",
            "critical",
            "computeJobBonus treats ratio>1 as a percent (divides by 100)",
            "Jobs store efficiency as a ratio (1.15 = 115%). computeJobBonus does "
            "`eff > 1 ? eff/100 : eff`, turning 115% into 1.15% and paying $0. "
            "The live path uses computeSessionBonus (correct). The job helper is a landmine "
            "if anything (reports, recover, future payroll) calls it. Live jobs already store "
            "ratios of 25–1600 from short test clocks.",
            {"jobBonusAsWritten": jb, "sessionBonusCorrect": b_ok, "liveEffSamples": [
                {"pn": j["partNumber"], "eff": j.get("efficiency"), "bonus": j.get("bonus")}
                for j in st["jobs"] if (j.get("efficiency") or 0) > 1
            ][:8]},
            "Delete the /100 branch. Efficiency is always a ratio. Cap displayed % at a sane max.",
        )
    else:
        ok("bonus", "computeJobBonus handles ratio")

    # 2-second setup still earns full quoted setup
    rec(
        "bonus",
        "critical",
        "Any completed setup/run credits the full quoted hours",
        "A 2-second OP1 setup still earns the full quoted setup (often 10–45 min). "
        "Live jobs show setups=[2,5] and [14,4] with efficiency 100–1600× and leftover $ bonuses. "
        "Day-bonus records then show 24×–312× efficiency with 0.0h on shift. "
        "Payroll is not trustworthy until this is gated.",
        {
            "examples": [
                {
                    "pn": j["partNumber"],
                    "setups": j.get("setups"),
                    "runtimes": j.get("runtimes"),
                    "quotedSetups": j.get("quotedSetups"),
                    "eff": j.get("efficiency"),
                    "bonus": j.get("bonus"),
                    "actual": j.get("actualTime"),
                    "status": j.get("status"),
                }
                for j in st["jobs"]
                if (j.get("efficiency") or 0) > 5
            ][:6]
        },
        "Require a minimum clock (e.g. 30s) or a confirm before crediting. "
        "Do not finalize day bonus from jobs whose actualTime < 60s. Mark test PNs (TEST*) excluded.",
    )

    # pairTwoVise double-count if OP2 slots also filled
    job_pair = {
        "setups": [120, 120],
        "runtimes": [60, 60],
        "quotedSetups": [600, 600],
        "quotedRuntimes": [300, 300],
        "quantity": 1,
        "actualTime": 360,
        "pairTwoVise": True,
    }
    eff_pair = compute_job_efficiency(job_pair)
    job_nopair = {**job_pair, "pairTwoVise": False}
    eff_nopair = compute_job_efficiency(job_nopair)
    if eff_pair > eff_nopair + 0.01:
        rec(
            "bonus",
            "high",
            "Two-vise flag double-counts OP2 when OP2 cells are also filled",
            f"pairTwoVise efficiency={eff_pair:.2f} vs same times without flag={eff_nopair:.2f}. "
            "The loop already credits every filled slot; the pairTwoVise block adds quoted OP2 again.",
            {"withFlag": eff_pair, "without": eff_nopair},
            "Only credit ghost OP2 when setups[1]/runtimes[1] are empty (the intended nest).",
        )

    # Night shift wrap
    req_night = shift_hours_required("16:00", "01:00", 1)
    if abs(req_night - 8) < 0.01:
        ok("bonus", "Night shift 16:00–01:00 − lunch = 8h", str(req_night))
    else:
        bad("bonus", "Night shift hours", str(req_night))

    # Overlapping downtimes double-count on-shift hours
    rec(
        "bonus",
        "high",
        "Overlapping downtimes are summed, not unioned",
        "Ethan's 8/12–8/13 has multiple End-of-Shift and Lunch rows that overlap the same hours. "
        "accumulateOperatorDay adds each overlap independently, so on-shift can exceed the clock. "
        "Live: Ethan 8/13 shows 7.0h of 8.0h plus 28.6h outside shift.",
        [d for d in st["downtimes"] if d.get("operator") == "Ethan"],
        "Merge downtime intervals per operator before summing. Close open downtimes on login/logout.",
    )


def sim_inventory():
    h = 10
    if apply_qty(h, "receive", 5) == 15 and apply_qty(h, "issue", 3) == 7:
        ok("inventory", "receive/issue math")
    if apply_qty(h, "issue", -3) == 7:
        rec(
            "inventory",
            "medium",
            "Issue/scrap use abs(qty) so a typed minus still subtracts",
            "applyQtyChange does Math.abs for issue/scrap. Typing -3 issues 3. Adjust is signed. Inconsistent.",
            None,
            "Document it, or reject negative issue qty in the UI.",
        )
    if apply_qty(2, "issue", 10) == -8:
        rec(
            "inventory",
            "high",
            "Issue can drive on-hand negative",
            "No floor at 0. A mis-scan or oversized issue silently creates negative stock.",
            {"after": apply_qty(2, "issue", 10)},
            "Block issue when qty > onHand unless an override is checked. Log the override.",
        )
    # adjust comment vs behavior
    rec(
        "inventory",
        "medium",
        "Adjust is a signed delta, comment says it can be an absolute count",
        "Comment in inventory.ts mentions 'new absolute count' / adjustAbsolute, but the code is always onHand+qty. "
        "A cycle count entered as 12 on a bin of 10 becomes 22.",
        None,
        "Add an explicit 'set count to' action separate from +/- adjust.",
    )


def sim_cut_tickets(st):
    t = {"status": "requested", "qtyRequested": 10, "qtyCut": 3, "qtyClaimed": 1}
    if derive_cut_status(t) == "partial":
        ok("saw", "partial status from progressive cut")
    t2 = {"status": "cancelled", "qtyRequested": 10, "qtyCut": 10, "qtyClaimed": 0}
    if derive_cut_status(t2) == "cancelled":
        ok("saw", "cancelled wins over qty")

    # claim > cut
    avail = max(0, 3 - 5)
    if avail == 0:
        ok("saw", "qtyAvailable floors at 0 when over-claimed")

    dups = defaultdict(list)
    for t in st["cutTickets"]:
        dups[(t.get("partNumber"), t.get("shopOrderId"), t.get("status"), t.get("qtyRequested"))].append(t)
    clones = {k: v for k, v in dups.items() if len(v) > 1}
    if clones:
        rec(
            "saw",
            "high",
            "Duplicate cut tickets for the same part",
            "Two identical skipped tickets for 4201-0200-02 (cut 3/57, claimed 3, no PO number). "
            "Floor can claim the same blanks twice.",
            [{"id": t["id"], "pn": t.get("partNumber"), "status": t.get("status"),
              "cut": t.get("qtyCut"), "req": t.get("qtyRequested"), "po": t.get("poNumber")}
             for ts in clones.values() for t in ts],
            "Unique (orderId, lineId, componentId) for open tickets. Dedup on create.",
        )

    for t in st["cutTickets"]:
        if (t.get("qtyClaimed") or 0) > (t.get("qtyCut") or 0):
            rec("saw", "high", "Claimed blanks exceed cut blanks", str(t))
        if (t.get("qtyCut") or 0) > (t.get("qtyRequested") or 0) and t.get("status") not in ("cancelled",):
            rec("saw", "medium", "Cut more than requested", str(t))


def sim_job_board(st):
    cards = 0
    unreleased = 0
    hidden = 0
    packed_incomplete = []
    over_complete = []
    for o in st["shopOrders"]:
        if o.get("status") == "cancelled" or o.get("deliveredAt"):
            continue
        for l in o.get("lines") or []:
            if l.get("lineStatus") == "cancelled":
                continue
            if l.get("readyForPack") or l.get("linePacked"):
                if shop_line_open(l) > 0 and o.get("packStatus") in ("packed", "verified"):
                    packed_incomplete.append(
                        f"{o.get('poNumber')} {l.get('partNumber')} qty={l.get('qty')} done={l.get('qtyCompleted')} pack={o.get('packStatus')}"
                    )
                continue
            if l.get("boardHidden"):
                hidden += 1
                continue
            cards += 1
            if not line_released(l):
                unreleased += 1
            if (l.get("qtyCompleted") or 0) > (l.get("qty") or 0):
                over_complete.append(
                    f"{o.get('poNumber')} {l.get('partNumber')} done={l.get('qtyCompleted')} qty={l.get('qty')}"
                )

    rec(
        "board",
        "high",
        f"{unreleased} of {cards} open board cards are not released (PDF/stock/CAD checks)",
        "PO-26142-24 (Sat-Lite, 28 lines) has revPdfOk=false and stockNoted=false on every line. "
        "Those cards sit on the board but cannot be pulled. Easy to think the job is live.",
        {"openCards": cards, "unreleased": unreleased, "hidden": hidden},
        "Show a big 'Not released — office must check PDF + stock' state. Don't mix with live work.",
    )

    if packed_incomplete:
        rec(
            "shipping",
            "critical",
            "Orders marked packed / verified with unfinished lines",
            "PO-26-X698 is packStatus=packed, qtyCompleted=0, readyForPack=false. "
            "PO-26-X621 is packed while 1831-0197 and 1831-0201 are still open.",
            packed_incomplete,
            "Block pack unless every active line is readyForPack or cancelled. "
            "Allow a documented partial-pack with remaining qty.",
        )

    if over_complete:
        rec(
            "orders",
            "high",
            "qtyCompleted can exceed qty ordered",
            "FD01-0088-01 is 22 completed against qty 10 (job saved 11, line later 22). "
            "shopLineOpenQty floors at 0 so the extra vanishes from material/buy logic.",
            over_complete,
            "Cap completed at ordered unless an over-run flag is set. Keep extras on part-stock / UIN.",
        )


def sim_permissions(st):
    default_op_tabs = {"dashboard", "machines", "jobs", "po", "calendar", "board", "active", "saw", "feedback", "inventory"}
    money = {"quoting", "database", "email", "reports"}
    for op in st["operators"]:
        tabs = set(op.get("tabs") or [])
        if op["role"] == "operator" and tabs & money:
            rec("auth", "critical", f"{op['name']} operator has money tabs", str(tabs))
        if op["role"] == "admin" and "settings" not in tabs:
            rec("auth", "high", f"{op['name']} admin missing Settings")
        if op["role"] == "operator":
            missing = default_op_tabs - tabs - {"jobs", "po", "calendar", "active", "saw", "inventory"}
            # operators currently only have dashboard/machines/board/feedback
            stripped = default_op_tabs - tabs
            if {"saw", "inventory", "po", "active"} & stripped:
                rec(
                    "auth",
                    "medium",
                    f"{op['name']} cannot open Saw / Inventory / Customer Orders / Active",
                    f"tabs={sorted(tabs)}. Floor will not see cut queue or stock unless an admin adds tabs back. "
                    "This may be intentional — flagging because saw tickets exist and operators are assigned work.",
                    {"tabs": sorted(tabs), "missing": sorted(stripped)},
                    "Confirm with James/Pam. If intentional, hide those nav items rather than 403 after a bookmark.",
                )
                break

    rec(
        "auth",
        "medium",
        "Default admin PIN 6283 is still compiled into the client as a fallback",
        "verifyOperatorPin() accepts DEFAULT_ADMIN_PIN for any admin if the stored pin is still plaintext. "
        "Live pins are hashed (good). The constant remains a known backdoor for any leftover plaintext admin.",
        None,
        "Remove the hardcoded fallback. Force hashed pins only.",
    )


def sim_merge():
    base = [{"id": "a", "qty": 1, "notes": "b"}]
    local = [{"id": "a", "qty": 2, "notes": "b"}]  # office changed qty
    remote = [{"id": "a", "qty": 1, "notes": "floor"}]  # floor changed notes
    # field-level merge would keep qty=2 and notes=floor
    # current mergeObj does walk keys, so this should work at object level
    rec(
        "sync",
        "high",
        "Three-way merge prefers local for non-id arrays and can resurrect deletes",
        "Arrays without id (setupTimes, prices, quotedRuntimes, drawings) take the local copy on any conflict. "
        "A stale tablet can overwrite a newer quote recipe. Deletes: if local still has a job the host deleted, "
        "mergeById puts it back (unless local equals base). A floor PC that never saw the delete re-creates it.",
        None,
        "Version or updatedAt per entity. Last-write-wins on quotes/jobs with timestamp. "
        "Tombstones for deletes. Do not merge recipe arrays field-blind.",
    )

    # settings merge
    rec(
        "sync",
        "medium",
        "Settings are 3-way merged field-by-field including bonusTiers and hourlyRate",
        "Two admins editing Settings at once can splice tiers from A with hourlyRate from B. "
        "betaMode flipped on one PC can flip back from a stale other PC.",
        None,
        "Treat settings as a single document with updatedAt. Last writer wins the whole object.",
    )


def sim_quotes_vs_recalc(st):
    mismatches = []
    drop_dead = 0
    for q in st["quotes"]:
        if (q.get("dropMultiplier") or 1) != 1:
            drop_dead += 1
        prices = q.get("prices") or []
        qtys = q.get("quantities") or []
        if not any(p or 0 for p in prices):
            continue
        if not any((q.get("setupTimes") or [0])) and not any((q.get("runTimes") or [0])) and not (q.get("rawMaterialCost") or 0):
            continue
        got = calculate_quote_costs(
            q.get("rawMaterialCost") or 0,
            q.get("rawMaterialLength") or 0,
            q.get("partLengthEach") or 0,
            q.get("materialPct") or 1,
            q.get("machineRate") or 1,
            bool(q.get("calculateMaterialDrop")),
            q.get("setupTimes") or [],
            q.get("runTimes") or [],
            qtys if len(qtys) >= 6 else list(qtys) + [0] * (6 - len(qtys)),
            0,
            q.get("benchAssembleMinutes") or 0,
            q.get("kind") or "part",
            q.get("dropMultiplier") or 1,
        )
        for i, (a, b) in enumerate(zip(prices, got["prices"])):
            if (qtys[i] if i < len(qtys) else 0) <= 0:
                continue
            if a and b and abs(a - b) > 0.05 and abs(a - b) / max(abs(a), 1e-9) > 0.01:
                mismatches.append(
                    {
                        "pn": q.get("partNumber"),
                        "rev": q.get("revision"),
                        "break": i,
                        "stored": a,
                        "recalc": b,
                        "delta": a - b,
                    }
                )
                break
    rec(
        "quote",
        "high",
        f"{len(mismatches)} live quotes do not match the current pricing formula",
        "Stored prices drifted from setup/run/material. Causes: imported historical prices, "
        "manual edits, formula changes after lock, or assembly BOM not re-rolled. "
        "Sending an old quote today would reprint a different number if someone hits Recalc.",
        mismatches[:15],
        "Never silently recalc a locked/sent quote. Show 'prices frozen on <date>' vs 'live recipe'.",
    )
    if drop_dead:
        rec(
            "quote",
            "medium",
            f"{drop_dead} quotes have dropMultiplier ≠ 1 and it does nothing",
            "Field is imported from CSV and stored. calculateQuoteCosts never reads it.",
            None,
            "Either apply it or remove it from the schema / import map.",
        )

    # circular BOM
    by_pn = {q["partNumber"].upper(): q for q in st["quotes"]}
    circular = []
    for q in st["quotes"]:
        if q.get("kind") != "assembly":
            continue
        pn = (q.get("partNumber") or "").upper()
        for row in q.get("bom") or []:
            child = (row.get("partNumber") or "").upper()
            if child == pn:
                circular.append(pn)
    if circular:
        rec(
            "quote",
            "high",
            "Assembly BOM includes itself",
            f"{circular}. TET-0293-03 lists TET-0293-03 as a child. childUnitCost then "
            "feeds the assembly's own first price back into itself (inflation / nonsense).",
            circular,
            "Reject self-references. Detect cycles. TET vs TEST looks like a typo.",
        )


def sim_jobs_live(st):
    started = []
    zombie = []
    test_jobs = []
    no_quote_times = []
    in_prog_no_end = []
    for j in st["jobs"]:
        cells = (j.get("setups") or []) + (j.get("runtimes") or [])
        if "STARTED" in cells:
            started.append(j["partNumber"])
        if (j.get("partNumber") or "").upper().startswith("TEST"):
            test_jobs.append(j["id"])
        if j.get("status") == "In Progress" and not j.get("endTime"):
            in_prog_no_end.append(j["partNumber"])
        qs = j.get("quotedSetups") or []
        qr = j.get("quotedRuntimes") or []
        if j.get("status") in ("Completed", "In Progress") and not any(qs) and not any(qr):
            if any(isinstance(x, (int, float)) and x > 60 for x in cells):
                no_quote_times.append(
                    {"pn": j["partNumber"], "setups": j.get("setups"), "runs": j.get("runtimes"),
                     "actual": j.get("actualTime")}
                )
        # actualTime 0 but cells have seconds
        actual = j.get("actualTime") or 0
        cell_sum = sum(x for x in cells if isinstance(x, (int, float)))
        if cell_sum > 30 and actual == 0 and j.get("status") == "In Progress":
            zombie.append({"pn": j["partNumber"], "cellSum": cell_sum, "op": j.get("operator")})

    if started:
        rec(
            "jobs",
            "high",
            "Completed job still has a STARTED timer cell",
            f"{started}. TEST job completed 8/14 still has runtimes[0]='STARTED'. "
            "Averages and efficiency skip that op; the cell is poison if the job is reopened.",
            started,
            "On complete, refuse STARTED cells or coerce them to elapsed seconds.",
        )
    if test_jobs:
        rec(
            "jobs",
            "medium",
            f"{len(test_jobs)} TEST jobs are in the live job history",
            "TEST / TEST-0293-* / TET-0293 mix with real Sat-Lite work. "
            "averageMaxRuns is 1, so one TEST complete can overwrite a real part's recipe.",
            {"count": len(test_jobs), "averageMaxRuns": st["settings"].get("averageMaxRuns")},
            "Purge or tag test jobs. Set averageMaxRuns back to ~8–10 before trusting averages.",
        )
    if no_quote_times:
        rec(
            "jobs",
            "high",
            "Real clock time on jobs with $0 quoted times — no bonus, no average",
            "FD01-0037-01 has 3600s setup + 5436s run and quotedSetups/Runtimes all 0. "
            "Someone ran the part with no recipe loaded. Efficiency stays 0. Completing it "
            "with countInAverage can average zeros into the quote.",
            no_quote_times,
            "Block start-job unless a quote exists, or warn and copy recipe first.",
        )
    if zombie:
        rec(
            "jobs",
            "medium",
            "In-progress jobs have timer cells but actualTime=0",
            "actualTime is only written on saveJob. Mid-shift crash / tab close leaves "
            "efficiency/bonus stale until someone hits Save.",
            zombie[:8],
            "Recompute actualTime whenever a timer stops, not only on Save/Complete.",
        )

    # Active sessions vs jobs
    for machine, sess in st["sessions"].items():
        jid = sess.get("jobId")
        if not jid:
            continue
        job = next((j for j in st["jobs"] if j["id"] == jid), None)
        timer = st["activeTimers"].get(machine)
        if not job:
            rec("jobs", "critical", f"{machine} session points at a missing job", jid)
        elif job.get("status") == "Completed" and sess.get("jobId"):
            rec("jobs", "high", f"{machine} still loaded with a completed job", job["partNumber"])
        if sess.get("paused") and timer:
            rec("jobs", "high", f"{machine} paused but timer still running")
        if not sess.get("paused") and not timer and job and job.get("status") == "In Progress":
            rec(
                "jobs",
                "medium",
                f"{machine} has {sess.get('partNumber')} loaded, not paused, no live timer",
                "Christian on VF2 and James on VF4 are sitting on a job with no clock. "
                "Easy to walk away and lose time, or think the clock is running.",
                {"machine": machine, "op": sess.get("operatorName"), "pn": sess.get("partNumber")},
                None,
            )


def sim_time_log(st):
    open_logs = [r for r in st["operatorTimeLog"] if not r.get("endTime")]
    if open_logs:
        rec(
            "time",
            "critical",
            "Open time-log row with no end (clock running for days)",
            "James Steck / LASER / OP1 Runtime started 2026-08-12T16:43:31Z still open. "
            "That row is ignored by day-bonus (requires endTime) but will explode if someone stops it. "
            "Also an open 'Waiting on Material' downtime since 8/12 and Christian End-of-Shift since 8/14 00:06.",
            open_logs + [d for d in st["downtimes"] if not d.get("endTime")],
            "Auto-close open timers at shift end. Surface a red 'clock left on' banner. "
            "Cap a single segment at shift length.",
        )

    # overlapping downtimes
    by_op = defaultdict(list)
    for d in st["downtimes"]:
        if d.get("endTime"):
            by_op[d["operator"]].append(d)
    overlaps = []
    for op, rows in by_op.items():
        rows = sorted(rows, key=lambda x: x["startTime"])
        for a, b in zip(rows, rows[1:]):
            if a["endTime"] > b["startTime"] and a["jobId"] == b["jobId"]:
                overlaps.append((op, a["reason"], b["reason"], a["startTime"], b["startTime"]))
    if overlaps:
        rec(
            "time",
            "high",
            f"{len(overlaps)} overlapping downtime pairs",
            "Same operator, same job, two pause reasons covering the same minutes "
            "(End of Shift + Lunch, duplicate End of Shift). Pause hours double.",
            overlaps[:10],
            "Only one open downtime per machine. Starting a new pause should close the previous.",
        )


def sim_day_bonus_replay(st):
    """Replay calculateDayBonus-ish numbers vs stored records."""
    tiers = st["settings"]["bonusTiers"]
    hourly = st["settings"]["hourlyRate"]
    stale = []
    for recb in st["dayBonuses"]:
        # If workedHours==0, stored efficiency should be 0
        if (recb.get("workedHours") or 0) <= 0 and (recb.get("efficiency") or 0) > 0:
            stale.append(
                {
                    "date": recb.get("dateKey"),
                    "op": recb.get("operatorName"),
                    "eff": recb.get("efficiency"),
                    "worked": recb.get("workedHours"),
                    "onShift": recb.get("onShiftHours"),
                    "reason": recb.get("eligibilityReason"),
                    "status": recb.get("status"),
                }
            )
    if stale:
        rec(
            "bonus",
            "high",
            "Stored day-bonus efficiency is leftover garbage when workedHours is 0",
            "Records show 24×–312× efficiency with 0.0h on shift. "
            "UI will flash insane % even though bonus is $0. Finalized 8/14 Pam & James "
            "are $0 'no timed work' — fine, but the stale % will confuse payroll review.",
            stale,
            "When workedHours==0, force efficiency=0, tierPct=0, pool=0 before save.",
        )

    if st["settings"].get("betaMode"):
        rec(
            "bonus",
            "info",
            "betaMode is still ON — Mark paid is blocked",
            "Correct for a shop still proving the numbers. Do not turn this off until "
            "the timer/bonus bugs above are fixed or every TEST job is purged.",
            {"betaMode": True, "hourlyRate": hourly, "tiers": tiers},
            None,
        )


def sim_material_and_rfq(st):
    # empty material + match=exact
    weird = []
    for o in st["shopOrders"]:
        for l in o.get("lines") or []:
            if l.get("materialMatch") == "exact" and not (l.get("material") or "").strip():
                weird.append(f"{o.get('poNumber')} {l.get('partNumber')}")
            if (l.get("material") or "").lower().startswith("customer") and (l.get("materialNeeded") or 0) > 0:
                rec(
                    "material",
                    "medium",
                    "Customer-supplied line still has materialNeeded > 0",
                    f"{o.get('poNumber')} {l.get('partNumber')} needed={l.get('materialNeeded')}",
                )
    if weird:
        rec(
            "material",
            "high",
            "Lines marked materialMatch=exact with a blank material",
            "PO-26142-24 several 3841-* lines. Exact match of nothing. Buy list skips them "
            "(no material.trim()), so they never show as a shortage.",
            weird,
            "exact requires a non-empty material + size. Otherwise force 'none' / needs_attention.",
        )

    # RFQs sent, no bids, no POs
    if st["purchaseOrders"] == []:
        rec(
            "buying",
            "medium",
            "Zero vendor purchase orders in the live shop",
            "Material buys module is empty. Two RFQs are status=sent with 0 bids. "
            "Stock is being received as ad-hoc inventory, not against a PO, so you lose "
            "price history and open-order visibility.",
            [{"rfq": r.get("rfqNumber"), "status": r.get("status"), "vendors": r.get("vendorsRequested"),
              "lines": len(r.get("lines") or []), "bids": len(r.get("bids") or [])}
             for r in st["vendorRfqs"]],
            "Either use Material Buys for EMJ/Action orders, or hide the RFQ module until you will.",
        )

    # inventory txn vs onHand
    last = {}
    for t in sorted(st["inventoryTxns"], key=lambda x: x["at"]):
        last[t["itemId"]] = t["balanceAfter"]
    drift = []
    stock_by_id = {m["id"]: m for m in st["materialStock"] + st["partStock"]}
    for iid, bal in last.items():
        row = stock_by_id.get(iid)
        if row and abs((row.get("onHand") or 0) - bal) > 1e-6:
            # only fail if this was the latest txn — later unlogged edits are expected
            drift.append((iid, bal, row.get("onHand"), row.get("material") or row.get("partNumber")))
    # Not necessarily a bug if they adjusted without a txn after. Report if any.
    if drift:
        rec(
            "inventory",
            "medium",
            "Last txn balanceAfter ≠ current onHand",
            "Stock was edited without a matching transaction, or a txn was written then qty changed again.",
            drift,
            "Every onHand change must write a txn. Rebuild onHand from txn history in Recover.",
        )

    good = [u for u in st["partUnits"] if u.get("quality") == "good"]
    seconds = [u for u in st["partUnits"] if u.get("quality") == "second"]
    if not good and seconds:
        rec(
            "inventory",
            "info",
            f"{len(seconds)} second-quality UINs on the shelf, 0 good",
            "FD01-0088-01 extras with defect '.189 HOLE .19'. Feature works. "
            "No good-unit tracking yet — only blemish parts got UINs.",
            {"seconds": len(seconds)},
            None,
        )


def sim_work_queue(st):
    no_machine = [q for q in st["workQueue"] if q.get("status") in ("queued", "active", "held") and not (q.get("machine") or "").strip()]
    no_op = [q for q in st["workQueue"] if q.get("status") in ("queued", "active") and not (q.get("operatorName") or "").strip()]
    if no_machine:
        rec(
            "assign",
            "medium",
            f"{len(no_machine)} queued jobs have no machine",
            "Assign workload cannot book hours onto a machine for these. They also vanish from machine queues.",
            [f"{q.get('poNumber')} {q.get('partNumber')}" for q in no_machine][:12],
            "Require a machine (or 'Any mill' / 'Any lathe') before leaving Assign.",
        )
    # double count assign + queue
    rec(
        "assign",
        "medium",
        "Assign workload can still double-count a job",
        "De-dupe key is machine|operator|PN|qty. If the queue has machine=VF2 and the board "
        "assignment has machine=HAAS VF2 MILL, both count. Assembly parent + component both count "
        "when both are assigned.",
        None,
        "De-dupe on shopOrderLineId / componentId, not on the display label.",
    )


def sim_sales_tax():
    lines = [
        {"amount": 1000, "taxable": False},
        {"amount": 50, "taxable": False},
    ]
    t = sales_order_totals(lines, 0.0825)
    if t["tax"] > 0:
        rec(
            "sales",
            "critical",
            "Sales-order tax treats the whole order as taxable when no line is flagged",
            f"Two NON lines totaling $1050 still compute tax=${t['tax']} (8.25% of 1050). "
            "TX machine shops often have resale / exempt Sat-Lite work. One missed checkbox "
            "and the QB CSV adds ~$86 tax that is not on the customer PO.",
            t,
            "Default to NON. Only tax lines explicitly marked taxable. Never infer 'all taxable'.",
        )


def sim_so_numbers(st):
    sos = [o.get("soNumber") for o in st["shopOrders"] if o.get("soNumber")]
    if len(sos) != len(set(sos)):
        rec("sales", "high", "Duplicate SO numbers", sos)
    if len(sos) < len(st["shopOrders"]):
        rec(
            "sales",
            "medium",
            f"{len(st['shopOrders']) - len(sos)} customer POs have no sales-order number",
            "suggestSoNumber starts at 1001. Only PO-26142-24 has SO 1001. "
            "Packing / QB export will mint numbers out of order later.",
            {"have": sos, "missing": [o.get("poNumber") for o in st["shopOrders"] if not o.get("soNumber")]},
            "Assign SO# on import, not on first print.",
        )


def sim_shipping_friday():
    # fridayOfWeek uses toISOString which is UTC
    rec(
        "calendar",
        "medium",
        "fridayOfWeek uses UTC (toISOString), weekRangeContaining uses local",
        "In Mineola/Van, TX (CDT, UTC−5) a Friday 7pm local is Saturday 00:00 UTC. "
        "The 'this Friday' chip can jump a week. weekRangeContaining is local — the two disagree.",
        None,
        "Use local Y-M-D for both helpers (same ymd() already used in weekRangeContaining).",
    )


def sim_find_quote_loose():
    rec(
        "quote",
        "high",
        "findQuoteForPart falls back to startsWith / startsWith-reverse",
        "assign-workload.ts: if no exact PN, it accepts a quote whose PN starts with the search "
        "or vice versa. '3841' can grab 3841-0035-01. '1231-0180' can grab 1231-0180-01 or 1231-0180-02. "
        "Wrong hours on the assign board, wrong material recipe on import.",
        None,
        "Exact PN+rev only. If multiple revs, pick latest date. Never prefix-match.",
    )


def sim_average_max_runs(st):
    if (st["settings"].get("averageMaxRuns") or 10) <= 1:
        rec(
            "averages",
            "critical",
            "averageMaxRuns is 1 — a single complete overwrites the quote recipe",
            "Settings: averageMaxRuns=1, averageShopWeight=0.5, averageOutlierRatio=1.25. "
            "One 14-second TEST complete on a real PN blends 50% of those zeros/seconds into setup/run. "
            "Next quote email goes out with garbage times.",
            {
                "averageMaxRuns": st["settings"].get("averageMaxRuns"),
                "averageShopWeight": st["settings"].get("averageShopWeight"),
                "averageOutlierRatio": st["settings"].get("averageOutlierRatio"),
            },
            "Set max runs to 8–10. Exclude TEST PNs. Don't average jobs with actualTime < 5 minutes "
            "or efficiency > 3×. Confirm before writing back to the live recipe.",
        )


def sim_security(st):
    # hashed pins in the USB json — the USB dump contains password hashes + shop data
    rec(
        "security",
        "high",
        "Full USB zip contains PIN hashes, edit-password hash, and the entire quote book",
        "Anyone with this zip has every customer, every price, every operator hash, chat, and drawings. "
        "data/.shop-secret is in the zip. This is the intended office backup — treat the zip as cash.",
        {"operators": len(st["operators"]), "quotes": len(st["quotes"]), "hasShopSecret": True},
        "Keep USB in the safe. Don't email the full zip. Separate a 'code-only' update pack from data.",
    )
    rec(
        "security",
        "medium",
        "shopPublicUrl is a LAN IP baked into Settings",
        f"{st['settings'].get('shopPublicUrl')}. Fine for barcode QR codes. "
        "If that DHCP lease changes, every printed label points at a dead host.",
        {"shopPublicUrl": st["settings"].get("shopPublicUrl")},
        "Prefer a hostname (lcm.local / lcm-shop) or reprint labels after IP change.",
    )


def sim_po_import_sanity(st):
    rec(
        "import",
        "medium",
        "PO import is a 937-line heuristic PDF parser with no golden-file tests in this dump",
        "scripts/ only has brand-check tests. po-import.ts, po-revise.ts, quote-import.ts "
        "have no fixture tests. A Sat-Lite layout change will silently drop lines or "
        "glue the next line's price onto the previous PN.",
        {"poImportLines": 937, "poReviseLines": 721, "quoteImportLines": 654},
        "Check in 5 anonymized PO PDFs + expected JSON. Run them on every update pack.",
    )


def sim_host_update():
    rec(
        "host",
        "medium",
        "Update pack can apply with a dirty shop still running",
        "APPLY-UPDATE-DOUBLE-CLICK-ME.bat extracts over C:\\LCM. HOW-TO-UPDATE says restart after. "
        "If the host process has the JSON open / Vite has source cached, you can get a half-applied update. "
        "Last log (8/7) also notes package.json changed → npm install required — easy to skip.",
        None,
        "Bat file should stop the host, apply, npm install if lockfile changed, then start.",
    )


def sim_data_backups():
    rec(
        "backup",
        "info",
        "29 same-day JSON backups in data/backups/ (~1.7–1.8 MB each)",
        "Backup-on-write is working. Several pairs are 200–300ms apart (double-save). "
        "USB zip is 30MB because of this. Not a logic bug — disk will grow fast.",
        None,
        "Keep last 20 + daily. Don't ship every backup on the USB restore zip.",
    )


def write_outputs():
    by_sev = Counter(f["severity"] for f in FINDINGS)
    report = {
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "source": "LCM-FULL-USB-2026-08-14T20-21-55",
        "shopRev": None,
        "counts": dict(by_sev),
        "simsRun": SIMS,
        "unitPass": PASS,
        "unitFail": FAIL,
        "findings": FINDINGS,
    }
    with open(DATA) as f:
        report["shopRev"] = json.load(f).get("rev")
    (OUT / "simulation-report.json").write_text(json.dumps(report, indent=2, default=str))

    sev_order = ["critical", "high", "medium", "info", "fail", "pass"]
    md = []
    md.append("# LCM simulation findings")
    md.append("")
    md.append(f"Shop rev **{report['shopRev']}** · {report['generatedAt']}")
    md.append("")
    md.append(
        f"Simulations run: **{SIMS}** · unit pass {PASS} · unit fail {FAIL} · "
        f"critical {by_sev['critical']} · high {by_sev['high']} · medium {by_sev['medium']}"
    )
    md.append("")
    for sev in sev_order:
        items = [f for f in FINDINGS if f["severity"] == sev]
        if not items:
            continue
        md.append(f"## {sev.upper()} ({len(items)})")
        md.append("")
        for f in items:
            md.append(f"### {f['title']}")
            md.append("")
            md.append(f"- Module: `{f['sim']}`")
            if f.get("detail"):
                md.append(f"- {f['detail']}")
            if f.get("fix"):
                md.append(f"- **Fix:** {f['fix']}")
            md.append("")
    (OUT / "SIMULATION-FINDINGS.md").write_text("\n".join(md))
    return report


def main():
    with open(DATA) as f:
        bundle = json.load(f)
    st = bundle["state"]

    sim_quote_formulas()
    sim_bonus_formulas(st)
    sim_inventory()
    sim_cut_tickets(st)
    sim_job_board(st)
    sim_permissions(st)
    sim_merge()
    sim_quotes_vs_recalc(st)
    sim_jobs_live(st)
    sim_time_log(st)
    sim_day_bonus_replay(st)
    sim_material_and_rfq(st)
    sim_work_queue(st)
    sim_sales_tax()
    sim_so_numbers(st)
    sim_shipping_friday()
    sim_find_quote_loose()
    sim_average_max_runs(st)
    sim_security(st)
    sim_po_import_sanity(st)
    sim_host_update()
    sim_data_backups()

    report = write_outputs()
    print(f"SIMS={SIMS} PASS={PASS} FAIL={FAIL}")
    print("severity", Counter(f["severity"] for f in FINDINGS))
    print("wrote", OUT / "SIMULATION-FINDINGS.md")
    # compact console list
    for sev in ("critical", "high", "fail"):
        for f in FINDINGS:
            if f["severity"] == sev:
                print(f"[{sev}] {f['sim']}: {f['title']}")


if __name__ == "__main__":
    main()
