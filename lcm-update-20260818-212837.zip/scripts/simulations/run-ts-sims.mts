/**
 * Import the real LCM modules and hammer them with edge cases + live shop JSON.
 */
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import {
  calculateQuoteCosts,
  calculateAssemblyAwareCosts,
  computeJobBonus,
  computeJobEfficiency,
  computeSessionBonus,
  computeSessionEfficiency,
  computeShiftBonus,
  findNextOperation,
  quoteFromForm,
  sessionOffersTwoVise,
} from "../../src/lib/lcm/calculations.ts";
import { bomRollup, childUnitCost } from "../../src/lib/lcm/assembly.ts";
import { applyQtyChange, isLowStock, generatePartUin } from "../../src/lib/lcm/inventory.ts";
import {
  calculateDayBonus,
  shiftHoursRequired,
  weekKeyFromDate,
  currentShiftContext,
  resolveWorkShifts,
  accumulateOperatorDay,
} from "../../src/lib/lcm/day-bonus.ts";
import {
  deriveCutStatus,
  qtyAvailable,
  ticketFromLine,
  emptyCutTicket,
} from "../../src/lib/lcm/cut-tickets.ts";
import { buildJobBoard, lineReleasedToShop } from "../../src/lib/lcm/job-board.ts";
import {
  operatorCanAccessTab,
  normalizeOperator,
  verifyOperatorPin,
  DEFAULT_ADMIN_PIN,
  canSeeMoney,
} from "../../src/lib/lcm/permissions.ts";
import { threeWayMergeShop, cloneShared } from "../../src/lib/lcm/shop-merge.ts";
import {
  shopLineOpenQty,
  deriveShopOrderStatus,
  derivePoStatus,
  emptyShopOrder,
  emptyShopOrderLine,
} from "../../src/lib/lcm/po.ts";
import { findQuoteForPart, quotedHoursForPart, buildAssignWorkload } from "../../src/lib/lcm/assign-workload.ts";
import { salesOrderTotals, shopLinesToSoLines, suggestSoNumber } from "../../src/lib/lcm/sales-order.ts";
import { emptyToolingCharge, toolingBillLines, normalizeToolingCharges } from "../../src/lib/lcm/quote-tooling.ts";
import { estimateMaterialUnits } from "../../src/lib/lcm/po-material.ts";
import { computeShopOrderBuyList } from "../../src/lib/lcm/order-material-needs.ts";
import type { JobRun, MachineSession, Quote, ShopSharedState } from "../../src/lib/lcm/types.ts";

const shop = JSON.parse(readFileSync("/workspace/lcm/data/lcm-shop.json", "utf8"));
const st = shop.state as ShopSharedState & { settings: any };
const findings: any[] = [];

function note(sev: string, title: string, detail: any) {
  findings.push({ sev, title, detail });
  console.log(`[${sev}] ${title}`);
}

// ---- Quote engine ----
const q1 = calculateQuoteCosts({
  rawMaterialCost: 24,
  totalSize: 12,
  partSize: 3,
  materialPercentage: 1.25,
  machineRate: 1,
  calculateMaterialDrop: false,
  setupTimes: [15, 10],
  runTimesPerPart: [5, 2],
  quantities: [1, 4, 10, 0, 0, 0],
});
if (Math.abs(q1.prices[0] - 71.5) > 1e-9) note("fail", "happy-path quote", q1);
else note("pass", "happy-path quote $71.50 / $34.00", q1.prices.slice(0, 2));

const qZero = calculateQuoteCosts({
  rawMaterialCost: 24,
  totalSize: 12,
  partSize: 3,
  materialPercentage: 1,
  machineRate: 0,
  calculateMaterialDrop: false,
  setupTimes: [10],
  runTimesPerPart: [5],
  quantities: [1, 0, 0, 0, 0, 0],
});
const qOne = calculateQuoteCosts({
  rawMaterialCost: 24,
  totalSize: 12,
  partSize: 3,
  materialPercentage: 1,
  machineRate: 1,
  calculateMaterialDrop: false,
  setupTimes: [10],
  runTimesPerPart: [5],
  quantities: [1, 0, 0, 0, 0, 0],
});
if (qZero.runCost === qOne.runCost) {
  note("critical", "machineRate=0 coerced to 1", { run0: qZero.runCost, run1: qOne.runCost });
}

const qDrop = calculateQuoteCosts({
  rawMaterialCost: 24,
  totalSize: 12,
  partSize: 3,
  materialPercentage: 1,
  machineRate: 1,
  calculateMaterialDrop: true,
  setupTimes: [0],
  runTimesPerPart: [0],
  quantities: [1, 4, 5, 0, 0, 0],
});
note(
  qDrop.prices[2] === qDrop.prices[1] ? "high" : "info",
  "drop: 5pcs from 12in bar costs same as 4pcs (second bar free)",
  qDrop.prices.slice(0, 3),
);

// Assembly self-BOM
const selfAsm: Quote = quoteFromForm({
  partNumber: "TET-0293-03",
  kind: "assembly",
  prices: [200, 0, 0, 0, 0, 0],
  bom: [{ partNumber: "TET-0293-03", revision: "A", qty: 1, note: "" }],
  quantities: [1, 0, 0, 0, 0, 0],
});
const roll = bomRollup(selfAsm.bom, [selfAsm]);
if (roll.total > 0 && roll.lines[0]?.found) {
  note("critical", "circular BOM: assembly prices itself as a child", roll);
}

// Loose quote match
const quotes = st.quotes as Quote[];
const loose = findQuoteForPart(quotes, "3841");
if (loose && loose.partNumber.toUpperCase() !== "3841") {
  note("high", "findQuoteForPart('3841') prefix-matched a real part", {
    got: loose.partNumber,
    rev: loose.revision,
  });
}

// ---- Bonus ----
const tiers = st.settings.bonusTiers;
const jobFast: JobRun = {
  id: "x",
  partNumber: "X",
  startTime: "2026-08-14T12:00:00Z",
  endTime: "2026-08-14T12:00:14Z",
  setups: [14, 4, null, null, null, null, null, null, null, null],
  runtimes: [13, 6, null, null, null, null, null, null, null, null],
  quotedSetups: [600, 3600, 1800, 0, 0, 0, 0, 0, 0, 0],
  quotedRuntimes: [60, 300, 420, 0, 0, 0, 0, 0, 0, 0],
  status: "Completed",
  saveTime: "2026-08-14T12:00:14Z",
  operator: "James Steck",
  efficiency: 123.24,
  bonus: 22.6,
  totalElapsed: 37,
  actualTime: 37,
  totalPaused: 0,
  machine: "HAAS VF4 MILL",
  revision: "A",
  quantity: 1,
  customer: "TEST",
  pauseReason: "",
  machinesUsed: [],
  quantityCompleted: 2,
  countInAverage: true,
};
const jobBonus = computeJobBonus(jobFast, tiers, 120);
const sess: MachineSession = {
  machine: "HAAS VF4 MILL",
  operatorId: null,
  operatorName: "James",
  jobId: "x",
  partNumber: "X",
  revision: "A",
  quantity: 1,
  customer: "TEST",
  loginTime: null,
  shiftStart: null,
  notes: "",
  setups: [14, 4, null, null, null, null, null, null, null, null],
  runtimes: [13, 6, null, null, null, null, null, null, null, null],
  quotedSetups: [600, 3600, 1800, 0, 0, 0, 0, 0, 0, 0],
  quotedRuntimes: [60, 300, 420, 0, 0, 0, 0, 0, 0, 0],
  efficiency: 123.24,
  bonus: 0,
  quantityCompleted: 2,
  paused: false,
  pauseStart: null,
};
const sessEff = computeSessionEfficiency(sess);
const sessBonus = computeSessionBonus(sess, tiers, 120);
note(jobBonus === 0 ? "critical" : "pass", "computeJobBonus on 123× job", {
  jobBonus,
  sessEff,
  sessBonus,
});

// pair two vise double count
const pairJob: JobRun = {
  ...jobFast,
  setups: [120, 120, null, null, null, null, null, null, null, null],
  runtimes: [60, 60, null, null, null, null, null, null, null, null],
  quotedSetups: [600, 600, 0, 0, 0, 0, 0, 0, 0, 0],
  quotedRuntimes: [300, 300, 0, 0, 0, 0, 0, 0, 0, 0],
  actualTime: 360,
  pairTwoVise: true,
  efficiency: 0,
};
const pairOn = computeJobEfficiency(pairJob);
const pairOff = computeJobEfficiency({ ...pairJob, pairTwoVise: false });
note(
  pairOn > pairOff + 0.01 ? "high" : "pass",
  "pairTwoVise double-counts OP2 when both slots filled",
  { pairOn, pairOff },
);

// findNextOperation two-vise
const nest: MachineSession = {
  ...sess,
  pairTwoVise: true,
  pairPartNumber: "X-02",
  setups: [null, null, null, null, null, null, null, null, null, null],
  runtimes: [null, null, null, null, null, null, null, null, null, null],
  quantity: 10,
  quantityCompleted: 0,
};
const n1 = findNextOperation(nest);
const nest2 = { ...nest, setups: [30, ...nest.setups.slice(1)] };
const n2 = findNextOperation(nest2 as MachineSession);
note("pass", "two-vise next op is OP1 setup then OP1 runtime only", { n1, n2 });

// Same P/N two-vise (no nest pair) — still OP1 only
const samePn = {
  ...sess,
  jobId: "same-pn",
  pairTwoVise: true,
  pairPartNumber: "",
  pairJobId: "",
  setups: [null, null, null, null, null, null, null, null, null, null],
  runtimes: [null, null, null, null, null, null, null, null, null, null],
  quotedSetups: [600, 300, 0, 0, 0, 0, 0, 0, 0, 0],
  quotedRuntimes: [120, 120, 0, 0, 0, 0, 0, 0, 0, 0],
  quantity: 10,
  quantityCompleted: 0,
  focusOpIndex: undefined,
};
const s1 = findNextOperation(samePn as MachineSession);
const s2 = findNextOperation({
  ...samePn,
  setups: [45, ...samePn.setups.slice(1)],
} as MachineSession);
const s3 = findNextOperation({
  ...samePn,
  setups: [45, ...samePn.setups.slice(1)],
  runtimes: [90, ...samePn.runtimes.slice(1)],
  quantityCompleted: 10,
} as MachineSession);
const offersSame = sessionOffersTwoVise(samePn as MachineSession);
const offersFocus = sessionOffersTwoVise({
  ...samePn,
  focusOpIndex: 1,
} as MachineSession);
note(
  s1?.operation === "OP1" &&
    s1.type === "Setup" &&
    s2?.operation === "OP1" &&
    s2.type === "Runtime" &&
    s3 == null &&
    offersSame &&
    !offersFocus
    ? "pass"
    : "high",
  "same-PN two-vise is OP1 only; checkbox hidden on focused OP",
  { s1, s2, s3, offersSame, offersFocus },
);

// ---- Day bonus replay for James 8/14 ----
const day = calculateDayBonus({
  operatorName: "James Steck",
  dateKey: "2026-08-14",
  jobs: st.jobs as JobRun[],
  operatorTimeLog: st.operatorTimeLog,
  downtimes: st.downtimes,
  workDayStart: "07:00",
  workDayEnd: "16:00",
  lunchHours: 1,
  bonusTiers: tiers,
  hourlyRate: 120,
  now: new Date("2026-08-14T22:00:00"),
});
note("info", "replay James 2026-08-14 day bonus", {
  eligible: day.eligible,
  reason: day.eligibilityReason,
  earned: day.earnedHours,
  worked: day.workedHours,
  onShift: day.onShiftHours,
  bonus: day.projectedBonus,
  efficiency: day.efficiency,
});

const ethan = calculateDayBonus({
  operatorName: "Ethan",
  dateKey: "2026-08-13",
  jobs: st.jobs as JobRun[],
  operatorTimeLog: st.operatorTimeLog,
  downtimes: st.downtimes,
  workDayStart: "07:00",
  workDayEnd: "16:00",
  lunchHours: 1,
  bonusTiers: tiers,
  hourlyRate: 120,
  now: new Date("2026-08-14T22:00:00"),
});
note(ethan.outsideShiftHours > 20 ? "high" : "info", "replay Ethan 2026-08-13 (open clocks)", {
  eligible: ethan.eligible,
  reason: ethan.eligibilityReason,
  worked: ethan.workedHours,
  pause: ethan.pauseHours,
  onShift: ethan.onShiftHours,
  outside: ethan.outsideShiftHours,
  bonus: ethan.projectedBonus,
});

// ---- Inventory ----
if (applyQtyChange(2, "issue", 10) < 0) {
  note("high", "issue 10 from 2 → negative onHand", applyQtyChange(2, "issue", 10));
}
if (applyQtyChange(10, "issue", -3) === 7) {
  note("medium", "negative issue qty still subtracts (abs)", applyQtyChange(10, "issue", -3));
}
const uins = new Set<string>();
for (let i = 0; i < 200; i++) uins.add(generatePartUin(uins));
if (uins.size !== 200) note("fail", "UIN collision in 200 generates", uins.size);
else note("pass", "200 unique UINs", uins.size);

// ---- Cut / board / orders ----
const board = buildJobBoard(st.shopOrders);
const unreleased = board.filter((c) => !c.released);
note("info", `job board ${board.length} cards, ${unreleased.length} unreleased`, {
  kinds: board.reduce((m: any, c) => ((m[c.kind] = (m[c.kind] || 0) + 1), m), {}),
});

const packedOpen = st.shopOrders.filter(
  (o) =>
    (o.packStatus === "packed" || o.packStatus === "verified") &&
    o.lines.some((l) => shopLineOpenQty(l) > 0 && l.lineStatus !== "cancelled"),
);
if (packedOpen.length) {
  note(
    "critical",
    "packed orders still have open qty",
    packedOpen.map((o) => ({
      po: o.poNumber,
      pack: o.packStatus,
      open: o.lines.map((l) => `${l.partNumber}:${shopLineOpenQty(l)}`).filter((s) => !s.endsWith(":0")),
    })),
  );
}

// derive status vs stored
const statusDrift = st.shopOrders
  .map((o) => ({ po: o.poNumber, stored: o.status, derived: deriveShopOrderStatus(o) }))
  .filter((x) => x.stored !== x.derived);
if (statusDrift.length) note("high", "shop order status ≠ derived", statusDrift);

// ---- Permissions ----
const christian = st.operators.find((o) => o.name === "Christian")!;
if (operatorCanAccessTab(christian, "quoting")) note("critical", "operator can open quoting");
else note("pass", "operator blocked from quoting");
if (canSeeMoney(christian)) note("critical", "operator canSeeMoney");
if (verifyOperatorPin({ ...christian, pin: "6283", role: "admin" } as any, "6283")) {
  note("high", "DEFAULT_ADMIN_PIN 6283 still accepted for plaintext admin", DEFAULT_ADMIN_PIN);
}

// ---- Merge resurrection ----
const remote = cloneShared(st);
const local = cloneShared(st);
const killed = remote.jobs[0];
remote.jobs = remote.jobs.filter((j) => j.id !== killed.id);
const merged = threeWayMergeShop(st, local, remote);
const resurrected = merged.jobs.some((j) => j.id === killed.id);
note(
  resurrected ? "high" : "pass",
  "stale local re-creates a job the host deleted",
  { job: killed.partNumber, resurrected },
);

// ---- Sales tax ----
const soLines = [
  { item: "A", description: "A", rev: "A", qty: 10, rate: 100, amount: 1000, taxable: false },
  { item: "B", description: "B", rev: "A", qty: 1, rate: 50, amount: 50, taxable: false },
];
const tax = salesOrderTotals(soLines as any, 0.0825);
note(tax.tax > 0 ? "critical" : "pass", "all-NON lines still taxed", tax);

// ---- Material estimate extra bar ----
const est = estimateMaterialUnits({
  orderQty: 5,
  partLengthEach: 3,
  rawMaterialLength: 12,
});
note("info", "material estimate 5×3in from 12in bar", est);

// Buy list for the packed-but-open PO
const x698 = st.shopOrders.find((o) => o.poNumber === "PO-26-X698");
if (x698) {
  const buy = computeShopOrderBuyList(x698, st.materialStock);
  note("info", "PO-26-X698 buy list (packed, qty done 0)", buy);
}

// ---- Tooling never in unit price ----
const charges = normalizeToolingCharges([
  { kind: "soft_jaws", shopCost: 250, billCustomer: true, billQty: 1, billUnitPrice: 350, description: "Soft jaws" },
]);
const bills = toolingBillLines(charges);
const qTool = calculateQuoteCosts({
  rawMaterialCost: 10,
  totalSize: 10,
  partSize: 1,
  materialPercentage: 1,
  machineRate: 1,
  calculateMaterialDrop: false,
  setupTimes: [10],
  runTimesPerPart: [1],
  quantities: [1, 0, 0, 0, 0, 0],
});
note("pass", "tooling bill is separate from unit price", { unit: qTool.prices[0], bill: bills });

// ---- Workload double-count risk ----
const load = buildAssignWorkload({
  shopOrders: st.shopOrders,
  workQueue: st.workQueue,
  quotes: st.quotes,
});
note("info", "assign workload snapshot", {
  machines: load.machines.slice(0, 8),
  operators: load.operators.slice(0, 8),
});

mkdirSync("/workspace/lcm/sim-results", { recursive: true });
writeFileSync(
  "/workspace/lcm/sim-results/ts-module-sims.json",
  JSON.stringify({ at: new Date().toISOString(), findings }, null, 2),
);
console.log("TS sims", findings.length, "wrote ts-module-sims.json");
