import { mkdirSync } from "node:fs";
import { chromium } from "playwright";

const base = "http://127.0.0.1:8080";
mkdirSync("/workspace/screenshots", { recursive: true });

const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
const page = await browser.newPage({ viewport: { width: 1400, height: 900 } });
const errors = [];
page.on("pageerror", (err) => errors.push(String(err?.message || err)));
page.on("console", (msg) => {
  if (msg.type() === "error") errors.push(msg.text());
});

async function unlock() {
  const pin = page.locator("#switch-pin");
  if (await pin.count()) {
    await pin.fill("6283");
    await page.getByRole("button", { name: /^Unlock$/ }).click();
    await page.waitForTimeout(800);
  }
  const gotIt = page.getByRole("button", { name: /Got it|What’s new|Whats new/i });
  if (await gotIt.count()) {
    await gotIt.first().click({ force: true }).catch(() => {});
    await page.waitForTimeout(300);
  }
  await page.keyboard.press("Escape").catch(() => {});
  await page.evaluate(() => {
    document.querySelectorAll(".fixed.inset-0.z-50").forEach((el) => el.remove());
  });
}

await page.goto(`${base}/machines/haas-vf2-mill`, {
  waitUntil: "networkidle",
  timeout: 45000,
});
await unlock();
await page.waitForTimeout(1000);

// Pick an operator if the station is on You
const youSelect = page.locator("select").first();
if (await youSelect.count()) {
  const opts = await youSelect.locator("option").allTextContents();
  const pick = opts.find((o) => o.trim() && !/select|pick|name/i.test(o));
  if (pick) {
    await youSelect.selectOption({ label: pick });
    await page.waitForTimeout(400);
  }
}

const searchToggle = page.getByText("Search a part instead");
if (await searchToggle.count()) {
  await searchToggle.click();
  await page.waitForTimeout(200);
  const partInput = page.getByPlaceholder("e.g. AF-4421");
  await partInput.fill("15138-0028-01");
  const qty = page.getByPlaceholder("Qty");
  if (await qty.count()) await qty.fill("10");
  await page.getByRole("button", { name: /Search \/ Load job/ }).click();
  await page.waitForTimeout(1200);
}

const body = await page.locator("body").innerText();
const hasCheckbox = await page
  .getByText("Two vises, one cycle")
  .count();
if (hasCheckbox) {
  const box = page.locator("label").filter({ hasText: "Two vises, one cycle" }).locator("input");
  if (await box.count()) {
    await box.check({ force: true });
    await page.waitForTimeout(400);
  }
}

await page.screenshot({
  path: "/workspace/screenshots/two-vise-same-pn.png",
  fullPage: false,
});

const after = await page.locator("body").innerText();
await page.setViewportSize({ width: 390, height: 844 });
await page.waitForTimeout(400);
await page.screenshot({
  path: "/workspace/screenshots/two-vise-same-pn-mobile.png",
  fullPage: false,
});

console.log(
  JSON.stringify(
    {
      hasTwoVise: /Two vises, one cycle/i.test(body) || /Two vises, one cycle/i.test(after),
      samePartCopy: /vise 1 is OP1 of this part/i.test(after),
      startOp2: /Start OP2/i.test(after),
      startOp1: /Start OP1/i.test(after),
      errors: errors.slice(0, 12),
    },
    null,
    2,
  ),
);

await browser.close();
if (errors.length) process.exit(2);
if (!/Two vises, one cycle/i.test(body) && !/Two vises, one cycle/i.test(after)) {
  process.exit(3);
}
