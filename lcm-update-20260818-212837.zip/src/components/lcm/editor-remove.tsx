import { Trash2, Undo2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export function EditorHideButton({
  onHide,
  label = "Remove",
}: {
  onHide: () => void;
  label?: string;
}) {
  return (
    <Button
      size="sm"
      variant="outline"
      type="button"
      className="min-h-9"
      onClick={() => {
        if (
          !confirm(
            "Remove this from the board / queue? The customer PO stays. You can assign it again later from Customer Orders.",
          )
        ) {
          return;
        }
        onHide();
      }}
    >
      <Trash2 className="h-3.5 w-3.5" />
      {label}
    </Button>
  );
}

export function EditorReleaseButton({ onRelease }: { onRelease: () => void }) {
  return (
    <Button
      size="sm"
      variant="outline"
      type="button"
      className="min-h-9"
      onClick={() => {
        if (!confirm("Release this job? It stays on the board as open.")) return;
        onRelease();
      }}
    >
      <Undo2 className="h-3.5 w-3.5" />
      Release
    </Button>
  );
}
