import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import type { ShopOrder } from "@/lib/lcm/types";

export function AssignLineDialog({
  assignLine,
  selected,
  assignMachine,
  setAssignMachine,
  assignOperator,
  setAssignOperator,
  assignQty,
  setAssignQty,
  assignNotes,
  setAssignNotes,
  assignOpIndex,
  setAssignOpIndex,
  opChoices,
  machines,
  operatorNames,
  onClose,
  onAssign,
}: {
  assignLine: { lineId: string; partNumber: string; openQty: number };
  selected: ShopOrder;
  assignMachine: string;
  setAssignMachine: (v: string) => void;
  assignOperator: string;
  setAssignOperator: (v: string) => void;
  assignQty: string;
  setAssignQty: (v: string) => void;
  assignNotes: string;
  setAssignNotes: (v: string) => void;
  assignOpIndex: string;
  setAssignOpIndex: (v: string) => void;
  opChoices: { index: number; label: string; machine: string }[];
  machines: string[];
  operatorNames: string[];
  onClose: () => void;
  onAssign: () => void;
}) {
  return (
  <div
    className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-4 print:hidden"
    onClick={onClose}
  >
    <div
      className="relative z-[60] w-full max-w-md rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 space-y-3 shadow-xl"
      onClick={(e) => e.stopPropagation()}
    >
      <h2 className="text-lg font-semibold">Assign job</h2>
      <p className="text-sm text-[var(--color-muted)]">
        {assignLine.partNumber} · open qty {assignLine.openQty}. Pick who
        runs it (Job Board / My Jobs). Machine is optional — adds it to that
        machine’s queue.
        {opChoices.length
          ? " This quote uses more than one machine — pick one OP or leave All remaining."
          : ""}
      </p>
      {opChoices.length > 0 && (
        <div className="space-y-1.5">
          <Label>Operation</Label>
          <Select
            value={assignOpIndex}
            onChange={(e) => {
              const v = e.target.value;
              setAssignOpIndex(v);
              if (v !== "all") {
                const choice = opChoices.find((c) => String(c.index) === v);
                if (choice?.machine) setAssignMachine(choice.machine);
              }
            }}
          >
            <option value="all">All remaining ops</option>
            {opChoices.map((c) => (
              <option key={c.index} value={String(c.index)}>
                {c.label}
                {c.machine ? ` · ${c.machine}` : ""}
              </option>
            ))}
          </Select>
        </div>
      )}
      <div className="space-y-1.5">
        <Label>Operator</Label>
        <Select
          value={assignOperator}
          onChange={(e) => setAssignOperator(e.target.value)}
        >
          <option value="">Select operator</option>
          {operatorNames.map((n) => (
            <option key={n} value={n}>
              {n}
            </option>
          ))}
        </Select>
      </div>
      <div className="space-y-1.5">
        <Label>Machine (optional)</Label>
        <Select
          value={assignMachine}
          onChange={(e) => setAssignMachine(e.target.value)}
        >
          <option value="">No machine yet</option>
          {machines.map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </Select>
      </div>
      <div className="space-y-1.5">
        <Label>Qty to run</Label>
        <Input
          type="number"
          value={assignQty}
          onChange={(e) => setAssignQty(e.target.value)}
        />
      </div>
      <div className="space-y-1.5">
        <Label>Note</Label>
        <Input
          value={assignNotes}
          onChange={(e) => setAssignNotes(e.target.value)}
          placeholder="Op 2 only, heat treat first..."
        />
      </div>
      <div className="flex justify-end gap-2 pt-1">
        <Button variant="ghost" onClick={onClose}>
          Cancel
        </Button>
        <Button onClick={onAssign}>Assign job</Button>
      </div>
    </div>
  </div>
  );
}
