/** @deprecated Use GuidedMaterialForm — kept so old imports do not break. */
export {
  GuidedMaterialForm as GuidedStockFields,
  type GuidedMaterialValue as GuidedStockValue,
} from "./guided-material-form";
