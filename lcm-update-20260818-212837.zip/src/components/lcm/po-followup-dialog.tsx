import { useMemo, useState } from "react";
import { Copy, Mail, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label, Textarea } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useLcmStore } from "@/store/lcm-store";
import {
  customerToEmail,
  followupKindLabel,
  poFollowupPlainText,
  poFollowupSubject,
} from "@/lib/lcm/po-followup";
import { mailtoUrl } from "@/lib/lcm/quote-email";
import type { PoFollowupReport } from "@/lib/lcm/types";

export function PoFollowupDialog({
  report,
  onClose,
}: {
  report: PoFollowupReport;
  onClose: () => void;
}) {
  const customers = useLcmStore((s) => s.customers);
  const company = useLcmStore((s) => s.settings.companyName);
  const updatePoFollowup = useLcmStore((s) => s.updatePoFollowup);
  const logEmailSend = useLcmStore((s) => s.logEmailSend);

  const [to, setTo] = useState(
    () => customerToEmail(customers, report.customer) || "",
  );
  const [notes, setNotes] = useState(report.notes || "");

  const live: PoFollowupReport = useMemo(
    () => ({ ...report, notes }),
    [report, notes],
  );
  const subject = poFollowupSubject(live);
  const body = poFollowupPlainText(live, company || "Lake Country Machine");

  function markSent(method: "mailto" | "copy") {
    updatePoFollowup(report.id, {
      status: "sent",
      sentAt: new Date().toISOString(),
      sentTo: to.trim(),
      notes,
    });
    logEmailSend({
      customer: report.customer,
      toEmail: to.trim() || "(none)",
      subject,
      quoteIds: [],
      partNumbers: [
        ...new Set(report.issues.map((i) => i.partNumber).filter(Boolean)),
      ],
      method,
    });
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-3 sm:p-4 print:hidden"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 space-y-3 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div>
          <h2 className="text-lg font-semibold">Customer follow-up</h2>
          <p className="text-sm text-[var(--color-muted)] mt-0.5">
            PO {report.poNumber || "—"}
            {report.customer ? ` · ${report.customer}` : ""} ·{" "}
            {report.issues.length} item(s)
          </p>
        </div>
        <ul className="space-y-1.5 max-h-52 overflow-y-auto">
          {report.issues.map((i, idx) => (
            <li
              key={`${i.kind}-${i.partNumber}-${idx}`}
              className="rounded-[var(--radius-md)] border border-[var(--color-border)] px-2.5 py-1.5 text-sm"
            >
              <div className="flex flex-wrap items-center gap-1.5">
                <Badge tone="warn">{followupKindLabel(i.kind)}</Badge>
                {i.partNumber ? (
                  <span className="font-mono font-medium">{i.partNumber}</span>
                ) : null}
              </div>
              <div className="text-xs text-[var(--color-muted)] mt-0.5">
                {i.detail}
              </div>
            </li>
          ))}
        </ul>
        <div className="space-y-1.5">
          <Label>Send to</Label>
          <Input
            type="email"
            value={to}
            onChange={(e) => setTo(e.target.value)}
            placeholder="customer@email.com"
          />
        </div>
        <div className="space-y-1.5">
          <Label>Extra note (optional)</Label>
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={2}
          />
        </div>
        <div className="flex flex-wrap gap-2 pt-1">
          <Button
            onClick={() => {
              if (!to.trim()) {
                toast.error("Enter the customer email");
                return;
              }
              const url = mailtoUrl(to.trim(), subject, body);
              window.location.href = url;
              markSent("mailto");
              toast.success("Email drafted — send from your mail app");
            }}
          >
            <Mail className="h-4 w-4" /> Email customer
          </Button>
          <Button
            variant="outline"
            onClick={async () => {
              try {
                await navigator.clipboard.writeText(
                  `To: ${to}\nSubject: ${subject}\n\n${body}`,
                );
                markSent("copy");
                toast.success("Copied — paste into email");
              } catch {
                toast.error("Could not copy");
              }
            }}
          >
            <Copy className="h-4 w-4" /> Copy
          </Button>
          <Button
            variant="ghost"
            onClick={() => {
              updatePoFollowup(report.id, { status: "resolved", notes });
              toast.message("Marked resolved");
              onClose();
            }}
          >
            <CheckCircle2 className="h-4 w-4" /> Resolved
          </Button>
          <Button variant="ghost" onClick={onClose}>
            Close
          </Button>
        </div>
      </div>
    </div>
  );
}
