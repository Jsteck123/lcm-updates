import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useLcmStore } from "@/store/lcm-store";
import { materialLabel } from "@/lib/lcm/inventory";
import {
  HOLD_STALE_DAYS,
  holdAgeDays,
  holdIsStale,
  pendingHolds,
} from "@/lib/lcm/material-holds";

export function PendingHoldsPanel() {
  const holds = useLcmStore((s) => s.materialHolds || []);
  const stock = useLcmStore((s) => s.materialStock || []);
  const confirmMaterialHold = useLcmStore((s) => s.confirmMaterialHold);
  const releaseMaterialHold = useLcmStore((s) => s.releaseMaterialHold);
  const open = pendingHolds(holds);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Pending holds</CardTitle>
        <CardDescription>
          Spoken-for inches for open jobs. Book qty stays on the rack row;
          available is book minus these holds. The saw takes them off when it
          cuts. After {HOLD_STALE_DAYS} days we ask you to confirm the hold.
        </CardDescription>
      </CardHeader>
      <CardContent className="overflow-x-auto">
        <table className="w-full text-sm min-w-[720px]">
          <thead>
            <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
              <th className="pb-2 font-medium">Job</th>
              <th className="pb-2 font-medium">Stock</th>
              <th className="pb-2 font-medium">Hold</th>
              <th className="pb-2 font-medium">Age</th>
              <th className="pb-2 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {open.map((h) => {
              const row = stock.find((s) => s.id === h.stockId);
              const stale = holdIsStale(h);
              return (
                <tr
                  key={h.id}
                  className="border-b border-[var(--color-border)]/60"
                >
                  <td className="py-2 pr-2">
                    <div className="font-medium">{h.partNumber || "—"}</div>
                    <div className="text-xs text-[var(--color-muted)]">
                      PO {h.poNumber || "—"}
                    </div>
                  </td>
                  <td className="py-2 pr-2">
                    {row ? materialLabel(row) : "No rack row yet"}
                    {row?.sizeNote ? (
                      <div className="text-xs text-[var(--color-muted)]">
                        {row.sizeNote}
                      </div>
                    ) : null}
                  </td>
                  <td className="py-2 pr-2 tabular font-semibold">
                    {h.qty} {h.unit}
                  </td>
                  <td className="py-2 pr-2">
                    {holdAgeDays(h)}d
                    {stale ? (
                      <Badge tone="hold" className="ml-1">
                        Confirm
                      </Badge>
                    ) : null}
                  </td>
                  <td className="py-2">
                    <div className="flex flex-wrap gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        type="button"
                        onClick={() => {
                          const r = confirmMaterialHold(h.id);
                          if (!r.ok) toast.error(r.error);
                          else toast.success("Still holding for this job");
                        }}
                      >
                        Still hold
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        type="button"
                        onClick={() => {
                          const r = releaseMaterialHold(h.id);
                          if (!r.ok) toast.error(r.error);
                          else toast.message("Hold released — back to available");
                        }}
                      >
                        Release
                      </Button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {open.length === 0 && (
              <tr>
                <td
                  colSpan={5}
                  className="py-8 text-center text-[var(--color-muted)]"
                >
                  No pending holds. Mark stock OK on a PO or Request cut to
                  speak for inches.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </CardContent>
    </Card>
  );
}
