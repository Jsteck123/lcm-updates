import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { StockPiece } from "@/lib/lcm/types";
import { useLcmStore } from "@/store/lcm-store";

export function PiecesPanel({ stockPieces }: { stockPieces: StockPiece[] }) {
  const removeStockPieces = useLcmStore((s) => s.removeStockPieces);
  const [confirmAll, setConfirmAll] = useState(false);

  function removeOne(p: StockPiece) {
    const r = removeStockPieces([p.id]);
    if (r.ok) toast.message(`Removed ${p.barcode}`);
    else toast.error("Could not remove that piece");
  }

  function removeAll() {
    const r = removeStockPieces(stockPieces.map((p) => p.id));
    setConfirmAll(false);
    if (r.ok) toast.message(`Removed ${r.removed} barcoded pieces`);
    else toast.error("Nothing removed");
  }

  return (
  <Card>
    <CardHeader>
      <CardTitle>Barcoded pieces ({stockPieces.length})</CardTitle>
      <CardDescription>
        These are individual bars created when a PO line was received — one
        barcode per bar, so you can scan and cut length. They are not your
        Material on hand list. Receiving 21 of 4" × 12 ft Aluminum made these
        21 rows. Removing them does not change Material on hand.
      </CardDescription>
    </CardHeader>
    <CardContent className="overflow-x-auto">
      <div className="flex flex-wrap gap-2 mb-3 print:hidden">
        <Link
          to="/labels"
          search={{ ids: "", kind: "pieces" }}
          className="text-sm text-[var(--color-primary)] underline"
        >
          Print all available labels
        </Link>
        {stockPieces.length > 0 ? (
          confirmAll ? (
            <span className="flex flex-wrap items-center gap-2 text-sm">
              Remove all {stockPieces.length} pieces? On-hand qty stays.
              <Button size="sm" variant="danger" onClick={removeAll}>
                Yes, remove all
              </Button>
              <Button size="sm" variant="secondary" onClick={() => setConfirmAll(false)}>
                Cancel
              </Button>
            </span>
          ) : (
            <button
              type="button"
              className="text-sm text-[var(--color-danger)] underline"
              onClick={() => setConfirmAll(true)}
            >
              Remove all pieces
            </button>
          )
        ) : null}
      </div>
      <table className="w-full text-sm min-w-[720px]">
        <thead>
          <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
            <th className="pb-2 font-medium">Barcode</th>
            <th className="pb-2 font-medium">Material</th>
            <th className="pb-2 font-medium">Remaining</th>
            <th className="pb-2 font-medium">Location</th>
            <th className="pb-2 font-medium">Status</th>
            <th className="pb-2 font-medium">Actions</th>
          </tr>
        </thead>
        <tbody>
          {stockPieces.map((p) => (
            <tr key={p.id} className="border-b border-[var(--color-border)]/60">
              <td className="py-2 font-mono text-xs">{p.barcode}</td>
              <td className="py-2">
                {p.material} {p.materialType}
                <div className="text-xs text-[var(--color-muted)]">{p.sizeNote}</div>
              </td>
              <td className="py-2 tabular">
                {p.remainingLength}" / {p.originalLength}"
              </td>
              <td className="py-2">{p.location}</td>
              <td className="py-2">
                <Badge tone={p.status === "available" ? "success" : "neutral"}>
                  {p.status}
                </Badge>
              </td>
              <td className="py-2">
                <div className="flex gap-2">
                  <Link
                    to="/scan"
                    search={{ c: p.barcode }}
                    className="text-xs text-[var(--color-primary)] underline"
                  >
                    Scan / cut
                  </Link>
                  <Link
                    to="/labels"
                    search={{ ids: p.id, kind: "pieces" }}
                    className="text-xs text-[var(--color-primary)] underline"
                  >
                    Label
                  </Link>
                  <button
                    type="button"
                    className="text-xs text-[var(--color-danger)] underline"
                    onClick={() => removeOne(p)}
                  >
                    Remove
                  </button>
                </div>
              </td>
            </tr>
          ))}
          {stockPieces.length === 0 && (
            <tr>
              <td colSpan={6} className="py-8 text-center text-[var(--color-muted)]">
                No barcoded pieces — receive a PO line to create them.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </CardContent>
  </Card>
  );
}
