import { useEffect, useMemo, useState } from "react";
import { BookOpen, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { getPageHowTo } from "@/lib/lcm/howtos";
import type { HowToBlock } from "@/lib/lcm/howtos/types";
import { useLcmStore } from "@/store/lcm-store";
import { getOperatorByEmail } from "@/lib/lcm/permissions";

function Block({ b }: { b: HowToBlock }) {
  if (b.type === "p") {
    return <p className="text-sm leading-relaxed text-[var(--color-fg)]/90">{b.text}</p>;
  }
  if (b.type === "h") {
    return (
      <h4 className="text-sm font-semibold mt-4 first:mt-0 text-[var(--color-fg)]">
        {b.text}
      </h4>
    );
  }
  if (b.type === "ol") {
    return (
      <ol className="list-decimal pl-5 space-y-1.5 text-sm leading-relaxed text-[var(--color-fg)]/90">
        {b.items.map((it, i) => (
          <li key={`${i}-${it.slice(0, 48)}`}>{it}</li>
        ))}
      </ol>
    );
  }
  if (b.type === "ul") {
    return (
      <ul className="list-disc pl-5 space-y-1.5 text-sm leading-relaxed text-[var(--color-fg)]/90">
        {b.items.map((it, i) => (
          <li key={`${i}-${it.slice(0, 48)}`}>{it}</li>
        ))}
      </ul>
    );
  }
  if (b.type === "note") {
    return (
      <p className="text-sm leading-relaxed rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2">
        {b.text}
      </p>
    );
  }
  if (b.type === "warn") {
    return (
      <p className="text-sm leading-relaxed rounded-[var(--radius-md)] border border-[color-mix(in_oklab,var(--color-status-hold)_40%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-status-hold)_12%,transparent)] px-3 py-2">
        {b.text}
      </p>
    );
  }
  return (
    <div className="grid grid-cols-1 sm:grid-cols-[minmax(8rem,12rem)_1fr] gap-1 sm:gap-3 text-sm py-2 border-b border-[var(--color-border)]/60 last:border-0">
      <div className="font-semibold">{b.name}</div>
      <div className="text-[var(--color-fg)]/90 leading-relaxed">{b.does}</div>
    </div>
  );
}

export function PageHowTo({
  id,
  className,
  defaultOpen = false,
}: {
  id: string;
  className?: string;
  defaultOpen?: boolean;
}) {
  const doc = getPageHowTo(id);
  const email = useLcmStore((s) => s.currentUserEmail);
  const operators = useLcmStore((s) => s.operators);
  const me = useMemo(
    () => getOperatorByEmail(operators, email),
    [operators, email],
  );
  const isAdmin = me?.role === "admin";
  const [open, setOpen] = useState(defaultOpen);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (window.location.hash === `#howto-${id}`) setOpen(true);
  }, [id]);

  if (!doc) return null;
  if (doc.audience === "admin" && !isAdmin) return null;

  return (
    <>
      <Button
        type="button"
        variant="outline"
        size="sm"
        className={cn("shrink-0", className)}
        onClick={() => setOpen(true)}
      >
        <BookOpen className="h-4 w-4" />
        How to use this page
      </Button>
      {open ? (
        <div
          className="fixed inset-0 z-[80] flex items-end sm:items-stretch sm:justify-end bg-black/55"
          onClick={() => setOpen(false)}
        >
          <aside
            className="w-full sm:max-w-xl h-[92vh] sm:h-full bg-[var(--color-surface)] border-t sm:border-t-0 sm:border-l border-[var(--color-border)] shadow-xl flex flex-col"
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-labelledby={`howto-title-${id}`}
          >
            <header className="shrink-0 px-4 py-3 border-b border-[var(--color-border)] flex items-start justify-between gap-3">
              <div>
                <div className="text-[11px] uppercase tracking-wide text-[var(--color-muted)]">
                  How to use this page
                </div>
                <h2
                  id={`howto-title-${id}`}
                  className="text-lg font-semibold tracking-tight"
                >
                  {doc.title}
                </h2>
              </div>
              <button
                type="button"
                className="h-11 w-11 inline-flex items-center justify-center rounded-[var(--radius-md)] hover:bg-[var(--color-surface-2)]"
                onClick={() => setOpen(false)}
                aria-label="Close how to"
              >
                <X className="h-5 w-5" />
              </button>
            </header>
            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-6">
              <p className="text-sm leading-relaxed text-[var(--color-fg)]">
                {doc.whatThisPageIs}
              </p>
              {doc.sections.map((sec) => (
                <section key={sec.title} className="space-y-2.5">
                  <h3 className="text-base font-semibold border-b border-[var(--color-border)] pb-1">
                    {sec.title}
                  </h3>
                  {sec.blocks.map((b, i) => (
                    <Block key={sec.title + i} b={b} />
                  ))}
                </section>
              ))}
            </div>
          </aside>
        </div>
      ) : null}
    </>
  );
}

export function PageHowToInline({
  id,
  hideHeader = false,
}: {
  id: string;
  hideHeader?: boolean;
}) {
  const doc = getPageHowTo(id);
  if (!doc) return null;
  return (
    <article className="space-y-6">
      {hideHeader ? null : (
        <div>
          <h2 className="text-xl font-semibold tracking-tight">{doc.title}</h2>
          <p className="text-sm leading-relaxed text-[var(--color-muted)] mt-2">
            {doc.whatThisPageIs}
          </p>
        </div>
      )}
      {hideHeader ? (
        <p className="text-sm leading-relaxed text-[var(--color-fg)]">
          {doc.whatThisPageIs}
        </p>
      ) : null}
      {doc.sections.map((sec) => (
        <section key={sec.title} className="space-y-2.5">
          <h3 className="text-base font-semibold border-b border-[var(--color-border)] pb-1">
            {sec.title}
          </h3>
          {sec.blocks.map((b, i) => (
            <Block key={sec.title + i} b={b} />
          ))}
        </section>
      ))}
    </article>
  );
}
