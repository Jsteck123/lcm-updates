import { Factory, Gauge, Target, TrendingUp } from "lucide-react";
import { useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useFloorPulse } from "@/hooks/use-floor-pulse";
import {
  jobPulseFromSession,
  type JobPulseView,
  type PersonPulse,
  type PulseTone,
  type ShopPulse,
} from "@/lib/lcm/floor-pulse";
import type { ShopStatus } from "@/lib/lcm/status-colors";
import { statusToBadgeTone } from "@/lib/lcm/status-colors";
import type { MachineSession } from "@/lib/lcm/types";
import { cn, formatCurrency, formatDurationShort } from "@/lib/utils";

function pulseMoney(n: number): string {
  if (!Number.isFinite(n) || n <= 0) return "";
  if (n >= 100) {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 0,
    }).format(n);
  }
  return formatCurrency(n);
}

function PulseBar({
  fill,
  tone = "primary",
}: {
  fill: number;
  tone?:
    | "primary"
    | "accent"
    | "success"
    | "warn"
    | "danger"
    | "overdue"
    | "soon"
    | "active"
    | "open"
    | "done";
}) {
  const pct = Math.round(Math.min(1, Math.max(0, fill)) * 100);
  return (
    <div className="h-2.5 rounded-full bg-[var(--color-surface-3)] overflow-hidden">
      <div
        className={cn(
          "h-full rounded-full transition-[width] duration-300 ease-out",
          tone === "accent" && "bg-[var(--color-accent)]",
          tone === "success" && "bg-[var(--color-success)]",
          tone === "primary" && "bg-[var(--color-primary)]",
          tone === "warn" && "bg-[var(--color-warn)]",
          tone === "danger" && "bg-[var(--color-danger)]",
          tone === "overdue" && "bg-[var(--color-status-overdue)]",
          tone === "soon" && "bg-[var(--color-status-soon)]",
          tone === "active" && "bg-[var(--color-status-active)]",
          tone === "open" && "bg-[var(--color-status-open)]",
          tone === "done" && "bg-[var(--color-status-done)]",
        )}
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

function countBarTone(
  tone: ShopStatus,
): "primary" | "overdue" | "soon" | "active" | "open" | "done" {
  if (tone === "overdue") return "overdue";
  if (tone === "soon") return "soon";
  if (tone === "active") return "active";
  if (tone === "done") return "done";
  if (tone === "open") return "open";
  return "primary";
}

function lastUpdatedLabel(ageSec: number): string {
  const s = Math.max(0, Math.round(ageSec || 0));
  if (s < 60) return "just now";
  return `${formatDurationShort(s)} ago`;
}

function CountMark({ job }: { job: JobPulseView }) {
  if (job.countTone === "overdue") {
    return (
      <span className="text-[var(--color-status-overdue)]">
        . Stale — last updated {lastUpdatedLabel(job.countAgeSec)}
      </span>
    );
  }
  if (job.countTone === "soon") {
    return <span className="text-[var(--color-status-soon)]"> · tap</span>;
  }
  if (job.live) {
    return <span className="text-[var(--color-status-active)]"> · live</span>;
  }
  return null;
}

function toneBar(tone: PulseTone): "primary" | "accent" | "success" {
  if (tone === "locked") return "success";
  if (tone === "pace") return "accent";
  return "primary";
}

function ShopFigures({ shop }: { shop: ShopPulse }) {
  const week = shop.weekTotal > 0.5 ? pulseMoney(shop.weekTotal) : "";
  const avg = shop.avgBonus > 0.5 ? pulseMoney(shop.avgBonus) : "";
  const today = shop.todayPace > 0.5 ? pulseMoney(shop.todayPace) : "";
  return (
    <div className="grid grid-cols-2 gap-3">
      <div>
        <div className="text-xs text-[var(--color-muted)]">Shop week</div>
        <div className="text-xl font-semibold tracking-tight tabular">
          {week || "—"}
        </div>
        <div className="text-xs text-[var(--color-subtle)]">
          {week ? "Locked + live on pace" : "Fills as days lock"}
        </div>
      </div>
      <div>
        <div className="text-xs text-[var(--color-muted)]">Avg bonus</div>
        <div className="text-xl font-semibold tracking-tight tabular">
          {avg || "—"}
        </div>
        <div className="text-xs text-[var(--color-subtle)]">
          {today
            ? `${today} on pace today`
            : shop.peopleClocked
              ? `${shop.peopleClocked} on the clock`
              : "First clock starts it"}
        </div>
      </div>
    </div>
  );
}

export function ShopPulseCard({ className }: { className?: string }) {
  const { shop } = useFloorPulse();
  return (
    <Card className={className}>
      <CardContent className="p-4 sm:p-5 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-[var(--color-muted)]">
              <Factory className="h-3.5 w-3.5" />
              Shop pulse
            </div>
            <p className="mt-1 text-sm font-medium">{shop.line}</p>
            <p className="text-xs text-[var(--color-muted)]">{shop.hint}</p>
          </div>
        </div>
        <ShopFigures shop={shop} />
        {shop.peopleClocked > 0 && (
          <div>
            <div className="flex justify-between text-xs text-[var(--color-muted)] mb-1">
              <span>Shift through the floor</span>
              <span className="tabular">
                {Math.round(shop.avgShiftFill * 100)}%
              </span>
            </div>
            <PulseBar
              fill={shop.avgShiftFill}
              tone={shop.peopleOnPace >= shop.peopleClocked / 2 ? "accent" : "primary"}
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function MyDayPulse({
  operatorName,
  compact = false,
  className,
}: {
  operatorName?: string;
  compact?: boolean;
  className?: string;
}) {
  const { me } = useFloorPulse({ operatorName });
  return (
    <MyDayPulseView me={me} compact={compact} className={className} />
  );
}

export function MyDayPulseView({
  me,
  compact = false,
  bare = false,
  className,
}: {
  me: PersonPulse;
  compact?: boolean;
  bare?: boolean;
  className?: string;
}) {
  const money = me.showMoney ? pulseMoney(me.pace) : "";
  const showBar = me.tone !== "quiet";
  const body = (
    <div className={cn("space-y-3", !bare && (compact ? "p-3.5" : "p-4 sm:p-5"), className)}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-[var(--color-muted)]">
            <Gauge className="h-3.5 w-3.5" />
            {me.name ? `${me.name.split(" ")[0]} · day` : "Your day"}
          </div>
          <p className="mt-1 text-sm font-medium">{me.line}</p>
          {!compact && (
            <p className="text-xs text-[var(--color-muted)]">{me.hint}</p>
          )}
        </div>
        {money ? (
          <div className="text-right shrink-0">
            <div className="text-xs text-[var(--color-muted)]">Possible</div>
            <div className="text-lg font-semibold tabular text-[var(--color-accent)]">
              {money}
            </div>
          </div>
        ) : null}
      </div>
      {showBar && (
        <div>
          <div className="flex justify-between text-xs text-[var(--color-muted)] mb-1">
            <span>Shift</span>
            <span className="tabular">
              {me.onShiftHours.toFixed(1)} / {me.requiredHours.toFixed(1)} h
            </span>
          </div>
          <PulseBar fill={me.shiftFill} tone={toneBar(me.tone)} />
        </div>
      )}
    </div>
  );
  if (bare) return body;
  return <Card>{body}</Card>;
}

export function JobPulseViewCard({
  job,
  className,
  compact = false,
}: {
  job: JobPulseView;
  className?: string;
  compact?: boolean;
}) {
  const remain =
    [job.remainLine, job.etaLine].filter(Boolean).join(" · ") || "";
  return (
    <div className={cn("space-y-2", !compact && "space-y-3", className)}>
      <div>
        <div className="flex justify-between text-xs text-[var(--color-muted)] mb-1">
          <span className="truncate pr-2">
            {compact ? "Ran" : job.partNumber}
            <CountMark job={job} />
          </span>
          <Badge
            tone={statusToBadgeTone(job.countTone)}
            className="tabular shrink-0 px-2 py-0 text-[11px]"
          >
            {job.done} / {job.qty || "—"}
          </Badge>
        </div>
        <PulseBar fill={job.fill} tone={countBarTone(job.countTone)} />
        {job.countHint ? (
          <div
            className={cn(
              "text-[11px] mt-1",
              job.countTone === "overdue"
                ? "text-[var(--color-status-overdue)]"
                : job.countTone === "soon"
                  ? "text-[var(--color-status-soon)]"
                  : "text-[var(--color-muted)]",
            )}
          >
            {job.countHint}
          </div>
        ) : null}
      </div>
      {job.pair && !compact && (
        <div>
          <div className="flex justify-between text-xs text-[var(--color-muted)] mb-1">
            <span className="truncate pr-2">{job.pair.partNumber}</span>
            <Badge
              tone={statusToBadgeTone(job.countTone)}
              className="tabular shrink-0 px-2 py-0 text-[11px]"
            >
              {job.pair.done} / {job.pair.qty || "—"}
            </Badge>
          </div>
          <PulseBar fill={job.pair.fill} tone={countBarTone(job.countTone)} />
        </div>
      )}
      {remain ? (
        <div className="text-xs text-[var(--color-muted)] tabular">{remain}</div>
      ) : null}
      {job.showTime && (
        <div>
          <div className="flex justify-between text-xs text-[var(--color-muted)] mb-1">
            <span>{job.timeLine}</span>
            <span className="tabular">
              {Math.round(job.timeFill * 100)}% of quoted
            </span>
          </div>
          <PulseBar fill={job.timeFill} tone={job.timeTone} />
        </div>
      )}
    </div>
  );
}

/** Compact ran/qty + completion + ETA for floor cards and the job board. */
export function JobProgressStrip({
  job,
  className,
}: {
  job: JobPulseView;
  className?: string;
}) {
  return (
    <div className={cn("print:hidden", className)}>
      <JobPulseViewCard job={job} compact />
    </div>
  );
}

export function StationPulse({
  operatorName,
  session,
  liveSeconds,
}: {
  operatorName?: string;
  session?: MachineSession;
  liveSeconds?: number | null;
}) {
  const { me } = useFloorPulse({ operatorName });
  const job = useMemo(
    () => jobPulseFromSession(session, liveSeconds),
    [session, liveSeconds],
  );
  return (
    <Card>
      <CardContent className="p-4 space-y-4">
        {job ? (
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-[var(--color-muted)]">
              <Target className="h-3.5 w-3.5" />
              This job
            </div>
            <JobPulseViewCard job={job} />
          </div>
        ) : (
          <p className="text-sm text-[var(--color-muted)]">
            Load a job — pieces fill this bar as you run.
          </p>
        )}
        <div className="border-t border-[var(--color-border)] pt-3">
          <MyDayPulseView me={me} compact bare />
        </div>
      </CardContent>
    </Card>
  );
}

export function FloorPulseStrip({
  operatorName,
  className,
}: {
  operatorName?: string;
  className?: string;
}) {
  const { shop, me } = useFloorPulse({ operatorName });
  const week = shop.weekTotal > 0.5 ? pulseMoney(shop.weekTotal) : "";
  const mine = me.showMoney ? pulseMoney(me.pace) : "";
  return (
    <div
      className={cn(
        "rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-surface)] px-3 py-2.5 sm:px-4",
        className,
      )}
    >
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
        <div className="min-w-0 flex-1">
          <div className="text-xs text-[var(--color-muted)]">
            {shop.line}
            {week ? (
              <span className="text-[var(--color-fg)] font-medium">
                {" "}
                · week {week}
              </span>
            ) : null}
          </div>
          <div className="text-sm font-medium truncate">
            {me.line}
            {mine ? (
              <span className="text-[var(--color-accent)]"> · {mine}</span>
            ) : null}
          </div>
        </div>
        {me.tone !== "quiet" && (
          <div className="w-full sm:w-40">
            <PulseBar fill={me.shiftFill} tone={toneBar(me.tone)} />
          </div>
        )}
      </div>
    </div>
  );
}

export function HeaderPulseChip() {
  const { shop, me } = useFloorPulse({ intervalMs: 4000 });
  const week = shop.weekTotal > 0.5 ? pulseMoney(shop.weekTotal) : "";
  const mine = me.showMoney ? pulseMoney(me.pace) : "";
  if (!week && !mine && me.tone === "quiet" && shop.peopleClocked === 0) {
    return null;
  }
  const label = week
    ? `Shop ${week}`
    : mine
      ? `Today ${mine}`
      : shop.peopleClocked
        ? shop.line
        : me.line;
  return (
    <span
      className="hidden sm:inline-flex items-center gap-1.5 rounded-full border border-[var(--color-border)] px-2.5 py-1 text-[11px] font-medium text-[var(--color-fg)] min-h-9 max-w-[12rem] truncate"
      title={`${shop.line}. ${me.line}${mine ? ` Possible ${mine}` : ""}`}
    >
      <TrendingUp className="h-3.5 w-3.5 text-[var(--color-accent)] shrink-0" />
      <span className="truncate">{label}</span>
    </span>
  );
}
