/**
 * Guided Master Quoter entry — prescribed popups, Tab/Enter to advance.
 * Order: customer → part → rev → part/assembly → machines → machine% → material → type →
 * material% → stock shape → cross-section/cut dims → raw $ → drop →
 * OP setup/run… → qty 1–6 → preview → save.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import { MultiSelect } from "@/components/ui/multi-select";
import { SmartNumberInput } from "@/components/ui/smart-number-input";
import { Typeahead } from "@/components/ui/typeahead";
import { profileForShape, type DimKey } from "@/lib/lcm/stock-shapes";
import type { MaterialPriceEntry } from "@/lib/lcm/material-rates";
import type { Quote } from "@/lib/lcm/types";
import { formatCurrency } from "@/lib/utils";
import { opLabel } from "@/lib/lcm/ops";

export type QuoteFormState = Partial<Quote> & {
  partNumber: string;
  setupTimes: number[];
  runTimes: number[];
  quantities: number[];
};

type WizardId =
  | "customer"
  | "partNumber"
  | "revision"
  | "quoteKind"
  | "machines"
  | "machineRate"
  | "material"
  | "materialType"
  | "materialPct"
  | "stockShape"
  | "dims"
  | "rawMaterialCost"
  | "materialDrop"
  | "ops"
  | "quantities"
  | "preview";

const STEP_META: { id: WizardId; title: string; blurb: string }[] = [
  { id: "customer", title: "Customer", blurb: "Who is this quote for?" },
  { id: "partNumber", title: "Part number", blurb: "Shop part # (loads DB match if known)." },
  { id: "revision", title: "Revision", blurb: "Drawing / part rev." },
  {
    id: "quoteKind",
    title: "Quote type",
    blurb: "Single part or assembly (BOM / bolt-up).",
  },
  { id: "machines", title: "Machine(s)", blurb: "Every machine this job may run on. 1st = preferred." },
  { id: "machineRate", title: "Machine %", blurb: "1 = actual · 1.25 = 25% markup on run." },
  { id: "material", title: "Material", blurb: "Base material family (Aluminum, Steel…)." },
  { id: "materialType", title: "Material type", blurb: "Alloy / temper (e.g. T6 6061)." },
  { id: "materialPct", title: "Material %", blurb: "1 = actual · 1.15 = 15% markup on material." },
  { id: "stockShape", title: "Stock shape", blurb: "Round, hex, flat, plate… drives size fields next." },
  { id: "dims", title: "Stock sizes", blurb: "Cross-section and cut / bar length for this shape." },
  { id: "rawMaterialCost", title: "Raw material cost", blurb: "Full stick $ — type it or estimate from price book." },
  { id: "materialDrop", title: "Material drop", blurb: "Charge leftover bar/sheet into the part price?" },
  { id: "ops", title: "Operations", blurb: "Setup then runtime per OP. Done when ops are filled." },
  { id: "quantities", title: "Quantity breaks", blurb: "Qty levels 1–6 for price breaks." },
  { id: "preview", title: "Preview", blurb: "Review costs, then save or update." },
];

type Props = {
  open: boolean;
  onClose: () => void;
  form: QuoteFormState;
  setForm: React.Dispatch<React.SetStateAction<QuoteFormState>>;
  maxOps: number;
  customerOptions: string[];
  machineOptions: string[];
  materialOptions: string[];
  typeOptions: string[];
  stockShapeOptions: string[];
  materialPriceBook: MaterialPriceEntry[];
  costs: {
    materialCostWithPct: number;
    setupCost: number;
    runCost: number;
    baseTotal: number;
    prices: number[];
    bomCost?: number;
    benchCost?: number;
  };
  loadedId: string | null;
  onPartChange: (value: string) => void;
  partQuery: string;
  onAddCustomer: (name: string) => boolean | void;
  onAddMachine: (name: string) => void;
  onAddMaterial: (name: string) => void;
  onAddMaterialType: (name: string) => void;
  onAddStockShape: (name: string) => void;
  onSave: (mode: "submit" | "update") => void;
  onApplyBookEstimate: () => void;
  bookEstimateOk: boolean;
  bookEstimateLine: string;
};

export function QuoteWizard({
  open,
  onClose,
  form,
  setForm,
  maxOps,
  customerOptions,
  machineOptions,
  materialOptions,
  typeOptions,
  stockShapeOptions,
  materialPriceBook: _book,
  costs,
  loadedId,
  onPartChange,
  partQuery,
  onAddCustomer,
  onAddMachine,
  onAddMaterial,
  onAddMaterialType,
  onAddStockShape,
  onSave,
  onApplyBookEstimate,
  bookEstimateOk,
  bookEstimateLine,
}: Props) {
  const [stepIdx, setStepIdx] = useState(0);
  /** Which OP we're on (0-based); kind setup first then runtime */
  const [opIndex, setOpIndex] = useState(0);
  const [opKind, setOpKind] = useState<"setup" | "runtime">("setup");
  const inputRef = useRef<HTMLInputElement | null>(null);

  const step = STEP_META[stepIdx] || STEP_META[0]!;
  const shapeProfile = profileForShape(form.stockShape || "");
  const dimFields = useMemo(
    () => [...shapeProfile.section, ...shapeProfile.cut],
    [shapeProfile],
  );
  const selectedMachines = (form.machines || [])
    .map((m) => String(m || "").trim())
    .filter(Boolean);

  useEffect(() => {
    if (!open) return;
    // focus primary field shortly after step change
    const t = setTimeout(() => {
      const el =
        document.querySelector<HTMLInputElement>(
          "[data-wizard-focus='1'] input, [data-wizard-focus='1'] button, input[data-wizard-focus='1'], select[data-wizard-focus='1']",
        ) || document.querySelector<HTMLInputElement>("[data-wizard-focus='1']");
      el?.focus?.();
    }, 40);
    return () => clearTimeout(t);
  }, [open, stepIdx, opIndex, opKind]);

  if (!open) return null;

  function goNext() {
    if (step.id === "ops") {
      // advance op setup → runtime → next op
      if (opKind === "setup") {
        setOpKind("runtime");
        return;
      }
      if (opIndex + 1 < maxOps) {
        setOpIndex(opIndex + 1);
        setOpKind("setup");
        return;
      }
      // last op runtime done
      setStepIdx((i) => Math.min(i + 1, STEP_META.length - 1));
      return;
    }
    setStepIdx((i) => Math.min(i + 1, STEP_META.length - 1));
    if (STEP_META[stepIdx + 1]?.id === "ops") {
      setOpIndex(0);
      setOpKind("setup");
    }
  }

  function goBack() {
    if (step.id === "ops") {
      if (opKind === "runtime") {
        setOpKind("setup");
        return;
      }
      if (opIndex > 0) {
        setOpIndex(opIndex - 1);
        setOpKind("runtime");
        return;
      }
    }
    setStepIdx((i) => Math.max(i - 1, 0));
  }

  function finishOpsEarly() {
    // jump to quantities
    const qi = STEP_META.findIndex((s) => s.id === "quantities");
    if (qi >= 0) setStepIdx(qi);
  }

  function onEnterAdvance() {
    goNext();
  }

  const progress = ((stepIdx + 1) / STEP_META.length) * 100;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-3 sm:p-4 print:hidden"
      role="dialog"
      aria-modal="true"
      aria-labelledby="quote-wizard-title"
      onKeyDown={(e) => {
        if (e.key === "Escape") {
          e.stopPropagation();
          onClose();
        }
      }}
    >
      <div
        className="w-full max-w-lg max-h-[92vh] overflow-y-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] shadow-xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-2 px-4 pt-4 pb-2 border-b border-[var(--color-border)]">
          <div className="min-w-0">
            <div className="text-[11px] uppercase tracking-wide text-[var(--color-muted)] font-semibold">
              Guided quote · step {stepIdx + 1} of {STEP_META.length}
            </div>
            <h2 id="quote-wizard-title" className="text-lg font-semibold truncate">
              {step.title}
              {step.id === "ops"
                ? ` · ${opLabel(opIndex)} ${opKind === "setup" ? "Setup" : "Runtime"}`
                : ""}
            </h2>
            <p className="text-xs text-[var(--color-muted)] mt-0.5">{step.blurb}</p>
          </div>
          <button
            type="button"
            className="shrink-0 rounded-md p-2 hover:bg-[var(--color-surface-2)]"
            onClick={onClose}
            aria-label="Close wizard"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="h-1 bg-[var(--color-surface-2)]">
          <div
            className="h-full bg-[var(--color-primary)] transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="px-4 py-4 space-y-3 flex-1" data-wizard-focus="1">
          {step.id === "customer" && (
            <div className="space-y-1.5">
              <Label>Customer</Label>
              <Typeahead
                autoFocus
                value={form.customer || ""}
                options={customerOptions}
                onChange={(v) => setForm((f) => ({ ...f, customer: v }))}
                onCreate={(v) => {
                  onAddCustomer(v);
                }}
                onEnterAfterCommit={onEnterAdvance}
                placeholder="Start typing customer…"
                allowCustom
              />
              <p className="text-[11px] text-[var(--color-subtle)]">
                Type-ahead · arrows · Enter to pick / next
              </p>
            </div>
          )}

          {step.id === "partNumber" && (
            <div className="space-y-1.5">
              <Label>Part number</Label>
              <Input
                ref={inputRef}
                autoFocus
                value={partQuery || form.partNumber || ""}
                onChange={(e) => onPartChange(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    onEnterAdvance();
                  }
                }}
                className="font-mono text-lg"
                placeholder="e.g. AF-4421"
              />
              <p className="text-[11px] text-[var(--color-subtle)]">
                Known parts load from the database automatically.
              </p>
            </div>
          )}

          {step.id === "revision" && (
            <div className="space-y-1.5">
              <Label>Revision</Label>
              <Input
                autoFocus
                value={form.revision || ""}
                onChange={(e) =>
                  setForm((f) => ({
                    ...f,
                    revision: e.target.value.toUpperCase(),
                  }))
                }
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    onEnterAdvance();
                  }
                }}
                className="text-lg uppercase"
                placeholder="A"
              />
            </div>
          )}

          {step.id === "quoteKind" && (
            <div className="space-y-3">
              <Label>Quote type</Label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  type="button"
                  autoFocus
                  className={
                    "rounded-[var(--radius-md)] border px-3 py-4 text-left min-h-14 " +
                    ((form.kind || "part") !== "assembly"
                      ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)]"
                      : "border-[var(--color-border)] hover:bg-[var(--color-surface-2)]")
                  }
                  onClick={() => {
                    setForm((f) => ({
                      ...f,
                      kind: "part",
                      bom: [],
                      benchAssembleMinutes: 0,
                    }));
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      setForm((f) => ({
                        ...f,
                        kind: "part",
                        bom: [],
                        benchAssembleMinutes: 0,
                      }));
                      onEnterAdvance();
                    }
                  }}
                >
                  <div className="font-semibold">Single part</div>
                  <div className="text-xs text-[var(--color-muted)] mt-0.5">
                    One part # · material · machine ops
                  </div>
                </button>
                <button
                  type="button"
                  className={
                    "rounded-[var(--radius-md)] border px-3 py-4 text-left min-h-14 " +
                    (form.kind === "assembly"
                      ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)]"
                      : "border-[var(--color-border)] hover:bg-[var(--color-surface-2)]")
                  }
                  onClick={() => {
                    setForm((f) => ({ ...f, kind: "assembly" }));
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      setForm((f) => ({ ...f, kind: "assembly" }));
                      onEnterAdvance();
                    }
                  }}
                >
                  <div className="font-semibold">Assembly</div>
                  <div className="text-xs text-[var(--color-muted)] mt-0.5">
                    BOM children · bench bolt · final ops
                  </div>
                </button>
              </div>
              <p className="text-[11px] text-[var(--color-subtle)]">
                Selected:{" "}
                <strong className="text-[var(--color-fg)]">
                  {form.kind === "assembly" ? "Assembly" : "Single part"}
                </strong>
                . You can edit BOM on the full form after preview if needed.
              </p>
            </div>
          )}

          {step.id === "machines" && (
            <div className="space-y-1.5">
              <Label>Machines</Label>
              <MultiSelect
                value={selectedMachines}
                options={machineOptions}
                onChange={(next) => {
                  for (const name of next) {
                    if (
                      !machineOptions.some(
                        (o) => o.toLowerCase() === name.toLowerCase(),
                      )
                    ) {
                      onAddMachine(name);
                    }
                  }
                  setForm((f) => ({
                    ...f,
                    machines: next.map((s) => s.trim()).filter(Boolean),
                  }));
                }}
                placeholder="Select one or more…"
                allowCreate
                allowReorder
              />
            </div>
          )}

          {step.id === "machineRate" && (
            <div className="space-y-1.5">
              <Label>Machine %</Label>
              <SmartNumberInput
                key="wiz-machineRate"
                autoFocus
                value={form.machineRate ?? 0}
                onValueChange={(n) =>
                  setForm((f) => ({ ...f, machineRate: n || 0 }))
                }
                format="plain"
                emptyMeans={0}
                onEnter={onEnterAdvance}
                className="text-lg"
                placeholder="e.g. 1 or 1.25"
              />
            </div>
          )}

          {step.id === "material" && (
            <div className="space-y-1.5">
              <Label>Material</Label>
              <Typeahead
                autoFocus
                value={form.material || ""}
                options={materialOptions}
                onChange={(v) =>
                  setForm((f) => ({
                    ...f,
                    material: v,
                    // clear type only when material family text changes away
                    materialType:
                      v.toLowerCase() === (f.material || "").toLowerCase()
                        ? f.materialType
                        : "",
                  }))
                }
                onCreate={(v) => onAddMaterial(v)}
                onEnterAfterCommit={onEnterAdvance}
                placeholder="Aluminum, Steel…"
                allowCustom
              />
            </div>
          )}

          {step.id === "materialType" && (
            <div className="space-y-1.5">
              <Label>Material type</Label>
              <Typeahead
                autoFocus
                value={form.materialType || ""}
                options={typeOptions}
                onChange={(v) => setForm((f) => ({ ...f, materialType: v }))}
                onCreate={(v) => onAddMaterialType(v)}
                onEnterAfterCommit={onEnterAdvance}
                placeholder="T6 6061, 4140…"
                allowCustom
              />
            </div>
          )}

          {step.id === "materialPct" && (
            <div className="space-y-1.5">
              <Label>Material %</Label>
              <SmartNumberInput
                key="wiz-materialPct"
                autoFocus
                value={form.materialPct ?? 0}
                onValueChange={(n) =>
                  setForm((f) => ({ ...f, materialPct: n || 0 }))
                }
                format="plain"
                emptyMeans={0}
                onEnter={onEnterAdvance}
                className="text-lg"
                placeholder="e.g. 1 or 1.15"
              />
            </div>
          )}

          {step.id === "stockShape" && (
            <div className="space-y-1.5">
              <Label>Stock shape</Label>
              <Typeahead
                autoFocus
                value={form.stockShape || ""}
                options={stockShapeOptions}
                onChange={(v) => {
                  const prev = form.stockShape || "";
                  if (v.toLowerCase() === prev.toLowerCase()) {
                    setForm((f) => ({ ...f, stockShape: v }));
                    return;
                  }
                  setForm((f) => ({
                    ...f,
                    stockShape: v,
                    dimX: 0,
                    dimY: 0,
                    dimZ: 0,
                    partLengthEach: 0,
                    rawMaterialLength: 0,
                    rawMaterialCost: 0,
                  }));
                }}
                onCreate={(v) => onAddStockShape(v)}
                onEnterAfterCommit={onEnterAdvance}
                placeholder="Round Stock, Hex…"
                allowCustom
              />
              {form.stockShape ? (
                <p className="text-[11px] text-[var(--color-muted)]">
                  {shapeProfile.title}: {shapeProfile.summary}
                </p>
              ) : null}
            </div>
          )}

          {step.id === "dims" && (
            <div className="space-y-3">
              {dimFields.length === 0 ? (
                <p className="text-sm text-[var(--color-muted)]">
                  No size fields for this shape — continue.
                </p>
              ) : (
                dimFields.map((field, i) => (
                  <div key={field.key} className="space-y-1.5">
                    <Label>{field.label}</Label>
                    <SmartNumberInput
                      key={`dim-${field.key}-${form.stockShape || ""}`}
                      autoFocus={i === 0}
                      value={Number(form[field.key as DimKey]) || 0}
                      onValueChange={(n) =>
                        setForm((f) => ({ ...f, [field.key]: n }))
                      }
                      format="inches"
                      onEnter={() => {
                        if (i === dimFields.length - 1) onEnterAdvance();
                      }}
                      placeholder="Size…"
                    />
                    {field.hint ? (
                      <p className="text-[11px] text-[var(--color-subtle)]">
                        {field.hint}
                      </p>
                    ) : null}
                  </div>
                ))
              )}
            </div>
          )}

          {step.id === "rawMaterialCost" && (
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label>Raw material cost (full stick)</Label>
                <SmartNumberInput
                  key="wiz-rawCost"
                  autoFocus
                  value={form.rawMaterialCost ?? 0}
                  onValueChange={(n) =>
                    setForm((f) => ({ ...f, rawMaterialCost: n }))
                  }
                  format="currency"
                  onEnter={onEnterAdvance}
                  className="text-lg"
                  placeholder="Type $ or estimate below"
                />
              </div>
              <Button
                type="button"
                variant="secondary"
                className="w-full min-h-11"
                onClick={onApplyBookEstimate}
              >
                Estimate from LCM material Calculator
              </Button>
              <p className="text-[11px] text-[var(--color-muted)] leading-relaxed">
                {bookEstimateOk
                  ? bookEstimateLine
                  : "Set material type, shape, section, and stock length for estimate."}
              </p>
            </div>
          )}

          {step.id === "materialDrop" && (
            <div className="space-y-1.5">
              <Label>Calculate material drop?</Label>
              <Select
                autoFocus
                value={form.calculateMaterialDrop ? "yes" : "no"}
                onChange={(e) =>
                  setForm((f) => ({
                    ...f,
                    calculateMaterialDrop: e.target.value === "yes",
                  }))
                }
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    onEnterAdvance();
                  }
                }}
              >
                <option value="no">No</option>
                <option value="yes">Yes — fold leftover stock into price</option>
              </Select>
            </div>
          )}

          {step.id === "ops" && (
            <div className="space-y-3">
              <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 text-sm">
                <span className="font-semibold">
                  {opLabel(opIndex)} ·{" "}
                  {opKind === "setup" ? "Setup (minutes)" : "Runtime (min / pc)"}
                </span>
              </div>
              <div className="space-y-1.5">
                <Label>
                  {opKind === "setup" ? "Setup minutes" : "Run minutes each"}
                </Label>
                <SmartNumberInput
                  key={`op-${opIndex}-${opKind}`}
                  autoFocus
                  value={
                    opKind === "setup"
                      ? form.setupTimes?.[opIndex] || 0
                      : form.runTimes?.[opIndex] || 0
                  }
                  onValueChange={(n) => {
                    if (opKind === "setup") {
                      setForm((f) => {
                        const setupTimes = [...(f.setupTimes || [])];
                        while (setupTimes.length < maxOps) setupTimes.push(0);
                        setupTimes[opIndex] = n;
                        return { ...f, setupTimes };
                      });
                    } else {
                      setForm((f) => {
                        const runTimes = [...(f.runTimes || [])];
                        while (runTimes.length < maxOps) runTimes.push(0);
                        runTimes[opIndex] = n;
                        return { ...f, runTimes };
                      });
                    }
                  }}
                  format="plain"
                  emptyMeans={0}
                  onEnter={onEnterAdvance}
                  className="text-lg"
                  placeholder="Type minutes…"
                />
              </div>
              <Button
                type="button"
                variant="outline"
                className="w-full min-h-11"
                onClick={finishOpsEarly}
              >
                <Check className="h-4 w-4" /> Done with operations
              </Button>
              <p className="text-[11px] text-[var(--color-subtle)]">
                Enter advances to next setup/runtime. “Done with operations”
                skips remaining OPs and goes to qty breaks.
              </p>
            </div>
          )}

          {step.id === "quantities" && (
            <div className="grid grid-cols-2 gap-3">
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="space-y-1">
                  <Label>Qty {i + 1}</Label>
                  <SmartNumberInput
                    key={`qty-${i}`}
                    autoFocus={i === 0}
                    value={form.quantities?.[i] || 0}
                    onValueChange={(n) =>
                      setForm((f) => {
                        const quantities = [...(f.quantities || zeros6())];
                        quantities[i] = n;
                        return { ...f, quantities };
                      })
                    }
                    format="plain"
                    emptyMeans={0}
                    onEnter={() => {
                      if (i === 5) onEnterAdvance();
                    }}
                    placeholder="0"
                  />
                </div>
              ))}
            </div>
          )}

          {step.id === "preview" && (
            <div className="space-y-3 text-sm">
              <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] p-3 space-y-1">
                <div className="font-semibold text-base font-mono">
                  {form.partNumber || "—"}{" "}
                  <span className="font-sans text-[var(--color-muted)] font-medium">
                    Rev {form.revision || "—"}
                  </span>
                </div>
                <div className="text-[var(--color-muted)]">
                  {form.kind === "assembly" ? "Assembly" : "Single part"}
                  {" · "}
                  {form.customer || "No customer"}
                  {selectedMachines.length
                    ? ` · ${selectedMachines.join(", ")}`
                    : ""}
                </div>
                <div className="text-[var(--color-muted)]">
                  {[form.material, form.materialType, form.stockShape]
                    .filter(Boolean)
                    .join(" · ") || "Material not set"}
                </div>
              </div>
              <div className="space-y-1">
                <Row label="Material w/ %" value={formatCurrency(costs.materialCostWithPct)} />
                <Row label="Setup cost" value={formatCurrency(costs.setupCost)} />
                <Row label="Run cost" value={formatCurrency(costs.runCost)} />
                <Row label="Base total" value={formatCurrency(costs.baseTotal)} strong />
              </div>
              <div className="border-t border-[var(--color-border)] pt-2 space-y-1">
                <div className="text-xs font-semibold uppercase text-[var(--color-muted)]">
                  Price each by qty
                </div>
                {(form.quantities || []).map((q, i) =>
                  q > 0 ? (
                    <Row
                      key={i}
                      label={`Qty ${q}`}
                      value={formatCurrency(costs.prices[i] || 0)}
                    />
                  ) : null,
                )}
              </div>
              <div className="flex flex-col gap-2 pt-1">
                <Button
                  type="button"
                  className="w-full min-h-12"
                  onClick={() => onSave(loadedId ? "update" : "submit")}
                >
                  <Check className="h-4 w-4" />
                  {loadedId ? "Update existing quote" : "Save new quote"}
                </Button>
                {loadedId && (
                  <Button
                    type="button"
                    variant="secondary"
                    className="w-full min-h-11"
                    onClick={() => onSave("submit")}
                  >
                    Save as new / submit
                  </Button>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2 px-4 py-3 border-t border-[var(--color-border)] bg-[var(--color-surface-2)]/40">
          <Button
            type="button"
            variant="ghost"
            disabled={stepIdx === 0 && !(step.id === "ops" && (opIndex > 0 || opKind === "runtime"))}
            onClick={goBack}
            className="min-h-11"
          >
            <ChevronLeft className="h-4 w-4" /> Back
          </Button>
          <div className="flex-1 text-center text-[11px] text-[var(--color-subtle)]">
            Tab / Enter to move · Esc closes
          </div>
          {step.id !== "preview" ? (
            <Button type="button" onClick={goNext} className="min-h-11">
              Next <ChevronRight className="h-4 w-4" />
            </Button>
          ) : (
            <Button type="button" variant="secondary" onClick={onClose} className="min-h-11">
              Edit on form
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

function Row({
  label,
  value,
  strong,
}: {
  label: string;
  value: string;
  strong?: boolean;
}) {
  return (
    <div className="flex justify-between gap-3">
      <span className="text-[var(--color-muted)]">{label}</span>
      <span className={strong ? "font-semibold tabular" : "tabular"}>{value}</span>
    </div>
  );
}

function zeros6() {
  return [0, 0, 0, 0, 0, 0];
}
