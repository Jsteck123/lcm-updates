import { CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cutTicketLabel, qtyAvailable, statusLabel } from "@/lib/lcm/cut-tickets";
import { leftoverCut } from "@/lib/lcm/scan-stock";
import type { CutTicket } from "@/lib/lcm/types";
import { cn } from "@/lib/utils";

export function CutJobCard({
  ticket,
  selected,
  onPick,
}: {
  ticket: CutTicket;
  selected?: boolean;
  onPick: () => void;
}) {
  const left = leftoverCut(ticket);
  return (
    <button
      type="button"
      onClick={onPick}
      className={cn(
        "w-full text-left rounded-[var(--radius-md)] border px-3 py-3 min-h-16 transition-colors",
        selected
          ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)]"
          : "border-[var(--color-border)] bg-[var(--color-surface-2)] hover:border-[var(--color-border-strong)]",
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="font-mono font-semibold truncate">
            {ticket.partNumber}{" "}
            <span className="font-sans text-xs font-normal text-[var(--color-muted)]">
              Rev {ticket.revision || "—"}
            </span>
          </div>
          <div className="text-xs text-[var(--color-muted)] truncate">
            {ticket.customer} · PO {ticket.poNumber || "—"}
            {ticket.dueDate ? ` · due ${ticket.dueDate.slice(0, 10)}` : ""}
          </div>
        </div>
        <Badge
          tone={
            ticket.status === "done"
              ? "done"
              : ticket.status === "partial" || ticket.status === "cutting"
                ? "info"
                : "hold"
          }
        >
          {statusLabel(ticket.status)}
        </Badge>
      </div>
      <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
        <div>
          <div className="text-[10px] uppercase text-[var(--color-muted)]">
            Cut length
          </div>
          <div className="font-medium">{cutTicketLabel(ticket)}</div>
        </div>
        <div>
          <div className="text-[10px] uppercase text-[var(--color-muted)]">
            Qty
          </div>
          <div className="font-semibold tabular">
            {ticket.qtyCut} / {ticket.qtyRequested}
            <span className="font-normal text-[var(--color-muted)]">
              {" "}
              · {left} left
            </span>
          </div>
        </div>
      </div>
    </button>
  );
}

export function CutQtyPad({
  leftover,
  qty,
  onQty,
  onConfirm,
  confirmLabel,
  disabled,
  lastOk,
}: {
  leftover: number;
  qty: string;
  onQty: (v: string) => void;
  onConfirm: () => void;
  confirmLabel: string;
  disabled?: boolean;
  lastOk?: string | null;
}) {
  const n = Math.max(0, Math.floor(Number(qty) || 0));
  function setN(v: number) {
    const next = Math.max(0, Math.min(leftover, Math.floor(v)));
    onQty(String(next || ""));
  }
  return (
    <div className="space-y-3">
      <div className="space-y-1.5">
        <Label>How many just cut</Label>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            type="button"
            variant="secondary"
            className="min-w-12"
            onClick={() => setN(n - 1)}
          >
            −
          </Button>
          <Input
            inputMode="numeric"
            className="w-20 text-center text-lg font-semibold tabular"
            value={qty}
            onChange={(e) => onQty(e.target.value)}
          />
          <Button
            type="button"
            variant="secondary"
            className="min-w-12"
            onClick={() => setN(n + 1)}
          >
            +
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => setN(Math.min(5, leftover))}
          >
            5
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => setN(leftover)}
          >
            All {leftover}
          </Button>
        </div>
      </div>
      <Button
        className="w-full min-h-12 text-base"
        disabled={disabled || n <= 0 || leftover <= 0}
        onClick={onConfirm}
      >
        {confirmLabel}
      </Button>
      {lastOk ? (
        <p className="text-sm text-[var(--color-success)] flex items-center gap-1.5">
          <CheckCircle2 className="h-4 w-4" />
          {lastOk}
        </p>
      ) : null}
    </div>
  );
}

export function CutPickedDetail({ ticket }: { ticket: CutTicket }) {
  const left = leftoverCut(ticket);
  const avail = qtyAvailable(ticket);
  return (
    <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-2">
      <div className="font-mono font-semibold text-lg">{ticket.partNumber}</div>
      <div className="text-sm text-[var(--color-muted)]">
        {ticket.customer} · PO {ticket.poNumber || "—"}
        {ticket.requestedMachine ? ` · for ${ticket.requestedMachine}` : ""}
      </div>
      <div className="grid grid-cols-2 gap-3 pt-1">
        <div>
          <div className="text-[10px] uppercase text-[var(--color-muted)]">
            Cut length
          </div>
          <div className="text-base font-semibold">{cutTicketLabel(ticket)}</div>
        </div>
        <div>
          <div className="text-[10px] uppercase text-[var(--color-muted)]">
            Qty
          </div>
          <div className="text-base font-semibold tabular">
            {ticket.qtyCut} / {ticket.qtyRequested}
          </div>
          <div className="text-xs text-[var(--color-muted)]">
            {left} left · {avail} available for machine
          </div>
        </div>
      </div>
    </div>
  );
}
