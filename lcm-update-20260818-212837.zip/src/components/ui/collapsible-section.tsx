import { useState, type ReactNode } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

/** Card that can start collapsed to calm busy pages. */
export function CollapsibleSection({
  title,
  description,
  defaultOpen = false,
  badge,
  children,
  className,
  forceOpen,
  open: openProp,
  onOpenChange,
  contentClassName,
}: {
  title: ReactNode;
  description?: ReactNode;
  defaultOpen?: boolean;
  badge?: string | number | null;
  children: ReactNode;
  className?: string;
  /** When true, stays open (e.g. floor reports waiting). */
  forceOpen?: boolean;
  /** Controlled open. When set, click reports through onOpenChange. */
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  contentClassName?: string;
}) {
  const [internal, setInternal] = useState(defaultOpen);
  const shown = forceOpen || (openProp !== undefined ? openProp : internal);

  function toggle() {
    if (forceOpen) return;
    const next = !shown;
    if (onOpenChange) onOpenChange(next);
    if (openProp === undefined) setInternal(next);
  }

  return (
    <Card className={className}>
      <CardHeader className={shown ? "pb-2" : "py-2"}>
        <button
          type="button"
          className="flex w-full min-h-11 items-center justify-between gap-3 text-left"
          onClick={toggle}
          aria-expanded={shown}
        >
          <div className="min-w-0 space-y-1">
            <CardTitle className="flex flex-wrap items-center gap-2 text-base">
              {title}
              {badge != null && badge !== "" && Number(badge) !== 0 ? (
                <Badge tone="warn">{badge}</Badge>
              ) : null}
            </CardTitle>
            {shown && description ? (
              <CardDescription className="text-xs">{description}</CardDescription>
            ) : null}
          </div>
          <ChevronDown
            className={cn(
              "h-5 w-5 shrink-0 text-[var(--color-muted)] transition-transform",
              shown && "rotate-180",
            )}
          />
        </button>
      </CardHeader>
      {shown ? (
        <CardContent className={cn("pt-0", contentClassName)}>{children}</CardContent>
      ) : null}
    </Card>
  );
}
