import { useCallback, useEffect, useState } from "react";

const KEY = "lcm-editor-mode";
const EVT = "lcm-editor-mode";

function readOn() {
  try {
    return sessionStorage.getItem(KEY) === "1";
  } catch {
    return false;
  }
}

export function useEditorMode(isAdmin: boolean) {
  const [on, setOn] = useState(false);

  useEffect(() => {
    if (!isAdmin) {
      setOn(false);
      return;
    }
    setOn(readOn());
    const sync = () => setOn(readOn());
    window.addEventListener(EVT, sync);
    return () => window.removeEventListener(EVT, sync);
  }, [isAdmin]);

  const setEditorMode = useCallback(
    (next: boolean) => {
      if (!isAdmin) return;
      try {
        sessionStorage.setItem(KEY, next ? "1" : "0");
      } catch {
        /* ignore */
      }
      setOn(next);
      window.dispatchEvent(new Event(EVT));
    },
    [isAdmin],
  );

  return { editorMode: isAdmin && on, setEditorMode };
}
