import { useEffect, useMemo, useState } from "react";
import { useLcmStore } from "@/store/lcm-store";
import { getOperatorByEmail } from "@/lib/lcm/permissions";
import {
  activeFloorNames,
  personPulse,
  shopPulse,
  withLiveClock,
  type PersonPulse,
  type ShopPulse,
} from "@/lib/lcm/floor-pulse";
import { currentShiftContext, weekKeyFromDate } from "@/lib/lcm/day-bonus";

export function useFloorPulse(opts?: {
  operatorName?: string;
  intervalMs?: number;
}): {
  shop: ShopPulse;
  me: PersonPulse;
  myName: string;
  shiftName: string;
} {
  const settings = useLcmStore((s) => s.settings);
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  const weeklyPayouts = useLcmStore((s) => s.weeklyPayouts || []);
  const dayBonuses = useLcmStore((s) => s.dayBonuses || []);
  const sessions = useLcmStore((s) => s.sessions);
  const activeTimers = useLcmStore((s) => s.activeTimers);
  const jobs = useLcmStore((s) => s.jobs);
  const operatorTimeLog = useLcmStore((s) => s.operatorTimeLog);
  const getDayBonusLive = useLcmStore((s) => s.getDayBonusLive);
  const getLiveSeconds = useLcmStore((s) => s.getLiveElapsedSeconds);

  const intervalMs = opts?.intervalMs ?? 2000;
  const [now, setNow] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setNow((n) => n + 1), intervalMs);
    return () => window.clearInterval(id);
  }, [intervalMs]);

  const signed = useMemo(
    () => getOperatorByEmail(operators, email),
    [operators, email],
  );
  const myName = (opts?.operatorName || signed?.name || "").trim();

  const ctx = useMemo(
    () => currentShiftContext(settings),
    [settings, jobs, operatorTimeLog, now],
  );
  const weekKey = weekKeyFromDate(`${ctx.dateKey}T12:00:00`);

  const liveOpts = {
    sessions,
    activeTimers,
    getLiveSeconds: (machine: string) => getLiveSeconds(machine) || 0,
    settings,
  };

  const shop = useMemo(() => {
    const names = activeFloorNames(operators);
    const live = names
      .map((n) =>
        withLiveClock(getDayBonusLive(n, ctx.dateKey, ctx.shift.id), {
          ...liveOpts,
          operatorName: n,
        }),
      )
      .filter((c): c is NonNullable<typeof c> => !!c);
    return shopPulse({
      dateKey: ctx.dateKey,
      weekKey,
      shiftName: ctx.shift.name,
      live,
      weeklyPayouts,
      dayBonuses,
    });
  }, [
    operators,
    getDayBonusLive,
    ctx.dateKey,
    weekKey,
    ctx.shift.id,
    ctx.shift.name,
    weeklyPayouts,
    dayBonuses,
    sessions,
    activeTimers,
    jobs,
    operatorTimeLog,
    now,
  ]);

  const me = useMemo(() => {
    if (!myName) {
      return personPulse("", null);
    }
    const calc = withLiveClock(
      getDayBonusLive(myName, ctx.dateKey, ctx.shift.id),
      { ...liveOpts, operatorName: myName },
    );
    return personPulse(myName, calc);
  }, [
    myName,
    getDayBonusLive,
    ctx.dateKey,
    ctx.shift.id,
    sessions,
    activeTimers,
    jobs,
    operatorTimeLog,
    now,
  ]);

  return { shop, me, myName, shiftName: ctx.shift.name };
}
