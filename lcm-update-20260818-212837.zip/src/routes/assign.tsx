/**
 * Admin desk queue: walk parts + drawings, assign operator (machine optional).
 * Drawing modal keeps assign controls visible; skip bumps to bottom.
 * Workload charts from quoted setup/run × open assignments.
 */
import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  UserCheck,
  FileText,
  Box,
  ChevronRight,
  ArrowDownToLine,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { toast } from "sonner";
import { PageHowTo } from "@/components/lcm/page-howto";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { buildAssignQueue, type AssignQueueItem } from "@/lib/lcm/assign-queue";
import {
  buildAssignWorkload,
  quotedHoursForPart,
} from "@/lib/lcm/assign-workload";
import { quotedHoursForOpOnPart } from "@/lib/lcm/op-slots";
import { AssignDrawingModal } from "@/components/lcm/assign-drawing-modal";
import { useEditorMode } from "@/hooks/use-editor-mode";
import { EditorHideButton } from "@/components/lcm/editor-remove";
import { allMachines } from "@/lib/lcm/lists";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/assign")({
  component: AssignQueuePage,
});

const SKIP_KEY = "lcm-assign-skipped-v1";

function loadSkipped(): string[] {
  try {
    const raw = sessionStorage.getItem(SKIP_KEY);
    if (!raw) return [];
    const a = JSON.parse(raw);
    return Array.isArray(a) ? a.map(String) : [];
  } catch {
    return [];
  }
}

function saveSkipped(keys: string[]) {
  try {
    sessionStorage.setItem(SKIP_KEY, JSON.stringify(keys));
  } catch {
    /* ignore */
  }
}

function AssignQueuePage() {
  const shopOrders = useLcmStore((s) => s.shopOrders || []);
  const workQueue = useLcmStore((s) => s.workQueue || []);
  const quotes = useLcmStore((s) => s.quotes || []);
  const operators = useLcmStore((s) => s.operators || []);
  const me = useLcmStore((s) =>
    (s.operators || []).find(
      (o) => o.email.toLowerCase() === (s.currentUserEmail || "").toLowerCase(),
    ),
  );
  const settings = useLcmStore((s) => s.settings);
  const officeAssignPart = useLcmStore((s) => s.officeAssignPart);
  const adminCleanFloor = useLcmStore((s) => s.adminCleanFloor);
  const { editorMode } = useEditorMode(true);

  const isAdmin = me?.role === "admin";
  const machines = useMemo(
    () => allMachines(settings.customLists),
    [settings.customLists],
  );
  const operatorNames = useMemo(
    () =>
      operators
        .filter((o) => o.active !== false)
        .map((o) => o.name)
        .filter(Boolean)
        .sort((a, b) => a.localeCompare(b)),
    [operators],
  );

  const baseQueue = useMemo(
    () => buildAssignQueue(shopOrders, quotes),
    [shopOrders, quotes],
  );

  const [skipped, setSkipped] = useState<string[]>(() => loadSkipped());
  const [filter, setFilter] = useState("");
  const [activeKey, setActiveKey] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [operator, setOperator] = useState("");
  const [machine, setMachine] = useState("");
  const [notes, setNotes] = useState("");

  useEffect(() => {
    saveSkipped(skipped);
  }, [skipped]);

  // Drop skip markers for items no longer in queue
  useEffect(() => {
    const live = new Set(baseQueue.map((i) => i.key));
    setSkipped((prev) => {
      const next = prev.filter((k) => live.has(k));
      return next.length === prev.length ? prev : next;
    });
  }, [baseQueue]);

  const orderedQueue = useMemo(() => {
    const q = filter.trim().toLowerCase();
    const filtered = !q
      ? baseQueue
      : baseQueue.filter(
          (i) =>
            i.partNumber.toLowerCase().includes(q) ||
            i.poNumber.toLowerCase().includes(q) ||
            i.customer.toLowerCase().includes(q) ||
            i.description.toLowerCase().includes(q) ||
            i.opLabel.toLowerCase().includes(q) ||
            i.quotedMachine.toLowerCase().includes(q),
        );
    const skipSet = new Set(skipped);
    const top = filtered.filter((i) => !skipSet.has(i.key));
    const bottom = filtered.filter((i) => skipSet.has(i.key));
    return [...top, ...bottom];
  }, [baseQueue, filter, skipped]);

  const active =
    orderedQueue.find((i) => i.key === activeKey) || orderedQueue[0] || null;

  const workload = useMemo(
    () =>
      buildAssignWorkload({
        shopOrders,
        workQueue,
        quotes,
        officialMachines: machines,
      }),
    [shopOrders, workQueue, quotes, machines],
  );

  function openItem(item: AssignQueueItem) {
    setActiveKey(item.key);
    setOperator(item.officeAssignedTo || "");
    setMachine(item.quotedMachine || "");
    setNotes("");
    setModalOpen(true);
  }

  function confirmAssign() {
    if (!active) return;
    if (!operator.trim()) {
      toast.error("Pick who this part is for");
      return;
    }
    const r = officeAssignPart({
      orderId: active.orderId,
      lineId: active.lineId,
      componentId: active.componentId || undefined,
      operatorName: operator.trim(),
      machine: machine.trim() || undefined,
      notes: notes.trim() || undefined,
      opIndex: active.opIndex == null ? undefined : active.opIndex,
    });
    if (!r.ok) {
      toast.error(r.error || "Assign failed");
      return;
    }
    const opBit = active.opLabel ? ` ${active.opLabel}` : "";
    toast.success(
      `${active.partNumber}${opBit} is ${operator.trim()}'s job` +
        (machine.trim() ? ` · ${machine.trim()}` : ""),
    );
    setSkipped((prev) => prev.filter((k) => k !== active.key));
    const nextSame = orderedQueue.find(
      (i) =>
        i.key !== active.key &&
        i.orderId === active.orderId &&
        i.lineId === active.lineId &&
        i.componentId === active.componentId &&
        i.opIndex != null &&
        (active.opIndex == null || i.opIndex > active.opIndex),
    );
    if (nextSame) {
      openItem(nextSame);
      return;
    }
    setOperator("");
    setMachine("");
    setNotes("");
    setModalOpen(false);
    setActiveKey(null);
  }

  function skipForLater() {
    if (!active) return;
    setSkipped((prev) => {
      const without = prev.filter((k) => k !== active.key);
      return [...without, active.key];
    });
    toast.message(`${active.partNumber} moved to bottom of queue`);
    setModalOpen(false);
    setOperator("");
    setMachine("");
    setNotes("");
    // jump to next non-skipped if possible
    const next = orderedQueue.find(
      (i) => i.key !== active.key && !skipped.includes(i.key),
    );
    setActiveKey(next?.key || null);
  }

  if (!isAdmin) {
    return (
      <div className="mx-auto max-w-lg p-6">
        <Card>
          <CardHeader>
            <CardTitle>Assign queue</CardTitle>
            <CardDescription>
              Admin only — desk walkthrough to hand parts to people.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-sm text-[var(--color-muted)]">
            Sign in as an admin to use this queue.
          </CardContent>
        </Card>
      </div>
    );
  }

  const estHours = active
    ? active.opIndex != null
      ? quotedHoursForOpOnPart(
          quotes,
          active.partNumber,
          active.qty,
          active.opIndex,
        )
      : quotedHoursForPart(quotes, active.partNumber, active.qty)
    : 0;

  return (
    <div className="mx-auto max-w-7xl space-y-3 p-3 sm:p-4 h-[calc(100dvh-4.5rem)] flex flex-col min-h-0">
      <div className="flex flex-wrap items-end justify-between gap-2 shrink-0">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold tracking-tight flex items-center gap-2">
            <UserCheck className="h-6 w-6 text-[var(--color-primary)]" />
            Assign queue
          </h1>
          <p className="text-xs sm:text-sm text-[var(--color-muted)] mt-0.5 max-w-2xl">
            Open drawing → pick person (machine optional) without leaving the
            print. Multi-machine quotes split into one row per OP (lathe then
            mill). Skip bumps to the bottom. Charts match Load Lanes — hours
            on cards they have now, not leftover running order.{" "}
            <Link to="/lanes" className="underline text-[var(--color-primary)]">
              Load lanes
            </Link>{" "}
            lays those hours on the week so you can see where a rush fits.
          </p>
        </div>
        <Badge tone="neutral" className="text-sm px-3 py-1">
          {orderedQueue.length} waiting
          {skipped.length ? ` · ${skipped.length} skipped` : ""}
        </Badge>
        <PageHowTo id="assign-queue" />
      </div>

      {/* Workload graphs */}
      <div className="grid md:grid-cols-2 gap-3 shrink-0">
        <WorkloadCard
          title="Machine workload"
          description="Quoted hours on cards they have now"
          data={workload.machines}
          empty="No machines booked yet — assign with a machine to fill this"
          color="var(--color-primary)"
        />
        <WorkloadCard
          title="Operator workload"
          description="Quoted hours on cards they have now"
          data={workload.operators}
          empty="No operators assigned yet"
          color="var(--color-status-active)"
        />
      </div>

      <div className="flex flex-wrap gap-2 shrink-0">
        <Input
          className="max-w-sm"
          placeholder="Filter part #, PO, customer…"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        />
        {skipped.length > 0 && (
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={() => {
              setSkipped([]);
              toast.message("Skipped items restored to normal order");
            }}
          >
            Clear skips
          </Button>
        )}
      </div>

      {/* Scrollable queue + side hint */}
      <div className="flex-1 min-h-0 grid lg:grid-cols-[1fr_280px] gap-3">
        <Card className="min-h-0 flex flex-col overflow-hidden">
          <CardHeader className="py-3 shrink-0">
            <CardTitle className="text-base">Parts to assign</CardTitle>
            <CardDescription>
              Click a line to open the drawing and assign. Skipped items stay at
              the bottom.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex-1 min-h-0 overflow-y-auto space-y-2 pb-4">
            {orderedQueue.length === 0 ? (
              <p className="py-10 text-center text-sm text-[var(--color-muted)]">
                Nothing waiting. When orders land with part numbers, they show
                here.
              </p>
            ) : (
              orderedQueue.map((item, idx) => {
                const isSkip = skipped.includes(item.key);
                const selected = active?.key === item.key;
                const hrs =
                  item.opIndex != null
                    ? quotedHoursForOpOnPart(
                        quotes,
                        item.partNumber,
                        item.qty,
                        item.opIndex,
                      )
                    : quotedHoursForPart(quotes, item.partNumber, item.qty);
                return (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => openItem(item)}
                    className={cn(
                      "w-full text-left rounded-[var(--radius-lg)] border p-3 transition",
                      "hover:border-[var(--color-primary)]/50",
                      selected
                        ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_10%,var(--color-surface))]"
                        : "border-[var(--color-border)] bg-[var(--color-surface)]",
                      isSkip && "opacity-75 border-dashed",
                    )}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-[11px] text-[var(--color-muted)] tabular">
                            #{idx + 1}
                          </span>
                          <span className="font-mono font-semibold">
                            {item.partNumber || "(no P/N)"}
                          </span>
                          {item.revision ? (
                            <Badge tone="neutral">Rev {item.revision}</Badge>
                          ) : null}
                          {item.opLabel ? (
                            <Badge tone="info">{item.opLabel}</Badge>
                          ) : null}
                          {item.quotedMachine ? (
                            <Badge tone="neutral">{item.quotedMachine}</Badge>
                          ) : null}
                          <Badge
                            tone={
                              item.kind === "component"
                                ? "info"
                                : item.kind === "assembly"
                                  ? "soon"
                                  : "neutral"
                            }
                          >
                            {item.kind}
                          </Badge>
                          {isSkip && (
                            <Badge tone="warn">skipped · later</Badge>
                          )}
                          {item.officeAssignedTo ? (
                            <Badge tone="active">
                              {item.officeAssignedTo} — tap to put on board
                            </Badge>
                          ) : null}
                          {hrs > 0 && (
                            <span className="text-[11px] text-[var(--color-muted)]">
                              ~{hrs}h
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-[var(--color-muted)] mt-0.5">
                          PO {item.poNumber}
                          {item.customer ? ` · ${item.customer}` : ""} · qty{" "}
                          {item.qty}
                          {item.parentPartNumber
                            ? ` · under ${item.parentPartNumber}`
                            : ""}
                        </div>
                        <div className="flex flex-wrap gap-1.5 mt-1.5">
                          {item.drawings.length === 0 &&
                            item.cadFiles.length === 0 && (
                              <span className="text-xs text-[var(--color-warn)]">
                                No drawing
                              </span>
                            )}
                          {item.drawings.slice(0, 3).map((d) => (
                            <span
                              key={d.id}
                              className="inline-flex items-center gap-1 text-[11px] text-[var(--color-muted)]"
                            >
                              <FileText className="h-3 w-3" />
                              {d.name || "Drawing"}
                            </span>
                          ))}
                          {item.cadFiles.slice(0, 2).map((d) => (
                            <span
                              key={d.id}
                              className="inline-flex items-center gap-1 text-[11px] text-[var(--color-muted)]"
                            >
                              <Box className="h-3 w-3" />
                              CAD
                            </span>
                          ))}
                        </div>
                      </div>
                      <ChevronRight className="h-5 w-5 shrink-0 text-[var(--color-muted)]" />
                    </div>
                    {editorMode && (
                      <div
                        className="mt-2"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <EditorHideButton
                          onHide={() => {
                            const r = adminCleanFloor({
                              orderId: item.orderId,
                              lineId: item.lineId,
                              componentId: item.componentId || undefined,
                              partNumber: item.partNumber,
                              mode: "hide",
                            });
                            if (r.ok) toast.success(`Removed ${item.partNumber}`);
                            else toast.error(r.error || "Could not remove");
                          }}
                        />
                      </div>
                    )}
                  </button>
                );
              })
            )}
          </CardContent>
        </Card>

        <Card className="hidden lg:flex flex-col min-h-0">
          <CardHeader className="py-3">
            <CardTitle className="text-base">How it works</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-[var(--color-muted)] space-y-2">
            <p>
              1. Click a part — drawing opens full screen with assign bar at
              the bottom.
            </p>
            <p>
              2. Choose <strong>operator</strong> (required) and{" "}
              <strong>machine</strong> (optional) while you look at the print.
            </p>
            <p>
              3. <strong>Assign & next</strong> puts it on that person’s Job
              Board (My Jobs) and their machine queue if you pick a machine.
            </p>
            <p>
              Charts update from quoted setup + runtime when that part is in
              the quote book.
            </p>
            {active && (
              <div className="pt-2 border-t border-[var(--color-border)] space-y-2">
                <div className="text-xs font-semibold text-[var(--color-fg)]">
                  Selected: {active.partNumber}
                </div>
                <Button
                  type="button"
                  className="w-full"
                  onClick={() => openItem(active)}
                >
                  Open drawing & assign
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={skipForLater}
                >
                  <ArrowDownToLine className="h-4 w-4" />
                  Skip for later
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {modalOpen && active && (
        <AssignDrawingModal
          item={active}
          operatorNames={operatorNames}
          machines={machines}
          operator={operator}
          machine={machine}
          notes={notes}
          onOperator={setOperator}
          onMachine={setMachine}
          onNotes={setNotes}
          onAssign={confirmAssign}
          onSkip={skipForLater}
          onClose={() => setModalOpen(false)}
          estimatedHours={estHours}
        />
      )}
    </div>
  );
}

function WorkloadCard({
  title,
  description,
  data,
  empty,
  color,
}: {
  title: string;
  description: string;
  data: { name: string; hours: number; jobs: number }[];
  empty: string;
  color: string;
}) {
  const chartData = data.slice(0, 12).map((d) => ({
    name: d.name.length > 12 ? d.name.slice(0, 11) + "…" : d.name,
    full: d.name,
    hours: d.hours,
    jobs: d.jobs,
  }));

  return (
    <Card>
      <CardHeader className="py-2.5 px-3 space-y-0.5">
        <CardTitle className="text-sm font-semibold">{title}</CardTitle>
        <CardDescription className="text-[11px]">{description}</CardDescription>
      </CardHeader>
      <CardContent className="px-2 pb-2 pt-0">
        {chartData.length === 0 ? (
          <p className="text-xs text-[var(--color-muted)] px-2 py-6 text-center">
            {empty}
          </p>
        ) : (
          <div className="h-[140px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={chartData}
                margin={{ top: 4, right: 8, left: 0, bottom: 0 }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="var(--color-border)"
                  vertical={false}
                />
                <XAxis
                  dataKey="name"
                  tick={{ fontSize: 10, fill: "var(--color-muted)" }}
                  interval={0}
                  angle={-20}
                  textAnchor="end"
                  height={48}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "var(--color-muted)" }}
                  width={32}
                  unit="h"
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--color-surface)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                  formatter={(value: number, _n, p) => [
                    `${value} h · ${p?.payload?.jobs ?? 0} job(s)`,
                    p?.payload?.full || "Hours",
                  ]}
                />
                <Bar dataKey="hours" fill={color} radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
