import { HeadContent, Outlet, Scripts, createRootRoute } from "@tanstack/react-router";
import { Toaster } from "sonner";
import { AppShell } from "@/components/layout/app-shell";
import { CreatedWithGrokBanner } from "@/components/created-with-grok-banner";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import appCss from "@/styles.css?url";

const APP_NAME = "LCM Data Management";
const host = import.meta.env.VITE_PUBLIC_HOSTNAME;
const ogImage = host
  ? `https://og.grok.me/v1/card.png?host=${encodeURIComponent(host)}&title=${encodeURIComponent(APP_NAME)}`
  : undefined;

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      {
        name: "viewport",
        content: "width=device-width, initial-scale=1, viewport-fit=cover",
      },
      { title: APP_NAME },
      { name: "apple-mobile-web-app-title", content: APP_NAME },
      { name: "theme-color", content: "#0c0e12" },
      {
        name: "description",
        content:
          "Lake Country Machine — shop floor job tracking, quoting, efficiency, and reports",
      },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "twitter:card", content: "summary_large_image" },
      ...(ogImage
        ? [
            { property: "og:image", content: ogImage },
            { property: "og:image:width", content: "1200" },
            { property: "og:image:height", content: "630" },
          ]
        : []),
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/api/branding/manifest" },
      { rel: "icon", href: "/api/branding/icon-192", type: "image/png" },
      { rel: "apple-touch-icon", href: "/api/branding/icon-192" },
      { rel: "shortcut icon", href: "/api/branding/icon-192" },
    ],
  }),
  component: RootComponent,
});

function RootComponent() {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <PreviewHostBridge />
        <CreatedWithGrokBanner />
        <AppShell>
          <Outlet />
        </AppShell>
        <Toaster
          theme="dark"
          position="top-right"
          toastOptions={{
            style: {
              background: "#1a1f2a",
              border: "1px solid #2a3140",
              color: "#e8eaef",
            },
          }}
        />
        <Scripts />
      </body>
    </html>
  );
}
