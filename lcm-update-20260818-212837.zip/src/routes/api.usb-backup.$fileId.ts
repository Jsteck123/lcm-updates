import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/usb-backup/$fileId")({
  server: {
    handlers: {
      GET: async ({ params, request }) => {
        const { verifyShopToken, readTokenFromHeaders } = await import(
          "@/lib/lcm/shop-session.server"
        );
        const headerTok = readTokenFromHeaders(request.headers);
        const url = new URL(request.url);
        const qToken = url.searchParams.get("token");
        const session =
          verifyShopToken(headerTok) || verifyShopToken(qToken);
        if (!session || session.role !== "admin") {
          return new Response("Unauthorized", { status: 401 });
        }
        const { readUsbBackup } = await import("@/lib/lcm/full-backup.server");
        const file = readUsbBackup(params.fileId);
        if (!file) return new Response("Not found", { status: 404 });
        return new Response(new Uint8Array(file.buffer), {
          status: 200,
          headers: {
            "Content-Type": "application/zip",
            "Content-Length": String(file.buffer.length),
            "Content-Disposition": `attachment; filename="${file.fileName.replace(/"/g, "")}"`,
            "Cache-Control": "private, no-store",
          },
        });
      },
    },
  },
});
