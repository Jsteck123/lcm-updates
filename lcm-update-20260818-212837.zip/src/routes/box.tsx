import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Package, Truck } from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getOperatorByEmail } from "@/lib/lcm/permissions";
import { classifyLabelCode, labelKindInfo } from "@/lib/lcm/label-kind";
import {
  boxesForOrder,
  findPackBox,
} from "@/lib/lcm/pack-boxes";
import { printPackBoxLabelOrToast } from "@/lib/lcm/print-box-labels";

export const Route = createFileRoute("/box")({
  validateSearch: (search: Record<string, unknown>): { c?: string } => {
    const out: { c?: string } = {};
    if (typeof search.c === "string" && search.c.trim()) out.c = search.c.trim();
    return out;
  },
  component: BoxScanPage,
});

function BoxScanPage() {
  const { c } = Route.useSearch();
  const packBoxes = useLcmStore((s) => s.packBoxes || []);
  const markBoxLoaded = useLcmStore((s) => s.markBoxLoaded);
  const shopPublicUrl = useLcmStore((s) => s.settings.shopPublicUrl);
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  const me = getOperatorByEmail(operators, email);
  const myName = me?.name || email.split("@")[0] || "Ship";
  const [code, setCode] = useState(c || "");

  const box = useMemo(
    () => findPackBox(packBoxes, code || c || ""),
    [packBoxes, code, c],
  );
  const kind = classifyLabelCode(code || c || "");
  const kindInfo = labelKindInfo(kind);
  const siblings = box ? boxesForOrder(packBoxes, box.orderId) : [];

  async function toggleLoaded() {
    if (!box) return;
    const r = markBoxLoaded(box.id, !box.loaded, myName);
    if (!r.ok) {
      toast.error(r.error || "Failed");
      return;
    }
    toast.success(
      r.box?.loaded ? "Loaded on truck" : "Unchecked — still on cart",
    );
  }

  return (
    <div className="mx-auto max-w-lg space-y-5 pb-10">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight flex items-center gap-2">
          <Package className="h-6 w-6 text-[var(--color-primary)]" />
          Packed box
        </h1>
        <p className="text-sm text-[var(--color-muted)] mt-1">
          Scan the carton sticker. Check it off when it goes on the truck.
        </p>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Sticker</CardTitle>
          <CardDescription>{kindInfo.instructions}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <Input
            autoFocus
            className="font-mono"
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="LCMBOX…"
          />
          {code.trim() && !box ? (
            <p className="text-sm text-[var(--color-warn)]">
              {kind === "box"
                ? "No packed box matches this code."
                : "This is not a packed-box sticker."}
            </p>
          ) : null}
        </CardContent>
      </Card>

      {box ? (
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-start justify-between gap-2">
              <div>
                <CardTitle className="text-xl font-mono">
                  {box.partNumber}
                </CardTitle>
                <CardDescription>
                  Rev {box.revision || "—"} · Qty {box.qty}
                </CardDescription>
              </div>
              <Badge tone={box.loaded ? "done" : "hold"}>
                {box.loaded ? "On truck" : "On cart"}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <div className="text-[10px] uppercase text-[var(--color-muted)]">
                  Customer
                </div>
                <div className="font-semibold">{box.customer || "—"}</div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-[var(--color-muted)]">
                  PO
                </div>
                <div className="font-mono font-semibold">
                  {box.poNumber || "—"}
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-[var(--color-muted)]">
                  Packed
                </div>
                <div>
                  {box.packedBy || "—"}
                  {box.packedAt
                    ? ` · ${box.packedAt.slice(0, 16).replace("T", " ")}`
                    : ""}
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-[var(--color-muted)]">
                  Code
                </div>
                <div className="font-mono text-xs">{box.barcode}</div>
              </div>
            </div>
            <Button
              className="w-full min-h-12 text-base"
              variant={box.loaded ? "secondary" : "default"}
              onClick={() => void toggleLoaded()}
            >
              <Truck className="h-4 w-4" />
              {box.loaded ? "Uncheck — still on cart" : "Loaded on truck"}
            </Button>
            <div className="flex flex-wrap gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => void printPackBoxLabelOrToast(box, shopPublicUrl)}
              >
                Reprint label
              </Button>
              <Link
                to="/calendar"
                className="inline-flex items-center text-sm text-[var(--color-primary)] underline"
              >
                Ship calendar
              </Link>
            </div>
            {siblings.length > 1 ? (
              <div className="pt-2 border-t border-[var(--color-border)] space-y-1">
                <div className="text-[10px] uppercase text-[var(--color-muted)]">
                  Other boxes on this PO
                </div>
                {siblings
                  .filter((b) => b.id !== box.id)
                  .map((b) => (
                    <button
                      key={b.id}
                      type="button"
                      className="w-full text-left text-sm py-1"
                      onClick={() => setCode(b.barcode)}
                    >
                      {b.partNumber} · qty {b.qty}{" "}
                      <span className="text-[var(--color-muted)]">
                        {b.loaded ? "on truck" : "on cart"}
                      </span>
                    </button>
                  ))}
              </div>
            ) : null}
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}
