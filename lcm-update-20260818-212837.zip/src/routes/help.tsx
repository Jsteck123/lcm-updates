import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { BookOpen, ExternalLink, ListTree, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { useLcmStore } from "@/store/lcm-store";
import { getOperatorByEmail } from "@/lib/lcm/permissions";
import {
  HOWTO_GROUPS,
  getPageHowTo,
  listPageHowTos,
} from "@/lib/lcm/howtos";
import type { PageHowToDoc } from "@/lib/lcm/howtos/types";
import { PageHowToInline } from "@/components/lcm/page-howto";

export const Route = createFileRoute("/help")({
  component: HelpManualIndex,
});

function blobOf(doc: PageHowToDoc): string {
  const bits = [doc.title, doc.whatThisPageIs, doc.path];
  for (const sec of doc.sections) {
    bits.push(sec.title);
    for (const b of sec.blocks) {
      if (b.type === "p" || b.type === "h" || b.type === "note" || b.type === "warn") {
        bits.push(b.text);
      } else if (b.type === "control") {
        bits.push(b.name, b.does);
      } else {
        bits.push(...b.items);
      }
    }
  }
  return bits.join(" ").toLowerCase();
}

function HelpManualIndex() {
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  const me = useMemo(
    () => getOperatorByEmail(operators, email),
    [operators, email],
  );
  const isAdmin = me?.role === "admin";

  const visible = useMemo(() => {
    return listPageHowTos().filter((d) => {
      if (d.audience === "admin" && !isAdmin) return false;
      return true;
    });
  }, [isAdmin]);

  const [query, setQuery] = useState("");
  const [openId, setOpenId] = useState<string>("sign-in");

  const groups = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return HOWTO_GROUPS.map((g) => {
      const docs = g.ids
        .map((id) => visible.find((d) => d.id === id))
        .filter((d): d is PageHowToDoc => {
          if (!d) return false;
          if (!needle) return true;
          return blobOf(d).includes(needle);
        });
      return { ...g, docs };
    }).filter((g) => g.docs.length > 0);
  }, [visible, query]);

  useEffect(() => {
    const hash =
      typeof window !== "undefined" ? window.location.hash.replace(/^#/, "") : "";
    if (hash && getPageHowTo(hash)) setOpenId(hash);
  }, []);

  useEffect(() => {
    const still = groups.some((g) => g.docs.some((d) => d.id === openId));
    if (!still) {
      const first = groups[0]?.docs[0]?.id;
      if (first) setOpenId(first);
    }
  }, [groups, openId]);

  function jump(id: string) {
    setOpenId(id);
    if (typeof window !== "undefined") {
      window.history.replaceState(null, "", `#${id}`);
    }
  }

  const current = visible.find((d) => d.id === openId);

  return (
    <div className="mx-auto max-w-6xl pb-16">
      <div className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight flex items-center gap-2">
          <BookOpen className="h-7 w-7 text-[var(--color-primary)]" />
          Shop manuals
        </h1>
        <p className="text-sm text-[var(--color-muted)] mt-2 max-w-3xl leading-relaxed">
          Each screen has its own manual — every button, how it works, and the
          exact steps. Open a page below, or tap{" "}
          <strong className="text-[var(--color-fg)]">How to use this page</strong>{" "}
          on that screen.
          {isAdmin
            ? " This login includes office manuals (quotes, reports, settings, backups)."
            : " This login shows the floor manuals — prices and bonus setup stay with office."}
        </p>
        <div className="flex flex-wrap gap-1.5 mt-3">
          <Badge tone="hold">Hold</Badge>
          <Badge tone="open">Open</Badge>
          <Badge tone="soon">Due soon</Badge>
          <Badge tone="overdue">Overdue</Badge>
          <Badge tone="active">Active</Badge>
          <Badge tone="ready">Ready</Badge>
          <Badge tone="done">Done</Badge>
          <Badge tone="danger">Problem</Badge>
          {isAdmin && <Badge tone="office">Office</Badge>}
        </div>
        <div className="relative mt-4 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--color-muted)]" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search a page, button, or step — label, saw, receive…"
            className="pl-9 h-11"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[260px_minmax(0,1fr)] gap-6 items-start">
        <nav className="lg:sticky lg:top-4 space-y-4 print:hidden">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <ListTree className="h-4 w-4 text-[var(--color-primary)]" />
                Page manuals
              </CardTitle>
              <CardDescription>
                One how-to per screen. Not a summary.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 max-h-[70vh] overflow-y-auto pr-1">
              {groups.map((g) => (
                <div key={g.id}>
                  <div className="text-[11px] font-semibold uppercase tracking-wide text-[var(--color-muted)] mb-1">
                    {g.title}
                  </div>
                  <ul className="space-y-0.5">
                    {g.docs.map((d) => (
                      <li key={d.id}>
                        <button
                          type="button"
                          onClick={() => jump(d.id)}
                          className={cn(
                            "w-full text-left text-sm rounded-[var(--radius-sm)] px-2 py-1.5 min-h-9",
                            openId === d.id
                              ? "bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)] text-[var(--color-fg)] font-medium"
                              : "text-[var(--color-muted)] hover:bg-[var(--color-surface-2)] hover:text-[var(--color-fg)]",
                          )}
                        >
                          {d.title}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
              {groups.length === 0 && (
                <p className="text-sm text-[var(--color-muted)]">
                  Nothing matches that search.
                </p>
              )}
            </CardContent>
          </Card>
        </nav>

        <div className="min-w-0 space-y-4">
          {current ? (
            <Card
              id={`guide-${current.id}`}
              className="scroll-mt-4 ring-1 ring-[color-mix(in_oklab,var(--color-primary)_35%,transparent)]"
            >
              <CardHeader className="pb-3 border-b border-[var(--color-border)]">
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                  <div>
                    <CardDescription className="uppercase tracking-wide text-[11px]">
                      How to use this page
                    </CardDescription>
                    <CardTitle className="text-lg mt-0.5">
                      {current.title}
                    </CardTitle>
                  </div>
                  {current.path ? (
                    <Link
                      to={current.path as "/"}
                      className="inline-flex items-center gap-1.5 text-sm text-[var(--color-primary)] font-medium hover:underline shrink-0 min-h-11"
                    >
                      Open this screen
                      <ExternalLink className="h-3.5 w-3.5" />
                    </Link>
                  ) : null}
                </div>
              </CardHeader>
              <CardContent className="p-4 sm:p-5">
                <PageHowToInline id={current.id} hideHeader />
              </CardContent>
            </Card>
          ) : (
            <p className="text-sm text-[var(--color-muted)]">
              Pick a page from the list.
            </p>
          )}

          {groups.length > 0 ? (
            <div className="flex justify-end print:hidden">
              <Button
                type="button"
                variant="outline"
                onClick={() =>
                  typeof window !== "undefined" && window.scrollTo({ top: 0 })
                }
              >
                Back to top
              </Button>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
