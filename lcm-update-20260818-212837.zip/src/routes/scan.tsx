import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ScanBarcode } from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHowTo } from "@/components/lcm/page-howto";
import {
  CutJobCard,
  CutPickedDetail,
  CutQtyPad,
} from "@/components/lcm/cut-queue-match";
import { getOperatorByEmail } from "@/lib/lcm/permissions";
import { classifyLabelCode, labelKindInfo } from "@/lib/lcm/label-kind";
import { findHoldForLine } from "@/lib/lcm/material-holds";
import {
  hitHeadline,
  hitSubline,
  leftoverCut,
  matchingOpenCuts,
  resolveScanCode,
} from "@/lib/lcm/scan-stock";

export const Route = createFileRoute("/scan")({
  validateSearch: (search: Record<string, unknown>): {
    c?: string;
    ticket?: string;
  } => {
    const out: { c?: string; ticket?: string } = {};
    if (typeof search.c === "string" && search.c.trim()) out.c = search.c.trim();
    if (typeof search.ticket === "string" && search.ticket.trim())
      out.ticket = search.ticket.trim();
    return out;
  },
  component: ScanPage,
});

function ScanPage() {
  const { c, ticket: ticketQ } = Route.useSearch();
  const consumePiece = useLcmStore((s) => s.consumePiece);
  const inventoryMove = useLcmStore((s) => s.inventoryMove);
  const recordCutProgress = useLcmStore((s) => s.recordCutProgress);
  const stockPieces = useLcmStore((s) => s.stockPieces || []);
  const materialStock = useLcmStore((s) => s.materialStock || []);
  const cutTickets = useLcmStore((s) => s.cutTickets || []);
  const materialHolds = useLcmStore((s) => s.materialHolds || []);
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  const me = getOperatorByEmail(operators, email);
  const myName = me?.name || email.split("@")[0] || "Saw";

  const [code, setCode] = useState(c || "");
  const [ticketId, setTicketId] = useState(ticketQ || "");
  const [qty, setQty] = useState("1");
  const [lastOk, setLastOk] = useState<string | null>(null);

  useEffect(() => {
    if (c) setCode(c);
  }, [c]);
  useEffect(() => {
    if (ticketQ) setTicketId(ticketQ);
  }, [ticketQ]);

  const hit = useMemo(
    () => resolveScanCode(code, stockPieces, materialStock),
    [code, stockPieces, materialStock],
  );
  const kind = hit?.kind || classifyLabelCode(code);
  const kindInfo = labelKindInfo(kind);
  const piece = hit?.kind === "piece" ? hit.piece : undefined;
  const rack = hit?.kind === "material" ? hit.material : undefined;

  const ticketChoices = useMemo(() => {
    if (hit) return matchingOpenCuts(hit, cutTickets);
    return [];
  }, [hit, cutTickets]);

  const boundTicket = useMemo(() => {
    if (ticketId) {
      return (
        ticketChoices.find((t) => t.id === ticketId) ||
        cutTickets.find((t) => t.id === ticketId) ||
        null
      );
    }
    return null;
  }, [ticketId, cutTickets, ticketChoices]);

  useEffect(() => {
    if (ticketId && ticketChoices.length && !ticketChoices.some((t) => t.id === ticketId)) {
      setTicketId("");
    }
  }, [ticketId, ticketChoices]);

  function lookup() {
    const found = resolveScanCode(code, stockPieces, materialStock);
    if (!found) {
      toast.error(
        kind === "unknown"
          ? "Not a rack or leftover-bar sticker."
          : "Not on the rack or piece book.",
      );
      return;
    }
    toast.message(
      found.kind === "piece"
        ? `Leftover bar · ${found.piece.material} ${found.piece.materialType}`
        : `Rack · ${found.material.material} ${found.material.materialType}`,
    );
  }

  function submitCut() {
    if (!boundTicket) {
      toast.error("Pick the job you are cutting");
      return;
    }
    const nQty = Math.max(1, Math.floor(Number(qty) || 1));
    const left = leftoverCut(boundTicket);
    if (nQty > left) {
      toast.error(`Only ${left} left to cut on this job`);
      return;
    }
    const loc = Number(boundTicket.locValue) || 0;
    const hold = findHoldForLine(materialHolds, boundTicket.shopOrderLineId);
    let spent = "";

    if (piece) {
      if (loc <= 0) {
        toast.error("This ticket has no cut length");
        return;
      }
      const res = consumePiece({
        barcode: code,
        lengthUsed: loc,
        qty: nQty,
        jobRef: boundTicket.partNumber,
        reason: `Saw cut ${boundTicket.partNumber}`,
      });
      if (!res.ok) {
        toast.error(res.error || "Failed");
        return;
      }
      const p = res.piece!;
      spent =
        p.status === "consumed"
          ? `${p.barcode} fully used`
          : `${p.barcode}: ${p.remainingLength}" remaining`;
    } else if (rack && !hold) {
      if (loc <= 0) {
        toast.error("This ticket has no cut length");
        return;
      }
      const inches = loc * nQty;
      const res = inventoryMove({
        itemKind: "material",
        itemId: rack.id,
        kind: "issue",
        qty: inches,
        reason: `Saw cut ${boundTicket.partNumber}`,
        ref: boundTicket.partNumber,
      });
      if (!res.ok) {
        toast.error(res.error || "Failed");
        return;
      }
      spent = `${rack.material} · −${inches}" · ${res.balance}" on hand`;
    }

    const r = recordCutProgress(boundTicket.id, nQty, myName);
    if (!r.ok) {
      toast.error(r.error || "Cut not marked");
      return;
    }
    spent = spent
      ? `${spent} · ${r.ticket?.qtyCut}/${r.ticket?.qtyRequested} on ${boundTicket.partNumber}`
      : `Cut ${nQty} · now ${r.ticket?.qtyCut}/${r.ticket?.qtyRequested} on ${boundTicket.partNumber}`;
    toast.success(spent);
    setLastOk(spent);
    setQty("1");
    if (leftoverCut(r.ticket!) <= 0) setTicketId("");
  }

  const canCut = Boolean(
    boundTicket &&
      leftoverCut(boundTicket) > 0 &&
      ((piece && piece.status === "available") ||
        (rack && (Number(rack.onHand) || 0) > 0) ||
        findHoldForLine(materialHolds, boundTicket.shopOrderLineId)),
  );

  return (
    <div className="mx-auto max-w-lg space-y-5 pb-10">
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight flex items-center gap-2">
            <ScanBarcode className="h-6 w-6 text-[var(--color-primary)]" />
            Scan stock
          </h1>
          <p className="text-sm text-[var(--color-muted)] mt-1">
            Scan the sticker on the bar. Matching jobs in the cut queue come
            up so you can pick what you are running.
          </p>
        </div>
        <PageHowTo id="scan-stock" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Sticker</CardTitle>
          <CardDescription>
            Phone camera on a rack or leftover-bar QR opens this page with the
            code filled in. Other labels have their own instructions.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex gap-2">
            <Input
              autoFocus
              value={code}
              onChange={(e) => {
                setCode(e.target.value.toUpperCase());
                setTicketId("");
                setLastOk(null);
              }}
              placeholder="LCMM… or LCM…"
              className="font-mono"
              onKeyDown={(e) => {
                if (e.key === "Enter") lookup();
              }}
            />
            <Button variant="secondary" onClick={lookup}>
              Find
            </Button>
          </div>

          {code.trim() ? (
            <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-1 text-sm">
              <div className="flex items-center justify-between gap-2">
                <span className="font-medium">{kindInfo.title}</span>
                {hit ? (
                  <Badge tone={hit.kind === "piece" ? "info" : "success"}>
                    {hit.kind === "piece" ? "leftover bar" : "rack"}
                  </Badge>
                ) : (
                  <Badge tone="neutral">not found</Badge>
                )}
              </div>
              <p className="text-[var(--color-muted)]">{kindInfo.instructions}</p>
              {hit ? (
                <div className="pt-1">
                  <div className="font-semibold">{hitHeadline(hit)}</div>
                  <div className="text-[var(--color-muted)]">{hitSubline(hit)}</div>
                  {piece ? (
                    <div className="tabular font-semibold mt-1">
                      {piece.remainingLength}" remaining of {piece.originalLength}"
                    </div>
                  ) : null}
                </div>
              ) : (
                <p className="text-[var(--color-warn)]">
                  {kind === "unknown"
                    ? "This sticker will not open the cut list."
                    : "Not on the rack book or piece book."}
                </p>
              )}
            </div>
          ) : null}
        </CardContent>
      </Card>

      {hit || boundTicket ? (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">
              {boundTicket
                ? "This cut"
                : ticketChoices.length
                  ? `Cut queue · ${ticketChoices.length} job${ticketChoices.length === 1 ? "" : "s"}`
                  : "Cut queue"}
            </CardTitle>
            <CardDescription>
              {boundTicket
                ? "Cut length and leftover qty for the job you picked."
                : ticketChoices.length
                  ? "Pick the job you are running."
                  : "No open cut-queue jobs use this material."}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {boundTicket ? (
              <>
                <Button
                  type="button"
                  variant="ghost"
                  className="px-0 h-auto min-h-0 text-sm text-[var(--color-primary)]"
                  onClick={() => {
                    setTicketId("");
                    setLastOk(null);
                  }}
                >
                  ← All matching jobs
                </Button>
                <CutPickedDetail ticket={boundTicket} />
                <CutQtyPad
                  leftover={leftoverCut(boundTicket)}
                  qty={qty}
                  onQty={setQty}
                  onConfirm={submitCut}
                  confirmLabel={`Cut ${Math.max(1, Math.floor(Number(qty) || 1))}`}
                  disabled={!canCut}
                  lastOk={lastOk}
                />
              </>
            ) : ticketChoices.length ? (
              <div className="space-y-2">
                {ticketChoices.map((t) => (
                  <CutJobCard
                    key={t.id}
                    ticket={t}
                    onPick={() => {
                      setTicketId(t.id);
                      setQty("1");
                      setLastOk(null);
                    }}
                  />
                ))}
              </div>
            ) : (
              <p className="text-sm text-[var(--color-muted)]">
                Request cut from the job board if this bar is for a job.{" "}
                <Link to="/saw" className="text-[var(--color-primary)] underline">
                  Open saw queue
                </Link>
              </p>
            )}
          </CardContent>
        </Card>
      ) : null}

      <div className="flex gap-2">
        <Link
          to="/saw"
          className="text-sm text-[var(--color-primary)] underline"
        >
          Saw queue
        </Link>
        <Link
          to="/inventory"
          className="text-sm text-[var(--color-primary)] underline"
        >
          Inventory
        </Link>
        <Link
          to="/labels"
          search={{ ids: "", kind: "materials" }}
          className="text-sm text-[var(--color-primary)] underline"
        >
          Print labels
        </Link>
      </div>
    </div>
  );
}
