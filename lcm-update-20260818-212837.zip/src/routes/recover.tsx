import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Download, RotateCcw, Shield } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { claimShopSession } from "@/lib/lcm/shop-api";
import { setShopToken } from "@/lib/lcm/shop-sync";
import {
  downloadShopBackup,
  listShopBackups,
  restoreShopBackup,
  type BackupInfo,
} from "@/lib/lcm/backup-api";
import { useLcmStore } from "@/store/lcm-store";
import { PageHowTo } from "@/components/lcm/page-howto";

export const Route = createFileRoute("/recover")({
  component: RecoverPage,
});

function RecoverPage() {
  const storedEmail = useLcmStore((s) => s.currentUserEmail);
  const [email, setEmail] = useState(storedEmail || "");
  const [pin, setPin] = useState("");
  const [token, setToken] = useState("");
  const [busy, setBusy] = useState(false);
  const [backups, setBackups] = useState<BackupInfo[]>([]);
  const [folder, setFolder] = useState("");

  async function unlock() {
    setBusy(true);
    try {
      const r = await claimShopSession({
        data: { email: email.trim(), pin: pin.trim() },
      });
      if (!r.ok) {
        toast.error(r.error || "PIN did not work");
        return;
      }
      if (r.operator.role !== "admin") {
        toast.error("Use an admin account to recover");
        return;
      }
      setShopToken(r.token);
      setToken(r.token);
      const list = await listShopBackups({ data: { token: r.token } });
      if (!list.ok) {
        toast.error(list.error || "Could not list backups");
        return;
      }
      setBackups(list.backups || []);
      setFolder(list.folder || "");
      toast.success("Unlocked — pick a backup");
    } finally {
      setBusy(false);
    }
  }

  async function downloadOne(fileName: string) {
    setBusy(true);
    try {
      const r = await downloadShopBackup({ data: { fileName, token } });
      if (!r.ok) {
        toast.error(r.error || "Download failed");
        return;
      }
      const blob = new Blob([r.json], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = r.fileName || fileName;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } finally {
      setBusy(false);
    }
  }

  async function restoreOne(fileName: string, when: string) {
    if (!confirm(`Restore shop data from ${when}? Current data is snapshotted first.`))
      return;
    setBusy(true);
    try {
      const r = await restoreShopBackup({ data: { fileName, token } });
      if (!r.ok) toast.error(r.error || "Restore failed");
      else {
        toast.success("Restored — reloading");
        window.location.href = "/";
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-xl p-4 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
      <div>
        <h1 className="text-xl font-semibold">Recover shop</h1>
        <p className="text-sm text-[var(--color-muted)] mt-1">
          Use this if Settings will not load or the shop looks empty/wrong.
          Unlock with your admin PIN, then restore or download a backup.
        </p>
      </div>
      <PageHowTo id="recover" />
      </div>

      {!token && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Admin unlock</CardTitle>
            <CardDescription>
              Same PIN you use to switch into your admin user.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-1">
              <Label>Email</Label>
              <Input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@shop"
              />
            </div>
            <div className="space-y-1">
              <Label>PIN</Label>
              <Input
                type="password"
                inputMode="numeric"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") void unlock();
                }}
              />
            </div>
            <Button className="w-full" disabled={busy} onClick={() => void unlock()}>
              <Shield className="h-4 w-4" />
              Unlock backups
            </Button>
          </CardContent>
        </Card>
      )}

      {token && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Backups on this host</CardTitle>
            <CardDescription>
              {folder
                ? `Also on disk: ${folder}`
                : "Files live in data/backups on the host PC."}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {backups.length === 0 && (
              <p className="text-sm text-[var(--color-muted)]">
                No backup files found on this host yet.
              </p>
            )}
            {backups.map((b) => (
              <div
                key={b.id}
                className="rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2 space-y-2"
              >
                <div className="text-sm font-medium">
                  {new Date(b.createdAt).toLocaleString()} · {b.label}
                </div>
                <div className="text-xs text-[var(--color-muted)]">
                  rev {b.rev ?? "?"} · {(b.sizeBytes / 1024).toFixed(0)} KB
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={busy}
                    onClick={() => void downloadOne(b.fileName)}
                  >
                    <Download className="h-3.5 w-3.5" />
                    Download
                  </Button>
                  <Button
                    size="sm"
                    variant="secondary"
                    disabled={busy}
                    onClick={() =>
                      void restoreOne(
                        b.fileName,
                        new Date(b.createdAt).toLocaleString(),
                      )
                    }
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    Restore this
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <p className="text-xs text-[var(--color-muted)]">
        <Link to="/settings" className="underline">
          Back to Settings
        </Link>
        {" · "}
        Host folder is next to the running app: <span className="font-mono">data/backups</span>
      </p>
    </div>
  );
}
