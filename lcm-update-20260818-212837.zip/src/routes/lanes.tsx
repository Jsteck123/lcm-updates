/**
 * Office load lanes: quoted hours on work days. Squeeze finds the first hole.
 */
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Rows3 } from "lucide-react";
import { PageHowTo } from "@/components/lcm/page-howto";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import {
  buildLoadDays,
  buildMachineLanes,
  buildPersonLanes,
  collectLoadJobs,
  findSqueeze,
  parseYmd,
  resolveSqueezeHours,
  ymdLocal,
  type LoadBlock,
  type LoadLane,
} from "@/lib/lcm/load-lanes";
import { quotedHoursForPart } from "@/lib/lcm/assign-workload";
import { allMachines } from "@/lib/lcm/lists";
import { dueUrgency, statusSurfaceClass, statusToBadgeTone } from "@/lib/lcm/status-colors";

export const Route = createFileRoute("/lanes")({
  component: LoadLanesPage,
});

function addWorkdays(fromYmd: string, dir: number): Date {
  const d = parseYmd(fromYmd);
  d.setDate(d.getDate() + dir * 7);
  return d;
}

function LoadLanesPage() {
  const shopOrders = useLcmStore((s) => s.shopOrders);
  const workQueue = useLcmStore((s) => s.workQueue);
  const quotes = useLcmStore((s) => s.quotes);
  const sessions = useLcmStore((s) => s.sessions);
  const operators = useLcmStore((s) => s.operators);
  const settings = useLcmStore((s) => s.settings);
  const official = useMemo(
    () => allMachines(settings.customLists),
    [settings.customLists],
  );

  const [mode, setMode] = useState<"people" | "machines">("people");
  const [anchor, setAnchor] = useState(() => new Date());
  const [selected, setSelected] = useState<string | null>(null);
  const [squeezeHours, setSqueezeHours] = useState("");
  const [squeezePn, setSqueezePn] = useState("");

  const days = useMemo(
    () =>
      buildLoadDays(anchor, {
        workDayStart: settings.workDayStart,
        workDayEnd: settings.workDayEnd,
        lunchHours: settings.lunchHours,
      }),
    [anchor, settings.workDayStart, settings.workDayEnd, settings.lunchHours],
  );

  const jobs = useMemo(
    () =>
      collectLoadJobs({
        shopOrders: shopOrders || [],
        workQueue: workQueue || [],
        quotes: quotes || [],
        sessions,
      }),
    [shopOrders, workQueue, quotes, sessions],
  );

  const operatorNames = useMemo(() => {
    const names = new Set<string>();
    for (const o of operators || []) {
      if (o.active === false) continue;
      if (o.role === "admin") continue;
      if (o.name.trim()) names.add(o.name.trim());
    }
    for (const j of jobs) if (j.operator) names.add(j.operator);
    return [...names].sort((a, b) => a.localeCompare(b));
  }, [operators, jobs]);

  const lanes = useMemo(
    () =>
      mode === "people"
        ? buildPersonLanes({ jobs, days, operatorNames })
        : buildMachineLanes({ jobs, days, officialMachines: official }),
    [mode, jobs, days, operatorNames, official],
  );

  const need = resolveSqueezeHours(quotes || [], squeezeHours, squeezePn, 1);
  const squeeze = useMemo(
    () => findSqueeze(lanes, need, days),
    [lanes, need, days],
  );

  const selectedLane = lanes.find((l) => l.name === selected) || null;
  const today = ymdLocal(new Date());
  const quoteHint = squeezePn.trim()
    ? quotedHoursForPart(quotes || [], squeezePn.trim(), 1)
    : 0;

  return (
    <div className="p-3 sm:p-5 space-y-4 max-w-[1400px] mx-auto">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-xl font-semibold tracking-tight flex items-center gap-2">
            <Rows3 className="h-5 w-5 text-[var(--color-primary)]" />
            Load lanes
          </h1>
          <p className="text-sm text-[var(--color-muted)] mt-0.5 max-w-2xl">
            Quoted hours stacked in due-date order — not a promised start time.
            Bars are who has the card now. Return or re-assign and they move.
            Ship dates stay on{" "}
            <Link to="/calendar" className="underline text-[var(--color-primary)]">
              Ship Calendar
            </Link>
            . Assign stays on{" "}
            <Link to="/assign" className="underline text-[var(--color-primary)]">
              Assign Queue
            </Link>
            .
          </p>
          <div className="flex flex-wrap gap-1.5 mt-2 text-[10px]">
            <Badge tone="active">On machine</Badge>
            <Badge tone="open">Assigned</Badge>
            <Badge tone="soon">Due ≤2 days</Badge>
            <Badge tone="overdue">Misses due</Badge>
          </div>
        </div>
        <PageHowTo id="load-lanes" />
      </div>

      <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-[var(--radius-md)] border border-[var(--color-border)] p-0.5">
            <Button
              type="button"
              size="sm"
              variant={mode === "people" ? "default" : "ghost"}
              onClick={() => {
                setMode("people");
                setSelected(null);
              }}
            >
              People
            </Button>
            <Button
              type="button"
              size="sm"
              variant={mode === "machines" ? "default" : "ghost"}
              onClick={() => {
                setMode("machines");
                setSelected(null);
              }}
            >
              Machines
            </Button>
          </div>
          <div className="inline-flex items-center gap-1">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setAnchor(addWorkdays(days[0]?.ymd || ymdLocal(new Date()), -1))}
              aria-label="Previous week"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setAnchor(new Date())}
            >
              This week
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setAnchor(addWorkdays(days[0]?.ymd || ymdLocal(new Date()), 1))}
              aria-label="Next week"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <form
          className="flex flex-wrap items-end gap-2"
          onSubmit={(e) => e.preventDefault()}
        >
          <label className="space-y-1">
            <span className="block text-[11px] uppercase tracking-wide text-[var(--color-muted)]">
              Hours
            </span>
            <Input
              className="w-24"
              inputMode="decimal"
              placeholder="2.4"
              value={squeezeHours}
              onChange={(e) => setSqueezeHours(e.target.value)}
            />
          </label>
          <label className="space-y-1">
            <span className="block text-[11px] uppercase tracking-wide text-[var(--color-muted)]">
              Or P/N
            </span>
            <Input
              className="w-40"
              placeholder="4201-0200-02"
              value={squeezePn}
              onChange={(e) => setSqueezePn(e.target.value)}
            />
          </label>
          {quoteHint > 0 && !Number(squeezeHours) ? (
            <span className="text-xs text-[var(--color-muted)] pb-2">
              Quote {quoteHint}h
            </span>
          ) : null}
        </form>
      </div>

      {need > 0 && squeeze ? (
        <div
          className={cn(
            "rounded-[var(--radius-lg)] border px-3 py-2 text-sm",
            statusSurfaceClass("ready"),
          )}
        >
          <span className="font-medium">First hole {need}h</span>
          <span className="text-[var(--color-muted)]">
            {" "}
            · {squeeze.dayLabel} · {squeeze.lane}
            {squeeze.open > need
              ? ` · ${squeeze.open}h open that day`
              : ""}
            . Quoted, on pace — not a promise.
          </span>
        </div>
      ) : need > 0 ? (
        <p className="text-sm text-[var(--color-muted)]">
          No {need}h hole in this window — try next week, or a different person.
        </p>
      ) : null}

      <div className="overflow-x-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)]">
        <div className="min-w-[720px]">
          <div
            className="grid border-b border-[var(--color-border)] text-[11px] uppercase tracking-wide text-[var(--color-muted)]"
            style={{ gridTemplateColumns: "9.5rem repeat(5, minmax(0, 1fr))" }}
          >
            <div className="px-3 py-2">{mode === "people" ? "Person" : "Machine"}</div>
            {days.map((d) => (
              <div
                key={d.ymd}
                className={cn(
                  "px-2 py-2 text-center",
                  d.ymd === today && "text-[var(--color-fg)] font-medium",
                )}
              >
                {d.weekday} {d.label}
              </div>
            ))}
          </div>
          {lanes.length === 0 ? (
            <p className="px-3 py-8 text-sm text-[var(--color-muted)]">
              Nobody is holding work yet — assign a part, then this fills.
            </p>
          ) : (
            lanes.map((lane) => (
              <LaneRow
                key={lane.name}
                lane={lane}
                days={days}
                selected={selected === lane.name}
                squeezeDay={
                  squeeze && squeeze.lane === lane.name ? squeeze.day : ""
                }
                onSelect={() =>
                  setSelected((n) => (n === lane.name ? null : lane.name))
                }
              />
            ))
          )}
        </div>
      </div>

      {selectedLane ? (
        <LaneDetail lane={selectedLane} />
      ) : (
        <p className="text-xs text-[var(--color-muted)]">
          Tap a lane for the job list. Hours = quote setup + run × leftover qty.
          No quote = named, no bar. They pull — this is due order, not a start
          clock.
        </p>
      )}
    </div>
  );
}

function LaneRow({
  lane,
  days,
  selected,
  squeezeDay,
  onSelect,
}: {
  lane: LoadLane;
  days: { ymd: string; capacity: number }[];
  selected: boolean;
  squeezeDay: string;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        "grid w-full text-left border-t border-[var(--color-border)] hover:bg-[var(--color-surface-2)]",
        selected && "bg-[var(--color-surface-2)]",
      )}
      style={{ gridTemplateColumns: "9.5rem repeat(5, minmax(0, 1fr))" }}
    >
      <div className="px-3 py-2.5 min-w-0">
        <div className="font-medium truncate">{lane.name}</div>
        <div className="text-[11px] text-[var(--color-muted)] tabular">
          {lane.bookedHours}h booked
          {lane.chips.length ? ` · ${lane.chips.length} no quote` : ""}
        </div>
      </div>
      {days.map((d) => (
        <div key={d.ymd} className="relative h-14 border-l border-[var(--color-border)] px-1 py-1.5">
          {lane.blocks.flatMap((b) =>
            b.segments
              .filter((s) => s.ymd === d.ymd)
              .map((s, i) => (
                <BlockChip key={`${b.job.key}-${i}`} block={b} seg={s} />
              )),
          )}
          {lane.chips.length > 0 && d.ymd === days[0]?.ymd
            ? lane.chips.slice(0, 1).map((c) => (
                <span
                  key={c.key}
                  className="pointer-events-none absolute bottom-1 left-1 text-[9px] text-[var(--color-subtle)] truncate max-w-[90%]"
                >
                  {c.partNumber} · no quote
                </span>
              ))
            : null}
          {squeezeDay === d.ymd ? (
            <span className="pointer-events-none absolute inset-y-1 right-1 rounded-[var(--radius-sm)] border border-dashed border-[var(--color-status-ready)] px-1 text-[9px] text-[var(--color-status-ready)] flex items-center">
              hole
            </span>
          ) : null}
        </div>
      ))}
    </button>
  );
}

function BlockChip({
  block,
  seg,
}: {
  block: LoadBlock;
  seg: { startFrac: number; widthFrac: number };
}) {
  return (
    <span
      title={`${block.job.partNumber}${block.job.opLabel ? ` ${block.job.opLabel}` : ""} · ${block.hours}h${block.job.dueDate ? ` · due ${block.job.dueDate}` : ""}${block.missesDue ? " · misses due" : ""}`}
      className={cn(
        "absolute top-1.5 bottom-1.5 overflow-hidden rounded-[var(--radius-sm)] px-1 text-[10px] leading-4 font-medium truncate",
        statusSurfaceClass(block.tone),
      )}
      style={{
        left: `calc(${seg.startFrac * 100}% + 2px)`,
        width: `calc(${Math.max(seg.widthFrac, 0.08) * 100}% - 4px)`,
      }}
    >
      {block.job.partNumber}
      {block.job.opLabel ? ` ${block.job.opLabel}` : ""}
    </span>
  );
}

function LaneDetail({ lane }: { lane: LoadLane }) {
  return (
    <div className="rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-4 space-y-3">
      <div>
        <h2 className="font-semibold">{lane.name}</h2>
        <p className="text-xs text-[var(--color-muted)]">
          {lane.bookedHours}h quoted this window
          {lane.tailDay
            ? ` · first leftover ${lane.tailOpen}h on ${lane.tailDay}`
            : ""}
        </p>
      </div>
      {lane.jobs.length === 0 ? (
        <p className="text-sm text-[var(--color-muted)]">No jobs on this lane.</p>
      ) : (
        <ul className="divide-y divide-[var(--color-border)]">
          {lane.jobs.map((j) => {
            const tone = j.live
              ? "active"
              : dueUrgency(j.dueDate) === "overdue"
                ? "overdue"
                : dueUrgency(j.dueDate) === "soon"
                  ? "soon"
                  : "open";
            return (
              <li
                key={j.key}
                className="flex flex-wrap items-baseline justify-between gap-2 py-2 text-sm"
              >
                <div className="min-w-0">
                  <span className="font-medium">{j.partNumber}</span>
                  {j.opLabel ? (
                    <span className="text-[var(--color-primary)]"> {j.opLabel}</span>
                  ) : null}
                  {j.poNumber ? (
                    <span className="text-[var(--color-muted)]"> · {j.poNumber}</span>
                  ) : null}
                  <div className="text-xs text-[var(--color-muted)]">
                    {j.customer || "—"}
                    {j.machine ? ` · ${j.machine}` : ""}
                    {j.dueDate ? ` · due ${j.dueDate}` : " · no due"}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="tabular text-[var(--color-muted)]">
                    {j.hours > 0 ? `${j.hours}h` : "no quote"}
                  </span>
                  <Badge tone={statusToBadgeTone(tone)}>
                    {j.live ? "On machine" : j.pulled ? "Pulled" : "Assigned"}
                  </Badge>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
