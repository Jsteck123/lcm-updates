/**
 * Every sticker kind has its own scan landing and instructions.
 * Material / leftover-bar stickers open the cut-queue picker.
 * Job, PO, and ship labels will not use this page when we print them.
 */

export type LabelKind = "material" | "piece" | "box" | "unknown";

export type LabelKindInfo = {
  kind: LabelKind;
  title: string;
  /** Floor-facing. Shown after the camera opens the sticker. */
  instructions: string;
};

export function classifyLabelCode(code: string): LabelKind {
  const up = (code || "").trim().toUpperCase();
  if (!up) return "unknown";
  if (up.startsWith("LCMBOX")) return "box";
  if (up.startsWith("LCMM")) return "material";
  if (up.startsWith("LCM")) return "piece";
  return "unknown";
}

export function labelKindInfo(kind: LabelKind): LabelKindInfo {
  if (kind === "box") {
    return {
      kind,
      title: "Packed box sticker",
      instructions:
        "This is a packed carton. The page shows customer, PO, part, rev, and qty. Check it off when it is loaded on the truck.",
    };
  }
  if (kind === "material") {
    return {
      kind,
      title: "Rack size sticker",
      instructions:
        "Jobs in the cut queue that use this material are listed. Pick the job you are running. Cut length and leftover qty fill in. Enter how many you just cut.",
    };
  }
  if (kind === "piece") {
    return {
      kind,
      title: "Leftover bar sticker",
      instructions:
        "This is one leftover bar. Matching cut-queue jobs are listed. Pick the job, enter how many you just cut. Remaining length on this bar drops by cut length × qty.",
    };
  }
  return {
    kind: "unknown",
    title: "Unknown sticker",
    instructions:
      "This code is not a rack, leftover-bar, or packed-box sticker. Each label kind has its own instructions.",
  };
}
