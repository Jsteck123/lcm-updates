import type { WorkQueueItem, WorkQueueStatus } from "./types";

export function emptyWorkQueueItem(
  partial?: Partial<WorkQueueItem>,
): WorkQueueItem {
  const now = new Date().toISOString();
  return {
    id: partial?.id || "",
    shopOrderId: partial?.shopOrderId || "",
    shopOrderLineId: partial?.shopOrderLineId || "",
    poNumber: partial?.poNumber || "",
    customer: partial?.customer || "",
    partNumber: (partial?.partNumber || "").toUpperCase(),
    revision: partial?.revision || "",
    description: partial?.description || "",
    qty: partial?.qty ?? 1,
    qtyCompleted: partial?.qtyCompleted ?? 0,
    machine: partial?.machine || "",
    operatorName: partial?.operatorName || "",
    opIndex:
      typeof partial?.opIndex === "number" && Number.isFinite(partial.opIndex)
        ? Math.max(0, Math.floor(partial.opIndex))
        : undefined,
    sortOrder: partial?.sortOrder ?? 0,
    status: partial?.status || "queued",
    notes: partial?.notes || "",
    jobId: partial?.jobId ?? null,
    createdAt: partial?.createdAt || now,
    updatedAt: partial?.updatedAt || now,
    createdBy: partial?.createdBy || "",
  };
}

/** Drop running-order rows for this line (and optional P/N + OP). */
export function dropWorkQueueMatches(
  queue: WorkQueueItem[],
  opts: {
    orderId: string;
    lineId: string;
    partNumber?: string;
    opIndex?: number | null;
  },
): WorkQueueItem[] {
  const pn = String(opts.partNumber || "")
    .trim()
    .toUpperCase();
  const focus =
    typeof opts.opIndex === "number" && Number.isFinite(opts.opIndex)
      ? Math.floor(opts.opIndex)
      : null;
  return (queue || []).filter((q) => {
    if (q.shopOrderId !== opts.orderId) return true;
    if (q.shopOrderLineId !== opts.lineId) return true;
    if (pn && (q.partNumber || "").toUpperCase() !== pn) return true;
    if (focus != null) {
      const qOp =
        typeof q.opIndex === "number" && Number.isFinite(q.opIndex)
          ? q.opIndex
          : null;
      if (qOp !== focus) return true;
    }
    return false;
  });
}

export function nextSortOrder(
  queue: WorkQueueItem[],
  machine: string,
): number {
  const same = queue.filter(
    (q) =>
      q.machine === machine &&
      (q.status === "queued" || q.status === "held" || q.status === "active"),
  );
  if (!same.length) return 10;
  return Math.max(...same.map((q) => q.sortOrder || 0)) + 10;
}

export function queueForMachine(
  queue: WorkQueueItem[],
  machine: string,
  statuses: WorkQueueStatus[] = ["queued", "held", "active"],
): WorkQueueItem[] {
  return queue
    .filter(
      (q) =>
        q.machine === machine &&
        statuses.includes(q.status),
    )
    .sort((a, b) => a.sortOrder - b.sortOrder || a.createdAt.localeCompare(b.createdAt));
}

export function queueForOperator(
  queue: WorkQueueItem[],
  operatorName: string,
  statuses: WorkQueueStatus[] = ["queued", "held", "active"],
): WorkQueueItem[] {
  const name = operatorName.trim().toLowerCase();
  if (!name) return [];
  return queue
    .filter(
      (q) =>
        (q.operatorName || "").trim().toLowerCase() === name &&
        statuses.includes(q.status),
    )
    .sort((a, b) => {
      if (a.machine !== b.machine) return a.machine.localeCompare(b.machine);
      return a.sortOrder - b.sortOrder;
    });
}

export function openQueue(queue: WorkQueueItem[]): WorkQueueItem[] {
  return queue
    .filter((q) => q.status === "queued" || q.status === "held" || q.status === "active")
    .sort((a, b) => {
      if (a.machine !== b.machine) return a.machine.localeCompare(b.machine);
      return a.sortOrder - b.sortOrder;
    });
}
