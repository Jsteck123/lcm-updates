/** Base materials and alloy/temper grades for the Master Quoter. */

export const MATERIALS = [
  "Aluminum",
  "Steel",
  "Stainless Steel",
  "Carbon Steel",
  "Tool Steel",
  "Brass",
  "Bronze",
  "Copper",
  "Titanium",
  "Plastic",
  "Other",
  "Customer Supplied",
] as const;

export type MaterialName = (typeof MATERIALS)[number];

/**
 * Material type (alloy / temper / grade) options keyed by base material.
 * Keep lists practical for a job shop — not every mill catalog entry.
 */
export const MATERIAL_TYPES: Record<string, string[]> = {
  Aluminum: [
    "T6 6061",
    "T651 6061",
    "T6 7075",
    "T651 7075",
    "T3 2024",
    "T351 2024",
    "T6 7050",
    "O 5052",
    "H32 5052",
    "H34 5052",
    "T6 6063",
    "Cast 356",
    "Other Aluminum",
  ],
  Steel: [
    "1018",
    "1020",
    "1045",
    "12L14",
    "4140",
    "4140 HT",
    "4340",
    "8620",
    "A36",
    "16ga CRS",
    "14ga CRS",
    "11ga CRS",
    "Hot Rolled",
    "Cold Rolled",
    "Other Steel",
  ],
  "Stainless Steel": [
    "303",
    "304",
    "304L",
    "316",
    "316L",
    "17-4 PH",
    "15-5 PH",
    "410",
    "416",
    "420",
    "440C",
    "Other Stainless",
  ],
  "Carbon Steel": [
    "A36",
    "1018",
    "1020",
    "1045",
    "12L14",
    "CRS",
    "HRS",
    "Other Carbon Steel",
  ],
  "Tool Steel": [
    "A2",
    "D2",
    "O1",
    "S7",
    "H13",
    "M2",
    "P20",
    "Other Tool Steel",
  ],
  Brass: [
    "360",
    "C360",
    "464 Naval",
    "Other Brass",
  ],
  Bronze: [
    "932 Bearing",
    "954 Aluminum Bronze",
    "Other Bronze",
  ],
  Copper: [
    "C110",
    "OFHC",
    "Other Copper",
  ],
  Titanium: [
    "Grade 2",
    "Grade 5 (6Al-4V)",
    "Other Titanium",
  ],
  Plastic: [
    "Delrin (Acetal)",
    "Nylon",
    "UHMW",
    "PEEK",
    "PTFE (Teflon)",
    "Polycarbonate",
    "Acrylic",
    "Other Plastic",
  ],
  Other: ["Custom / See notes"],
};

export function materialTypesFor(material: string): string[] {
  if (!material) return [];
  const exact = MATERIAL_TYPES[material];
  if (exact) return exact;
  // case-insensitive fallback
  const key = Object.keys(MATERIAL_TYPES).find(
    (k) => k.toLowerCase() === material.toLowerCase(),
  );
  return key ? MATERIAL_TYPES[key] : ["Other"];
}

/** Options list that always includes the current value if it's not in the list (legacy data). */
export function materialTypeOptions(material: string, currentType?: string): string[] {
  const base = [...materialTypesFor(material)];
  const cur = (currentType || "").trim();
  if (cur && !base.some((t) => t.toLowerCase() === cur.toLowerCase())) {
    base.unshift(cur);
  }
  return base;
}
