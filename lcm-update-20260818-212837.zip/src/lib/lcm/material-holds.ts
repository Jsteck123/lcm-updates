import type { MaterialHold, MaterialStock, ShopOrderLine } from "./types";
import { estimateMaterialUnits } from "./po-material";

export const HOLD_STALE_DAYS = 30;
const HOLD_STALE_MS = HOLD_STALE_DAYS * 24 * 60 * 60 * 1000;

export function pendingHolds(list: MaterialHold[] | undefined): MaterialHold[] {
  return (list || []).filter((h) => h.status === "pending");
}

export function pendingQtyForStock(
  list: MaterialHold[] | undefined,
  stockId: string,
  exceptLineId?: string,
): number {
  if (!stockId) return 0;
  return pendingHolds(list)
    .filter(
      (h) =>
        h.stockId === stockId &&
        (!exceptLineId || h.shopOrderLineId !== exceptLineId),
    )
    .reduce((n, h) => n + (Number(h.qty) || 0), 0);
}

export function availableOnHand(
  row: Pick<MaterialStock, "id" | "onHand">,
  list: MaterialHold[] | undefined,
  exceptLineId?: string,
): number {
  const book = Number(row.onHand) || 0;
  const hold = pendingQtyForStock(list, row.id, exceptLineId);
  return Math.round(Math.max(0, book - hold) * 1000) / 1000;
}

export function holdIsStale(
  h: MaterialHold,
  now = Date.now(),
): boolean {
  if (h.status !== "pending") return false;
  const t = Date.parse(h.confirmedAt || h.createdAt || "");
  if (!Number.isFinite(t)) return false;
  return now - t >= HOLD_STALE_MS;
}

export function staleHolds(list: MaterialHold[] | undefined): MaterialHold[] {
  const now = Date.now();
  return pendingHolds(list).filter((h) => holdIsStale(h, now));
}

export function holdAgeDays(h: MaterialHold, now = Date.now()): number {
  const t = Date.parse(h.confirmedAt || h.createdAt || "");
  if (!Number.isFinite(t)) return 0;
  return Math.max(0, Math.floor((now - t) / 86400000));
}

export function lineHoldQty(line: ShopOrderLine): number {
  const needed = Number(line.materialNeeded) || 0;
  if (needed > 0) return Math.round(needed * 1000) / 1000;
  const est = estimateMaterialUnits({
    orderQty: Number(line.qty) || 0,
    partLengthEach: Number(line.partLengthEach) || 0,
    rawMaterialLength: Number(line.rawMaterialLength) || 0,
    stockShape: line.stockShape || "",
  });
  return Math.round((est.needed || 0) * 1000) / 1000;
}

/** Inches still spoken-for: leftover pcs of the original need. */
export function lineHoldQtyRemaining(line: ShopOrderLine): number {
  const full = lineHoldQty(line);
  const qty = Number(line.qty) || 0;
  const done = Number(line.qtyCompleted) || 0;
  if (qty <= 0) return full;
  const open = Math.max(0, qty - done);
  if (line.lineStatus === "cancelled" || open <= 0) return 0;
  return Math.round(full * (open / qty) * 1000) / 1000;
}

export function cutHoldQty(locValue: number, qty: number): number {
  return Math.round(Math.max(0, Number(locValue) || 0) * Math.max(0, Number(qty) || 0) * 1000) / 1000;
}

export function findHoldForLine(
  list: MaterialHold[] | undefined,
  lineId: string,
): MaterialHold | undefined {
  return pendingHolds(list).find((h) => h.shopOrderLineId === lineId);
}

export function pendingHoldsForOrder(
  list: MaterialHold[] | undefined,
  orderId: string,
): MaterialHold[] {
  if (!orderId) return [];
  return pendingHolds(list).filter((h) => h.shopOrderId === orderId);
}
