import { createServerFn } from "@tanstack/react-start";

export const listShopLabelPrinters = createServerFn({ method: "POST" })
  .validator((data: { token?: string } = {}) => data ?? {})
  .handler(async ({ data }) => {
    const { verifyShopToken } = await import("./shop-session.server");
    if (!verifyShopToken(data?.token)) {
      return { ok: false as const, error: "Unlock this PC first." };
    }
    const { discoverPrinterIps } = await import("./print-label.server");
    return {
      ok: true as const,
      ips: discoverPrinterIps(),
      windows: process.platform === "win32",
    };
  });

export const printLabelOnShopHost = createServerFn({ method: "POST" })
  .validator(
    (data: {
      token?: string;
      ip?: string;
      width: number;
      height: number;
      pixelsB64: string;
    }) => data,
  )
  .handler(async ({ data }) => {
    const { verifyShopToken } = await import("./shop-session.server");
    if (!verifyShopToken(data.token)) {
      return { ok: false as const, error: "Unlock this PC first (Switch user / PIN)." };
    }
    const { printMonoOnQlWifi } = await import("./print-label.server");
    return printMonoOnQlWifi({
      ip: data.ip,
      width: data.width,
      height: data.height,
      pixelsB64: data.pixelsB64,
    });
  });
