import type { Quote, ShopOrder } from "./types";

export type PairHint = {
  partNumber: string;
  revision: string;
  quantity: number;
  customer: string;
  source: "quote" | "po" | "dash";
};

function normPn(pn: string): string {
  return (pn || "").trim().toUpperCase();
}

/** FD01-0088-02 → { prefix: "FD01-0088", suffix: "02" } */
export function splitDashPn(pn: string): { prefix: string; suffix: string } | null {
  const s = normPn(pn);
  const m = s.match(/^(.*)-(\d{2,3})$/);
  if (!m) return null;
  return { prefix: m[1]!, suffix: m[2]! };
}

export function isLikelyPairPn(a: string, b: string): boolean {
  const x = splitDashPn(a);
  const y = splitDashPn(b);
  if (!x || !y) return false;
  if (x.prefix !== y.prefix) return false;
  if (x.suffix === y.suffix) return false;
  const na = Number(x.suffix);
  const nb = Number(y.suffix);
  return Math.abs(na - nb) === 1;
}

function quoteByPn(quotes: Quote[], pn: string): Quote | undefined {
  const key = normPn(pn);
  return quotes.find((q) => normPn(q.partNumber) === key);
}

/** Explicit quote link, or a dash-sibling on the same PO / in the quote book. */
export function findPairHint(
  partNumber: string,
  opts: {
    quotes: Quote[];
    shopOrders?: ShopOrder[];
    preferQty?: number;
    preferRev?: string;
    preferCustomer?: string;
  },
): PairHint | null {
  const pn = normPn(partNumber);
  if (!pn) return null;
  const quotes = opts.quotes || [];

  const fromQuote = quoteByPn(quotes, pn);
  const explicit = normPn(fromQuote?.pairedPartNumber || "");
  const reverse = quotes.find((q) => normPn(q.pairedPartNumber || "") === pn);
  const named = explicit || (reverse ? normPn(reverse.partNumber) : "");

  const hit = (other: string, source: PairHint["source"]): PairHint | null => {
    const o = normPn(other);
    if (!o || o === pn) return null;
    const q = quoteByPn(quotes, o);
    if (fromQuote?.kind === "assembly" && splitDashPn(pn)?.suffix === "01") {
      if (source !== "quote") return null;
    }
    return {
      partNumber: o,
      revision: (opts.preferRev || q?.revision || fromQuote?.revision || "A").toUpperCase(),
      quantity: opts.preferQty || q?.quantities?.find((n) => n > 0) || 1,
      customer: opts.preferCustomer || q?.customer || fromQuote?.customer || "",
      source,
    };
  };

  if (named) return hit(named, "quote");

  for (const order of opts.shopOrders || []) {
    for (const line of order.lines || []) {
      const linePn = normPn(line.partNumber);
      if (isLikelyPairPn(pn, linePn)) {
        return hit(linePn, "po");
      }
      for (const c of line.components || []) {
        const cPn = normPn(c.partNumber);
        if (isLikelyPairPn(pn, cPn)) return hit(cPn, "po");
      }
    }
  }

  const split = splitDashPn(pn);
  if (!split) return null;
  const n = Number(split.suffix);
  const pad = split.suffix.length;
  const neighbors = [n + 1, n - 1]
    .filter((x) => x > 0)
    .map((x) => `${split.prefix}-${String(x).padStart(pad, "0")}`);
  for (const cand of neighbors) {
    if (fromQuote?.kind === "assembly" && split.suffix === "01") continue;
    if (quoteByPn(quotes, cand)) return hit(cand, "dash");
  }
  return null;
}
