/**
 * One shop language for stock.
 *
 * X Y Z = the blank sitting in the machine (not the finished model).
 * LOC   = Length of Cut — the axis the saw cuts, and how long that cut is.
 *         Model 3" → cut 3.1" so you can machine .05" off each end.
 * The other faces stay mill/lathe stock (may be a model surface — do not saw them).
 */
import type { LocAxis, ShopOrder, ShopOrderLine } from "./types";
import { profileForShape, isSheetOrPlate, isTubeShape } from "./stock-shapes";

export type StockProcess = "mill" | "lathe" | "";

const SHAPE_ALIASES: Record<string, string> = {
  rd: "Round Stock",
  round: "Round Stock",
  "round stock": "Round Stock",
  "round bar": "Round Stock",
  bar: "Round Stock",
  "bar stock": "Round Stock",
  hex: "Hex Stock",
  "hex stock": "Hex Stock",
  sq: "Square Stock",
  square: "Square Stock",
  "square stock": "Square Stock",
  rect: "Rectangular Stock",
  rectangle: "Rectangular Stock",
  "rectangle stock": "Rectangular Stock",
  "rectangular stock": "Rectangular Stock",
  flat: "Flat Bar",
  "flat bar": "Flat Bar",
  "flat stock": "Flat Bar",
  plate: "Plate",
  sheet: "Flat Sheet",
  "flat sheet": "Flat Sheet",
  "cast plate": "Cast Plate",
  tube: "Round Tube",
  "round tube": "Round Tube",
  "square tube": "Square Tube",
  "sq tube": "Square Tube",
  "rect tube": "Rectangular Tube",
  "rectangular tube": "Rectangular Tube",
  "rectangle tube": "Rectangular Tube",
  pipe: "Pipe",
  angle: "Angle Stock",
  "angle stock": "Angle Stock",
  channel: "Channel",
};

const PLACEHOLDER = new Set([
  "",
  "material shape",
  "material type",
  "rd/sq/ang stock",
  "rd sq ang stock",
  "stock shape",
  "shape",
  "n/a",
  "na",
  "none",
  "-",
  "select",
]);

export function isPlaceholderShape(raw: string): boolean {
  return PLACEHOLDER.has((raw || "").trim().toLowerCase());
}

export function canonicalizeShape(raw: string): string {
  const s = (raw || "").trim();
  if (isPlaceholderShape(s)) return "";
  const hit = SHAPE_ALIASES[s.toLowerCase()];
  return hit || s;
}

export function guessProcess(opts: {
  process?: StockProcess;
  machines?: string[];
  stockShape?: string;
}): StockProcess {
  if (opts.process === "mill" || opts.process === "lathe") return opts.process;
  const machines = opts.machines || [];
  const millish = machines.some((m) => /mill|vf|vm|umc|dt|dmtg/i.test(m));
  const latheish = machines.some((m) => /lathe|sl-|st-|ds\d|tl-/i.test(m));
  if (latheish && !millish) return "lathe";
  if (millish && !latheish) return "mill";
  const id = profileForShape(canonicalizeShape(opts.stockShape || "")).id;
  if (id === "round" || id === "hex" || id === "round-tube" || id === "pipe")
    return "lathe";
  if (id === "sheet" || id === "rectangular" || id === "flat-bar" || id === "square" || id === "square-tube" || id === "rectangular-tube")
    return "mill";
  return "";
}

export function guessShapeFromDims(opts: {
  dimX: number;
  dimY: number;
  dimZ: number;
  machines?: string[];
}): string {
  const x = Number(opts.dimX) || 0;
  const y = Number(opts.dimY) || 0;
  const z = Number(opts.dimZ) || 0;
  const proc = guessProcess({ machines: opts.machines });
  if (proc === "lathe") return "Round Stock";
  if (x > 0 && !(y > 0)) return "Round Stock";
  if (x > 0 && y > 0 && Math.abs(x - y) < 0.02) return "Square Stock";
  if (z > 0 && z < 1 && (x >= 6 || y >= 6)) return "Plate";
  if (x > 0 && y > 0) return "Rectangular Stock";
  return "";
}

export type AxisKey = "x" | "y" | "z";

export function axisLabels(
  shape: string,
  process: StockProcess = "",
): Record<AxisKey, string> {
  if (process === "lathe") {
    return {
      x: "X · diameter",
      y: "Y · (not used)",
      z: "Z · length of cut (LOC)",
    };
  }
  const id = profileForShape(shape).id;
  if (id === "round" || id === "hex") {
    return {
      x: id === "hex" ? "X · across flats" : "X · diameter",
      y: "Y · (not used)",
      z: "Z · length in the machine",
    };
  }
  if (id === "round-tube") {
    return {
      x: "OD · outside diameter",
      y: "Wall thickness",
      z: "Z · (not used)",
    };
  }
  if (id === "square-tube") {
    return {
      x: "OD · outside",
      y: "Y · (same as outside)",
      z: "Wall thickness",
    };
  }
  if (id === "rectangular-tube") {
    return {
      x: "Outside width",
      y: "Outside height",
      z: "Wall thickness",
    };
  }
  if (id === "sheet") {
    return {
      x: "X · width in the machine",
      y: "Y · length in the machine",
      z: "Z · thickness",
    };
  }
  return {
    x: "X · as it sits in the mill",
    y: "Y · as it sits in the mill",
    z: "Z · as it sits in the mill",
  };
}

export function defaultLocAxis(
  shape: string,
  process: StockProcess = "",
): LocAxis {
  if (process === "lathe") return "z";
  const id = profileForShape(shape).id;
  if (id === "round" || id === "hex" || id === "round-tube" || id === "pipe")
    return "z";
  if (id === "sheet") return "x";
  return "z";
}

export function locChoices(
  shape: string,
  process: StockProcess = "",
): { axis: LocAxis; label: string }[] {
  if (process === "lathe") {
    return [{ axis: "z", label: "Z · length of cut (saw this axis)" }];
  }
  return [
    { axis: "x", label: "X · length of cut (saw this axis)" },
    { axis: "y", label: "Y · length of cut (saw this axis)" },
    { axis: "z", label: "Z · length of cut (saw this axis)" },
  ];
}

export function locValue(
  axis: LocAxis | "",
  dims: { dimX: number; dimY: number; dimZ: number },
): number {
  if (axis === "x") return Number(dims.dimX) || 0;
  if (axis === "y") return Number(dims.dimY) || 0;
  if (axis === "z") return Number(dims.dimZ) || 0;
  return 0;
}

export function describeStock(opts: {
  material?: string;
  materialType?: string;
  stockShape: string;
  dimX: number;
  dimY: number;
  dimZ: number;
  locAxis?: LocAxis | "";
  partLengthEach?: number;
  stockProcess?: StockProcess;
}): string {
  const alloy = [opts.material, opts.materialType].filter(Boolean).join(" ");
  const shape = canonicalizeShape(opts.stockShape) || "stock";
  const proc = opts.stockProcess || "";
  const x = Number(opts.dimX) || 0;
  const y = Number(opts.dimY) || 0;
  const z = Number(opts.dimZ) || 0;
  const id = profileForShape(shape).id;
  let size = "";
  if (id === "round-tube") {
    const wall = y || z;
    size = x ? `${x}" OD` : "";
    if (wall) size += size ? ` × ${wall}" wall` : `${wall}" wall`;
  } else if (id === "square-tube") {
    const od = x || y;
    const wall = z || (y && y !== x ? y : 0);
    size = od ? `${od}" × ${od}"` : "";
    if (wall) size += size ? ` × ${wall}" wall` : `${wall}" wall`;
  } else if (id === "rectangular-tube") {
    size = [x, y].filter((n) => n > 0).map((n) => `${n}"`).join(" × ");
    if (z) size += size ? ` × ${z}" wall` : `${z}" wall`;
  } else if (proc === "lathe" || id === "round") {
    size = x ? `${x}" Ø` : "";
    if (z) size += size ? ` × ${z}" long` : `${z}" long`;
  } else {
    size = [x, y, z].filter((n) => n > 0).map((n) => `${n}"`).join(" × ");
  }
  const loc = Number(opts.partLengthEach) || (isTubeShape(shape) ? 0 : locValue(opts.locAxis || "", opts));
  const locBit = loc
    ? ` LOC ${!isTubeShape(shape) && opts.locAxis && opts.locAxis !== "dia" ? opts.locAxis.toUpperCase() + " " : ""}${loc}" (length of cut).`
    : "";
  return [alloy, shape, size].filter(Boolean).join(" · ") + locBit;
}

export function findShopLineForPart(
  orders: ShopOrder[],
  partNumber: string,
  revision?: string,
): { orderId: string; line: ShopOrderLine } | null {
  const pn = (partNumber || "").trim().toUpperCase();
  if (!pn) return null;
  const rev = (revision || "").trim().toUpperCase();
  let loose: { orderId: string; line: ShopOrderLine } | null = null;
  for (const o of orders || []) {
    for (const line of o.lines || []) {
      if ((line.partNumber || "").trim().toUpperCase() !== pn) continue;
      if (rev && (line.revision || "").trim().toUpperCase() === rev) {
        return { orderId: o.id, line };
      }
      if (!loose) loose = { orderId: o.id, line };
    }
  }
  return loose;
}

export function stockIsPicked(line: {
  material?: string;
  dimX?: number;
  dimY?: number;
  dimZ?: number;
  partLengthEach?: number;
  locAxis?: string;
  materialReviewed?: boolean;
}): boolean {
  if (line.materialReviewed) return true;
  if ((Number(line.partLengthEach) || 0) > 0) return true;
  if (line.locAxis) return true;
  return (
    Boolean((line.material || "").trim()) &&
    ((Number(line.dimX) || 0) > 0 ||
      (Number(line.dimY) || 0) > 0 ||
      (Number(line.dimZ) || 0) > 0)
  );
}

export { isSheetOrPlate };
