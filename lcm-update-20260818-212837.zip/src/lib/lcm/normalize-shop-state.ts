/**
 * Shared shop-state normalization (seed merge, legacy field backfill).
 * Extracted from shop-store.server so routes/store can reuse one path.
 */
import { createSeedState } from "./seed";
import type { ShopSharedState } from "./shop-types";
import { mergeQuoteLists } from "./po-material";
import { mergeChatMessages } from "./chat";
import type { Operator, ShopOrder, ShopOrderLine, AppSettings } from "./types";
import { normalizeMaterialPriceBook } from "./material-rates";
import {
  normalizeLineFiles,
  promoteRelatedFilesToComponents,
  normalizeComponents,
} from "./line-files";
import { normalizeOpAssignments } from "./op-slots";

export function normalizeShopOrderLines(
  lines: Partial<ShopOrderLine>[] | undefined,
): ShopOrderLine[] {
  return (lines || []).map((l) => {
    const promoted = promoteRelatedFilesToComponents(l);
    const files = normalizeLineFiles(promoted);
    return {
    ...(l as ShopOrderLine),
    material: l.material || "",
    materialType: l.materialType || "",
    stockShape: l.stockShape || "",
    materialVendor: l.materialVendor || "",
    materialNeeded: l.materialNeeded ?? 0,
    materialOnHand: l.materialOnHand ?? 0,
    materialStockId: l.materialStockId || "",
    materialLocation: l.materialLocation || "",
    finishedOnHand: l.finishedOnHand ?? 0,
    finishedStockId: l.finishedStockId || "",
    materialMatch: l.materialMatch || "none",
    materialStatus: l.materialStatus || "unchecked",
    attentionReason: l.attentionReason || "",
    materialReviewed: Boolean(l.materialReviewed),
    quoteId: l.quoteId || "",
    sizeNote: l.sizeNote || "",
    dimX: l.dimX ?? 0,
    dimY: l.dimY ?? 0,
    dimZ: l.dimZ ?? 0,
    partLengthEach: l.partLengthEach ?? 0,
    rawMaterialLength: l.rawMaterialLength ?? 0,
    ...files,
    components: normalizeComponents({ ...l, ...promoted }),
    revPdfOk: Boolean(l.revPdfOk),
    revCadOk: Boolean(l.revCadOk),
    stockNoted: Boolean(l.stockNoted),
    checkedOutBy: l.checkedOutBy || "",
    checkedOutAt: l.checkedOutAt || "",
    checkedOutMachine: l.checkedOutMachine || "",
    officeAssignedTo: l.officeAssignedTo || "",
    officeAssignedMachine: l.officeAssignedMachine || "",
    officeAssignedAt: l.officeAssignedAt || "",
    officeAssignNotes: l.officeAssignNotes || "",
    opAssignments: normalizeOpAssignments(l.opAssignments),
    boardHidden: Boolean(l.boardHidden),
    readyForPack: Boolean(l.readyForPack),
    readyForPackAt: l.readyForPackAt || "",
    readyForPackBy: l.readyForPackBy || "",
    linePacked: Boolean(l.linePacked),
    linePackedAt: l.linePackedAt || "",
    linePackedBy: l.linePackedBy || "",
    lineStatus: l.lineStatus === "cancelled" ? "cancelled" : "active",
    cancelledAt: l.cancelledAt || "",
    cancelledReason: l.cancelledReason || "",
  };
  });
}

export function normalizeShopOrder(o: Partial<ShopOrder>): ShopOrder {
  return {
    ...(o as ShopOrder),
    poRevision: o.poRevision || "",
    priorPoFiles: Array.isArray(o.priorPoFiles) ? o.priorPoFiles : [],
    packStatus: o.packStatus || "pending",
    packedBy: o.packedBy || "",
    packedAt: o.packedAt || "",
    verifiedBy: o.verifiedBy || "",
    verifiedAt: o.verifiedAt || "",
    deliveredAt: o.deliveredAt || "",
    deliveredBy: o.deliveredBy || "",
    signedSlipFileId: o.signedSlipFileId || "",
    signedSlipName: o.signedSlipName || "",
    signedSlipMime: o.signedSlipMime || "",
    invoicedInQb: Boolean(o.invoicedInQb),
    invoicedAt: o.invoicedAt || "",
    paymentReceived: Boolean(o.paymentReceived),
    paymentReceivedAt: o.paymentReceivedAt || "",
    closedAt: o.closedAt || "",
    lines: normalizeShopOrderLines(o.lines),
  };
}

export function sliceSharedFromSeed(): ShopSharedState {
  const s = createSeedState();
  return {
    operators: s.operators,
    customers: s.customers,
    quotes: s.quotes,
    jobs: s.jobs,
    downtimes: s.downtimes,
    operatorTimeLog: s.operatorTimeLog,
    auditLog: s.auditLog,
    sessions: s.sessions,
    activeTimers: s.activeTimers,
    dayBonuses: s.dayBonuses || [],
    weeklyPayouts: s.weeklyPayouts || [],
    materialStock: s.materialStock || [],
    materialHolds: s.materialHolds || [],
    partStock: s.partStock || [],
    partUnits: s.partUnits || [],
    inventoryTxns: s.inventoryTxns || [],
    purchaseOrders: s.purchaseOrders || [],
    vendorRfqs: s.vendorRfqs || [],
    shopOrders: (s.shopOrders || []).map((o) => normalizeShopOrder(o)),
    workQueue: s.workQueue || [],
    cutTickets: s.cutTickets || [],
    stockPieces: s.stockPieces || [],
    packBoxes: s.packBoxes || [],
    quoteHistory: s.quoteHistory || [],
    emailLog: s.emailLog || [],
    poFollowups: s.poFollowups || [],
    chatMessages: s.chatMessages || [],
    shopToolingLogs: s.shopToolingLogs || [],
    feedbackTickets: s.feedbackTickets || [],
    settings: s.settings,
  };
}

export function normalizeShopState(state: ShopSharedState): ShopSharedState {
  return {
    ...state,
    dayBonuses: state.dayBonuses || [],
    weeklyPayouts: state.weeklyPayouts || [],
    materialStock: state.materialStock || [],
    materialHolds: state.materialHolds || [],
    partStock: state.partStock || [],
    partUnits: state.partUnits || [],
    inventoryTxns: state.inventoryTxns || [],
    purchaseOrders: state.purchaseOrders || [],
    vendorRfqs: state.vendorRfqs || [],
    shopOrders: (state.shopOrders || []).map((o) => normalizeShopOrder(o)),
    workQueue: state.workQueue || [],
    cutTickets: state.cutTickets || [],
    stockPieces: state.stockPieces || [],
    packBoxes: state.packBoxes || [],
    quoteHistory: state.quoteHistory || [],
    emailLog: state.emailLog || [],
    poFollowups: state.poFollowups || [],
    chatMessages: state.chatMessages || [],
    shopToolingLogs: state.shopToolingLogs || [],
    feedbackTickets: state.feedbackTickets || [],
    settings: {
      ...state.settings,
      quoteFromEmail: state.settings?.quoteFromEmail || "",
      shopPublicUrl: String(state.settings?.shopPublicUrl || "").trim(),
      averageMaxRuns: state.settings?.averageMaxRuns ?? 10,
      averageShopWeight: state.settings?.averageShopWeight ?? 0.7,
      averageOutlierRatio: state.settings?.averageOutlierRatio ?? 1.5,
      materialPriceBook: normalizeMaterialPriceBook(
        state.settings?.materialPriceBook,
      ),
    },
  };
}

export function mergeSharedWithSeed(state: ShopSharedState): ShopSharedState {
  const seed = sliceSharedFromSeed();
  // Live/host state wins. Seed is only a template for missing fields on brand-new installs.
  // Empty arrays on the host (go-live wipe) must stay empty — do not re-inject seed demos.
  return {
    ...seed,
    ...state,
    quotes: Array.isArray(state.quotes)
      ? state.quotes
      : mergeQuoteLists(seed.quotes, state.quotes),
    purchaseOrders: state.purchaseOrders ?? seed.purchaseOrders ?? [],
    vendorRfqs: state.vendorRfqs ?? seed.vendorRfqs ?? [],
    shopOrders: (state.shopOrders ?? seed.shopOrders ?? []).map((o) =>
      normalizeShopOrder(o),
    ),
    workQueue: state.workQueue ?? seed.workQueue ?? [],
    cutTickets: state.cutTickets ?? seed.cutTickets ?? [],
    stockPieces: state.stockPieces ?? seed.stockPieces ?? [],
    packBoxes: state.packBoxes ?? seed.packBoxes ?? [],
    materialStock: state.materialStock ?? seed.materialStock ?? [],
    materialHolds: state.materialHolds ?? seed.materialHolds ?? [],
    partStock: state.partStock ?? seed.partStock ?? [],
    inventoryTxns: state.inventoryTxns ?? seed.inventoryTxns ?? [],
    jobs: state.jobs ?? seed.jobs ?? [],
    customers: state.customers ?? seed.customers ?? [],
    operators: state.operators?.length ? state.operators : seed.operators,
    chatMessages: Array.isArray(state.chatMessages)
      ? state.chatMessages
      : mergeChatMessages(seed.chatMessages, state.chatMessages),
    feedbackTickets: state.feedbackTickets ?? seed.feedbackTickets ?? [],
  };
}

/**
 * Strip secrets before sending shop state to browsers.
 * Clients only see placeholder pin / password markers + hasPin flags.
 */
export function stripSecretsForClient(state: ShopSharedState): ShopSharedState {
  return {
    ...state,
    operators: state.operators.map((op) => {
      const hasPin = Boolean(op.pin && String(op.pin).length > 0);
      return {
        ...op,
        pin: hasPin ? "••••" : "",
        hasPin,
      } as Operator & { hasPin: boolean };
    }),
    settings: {
      ...state.settings,
      editPassword: state.settings.editPassword ? "••••" : "",
      hasEditPassword: Boolean(state.settings.editPassword),
    } as AppSettings & { hasEditPassword: boolean },
  };
}
