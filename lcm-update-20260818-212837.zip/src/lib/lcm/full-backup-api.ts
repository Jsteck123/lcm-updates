import { createServerFn } from "@tanstack/react-start";

async function requireAdmin(token?: string) {
  const { verifyShopToken } = await import("./shop-session.server");
  const session = verifyShopToken(token);
  if (!session) {
    return {
      ok: false as const,
      error: "Unlock with your admin PIN first.",
    };
  }
  if (session.role !== "admin") {
    return { ok: false as const, error: "Admin only" };
  }
  return { ok: true as const };
}

export const createUsbFullBackup = createServerFn({ method: "POST" })
  .validator((data: { token?: string } = {}) => data ?? {})
  .handler(async ({ data }) => {
    const gate = await requireAdmin(data?.token);
    if (!gate.ok) return gate;
    const { createFullUsbBackup } = await import("./full-backup.server");
    return createFullUsbBackup();
  });

export const listUsbFullBackups = createServerFn({ method: "POST" })
  .validator((data: { token?: string } = {}) => data ?? {})
  .handler(async ({ data }) => {
    const gate = await requireAdmin(data?.token);
    if (!gate.ok) return gate;
    const { listUsbBackups } = await import("./full-backup.server");
    return { ok: true as const, backups: listUsbBackups() };
  });
