/**
 * Multi drawing/CAD per PO line (assemblies).
 * Legacy drawingId/cadFileId stay in sync with the first entry of each list.
 */
import type { LineFileRef, ShopLineComponent, ShopOrderLine } from "./types";
import { normalizeOpAssignments } from "./op-slots";


export function pnSegments(pn: string): string[] {
  return String(pn || "")
    .toUpperCase()
    .trim()
    .split(/[-_]/)
    .filter(Boolean);
}

/** Last hyphen segment: 01, 02, C, D, … */
export function lastPnSegment(pn: string): string {
  const segs = pnSegments(pn);
  return segs[segs.length - 1] || "";
}

/** True for assembly detail numbers: -01, -02, -03 (not -C rev letters). */
export function isNumericDetailSuffix(seg: string): boolean {
  return /^\d{2,3}$/.test(String(seg || "").trim());
}

/** Single-letter (or short alpha) revision tail used in drawing file names. */
export function isLetterRevSuffix(seg: string): boolean {
  const s = String(seg || "").trim().toUpperCase();
  if (!s) return false;
  if (/^[A-Z]$/.test(s)) return true; // -A … -Z
  if (/^REV[A-Z0-9]{0,3}$/.test(s)) return true;
  return false;
}

/**
 * Base without trailing detail/rev: FD01-0010-01 → FD01-0010, FD01-0010-C → FD01-0010
 */
export function partBaseKey(pn: string): string {
  const segs = pnSegments(pn);
  if (segs.length < 2) return segs.join("-") || String(pn || "").toUpperCase();
  const last = segs[segs.length - 1]!;
  if (isNumericDetailSuffix(last) || isLetterRevSuffix(last)) {
    return segs.slice(0, -1).join("-");
  }
  return segs.join("-");
}

/** @deprecated use partBaseKey — kept for callers */
export function partFamilyKey(pn: string): string {
  return partBaseKey(pn);
}

/**
 * True only when candidate is a real assembly sibling of parent:
 * same base + both end in numeric -01/-02/… and different.
 * FD01-0010-01 + FD01-0010-02 → yes
 * FD01-0010-01 + FD01-0010-C  → no (rev letter on drawing)
 * 4201-0200-02 + 4201-0200-D  → no
 */
export function isAssemblyComponentOf(
  parentPn: string,
  candidatePn: string,
): boolean {
  const a = String(parentPn || "").toUpperCase().trim();
  const b = String(candidatePn || "").toUpperCase().trim();
  if (!a || !b || a === b) return false;
  const la = lastPnSegment(a);
  const lb = lastPnSegment(b);
  if (!isNumericDetailSuffix(la) || !isNumericDetailSuffix(lb)) return false;
  if (la === lb) return false;
  return partBaseKey(a) === partBaseKey(b) && Boolean(partBaseKey(a));
}

/** Drawing/CAD token is the same part as the PO line (incl. rev-letter filenames). */
export function isSamePartFileAsLine(linePn: string, token: string): boolean {
  const a = String(linePn || "").toUpperCase().trim();
  const b = String(token || "").toUpperCase().trim();
  if (!a || !b) return false;
  if (a === b) return true;
  // FD01-0010-01 vs FD01-0010-C or FD01-0010
  if (partBaseKey(a) && partBaseKey(a) === partBaseKey(b)) {
    // letter rev on file, or stripped base only
    if (isLetterRevSuffix(lastPnSegment(b))) return true;
    if (b === partBaseKey(a)) return true;
    // same numeric detail
    if (
      isNumericDetailSuffix(lastPnSegment(a)) &&
      isNumericDetailSuffix(lastPnSegment(b)) &&
      lastPnSegment(a) === lastPnSegment(b)
    ) {
      return true;
    }
  }
  return false;
}

/** True if candidate is same P/N or a true -02/-03 sibling (not rev letters). */
export function isRelatedPartNumber(parentPn: string, candidatePn: string): boolean {
  const a = String(parentPn || "").toUpperCase().trim();
  const b = String(candidatePn || "").toUpperCase().trim();
  if (!a || !b) return false;
  if (a === b) return true;
  if (isSamePartFileAsLine(a, b)) return true;
  return isAssemblyComponentOf(a, b);
}

/** Pull a part-like token from a filename for related matching. */
export function extractPartTokenFromFileName(fileName: string): string {
  let base = String(fileName || "")
    .replace(/\.[^.]+$/, "")
    .toUpperCase();
  // Strip common rev suffixes so 1234-4567-02_RevA → 1234-4567-02
  base = base
    .replace(/[ _-]?REV(?:ISION)?[ _-]?[A-Z0-9]{1,4}$/i, "")
    .replace(/[ _-]R[0-9A-Z]{1,3}$/i, "");
  // Prefer longest dashed P/N (do not stop at hyphen via \b)
  const matches = base.match(/[A-Z0-9]{2,}(?:-[A-Z0-9]{1,12}){1,5}/g);
  if (matches?.length) {
    return matches.sort((a, b) => b.length - a.length)[0]!;
  }
  const compact = base.replace(/[^A-Z0-9]+/g, "");
  return compact.slice(0, 16);
}

function asRef(
  id: string,
  name: string,
  mime: string,
  relatedPartNumber?: string,
): LineFileRef {
  const r: LineFileRef = {
    id: id || "",
    name: name || "",
    mime: mime || "application/octet-stream",
  };
  if (relatedPartNumber?.trim()) {
    r.relatedPartNumber = relatedPartNumber.trim().toUpperCase();
  }
  return r;
}

/** Normalize drawings/cadFiles arrays + legacy primary fields. */
export function normalizeLineFiles(
  line: Partial<ShopOrderLine>,
): Pick<
  ShopOrderLine,
  | "drawings"
  | "cadFiles"
  | "drawingId"
  | "drawingName"
  | "drawingMime"
  | "cadFileId"
  | "cadFileName"
  | "cadFileMime"
> {
  let drawings = Array.isArray(line.drawings)
    ? line.drawings
        .filter((f) => f && f.id)
        .map((f) =>
          asRef(f.id, f.name, f.mime, f.relatedPartNumber),
        )
    : [];
  let cadFiles = Array.isArray(line.cadFiles)
    ? line.cadFiles
        .filter((f) => f && f.id)
        .map((f) =>
          asRef(f.id, f.name, f.mime, f.relatedPartNumber),
        )
    : [];

  // Backfill from legacy singles
  if (!drawings.length && line.drawingId) {
    drawings = [
      asRef(
        line.drawingId,
        line.drawingName || "",
        line.drawingMime || "",
      ),
    ];
  }
  if (!cadFiles.length && line.cadFileId) {
    cadFiles = [
      asRef(
        line.cadFileId,
        line.cadFileName || "",
        line.cadFileMime || "",
      ),
    ];
  }

  // Dedupe by id
  const dedupe = (list: LineFileRef[]) => {
    const seen = new Set<string>();
    const out: LineFileRef[] = [];
    for (const f of list) {
      if (seen.has(f.id)) continue;
      seen.add(f.id);
      out.push(f);
    }
    return out;
  };
  drawings = dedupe(drawings);
  cadFiles = dedupe(cadFiles);

  const d0 = drawings[0];
  const c0 = cadFiles[0];
  return {
    drawings,
    cadFiles,
    drawingId: d0?.id || "",
    drawingName: d0?.name || "",
    drawingMime: d0?.mime || "",
    cadFileId: c0?.id || "",
    cadFileName: c0?.name || "",
    cadFileMime: c0?.mime || "",
  };
}

export function lineDrawings(line: Partial<ShopOrderLine> | null | undefined): LineFileRef[] {
  return normalizeLineFiles(line || {}).drawings;
}

export function lineCadFiles(line: Partial<ShopOrderLine> | null | undefined): LineFileRef[] {
  return normalizeLineFiles(line || {}).cadFiles;
}

export function lineHasCad(line: Partial<ShopOrderLine> | null | undefined): boolean {
  return lineCadFiles(line).length > 0;
}

/** Add a file to a line (no silent replace — appends if new id). */
export function addFileToLine(
  line: Partial<ShopOrderLine>,
  kind: "drawing" | "cad",
  file: { id: string; name: string; mime?: string },
  relatedPartNumber?: string,
): Partial<ShopOrderLine> {
  const cur = normalizeLineFiles(line);
  const ref = asRef(
    file.id,
    file.name,
    file.mime || "application/octet-stream",
    relatedPartNumber,
  );
  if (!ref.id) return normalizeLineFiles(line);
  if (kind === "cad") {
    const cadFiles = cur.cadFiles.some((f) => f.id === ref.id)
      ? cur.cadFiles
      : [...cur.cadFiles, ref];
    return normalizeLineFiles({ ...line, cadFiles, drawings: cur.drawings });
  }
  const drawings = cur.drawings.some((f) => f.id === ref.id)
    ? cur.drawings
    : [...cur.drawings, ref];
  return normalizeLineFiles({ ...line, drawings, cadFiles: cur.cadFiles });
}

export function removeFileFromLine(
  line: Partial<ShopOrderLine>,
  kind: "drawing" | "cad",
  fileId: string,
): Partial<ShopOrderLine> {
  const cur = normalizeLineFiles(line);
  if (kind === "cad") {
    return normalizeLineFiles({
      ...line,
      drawings: cur.drawings,
      cadFiles: cur.cadFiles.filter((f) => f.id !== fileId),
    });
  }
  return normalizeLineFiles({
    ...line,
    drawings: cur.drawings.filter((f) => f.id !== fileId),
    cadFiles: cur.cadFiles,
  });
}

/**
 * Match a package file to the best PO line:
 * 1) exact / same-part (drawing named with rev letter -C stays on the line)
 * 2) true assembly child only when token ends in -02/-03 numeric detail
 */
export function matchFileToAssemblyLine(
  partNumbers: string[],
  fileName: string,
): { partNumber: string; relatedPartNumber: string; exact: boolean } | null {
  const token = extractPartTokenFromFileName(fileName);
  if (!token) return null;
  const parts = partNumbers.map((p) => p.toUpperCase().trim()).filter(Boolean);

  // Exact P/N in name
  for (const pn of parts) {
    if (
      fileName.toUpperCase().includes(pn) ||
      token === pn ||
      token.replace(/[^A-Z0-9]/g, "") === pn.replace(/[^A-Z0-9]/g, "")
    ) {
      return { partNumber: pn, relatedPartNumber: pn, exact: true };
    }
  }

  // Same part, rev-letter filename (FD01-0010-C.pdf for line FD01-0010-01)
  for (const pn of parts) {
    if (isSamePartFileAsLine(pn, token)) {
      return { partNumber: pn, relatedPartNumber: pn, exact: true };
    }
  }

  // True component file: 1234-4567-02.* under line 1234-4567-01
  for (const pn of parts) {
    if (isAssemblyComponentOf(pn, token)) {
      return {
        partNumber: pn,
        relatedPartNumber: token,
        exact: false,
      };
    }
  }
  return null;
}


function newId(): string {
  return `c_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export function emptyComponent(
  partial?: Partial<ShopLineComponent>,
): ShopLineComponent {
  return {
    id: partial?.id || newId(),
    partNumber: (partial?.partNumber || "").toUpperCase(),
    revision: (partial?.revision || "").toUpperCase(),
    description: partial?.description || "",
    qty: partial?.qty ?? 1,
    drawings: Array.isArray(partial?.drawings) ? partial!.drawings! : [],
    cadFiles: Array.isArray(partial?.cadFiles) ? partial!.cadFiles! : [],
    checkedOutBy: partial?.checkedOutBy || "",
    checkedOutAt: partial?.checkedOutAt || "",
    checkedOutMachine: partial?.checkedOutMachine || "",
    officeAssignedTo: partial?.officeAssignedTo || "",
    officeAssignedMachine: partial?.officeAssignedMachine || "",
    officeAssignedAt: partial?.officeAssignedAt || "",
    officeAssignNotes: partial?.officeAssignNotes || "",
    complete: Boolean(partial?.complete),
    completedAt: partial?.completedAt || "",
    completedBy: partial?.completedBy || "",
    notes: partial?.notes || "",
    boardHidden: Boolean(partial?.boardHidden),
    opAssignments: normalizeOpAssignments(partial?.opAssignments),
  };
}

export function normalizeComponents(
  line: Partial<ShopOrderLine>,
): ShopLineComponent[] {
  const list = Array.isArray(line.components) ? line.components : [];
  return list
    .filter((c) => c && (c.partNumber || c.id))
    .map((c) => emptyComponent(c));
}

/** All components complete (or no components). */
export function allComponentsComplete(line: Partial<ShopOrderLine>): boolean {
  const comps = normalizeComponents(line);
  if (!comps.length) return true;
  return comps.every((c) => c.complete);
}

/**
 * Move related-P/N files off the line bag into components[] so shop can
 * pull -02 / -03 as separate jobs under assembly -01.
 */
/**
 * Move ONLY true -02/-03 component files into components[].
 * Rev-letter drawings (…-C, …-D) stay on the parent line — not fake assemblies.
 * Also demotes previously mis-tagged letter "components" back to line files.
 */
export function promoteRelatedFilesToComponents(
  line: Partial<ShopOrderLine>,
): Partial<ShopOrderLine> {
  const parent = (line.partNumber || "").toUpperCase().trim();
  const files = normalizeLineFiles(line);
  const existing = normalizeComponents(line);
  const parentDraw: LineFileRef[] = [...files.drawings];
  const parentCad: LineFileRef[] = [...files.cadFiles];
  let comps: ShopLineComponent[] = [];

  // Keep only real numeric-detail components; fold fakes back into line files
  for (const c of existing) {
    const cpn = (c.partNumber || "").toUpperCase();
    if (parent && isAssemblyComponentOf(parent, cpn)) {
      comps.push(emptyComponent(c));
    } else {
      for (const f of c.drawings || []) parentDraw.push(f);
      for (const f of c.cadFiles || []) parentCad.push(f);
    }
  }

  function upsertComp(
    pn: string,
    kind: "drawing" | "cad",
    ref: LineFileRef,
  ) {
    const key = pn.toUpperCase();
    if (!parent || !isAssemblyComponentOf(parent, key)) return false;
    let c = comps.find((x) => x.partNumber.toUpperCase() === key);
    if (!c) {
      c = emptyComponent({
        partNumber: key,
        qty: Number(line.qty) || 1,
        revision: line.revision || "",
        description: `Component of ${parent || "assembly"}`,
      });
      comps = [...comps, c];
    }
    const bag = kind === "cad" ? "cadFiles" : "drawings";
    if (!c[bag].some((f) => f.id === ref.id)) {
      c = {
        ...c,
        [bag]: [...c[bag], { ...ref, relatedPartNumber: key }],
      };
      comps = comps.map((x) => (x.id === c!.id ? c! : x));
    }
    return true;
  }

  const keepDraw: LineFileRef[] = [];
  for (const f of parentDraw) {
    const rel = (f.relatedPartNumber || "").toUpperCase();
    const token = extractPartTokenFromFileName(f.name);
    let target = "";
    if (rel && isAssemblyComponentOf(parent, rel)) target = rel;
    else if (token && isAssemblyComponentOf(parent, token)) target = token;
    if (target && upsertComp(target, "drawing", f)) {
      // moved to component
    } else {
      // strip bogus relatedPartNumber (rev letter tags)
      const { relatedPartNumber: _r, ...rest } = f;
      keepDraw.push(
        rest.id
          ? {
              id: f.id,
              name: f.name,
              mime: f.mime,
            }
          : f,
      );
    }
  }

  const keepCad: LineFileRef[] = [];
  for (const f of parentCad) {
    const rel = (f.relatedPartNumber || "").toUpperCase();
    const token = extractPartTokenFromFileName(f.name);
    let target = "";
    if (rel && isAssemblyComponentOf(parent, rel)) target = rel;
    else if (token && isAssemblyComponentOf(parent, token)) target = token;
    if (target && upsertComp(target, "cad", f)) {
      // moved
    } else {
      keepCad.push({
        id: f.id,
        name: f.name,
        mime: f.mime,
      });
    }
  }

  comps = comps
    .filter((c) => isAssemblyComponentOf(parent, c.partNumber))
    .sort((a, b) => a.partNumber.localeCompare(b.partNumber));

  return {
    ...normalizeLineFiles({
      ...line,
      drawings: keepDraw,
      cadFiles: keepCad,
    }),
    components: comps,
  };
}

export function addFileToComponent(
  line: Partial<ShopOrderLine>,
  componentId: string,
  kind: "drawing" | "cad",
  file: { id: string; name: string; mime?: string },
): Partial<ShopOrderLine> {
  const comps = normalizeComponents(line).map((c) => {
    if (c.id !== componentId) return c;
    const ref: LineFileRef = {
      id: file.id,
      name: file.name,
      mime: file.mime || "application/octet-stream",
      relatedPartNumber: c.partNumber,
    };
    const bag = kind === "cad" ? "cadFiles" : "drawings";
    if (c[bag].some((f) => f.id === ref.id)) return c;
    return { ...c, [bag]: [...c[bag], ref] };
  });
  return { components: comps };
}

export function patchComponent(
  line: Partial<ShopOrderLine>,
  componentId: string,
  patch: Partial<ShopLineComponent>,
): Partial<ShopOrderLine> {
  const comps = normalizeComponents(line).map((c) =>
    c.id === componentId ? emptyComponent({ ...c, ...patch, id: c.id }) : c,
  );
  return { components: comps };
}
