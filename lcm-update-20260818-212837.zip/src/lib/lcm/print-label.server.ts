/**
 * Send a Brother QL-810W raster job over Wi-Fi (TCP 9100).
 * No Windows print queue. No Paint. No Edge.
 */
import { spawnSync } from "node:child_process";
import net from "node:net";
import { buildQl810ContinuousJob, decodeMonoPixels } from "./ql-raster";

const PORT = 9100;

function runPs(command: string): string {
  if (process.platform !== "win32") return "";
  const r = spawnSync(
    "powershell.exe",
    ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", command],
    { encoding: "utf8", timeout: 12000, windowsHide: true },
  );
  return String(r.stdout || "").trim();
}

function ipsFromText(text: string): string[] {
  const found = text.match(/\b\d{1,3}(?:\.\d{1,3}){3}\b/g) || [];
  return [...new Set(found)].filter((ip) => {
    const p = ip.split(".").map(Number);
    if (p.some((n) => n > 255)) return false;
    if (p[0] === 127 || p[0] === 0 || p[0] === 255) return false;
    return true;
  });
}

/** IPs Windows already knows for printers (TCP/IP ports, IP_x.x.x.x names). */
export function discoverPrinterIps(): string[] {
  const chunks: string[] = [];
  chunks.push(
    runPs(
      "Get-PrinterPort | ForEach-Object { $_.Name + ' ' + $_.PrinterHostAddress }",
    ),
  );
  chunks.push(runPs("Get-Printer | ForEach-Object { $_.Name + ' ' + $_.PortName }"));
  return ipsFromText(chunks.join("\n"));
}

function sendRaster(ip: string, job: Buffer): Promise<void> {
  return new Promise((resolve, reject) => {
    let settled = false;
    const fail = (err: Error) => {
      if (settled) return;
      settled = true;
      reject(err);
    };
    const ok = () => {
      if (settled) return;
      settled = true;
      resolve();
    };
    const sock = net.connect({ host: ip, port: PORT }, () => {
      sock.write(job, (err) => {
        if (err) {
          sock.destroy();
          fail(err);
          return;
        }
        sock.end();
      });
    });
    sock.setTimeout(10000);
    sock.on("timeout", () => {
      sock.destroy();
      fail(new Error("QL-810W at " + ip + " did not answer on Wi-Fi (port 9100)."));
    });
    sock.on("error", (err) => {
      fail(
        new Error(
          "Could not reach QL-810W at " +
            ip +
            " over Wi-Fi. " +
            (err.message || "Connection failed"),
        ),
      );
    });
    sock.on("close", () => {
      if (!settled) ok();
    });
  });
}

export async function printMonoOnQlWifi(opts: {
  ip?: string;
  width: number;
  height: number;
  pixelsB64: string;
}): Promise<{ ok: true; ip: string } | { ok: false; error: string; ips?: string[] }> {
  const discovered = discoverPrinterIps();
  const ip = String(opts.ip || discovered[0] || "").trim();
  if (!ip) {
    return {
      ok: false,
      error:
        "Type the QL-810W Wi-Fi address (the number on the printer or in Brother setup). Example 10.200.1.50",
      ips: discovered,
    };
  }
  if (!/^\d{1,3}(?:\.\d{1,3}){3}$/.test(ip)) {
    return { ok: false, error: "That is not a Wi-Fi address.", ips: discovered };
  }
  let job: Buffer;
  try {
    const bmp = decodeMonoPixels(opts.width, opts.height, opts.pixelsB64);
    job = buildQl810ContinuousJob(bmp);
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not build label" };
  }
  try {
    await sendRaster(ip, job);
    return { ok: true, ip };
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : "Wi-Fi print failed",
      ips: discovered,
    };
  }
}
