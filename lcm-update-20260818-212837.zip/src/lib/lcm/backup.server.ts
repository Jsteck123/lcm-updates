/**
 * Rotating backups of the shop database on the host PC.
 * Hourly snapshots: last 8. Labeled (pre-update / pre-restore / manual): last 6.
 * Shop data itself is never deleted by prune — only extra copies in data/backups/.
 */
import fs from "node:fs";
import path from "node:path";

const DATA_DIR = path.join(process.cwd(), "data");
const DATA_FILE = path.join(DATA_DIR, "lcm-shop.json");
const BACKUP_DIR = path.join(DATA_DIR, "backups");
const MAX_HOURLY = 8;
const MAX_LABELED = 6;

export type BackupMeta = {
  id: string;
  fileName: string;
  createdAt: string;
  sizeBytes: number;
  rev: number | null;
  label: string;
};

function ensureDirs() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });
}

export function listBackups(): BackupMeta[] {
  ensureDirs();
  const files = fs
    .readdirSync(BACKUP_DIR)
    .filter((f) => f.endsWith(".json"))
    .sort()
    .reverse();
  const out: BackupMeta[] = [];
  for (const fileName of files) {
    const full = path.join(BACKUP_DIR, fileName);
    try {
      const st = fs.statSync(full);
      let rev: number | null = null;
      let createdAt = st.mtime.toISOString();
      try {
        const raw = fs.readFileSync(full, "utf8");
        const parsed = JSON.parse(raw) as {
          rev?: number;
          updatedAt?: string;
          backupMeta?: { createdAt?: string; label?: string };
        };
        if (typeof parsed.rev === "number") rev = parsed.rev;
        if (parsed.backupMeta?.createdAt) createdAt = parsed.backupMeta.createdAt;
        else if (parsed.updatedAt) createdAt = parsed.updatedAt;
        out.push({
          id: fileName.replace(/\.json$/, ""),
          fileName,
          createdAt,
          sizeBytes: st.size,
          rev,
          label: parsed.backupMeta?.label || "auto",
        });
      } catch {
        out.push({
          id: fileName.replace(/\.json$/, ""),
          fileName,
          createdAt,
          sizeBytes: st.size,
          rev: null,
          label: "auto",
        });
      }
    } catch {
      /* skip */
    }
  }
  return out.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );
}

function pruneOld() {
  const all = listBackups();
  const hourly = all.filter((b) => b.label === "auto" || b.label === "hourly");
  const labeled = all.filter((b) => b.label !== "auto" && b.label !== "hourly");
  const drop = [...hourly.slice(MAX_HOURLY), ...labeled.slice(MAX_LABELED)];
  for (const b of drop) {
    try {
      fs.unlinkSync(path.join(BACKUP_DIR, b.fileName));
    } catch {
      /* ignore */
    }
  }
}

/** Copy current shop DB to backups/. Safe no-op if DB missing. */
export function createBackup(label = "auto"): BackupMeta | null {
  ensureDirs();
  if (!fs.existsSync(DATA_FILE)) return null;
  const raw = fs.readFileSync(DATA_FILE, "utf8");
  let rev: number | null = null;
  let parsed: Record<string, unknown> = {};
  try {
    parsed = JSON.parse(raw) as Record<string, unknown>;
    if (typeof parsed.rev === "number") rev = parsed.rev;
  } catch {
    parsed = { raw: true };
  }
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const id = `backup-${stamp}`;
  const fileName = `${id}.json`;
  const payload = {
    ...parsed,
    backupMeta: {
      id,
      createdAt: new Date().toISOString(),
      label,
    },
  };
  const full = path.join(BACKUP_DIR, fileName);
  const tmp = `${full}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(payload), "utf8");
  fs.renameSync(tmp, full);
  pruneOld();
  const st = fs.statSync(full);
  return {
    id,
    fileName,
    createdAt: new Date().toISOString(),
    sizeBytes: st.size,
    rev,
    label,
  };
}

/** Restore a backup file over the live DB. Returns true if restored. */
export function restoreBackup(fileName: string): {
  ok: boolean;
  error?: string;
} {
  ensureDirs();
  const safe = path.basename(fileName);
  if (!safe.endsWith(".json") || safe.includes("..")) {
    return { ok: false, error: "Invalid backup name" };
  }
  const full = path.join(BACKUP_DIR, safe);
  if (!fs.existsSync(full)) return { ok: false, error: "Backup not found" };
  try {
    // Safety: backup current before restore
    createBackup("pre-restore");
    const raw = fs.readFileSync(full, "utf8");
    const parsed = JSON.parse(raw) as { rev?: number; state?: unknown };
    if (!parsed || typeof parsed.rev !== "number" || !parsed.state) {
      return { ok: false, error: "Backup file is not a valid shop snapshot" };
    }
    // Strip backupMeta for live file
    const { backupMeta: _b, ...live } = parsed as Record<string, unknown>;
    const tmp = `${DATA_FILE}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(live), "utf8");
    fs.renameSync(tmp, DATA_FILE);
    return { ok: true };
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : "Restore failed",
    };
  }
}

export function backupFolderHint(): string {
  return BACKUP_DIR;
}

export function readBackupFile(
  fileName: string,
): { fileName: string; json: string } | null {
  ensureDirs();
  const safe = path.basename(fileName);
  if (!safe.endsWith(".json") || safe.includes("..")) return null;
  const full = path.join(BACKUP_DIR, safe);
  if (!fs.existsSync(full)) return null;
  return { fileName: safe, json: fs.readFileSync(full, "utf8") };
}

/** First-run: keep at least one copy if the live DB exists. */
export function ensureFirstBackup(): BackupMeta | null {
  ensureDirs();
  if (listBackups().length > 0) return null;
  return createBackup("startup");
}

/** Create backup if last one is older than minIntervalMs (default 1 hour) or force. */
export function maybeAutoBackup(minIntervalMs = 60 * 60 * 1000): BackupMeta | null {
  const list = listBackups().filter((b) => b.label === "auto" || b.label === "hourly");
  const latest = list[0];
  if (
    latest &&
    Date.now() - new Date(latest.createdAt).getTime() < minIntervalMs
  ) {
    return null;
  }
  return createBackup("hourly");
}
