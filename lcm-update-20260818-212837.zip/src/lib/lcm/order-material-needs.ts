import type {
  MaterialStock,
  ShopOrder,
  VendorRfq,
} from "./types";
import {
  estimateMaterialUnits,
  normalizeSizeKey,
  onHandInNeedUnits,
  parseShopSize,
  stockMatchesRecipe,
  DEFAULT_BAR_LENGTH_IN,
  roundShopInches,
  isCustomerSuppliedMaterial,
  isBoughtBlankMaterial,
} from "./po-material";
import { isSheetOrPlate } from "./stock-shapes";
import { shopLineOpenQty } from "./po";
import { materialLabel } from "./inventory";

export { isCustomerSuppliedMaterial, isBoughtBlankMaterial };

function norm(s: string): string {
  return (s || "").trim().toLowerCase().replace(/\s+/g, " ");
}

export function stockNeedKey(opts: {
  material: string;
  materialType: string;
  stockShape: string;
  sizeNote: string;
  dimX?: number;
  dimY?: number;
  dimZ?: number;
  partLengthEach?: number;
}): string {
  const parsed = parseShopSize({
    stockShape: opts.stockShape,
    sizeNote: opts.sizeNote,
    dimX: opts.dimX,
    dimY: opts.dimY,
    dimZ: opts.dimZ,
    partLengthEach: opts.partLengthEach,
  });
  const sizeKey = parsed.section.length
    ? parsed.section.join("x")
    : normalizeSizeKey(opts.sizeNote || "");
  return [
    norm(opts.material),
    norm(opts.materialType),
    norm(opts.stockShape),
    sizeKey,
  ].join("|");
}

export type OrderBuyRow = {
  key: string;
  material: string;
  materialType: string;
  stockShape: string;
  sizeNote: string;
  qtyNeeded: number;
  onHand: number;
  toBuy: number;
  unit: "sheet" | "in" | "pcs";
  partNumbers: string[];
  customerSupplied: boolean;
  missingSize: boolean;
};

export function computeShopOrderBuyList(
  order: ShopOrder | null | undefined,
  materialStock: MaterialStock[],
): OrderBuyRow[] {
  if (!order) return [];
  const map = new Map<string, OrderBuyRow>();

  for (const line of order.lines || []) {
    if (line.lineStatus === "cancelled") continue;
    const open = shopLineOpenQty(line);
    if (open <= 0) continue;
    if (!line.material?.trim()) continue;

    const supplied = isCustomerSuppliedMaterial(line);
    const boughtBlank = isBoughtBlankMaterial(line);
    const shape = line.stockShape || "";
    const sheet = isSheetOrPlate(shape);
    const barLen =
      sheet || boughtBlank
        ? 0
        : line.rawMaterialLength || line.dimZ || DEFAULT_BAR_LENGTH_IN;
    const est = boughtBlank
      ? { needed: open }
      : estimateMaterialUnits({
          orderQty: open,
          partLengthEach: line.partLengthEach || 0,
          rawMaterialLength: barLen,
          stockShape: shape,
        });
    const needed = boughtBlank
      ? open
      : line.materialReviewed &&
          line.materialNeeded > 0 &&
          (sheet || line.materialNeeded >= 10)
        ? line.materialNeeded
        : est.needed;

    const sizeNote = (line.sizeNote || "").trim();
    const key = stockNeedKey({
      material: line.material,
      materialType: line.materialType || "",
      stockShape: shape,
      sizeNote,
      dimX: line.dimX,
      dimY: line.dimY,
      dimZ: line.dimZ,
      partLengthEach: line.partLengthEach,
    });

    const want = {
      stockShape: shape,
      sizeNote,
      dimX: line.dimX,
      dimY: line.dimY,
      dimZ: line.dimZ,
      partLengthEach: line.partLengthEach,
      locAxis: line.locAxis,
    };
    const onHand = (materialStock || [])
      .filter((s) => {
        if (norm(s.material) !== norm(line.material)) return false;
        if (
          line.materialType &&
          s.materialType &&
          norm(s.materialType) !== norm(line.materialType)
        )
          return false;
        return stockMatchesRecipe(s, want);
      })
      .reduce(
        (n, s) =>
          n + onHandInNeedUnits(s, { barLengthIn: barLen, sheet }),
        0,
      );

    const prev = map.get(key);
    const pn = line.partNumber || "";
    if (prev) {
      prev.qtyNeeded += needed;
      prev.onHand = Math.max(prev.onHand, onHand);
      prev.toBuy = supplied
        ? 0
        : Math.max(0, roundShopInches(prev.qtyNeeded - prev.onHand));
      if (pn && !prev.partNumbers.includes(pn)) prev.partNumbers.push(pn);
      prev.missingSize = prev.missingSize && !sizeNote;
      continue;
    }
    map.set(key, {
      key,
      material: line.material,
      materialType: line.materialType || "",
      stockShape: shape,
      sizeNote,
      qtyNeeded: needed,
      onHand,
      toBuy: supplied ? 0 : Math.max(0, roundShopInches(needed - onHand)),
      unit: sheet ? "sheet" : boughtBlank ? "pcs" : "in",
      partNumbers: pn ? [pn] : [],
      customerSupplied: supplied,
      missingSize: boughtBlank ? false : !sizeNote && !(line.dimX > 0),
    });
  }

  return [...map.values()].sort((a, b) => {
    if (a.customerSupplied !== b.customerSupplied)
      return a.customerSupplied ? 1 : -1;
    return b.toBuy - a.toBuy || a.material.localeCompare(b.material);
  });
}

export function rfqsForShopOrder(
  order: ShopOrder | null | undefined,
  rfqs: VendorRfq[],
): VendorRfq[] {
  if (!order) return [];
  const refs = new Set(
    [order.poNumber, order.id]
      .map((x) => (x || "").trim().toLowerCase())
      .filter(Boolean),
  );
  return (rfqs || []).filter((r) => {
    if (r.status === "cancelled") return false;
    const ref = (r.shopOrderRef || "").trim().toLowerCase();
    return ref && refs.has(ref);
  });
}

export { materialLabel };
