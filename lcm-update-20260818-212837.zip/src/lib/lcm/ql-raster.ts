/**
 * Brother QL-810W raster job for DK-2210 (29 mm continuous).
 * Bytes match pklaus/brother_ql (QL-800 series).
 */

export const QL810_BYTES_PER_ROW = 90;
export const QL810_HEAD_DOTS = QL810_BYTES_PER_ROW * 8; // 720
export const DK2210_PRINTABLE_W = 306;
export const DK2210_RIGHT_MARGIN = 6;
export const DK2210_WIDTH_MM = 29;
export const DK2210_FEED_MARGIN = 35;
export const DK2210_MIN_LENGTH = 150;
export const MEDIA_CONTINUOUS = 0x0a;

export type MonoBitmap = {
  width: number;
  height: number;
  /** 0 = white, 1 = black, row-major, length width*height */
  pixels: Uint8Array;
};

function push(buf: number[], bytes: ArrayLike<number>) {
  for (let i = 0; i < bytes.length; i++) buf.push(bytes[i]!);
}

function packRow(dots: Uint8Array): Uint8Array {
  const out = new Uint8Array(QL810_BYTES_PER_ROW);
  const n = Math.min(dots.length, QL810_HEAD_DOTS);
  for (let x = 0; x < n; x++) {
    if (dots[x]) out[x >> 3] |= 0x80 >> (x & 7);
  }
  return out;
}

/** Build one 720-dot row: 306-wide bitmap placed for 29 mm tape, then mirrored. */
function placeRow(src: Uint8Array, srcW: number, y: number): Uint8Array {
  const full = new Uint8Array(QL810_HEAD_DOTS);
  const offset = QL810_HEAD_DOTS - DK2210_PRINTABLE_W - DK2210_RIGHT_MARGIN;
  const w = Math.min(srcW, DK2210_PRINTABLE_W);
  const rowStart = y * srcW;
  for (let x = 0; x < w; x++) {
    full[offset + x] = src[rowStart + x] ? 1 : 0;
  }
  full.reverse();
  return packRow(full);
}

export function buildQl810ContinuousJob(bitmap: MonoBitmap): Buffer {
  const w = bitmap.width;
  const h = Math.max(DK2210_MIN_LENGTH, bitmap.height);
  const src = bitmap.pixels;
  const rows: number[] = [];

  // invalidate
  for (let i = 0; i < 400; i++) rows.push(0);
  // ESC @ init
  push(rows, [0x1b, 0x40]);
  // ESC i a 01  raster mode
  push(rows, [0x1b, 0x69, 0x61, 0x01]);
  // ESC i z  media + quality
  // flags: 0x80 | type | width | length | quality
  const flags = 0x80 | (1 << 1) | (1 << 2) | (1 << 3) | (1 << 6);
  push(rows, [0x1b, 0x69, 0x7a, flags, MEDIA_CONTINUOUS, DK2210_WIDTH_MM, 0]);
  rows.push(h & 0xff, (h >> 8) & 0xff, (h >> 16) & 0xff, (h >> 24) & 0xff);
  rows.push(0x00, 0x00);
  // ESC i M  autocut on
  push(rows, [0x1b, 0x69, 0x4d, 0x40]);
  // ESC i A  cut every 1
  push(rows, [0x1b, 0x69, 0x41, 0x01]);
  // ESC i K  expanded: cut at end
  push(rows, [0x1b, 0x69, 0x4b, 0x08]);
  // ESC i d  feed margin
  push(rows, [0x1b, 0x69, 0x64, DK2210_FEED_MARGIN & 0xff, (DK2210_FEED_MARGIN >> 8) & 0xff]);
  // M 00  no compression
  push(rows, [0x4d, 0x00]);

  const lineCount = h;
  for (let y = 0; y < lineCount; y++) {
    const srcY = y < bitmap.height ? y : bitmap.height - 1;
    const packed = placeRow(src, w, srcY);
    // g 00 <len> <data>
    rows.push(0x67, 0x00, packed.length);
    push(rows, packed);
  }
  // last page print
  rows.push(0x1a);
  return Buffer.from(rows);
}

export function decodeMonoPixels(width: number, height: number, b64: string): MonoBitmap {
  const pixels = Uint8Array.from(Buffer.from(b64, "base64"));
  if (pixels.length < width * height) {
    throw new Error("Label bitmap was short");
  }
  return { width, height, pixels };
}
