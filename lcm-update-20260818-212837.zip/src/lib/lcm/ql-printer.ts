const KEY = "lcm-ql-ip";

export function loadQlPrinterIp(): string {
  if (typeof window === "undefined") return "";
  try {
    return localStorage.getItem(KEY) || "";
  } catch {
    return "";
  }
}

export function saveQlPrinterIp(ip: string) {
  if (typeof window === "undefined") return;
  try {
    const v = ip.trim();
    if (v) localStorage.setItem(KEY, v);
    else localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}
