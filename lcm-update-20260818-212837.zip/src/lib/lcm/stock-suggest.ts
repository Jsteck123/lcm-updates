import type { MaterialStock } from "./types";

const EXACT_IN = 0.03;
const OVER_IN = 0.5;

export type StockSuggestHit = {
  row: MaterialStock;
  why: string;
  suggested: boolean;
};

function norm(s: string) {
  return (s || "").trim().toLowerCase();
}

export function parseSizeNumbers(raw: string): number[] {
  const ms = String(raw || "").match(/\d+(?:\.\d+)?/g);
  if (!ms) return [];
  const out: number[] = [];
  for (const m of ms) {
    const n = Number(m);
    if (Number.isFinite(n) && n > 0 && n < 400) out.push(n);
  }
  return out;
}

export function shapeFamily(
  shape: string,
): "round" | "rect" | "sq" | "hex" | "tube" | "sheet" | "other" {
  const t = norm(shape);
  if (!t) return "other";
  if (t.includes("sheet") || t.includes("plate")) return "sheet";
  if (t.includes("tube")) return "tube";
  if (t.includes("hex")) return "hex";
  if (t.includes("square") || t.includes("sq ")) return "sq";
  if (t.includes("rect") || t.includes("flat") || t.includes("block"))
    return "rect";
  if (
    t.includes("round") ||
    t.includes("dia") ||
    t === "bar" ||
    t === "bar stock"
  )
    return "round";
  return "other";
}

function familyOk(want: string, have: string): boolean {
  const a = shapeFamily(want);
  const b = shapeFamily(have);
  if (a === "other" || b === "other") return true;
  if (a === b) return true;
  if ((a === "rect" || a === "sq") && (b === "rect" || b === "sq")) return true;
  if ((a === "round" || a === "tube") && (b === "round" || b === "tube"))
    return true;
  return false;
}

export function stockSectionDims(row: MaterialStock): number[] {
  const fields = [row.dimX, row.dimY, row.dimZ]
    .map((n) => Number(n) || 0)
    .filter((n) => n > 0);
  if (fields.length) return fields;
  return parseSizeNumbers(row.sizeNote);
}

function fmt(n: number) {
  const r = Math.round(n * 1000) / 1000;
  return Number.isInteger(r) ? String(r) : String(r);
}

function pairDims(
  want: number[],
  have: number[],
): { score: number; why: string } | null {
  if (!want.length || !have.length) return null;
  const used = new Set<number>();
  let exact = 0;
  let over = 0;
  const bits: string[] = [];

  for (const w of [...want].sort((a, b) => a - b)) {
    let bestI = -1;
    let bestKind: "exact" | "over" | null = null;
    let bestH = 0;
    let bestDelta = 99;
    have.forEach((h, i) => {
      if (used.has(i)) return;
      const d = h - w;
      if (Math.abs(d) <= EXACT_IN) {
        if (bestKind !== "exact" || Math.abs(d) < bestDelta) {
          bestI = i;
          bestKind = "exact";
          bestH = h;
          bestDelta = Math.abs(d);
        }
      } else if (d > 0 && d <= OVER_IN) {
        if (bestKind !== "exact" && d < bestDelta) {
          bestI = i;
          bestKind = "over";
          bestH = h;
          bestDelta = d;
        }
      }
    });
    if (bestI < 0 || !bestKind) continue;
    used.add(bestI);
    if (bestKind === "exact") {
      exact += 1;
      bits.push(`${fmt(bestH)}" same as ${fmt(w)}`);
    } else {
      over += 1;
      bits.push(`${fmt(bestH)}" covers ${fmt(w)}`);
    }
  }

  const need = want.length >= 2 ? 2 : 1;
  if (exact + over < need) return null;
  return {
    score: exact * 10 + over * 4,
    why: bits.slice(0, 3).join(" · "),
  };
}

/** Only rows close to the sizes being typed. Nothing until a size is typed. */
export function suggestCloseStock(
  stock: MaterialStock[],
  want: {
    material?: string;
    stockShape?: string;
    dimX?: number;
    dimY?: number;
    dimZ?: number;
    diameter?: number;
    partLengthEach?: number;
  },
): StockSuggestHit[] {
  const typed = [
    Number(want.dimX) || 0,
    Number(want.dimY) || 0,
    Number(want.dimZ) || 0,
    Number(want.diameter) || 0,
    Number(want.partLengthEach) || 0,
  ].filter((n) => n > 0);
  if (!typed.length) return [];

  const mat = norm(want.material || "");
  const hits: { row: MaterialStock; score: number; why: string }[] = [];

  for (const row of stock || []) {
    if (!(Number(row.onHand) > 0)) continue;
    if (mat && norm(row.material) !== mat) continue;
    if (!familyOk(want.stockShape || "", row.stockShape)) continue;
    const have = stockSectionDims(row);
    const pair = pairDims(typed, have);
    if (!pair) continue;
    let score = pair.score;
    if (want.stockShape && shapeFamily(want.stockShape) === shapeFamily(row.stockShape))
      score += 2;
    hits.push({ row, score, why: pair.why });
  }

  hits.sort((a, b) => b.score - a.score || b.row.onHand - a.row.onHand);
  const best = hits[0]?.score ?? 0;
  return hits.slice(0, 6).map((h, i) => ({
    row: h.row,
    why: h.why,
    suggested: i === 0 && best >= 10,
  }));
}
