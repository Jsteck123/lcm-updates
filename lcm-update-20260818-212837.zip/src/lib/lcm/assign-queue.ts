/**
 * Admin-only desk queue: walk POs, open drawings, assign part → person (+ optional machine).
 * Multi-machine quotes expand to one row per timed OP.
 */
import type { Quote, ShopOrder, ShopOrderLine } from "./types";
import {
  lineCadFiles,
  lineDrawings,
  normalizeComponents,
  promoteRelatedFilesToComponents,
} from "./line-files";
import { lineShipDate } from "./shipping-calendar";
import { opLabel } from "./ops";
import {
  getOpAssignment,
  isMultiMachinePart,
  quoteForPn,
  quoteOpMachine,
  remainingTimedOps,
  timedOpIndexes,
} from "./op-slots";

export type AssignQueueItem = {
  key: string;
  orderId: string;
  lineId: string;
  componentId: string;
  poNumber: string;
  customer: string;
  partNumber: string;
  revision: string;
  description: string;
  qty: number;
  dueDate: string;
  kind: "component" | "assembly" | "part";
  parentPartNumber: string;
  drawings: { id: string; name: string; mime?: string }[];
  cadFiles: { id: string; name: string; mime?: string }[];
  /** Already assigned at desk (this OP, or the whole part) */
  officeAssignedTo: string;
  /** 0-based OP when this row is one operation of a multi-machine job */
  opIndex: number | null;
  opLabel: string;
  quotedMachine: string;
};

function mapFiles(
  list: { id: string; name: string; mime?: string }[],
) {
  return (list || [])
    .filter((f) => f?.id)
    .map((f) => ({ id: f.id, name: f.name || "file", mime: f.mime }));
}

type HostAssign = {
  officeAssignedTo?: string;
  checkedOutBy?: string;
  opAssignments?: import("./types").ShopOpAssignment[];
};

function pushWhole(
  out: AssignQueueItem[],
  base: Omit<
    AssignQueueItem,
    "key" | "officeAssignedTo" | "opIndex" | "opLabel" | "quotedMachine"
  > & { keyBase: string },
  host: HostAssign,
) {
  const assigned = (host.officeAssignedTo || "").trim();
  const pulled = (host.checkedOutBy || "").trim();
  if (assigned && pulled) return;
  out.push({
    key: base.keyBase,
    orderId: base.orderId,
    lineId: base.lineId,
    componentId: base.componentId,
    poNumber: base.poNumber,
    customer: base.customer,
    partNumber: base.partNumber,
    revision: base.revision,
    description: base.description,
    qty: base.qty,
    dueDate: base.dueDate,
    kind: base.kind,
    parentPartNumber: base.parentPartNumber,
    drawings: base.drawings,
    cadFiles: base.cadFiles,
    officeAssignedTo: assigned,
    opIndex: null,
    opLabel: "",
    quotedMachine: "",
  });
}

function pushOps(
  out: AssignQueueItem[],
  base: Omit<
    AssignQueueItem,
    "key" | "officeAssignedTo" | "opIndex" | "opLabel" | "quotedMachine"
  > & { keyBase: string },
  host: HostAssign,
  quote: Quote | undefined,
) {
  const open = remainingTimedOps(quote, host.opAssignments);
  const idxs = open.length ? open : timedOpIndexes(quote);
  for (const opIndex of idxs) {
    const slot = getOpAssignment(host.opAssignments, opIndex);
    if (slot?.complete) continue;
    const assigned = (slot?.officeAssignedTo || "").trim();
    const pulled = (slot?.checkedOutBy || "").trim();
    if (assigned && pulled) continue;
    out.push({
      key: `${base.keyBase}:op${opIndex}`,
      orderId: base.orderId,
      lineId: base.lineId,
      componentId: base.componentId,
      poNumber: base.poNumber,
      customer: base.customer,
      partNumber: base.partNumber,
      revision: base.revision,
      description: base.description,
      qty: base.qty,
      dueDate: base.dueDate,
      kind: base.kind,
      parentPartNumber: base.parentPartNumber,
      drawings: base.drawings,
      cadFiles: base.cadFiles,
      officeAssignedTo: assigned,
      opIndex,
      opLabel: opLabel(opIndex),
      quotedMachine: slot?.officeAssignedMachine || quoteOpMachine(quote, opIndex),
    });
  }
}

/** Open items that still need office person assignment */
export function buildAssignQueue(
  orders: ShopOrder[],
  quotes: Quote[] = [],
): AssignQueueItem[] {
  const out: AssignQueueItem[] = [];
  for (const order of orders || []) {
    if (order.status === "cancelled" || order.deliveredAt) continue;
    for (const raw of order.lines || []) {
      if (raw.lineStatus === "cancelled") continue;
      if (raw.readyForPack || raw.linePacked) continue;
      if (!(raw.partNumber || raw.description)) continue;

      const promoted = promoteRelatedFilesToComponents(raw);
      const line = {
        ...raw,
        ...promoted,
        components: normalizeComponents({ ...raw, ...promoted }),
      } as ShopOrderLine;

      const due =
        lineShipDate(order, line) || order.dateRequired || "9999-12-31";
      const comps = normalizeComponents(line);

      if (comps.length > 0) {
        for (const c of comps) {
          if (c.complete) continue;
          if (c.boardHidden) continue;
          const quote = quoteForPn(quotes, c.partNumber);
          const base = {
            keyBase: `${order.id}:${line.id}:${c.id}`,
            orderId: order.id,
            lineId: line.id,
            componentId: c.id,
            poNumber: order.poNumber || "(no PO)",
            customer: order.customer || "",
            partNumber: c.partNumber,
            revision: c.revision || line.revision || "",
            description: c.description || line.description || "",
            qty: c.qty || line.qty || 1,
            dueDate: due,
            kind: "component" as const,
            parentPartNumber: line.partNumber,
            drawings: mapFiles(c.drawings || []),
            cadFiles: mapFiles(c.cadFiles || []),
          };
          if (isMultiMachinePart(quote)) pushOps(out, base, c, quote);
          else pushWhole(out, base, c);
        }
        const lineQuote = quoteForPn(quotes, line.partNumber);
        const lineBase = {
          keyBase: `${order.id}:${line.id}:`,
          orderId: order.id,
          lineId: line.id,
          componentId: "",
          poNumber: order.poNumber || "(no PO)",
          customer: order.customer || "",
          partNumber: line.partNumber,
          revision: line.revision || "",
          description: line.description || "",
          qty: line.qty || 1,
          dueDate: due,
          kind: "assembly" as const,
          parentPartNumber: "",
          drawings: mapFiles(lineDrawings(line)),
          cadFiles: mapFiles(lineCadFiles(line)),
        };
        if (!line.readyForPack && !line.boardHidden) {
          if (isMultiMachinePart(lineQuote)) pushOps(out, lineBase, line, lineQuote);
          else {
            const lineAssigned = (line.officeAssignedTo || "").trim();
            const linePulled = (line.checkedOutBy || "").trim();
            if (!(lineAssigned && linePulled)) pushWhole(out, lineBase, line);
          }
        }
      } else {
        if (line.boardHidden) continue;
        const quote = quoteForPn(quotes, line.partNumber);
        const base = {
          keyBase: `${order.id}:${line.id}:`,
          orderId: order.id,
          lineId: line.id,
          componentId: "",
          poNumber: order.poNumber || "(no PO)",
          customer: order.customer || "",
          partNumber: line.partNumber,
          revision: line.revision || "",
          description: line.description || "",
          qty: line.qty || 1,
          dueDate: due,
          kind: "part" as const,
          parentPartNumber: "",
          drawings: mapFiles(lineDrawings(line)),
          cadFiles: mapFiles(lineCadFiles(line)),
        };
        if (isMultiMachinePart(quote)) pushOps(out, base, line, quote);
        else pushWhole(out, base, line);
      }
    }
  }
  out.sort((a, b) => {
    const d = (a.dueDate || "").localeCompare(b.dueDate || "");
    if (d) return d;
    const p = (a.partNumber || "").localeCompare(b.partNumber || "");
    if (p) return p;
    const ao = a.opIndex == null ? -1 : a.opIndex;
    const bo = b.opIndex == null ? -1 : b.opIndex;
    return ao - bo;
  });
  return out;
}
