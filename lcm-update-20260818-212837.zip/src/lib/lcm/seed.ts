import type { LcmState } from "./types";
import { MACHINES } from "./types";
import { emptySession } from "./calculations";
import {
  ALL_TABS,
  DEFAULT_ADMIN_PIN,
  normalizeOperator,
} from "./permissions";
import { DEFAULT_OPERATIONS } from "./ops";
import { EMPTY_CUSTOM_LISTS } from "./lists";
import { defaultMaterialPriceBook } from "./material-rates";

/**
 * Clean production / go-live seed.
 * No demo customers, quotes, jobs, inventory, or sample operators.
 * Real company people only — add operators in Settings after install.
 */
export function createSeedState(): LcmState {
  const operators = [
    normalizeOperator({
      id: "op-james",
      name: "James Steck",
      email: "jsteck123@gmail.com",
      active: true,
      role: "admin",
      tabs: [...ALL_TABS],
      pin: DEFAULT_ADMIN_PIN,
    }),
    normalizeOperator({
      id: "op-pam",
      name: "Pam Steck",
      email: "pam@lakecountrymachine.com",
      active: true,
      role: "admin",
      tabs: [...ALL_TABS],
      pin: DEFAULT_ADMIN_PIN,
    }),
  ];

  const sessions: LcmState["sessions"] = {};
  const activeTimers: LcmState["activeTimers"] = {};
  for (const m of MACHINES) {
    sessions[m] = emptySession(m, DEFAULT_OPERATIONS);
    activeTimers[m] = null;
  }

  return {
    operators,
    customers: [],
    quotes: [],
    jobs: [],
    downtimes: [],
    operatorTimeLog: [],
    auditLog: [
      {
        id: "audit-golive",
        timestamp: new Date().toISOString(),
        user: "system",
        action: "Go-live",
        details: "Clean shop database — no demo data",
      },
    ],
    sessions,
    activeTimers,
    dayBonuses: [],
    weeklyPayouts: [],
    materialStock: [],
    materialHolds: [],
    partStock: [],
    partUnits: [],
    inventoryTxns: [],
    purchaseOrders: [],
    vendorRfqs: [],
    shopOrders: [],
    workQueue: [],
    cutTickets: [],
    stockPieces: [],
    packBoxes: [],
    quoteHistory: [],
    emailLog: [],
    poFollowups: [],
    chatMessages: [],
    shopToolingLogs: [],
    feedbackTickets: [],
    settings: {
      editPassword: DEFAULT_ADMIN_PIN,
      workDayStart: "07:00",
      workDayEnd: "16:00",
      lunchHours: 1,
      shifts: [
        {
          id: "day",
          name: "Day",
          start: "07:00",
          end: "16:00",
          lunchHours: 1,
          enabled: true,
        },
        {
          id: "night",
          name: "Night",
          start: "16:00",
          end: "01:00",
          lunchHours: 1,
          enabled: false,
        },
      ],
      bonusTiers: [
        { minEff: 1.0, percentage: 0.1 },
        { minEff: 0.9, percentage: 0.07 },
        { minEff: 0.8, percentage: 0.05 },
        { minEff: 0.7, percentage: 0.03 },
      ],
      hourlyRate: 120,
      companyName: "Lake Country Machine",
      /** Keep true until you are ready for real bonus payroll closeout */
      betaMode: true,
      quoteFromEmail: "jsteck123@gmail.com",
      shopPublicUrl: "",
      maxOperations: DEFAULT_OPERATIONS,
      customLists: { ...EMPTY_CUSTOM_LISTS, materialTypes: {} },
      averageMaxRuns: 10,
      averageShopWeight: 0.7,
      averageOutlierRatio: 1.5,
      materialPriceBook: defaultMaterialPriceBook(),
    },
    currentUserEmail: "jsteck123@gmail.com",
  };
}
