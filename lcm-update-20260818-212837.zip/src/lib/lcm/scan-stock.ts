import { materialLabelBarcode } from "./brother-label-print";
import { activeCutTickets } from "./cut-tickets";
import {
  parseSizeNumbers,
  shapeFamily,
  stockSectionDims,
} from "./stock-suggest";
import type { CutTicket, MaterialStock, StockPiece } from "./types";

export type ScanHit =
  | { kind: "piece"; piece: StockPiece }
  | { kind: "material"; material: MaterialStock };

export function resolveScanCode(
  code: string,
  pieces: StockPiece[],
  stock: MaterialStock[],
): ScanHit | null {
  const raw = (code || "").trim();
  if (!raw) return null;
  const up = raw.toUpperCase();
  const piece = (pieces || []).find(
    (p) => (p.barcode || "").toUpperCase() === up || p.id === raw,
  );
  if (piece) return { kind: "piece", piece };
  const material = (stock || []).find(
    (m) => materialLabelBarcode(m.id) === up || m.id === raw,
  );
  if (material) return { kind: "material", material };
  return null;
}

function norm(s: string) {
  return (s || "").trim().toLowerCase();
}

export function hitMaterialName(hit: ScanHit): string {
  return hit.kind === "piece" ? hit.piece.material : hit.material.material;
}

export function hitMaterialType(hit: ScanHit): string {
  return hit.kind === "piece" ? hit.piece.materialType : hit.material.materialType;
}

export function hitStockShape(hit: ScanHit): string {
  return hit.kind === "piece" ? hit.piece.stockShape : hit.material.stockShape;
}

export function hitSizeNote(hit: ScanHit): string {
  return hit.kind === "piece" ? hit.piece.sizeNote : hit.material.sizeNote;
}

export function hitSectionDims(hit: ScanHit): number[] {
  if (hit.kind === "piece") {
    const fromNote = parseSizeNumbers(hit.piece.sizeNote);
    return fromNote.length ? fromNote : [];
  }
  return stockSectionDims(hit.material);
}

function ticketSectionDims(t: CutTicket): number[] {
  if (t.process === "lathe") {
    const d = Number(t.diameter) || 0;
    return d > 0 ? [d] : [];
  }
  const skip = (t.locAxis || "").toLowerCase();
  const pairs: [string, number][] = [
    ["x", Number(t.dimX) || 0],
    ["y", Number(t.dimY) || 0],
    ["z", Number(t.dimZ) || 0],
  ];
  const section = pairs
    .filter(([axis, n]) => n > 0 && axis !== skip)
    .map(([, n]) => n);
  if (section.length) return section;
  return pairs.map(([, n]) => n).filter((n) => n > 0);
}

function familyOk(want: string, have: string): boolean {
  const a = shapeFamily(want);
  const b = shapeFamily(have);
  if (a === "other" || b === "other") return true;
  if (a === b) return true;
  if ((a === "rect" || a === "sq") && (b === "rect" || b === "sq")) return true;
  if ((a === "round" || a === "tube") && (b === "round" || b === "tube"))
    return true;
  return false;
}

/** Same alloy + compatible shape. Type ranks, does not hide. */
export function ticketMatchesHit(t: CutTicket, hit: ScanHit): boolean {
  const mat = hitMaterialName(hit);
  if (!t.material && !mat) return false;
  if (t.material && mat && norm(t.material) !== norm(mat)) return false;
  const shp = hitStockShape(hit);
  if (t.stockShape && shp && !familyOk(t.stockShape, shp)) return false;
  return true;
}

function sizeScore(t: CutTicket, hit: ScanHit): number {
  const want = ticketSectionDims(t);
  const have = hitSectionDims(hit);
  if (!want.length || !have.length) return 0;
  let score = 0;
  for (const w of want) {
    let best = 0;
    for (const h of have) {
      const d = h - w;
      if (Math.abs(d) <= 0.03) best = Math.max(best, 20);
      else if (d > 0 && d <= 0.5) best = Math.max(best, 8);
    }
    score += best;
  }
  return score;
}

export function matchingOpenCuts(
  hit: ScanHit,
  tickets: CutTicket[],
): CutTicket[] {
  const typ = hitMaterialType(hit);
  return activeCutTickets(tickets || [])
    .filter((t) => ticketMatchesHit(t, hit))
    .sort((a, b) => {
      const typeA =
        typ && a.materialType && norm(a.materialType) === norm(typ) ? 1 : 0;
      const typeB =
        typ && b.materialType && norm(b.materialType) === norm(typ) ? 1 : 0;
      if (typeA !== typeB) return typeB - typeA;
      const sa = sizeScore(a, hit);
      const sb = sizeScore(b, hit);
      if (sa !== sb) return sb - sa;
      const da = a.dueDate || "9999";
      const db = b.dueDate || "9999";
      if (da !== db) return da.localeCompare(db);
      return leftoverCut(b) - leftoverCut(a);
    });
}

export function leftoverCut(t: CutTicket): number {
  return Math.max(0, (Number(t.qtyRequested) || 0) - (Number(t.qtyCut) || 0));
}

export function hitHeadline(hit: ScanHit): string {
  return `${hitMaterialName(hit)} ${hitMaterialType(hit)}`.trim();
}

export function hitSubline(hit: ScanHit): string {
  const shape = hitStockShape(hit);
  const size = hitSizeNote(hit);
  if (hit.kind === "piece") {
    return `${shape}${size ? ` · ${size}` : ""} · ${hit.piece.remainingLength}" left`;
  }
  return `${shape}${size ? ` · ${size}` : ""} · ${hit.material.onHand} ${hit.material.unit || "in"} on hand`;
}
