import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

/** Queue a host restart. Response returns before Node is killed. */
export function scheduleShopHostRestart():
  | { ok: true }
  | { ok: false; error: string } {
  if (process.platform !== "win32") {
    return {
      ok: false,
      error: "Restart from Settings is for the Windows shop host.",
    };
  }
  const script = path.join(process.cwd(), "scripts", "host", "restart-host.cmd");
  if (!fs.existsSync(script)) {
    return { ok: false, error: "restart-host.cmd is missing on this PC." };
  }
  spawn("cmd.exe", ["/c", script], {
    detached: true,
    stdio: "ignore",
    cwd: process.cwd(),
    windowsHide: true,
  }).unref();
  return { ok: true };
}
