import { toast } from "sonner";
import { barcodeToDataUrl, boxUrlForBarcode } from "./barcode";
import { renderBoxLabelMono } from "./brother-label-print";
import { printLabelOnShopHost } from "./print-label-api";
import { loadQlPrinterIp } from "./ql-printer";
import { getShopToken, requestShopUnlock } from "./shop-sync";
import type { PackBox } from "./types";

export async function printPackBoxLabel(
  box: PackBox,
  shopPublicUrl?: string,
): Promise<{ ok: true; ip: string } | { ok: false; error: string }> {
  if (!getShopToken()) {
    requestShopUnlock();
    return { ok: false, error: "Unlock this PC first, then print again." };
  }
  const ip = loadQlPrinterIp();
  if (!ip) {
    return {
      ok: false,
      error: "Set the QL-810W Wi-Fi address on the sample label page first.",
    };
  }
  const qrDataUrl = await barcodeToDataUrl(
    boxUrlForBarcode(box.barcode, shopPublicUrl),
    280,
  );
  const mono = await renderBoxLabelMono({
    qrDataUrl,
    customer: box.customer,
    poNumber: box.poNumber,
    partNumber: box.partNumber,
    revision: box.revision,
    qty: box.qty,
  });
  const r = await printLabelOnShopHost({
    data: {
      token: getShopToken() || undefined,
      ip,
      width: mono.width,
      height: mono.height,
      pixelsB64: mono.pixelsB64,
    },
  });
  if (!r.ok) return { ok: false, error: r.error || "Print failed" };
  return { ok: true, ip: r.ip || ip };
}

export async function printPackBoxLabelOrToast(
  box: PackBox,
  shopPublicUrl?: string,
) {
  const r = await printPackBoxLabel(box, shopPublicUrl);
  if (!r.ok) {
    toast.error(r.error);
    return r;
  }
  toast.success(`Box label sent to ${r.ip}`);
  return r;
}
