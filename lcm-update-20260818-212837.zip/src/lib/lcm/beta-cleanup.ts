/**
 * Beta go-live desk.
 * Lists leftover practice data and open clocks. Never deletes a record —
 * actions close, unpack, exclude, or cancel.
 */
import type {
  CutTicket,
  DayBonusRecord,
  DowntimeEntry,
  JobRun,
  LcmState,
  OperatorTimeEntry,
  Quote,
  ShopOrder,
} from "./types";
import { shopLineOpenQty } from "./po";

export type CleanupKind =
  | "open_clock"
  | "open_downtime"
  | "loaded_session"
  | "test_job"
  | "odd_quote"
  | "packed_open"
  | "over_complete"
  | "dup_cut"
  | "started_cell"
  | "stale_bonus"
  | "settings";

export type CleanupAction =
  | { type: "close_time_log"; id: string }
  | { type: "close_downtime"; id: string }
  | { type: "clear_timer"; machine: string }
  | { type: "unload_machine"; machine: string }
  | { type: "exclude_job_average"; jobId: string }
  | { type: "clear_started"; jobId: string }
  | { type: "unpack_order"; orderId: string }
  | { type: "cap_line_qty"; orderId: string; lineId: string }
  | { type: "cancel_cut"; ticketId: string }
  | { type: "zero_stale_bonus"; recordId: string }
  | { type: "set_avg_runs"; value: number }
  | { type: "flag_quote"; quoteId: string };

export type CleanupItem = {
  id: string;
  kind: CleanupKind;
  title: string;
  detail: string;
  why: string;
  action: CleanupAction;
};

function hoursSince(iso: string, now: Date): number {
  const t = new Date(iso).getTime();
  if (!Number.isFinite(t)) return 0;
  return Math.max(0, (now.getTime() - t) / 3600000);
}

export function looksLikeTestPart(pn: string): boolean {
  const u = String(pn || "").trim().toUpperCase();
  // Sat-Lite ships real P/Ns like TEST-0143-01. Only the practice names.
  return (
    u === "TEST" ||
    u.startsWith("TEST ") ||
    u.startsWith("TEST-0293") ||
    u.startsWith("TET-0293")
  );
}

export function looksLikeOddQuote(q: Quote): boolean {
  const pn = String(q.partNumber || "").trim();
  if (!pn) return true;
  if (looksLikeTestPart(pn)) return true;
  if (pn.length <= 1) return true;
  const cust = String(q.customer || "").trim();
  // Botched import: PN "3" rev "4" customer "2"
  if (pn === "3" && (cust === "2" || !cust)) return true;
  return false;
}

export function scanBetaCleanup(
  state: Pick<
    LcmState,
    | "operatorTimeLog"
    | "downtimes"
    | "activeTimers"
    | "sessions"
    | "jobs"
    | "quotes"
    | "shopOrders"
    | "cutTickets"
    | "dayBonuses"
    | "settings"
  >,
  now = new Date(),
): CleanupItem[] {
  const items: CleanupItem[] = [];

  for (const row of state.operatorTimeLog || []) {
    if (row.endTime) continue;
    const hrs = hoursSince(row.startTime, now);
    items.push({
      id: `log:${row.id}`,
      kind: "open_clock",
      title: `Open ${row.type} on ${row.machine} — ${row.operator || "?"} · ${row.operation}`,
      detail: `Started ${row.startTime} · ~${hrs.toFixed(1)} hours still running`,
      why: "An unfinished time-log row is ignored until someone stops it, then the whole span dumps into that day. Apply here closes it with 0 hours (as if it never ran). The row stays for history.",
      action: { type: "close_time_log", id: row.id },
    });
  }

  for (const [machine, timer] of Object.entries(state.activeTimers || {})) {
    if (!timer) continue;
    const hrs = hoursSince(timer.startIso, now);
    items.push({
      id: `timer:${machine}`,
      kind: "open_clock",
      title: `Live timer on ${machine} (${timer.type} ${timer.operation})`,
      detail: `Started ${timer.startIso} · ~${hrs.toFixed(1)} hours`,
      why: "A live timer keeps adding seconds. If nobody is at that machine, stop it so tonight’s shift is not charged.",
      action: { type: "clear_timer", machine },
    });
  }

  for (const d of state.downtimes || []) {
    if (d.endTime) continue;
    const hrs = hoursSince(d.startTime, now);
    items.push({
      id: `down:${d.id}`,
      kind: "open_downtime",
      title: `Open pause: ${d.reason} on ${d.machine} — ${d.operator || "?"}`,
      detail: `Started ${d.startTime} · ~${hrs.toFixed(1)} hours`,
      why: "Open pause hours count toward “on shift” once closed. Apply here closes it at the start time (0 hours) so a leftover lunch does not become a 20-hour day.",
      action: { type: "close_downtime", id: d.id },
    });
  }

  for (const [machine, sess] of Object.entries(state.sessions || {})) {
    if (!sess?.jobId) continue;
    const job = (state.jobs || []).find((j) => j.id === sess.jobId);
    const test = looksLikeTestPart(sess.partNumber || job?.partNumber || "");
    if (!test && job?.status === "In Progress") continue;
    items.push({
      id: `sess:${machine}`,
      kind: "loaded_session",
      title: `${machine} still loaded with ${sess.partNumber || job?.partNumber || "a job"}${test ? " (TEST)" : ""}`,
      detail: `${sess.operatorName || "No operator"} · qty ${sess.quantity || 0} · job ${job?.status || "missing"}`,
      why: test
        ? "Practice jobs should come off the machine before the floor treats VF4 / VF2 as real work."
        : "A completed or missing job is still sitting on the machine screen.",
      action: { type: "unload_machine", machine },
    });
  }

  for (const j of state.jobs || []) {
    if (looksLikeTestPart(j.partNumber) && j.countInAverage !== false) {
      items.push({
        id: `testjob:${j.id}`,
        kind: "test_job",
        title: `TEST job ${j.partNumber} still counts toward averages`,
        detail: `${j.operator || "?"} · ${j.status} · ${j.actualTime || 0}s actual · eff ${(j.efficiency || 0).toFixed(1)}`,
        why: "With average-max-runs at 1, one TEST complete can write 50% of those click-times into a real part’s recipe. This only unchecks “count in average” — the job stays in history.",
        action: { type: "exclude_job_average", jobId: j.id },
      });
    }
    const cells = [...(j.setups || []), ...(j.runtimes || [])];
    if (cells.includes("STARTED")) {
      items.push({
        id: `started:${j.id}`,
        kind: "started_cell",
        title: `${j.partNumber} has a STARTED timer cell`,
        detail: `${j.status} · setups/runtimes still say STARTED`,
        why: "A finished job should not still say STARTED. We turn that cell into 0 seconds so averages and reopen do not choke. History stays.",
        action: { type: "clear_started", jobId: j.id },
      });
    }
  }

  for (const q of state.quotes || []) {
    if (!looksLikeOddQuote(q)) continue;
    items.push({
      id: `quote:${q.id}`,
      kind: "odd_quote",
      title: `Odd quote ${q.partNumber || "(blank)"} rev ${q.revision || "—"} · ${q.customer || "no customer"}`,
      detail: "Will be tagged in notes as beta leftover. Not deleted.",
      why: "Short / TEST / mistyped P/Ns (like “3” rev “4” customer “2”) steal material lookups when a search used to prefix-match. Tag them so the office can hide or ignore them. Nothing is removed.",
      action: { type: "flag_quote", quoteId: q.id },
    });
  }

  for (const o of state.shopOrders || []) {
    if (o.packStatus !== "packed" && o.packStatus !== "verified") continue;
    const open = (o.lines || []).filter(
      (l) =>
        l.lineStatus !== "cancelled" &&
        shopLineOpenQty(l) > 0 &&
        !l.readyForPack &&
        !l.linePacked,
    );
    if (!open.length) continue;
    items.push({
      id: `pack:${o.id}`,
      kind: "packed_open",
      title: `${o.poNumber} is ${o.packStatus} with unfinished lines`,
      detail: open.map((l) => `${l.partNumber} ${l.qtyCompleted || 0}/${l.qty}`).join(" · "),
      why: "Packing should mean the cart is ready. This sets pack back to pending so shipping and the board agree. Lines and qty are untouched.",
      action: { type: "unpack_order", orderId: o.id },
    });
  }

  for (const o of state.shopOrders || []) {
    for (const l of o.lines || []) {
      if ((l.qtyCompleted || 0) > (l.qty || 0)) {
        items.push({
          id: `over:${o.id}:${l.id}`,
          kind: "over_complete",
          title: `${o.poNumber} ${l.partNumber} completed ${l.qtyCompleted} of ${l.qty}`,
          detail: "Caps completed at the ordered qty. Extras stay on part-stock / UIN if you already tagged them.",
          why: "Open-qty math floors at zero, so extras vanish from the buy list and the line looks done twice. Cap the line; keep extras on the shelf as seconds.",
          action: { type: "cap_line_qty", orderId: o.id, lineId: l.id },
        });
      }
    }
  }

  const cutGroups = new Map<string, CutTicket[]>();
  for (const t of state.cutTickets || []) {
    if (t.status === "cancelled") continue;
    const key = `${t.shopOrderId || ""}|${t.shopOrderLineId || ""}|${t.componentId || ""}|${(t.partNumber || "").toUpperCase()}`;
    const list = cutGroups.get(key) || [];
    list.push(t);
    cutGroups.set(key, list);
  }
  for (const [, list] of cutGroups) {
    if (list.length < 2) continue;
    const keep = [...list].sort((a, b) =>
      String(b.requestedAt || "").localeCompare(String(a.requestedAt || "")),
    )[0];
    for (const t of list) {
      if (t.id === keep.id) continue;
      items.push({
        id: `cut:${t.id}`,
        kind: "dup_cut",
        title: `Duplicate cut ticket ${t.partNumber} (${t.status} ${t.qtyCut}/${t.qtyRequested})`,
        detail: `Keeping ${keep.id.slice(0, 8)}… · this one will be marked cancelled`,
        why: "Two tickets for the same line let the saw claim the same blanks twice. Cancel the extra. The keeper stays.",
        action: { type: "cancel_cut", ticketId: t.id },
      });
    }
  }

  for (const b of state.dayBonuses || []) {
    if ((b.workedHours || 0) <= 0 && (b.efficiency || 0) > 0) {
      items.push({
        id: `bonus:${b.id}`,
        kind: "stale_bonus",
        title: `${b.operatorName} ${b.dateKey} shows ${(b.efficiency * 100).toFixed(0)}% with 0h worked`,
        detail: b.eligibilityReason || "stale efficiency",
        why: "The $ amount is already 0. This just clears the leftover percentage so payroll review is not looking at 3,000% days.",
        action: { type: "zero_stale_bonus", recordId: b.id },
      });
    }
  }

  const avgMax = state.settings?.averageMaxRuns ?? 10;
  if (avgMax <= 2) {
    items.push({
      id: "settings:avg-runs",
      kind: "settings",
      title: `Shop average uses only ${avgMax} completed run${avgMax === 1 ? "" : "s"}`,
      detail: "Recommended: 8–10 runs before the recipe moves.",
      why: "One complete (especially a TEST click) currently rewrites half the quote times. This only changes the setting — no jobs or quotes are touched.",
      action: { type: "set_avg_runs", value: 10 },
    });
  }

  return items;
}

export function cleanupKindLabel(kind: CleanupKind): string {
  switch (kind) {
    case "open_clock":
      return "Open clocks";
    case "open_downtime":
      return "Open pauses";
    case "loaded_session":
      return "Machines still loaded";
    case "test_job":
      return "TEST jobs in averages";
    case "odd_quote":
      return "Odd / practice quotes";
    case "packed_open":
      return "Packed but not finished";
    case "over_complete":
      return "Qty completed over ordered";
    case "dup_cut":
      return "Duplicate saw tickets";
    case "started_cell":
      return "STARTED leftover cells";
    case "stale_bonus":
      return "Stale bonus %";
    case "settings":
      return "Settings to reset";
    default:
      return kind;
  }
}

export type { OperatorTimeEntry, DowntimeEntry, JobRun, ShopOrder, DayBonusRecord };
