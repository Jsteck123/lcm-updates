import type { BomLine, Quote } from "./types";

/** Shop convention: -01 = assembly, -02/-03… = unique sub-pieces */
const SUFFIX_RE = /-(\d{2})$/;

export function partBase(partNumber: string): string {
  const pn = (partNumber || "").trim().toUpperCase();
  const m = pn.match(SUFFIX_RE);
  if (!m) return pn;
  return pn.slice(0, -m[0].length);
}

export function partSuffix(partNumber: string): number | null {
  const m = (partNumber || "").trim().toUpperCase().match(SUFFIX_RE);
  return m ? Number(m[1]) : null;
}

export function withPartSuffix(base: string, suffix: number): string {
  const b = partBase(base) || base.trim().toUpperCase();
  const n = Math.max(1, Math.round(suffix));
  return `${b}-${String(n).padStart(2, "0")}`;
}

export function looksLikeAssemblyPn(partNumber: string): boolean {
  return partSuffix(partNumber) === 1;
}

/** Suggest -02, -03 (and optional more) under a parent assembly PN. */
export function suggestChildPartNumbers(
  assemblyPn: string,
  count = 2,
): string[] {
  const base = partBase(assemblyPn);
  if (!base) return [];
  const out: string[] = [];
  for (let i = 2; i < 2 + count; i++) {
    out.push(withPartSuffix(base, i));
  }
  return out;
}

export function emptyBomLine(partial?: Partial<BomLine>): BomLine {
  return {
    partNumber: "",
    revision: "A",
    qty: 1,
    note: "",
    ...partial,
  };
}

/**
 * Best unit cost for a child quote:
 * first non-zero price break, else rough setup+run material base.
 */
export function childUnitCost(child: Quote | undefined, qty = 0): number {
  if (!child) return 0;
  // Prefer the price break that matches the assembly qty when we have one.
  if (qty > 0 && child.quantities?.length && child.prices?.length) {
    let best = 0;
    let bestDist = Infinity;
    for (let i = 0; i < child.quantities.length; i++) {
      const q = Number(child.quantities[i]) || 0;
      const price = Number(child.prices[i]) || 0;
      if (q <= 0 || price <= 0) continue;
      const dist = Math.abs(q - qty);
      if (dist < bestDist) {
        bestDist = dist;
        best = price;
      }
    }
    if (best > 0) return best;
  }
  const priced = (child.prices || []).find((p) => p > 0);
  if (priced && priced > 0) return priced;
  // Fallback: very rough from times (same $2/min convention as quoter)
  const setup = (child.setupTimes || []).reduce((a, b) => a + (b || 0), 0);
  const run = (child.runTimes || []).reduce((a, b) => a + (b || 0), 0);
  const mat =
    child.rawMaterialLength > 0
      ? (child.rawMaterialCost / child.rawMaterialLength) *
        (child.partLengthEach || 0) *
        (child.materialPct || 1)
      : 0;
  return setup * 2 + run * 2 * (child.machineRate || 1) + mat;
}

export function bomRollup(
  bom: BomLine[] | undefined,
  quotes: Quote[],
  parentPartNumber?: string,
): {
  lines: {
    partNumber: string;
    qty: number;
    unitCost: number;
    extCost: number;
    found: boolean;
    revision: string;
  }[];
  total: number;
} {
  const parent = String(parentPartNumber || "").trim().toUpperCase();
  const lines = (bom || []).map((row) => {
    const pn = row.partNumber.trim().toUpperCase();
    if (parent && pn === parent) {
      return {
        partNumber: pn,
        qty: row.qty > 0 ? row.qty : 0,
        unitCost: 0,
        extCost: 0,
        found: false,
        revision: row.revision || "A",
      };
    }
    const wantRev = String(row.revision || "").trim().toUpperCase();
    const samePn = quotes.filter(
      (q) => q.partNumber.toLowerCase() === pn.toLowerCase(),
    );
    const child =
      (wantRev
        ? samePn.find((q) => String(q.revision || "").toUpperCase() === wantRev)
        : undefined) ||
      [...samePn].sort((a, b) =>
        String(b.date || "").localeCompare(String(a.date || "")),
      )[0];
    const qty = row.qty > 0 ? row.qty : 0;
    const childPn = String(child?.partNumber || "").trim().toUpperCase();
    const childEatsSelf = Boolean(
      child &&
        childPn === pn &&
        (child.bom || []).some(
          (b) => String(b.partNumber || "").trim().toUpperCase() === pn,
        ),
    );
    const unitCost = childEatsSelf ? 0 : childUnitCost(child, qty);
    return {
      partNumber: pn || row.partNumber,
      qty,
      unitCost,
      extCost: unitCost * qty,
      found: !!child && !childEatsSelf,
      revision: row.revision || child?.revision || "A",
    };
  });
  const total = lines.reduce((s, l) => s + l.extCost, 0);
  return { lines, total };
}
