export type ChangelogEntry = {
  version: string;
  note: string;
  appliedAt: string;
  fileName?: string;
};

const SEEN_KEY = "lcm-whats-new-seen";

export function lastSeenWhatsNew(): string {
  if (typeof window === "undefined") return "";
  try {
    return localStorage.getItem(SEEN_KEY) || "";
  } catch {
    return "";
  }
}

export function markWhatsNewSeen(version: string): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(SEEN_KEY, version || "");
  } catch {
    /* ignore */
  }
}

export function shouldShowWhatsNew(
  version: string | null | undefined,
): boolean {
  const v = (version || "").trim();
  if (!v) return false;
  return lastSeenWhatsNew() !== v;
}
