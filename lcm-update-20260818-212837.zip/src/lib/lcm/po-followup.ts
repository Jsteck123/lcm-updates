/**
 * Customer follow-up after PO import: missing drawings, CAD, rev mismatches.
 */
import type {
  Customer,
  PoFollowupIssue,
  PoFollowupIssueKind,
  PoFollowupReport,
  Quote,
  ShopOrder,
  ShopOrderLine,
} from "./types";
import { lineCadFiles, lineDrawings, normalizeComponents } from "./line-files";
import { customerEmailList } from "./quote-email";

const KIND_LABEL: Record<PoFollowupIssueKind, string> = {
  missing_drawing: "Missing drawing",
  missing_cad: "Missing CAD",
  unmatched_file: "File not matched to a line",
  not_in_quote_book: "Not in our quote book",
  revision_mismatch: "Revision mismatch",
  missing_part_number: "Missing part number",
  missing_qty: "Missing / zero qty",
  missing_due_date: "No date required",
  parse_warning: "Import note",
};

export function followupKindLabel(kind: PoFollowupIssueKind) {
  return KIND_LABEL[kind] || kind;
}

function hasDrawing(line: ShopOrderLine) {
  return lineDrawings(line).length > 0 || Boolean(line.drawingId);
}

function hasCad(line: ShopOrderLine) {
  return lineCadFiles(line).length > 0 || Boolean(line.cadFileId);
}

function findQuote(quotes: Quote[], partNumber: string, rev: string) {
  const pn = (partNumber || "").trim().toUpperCase();
  if (!pn) return null;
  const list = quotes || [];
  const samePn = list.filter(
    (q) => (q.partNumber || "").trim().toUpperCase() === pn,
  );
  if (!samePn.length) return { quote: null as Quote | null, anyPn: false };
  const r = (rev || "").trim().toUpperCase();
  const exact = r
    ? samePn.find((q) => (q.revision || "").trim().toUpperCase() === r)
    : samePn[0];
  return { quote: exact || samePn[0]!, anyPn: true };
}

export function buildPoFollowupIssues(opts: {
  order: ShopOrder;
  quotes: Quote[];
  unmatched?: { name: string; kind: string }[];
  parseWarnings?: string[];
}): PoFollowupIssue[] {
  const issues: PoFollowupIssue[] = [];
  const order = opts.order;
  const quotes = opts.quotes || [];

  if (!(order.dueDate || order.dateRequired || "").trim()) {
    issues.push({
      partNumber: "",
      itemNo: 0,
      kind: "missing_due_date",
      detail: "PO has no date required / due date",
    });
  }

  for (const line of order.lines || []) {
    if (line.lineStatus === "cancelled") continue;
    const pn = (line.partNumber || "").trim();
    const itemNo = line.itemNo || 0;
    if (!pn) {
      issues.push({
        partNumber: "",
        itemNo,
        kind: "missing_part_number",
        detail: `Line ${itemNo || "?"} has no part number`,
      });
      continue;
    }
    if (!(Number(line.qty) > 0)) {
      issues.push({
        partNumber: pn,
        itemNo,
        kind: "missing_qty",
        detail: `${pn} qty is missing or zero`,
      });
    }

    const comps = normalizeComponents(line);
    if (comps.length) {
      for (const c of comps) {
        const cpn = (c.partNumber || pn).trim();
        const draws = (c.drawings || []).length;
        const cads = (c.cadFiles || []).length;
        if (!draws) {
          issues.push({
            partNumber: cpn,
            itemNo,
            kind: "missing_drawing",
            detail: `${cpn} has no shop drawing (PDF/print)`,
          });
        }
        if (!cads) {
          issues.push({
            partNumber: cpn,
            itemNo,
            kind: "missing_cad",
            detail: `${cpn} has no CAD / solid file`,
          });
        }
        const hit = findQuote(quotes, cpn, c.revision || line.revision);
        if (!hit?.anyPn) {
          issues.push({
            partNumber: cpn,
            itemNo,
            kind: "not_in_quote_book",
            detail: `${cpn} is not in our quote book`,
          });
        } else if (
          (c.revision || line.revision) &&
          hit.quote &&
          (hit.quote.revision || "").toUpperCase() !==
            (c.revision || line.revision).toUpperCase()
        ) {
          issues.push({
            partNumber: cpn,
            itemNo,
            kind: "revision_mismatch",
            detail: `${cpn} PO rev ${(c.revision || line.revision).toUpperCase()} · quote book rev ${(hit.quote.revision || "—").toUpperCase()}`,
          });
        }
      }
      if (!hasDrawing(line)) {
        issues.push({
          partNumber: pn,
          itemNo,
          kind: "missing_drawing",
          detail: `Assembly ${pn} has no top-level drawing`,
        });
      }
    } else {
      if (!hasDrawing(line)) {
        issues.push({
          partNumber: pn,
          itemNo,
          kind: "missing_drawing",
          detail: `${pn} has no shop drawing (PDF/print)`,
        });
      }
      if (!hasCad(line)) {
        issues.push({
          partNumber: pn,
          itemNo,
          kind: "missing_cad",
          detail: `${pn} has no CAD / solid file`,
        });
      }
      const hit = findQuote(quotes, pn, line.revision);
      if (!hit?.anyPn) {
        issues.push({
          partNumber: pn,
          itemNo,
          kind: "not_in_quote_book",
          detail: `${pn} is not in our quote book`,
        });
      } else if (
        line.revision &&
        hit.quote &&
        (hit.quote.revision || "").toUpperCase() !==
          line.revision.toUpperCase()
      ) {
        issues.push({
          partNumber: pn,
          itemNo,
          kind: "revision_mismatch",
          detail: `${pn} PO rev ${line.revision.toUpperCase()} · quote book rev ${(hit.quote.revision || "—").toUpperCase()}`,
        });
      }
    }
  }

  for (const u of opts.unmatched || []) {
    issues.push({
      partNumber: "",
      itemNo: 0,
      kind: "unmatched_file",
      detail: `${u.kind === "cad" ? "CAD" : "File"} “${u.name}” was in the package but did not match a PO line`,
    });
  }

  for (const w of opts.parseWarnings || []) {
    const t = (w || "").trim();
    if (!t) continue;
    issues.push({
      partNumber: "",
      itemNo: 0,
      kind: "parse_warning",
      detail: t,
    });
  }

  return issues;
}

export function poFollowupSubject(report: PoFollowupReport) {
  return `PO ${report.poNumber || "—"} — drawings / files needed`;
}

export function poFollowupPlainText(report: PoFollowupReport, company: string) {
  const lines = [
    `Hello${report.customer ? ` ${report.customer}` : ""},`,
    "",
    `We received PO ${report.poNumber || "—"} and need the following to release work:`,
    "",
  ];
  for (const i of report.issues) {
    const who = i.partNumber
      ? `${i.partNumber}${i.itemNo ? ` (item ${i.itemNo})` : ""}`
      : i.itemNo
        ? `Item ${i.itemNo}`
        : "PO";
    lines.push(`• ${who} — ${followupKindLabel(i.kind)}: ${i.detail}`);
  }
  if (report.notes.trim()) {
    lines.push("", report.notes.trim());
  }
  lines.push(
    "",
    "Please send these at your earliest convenience.",
    "",
    "Thank you,",
    company || "Lake Country Machine",
  );
  return lines.join("\n");
}

export function customerToEmail(customers: Customer[], name: string) {
  const n = (name || "").trim().toLowerCase();
  const c = (customers || []).find((x) => x.name.trim().toLowerCase() === n);
  return customerEmailList(c)[0] || "";
}
