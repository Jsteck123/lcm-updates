import type {
  ActiveTimer,
  DayBonusRecord,
  JobRun,
  MachineSession,
  Operator,
  WeeklyPayout,
  AppSettings,
} from "./types";
import { currentShiftContext, dateAtHhmm, overlapHours, type DayBonusCalc } from "./day-bonus";
import { opIndex } from "./ops";
import type { ShopStatus } from "./status-colors";
import { formatClock, formatDurationShort } from "@/lib/utils";

/** Bonus $ we would show if this pace held through a full shift (even if not locked yet). */
export function paceBonus(calc: DayBonusCalc | null | undefined): number {
  if (!calc || calc.workedHours <= 0) return 0;
  if (calc.tierPct <= 0) return 0;
  return Math.max(0, calc.pool * calc.tierPct);
}

export type PulseTone = "quiet" | "building" | "pace" | "locked";

export type PersonPulse = {
  name: string;
  efficiency: number;
  onShiftHours: number;
  requiredHours: number;
  shiftFill: number;
  eligible: boolean;
  pace: number;
  showMoney: boolean;
  tone: PulseTone;
  line: string;
  hint: string;
};

export type ShopPulse = {
  dateKey: string;
  weekKey: string;
  shiftName: string;
  peopleClocked: number;
  peopleOnPace: number;
  avgEfficiency: number;
  avgShiftFill: number;
  todayPace: number;
  avgBonus: number;
  weekTotal: number;
  line: string;
  hint: string;
};

export type JobPulseView = {
  partNumber: string;
  done: number;
  qty: number;
  fill: number;
  live: boolean;
  pair?: { partNumber: string; done: number; qty: number; fill: number };
  showTime: boolean;
  timeFill: number;
  timeLine: string;
  timeTone: "accent" | "warn" | "danger";
  remainLine: string;
  etaLine: string;
  countTone: ShopStatus;
  countHint: string;
  countAgeSec: number;
};

/** Hide pace when they are under 60% of sold — don't rub it in. */
export const PACE_HIDE_BELOW = 0.6;

/** One sold cycle without a tap → count is overdue (probably wrong). */
export const COUNT_SOON_RATIO = 0.85;
export const COUNT_OVERDUE_RATIO = 1;
/** When the op has no quoted cycle, nag on a 5-minute beat. */
export const COUNT_CYCLE_FALLBACK_SEC = 5 * 60;
/** They can run about 2× sold and still catch up. Not type 50 at the start. */
export const COUNT_SPEED_BUFFER = 2;
export const COUNT_AHEAD_SLACK = 1;
/** Unquoted ops: short assumed cycle so they can tap, not dump a pile. */
export const COUNT_CAP_FALLBACK_SEC = 20;

/** Don't flash $0 or "no bonus" in a guy's face. */
export function shouldShowPersonalMoney(calc: DayBonusCalc | null): boolean {
  if (!calc) return false;
  if (calc.tierPct <= 0) return false;
  const fill =
    calc.requiredShiftHours > 0
      ? calc.onShiftHours / calc.requiredShiftHours
      : 0;
  if (calc.eligible) return true;
  return calc.efficiency >= 0.85 && fill >= 0.2;
}

export function personPulse(
  name: string,
  calc: DayBonusCalc | null,
): PersonPulse {
  const eff = calc?.efficiency || 0;
  const on = calc?.onShiftHours || 0;
  const req = calc?.requiredShiftHours || 8;
  const fill = req > 0 ? Math.min(1, on / req) : 0;
  const pace = paceBonus(calc);
  const showMoney = shouldShowPersonalMoney(calc);

  let tone: PulseTone = "quiet";
  let line = "Start a timer — the day fills as you run.";
  let hint = "Your name on the machine, then Start.";

  if (!calc || on <= 0.02) {
    tone = "quiet";
  } else if (calc.eligible) {
    tone = "locked";
    line = "Day bonus is in play.";
    hint = "Full shift is in. Keep the clock honest through the end.";
  } else if (eff >= 0.85) {
    tone = "pace";
    line = "On pace.";
    hint = "Bonus locks after a full shift in the window.";
  } else if (fill >= 0.15) {
    tone = "building";
    line = "Day is building.";
    hint = "Stay on the work. The bar is the shift, not a grade.";
  } else {
    tone = "building";
    line = "Clock is on.";
    hint = "Keep running — this fills as the shift goes.";
  }

  return {
    name,
    efficiency: eff,
    onShiftHours: on,
    requiredHours: req,
    shiftFill: fill,
    eligible: Boolean(calc?.eligible),
    pace,
    showMoney,
    tone,
    line,
    hint,
  };
}

export function shopPulse(opts: {
  dateKey: string;
  weekKey: string;
  shiftName: string;
  live: DayBonusCalc[];
  weeklyPayouts: WeeklyPayout[];
  dayBonuses: DayBonusRecord[];
}): ShopPulse {
  const clocked = opts.live.filter((c) => c.onShiftHours > 0.05);
  const worked = clocked.filter((c) => c.workedHours > 0);
  const onPace = clocked.filter((c) => c.tierPct > 0 && c.efficiency >= 0.85);

  let earned = 0;
  let hours = 0;
  let fillSum = 0;
  let todayPace = 0;
  for (const c of clocked) {
    const req = c.requiredShiftHours || 8;
    fillSum += req > 0 ? Math.min(1, c.onShiftHours / req) : 0;
    todayPace += paceBonus(c);
  }
  for (const c of worked) {
    earned += c.efficiency * c.workedHours;
    hours += c.workedHours;
  }
  const avgEfficiency = hours > 0 ? earned / hours : 0;
  const avgShiftFill = clocked.length ? fillSum / clocked.length : 0;

  const weekLocked = (opts.weeklyPayouts || [])
    .filter((w) => w.weekKey === opts.weekKey)
    .reduce((s, w) => s + (w.totalBonus || 0), 0);

  const finalizedToday = new Set(
    (opts.dayBonuses || [])
      .filter(
        (d) =>
          d.dateKey === opts.dateKey &&
          d.status === "finalized" &&
          d.weekKey === opts.weekKey,
      )
      .map((d) => d.operatorName.trim().toLowerCase()),
  );
  const liveNotLocked = clocked
    .filter((c) => !finalizedToday.has(c.operatorName.trim().toLowerCase()))
    .reduce((s, c) => s + paceBonus(c), 0);

  const weekTotal = weekLocked + liveNotLocked;

  let line = "Shop is quiet — first clock starts the board.";
  let hint = `${opts.shiftName} shift`;
  if (clocked.length === 0) {
    line = "Shop is quiet — first clock starts the board.";
  } else if (avgEfficiency >= 1) {
    line = "Shop is running ahead of quote.";
    hint = `${clocked.length} on the clock · ${opts.shiftName}`;
  } else if (
    avgEfficiency >= 0.85 ||
    onPace.length >= Math.ceil(clocked.length / 2)
  ) {
    line = "Shop is on a bonus pace.";
    hint = `${onPace.length} of ${clocked.length} looking solid · ${opts.shiftName}`;
  } else {
    line = "Shop is moving.";
    hint = `${clocked.length} on the clock · ${opts.shiftName}`;
  }

  return {
    dateKey: opts.dateKey,
    weekKey: opts.weekKey,
    shiftName: opts.shiftName,
    peopleClocked: clocked.length,
    peopleOnPace: onPace.length,
    avgEfficiency,
    avgShiftFill,
    todayPace,
    avgBonus: clocked.length ? todayPace / clocked.length : 0,
    weekTotal,
    line,
    hint,
  };
}

/** Pieces first. Pace bar can go a little red; disappears under 60% of sold. */
export function jobPulseFromRun(opts: {
  partNumber: string;
  qty: number;
  done: number;
  pairPartNumber?: string;
  pairQty?: number;
  pairDone?: number;
  quotedSeconds?: number;
  actualSeconds?: number;
  remainLine?: string;
  etaLine?: string;
  live?: boolean;
  countTone?: ShopStatus;
  countHint?: string;
  countAgeSec?: number;
}): JobPulseView {
  const qty = Math.max(0, Number(opts.qty) || 0);
  const done = Math.max(0, Number(opts.done) || 0);
  const fill = qty > 0 ? Math.min(1, done / qty) : 0;
  let pair: JobPulseView["pair"];
  if (opts.pairPartNumber) {
    const pq = Math.max(0, Number(opts.pairQty) || 0);
    const pd = Math.max(0, Number(opts.pairDone) || 0);
    pair = {
      partNumber: opts.pairPartNumber,
      qty: pq,
      done: pd,
      fill: pq > 0 ? Math.min(1, pd / pq) : 0,
    };
  }

  const quoted = Math.max(0, Number(opts.quotedSeconds) || 0);
  const actual = Math.max(0, Number(opts.actualSeconds) || 0);
  const efficiency = quoted > 0 && actual > 0 ? quoted / actual : 0;
  const showTime = efficiency >= PACE_HIDE_BELOW;
  let timeLine = "";
  let timeTone: JobPulseView["timeTone"] = "accent";
  if (showTime) {
    if (efficiency >= 1.08) {
      timeLine = "Ahead of quoted";
      timeTone = "accent";
    } else if (efficiency >= 0.92) {
      timeLine = "On quoted time";
      timeTone = "accent";
    } else {
      timeLine = "A little behind quoted";
      timeTone = efficiency >= 0.75 ? "warn" : "danger";
    }
  }

  return {
    partNumber: opts.partNumber || "Job",
    done,
    qty,
    fill,
    live: Boolean(opts.live),
    pair,
    showTime,
    timeFill: showTime ? Math.min(1, efficiency) : 0,
    timeLine,
    timeTone,
    remainLine: opts.remainLine || "",
    etaLine: opts.etaLine || "",
    countTone: opts.countTone || "neutral",
    countHint: opts.countHint || "",
    countAgeSec: Math.max(0, Number(opts.countAgeSec) || 0),
  };
}

export function quotedSecondsForJob(job: JobRun | undefined, qty: number): number {
  if (!job) return 0;
  const n = Math.max(
    job.quotedSetups?.length || 0,
    job.quotedRuntimes?.length || 0,
  );
  const q = Math.max(1, qty || job.quantityCompleted || job.quantity || 1);
  let s = 0;
  for (let i = 0; i < n; i++) {
    s += job.quotedSetups?.[i] || 0;
    s += (job.quotedRuntimes?.[i] || 0) * q;
  }
  return s;
}

export function quotedSecondsForSession(session: MachineSession | undefined): number {
  if (!session) return 0;
  const n = Math.max(
    session.quotedSetups?.length || 0,
    session.quotedRuntimes?.length || 0,
  );
  const q = Math.max(1, session.quantity || 1);
  let s = 0;
  for (let i = 0; i < n; i++) {
    s += session.quotedSetups?.[i] || 0;
    s += (session.quotedRuntimes?.[i] || 0) * q;
  }
  return s;
}

export function actualSecondsForSession(
  session: MachineSession | undefined,
  liveSeconds?: number | null,
): number {
  if (!session) return 0;
  let s = 0;
  for (const v of [...(session.setups || []), ...(session.runtimes || [])]) {
    if (typeof v === "number" && v > 0) s += v;
  }
  if (liveSeconds && liveSeconds > 0) s += liveSeconds;
  return s;
}

/** Current runtime slot if the clock is on (or paused mid-runtime). */
export function liveRuntimeIndex(session: MachineSession | undefined): number | null {
  if (!session) return null;
  const started = (session.runtimes || []).findIndex((v) => v === "STARTED");
  if (started >= 0) return started;
  if (session.pausedTimer?.type === "Runtime") {
    return opIndex(session.pausedTimer.operation);
  }
  return null;
}

/** Good pieces tapped on this runtime — not locked until Stop. */
export function liveRuntimePieces(session: MachineSession | undefined): number {
  if (liveRuntimeIndex(session) == null) return 0;
  return Math.max(0, Math.floor(Number(session?.runtimeLivePieces) || 0));
}

/** Clock seconds that still tick while they run and freeze on pause. */
export function effectiveRuntimeSeconds(
  session: MachineSession | undefined,
  liveSeconds?: number | null,
): number {
  if (liveSeconds != null && liveSeconds > 0) return liveSeconds;
  if (session?.pausedTimer?.type === "Runtime") {
    return Math.max(0, session.pausedTimer.accumulatedSeconds || 0);
  }
  return Math.max(0, Number(liveSeconds) || 0);
}

export function soldCycleSeconds(session: MachineSession | undefined): number {
  if (!session) return COUNT_CYCLE_FALLBACK_SEC;
  const per = quotedRunPerPiece(session);
  return per > 0 ? per : COUNT_CYCLE_FALLBACK_SEC;
}

export type CountFreshness = {
  tone: ShopStatus;
  hint: string;
  ageSec: number;
  cycleSec: number;
};

/**
 * Last tap is a refresh. Past one sold cycle without a tap, the count
 * is overdue — floor and office should not trust it.
 */
export function countFreshness(
  session: MachineSession | undefined,
  liveSeconds?: number | null,
): CountFreshness {
  const livePcs = liveRuntimePieces(session);
  const done = (session?.quantityCompleted || 0) + livePcs;
  const qty = session?.quantity || 0;
  if (qty > 0 && done >= qty) {
    return { tone: "done", hint: "", ageSec: 0, cycleSec: 0 };
  }
  if (liveRuntimeIndex(session) == null) {
    return { tone: "neutral", hint: "", ageSec: 0, cycleSec: 0 };
  }
  const clock = effectiveRuntimeSeconds(session, liveSeconds);
  const stamped = session?.runtimeLivePiecesAtSeconds;
  const last =
    typeof stamped === "number" && Number.isFinite(stamped) ? stamped : 0;
  const age = Math.max(0, clock - last);
  const cycle = soldCycleSeconds(session);
  const ratio = cycle > 0 ? age / cycle : 0;
  if (ratio >= COUNT_OVERDUE_RATIO) {
    return {
      tone: "overdue",
      hint: "Tap Good so far",
      ageSec: age,
      cycleSec: cycle,
    };
  }
  if (ratio >= COUNT_SOON_RATIO) {
    return {
      tone: "soon",
      hint: "Time to tap",
      ageSec: age,
      cycleSec: cycle,
    };
  }
  return {
    tone: livePcs > 0 ? "active" : "open",
    hint: "",
    ageSec: age,
    cycleSec: cycle,
  };
}

/**
 * Most pieces this clock could honestly have. 2× sold + one slack
 * so they can catch up a missed tap, never dump a pile ahead.
 */
export function maxLivePieces(
  session: MachineSession | undefined,
  liveSeconds?: number | null,
): number {
  if (!session || liveRuntimeIndex(session) == null) return 0;
  const already = Math.max(0, Math.floor(Number(session.quantityCompleted) || 0));
  const qty = Math.max(0, Math.floor(Number(session.quantity) || 0));
  const remain = qty > 0 ? Math.max(0, qty - already) : 999;
  if (remain <= 0) return 0;
  const clock = effectiveRuntimeSeconds(session, liveSeconds);
  const quoted = quotedRunPerPiece(session);
  const cycle = quoted > 0 ? quoted : COUNT_CAP_FALLBACK_SEC;
  const fromClock =
    Math.floor((Math.max(0, clock) / cycle) * COUNT_SPEED_BUFFER) +
    COUNT_AHEAD_SLACK;
  return Math.min(remain, Math.max(1, fromClock), 999);
}

export function clampLivePieces(
  session: MachineSession | undefined,
  n: number,
  liveSeconds?: number | null,
): number {
  const want = Math.max(0, Math.floor(Number(n) || 0));
  const current = Math.max(
    0,
    Math.floor(Number(session?.runtimeLivePieces) || 0),
  );
  // Minus / same: never steal a piece they already tapped.
  if (want <= current) return want;
  const max = maxLivePieces(session, liveSeconds);
  return Math.min(want, Math.max(current, max));
}

/**
 * Cycle math for the open runtime: sold time for pieces tapped so far
 * vs this clock. Setup of this op is included only after that setup is stopped.
 */
export function runtimePaceSeconds(
  session: MachineSession | undefined,
  liveSeconds?: number | null,
): { quoted: number; actual: number; pieces: number } | null {
  if (!session) return null;
  const idx = liveRuntimeIndex(session);
  if (idx == null) return null;
  const pieces = liveRuntimePieces(session);
  if (pieces <= 0) return null;
  const per = session.quotedRuntimes?.[idx] || 0;
  if (per <= 0) return null;
  let quoted = per * pieces;
  let actual = Math.max(0, Number(liveSeconds) || 0);
  const setup = session.setups?.[idx];
  if (typeof setup === "number" && setup > 0) {
    quoted += session.quotedSetups?.[idx] || 0;
    actual += setup;
  }
  return { quoted, actual, pieces };
}

export function jobPulseFromSession(
  session: MachineSession | undefined,
  liveSeconds?: number | null,
  now?: Date,
): JobPulseView | null {
  if (!session?.jobId) return null;
  const livePcs = liveRuntimePieces(session);
  const done = (session.quantityCompleted || 0) + livePcs;
  const pairDone =
    (session.pairQuantityCompleted || 0) +
    (session.pairPartNumber ? livePcs : 0);
  const pace = runtimePaceSeconds(session, liveSeconds);
  const { remainLine, etaLine } = remainAndEta(session, liveSeconds, now);
  const fresh = countFreshness(session, liveSeconds);
  return jobPulseFromRun({
    partNumber: session.partNumber,
    qty: session.quantity,
    done,
    pairPartNumber: session.pairPartNumber,
    pairQty: session.pairQuantity,
    pairDone,
    quotedSeconds: pace ? pace.quoted : quotedSecondsForSession(session),
    actualSeconds: pace ? pace.actual : actualSecondsForSession(session, liveSeconds),
    remainLine,
    etaLine,
    live: livePcs > 0,
    countTone: fresh.tone,
    countHint: fresh.hint,
    countAgeSec: fresh.ageSec,
  });
}

function quotedRunPerPiece(session: MachineSession): number {
  const idx = liveRuntimeIndex(session);
  if (idx != null) return session.quotedRuntimes?.[idx] || 0;
  const runs = session.quotedRuntimes || [];
  for (let i = 0; i < runs.length; i++) {
    const cell = session.runtimes?.[i];
    if (cell !== null && typeof cell === "number" && cell > 0) continue;
    if ((runs[i] || 0) > 0) return runs[i] || 0;
  }
  return Math.max(0, ...runs, 0);
}

function remainAndEta(
  session: MachineSession,
  liveSeconds?: number | null,
  now?: Date,
): { remainLine: string; etaLine: string } {
  const livePcs = liveRuntimePieces(session);
  const done = (session.quantityCompleted || 0) + livePcs;
  const remainPcs = Math.max(0, (session.quantity || 0) - done);
  if (remainPcs <= 0) {
    return done > 0 ? { remainLine: "Qty in", etaLine: "" } : { remainLine: "", etaLine: "" };
  }

  const clock = now || new Date();
  const liveSec = effectiveRuntimeSeconds(session, liveSeconds);

  if (livePcs > 0 && liveSec > 0) {
    const secEach = liveSec / livePcs;
    const remainSec = remainPcs * secEach;
    const pace = runtimePaceSeconds(session, liveSeconds);
    const efficiency =
      pace && pace.actual > 0 ? pace.quoted / pace.actual : 1;
    if (efficiency < PACE_HIDE_BELOW) {
      return { remainLine: "", etaLine: "" };
    }
    const eta = new Date(clock.getTime() + remainSec * 1000);
    return {
      remainLine: `${formatDurationShort(remainSec)} left`,
      etaLine: `~${formatClock(eta)}`,
    };
  }

  const per = quotedRunPerPiece(session);
  if (per <= 0) return { remainLine: "", etaLine: "" };
  const remainSec = remainPcs * per;
  return {
    remainLine: `Sold ${formatDurationShort(remainSec)} left`,
    etaLine: "",
  };
}

export function findSessionForPart(
  sessions: Record<string, MachineSession | undefined>,
  partNumber: string,
): MachineSession | undefined {
  const pn = (partNumber || "").trim().toUpperCase();
  if (!pn) return undefined;
  const hits = Object.values(sessions).filter((s) => {
    if (!s?.jobId) return false;
    return (
      (s.partNumber || "").toUpperCase() === pn ||
      (s.pairPartNumber || "").toUpperCase() === pn
    );
  });
  if (!hits.length) return undefined;
  const running = hits.find((s) => liveRuntimeIndex(s) != null);
  return running || hits[0];
}

/** Same as jobPulseFromSession, but flip to the nest-pair numbers when the board card is the pair P/N. */
export function jobProgressForPart(
  session: MachineSession | undefined,
  liveSeconds: number | null | undefined,
  partNumber: string,
): JobPulseView | null {
  const view = jobPulseFromSession(session, liveSeconds);
  if (!view) return null;
  const pn = (partNumber || "").trim().toUpperCase();
  if (view.pair && (view.pair.partNumber || "").toUpperCase() === pn) {
    return {
      ...view,
      partNumber: view.pair.partNumber,
      done: view.pair.done,
      qty: view.pair.qty,
      fill: view.pair.fill,
      pair: undefined,
    };
  }
  return view;
}

/** Add the open timer so the shift bar moves while they run. Display only. */
export function withLiveClock(
  calc: DayBonusCalc | null,
  opts: {
    operatorName: string;
    sessions: Record<string, MachineSession | undefined>;
    activeTimers: Record<string, ActiveTimer | null | undefined>;
    getLiveSeconds: (machine: string) => number;
    settings: Pick<
      AppSettings,
      "workDayStart" | "workDayEnd" | "lunchHours" | "shifts"
    >;
    now?: Date;
  },
): DayBonusCalc | null {
  if (!calc) return calc;
  const name = opts.operatorName.trim().toLowerCase();
  if (!name) return calc;
  const now = opts.now || new Date();
  const start = calc.workDayStart;
  const end = calc.workDayEnd;
  const winStart = dateAtHhmm(calc.dateKey, start).getTime();
  let winEnd = dateAtHhmm(calc.dateKey, end).getTime();
  if (winEnd <= winStart) winEnd += 24 * 3600000;

  let extra = 0;
  for (const [machine, timer] of Object.entries(opts.activeTimers || {})) {
    if (!timer) continue;
    const sess = opts.sessions[machine];
    if ((sess?.operatorName || "").trim().toLowerCase() !== name) continue;
    const live = Math.max(0, opts.getLiveSeconds(machine) || 0);
    if (live <= 0) continue;
    const a = now.getTime() - live * 1000;
    extra += overlapHours(a, now.getTime(), winStart, winEnd);
  }
  if (extra <= 0.001) return calc;
  const onShiftHours = calc.onShiftHours + extra;
  const workedHours = calc.workedHours + extra;
  const efficiency =
    workedHours > 0 ? calc.earnedHours / workedHours : calc.efficiency;
  return {
    ...calc,
    onShiftHours,
    workedHours,
    efficiency,
  };
}

export function activeFloorNames(operators: Operator[]): string[] {
  return operators
    .filter((o) => o.active !== false && (o.name || "").trim())
    .map((o) => o.name.trim());
}

export { currentShiftContext };
