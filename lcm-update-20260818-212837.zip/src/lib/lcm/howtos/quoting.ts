import type { PageHowToDoc } from "./types";

export const quotingHowTo: PageHowToDoc = {
  id: "quoting",
  path: "/quoting",
  title: "Master Quoter",
  audience: "admin",
  tab: "quoting",
  whatThisPageIs:
    "Master quoter. Typing a part number loads history from the live database. Price each is always calculated from setup, runtime, material, machine %, qty breaks, and (on assemblies) BOM + bench. You do not type a unit price. Shop averages can move setup & run times on the saved part — the live price moves because the recipe moved. Money-gated admin tab. Floor never sees this screen.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "One form is one part (or one -01 assembly). Exact part # match loads the whole record silently. Partial type-ahead lists up to 12 hits — click or Enter to fill. Empty part # blanks the entire form so leftovers do not ride onto a new number.",
        },
        {
          type: "p",
          text: "The form auto-saves a draft on this device while you type (part #, loaded id, fields). Save / Update existing writes the live shop book and flushes to the host so Customer Orders import can see the part immediately. Email jumps to Email Quotes with this quote checked (saves first if needed).",
        },
        {
          type: "p",
          text: "Assemblies: -01 parent, children -02 / -03 on the BOM, bench bolt-up minutes, then final machine ops on -01. Child $ pull from those parts’ quotes when they exist. Single parts use material + stock + ops only.",
        },
        {
          type: "note",
          text: "Number boxes accept shop math: type 12*12 or 12x12 — it does the math on blur / Enter. Do not roll the mouse wheel on Machine % or Material %.",
        },
        {
          type: "warn",
          text: "Admin / money. Machine % and Material %: 1 = actual, 1.25 = 25% markup. Soft jaws and special tools bill as their own lines — do not bury them in the part each. Saved without material still writes the part, but PO import cannot auto-fill stock until you add material/size.",
        },
      ],
    },
    {
      title: "Top bar — Guided quote, Save, Email, More…",
      blocks: [
        {
          type: "control",
          name: "Master Quoter",
          does: "Page title. Type a part # to search the database — selecting a match fills the whole form.",
        },
        {
          type: "control",
          name: "Guided quote",
          does: "Opens the step-through wizard (Customer → Part number → Revision → Quote type → Material & stock → Soft jaws / tooling → Machines → Setup & runtime → Quantity breaks → Review). Apply to form dumps the answers onto this page — you still review and Save here.",
        },
        {
          type: "control",
          name: "Save",
          does: "Writes the live database (submit). Part number required. Revision defaults to A if blank. Keeps the form loaded so you can confirm what was saved. Toast includes material · type · shape · size, or (no material).",
        },
        {
          type: "control",
          name: "Email",
          does: "Opens Email Quotes with this part selected. If the quote is not saved yet, it Update-saves first. Needs a part number.",
        },
        {
          type: "control",
          name: "More…",
          does: "Menu: Search database, Update existing, Clear form, Delete part.",
        },
        {
          type: "control",
          name: "Search database",
          does: "Looks up the typed part # exactly. No quote found for that part # if it is not in the book. Type-ahead + Enter on a highlighted row also loads.",
        },
        {
          type: "control",
          name: "Update existing",
          does: "Same write as Save but as an update of the loaded / same part # record.",
        },
        {
          type: "control",
          name: "Clear form",
          does: "Empties the form and the part search. Does not delete the database row.",
        },
        {
          type: "control",
          name: "Delete part",
          does: "Deletes the quote for this part # after confirm: Delete quote for [PN]?. Then clears the form.",
        },
        {
          type: "p",
          text: "Loaded from database: [PN] · customer · Rev — banner after a load. Assembly chip when Quote type is Assembly (-01).",
        },
      ],
    },
    {
      title: "Shop evidence and lock prices",
      blocks: [
        {
          type: "p",
          text: "Appears when this part/rev has completed floor runs. Collapsed by default: Shop evidence · N floor runs. Floor proof for reprice — expand when needed. Show / Hide.",
        },
        {
          type: "control",
          name: "Shop evidence",
          does: "Expand for how Price each is calculated, last floor runs, past calculated prices, and Lock today's calculated prices.",
        },
        {
          type: "p",
          text: "Price each is always calculated. Setup, runtime, material, machine %, qty breaks → the green Price each row. You do not type a unit price; change the recipe and the price moves with it.",
        },
        {
          type: "p",
          text: "How to read floor runs: Time sold → actual compares the time built into that quote vs what the job really took. +% = slower than sold (price may need to go up). −% = faster (margin room).",
        },
        {
          type: "p",
          text: "What averages change: Completed jobs can update setup & run times on the saved part (rules in Settings → Shop average rules). Next time you open it, Price each recalculates from those times.",
        },
        {
          type: "p",
          text: "What “lock / history” is: A photo of the calculated qty & $ each at that moment (save, email, or lock). History does not change later; the live quoter still always recalculates from current data.",
        },
        {
          type: "control",
          name: "Last floor runs (newest first)",
          does: "Table: When, Machine, Time sold → actual, vs sold time, Efficiency. vs sold time says slower — consider raise, faster — margin headroom, or about as quoted.",
        },
        {
          type: "control",
          name: "Past calculated prices (history)",
          does: "Snapshots labeled Emailed, Locked, or Saved with date and qty N @ $ ea. Empty: No frozen price yet — email a quote or use lock below after you set qty breaks.",
        },
        {
          type: "control",
          name: "Lock today's calculated prices",
          does: "Saves the current form, then writes a history photo of the Price each row (from setup / run / material / qty) — not a typed price. Needs a part number and a loaded quote.",
        },
      ],
    },
    {
      title: "Part & material — identity",
      blocks: [
        {
          type: "control",
          name: "Part & material",
          does: "Main identity card (left/wide column).",
        },
        {
          type: "control",
          name: "Part #",
          does: "Search + identity. Placeholder: Start typing part number…. Filters as you type. Click a result (or press Enter) to fill the entire quoter. Arrow keys move the highlight. Escape closes the list. Exact match auto-loads. Empty box blanks the form. No matching parts — keep typing for a new quote.",
        },
        {
          type: "control",
          name: "Quote type",
          does: "Single part or Assembly (-01). Assembly = -01 parent · children -02/-03 · one sell price. Switching to assembly suggests BOM children from the PN and turns off Calculate material drop. Switching back to part clears BOM and bench minutes.",
        },
        {
          type: "control",
          name: "Single part",
          does: "One piece, own material and ops. Live costs show Run cost / Base total.",
        },
        {
          type: "control",
          name: "Assembly (-01)",
          does: "Shows Assembly BOM and retitles ops to Final -01 machine ops. Live costs add BOM (children) and Bench bolt-up; run line becomes Final machine run / Assembly unit total.",
        },
        {
          type: "control",
          name: "Customer",
          does: "Creatable list from Customers & emails. Add customer saves that name for future quotes.",
        },
        {
          type: "control",
          name: "Revision",
          does: "Forced uppercase. Save stores A if you leave it blank.",
        },
        {
          type: "control",
          name: "Suggested pair (optional)",
          does: "Hint for the floor. — Floor decides — if empty. Operators can nest any two jobs on the machine. Create title: Pair part #.",
        },
        {
          type: "control",
          name: "Machines (select all that apply)",
          does: "Check every machine this job may run on. First selected is preferred. Job averages use these when matching past runs. Placeholder: Select one or more machines…. New names are added to the shop machine list.",
        },
        {
          type: "control",
          name: "Machine %",
          does: "1 = actual · 1.25 = 25% markup on run time. Do not roll the wheel.",
        },
      ],
    },
    {
      title: "Material, size, LOC, live calculator",
      blocks: [
        {
          type: "control",
          name: "Where does the stock come from?",
          does: "Cut from our rack (normal bar/plate you saw) or Bought blank (Total Fab). Bought blank hides size, calculator, and drop. Type their $ each instead.",
        },
        {
          type: "control",
          name: "Bought blank (Total Fab)",
          does: "Pre-cut blanks they sell us (time + material in one price). Vendor defaults to Total Fab. Blank $ each is the material cost per piece. Material % still marks it up. Live costs show Blank w/ %. PO will not hold rack inches or send this to the saw — it asks you to order that many pieces from the vendor.",
        },
        {
          type: "control",
          name: "Vendor",
          does: "Who is selling the blank. Default Total Fab. Add another vendor if needed.",
        },
        {
          type: "control",
          name: "Blank $ each",
          does: "What they charge per piece. That number × Material % is the material line on the quote. No bar length, no drop.",
        },
        {
          type: "control",
          name: "Material",
          does: "Family (Aluminum, Steel…). Changing family clears type if the old grade is not on the new family. Add material creates a shop list item.",
        },
        {
          type: "control",
          name: "Material type",
          does: "Grade (T6 6061…). Add type adds it under the current family.",
        },
        {
          type: "control",
          name: "Stock shape",
          does: "Round, rectangle, plate…. Changing shape drives which size fields show (dia vs X × Y). Add shape adds to the shop list.",
        },
        {
          type: "control",
          name: "How it sits",
          does: "Mill — X Y Z in the vise, or Lathe — X diameter, Z length. Lathe hides Y and treats X as diameter.",
        },
        {
          type: "control",
          name: "Size in the machine",
          does: "Stock blank as it sits in the machine. The highlighted axis is LOC — the one the saw cuts. Lathe: X is diameter (stays stock). Z is length of cut. Mill: pick which axis is the cut. The other faces stay stock. Type inches; 12*12 math works.",
        },
        {
          type: "control",
          name: "LOC — length of cut",
          does: "The axis being sawed, and how long that cut is. If the model is 3\", cut 3.1\" so you can machine .05\" off each end. Do not pick an axis that must stay stock (a model surface). Radio choices come from the shape + mill/lathe.",
        },
        {
          type: "control",
          name: "Length of cut (X/Y/Z) \"",
          does: "Cut length in inches (e.g. 3.1). Syncs with the highlighted size axis.",
        },
        {
          type: "control",
          name: "Full bar on the rack (\")",
          does: "Raw stick length for the calculator (placeholder 144). Needed for full stick $.",
        },
        {
          type: "control",
          name: "Material %",
          does: "1 = actual · 1.15 = 15% markup on material.",
        },
        {
          type: "control",
          name: "Raw material cost",
          does: "Dollar amount in the recipe. The calculator can fill this when you tap Use as raw material cost. If the book estimate is > 0 and this box is still 0, the form auto-fills the estimate once.",
        },
        {
          type: "control",
          name: "LCM material Calculator",
          does: "Live estimate from Settings price book: grade, $/lb, lb/ft, $/in, stock lb and $, cut $. Formula line under it. Set material, type, shape, section, and stock length to estimate. Set stock length for full stick $.",
        },
        {
          type: "control",
          name: "Use as raw material cost",
          does: "Copies the calculator stock $ into Raw material cost. Shows when stock cost > 0.",
        },
        {
          type: "control",
          name: "Calculate material drop",
          does: "No / Yes. When Yes, Drop $/pc on the qty table gets a drop charge. Assemblies force this off.",
        },
      ],
    },
    {
      title: "Live costs",
      blocks: [
        {
          type: "control",
          name: "Live costs",
          does: "Right-hand running total. Recalculates as you type. Price each on the qty card is the customer number; this card is the build-up.",
        },
        {
          type: "control",
          name: "BOM (children)",
          does: "Assembly only. Sum of child quotes × BOM qty.",
        },
        {
          type: "control",
          name: "Bench bolt-up",
          does: "Assembly only. Bench assemble minutes × machine rate math.",
        },
        {
          type: "control",
          name: "Material w/ %",
          does: "Raw material cost after Material %.",
        },
        {
          type: "control",
          name: "Setup cost",
          does: "All Setup min × rate (spread across qty in Price each).",
        },
        {
          type: "control",
          name: "Run cost",
          does: "Single part. Run min/pc after Machine %.",
        },
        {
          type: "control",
          name: "Final machine run",
          does: "Assembly label for the same run line (ops on -01 after bolt-up).",
        },
        {
          type: "control",
          name: "Base total",
          does: "Single-part unit build-up before qty breaks.",
        },
        {
          type: "control",
          name: "Assembly unit total",
          does: "Assembly label for the same strong total.",
        },
        {
          type: "control",
          name: "Special tools shop cost (not in price each)",
          does: "Internal tooling $ on the quote. Not rolled into Price each. Bill separately with Bill customer (separate line).",
        },
      ],
    },
    {
      title: "Assembly BOM",
      blocks: [
        {
          type: "p",
          text: "Only when Quote type is Assembly (-01). Shop flow: machine -02 & -03 → bench bolt → final ops on -01 (grid below). Child costs pull from the parts database when those quotes exist.",
        },
        {
          type: "control",
          name: "Assembly BOM",
          does: "Child table plus bench minutes and BOM roll-up / assembly total.",
        },
        {
          type: "control",
          name: "Suggest -02 / -03",
          does: "Needs the assembly part number first (e.g. NS-2200-01). Fills two children from the PN, pulls rev/material note if those quotes exist. Toast: BOM set to [children].",
        },
        {
          type: "control",
          name: "Line",
          does: "Adds another child row, suggesting the next -0N from the parent PN.",
        },
        {
          type: "control",
          name: "Child part #",
          does: "Uppercase. Datalist of non-assembly quotes. Not in DB yet if that PN has no quote — Unit $ / Ext $ stay —.",
        },
        {
          type: "control",
          name: "Rev",
          does: "Child revision (often filled from the child’s quote).",
        },
        {
          type: "control",
          name: "Qty",
          does: "How many of that child per parent. Minimum 1.",
        },
        {
          type: "control",
          name: "Note",
          does: "Housing, shaft… — shop note on the line.",
        },
        {
          type: "control",
          name: "Unit $",
          does: "From the child’s quote when found. Not typed.",
        },
        {
          type: "control",
          name: "Ext $",
          does: "Unit $ × Qty. Not typed.",
        },
        {
          type: "control",
          name: "Remove",
          does: "Trash on that BOM line.",
        },
        {
          type: "control",
          name: "Bench assemble (minutes)",
          does: "Bolt / fit on the bench before final machine ops.",
        },
        {
          type: "control",
          name: "BOM roll-up / assembly",
          does: "Sum of found child ext $.",
        },
      ],
    },
    {
      title: "Setup & run times (ops)",
      blocks: [
        {
          type: "control",
          name: "Setup & run times (minutes) · OP1–OPn",
          does: "Single-part title. n is Settings → Max operations (OP slots).",
        },
        {
          type: "control",
          name: "Final -01 machine ops (minutes) · OP1–OPn",
          does: "Assembly title for the same grid — ops after bench bolt-up.",
        },
        {
          type: "control",
          name: "Setup min",
          does: "Minutes per OP to indicate, tool, first-article. Leave 0 if that OP is not used. More than 6 ops are allowed when max ops is raised.",
        },
        {
          type: "control",
          name: "Run min/pc",
          does: "Minutes per piece on that OP. Shop averages can rewrite these after completed jobs (see Shop evidence).",
        },
        {
          type: "control",
          name: "Machine",
          does: "One official floor machine per OP, under Setup min / Run min/pc. Leave — if that OP is unused. When two or more OPs name different machines, Assign Queue and Job Board split the job by OP. The Machines (select all that apply) list stays in sync with the unique names you pick here.",
        },
        {
          type: "p",
          text: "OP column headers are OP1, OP2, … up to max operations. Empty / 0 slots do not add cost.",
        },
      ],
    },
    {
      title: "Shop floor time (open tooling logs)",
      blocks: [
        {
          type: "p",
          text: "Appears only when operators timed soft jaws / other on the machine for this part/rev and the log is still open. Adjust minutes and customer amount here before you put it on the quote or send email.",
        },
        {
          type: "control",
          name: "Shop floor time",
          does: "One card per open log. Title includes Soft jaws / Special tool / Other tooling and · timer still running if the clock is still on.",
        },
        {
          type: "control",
          name: "Description (customer line)",
          does: "What the customer will see if you bill it.",
        },
        {
          type: "control",
          name: "Minutes (adjust)",
          does: "Live minutes from the floor clock, editable. Changing minutes recalculates suggested shop cost / bill when you have not overridden them.",
        },
        {
          type: "control",
          name: "Shop cost (internal)",
          does: "Internal $ from minutes. Not on the letter unless you also bill.",
        },
        {
          type: "control",
          name: "Bill customer as separate line",
          does: "When checked, Customer price each appears and Add to quote puts a billed tooling line on the quote.",
        },
        {
          type: "control",
          name: "Customer price each",
          does: "What appears on the quote email — change freely before sending.",
        },
        {
          type: "control",
          name: "Add to quote",
          does: "Saves the part, applies the log (minutes, bill, shop cost, description), reloads the form. Load or enter the part first. Toast: Added to quote — adjust line below if needed, or Stored on quote (not billed).",
        },
        {
          type: "control",
          name: "No charge",
          does: "Resolves the floor log as no_charge. Does not add a line.",
        },
        {
          type: "control",
          name: "Dismiss",
          does: "Resolves the log as dismissed. Does not add a line.",
        },
      ],
    },
    {
      title: "Special tools",
      blocks: [
        {
          type: "control",
          name: "Special tools",
          does: "Collapsed unless there are already charges. Soft jaws & extras — separate from part price each. optional · expand to add.",
        },
        {
          type: "control",
          name: "Soft jaws",
          does: "Kind dropdown value. Default description Soft jaws.",
        },
        {
          type: "control",
          name: "Special tool",
          does: "Kind dropdown value.",
        },
        {
          type: "control",
          name: "Other",
          does: "Kind dropdown value (stored as other; label Other tooling on floor logs).",
        },
        {
          type: "control",
          name: "Bill customer (separate line)",
          does: "When on, Bill qty and Customer price each show. Those lines print / email. Shop cost stays internal either way.",
        },
        {
          type: "control",
          name: "Remove",
          does: "Deletes that tooling charge from the quote form (not a floor log).",
        },
        {
          type: "control",
          name: "Description",
          does: "Customer-facing name. Placeholder is the kind label.",
        },
        {
          type: "control",
          name: "Shop cost (internal)",
          does: "Internal $ on this charge. If bill is on and customer price is still 0, it copies this amount.",
        },
        {
          type: "control",
          name: "Notes (shop only)",
          does: "Vendor, re-use on next job… — never on the customer letter.",
        },
        {
          type: "control",
          name: "Bill qty",
          does: "How many of this tool line to bill. Minimum 1.",
        },
        {
          type: "control",
          name: "Customer price each",
          does: "Edit anytime before emailing the customer — separate from part price each.",
        },
        {
          type: "control",
          name: "Add special tool",
          does: "Appends a Special tool row.",
        },
      ],
    },
    {
      title: "Quantity breaks & price each",
      blocks: [
        {
          type: "control",
          name: "Quantity breaks & price each",
          does: "Six levels L1–L6. You type Qty. Drop $/pc and Price each are calculated.",
        },
        {
          type: "control",
          name: "Level",
          does: "Column headers L1 … L6.",
        },
        {
          type: "control",
          name: "Qty",
          does: "Break quantities (1, 5, 10…). Zero / empty is unused. Email Quotes counts breaks with qty > 0.",
        },
        {
          type: "control",
          name: "Drop $/pc",
          does: "Calculated drop charge per piece when Calculate material drop is Yes. Read-only.",
        },
        {
          type: "control",
          name: "Price each",
          does: "Green calculated customer unit price at that qty. Dash if that level has no qty. You do not type this row. Lock today's calculated prices snapshots these numbers.",
        },
      ],
    },
    {
      title: "Guided quote steps",
      blocks: [
        {
          type: "p",
          text: "Wizard title Guided quote. Step N of 10: [step]. Progress dots. Close dismisses without applying. Back / Next. Last step is Apply to form — review prices and save on the main form. Enter on Part number and Revision advances.",
        },
        {
          type: "control",
          name: "Customer",
          does: "Step 1. Same creatable customer list. Add customer · Saved for future quotes.",
        },
        {
          type: "control",
          name: "Part number",
          does: "Step 2. Forced uppercase. Placeholder e.g. AF-4421.",
        },
        {
          type: "control",
          name: "Revision",
          does: "Step 3. Forced uppercase. Placeholder A.",
        },
        {
          type: "control",
          name: "Quote type",
          does: "Step 4. Part or Assembly buttons (same meaning as Single part / Assembly (-01) on the full form).",
        },
        {
          type: "control",
          name: "Material & stock",
          does: "Step 5. Same GuidedMaterialForm as the full form: Material, Material type, Stock shape, How it sits, Size in the machine, LOC — length of cut, Length of cut, Full bar on the rack.",
        },
        {
          type: "control",
          name: "Soft jaws / tooling",
          does: "Step 6. Soft jaws or special tools for this part? (You can add charges on the full form later.) Yes — need tooling or No. This only notes intent — charges are added on Special tools after Apply.",
        },
        {
          type: "control",
          name: "Machines that run this part",
          does: "Step 7. Same multi-select as Machines (select all that apply). First selected is preferred.",
        },
        {
          type: "control",
          name: "Setup & runtime",
          does: "Step 8. One field at a time: OP1 Setup (minutes), then OP1 Runtime (minutes), then OP2…. Enter minutes, then Next. Field clears for the next op. Leave 0 if this op is not used. Back walks setup ← runtime ← previous OP.",
        },
        {
          type: "control",
          name: "Quantity breaks",
          does: "Step 9. Qty and @ $ per level. Unlike the main form, the wizard lets you type a $ here; Apply writes those prices onto the form draft — the live green Price each still recalculates from the recipe when you land back on the main page. Review and Save there.",
        },
        {
          type: "control",
          name: "Review",
          does: "Step 10. PN, Rev, kind, customer, material, shape, machines, soft jaws noted, ops setup/run. Apply fills the main form — review prices and save there.",
        },
        {
          type: "control",
          name: "Close",
          does: "Closes the wizard. No apply.",
        },
        {
          type: "control",
          name: "Back",
          does: "Previous step (or previous OP phase). Disabled on the first setup field of OP1.",
        },
        {
          type: "control",
          name: "Next",
          does: "Next step / next OP phase.",
        },
        {
          type: "control",
          name: "Apply to form",
          does: "Writes the draft onto Master Quoter and closes. Toast: Guided quote applied — review and Save.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Reprice a part from floor time",
        },
        {
          type: "ol",
          items: [
            "Type the part #. Confirm Loaded from database.",
            "Open Shop evidence. Read Time sold → actual. +% means raise; −% is margin room.",
            "If averages already moved Setup min / Run min/pc, look at the new green Price each.",
            "Change Machine % / Material % / times if the recipe should change.",
            "Save or Update existing. Lock today's calculated prices if you want a history photo. Email if the buyer should see it.",
          ],
        },
        {
          type: "h",
          text: "New single part (full form)",
        },
        {
          type: "ol",
          items: [
            "Clear form (or start with an empty Part #).",
            "Type the new part # (no match). Set Customer, Revision.",
            "Quote type = Single part. Check Machines (select all that apply). Set Machine %.",
            "Material, Material type, Stock shape, How it sits, Size in the machine, LOC — length of cut, Full bar on the rack. Or Bought blank (Total Fab) and type their $ each.",
            "If cutting from the rack: Read LCM material Calculator. Use as raw material cost. Set Material %. If a bought blank: set Blank $ each and Material %.",
            "Fill Setup min and Run min/pc. Qty on L1–L6. Read Price each.",
            "Add special tool if jaws / tools bill separately. Save.",
          ],
        },
        {
          type: "h",
          text: "New part with Guided quote",
        },
        {
          type: "ol",
          items: [
            "Guided quote.",
            "Customer → Part number → Revision → Part or Assembly.",
            "Material & stock (same size / LOC fields).",
            "Yes — need tooling or No.",
            "Machines that run this part.",
            "Each OP Setup then Runtime (minutes), Next through unused 0s.",
            "Quantity breaks. Review. Apply to form.",
            "On the main form: confirm Live costs and Price each, add billed Special tools, Save.",
          ],
        },
        {
          type: "h",
          text: "Quote a -01 assembly",
        },
        {
          type: "ol",
          items: [
            "Save the -02 / -03 children as Single part first so Unit $ exist.",
            "Type the -01 number. Quote type = Assembly (-01).",
            "Suggest -02 / -03 (or Line). Fix Child part # / Qty / Note. Not in DB yet means go quote that child.",
            "Set Bench assemble (minutes).",
            "Fill Final -01 machine ops only (after bolt-up).",
            "Read Live costs: BOM (children), Bench bolt-up, Final machine run, Assembly unit total.",
            "Set Qty breaks. Save. Email — customer sees one sell price plus any billed tools, not the BOM recipe.",
          ],
        },
        {
          type: "h",
          text: "Apply floor soft-jaw time to the letter",
        },
        {
          type: "ol",
          items: [
            "Load the part. Shop floor time appears if a log is open.",
            "Adjust Description (customer line), Minutes (adjust), Shop cost (internal).",
            "Check Bill customer as separate line and set Customer price each — or leave it unchecked to store only.",
            "Add to quote (or No charge / Dismiss).",
            "Confirm the line under Special tools. Save. Email.",
          ],
        },
        {
          type: "warn",
          text: "Delete part removes the quote from the book. It does not delete jobs, POs, or floor time. Prefer Clear form when you only want a blank screen.",
        },
      ],
    },
  ],
};
