import type { PageHowToDoc } from "./types";

export const partsQuotesHowTo: PageHowToDoc = {
  id: "parts-quotes",
  path: "/database",
  title: "Parts & Quotes",
  audience: "admin",
  tab: "database",
  whatThisPageIs:
    "The quote book. Same records Master Quoter saves and Settings → Import historical quotes fills. Money-gated — shop logins never open this tab. Browse and search only; you do not edit prices here. Open Master Quoter to change a part.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "Every saved quote is one row. Assemblies show as Assembly with the child part numbers in the Type column. Single parts show Part plus material type. Missing stock shape on a part lights yellow Shape? — fix that on the quoter so Customer Orders can match rack stock.",
        },
        {
          type: "p",
          text: "Search is comma-separated AND. Type assembly, NS-2200, aluminum and a row must contain every term. It looks at part number, customer, material, revision, material type, kind (part / assembly), BOM children, and machines.",
        },
        {
          type: "note",
          text: "Price @ qty1 is the first quantity-break price (L1). It is calculated on the quoter, not typed here. Empty means the quote has no qty-1 price yet.",
        },
        {
          type: "warn",
          text: "Admin / money tab. Operators cannot leave this tab on — Settings strips Quoting, Parts & Quotes, Email Quotes, and Reports from shop logins.",
        },
      ],
    },
    {
      title: "Page controls",
      blocks: [
        {
          type: "control",
          name: "Parts & Quotes",
          does: "Page title. Subtitle counts filtered vs all: Search quotes (comma-separated terms = AND). N of M shown. Assemblies use -01 with BOM children (-02, -03…).",
        },
        {
          type: "control",
          name: "Open Master Quoter",
          does: "Jumps to /quoting so you can load the part, change the recipe, and Save.",
        },
        {
          type: "control",
          name: "Search e.g. assembly, NS-2200, aluminum",
          does: "Live filter. Commas mean AND. Empty box shows the whole book.",
        },
      ],
    },
    {
      title: "Part / quote database columns",
      blocks: [
        {
          type: "control",
          name: "Part / quote database",
          does: "The table. One row per saved quote.",
        },
        {
          type: "control",
          name: "Date",
          does: "Quote date from the record.",
        },
        {
          type: "control",
          name: "Part #",
          does: "Part number as saved (usually uppercase from the quoter).",
        },
        {
          type: "control",
          name: "Type",
          does: "Assembly badge or Part badge. Not the same as the later Type (material grade) column.",
        },
        {
          type: "control",
          name: "Rev",
          does: "Revision badge.",
        },
        {
          type: "control",
          name: "Customer",
          does: "Customer name on the quote.",
        },
        {
          type: "control",
          name: "Material",
          does: "Family (Aluminum, Steel…). Dash if empty.",
        },
        {
          type: "control",
          name: "Type",
          does: "On a part: material type / grade. On an assembly: child part numbers from the BOM, comma-separated.",
        },
        {
          type: "control",
          name: "Stock",
          does: "Stock shape on a part. Assemblies show a dash. Missing shape on a part: Shape?",
        },
        {
          type: "control",
          name: "Machines",
          does: "Machines checked on the quote. Dash if none.",
        },
        {
          type: "control",
          name: "Price @ qty1",
          does: "First price break. Money. Admin only.",
        },
        {
          type: "control",
          name: "Shape?",
          does: "Yellow chip when a single part has no stock shape. PO import and rack match need a shape.",
        },
        {
          type: "control",
          name: "ASM",
          does: "Not on this table — that chip is on the quoter search list. Here assemblies use the Assembly badge.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Find a part before you requote",
        },
        {
          type: "ol",
          items: [
            "Type the part number (or customer, or material). Add a comma and a second term if the list is long.",
            "Read Type, Rev, Stock, Machines, Price @ qty1.",
            "If Stock is Shape?, open Master Quoter and set Stock shape before the next PO lands.",
            "Tap Open Master Quoter, type the same part #, and the form fills from this book.",
          ],
        },
        {
          type: "h",
          text: "See an assembly and its children",
        },
        {
          type: "ol",
          items: [
            "Search assembly or the -01 parent number.",
            "Type column lists the -02 / -03 children.",
            "Search a child number to open that piece’s own quote row.",
          ],
        },
        {
          type: "note",
          text: "This page does not delete or edit. Delete part lives under More… on Master Quoter.",
        },
      ],
    },
  ],
};
