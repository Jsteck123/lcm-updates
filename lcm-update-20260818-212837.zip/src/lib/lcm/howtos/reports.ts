import type { PageHowToDoc } from "./types";

export const reportsHowTo: PageHowToDoc = {
  id: "reports",
  path: "/reports",
  title: "Reports",
  audience: "admin",
  tab: "reports",
  whatThisPageIs:
    "Who ran what versus quote. Machine hours, operator efficiency, day / week bonus, downtime, and quoted vs actual. Money-gated admin tab. Weekly Mark paid is live only when Beta is off. Shift windows, lunch, hourly rate, and tiers live in Settings → Shifts & bonus.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "Period filters completed jobs (and downtime / finalized bonuses) to Today, Last 7 days, Last 30 days, or All time. Tabs switch the view; they do not change the data.",
        },
        {
          type: "p",
          text: "Bonus window is Settings shift. Time before start or after end does not count. Lunch is excluded so a 7–4 day is 8 hours. Full work day required (work + pause inside the window). Day % = earned ÷ worked. Cash is locked when the day is finalized, then paid weekly.",
        },
        {
          type: "warn",
          text: "While BETA is on (header pill / Settings → Beta), amounts show for practice and Mark paid is replaced by Beta · not paid. Turn Beta off before a real closeout week.",
        },
        {
          type: "note",
          text: "End of shift on the floor: stop timer → pause (End of Shift) → save in progress if the job continues tomorrow → Finalize day on this page.",
        },
      ],
    },
    {
      title: "Period and tabs",
      blocks: [
        {
          type: "control",
          name: "Period",
          does: "Today / Last 7 days / Last 30 days / All time. Applies to utilization, operator perf, downtime, and variance. Bonus lists show all finalized days / weeks; the live panel is today.",
        },
        {
          type: "control",
          name: "Utilization",
          does: "Machine utilization (hours) bar chart: Quoted, Actual, Pause per machine.",
        },
        {
          type: "control",
          name: "Operator perf",
          does: "Operator performance table.",
        },
        {
          type: "control",
          name: "Day / week bonus",
          does: "How day bonus works, Operator picker, Shift bonus panel, Finalized days, Weekly payouts.",
        },
        {
          type: "control",
          name: "Downtime",
          does: "Downtime log for the period.",
        },
        {
          type: "control",
          name: "Variance",
          does: "Quoted vs actual table for completed jobs in the period.",
        },
      ],
    },
    {
      title: "Utilization",
      blocks: [
        {
          type: "control",
          name: "Machine utilization (hours)",
          does: "One group per machine (names shortened). Quoted = sold time from the quote. Actual = clocked time split across machines used. Pause = closed downtime on that machine in the period.",
        },
      ],
    },
    {
      title: "Operator perf",
      blocks: [
        {
          type: "control",
          name: "Operator performance",
          does: "Rows from completed jobs plus finalized eligible day bonuses in the period.",
        },
        {
          type: "control",
          name: "Operator",
          does: "Name on the job / bonus record.",
        },
        {
          type: "control",
          name: "Jobs",
          does: "Completed jobs in the period.",
        },
        {
          type: "control",
          name: "Avg job eff",
          does: "Average of job efficiency (values over 1 are treated as percent and divided by 100).",
        },
        {
          type: "control",
          name: "Day bonuses",
          does: "Sum of finalized eligible day bonus dollars in the period. Money.",
        },
      ],
    },
    {
      title: "Day / week bonus",
      blocks: [
        {
          type: "control",
          name: "How day bonus works",
          does: "Explains the window, lunch, full-day rule, and weekly pay. Numbers come from Settings.",
        },
        {
          type: "control",
          name: "Operator",
          does: "Whose live bonus panel and finalize buttons you are looking at. Defaults to the first operator.",
        },
        {
          type: "control",
          name: "Shift bonus · [name]",
          does: "Live or Finalized card for that person. Shift chips (Day / Night, · now on the current window).",
        },
        {
          type: "control",
          name: "Shift efficiency",
          does: "Earned ÷ worked inside the window.",
        },
        {
          type: "control",
          name: "On shift (in window)",
          does: "Hours inside the shift vs required hours (after lunch).",
        },
        {
          type: "control",
          name: "Earned hours",
          does: "Hours that count toward the pool.",
        },
        {
          type: "control",
          name: "Projected",
          does: "Admin-only dollar estimate before finalize. After finalize the label is Shift bonus.",
        },
        {
          type: "control",
          name: "Finalize [shift]",
          does: "Locks the day after the shift end time. Disabled until then. Floor should have stopped timers and paused End of Shift first.",
        },
        {
          type: "control",
          name: "Admin force finalize",
          does: "Admin-only. Locks the day even if the shift has not ended.",
        },
        {
          type: "control",
          name: "Finalized days",
          does: "Each locked day: name, date, efficiency, on-shift hours / required, Eligible or No bonus, dollar amount.",
        },
        {
          type: "control",
          name: "Weekly payouts · current [week]",
          does: "Totals by operator and week. Paid badge, or Mark paid when Production is on, or Beta · not paid while Beta is on.",
        },
        {
          type: "control",
          name: "Mark paid",
          does: "Records that week as paid. Hidden in Beta. Confirm the dollar amount before you tap — this is the real closeout.",
        },
        {
          type: "control",
          name: "Paid",
          does: "Badge after Mark paid.",
        },
        {
          type: "control",
          name: "Beta · not paid",
          does: "Badge while App mode is Beta. You cannot mark paid.",
        },
      ],
    },
    {
      title: "Downtime and variance",
      blocks: [
        {
          type: "control",
          name: "Downtime log",
          does: "Reason, operator · machine · start, duration or open if still running.",
        },
        {
          type: "control",
          name: "Quoted vs actual",
          does: "Part, Operator, Quoted seconds, Actual seconds, Δ (red if over sold time, green if under).",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Close a day after the shift",
        },
        {
          type: "ol",
          items: [
            "On the floor: stop timers, pause End of Shift, save in progress if the job continues tomorrow.",
            "Open Reports → Day / week bonus.",
            "Pick Operator. Confirm the shift chip (Day / Night).",
            "After the shift End time, tap Finalize [shift]. Use Admin force finalize only if you mean to lock early.",
            "Check Finalized days — Eligible vs No bonus and the dollar amount.",
          ],
        },
        {
          type: "h",
          text: "Weekly closeout (Production only)",
        },
        {
          type: "ol",
          items: [
            "Confirm Settings → App mode is Production (live). BETA pill should be gone.",
            "Confirm every day of the week is finalized.",
            "On Weekly payouts, read the dollar amount and day count.",
            "Tap Mark paid after payroll is actually cut.",
          ],
        },
        {
          type: "h",
          text: "See if a machine is eating quote",
        },
        {
          type: "ol",
          items: [
            "Set Period to Last 7 days (or Last 30 days).",
            "Utilization — Actual vs Quoted bars.",
            "Variance — sort by eye for red +Δ parts, then open that part on Master Quoter → Shop evidence.",
          ],
        },
      ],
    },
  ],
};
