import type { AppTab } from "../types";

export type HowToAudience = "all" | "floor" | "admin";

export type HowToBlock =
  | { type: "p"; text: string }
  | { type: "h"; text: string }
  | { type: "ol"; items: string[] }
  | { type: "ul"; items: string[] }
  | { type: "note"; text: string }
  | { type: "warn"; text: string }
  | { type: "control"; name: string; does: string };

export type HowToSection = {
  title: string;
  blocks: HowToBlock[];
};

export type PageHowToDoc = {
  id: string;
  path: string;
  title: string;
  audience?: HowToAudience;
  tab?: AppTab;
  whatThisPageIs: string;
  sections: HowToSection[];
};
