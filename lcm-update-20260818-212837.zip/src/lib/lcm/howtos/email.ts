import type { PageHowToDoc } from "./types";

export const emailQuotesHowTo: PageHowToDoc = {
  id: "email-quotes",
  path: "/email",
  title: "Email Quotes",
  audience: "admin",
  tab: "email",
  whatThisPageIs:
    "Batch a customer letter: part, rev, qty breaks, and price each — plus any soft jaws / tools you chose to bill as separate lines. Setup times, material %, and internal shop costs stay off the letter. Money-gated admin tab. Master Quoter → Email lands here with that part already checked.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "Two steps. Pick quotes (filter + check rows). Then Preview & send: choose the recipient, write the note, open a formatted Outlook draft or copy the same boxed tables. The customer preview is exactly what print uses.",
        },
        {
          type: "p",
          text: "Open formatted email downloads a .eml with HTML tables (same boxed layout as print) and also puts that letter on the clipboard. mailto cannot carry HTML — that was the plain QTY 5 10 dump. Prefer the .eml.",
        },
        {
          type: "note",
          text: "From (your shop) shows Settings → Quote From email (display) when set. Logo on the letter comes from Settings → Company logo.",
        },
        {
          type: "warn",
          text: "Admin / money. Save the quote on Master Quoter first. Deep-link with a missing quote says Quote not found — save it on Master Quoter first.",
        },
      ],
    },
    {
      title: "Filter quotes",
      blocks: [
        {
          type: "control",
          name: "Filter quotes",
          does: "Card that narrows the list before you check rows.",
        },
        {
          type: "control",
          name: "Customer",
          does: "All customers, or one name from quotes that have a customer. Changing customer does not clear the date.",
        },
        {
          type: "control",
          name: "Date quoted (blank = any)",
          does: "Calendar day the quote was dated. Blank = any date. Master Quoter deep-link clears the date so that part still shows.",
        },
        {
          type: "control",
          name: "Today",
          does: "Sets Date quoted to today on this PC.",
        },
        {
          type: "control",
          name: "Any date",
          does: "Clears Date quoted.",
        },
      ],
    },
    {
      title: "Select quotes",
      blocks: [
        {
          type: "control",
          name: "Select quotes (N selected)",
          does: "List of filtered quotes. Tap a row to check or uncheck.",
        },
        {
          type: "control",
          name: "Select filtered",
          does: "Checks every quote currently matching the filter.",
        },
        {
          type: "control",
          name: "Clear",
          does: "Unchecks all.",
        },
        {
          type: "p",
          text: "Each row shows part #, Rev, customer, date, and how many qty breaks have qty > 0. Tooling you marked to bill shows a tooling bill badge. Tooling with only shop cost shows tooling stored (customer will not see it).",
        },
        {
          type: "control",
          name: "Preview & send",
          does: "Goes to the send step. Needs at least one quote. Prefills Customer from the selected parts when that name exists on Customers & emails; otherwise the first customer in the recent-email sort.",
        },
        {
          type: "note",
          text: "Empty list: No quotes match. Save quotes on Master Quoter first, or clear the date filter.",
        },
      ],
    },
    {
      title: "Recipient and send",
      blocks: [
        {
          type: "control",
          name: "← Back to selection",
          does: "Returns to Filter quotes / Select quotes without losing the checks.",
        },
        {
          type: "control",
          name: "Recipient",
          does: "Who gets the letter and how you send it.",
        },
        {
          type: "control",
          name: "Customer",
          does: "Shop customer record. — Select — until you pick one. Names with a recent send show · recent (sorted to the top).",
        },
        {
          type: "control",
          name: "Their email",
          does: "Addresses already on that customer. Shows only when the customer has at least one email.",
        },
        {
          type: "control",
          name: "Or type email",
          does: "buyer@customer.com box for a new address.",
        },
        {
          type: "control",
          name: "Save",
          does: "Writes that typed address onto the selected customer (primary if they had none; otherwise extras). Needs a customer picked and a valid @ address.",
        },
        {
          type: "control",
          name: "Note on email",
          does: "Paragraph on the letter. Default: Thank you for the opportunity to quote. Lead times confirmed at order. Please reply with PO or questions.",
        },
        {
          type: "control",
          name: "Open formatted email",
          does: "Builds the .eml (Outlook shows the boxes), copies the same letter, logs the send as mailto, and marks that customer last-emailed. Needs a real @ address and at least one quote.",
        },
        {
          type: "control",
          name: "Copy tables",
          does: "Copies the boxed HTML letter (tables match print). Logs as copy. Paste into Outlook / Gmail.",
        },
        {
          type: "control",
          name: "Print",
          does: "Prints the customer preview. Logs as print.",
        },
        {
          type: "control",
          name: "Download HTML",
          does: "Downloads quote-[customer].html — open or attach; matches print layout.",
        },
        {
          type: "control",
          name: "Plain mailto only",
          does: "Last-resort plain-text mail (no tables). Prefer Open formatted email.",
        },
        {
          type: "control",
          name: "Customer preview",
          does: "Subject line plus the letter. This is exactly what print uses — and what Copy formatted puts on the clipboard.",
        },
        {
          type: "control",
          name: "Plain-text fallback (mailto apps that cannot take HTML)",
          does: "Expand to see the dump mailto would send.",
        },
        {
          type: "control",
          name: "Recent sends",
          does: "Last eight log rows: to-address, part numbers, date, method (mailto / copy / print).",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Email today’s quotes to one buyer",
        },
        {
          type: "ol",
          items: [
            "Filter Customer to that shop. Tap Today (or leave Any date).",
            "Select filtered, or check the rows you want. Confirm tooling bill badges — those become extra lines.",
            "Preview & send.",
            "Pick Customer. Pick Their email, or type one and Save.",
            "Edit Note on email if needed.",
            "Open formatted email. Open the .eml download in Outlook. Send from there.",
          ],
        },
        {
          type: "h",
          text: "From Master Quoter",
        },
        {
          type: "ol",
          items: [
            "On Master Quoter, Save the part.",
            "Tap Email. This page opens with that quote checked and the customer filter set.",
            "Preview & send and finish as above.",
          ],
        },
        {
          type: "warn",
          text: "Customer gets part #, rev, qty, price each, and billed tooling — not material %, machine times, or internal shop costs. If a tooling line should not print, uncheck Bill customer on the quoter and Save again.",
        },
      ],
    },
  ],
};
