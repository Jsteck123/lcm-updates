import type { PageHowToDoc } from "./types";

export const dashboardHowTo: PageHowToDoc = {
  id: "dashboard",
  path: "/",
  title: "Shop Dashboard",
  tab: "dashboard",
  whatThisPageIs:
    "The first screen after you open LCM. It is the shop’s morning board: which machines are live, what is paused or overdue, what is in your queue, shop-wide week bonus and average pace, and how your own day is filling. Floor and owner both see the shop pulse (week total + average bonus when the shop is on pace). Customer prices stay office-only. Nothing on this page starts a timer — it only shows the floor and jumps you to the right screen.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "The header shows the company name, who is signed in, whether this is an owner view or a floor view, and today’s date. Numbers on the four tiles tick live every second while a machine timer is running.",
        },
        {
          type: "p",
          text: "The page is role-aware. Everyone sees shop-wide week bonus and average bonus on the pulse cards — only when those numbers are real (never a $0 slap). Customer Orders, Low stock, and Job history only appear if your login is allowed on those tabs. Admin always sees them. Quote prices stay office-only.",
        },
        {
          type: "ul",
          items: [
            "Live machines counts every machine that has a running timer, a pause, or a job loaded.",
            "Needs attention is a ranked list (red first): overdue POs, due-soon POs, material gaps, paused machines, timers over 4 hours, low stock, and a fat machine queue.",
            "Completed today is how many jobs were saved completed on today’s date key.",
            "Signed in is your name. Switch user in the sidebar if it is the wrong person.",
            "Shop pulse is the shop-wide week total (locked days + live on-pace) and the average bonus of people on the clock. The bar is how far through the shift the floor is — not a grade.",
            "Your day is your shift fill and a Possible today dollar only when you are on a bonus pace. A quiet day just says start a timer — it will not flash $0 or “no bonus”.",
            "Floor board is every machine on the list. Tap a row to open that station. A loaded job shows pieces ran / qty, a completion bar, and time remaining. Clock finish only after they tap Good so far. If they have not tapped in a sold cycle the count goes overdue red (same overdue as the rest of the shop) — the number is probably wrong. Due soon is amber when a cycle is almost up. Sold-pace bar can go a little red and hides under 60%.",
            "Assigned queue is work already put on a machine from Customer Orders. Tap a line to jump to that machine.",
          ],
        },
        {
          type: "note",
          text: "Jobs you only took on the Job Board do not show as “live” here until you Load them onto a machine. Use Job board or Active jobs for that.",
        },
        {
          type: "warn",
          text: "If you are signed in as the wrong person, the “My …” tiles and recent runs belong to that name. Use Switch user before you start a shift.",
        },
        {
          type: "p",
          text: "On a brand-new shop (admin, no customer orders, three or fewer completed jobs) a yellow tip tells you to import a PO, switch user, and run a timer. That tip hides once real orders and more completed jobs exist.",
        },
      ],
    },
    {
      title: "Header and jump buttons",
      blocks: [
        {
          type: "control",
          name: "Shop Dashboard",
          does: "Page title. The line under it is company · your name · owner view or floor view · today’s date key.",
        },
        {
          type: "control",
          name: "Shop floor",
          does: "Primary green button. Opens /machines so you can pick a machine, log in, load a part, and run timers. Always shown.",
        },
        {
          type: "control",
          name: "Customer orders",
          does: "Opens /po. Shown only if you are admin or your login has the Customer Orders (po) tab. Hidden for floor people without that tab.",
        },
        {
          type: "control",
          name: "Job board",
          does: "Opens /board so you can take a released line. Shown if you are admin or your login has the Job Board tab. Hidden otherwise.",
        },
        {
          type: "control",
          name: "Active jobs",
          does: "Opens /active — jobs you already loaded on a machine. Shown if you are admin or your login has the Active Jobs tab. Hidden otherwise.",
        },
      ],
    },
    {
      title: "KPI strip",
      blocks: [
        {
          type: "control",
          name: "Live machines",
          does: "Count of machines that are running, paused, or have a job loaded. Hint under the number is how many machines are on the floor list total.",
        },
        {
          type: "control",
          name: "Needs attention",
          does: "How many flags are in the list below (capped at 12). The hint is the first flag title, or “Nothing flagged” when the list is empty. Tile border turns warn/danger when anything is flagged.",
        },
        {
          type: "control",
          name: "Completed today",
          does: "Count of jobs saved as Completed on today’s date key. Hint is how many jobs are still In Progress.",
        },
        {
          type: "control",
          name: "Signed in",
          does: "Your operator name (or “Switch user” if none). Hint reminds you the shop pulse is below. Wrong name? Use Switch user before you start a shift.",
        },
        {
          type: "control",
          name: "Shop pulse",
          does: "Card for the whole shop. Line is quiet / moving / on a bonus pace / running ahead of quote. Shop week is locked weekly payouts plus live on-pace people not yet finalized. Avg bonus is today’s on-pace pool divided by people on the clock. Both money figures hide at $0 — they show a dash and “Fills as days lock” / “First clock starts it” instead. The bar is average shift fill, not efficiency.",
        },
        {
          type: "control",
          name: "Your day",
          does: "Personal card. Shift bar is hours inside the current shift window vs required hours. Possible today only appears when you are on pace (eligible, or ≥85% efficiency with some shift time). A quiet card says “Start a timer — the day fills as you run.” It never shows $0 or “no bonus”.",
        },
        {
          type: "control",
          name: "Today efficiency",
          does: "Removed from the dashboard tiles. Shop pace and your day live on the two pulse cards instead of a failing efficiency number.",
        },
        {
          type: "control",
          name: "Week bonus open",
          does: "Replaced by Shop pulse → Shop week, which everyone can see (when the number is real). Finalize still happens on the machine station under More.",
        },
      ],
    },
    {
      title: "Needs attention list",
      blocks: [
        {
          type: "control",
          name: "Needs attention",
          does: "Card of flags. Admin description: overdue orders, material gaps, paused machines, low stock. Floor description: paused machines, long timers, and work that needs your eyes. Each row is a link.",
        },
        {
          type: "control",
          name: "All clear — no urgent flags right now.",
          does: "Empty state when the list is empty. Green text. No action.",
        },
        {
          type: "control",
          name: "Paused machine row",
          does: "Title is “{machine} paused”. Detail is part number · operator, or “Paused with no part”. Tap opens that machine station.",
        },
        {
          type: "control",
          name: "Timer over 4h row",
          does: "Title is “{machine} timer over 4h”. Detail is timer type, operation, and live time. Tap the station and verify the clock is still supposed to be running.",
        },
        {
          type: "control",
          name: "Overdue PO row",
          does: "Admin / PO-tab only. Red. Title “Overdue PO {number}”. Detail is customer, days past due, open line count. Tap opens Customer Orders.",
        },
        {
          type: "control",
          name: "Due soon row",
          does: "Admin / PO-tab only. Warn. Title “Due soon · {PO}”. Detail is customer, today or N day(s), open lines. Tap opens Customer Orders.",
        },
        {
          type: "control",
          name: "Material needs attention row",
          does: "Admin / PO-tab only. Warn. Title “Material needs attention · {PO}”. Detail is how many lines are unchecked or short. Tap opens Customer Orders.",
        },
        {
          type: "control",
          name: "Low stock",
          does: "Admin or inventory-tab only. Up to six material/part rows. Detail is label · on hand (min). Tap opens Inventory.",
        },
        {
          type: "control",
          name: "items in machine queues",
          does: "Info flag when more than 8 open queue items exist. Detail tells you to check Shop Floor. Tap opens /machines.",
        },
      ],
    },
    {
      title: "Floor board",
      blocks: [
        {
          type: "control",
          name: "Floor board",
          does: "One row per machine on the shop list. Tap the row to open that machine station.",
        },
        {
          type: "control",
          name: "All machines",
          does: "Small link in the card header. Opens Shop Floor (/machines).",
        },
        {
          type: "control",
          name: "Running",
          does: "Badge when that machine has an active timer. Row also shows timer type, operation, and live clock.",
        },
        {
          type: "control",
          name: "Paused",
          does: "Badge (and a yellow Paused tag) when the session is paused. No timer is running.",
        },
        {
          type: "control",
          name: "Loaded",
          does: "Badge when a job is on the machine but the timer is not running and it is not paused.",
        },
        {
          type: "control",
          name: "Idle",
          does: "Badge when the machine has no job, no timer, and is not paused.",
        },
        {
          type: "control",
          name: "No job",
          does: "Shown on an idle or empty session instead of a part number.",
        },
        {
          type: "control",
          name: "Next: OP Setup / Runtime",
          does: "Hint under a busy machine. Tells you the next untimed op, or “All ops complete — save job”, or “No job loaded”.",
        },
      ],
    },
    {
      title: "Customer orders and assigned queue",
      blocks: [
        {
          type: "control",
          name: "Customer orders",
          does: "Card of open POs (not cancelled, complete, or draft), soonest due first, max six. Hidden if you do not have the PO tab.",
        },
        {
          type: "control",
          name: "Open",
          does: "Header link on the Customer orders card. Opens /po.",
        },
        {
          type: "control",
          name: "No open customer orders.",
          does: "Empty state inside the Customer orders card.",
        },
        {
          type: "control",
          name: "Due today",
          does: "Badge on an order row when the due date is today. Other badges: “{n}d late” (red), “{n}d”, or “No due date”. Tap the row to open Customer Orders.",
        },
        {
          type: "control",
          name: "Assigned queue",
          does: "Open work-queue items (max six). Header shows “{n} open”. Each row is part number → machine and a status badge. Tap jumps to that machine.",
        },
        {
          type: "control",
          name: "Nothing assigned to machines yet",
          does: "Empty state. If you have the PO tab it adds “ — assign from Customer Orders.”",
        },
        {
          type: "control",
          name: "active",
          does: "Queue status badge when the item is already started on the machine. Other statuses print as stored (queued, etc.).",
        },
      ],
    },
    {
      title: "Recent runs and low stock",
      blocks: [
        {
          type: "control",
          name: "Recent job runs",
          does: "Admin card title. Last eight jobs shop-wide, newest start first. Hidden if you do not have the Jobs tab.",
        },
        {
          type: "control",
          name: "My recent runs",
          does: "Floor card title (Jobs tab). Same list, filtered to jobs whose operator matches your name.",
        },
        {
          type: "control",
          name: "Job history",
          does: "Header link. Opens /jobs.",
        },
        {
          type: "control",
          name: "No jobs yet.",
          does: "Empty state when the recent list is empty.",
        },
        {
          type: "control",
          name: "Completed",
          does: "Job status badge. Completed rows also show quoted → actual time and a +/- % vs quote plus efficiency.",
        },
        {
          type: "control",
          name: "In Progress",
          does: "Job status badge for a run that was saved without completing.",
        },
        {
          type: "control",
          name: "Low stock",
          does: "Card of materials and finished parts at or below min qty (max eight). Hidden without the Inventory tab. Each row is label + on hand / min.",
        },
        {
          type: "control",
          name: "Inventory",
          does: "Header link on Low stock. Opens /inventory.",
        },
        {
          type: "control",
          name: "All stock above minimums.",
          does: "Empty state when nothing is low.",
        },
      ],
    },
    {
      title: "Owner glance and help (admin / floor)",
      blocks: [
        {
          type: "control",
          name: "Today at a glance (owner)",
          does: "Admin only. Counts open jobs, completed today, queue, and open POs. Hidden on floor logins.",
        },
        {
          type: "control",
          name: "Reports",
          does: "Admin only pill. Opens /reports.",
        },
        {
          type: "control",
          name: "Email quotes",
          does: "Admin only pill. Opens /email.",
        },
        {
          type: "control",
          name: "Settings / backups",
          does: "Admin only pill. Opens /settings.",
        },
        {
          type: "control",
          name: "How to use",
          does: "Admin only pill. Opens the shop help book at /help.",
        },
        {
          type: "control",
          name: "How to use (floor guide)",
          does: "Floor-only link at the bottom. Same /help book, written for the floor screens.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Start the shift from the dashboard",
        },
        {
          type: "ol",
          items: [
            "Confirm the name under Shop Dashboard is you. If not, Switch user.",
            "Scan Needs attention. Tap any paused machine or long timer and deal with it on the station.",
            "Tap Shop floor (or a Floor board row) and load the next job.",
            "Or tap Job board, take a released line, then Load it on a machine.",
          ],
        },
        {
          type: "h",
          text: "Chase an overdue customer order (office / PO tab)",
        },
        {
          type: "ol",
          items: [
            "On Needs attention tap the Overdue PO or Due soon row, or tap Customer orders then Open.",
            "Work the PO: material, release, assign.",
            "Come back here — the flag drops when the order is no longer late or open.",
          ],
        },
        {
          type: "h",
          text: "Check your own runs",
        },
        {
          type: "ol",
          items: [
            "Open My recent runs (or Recent job runs if you are owner).",
            "Tap a row to go to Job history.",
            "Or tap Active jobs to start/stop a timer already on a machine.",
          ],
        },
      ],
    },
  ],
};
