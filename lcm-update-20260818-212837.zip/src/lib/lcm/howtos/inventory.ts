import type { PageHowToDoc } from "./types";

export const inventoryHowTo: PageHowToDoc = {
  id: "inventory",
  path: "/inventory",
  title: "Inventory / Buy",
  tab: "inventory",
  whatThisPageIs:
    "The shop’s stock book. Material on the rack, extra parts and hardware, and the individual barcoded bars that came in on a vendor buy. Shared live across every PC on the shop network. This is not Customer Orders and not Master Quoter — those are customer work. This page is what you have, what you pull, and (office only) what you ask vendors to quote and buy.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "One host PC holds the book. Every station that is unlocked sees the same on-hand, the same pieces, and the same history. If you tap In, Out, Add material, or Receive, the rest of the shop sees it after a moment. Do not keep a private spreadsheet.",
        },
        {
          type: "p",
          text: "The page title is Inventory. The subtitle says material stock and extra parts / hardware, shared across every PC. A help tip next to the title is Scan / issue stock — that tip points you at scanning a barcode sticker and deducting length, which happens on Scan stock, not on this tab’s In / Out buttons.",
        },
        {
          type: "h",
          text: "Three books — do not mix them",
        },
        {
          type: "p",
          text: "LCM keeps three separate lists. They look related. They are not the same number.",
        },
        {
          type: "ul",
          items: [
            "Pending holds (materialHolds) — Inventory → Pending. Spoken-for inches for an open PO line. Book on-hand stays 288; available becomes 226 if 62 is held. Mark OK on the PO or Request cut creates/updates the hold. Installing this update also backfills holds on open POs that were already Mark OK / stock noted / sitting at the saw (not on lines nobody has planned yet). Dwayne’s saw cut (or skip) issues the inches and takes them off Pending. After 30 days the hold asks for Still hold or Release.",
            "Material stock (materialStock) — the Material stock tab and Material on hand table. One row per material + type + shape + size. On hand is the book qty in the Unit you picked (usually inches of stick). Available is book minus pending holds. In, Out, adjust, Add material, Edit, and Delete on that table change this book. History logs those moves.",
            "Barcoded pieces (stockPieces) — the Barcoded pieces tab. One row per physical bar that was created when a vendor PO line was received. Each bar has its own barcode, remaining length, and status. Scan / cut uses these rows. Print labels for Pieces prints these rows.",
            "Parts & hardware (partStock) — the Parts & hardware tab. Finished goods, WIP, bolts, inserts, bought-outs. Separate from raw bar and sheet. Has its own In / Out / adjust and its own UIN (sharpie code) lookup.",
          ],
        },
        {
          type: "warn",
          text: "CRITICAL: Removing barcoded pieces does NOT change Material on hand. The pieces list is a sticker book, not the qty book. Receive on a material buy writes BOTH — it adds on-hand and creates piece rows. Remove / Remove all pieces only deletes the sticker rows. On-hand qty stays. The confirm text says so: “On-hand qty stays.” The audit log says “material on hand unchanged.” If you threw the bars away, you still have to Out or adjust the Material stock line, or the book will lie.",
        },
        {
          type: "note",
          text: "Receiving 21 bars of 4\" × 12 ft Aluminum makes 21 Barcoded pieces rows. Material on hand goes up by the receive qty in that line’s unit. If you later tap Remove on those 21 rows, you still show the metal in Material on hand until you Out or adjust it.",
        },
        {
          type: "h",
          text: "Who sees money tabs",
        },
        {
          type: "p",
          text: "Floor logins see Material stock, Parts & hardware, Barcoded pieces, Order needs, and History. Vendor RFQs and Material buys only show if this login can see money (office / admin). Cost / unit and the Value column also hide on the floor. If you are on the floor and those tabs vanish, that is correct — use Order needs and tell the office.",
        },
        {
          type: "h",
          text: "How qty actually moves",
        },
        {
          type: "ul",
          items: [
            "Add material / Add part writes the starting On hand you typed. That is a starting count, not an In move. Use In after that for receipts you want in History.",
            "In opens receive stock. Adds the Quantity to on-hand. Writes History as receive.",
            "Out opens issue stock. Subtracts Quantity. Refuses if you would go below zero (“Not enough on hand”). Writes History as issue.",
            "The sliders icon opens adjust stock. Default is Set absolute count (checked) so Quantity becomes New on-hand count. Uncheck to add/subtract a signed delta. Writes History as adjust.",
            "Delete stock line? removes the whole row from this book. It does not delete the part from Master Quoter. It does not touch barcoded pieces.",
            "Scan / cut on a piece shortens remaining length on that barcode. That is the pieces book. It is not the same as Out on the Material on hand row.",
            "Receive on a Material buy (admin) adds on-hand and creates barcodes. Then Print last labels.",
          ],
        },
      ],
    },
    {
      title: "Page chrome",
      blocks: [
        {
          type: "p",
          text: "Top of /inventory. Always visible, every tab.",
        },
        {
          type: "control",
          name: "Inventory",
          does: "Page title. The package icon and the Scan / issue stock help tip sit next to it. Tip body: scan a material barcode sticker and enter length/qty used to deduct from inventory — that workflow is Scan stock, not the In / Out buttons on this page.",
        },
        {
          type: "control",
          name: "N low stock",
          does: "Orange hold badge with a warning triangle. Only appears when any Material stock or Parts & hardware line is at or below its min qty (min must be greater than zero). The number is low materials + low parts. It does not count barcoded pieces.",
        },
        {
          type: "control",
          name: "N to order",
          does: "Blue info badge. Count of Order needs rows where Order (toOrder) is greater than zero. Same math as the Order needs tab: min stock + open shop orders + jobs − on hand − material already on order.",
        },
        {
          type: "control",
          name: "Scan stock",
          does: "Opens /scan with an empty barcode. Scan a rack or leftover-bar sticker to see cut-queue jobs that use that material, pick the job, and mark how many you just cut.",
        },
        {
          type: "control",
          name: "Print labels",
          does: "Opens /labels on Materials — one 1.1 × 0.6 DK-2210 sticker per Material stock line that has on-hand greater than zero. Not pieces. Use Barcoded pieces → Print all available labels when you want bar stickers.",
        },
        {
          type: "control",
          name: "Sample label",
          does: "Opens /sample-label. That is where you set the QL-810W Wi-Fi address and fire a test print. Do this once per shop before anyone mashes Print labels.",
        },
        {
          type: "control",
          name: "Shop orders",
          does: "Primary button. Opens /po — customer Purchase Orders (work coming in). Not vendor metal buys. Vendor buys live on Material buys (admin). Same destination as Shop orders on the Material buys tab and Open Purchase Orders to buy on Order needs.",
        },
      ],
    },
    {
      title: "Tabs",
      blocks: [
        {
          type: "p",
          text: "Pill buttons under the header. The active pill is outlined in the shop primary color. Vendor RFQs and Material buys are stripped out when this login cannot see money; if you were on one of those tabs and lose money access, the page dumps you back on Material stock.",
        },
        {
          type: "control",
          name: "Material stock",
          does: "Default tab. Add / Edit material form plus Material on hand table. Book qty is still the rack count. Available is book minus pending holds (288 book · 62 hold · 226 avail). Low / Out uses available.",
        },
        {
          type: "control",
          name: "Pending",
          does: "Spoken-for inches for open jobs. Still hold refreshes the 30-day clock. Release puts those inches back in available without changing book. Saw cut / skip takes the hold off and issues the book.",
        },
        {
          type: "control",
          name: "Parts & hardware",
          does: "partStock book. Add / Edit part form, UIN (sharpie code) lookup, and Parts on hand table. Also shows the page-level Search part #, category, location… box and Low only toggle above the tab body.",
        },
        {
          type: "control",
          name: "Barcoded pieces",
          does: "stockPieces book. Individual bars created when a PO line was received. Removing rows here does not change Material on hand.",
        },
        {
          type: "control",
          name: "Order needs",
          does: "Live “What to order” list. Not a buy. Not a PO. A shopping list the office uses to build Material buys or Shop orders.",
        },
        {
          type: "control",
          name: "Vendor RFQs",
          does: "Admin / money only. Ask vendors for pricing, enter their quotes, award a winner, and turn it into a material buy PO. Customer part quotes stay on Master Quoter.",
        },
        {
          type: "control",
          name: "Material buys",
          does: "Admin / money only. Vendor POs for bar and sheet. Receive creates barcode stickers. Customer POs are Shop orders, not this tab.",
        },
        {
          type: "control",
          name: "History",
          does: "Shared shop log of receive, issue, adjust, scrap, return — last 500 moves on material and part stock. Piece removes do not show here as In / Out; they only write the audit line that on-hand was unchanged.",
        },
      ],
    },
    {
      title: "Material stock — Add / Edit material",
      blocks: [
        {
          type: "p",
          text: "Top card on the Material stock tab. Title flips between Add material stock and Edit material when you tap Edit on a row. Description: track bar, plate, sheet by material + type + size. Set a min qty for reorder warnings.",
        },
        {
          type: "control",
          name: "Clear all",
          does: "Wipes the form back to empty (material, type, shape, size, location, vendor, notes, dims, costs all blank; unit pcs; on hand and min 0) and cancels any edit. Toast: “Material form cleared.” Does not delete stock rows.",
        },
        {
          type: "h",
          text: "Guided material (inventory mode)",
        },
        {
          type: "p",
          text: "Same mill / lathe size picker as jobs, but inventory mode hides LOC (length of cut). You are describing the rack piece, not a saw ticket. Changing material / type / shape / dims rewrites Size on the table via the size note (for example 1.5\" dia). There is no separate Size note box on this form.",
        },
        {
          type: "control",
          name: "Material",
          does: "Creatable dropdown of shop materials (Aluminum, Steel, … plus anything added in Settings lists). Changing material clears Material type. Required — Save / Add material toasts “Material required” if this is blank.",
        },
        {
          type: "control",
          name: "＋ Add new…",
          does: "Last option on Material, Material type, Stock shape, and Vendor. Opens a dialog titled Add material, Add type, Add shape, or Add vendor. Type the new name… then Add & select or Cancel. Add type fails with “Set material first” if Material is empty. New materials and shapes are saved to the shop lists so every station sees them.",
        },
        {
          type: "control",
          name: "Add material",
          does: "Create dialog title when you add a new material name. Confirm with Add & select. Toast: “Added material {name}.”",
        },
        {
          type: "control",
          name: "Material type",
          does: "Grade / type under that material (T6 6061, 304, …). Options narrow to types for the selected Material. Add type saves under that material (“Added {type} under {material}”).",
        },
        {
          type: "control",
          name: "Add type",
          does: "Create dialog for a new grade. Material must already be set.",
        },
        {
          type: "control",
          name: "Stock shape",
          does: "Round Stock, Hex Stock, Square Stock, Rectangular Stock, Plate, Flat Sheet, Round Tube, Square Tube, Rectangular Tube, pipe, etc. Tube shapes switch Size in the machine to OD + wall (rectangular tube is width × height + wall). Those numbers build the size note — 2\" OD × 0.125\" wall, or 2\" × 2\" × 0.125\" wall.",
        },
        {
          type: "control",
          name: "Add shape",
          does: "Create dialog for a new stock shape. Saved to the shop list.",
        },
        {
          type: "control",
          name: "How it sits",
          does: "Two big buttons. Mill — X Y Z in the vise shows three size fields. Lathe — X diameter, Z length hides Y. This only changes how you type the blank; it is not a machine assignment.",
        },
        {
          type: "control",
          name: "Mill — X Y Z in the vise",
          does: "Treat the blank as it sits in a mill. Size labels become X / Y / Z as it sits (or width / length / thickness on sheet).",
        },
        {
          type: "control",
          name: "Lathe — X diameter, Z length",
          does: "Treat the blank as lathe stock. Fields are X · diameter and Z · length of cut (LOC). Y is not used.",
        },
        {
          type: "control",
          name: "Size in the machine",
          does: "Inch fields for the stock blank. Solid bar uses X Y Z as it sits in the mill (or lathe X diameter / Z length). Round Tube and Square Tube are OD + wall. Rectangular Tube is outside width, outside height, and wall. Inventory mode does not show LOC — length of cut or Full bar on the rack.",
        },
        {
          type: "h",
          text: "Qty, location, vendor, cost",
        },
        {
          type: "control",
          name: "Unit (bar stock = inches)",
          does: "Dropdown: in, ft, bar, sheet, pcs, lbs. Bar / rect / round should stay in (inches of stick). The On hand hint says count bar / rect / round in inches of stick. Cost / unit is “what you pay for one of this Unit.”",
        },
        {
          type: "control",
          name: "On hand",
          does: "Starting book qty when you Add material, or the qty you are writing if you Edit and Save. After the line exists, day-to-day receipts and issues should go through In / Out so History has a trail. Number. Hint under the box: Count bar / rect / round in inches of stick.",
        },
        {
          type: "control",
          name: "Min qty (reorder)",
          does: "Reorder point. When On hand is at or below this (and min is greater than 0) the row goes Low, the header can show N low stock, Low only can find it, and Order needs can put a number in Order.",
        },
        {
          type: "control",
          name: "Location",
          does: "Where it lives. Placeholder Rack A-1. Shows in the Material on hand Location column and in search / filter typeaheads.",
        },
        {
          type: "control",
          name: "Vendor",
          does: "Who you buy this stock from. Creatable. Empty option is — Select vendor —. ＋ Add new… opens Add vendor (“Supplier you buy this stock from”). Options come from existing stock, quotes, POs, plus Metal Supermarkets, Ryerson, Online Metals, McMaster-Carr, Local Steel.",
        },
        {
          type: "control",
          name: "Add vendor",
          does: "Create dialog for a new supplier name. Toast: “Vendor {name} ready to save.” The name is stored on this line when you Add material / Save material.",
        },
        {
          type: "control",
          name: "Cost / unit",
          does: "Admin / money only. Money box, placeholder $0.00. What you pay for one of the Unit above (ea, ft, lb…). Stock value on the table = on hand × this. Floor logins do not see this field. On a new (not edit) line, if the price book can compute a unit cost, this box fills itself.",
        },
        {
          type: "control",
          name: "LCM material Calculator",
          does: "Admin / money only box under Cost / unit. Reads the shop price book for this material / type / shape / size. Shows grade, $/lb, lb/ft, and a stock dollars estimate when it has enough size. If the book has the grade but no size, it tells you to add a size (e.g. 3\" dia) so it can compute $/inch. If nothing matches: “Set material, type, shape, and size to estimate from the price book.”",
        },
        {
          type: "control",
          name: "Use as cost / unit",
          does: "Admin / money only. Copies the calculator’s unit cost into Cost / unit. Toast: “Cost / unit set to {label}.” Only shows when the book produced a cost greater than zero.",
        },
        {
          type: "control",
          name: "Notes",
          does: "Free text on the stock line. Searchable. Not printed on the barcode sticker.",
        },
        {
          type: "control",
          name: "Add material",
          does: "Saves a new Material stock row. Requires Material. Parses size from shape + dims + size note (diameter / thickness / width / length). Toast: “Material added.” Form resets. After this, use In for later receipts if you want History.",
        },
        {
          type: "control",
          name: "Save material",
          does: "Same button while editing. Writes over that row (including On hand if you changed it). Toast: “Material updated.”",
        },
        {
          type: "control",
          name: "Cancel edit",
          does: "Only while editing. Drops the edit, clears the form back to a blank Add material stock card. Does not undo a save you already made.",
        },
      ],
    },
    {
      title: "Material on hand",
      blocks: [
        {
          type: "p",
          text: "Second card on Material stock. Title Material on hand (N) or Material on hand (N of Y) when filters hide rows. Description: Filter by column or search — 4×2 finds 2×4. Odd leftover like 1.6\" is the cut (LOC), not the bar.",
        },
        {
          type: "control",
          name: "N filters",
          does: "Blue info badge. How many filter boxes are non-empty, counting search, Material, Type / grade, Shape, Size, Location, Vendor, and Low only. Only shows when at least one is set.",
        },
        {
          type: "control",
          name: "Low only",
          does: "Toggle. On = secondary (filled). Off = outline. Hides every row that is not at or below min qty. Counts as one active filter.",
        },
        {
          type: "control",
          name: "Clear filters",
          does: "Ghost button with an X. Only appears when any filter is active. Resets search, all column filters, and Low only.",
        },
        {
          type: "control",
          name: "Search material, size, location, vendor…",
          does: "Typeahead over labels, sizes, locations, vendors already in stock. Matches the blob of material, type, shape, size, location, vendor, notes, unit. Size-aware: typing .75 finds 3/4\". 4×2×1.6 finds 2×4 — faces can be in any order; the odd leftover is LOC. Empty message: “No matches in stock — keep typing.”",
        },
        {
          type: "control",
          name: "Material",
          does: "Column filter typeahead. Placeholder All materials. Empty: “No material matches.” Changing material clears Type / grade so the type list can narrow.",
        },
        {
          type: "control",
          name: "Type / grade",
          does: "Column filter. Placeholder All types. Options narrow to types that exist on rows matching the Material filter.",
        },
        {
          type: "control",
          name: "Shape",
          does: "Column filter. Placeholder All shapes. Also narrows the Size list when set.",
        },
        {
          type: "control",
          name: "Size",
          does: "Column filter. Placeholder All sizes — try .75 or 3/4\" or 4 x 2. Size-aware match (.75 = 3/4\", 4×2 = 2×4). Odd third number is the cut, not a different bar. List narrows when Material or Shape is set.",
        },
        {
          type: "control",
          name: "Location",
          does: "Column filter. Placeholder All locations.",
        },
        {
          type: "control",
          name: "Vendor",
          does: "Column filter. Placeholder All vendors.",
        },
        {
          type: "h",
          text: "Table columns and row actions",
        },
        {
          type: "control",
          name: "Material",
          does: "Column. Material name, muted type / grade under it, then shape · vendor.",
        },
        {
          type: "control",
          name: "Size",
          does: "Column. The size note, or — if none. Beside it: Print. Opens a dialog: “How many of {size} to print?” Type the count and Print — that many copies of the same rack-size sticker go to the QL-810W. Does not split the inventory line and does not change on-hand. Use this when one row is four 144\" sticks (576\") and you need four labels.",
        },
        {
          type: "control",
          name: "Print",
          does: "Beside Size on each Material on hand row. Opens “Print labels” — How many of {size} to print? Quantity (default 1, max 40, Enter prints). Print sends N copies of that size’s rack sticker to the Brother. Cancel closes. Unlock this PC if it asks. Printer IP is set on Sample label. Does not create barcoded pieces and does not change on-hand.",
        },
        {
          type: "control",
          name: "On hand",
          does: "Column. Qty plus Unit. Turns warning-colored when Low. Badge Out when qty is in the danger band (empty / critically under). Badge Low when at or under min.",
        },
        {
          type: "control",
          name: "Out",
          does: "Danger badge on the On hand cell when the qty status is empty / critically low. Not the Out button — the Out button is in Actions.",
        },
        {
          type: "control",
          name: "Low",
          does: "Hold badge on the On hand cell when the line is at or under min but not empty.",
        },
        {
          type: "control",
          name: "Min",
          does: "Column. The reorder point you set as Min qty (reorder).",
        },
        {
          type: "control",
          name: "Location",
          does: "Column. Rack / bin, or —.",
        },
        {
          type: "control",
          name: "Value",
          does: "Admin / money only column. on hand × Cost / unit, with a small “$X / unit” or “no unit cost” under it. Floor does not see this column.",
        },
        {
          type: "control",
          name: "Actions",
          does: "Column of buttons on every row: In, Out, sliders, Edit, and the delete trash.",
        },
        {
          type: "control",
          name: "In",
          does: "Opens the shared receive stock dialog for this material line. Adds qty to Material on hand. Writes History. Does not create barcoded pieces — pieces only come from Receive on a Material buy.",
        },
        {
          type: "control",
          name: "Out",
          does: "Opens issue stock for this material line. Subtracts qty. Fails with “Not enough on hand” if you overshoot. Writes History. Does not consume a barcode — Scan / cut on a piece does that.",
        },
        {
          type: "control",
          name: "sliders",
          does: "Ghost icon-only button (sliders) after Out. Opens adjust stock. Default is Set absolute count so you type the new rack count. Use this for cycle counts. Writes History as adjust.",
        },
        {
          type: "control",
          name: "Edit",
          does: "Loads this row into the form, retitles it Edit material, scrolls you to Material stock. Change fields, then Save material or Cancel edit. Changing On hand here skips the move dialog — prefer In / Out / sliders if you want a History reason.",
        },
        {
          type: "control",
          name: "Delete material line",
          does: "Trash icon. Title: “Delete this stock line.” Opens Delete stock line? for this material row. Does not delete barcoded pieces and does not delete the material from quoting lists.",
        },
        {
          type: "control",
          name: "No material stock yet — add a line above.",
          does: "Empty table when there are zero material rows at all.",
        },
        {
          type: "control",
          name: "No lines match these filters — clear filters or adjust search.",
          does: "Empty table when rows exist but the current search / column filters hide them all.",
        },
      ],
    },
    {
      title: "Parts & hardware — Add / Edit part",
      blocks: [
        {
          type: "p",
          text: "Above the tab body, only on Parts & hardware: a search box and Low only. Then the Add part / hardware card. Title flips to Edit part / hardware when you tap Edit. Description: finished goods, WIP, bolts, inserts, bought-outs — anything that isn’t raw bar/sheet.",
        },
        {
          type: "control",
          name: "Search part #, category, location…",
          does: "Filters Parts on hand. Matches part label, category, location, notes, vendor. Does not search UINs.",
        },
        {
          type: "control",
          name: "Low only",
          does: "Same idea as Material stock. Only parts at or below min qty. Independent of the material Low only — this one is the parts toggle.",
        },
        {
          type: "control",
          name: "Part number",
          does: "Required. Creatable. Options come from quotes, quote BOM lines, and existing part stock. ＋ Add new… opens New part number. Save / Add part toasts “Part number required” if blank.",
        },
        {
          type: "control",
          name: "New part number",
          does: "Create dialog title when you add a number that is not in the list. Confirm with Add & select.",
        },
        {
          type: "control",
          name: "Revision",
          does: "Rev letter / number. Shows on the table as “rev {revision}” next to the part number.",
        },
        {
          type: "control",
          name: "Category",
          does: "Dropdown: Finished part, Second quality / blemish, WIP / semi-finished, Hardware, Insert / tooling, Bought-out, Fixture, Other. If the category text includes “second” or “blemish”, the table shows a Blemish badge.",
        },
        {
          type: "control",
          name: "Description",
          does: "What it is. Shows under the part number on the table.",
        },
        {
          type: "control",
          name: "Unit",
          does: "in, ft, bar, sheet, pcs, lbs. Hardware is usually pcs.",
        },
        {
          type: "control",
          name: "On hand",
          does: "Starting count on Add part, or the qty you overwrite on Save part. Day-to-day use In / Out after that.",
        },
        {
          type: "control",
          name: "Min qty",
          does: "Reorder point for this part. Drives Low / Out badges, Low only, and the header N low stock count.",
        },
        {
          type: "control",
          name: "Location",
          does: "Bin / shelf for this part line.",
        },
        {
          type: "control",
          name: "Vendor",
          does: "Creatable. — Select vendor —. Add vendor hint: “Who you buy this part / hardware from.” Same vendor list as material.",
        },
        {
          type: "control",
          name: "Cost / unit",
          does: "Admin / money only. Your cost for one unit (not sell price). Value = on hand × this. Placeholder $0.00.",
        },
        {
          type: "control",
          name: "Notes",
          does: "Free text. On the table, notes under Category print in warning color (use this for blemish / second-quality write-ups).",
        },
        {
          type: "control",
          name: "Add part",
          does: "Saves a new partStock row. Toast: “Part added.” Form clears.",
        },
        {
          type: "control",
          name: "Save part",
          does: "Writes the edit. Toast: “Part updated.”",
        },
        {
          type: "control",
          name: "Cancel edit",
          does: "Drops the edit and returns the card to Add part / hardware.",
        },
      ],
    },
    {
      title: "Look up part by UIN (sharpie code)",
      blocks: [
        {
          type: "p",
          text: "Middle card on Parts & hardware. Read the short code written on the part, type it here to see defect notes and quality before you use or ship it.",
        },
        {
          type: "control",
          name: "e.g. K7M2",
          does: "UIN box. Mono, uppercase as you type. Enter runs the same lookup as Look up. Clears the last hit when you edit. Toast if missing: “No part found for that UIN.”",
        },
        {
          type: "control",
          name: "Look up",
          does: "Finds the PartUnit for that UIN. Shows the big code, part number, Rev, Good or Second quality badge, status, defect note or “No defect note on file.”, and Location: {bin} if set.",
        },
        {
          type: "control",
          name: "Good",
          does: "Green badge when quality is not second. Second quality is the warn badge instead.",
        },
        {
          type: "control",
          name: "Second quality",
          does: "Warn badge. The whole hit card also gets a warn border. Read Defect / note before you ship it as good.",
        },
        {
          type: "control",
          name: "Mark issued / used",
          does: "Only when status is available. Calls issue with reason “Pulled from shelf.” Toast: “UIN {code} marked issued.” Button then hides because status is issued. Does not change the Parts on hand qty by itself — Out the part line if the book qty should drop.",
        },
        {
          type: "control",
          name: "Available UINs on shelf (N)",
          does: "Chip list of up to 40 available UINs. Second-quality chips are warn-colored. Tap a chip to fill the box and show that hit. Hidden when none are available.",
        },
      ],
    },
    {
      title: "Parts on hand",
      blocks: [
        {
          type: "p",
          text: "Bottom card. Title Parts on hand (N) — N is after Search / Low only.",
        },
        {
          type: "control",
          name: "Part",
          does: "Column. Part number, muted “rev {revision}”, description underneath (or —).",
        },
        {
          type: "control",
          name: "Category",
          does: "Column. Category name, optional Blemish badge, then notes in warning color if present.",
        },
        {
          type: "control",
          name: "Blemish",
          does: "Hold badge when Category contains “second” or “blemish.”",
        },
        {
          type: "control",
          name: "On hand",
          does: "Qty + unit, with Out / Low badges the same way as material.",
        },
        {
          type: "control",
          name: "Min",
          does: "Reorder point.",
        },
        {
          type: "control",
          name: "Location",
          does: "Bin, or —.",
        },
        {
          type: "control",
          name: "Value",
          does: "Admin / money only. on hand × cost, or “no unit cost.”",
        },
        {
          type: "control",
          name: "In",
          does: "receive stock on this part line. Adds to partStock on-hand. History.",
        },
        {
          type: "control",
          name: "Out",
          does: "issue stock on this part line. Subtracts. “Not enough on hand” if you overshoot.",
        },
        {
          type: "control",
          name: "sliders",
          does: "adjust stock on this part line. Same dialog as material.",
        },
        {
          type: "control",
          name: "Edit",
          does: "Loads the part into Edit part / hardware.",
        },
        {
          type: "control",
          name: "Delete part line",
          does: "Trash. Title “Delete this stock line.” Opens Delete stock line? for this part. Does not delete the part from Master Quoter.",
        },
        {
          type: "control",
          name: "No parts inventory yet — add a line above.",
          does: "Empty table. Also shows when Search / Low only hide every row.",
        },
      ],
    },
    {
      title: "Barcoded pieces",
      blocks: [
        {
          type: "p",
          text: "These are individual bars created when a PO line was received — one barcode per bar, so you can scan and cut length. They are not your Material on hand list. Receiving 21 of 4\" × 12 ft Aluminum made these 21 rows. Removing them does not change Material on hand.",
        },
        {
          type: "control",
          name: "Barcoded pieces (N)",
          does: "Card title. N is how many piece rows exist, every status.",
        },
        {
          type: "control",
          name: "Print all available labels",
          does: "Opens /labels with kind=pieces and no id filter — every piece whose status is available. Not consumed / gone bars.",
        },
        {
          type: "control",
          name: "Remove all pieces",
          does: "Danger underline. Only if there is at least one piece. Flips to a confirm: “Remove all N pieces? On-hand qty stays.” plus Yes, remove all and Cancel.",
        },
        {
          type: "control",
          name: "Yes, remove all",
          does: "Deletes every piece row. Toast: “Removed N barcoded pieces.” Material on hand does not move. Audit: “Removed N barcoded pieces (material on hand unchanged).”",
        },
        {
          type: "control",
          name: "Cancel",
          does: "Backs out of Remove all pieces. Pieces stay.",
        },
        {
          type: "control",
          name: "Barcode",
          does: "Column. Mono code printed on the sticker and encoded in the QR.",
        },
        {
          type: "control",
          name: "Material",
          does: "Column. Material + type, size note underneath.",
        },
        {
          type: "control",
          name: "Remaining",
          does: "Column. remainingLength\" / originalLength\". Scan / cut lowers remaining. This is not Material on hand.",
        },
        {
          type: "control",
          name: "Location",
          does: "Column. Where that bar was put when received (Receive on a buy stamps Receiving unless you change it later).",
        },
        {
          type: "control",
          name: "Status",
          does: "Badge. available is green. Anything else (consumed, etc.) is neutral. Print all available labels only prints available.",
        },
        {
          type: "control",
          name: "Scan / cut",
          does: "Opens /scan with this leftover-bar barcode filled. Matching cut-queue jobs are listed. Pick the job and enter how many you just cut. Remaining length on this bar drops.",
        },
        {
          type: "control",
          name: "Label",
          does: "Opens /labels with just this piece id so you can reprint one sticker.",
        },
        {
          type: "control",
          name: "Remove",
          does: "Deletes this one piece row. Toast: “Removed {barcode}.” On-hand stays. Use this when the sticker book is wrong (duplicate, scrap bar already Out on the material line, test barcode). If the metal is gone, also Out the Material stock line.",
        },
        {
          type: "control",
          name: "No barcoded pieces — receive a PO line to create them.",
          does: "Empty table. You cannot type a piece in here. Go to Material buys (admin) → Receive, or have the office receive the vendor PO.",
        },
      ],
    },
    {
      title: "Order needs",
      blocks: [
        {
          type: "p",
          text: "Card title What to order. Live: min stock + open shop orders + jobs − on hand − material buys. Add lines from Purchase Orders. This tab does not buy anything.",
        },
        {
          type: "control",
          name: "Material",
          does: "Column. Material + type, then shape · first few demand sources (job / order names).",
        },
        {
          type: "control",
          name: "On hand",
          does: "Current Material stock qty for that match.",
        },
        {
          type: "control",
          name: "Min",
          does: "Min qty from the stock line.",
        },
        {
          type: "control",
          name: "Job demand",
          does: "What open jobs / shop orders still need.",
        },
        {
          type: "control",
          name: "On order",
          does: "Already on a material buy (vendor PO) and not yet received.",
        },
        {
          type: "control",
          name: "Order",
          does: "What is still short (toOrder). Warning-colored. The header N to order badge counts rows where this is greater than zero.",
        },
        {
          type: "control",
          name: "Stock covers current demand.",
          does: "Empty table. Nothing to buy for min + jobs right now.",
        },
        {
          type: "control",
          name: "Open Purchase Orders to buy",
          does: "Link to /po (customer Shop orders). Office also uses Material buys to actually order bar from a vendor. This link does not create a vendor PO.",
        },
      ],
    },
    {
      title: "Vendor RFQs (admin)",
      blocks: [
        {
          type: "p",
          text: "Money / admin only. Card: Vendor RFQs (material quotes). Ask vendors for pricing with your RFQ # → enter their quotes → pick a winner → turn it into a material buy PO. Customer part quotes stay on Master Quoter. After award, open the Material buys tab to receive and print labels.",
        },
        {
          type: "control",
          name: "New RFQ",
          does: "Creates an RFQ with one starter line (Aluminum / T6 6061). Selects it. Toast: “Created {RFQ-number}.”",
        },
        {
          type: "control",
          name: "RFQ list",
          does: "Left list of every vendor RFQ. Each row shows the RFQ number, a status badge (draft / sent / quoted / awarded), and “N bid(s).” Tap to select. Empty: “No RFQs yet. Create one when you need material pricing.”",
        },
        {
          type: "control",
          name: "draft / sent / quoted / awarded",
          does: "Status badge on the list. awarded is green, quoted info, sent warn, draft neutral. Awarded RFQs cannot be deleted from the trash on the header.",
        },
        {
          type: "control",
          name: "Select or create an RFQ",
          does: "Right-card title when nothing is selected. Once selected, the title is the RFQ number, plus “Status: … · linked material PO created” after award.",
        },
        {
          type: "control",
          name: "trash",
          does: "Ghost trash on the RFQ header. Hidden once awarded. Browser confirm: “Delete {RFQ-number}?” Then the RFQ is gone.",
        },
        {
          type: "control",
          name: "Date",
          does: "RFQ date. Saves as you change it.",
        },
        {
          type: "control",
          name: "Needed by",
          does: "When you need the metal. Date.",
        },
        {
          type: "control",
          name: "Customer quote ref (optional)",
          does: "Part # / quote batch so the vendor RFQ ties back to a customer quote. Placeholder: Part # / quote batch.",
        },
        {
          type: "control",
          name: "Shop order / job ref (optional)",
          does: "PO-26-… or job. Placeholder: PO-26-… or job.",
        },
        {
          type: "control",
          name: "Vendors to request",
          does: "Multi-select. Placeholder: Select one or more vendors…. Type to filter, add a new vendor name anytime. Hint: Multi-select · type to filter · add a new vendor name anytime. Names also come from prior RFQs and Metal Supermarkets / Ryerson / Online Metals / McMaster-Carr / Local Steel.",
        },
        {
          type: "control",
          name: "Notes to vendors",
          does: "Text area. Goes on the RFQ email body.",
        },
        {
          type: "control",
          name: "Lines to quote",
          does: "Section of material lines on this RFQ.",
        },
        {
          type: "control",
          name: "Line",
          does: "Adds another empty material line.",
        },
        {
          type: "control",
          name: "Material",
          does: "Typeahead on a line. Changing it clears Type. Placeholder Aluminum.",
        },
        {
          type: "control",
          name: "Type",
          does: "Typeahead of grades for that material. Placeholder T6 6061.",
        },
        {
          type: "control",
          name: "Shape",
          does: "Typeahead of stock shapes.",
        },
        {
          type: "control",
          name: "Size note",
          does: "Typeahead of catalog sizes for that material / type / shape. Placeholder: Type to filter — e.g. 1.5 or 12 ft.",
        },
        {
          type: "control",
          name: "Guide",
          does: "Opens Stock for RFQ line — the guided material dialog. Hint: Same mill / lathe layout. LOC is length of cut — the saw axis (model 3 inch, cut 3.1). Writes material, type, shape, size note, and Length each back onto the line. Close or Done to dismiss.",
        },
        {
          type: "control",
          name: "Qty",
          does: "How many of this line you want quoted.",
        },
        {
          type: "control",
          name: "Unit",
          does: "in, ft, bar, sheet, pcs, lbs.",
        },
        {
          type: "control",
          name: "Length each (in)",
          does: "Inches per piece. Guide can fill this from LOC.",
        },
        {
          type: "control",
          name: "Part # (optional)",
          does: "If this metal is for a known part number.",
        },
        {
          type: "control",
          name: "Remove line",
          does: "Drops that line. Refuses if it is the last one: “Keep at least one line.”",
        },
        {
          type: "control",
          name: "Email RFQ to vendor",
          does: "Opens a mailto with subject “{Company} Material RFQ {number}” and the RFQ body (so vendors put that number on the reply). If the body is too long for mailto it copies to the clipboard: “RFQ body copied — paste into email (too long for mailto).” Draft RFQs flip to sent.",
        },
        {
          type: "control",
          name: "Mark sent",
          does: "Sets status to sent if it was draft. Needs at least one line with Material. Toast: “RFQ marked sent — enter vendor bids when they reply.”",
        },
        {
          type: "h",
          text: "Enter vendor quote (bid)",
        },
        {
          type: "p",
          text: "Hidden after the RFQ is awarded. One card per RFQ for typing a vendor’s reply.",
        },
        {
          type: "control",
          name: "Vendor",
          does: "Who quoted. Typeahead. Placeholder: Who quoted?",
        },
        {
          type: "control",
          name: "Their quote #",
          does: "Vendor’s number. Placeholder: Vendor Q-…",
        },
        {
          type: "control",
          name: "$/unit · {material} {size}",
          does: "One money box per RFQ line. Enter what that vendor wants per unit. Placeholder 0.00.",
        },
        {
          type: "control",
          name: "Freight $",
          does: "Freight dollars on this bid.",
        },
        {
          type: "control",
          name: "Bid notes",
          does: "Lead time, mill cert, etc.",
        },
        {
          type: "control",
          name: "Save vendor bid",
          does: "Stores the bid on this RFQ. Toast: “Bid from {vendor} saved.” Clears the bid form. Then it shows under Bids received.",
        },
        {
          type: "control",
          name: "Bids received",
          does: "Each bid shows vendor, their #, status badge (open / accepted / rejected), total dollars (mat + frt), and notes. Empty: “No bids yet — wait for vendor replies, then enter them above.”",
        },
        {
          type: "control",
          name: "Accept → create PO",
          does: "Only on an open bid while the RFQ is not awarded. Awards that vendor, creates a Material buy PO. Toast: “Awarded to {vendor} · material PO {number} created. Open Material buys to receive.” Winner card says: “Winner — open Material buys tab to receive stock & print labels.”",
        },
        {
          type: "control",
          name: "Stock for RFQ line",
          does: "Guided dialog from Guide. Buttons Close and Done. Same material / type / shape / How it sits / size fields as Add material, plus LOC because this dialog is not inventory-mode.",
        },
        {
          type: "control",
          name: "Close",
          does: "Closes Stock for RFQ line without an extra save — changes already patched as you typed.",
        },
        {
          type: "control",
          name: "Done",
          does: "Closes Stock for RFQ line (same as Close unless a caller passed onDone).",
        },
      ],
    },
    {
      title: "Material buys (admin)",
      blocks: [
        {
          type: "p",
          text: "Money / admin only. Buy bar/sheet from vendors. Receive creates barcode stickers. Shop customer POs live under Shop Orders.",
        },
        {
          type: "control",
          name: "New material buy",
          does: "Creates a vendor PO, status ordered, no lines. Selects it. Toast: “Material buy {PO-number}.”",
        },
        {
          type: "control",
          name: "Print last labels (N)",
          does: "Only after a successful Receive & barcodes on this session. Opens /labels with those new piece ids so you can print the stickers you just made.",
        },
        {
          type: "control",
          name: "Shop orders",
          does: "Link to /po — customer work, not this vendor buy list.",
        },
        {
          type: "control",
          name: "Buy list",
          does: "Left list. Each row is PO number, vendor or —, and status. Tap to select. Empty: “No material buys yet.”",
        },
        {
          type: "control",
          name: "Select a buy",
          does: "Right-card title when nothing is selected. Otherwise the PO number.",
        },
        {
          type: "control",
          name: "Vendor",
          does: "Who you ordered from. Saves as you type.",
        },
        {
          type: "control",
          name: "Status",
          does: "draft, ordered, partial, received, cancelled. You set this by hand — Receive does not auto-flip it for you on this panel.",
        },
        {
          type: "control",
          name: "Add line",
          does: "Appends a starter line: Aluminum, T6 6061, Round Stock, unit in, qty 1, length each 144, nothing received yet. Then edit Material / Type / Size note / Qty.",
        },
        {
          type: "control",
          name: "Material",
          does: "Free text on the line. Placeholder Material.",
        },
        {
          type: "control",
          name: "Type",
          does: "Free text. Placeholder Type.",
        },
        {
          type: "control",
          name: "Size note",
          does: "Free text. Placeholder Size note. This is what prints on the piece sticker size line after Receive.",
        },
        {
          type: "control",
          name: "Qty",
          does: "qtyOrdered. Next to it: “recv {received}/{ordered}.”",
        },
        {
          type: "control",
          name: "Receive",
          does: "Opens Receive material for the open qty (ordered − received). Disabled when nothing is left to receive. Prefills the qty box with the open qty.",
        },
        {
          type: "note",
          text: "If Order needs has shorts, a tip under the lines says: short materials show under Order needs — add lines here, then receive for barcodes.",
        },
        {
          type: "h",
          text: "Receive material dialog",
        },
        {
          type: "control",
          name: "Receive material",
          does: "Dialog title. Subtitle is “{material} {type} · open {N}.” Clicking the dark backdrop cancels.",
        },
        {
          type: "control",
          name: "qty (receive)",
          does: "Number of bars / units to receive right now. Defaults to the open qty. Location is stamped Receiving.",
        },
        {
          type: "control",
          name: "Cancel",
          does: "Closes Receive material without writing stock.",
        },
        {
          type: "control",
          name: "Receive & barcodes",
          does: "Calls receive on that PO line. Adds Material on hand AND creates one stockPieces row (barcode) per unit received. Toast: “Received · N barcodes.” Then Print last labels (N) appears. This is the only shop path that creates barcoded pieces.",
        },
      ],
    },
    {
      title: "History",
      blocks: [
        {
          type: "p",
          text: "Card: Inventory history. Receive, issue, adjust, scrap — last 500 moves (shared shop log). This is materialStock and partStock only.",
        },
        {
          type: "control",
          name: "When",
          does: "When the move was written.",
        },
        {
          type: "control",
          name: "Kind",
          does: "receive / issue / adjust / scrap / return, plus a small material or part tag.",
        },
        {
          type: "control",
          name: "Item",
          does: "The material or part label at the time of the move.",
        },
        {
          type: "control",
          name: "Qty",
          does: "How much moved. On an absolute adjust this is the delta (new − old).",
        },
        {
          type: "control",
          name: "Balance",
          does: "On-hand after the move.",
        },
        {
          type: "control",
          name: "By / note",
          does: "Who (signed-in email), Reason / note, and Reference if they filled those on the dialog.",
        },
        {
          type: "control",
          name: "No inventory moves yet. Use In / Out on a stock line.",
          does: "Empty history. Add material / Add part starting qty does not write a row here. Piece Remove does not write a row here.",
        },
      ],
    },
    {
      title: "In / Out / adjust dialog",
      blocks: [
        {
          type: "p",
          text: "Same dialog for material and parts. Title is receive stock, issue stock, or adjust stock (capitalized). The line label sits under the title. Backdrop click is Cancel.",
        },
        {
          type: "control",
          name: "Quantity",
          does: "How much to add (In / receive), subtract (Out / issue), or — when adjust is not absolute — the signed delta. Enter confirms. Must be greater than zero for In / Out. Absolute adjust uses New on-hand count instead.",
        },
        {
          type: "control",
          name: "New on-hand count",
          does: "Label on the same box when kind is adjust and Set absolute count is checked. Type what the rack actually is. The move stores the delta in History.",
        },
        {
          type: "control",
          name: "Set absolute count (unchecked = add/subtract)",
          does: "Only on adjust. Checked by default when you open sliders. Checked = Quantity is the new on-hand. Unchecked = Quantity is a signed add/subtract (negative allowed).",
        },
        {
          type: "control",
          name: "Reason / note",
          does: "Why. Placeholder: PO #, job, scrap, etc. Shows in History under By / note.",
        },
        {
          type: "control",
          name: "Reference (optional)",
          does: "Job or PO number. Placeholder: Job or PO. Also shows in History.",
        },
        {
          type: "control",
          name: "Cancel",
          does: "Closes without writing. On-hand stays.",
        },
        {
          type: "control",
          name: "Confirm",
          does: "Writes the move. Toast: “{kind} · balance {n} · {label}.” Errors: “Invalid quantity”, “Quantity must be greater than zero”, “Not enough on hand”, “Material not found” / “Part not found.” Enter in the qty box is the same as Confirm.",
        },
      ],
    },
    {
      title: "Delete stock line dialog",
      blocks: [
        {
          type: "control",
          name: "Delete stock line?",
          does: "Title. Body: Remove {label} from inventory. This does not delete the part from Master Quoter — only this stock row. Backdrop click cancels.",
        },
        {
          type: "control",
          name: "Cancel",
          does: "Keep the row.",
        },
        {
          type: "control",
          name: "Delete",
          does: "Removes the materialStock or partStock row. Toast: “Deleted {label}.” Barcoded pieces for that material stay until you Remove them on Barcoded pieces. History does not get an In / Out row for the delete.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Put a new size on the rack (starting count)",
        },
        {
          type: "ol",
          items: [
            "Open Inventory → Material stock.",
            "If the form says Edit material, tap Cancel edit or Clear all.",
            "Set Material, Material type, Stock shape, How it sits, and Size in the machine.",
            "Set Unit (bar stock = inches) to in for bar / round / rect. Type On hand in inches of stick. Set Min qty (reorder) and Location (Rack A-1).",
            "Office: fill Cost / unit or tap Use as cost / unit from LCM material Calculator.",
            "Tap Add material. You should see the row in Material on hand. This starting qty is not a History receive — later receipts use In or Material buys → Receive.",
          ],
        },
        {
          type: "h",
          text: "Receive more of a size already on the book (no new barcodes)",
        },
        {
          type: "ol",
          items: [
            "Material stock → find the line (search or Size filter; .75 finds 3/4\").",
            "Tap In.",
            "Type Quantity, Reason / note (PO #), optional Reference.",
            "Confirm. History shows receive. Barcoded pieces do not gain rows — only Material buys → Receive & barcodes does that.",
          ],
        },
        {
          type: "h",
          text: "Issue metal from the book (no barcode)",
        },
        {
          type: "ol",
          items: [
            "Material stock → Out on that line.",
            "Type Quantity (inches of stick if Unit is in), Reason / note (job), Reference.",
            "Confirm. If you would go negative you get “Not enough on hand.”",
            "If you also cut a barcoded bar, do Scan / cut on that piece separately. Out here does not shorten Remaining on the piece.",
          ],
        },
        {
          type: "h",
          text: "Cycle count (set the rack to what you counted)",
        },
        {
          type: "ol",
          items: [
            "On the material or part row tap the sliders icon.",
            "Leave Set absolute count (unchecked = add/subtract) checked.",
            "Type the New on-hand count — what is actually on the rack, not the delta.",
            "Reason / note: “cycle count” or the sheet number. Confirm.",
            "History shows adjust and the new Balance.",
          ],
        },
        {
          type: "h",
          text: "Fix a wrong material row",
        },
        {
          type: "ol",
          items: [
            "Tap Edit. The top card becomes Edit material.",
            "Change type, size, location, vendor, cost. Prefer sliders / In / Out for qty so History has a reason.",
            "Save material, or Cancel edit to throw away the form.",
          ],
        },
        {
          type: "h",
          text: "Delete a stock line",
        },
        {
          type: "ol",
          items: [
            "Trash (Delete material line or Delete part line).",
            "Read Delete stock line? — only this row, not Master Quoter.",
            "Delete. If barcodes still exist for that metal, go to Barcoded pieces and Remove them too. Removing pieces will not fix on-hand; deleting the line is what drops the book qty.",
          ],
        },
        {
          type: "h",
          text: "Find one size in a long rack list",
        },
        {
          type: "ol",
          items: [
            "On Material on hand type in Search material, size, location, vendor… or set Material / Type / grade / Shape / Size.",
            "Size understands .75 and 3/4\" as the same.",
            "Low only if you only want shorts. Badge N filters shows how many boxes are live. Clear filters when you are done.",
          ],
        },
        {
          type: "h",
          text: "Add hardware or a finished part",
        },
        {
          type: "ol",
          items: [
            "Parts & hardware.",
            "Part number (or New part number → Add & select), Revision, Category, Description, Unit, On hand, Min qty, Location, Vendor.",
            "If it is a second, pick Second quality / blemish so the table shows Blemish, and write the defect in Notes.",
            "Add part. Use In / Out after that.",
          ],
        },
        {
          type: "h",
          text: "Read a sharpie UIN before you ship or use it",
        },
        {
          type: "ol",
          items: [
            "Parts & hardware → Look up part by UIN (sharpie code).",
            "Type the code (K7M2) or tap it under Available UINs on shelf. Look up (or Enter).",
            "Read Good vs Second quality and Defect / note.",
            "If you are taking it, tap Mark issued / used. Then Out the Parts on hand line if the book qty should drop.",
          ],
        },
        {
          type: "h",
          text: "Office: quote vendors, award, receive bars, print stickers",
        },
        {
          type: "ol",
          items: [
            "Vendor RFQs → New RFQ. Fill Needed by, Vendors to request, Notes to vendors.",
            "On each line set Material, Type, Shape, Size note (or Guide). Qty, Unit, Length each (in).",
            "Email RFQ to vendor (or Mark sent if you already sent it outside the app).",
            "When a quote comes back: Enter vendor quote (bid) → Vendor, Their quote #, $/unit, Freight $, Save vendor bid. Repeat per vendor.",
            "On the winner tap Accept → create PO. Open Material buys. That PO is selected.",
            "Check Vendor / lines. Receive → qty → Receive & barcodes.",
            "Print last labels (N), or Barcoded pieces → Print all available labels. Stand at the QL-810W. Unlock this PC if it asks. IP is set on Sample label.",
          ],
        },
        {
          type: "h",
          text: "Office: skip RFQ, just buy and receive",
        },
        {
          type: "ol",
          items: [
            "Material buys → New material buy.",
            "Vendor, Status (usually ordered), Add line, edit Material / Type / Size note / Qty.",
            "When the truck shows: Receive → Receive & barcodes.",
            "Print last labels. Put stickers on the bars. Move Location later if they leave Receiving.",
          ],
        },
        {
          type: "h",
          text: "Reprint one bar sticker or scan-cut a bar",
        },
        {
          type: "ol",
          items: [
            "Barcoded pieces. Find the barcode.",
            "Label reprints one sticker. Scan / cut opens Scan stock with that code.",
            "Do not tap Remove unless the sticker row is junk. Remove does not Out the metal.",
          ],
        },
        {
          type: "h",
          text: "Clean out leftover piece rows without lying about on-hand",
        },
        {
          type: "ol",
          items: [
            "Barcoded pieces → Remove on one row, or Remove all pieces → Yes, remove all.",
            "Read the confirm: On-hand qty stays.",
            "If the metal is actually gone, Material stock → Out or sliders on those sizes. Otherwise the book still thinks the steel is there.",
          ],
        },
        {
          type: "h",
          text: "See what the shop still needs to buy",
        },
        {
          type: "ol",
          items: [
            "Order needs. Rows with a warning Order number are short.",
            "Header badge N to order is the same count.",
            "Floor: tell the office. Office: add lines on Material buys (or Open Purchase Orders to buy for customer-side work).",
          ],
        },
        {
          type: "warn",
          text: "Never treat Barcoded pieces as the qty book. Never treat Material on hand as a list of stickers. In / Out / sliders / Delete change on-hand. Receive & barcodes writes both books. Remove / Remove all pieces / Yes, remove all only delete stickers. Scan / cut only shortens a barcode’s Remaining.",
        },
      ],
    },
  ],
};
