import type { PageHowToDoc } from "./types";

export const sawHowTo: PageHowToDoc = {
  id: "saw",
  path: "/saw",
  title: "Saw / Cut queue",
  tab: "saw",
  whatThisPageIs:
    "The saw’s work list. Every Request cut from the Job Board lands here as a ticket with CAD sizes, material, qty, who asked, and which machine wants the blanks. Scan a bar on the ground to see only the jobs that use that material. You mark pieces as they come off so mills can start before the full qty is cut.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "Tickets sort soonest due first, then newest request. Active hides cancelled / skipped / fully done tickets. All shows every ticket including history. Scanning a rack or leftover-bar sticker filters the list to jobs that use that material. Other label kinds have their own instructions and will not filter this queue.",
        },
        {
          type: "ul",
          items: [
            "Qty is progressive: Cut N / requested. Available = cut minus claimed by machines. Left to cut = requested minus cut.",
            "Mills claim blanks on the machine station (Claim 1 blank). That raises claimed and lowers available — it does not change qty cut.",
            "Mark cut adds to qty cut under your signed-in name. All remaining marks the rest of the ticket done in one tap.",
            "Skip saw / on hand is for bar already cut or on the rack — the ticket closes without more saw time.",
          ],
        },
        {
          type: "note",
          text: "No tickets yet? After you take a job on the board, use Request cut to send sizes here.",
        },
        {
          type: "warn",
          text: "Print list needs pop-ups. If the sheet does not open, allow pop-ups for this shop site and tap Print list again.",
        },
      ],
    },
    {
      title: "Header",
      blocks: [
        {
          type: "control",
          name: "Saw / Cut queue",
          does: "Page title. Subtitle: scan a bar on the ground to see every job in this queue that uses that material.",
        },
        {
          type: "control",
          name: "Shop pulse strip",
          does: "Under the title. Shop week when the shop is on pace, plus your day line and shift bar. Same strip as Shop Floor, Job Board, and Active Jobs.",
        },
        {
          type: "control",
          name: "Print list",
          does: "Opens a printable sheet of the tickets currently shown (Active or All, same sort, after any scan filter). Errors “Allow pop-ups to print” if the window is blocked.",
        },
        {
          type: "control",
          name: "Job board",
          does: "Link back to /board so you can open Request cut on a taken job.",
        },
        {
          type: "control",
          name: "Scan material on the ground",
          does: "Type or scan a rack (LCMM) or leftover-bar (LCM) sticker. The list filters to jobs that use that material. Clear removes the filter. Unknown stickers do not filter — they have their own instructions.",
        },
        {
          type: "control",
          name: "Active",
          does: "Filter pill (default). Only tickets still in play — not cancelled, skipped, or fully done.",
        },
        {
          type: "control",
          name: "All",
          does: "Filter pill. Entire ticket history including cancelled, skipped, and All cut.",
        },
        {
          type: "control",
          name: "No cut tickets yet. After you take a job on the board, use Request cut to send sizes to the saw.",
          does: "Empty state when the current filter has no tickets. After a scan: “No open cut tickets use this material.”",
        },
      ],
    },
    {
      title: "Ticket card",
      blocks: [
        {
          type: "control",
          name: "Part / Rev / customer / PO / due / machine",
          does: "Header identity. “for {machine}” is the machine stored when the floor requested the cut.",
        },
        {
          type: "control",
          name: "Waiting on saw",
          does: "Status badge for a new ticket (nothing cut yet).",
        },
        {
          type: "control",
          name: "Saw cutting",
          does: "Status badge while the ticket is in a cutting state.",
        },
        {
          type: "control",
          name: "Partial ready",
          does: "Status badge when some qty is cut but not all. Mills can already claim.",
        },
        {
          type: "control",
          name: "All cut",
          does: "Status badge when qty cut meets qty requested.",
        },
        {
          type: "control",
          name: "Skip saw / on hand",
          does: "Status badge after someone skipped the saw because stock was already on hand. Also the name of the button that does that (see below).",
        },
        {
          type: "control",
          name: "Cancelled",
          does: "Status badge after Cancel ticket. No more mark-cut.",
        },
        {
          type: "control",
          name: "Material",
          does: "Material, type, and stock shape from the request.",
        },
        {
          type: "control",
          name: "Cut size",
          does: "The cut label (Ø × LOC or LOC axis=… · X/Y/Z). Under it: Lathe or Mill · requested by {name}.",
        },
        {
          type: "control",
          name: "Qty",
          does: "Cut {cut} / {requested}. Under it: available · claimed · left to cut.",
        },
        {
          type: "control",
          name: "Notes",
          does: "Optional saw notes from Request cut. Hidden when empty.",
        },
      ],
    },
    {
      title: "Ticket actions",
      blocks: [
        {
          type: "control",
          name: "Mark cut qty",
          does: "Number field (default 1). How many blanks you just cut. Hidden when the ticket is cancelled, skipped, or nothing is left to cut.",
        },
        {
          type: "control",
          name: "Mark cut",
          does: "Adds Mark cut qty to the ticket under your name. Toast: Cut +N · now cut/requested · available for machine. Resets the qty box to 1. Hidden with the qty field.",
        },
        {
          type: "control",
          name: "Scan bar for this cut",
          does: "Opens Scan stock with this ticket already picked. Scan the rack sticker (LCMM) or leftover bar (LCM). Cut length and leftover qty are on screen. Enter how many you just cut.",
        },
        {
          type: "control",
          name: "All remaining",
          does: "Marks every leftover piece cut in one tap. Toast: All remaining cut · cut/requested. Hidden with the qty field.",
        },
        {
          type: "control",
          name: "Skip saw / on hand",
          does: "Button (same label as the skipped badge). Closes the ticket without more cutting — stock already exists. Hidden when status is already skipped, cancelled, or All cut.",
        },
        {
          type: "control",
          name: "Cancel ticket",
          does: "Voids the ticket. Hidden once already cancelled. Use this for a wrong size or a duplicate request — not for “we already have bar”.",
        },
        {
          type: "control",
          name: "Write size to quote",
          does: "Shown when status is All cut or Partial ready and the size has not been written back yet. Copies actual cut size onto the matching quote recipe. Prices stay put. Errors “No matching quote” if none exists.",
        },
        {
          type: "control",
          name: "Size written to quote",
          does: "Read-only note after a successful write-back. Replaces Write size to quote.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Scan a bar, pick the job, mark the cut",
        },
        {
          type: "ol",
          items: [
            "Scan the sticker on the bar in Scan material on the ground (or phone-camera the QR — that opens Scan stock with the same job list).",
            "Confirm the list is only jobs that use that material.",
            "Open the job. Read Cut size and leftover qty.",
            "Set Mark cut qty and tap Mark cut, or tap Scan bar for this cut and enter how many on the scan page.",
            "Repeat until left to cut is 0, or tap All remaining when the last pieces are done.",
            "Mills can Claim 1 blank on the machine as soon as available > 0.",
          ],
        },
        {
          type: "h",
          text: "Stock is already on the rack",
        },
        {
          type: "ol",
          items: [
            "Open the ticket.",
            "Tap Skip saw / on hand.",
            "Do not Cancel ticket — cancel means the request was wrong, not that you used existing bar.",
          ],
        },
        {
          type: "h",
          text: "Print a saw list for the bench",
        },
        {
          type: "ol",
          items: [
            "Pick Active (today’s work) or All.",
            "Tap Print list.",
            "If nothing opens, allow pop-ups and tap Print list again.",
          ],
        },
        {
          type: "h",
          text: "Put the real size on the recipe",
        },
        {
          type: "ol",
          items: [
            "When the ticket is Partial ready or All cut, tap Write size to quote.",
            "Quoted prices do not change. Only the size fields update.",
          ],
        },
      ],
    },
  ],
};
