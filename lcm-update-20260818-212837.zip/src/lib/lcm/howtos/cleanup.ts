import type { PageHowToDoc } from "./types";

export const cleanupHowTo: PageHowToDoc = {
  id: "cleanup",
  path: "/cleanup",
  title: "Beta cleanup desk",
  audience: "admin",
  tab: "settings",
  whatThisPageIs:
    "Practice clocks, TEST jobs, and half-packed POs are normal while the shop is in beta. This desk lists them so you can close or correct each one. Nothing is deleted — jobs, quotes, and POs stay in history. Admin-only. Opened from Settings → Beta cleanup desk.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "The desk scans open clocks, open pauses, machines still loaded, leftover settings, packed-but-open POs, over-complete lines, duplicate saw tickets, STARTED leftover cells, TEST jobs still in averages, stale bonus rows, and odd / practice quotes. Each row has one action: close, unload, unpack, cap qty, cancel a ticket, exclude from averages, zero a stale bonus, or flag a quote. It never removes the record.",
        },
        {
          type: "warn",
          text: "Nothing is deleted. Apply selected / Apply all / Apply on a row only run those close-or-correct actions. A success toast says Applied N cleanup action(s). Nothing was deleted.",
        },
        {
          type: "note",
          text: "Non-admins see Admin only — Switch to James or Pam to review leftover beta data. Nothing here deletes records.",
        },
      ],
    },
    {
      title: "Desk controls",
      blocks: [
        {
          type: "control",
          name: "Beta cleanup desk",
          does: "Page title under Settings · go-live.",
        },
        {
          type: "control",
          name: "N items to review",
          does: "How many leftover rows the scan found. Tick what you want to clean, then apply. Or apply one row at a time.",
        },
        {
          type: "control",
          name: "Apply selected (N)",
          does: "Runs the action on every ticked row. Disabled until you tick at least one. Pick one or more rows first if you tap with none checked.",
        },
        {
          type: "control",
          name: "Apply all N",
          does: "Runs every action on the desk. Use when you have read the list and mean to clear the whole leftover pile.",
        },
        {
          type: "control",
          name: "Back to Settings",
          does: "Returns to Settings. The desk is still there next time until leftovers are gone.",
        },
        {
          type: "control",
          name: "Select group",
          does: "Ticks every row in that kind (Open clocks, TEST jobs, …).",
        },
        {
          type: "control",
          name: "Unselect group",
          does: "Clears the ticks in that kind.",
        },
        {
          type: "control",
          name: "Why this matters",
          does: "Expands the why text for that leftover so you know what Apply will do.",
        },
        {
          type: "control",
          name: "Apply",
          does: "Runs that one row’s action only.",
        },
      ],
    },
    {
      title: "Groups you may see",
      blocks: [
        {
          type: "control",
          name: "Open clocks",
          does: "A timer or operator time log still running. Apply closes the clock. The job stays.",
        },
        {
          type: "control",
          name: "Open pauses",
          does: "Downtime / pause with no end. Apply closes it.",
        },
        {
          type: "control",
          name: "Machines still loaded",
          does: "A session or active timer still on a machine. Apply unloads / clears the timer. The PO line is not deleted.",
        },
        {
          type: "control",
          name: "Settings to reset",
          does: "Average-run setting left in a practice state. Apply writes the recommended value. Does not wipe Settings.",
        },
        {
          type: "control",
          name: "Packed but not finished",
          does: "A PO looks packed while lines are still open. Apply unpacks so the board / calendar match reality. The order stays.",
        },
        {
          type: "control",
          name: "Qty completed over ordered",
          does: "Completed qty above the PO line. Apply caps the line qty. History of the run stays.",
        },
        {
          type: "control",
          name: "Duplicate saw tickets",
          does: "Extra cut tickets for the same need. Apply cancels the duplicate. The good ticket stays.",
        },
        {
          type: "control",
          name: "STARTED leftover cells",
          does: "A STARTED leftover on a job cell. Apply clears the leftover flag. The job stays.",
        },
        {
          type: "control",
          name: "TEST jobs in averages",
          does: "Practice part numbers still feeding shop averages (TEST, TEST-0293…, not real Sat-Lite TEST-0143-01 parts). Apply excludes them from averages. The job row stays in Job History.",
        },
        {
          type: "control",
          name: "Stale bonus %",
          does: "A bonus row that should not pay. Apply zeros it. The day record stays.",
        },
        {
          type: "control",
          name: "Odd / practice quotes",
          does: "Empty / one-letter / botched-import quotes (e.g. PN 3 customer 2). Apply flags them for office — it does not delete the quote. Delete part is on Master Quoter if you truly want it gone.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Go-live sweep (nothing deleted)",
        },
        {
          type: "ol",
          items: [
            "Settings → Open cleanup desk (or sidebar path /cleanup).",
            "Read each group. Expand Why this matters on anything you do not recognize.",
            "Tick the leftovers you accept, or Select group on a kind you have reviewed.",
            "Apply selected, or Apply on one row if you want to go slow.",
            "Empty desk: Nothing leftover. Clocks are closed, TEST jobs are out of averages, and packed orders match completed qty.",
          ],
        },
        {
          type: "warn",
          text: "This is not Reset demo data and not Restore. Those wipe or roll back the whole shop. Cleanup only closes leftover practice state.",
        },
      ],
    },
  ],
};
