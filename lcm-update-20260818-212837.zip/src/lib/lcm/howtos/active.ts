import type { PageHowToDoc } from "./types";

export const activeJobsHowTo: PageHowToDoc = {
  id: "active-jobs",
  path: "/active",
  title: "My Active Jobs",
  tab: "active",
  whatThisPageIs:
    "A live list of jobs you already loaded on a machine, under your name. Each card is one machine: part, rev, qty, customer, and the clock. You can jump to the station or Start / Stop the smart timer from here. Taking a job on the Job Board does not put it here — you must Load it first.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "The page filters every machine on the floor list to sessions whose operator is you (the signed-in name). The clocks tick every second. Status color matches the rest of the shop: live, paused, or just loaded.",
        },
        {
          type: "ul",
          items: [
            "One card per machine you have a job on — including a nest pair sitting on that machine. Pieces ran / qty and the completion bar update as they tap Good so far. That tap is a refresh. If they skip a sold cycle the count goes overdue red on this card too — office and floor both see the number is probably wrong. Clock finish only after a tap.",
            "Start uses the same smart start as the station: next untimed Setup or Runtime for that job.",
            "Stop uses the same smart stop. If the runtime needs a completed qty, you are sent to the machine to enter it.",
            "Open machine always goes to that station so you can pause, save, view the print, or finish.",
          ],
        },
        {
          type: "note",
          text: "Jobs you took on the Job Board stay on the board until you Load them. This page is only loaded sessions.",
        },
        {
          type: "warn",
          text: "Start and Stop here still belong to the machine. If someone else is standing at that station, talk to them before you hit Start from your phone.",
        },
        {
          type: "p",
          text: "This is not the Job Board and not Shop Floor. Board = take a released line. Floor = every machine. Active = only your loaded jobs, with Start / Stop in reach.",
        },
      ],
    },
    {
      title: "Page chrome",
      blocks: [
        {
          type: "control",
          name: "My Active Jobs",
          does: "Page title. Subtitle names you and reminds you that Job Board takes stay on the board until you Load them.",
        },
        {
          type: "control",
          name: "Shop pulse strip",
          does: "Under the title. Shop week when the shop is on pace, plus your day line and shift bar. Same strip as Shop Floor, Job Board, and Saw.",
        },
        {
          type: "control",
          name: "No jobs running. Load one of My Jobs from the Job Board onto a machine and it will show here.",
          does: "Empty state when none of your sessions have a loaded job. No cards, no buttons. Switch user if you expected to see work under a different name.",
        },
      ],
    },
    {
      title: "Job card",
      blocks: [
        {
          type: "control",
          name: "Machine name",
          does: "Card title (factory icon + machine). This is the station Open machine will open.",
        },
        {
          type: "control",
          name: "Live",
          does: "Badge when a timer is running on that machine. The timer strip below shows type · op · live time.",
        },
        {
          type: "control",
          name: "Paused",
          does: "Badge when the session is paused. Timer is off. Resume from the station (or Start if smart start allows).",
        },
        {
          type: "control",
          name: "Loaded",
          does: "Badge when a job is on the machine, timer off, not paused.",
        },
        {
          type: "control",
          name: "Part / Rev / Qty",
          does: "Session part number, revision, quantity, and customer. This is what is actually loaded — not just taken on the board.",
        },
        {
          type: "control",
          name: "Timer off",
          does: "Timer strip text when no clock is running. When a clock is running it reads “{Setup|Runtime} · {OPn} · {time}”.",
        },
        {
          type: "control",
          name: "Open machine",
          does: "Opens the machine station for that card. Use this for pause, print, save, jaws, notes, extras, or finish. Start / Stop on this page will not open Units completed here — Stop sends you to the station when qty is required.",
        },
        {
          type: "control",
          name: "Start",
          does: "Shown when no timer is running. Smart-starts the next Setup or Runtime on that machine. Toast shows the start message or an error (no operator, no job, already running, etc.). Hidden while Live.",
        },
        {
          type: "control",
          name: "Stop",
          does: "Shown while Live. Smart-stops the current timer. If the stop needs a completed qty, toast says “Enter completed qty on the machine” and you are sent to the station (Units completed). Hidden when the timer is off.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Get a job onto this page",
        },
        {
          type: "ol",
          items: [
            "On Job Board tap Take job (or take from the machine queue on Shop Floor).",
            "Pick the machine and tap Load (board) or Load (queue).",
            "Come back to My Active Jobs — the machine card is here.",
          ],
        },
        {
          type: "h",
          text: "Run the next op from your phone",
        },
        {
          type: "ol",
          items: [
            "Find the machine card.",
            "If the badge is Loaded or Paused, tap Start.",
            "When the cut / setup is done, tap Stop.",
            "If it asks for qty, finish Units completed on the station.",
          ],
        },
        {
          type: "h",
          text: "Go do the full station work",
        },
        {
          type: "ol",
          items: [
            "Tap Open machine.",
            "Use You / Load / Stock / Jaws / Work / Done on the station — pause, print, save, extras.",
          ],
        },
        {
          type: "h",
          text: "You have two machines going",
        },
        {
          type: "ol",
          items: [
            "Both cards stay on this page as long as you are the operator.",
            "Start / Stop the one that is actually cutting. Use Open machine on the other to pause or save.",
            "The station header also chips your other loaded machines so you can hop without coming back here.",
          ],
        },
      ],
    },
  ],
};
