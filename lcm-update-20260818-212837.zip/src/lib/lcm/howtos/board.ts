import type { PageHowToDoc } from "./types";

export const jobBoardHowTo: PageHowToDoc = {
  id: "job-board",
  path: "/board",
  title: "Job Board",
  tab: "board",
  whatThisPageIs:
    "The floor’s take-a-job wall. Every released customer-order line (and each assembly component) is a card, soonest due first. You take one job (or a nest pair), pick a machine at the top, Load it onto that machine, request a saw cut if you need blanks, and mark the line done when the qty is finished. Cards that are not released stay on Hold until the office checks PDF rev and stock. This page does not run timers — Load jumps you to the machine station for that.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "Soonest due first. Assemblies: take component jobs (-02, -03…) first, finish each qty, then take the assembly job (-01) to bolt together and pack. A card is one PO line or one component of a line — not the whole PO. A quote that runs on two or more machines (OP1 lathe, OP2 mill, OP3 lathe) becomes one card per remaining OP. Gayle still takes a 3-op mill job as one card.",
        },
        {
          type: "ul",
          items: [
            "Soft tints match the rest of the shop: Hold, Open, Due soon, Overdue, My Job.",
            "The pulse strip under the title is shop week + your day (hidden when you print a WO or label).",
            "A card is not released until the office checks PDF rev + stock on Customer Orders. Unreleased cards cannot be taken.",
            "Take job checks the line out to your signed-in name. Nobody else should run it until you Return job or Done.",
            "Load puts that part on the machine you picked in Machine (optional) — or the machine already stored on the checkout — then opens the station.",
            "If that part is already loaded on a machine, the card shows pieces ran / qty, a completion bar, and time remaining. Clock finish only after Good so far taps. Count uses the same shop colors: overdue red if they have not tapped in a quoted cycle (do not trust that number — it says Stale — last updated … ago), due soon when a cycle is almost up. Pace under 60% of quoted hides the time bar. Behind pace says a little behind quoted.",
            "Request cut opens Request saw cut and sends sizes to Saw / Cut queue.",
          ],
        },
        {
          type: "note",
          text: "Jobs you take stay on this board under My Jobs until you Return job or mark them done. They do not appear on My Active Jobs until you press Load.",
        },
        {
          type: "warn",
          text: "Load will refuse if you did not pick a machine, if that machine already has a different part loaded, or if a timer is running for a different part. Stop the other timer first.",
        },
        {
          type: "p",
          text: "Shop WO hides the board and prints only the work-order sheet. Allow the browser print dialog. Box labels print from Ship Calendar → Mark packed, not from this card.",
        },
      ],
    },
    {
      title: "Legend badges",
      blocks: [
        {
          type: "control",
          name: "Hold",
          does: "Legend and card badge. Line is not released (office has not checked PDF rev + stock), or an assembly is waiting on components (“Wait components”). You cannot Take job until it is Open.",
        },
        {
          type: "control",
          name: "Open",
          does: "Released, nobody has it, not due soon. Ready to take.",
        },
        {
          type: "control",
          name: "Due soon",
          does: "Released and the due date is close. Card also reads “Open · due soon”.",
        },
        {
          type: "control",
          name: "Overdue",
          does: "Released and past due. Card also reads “Open · overdue”. Take these first unless the office says otherwise.",
        },
        {
          type: "control",
          name: "My Job",
          does: "You have this card checked out. It rings so you can find it. Other people’s checkouts dim and show their name instead of Open.",
        },
        {
          type: "control",
          name: "OP1 / OP2 / OP3",
          does: "On a multi-machine card. That card is only this operation. Take / Load / Return / Done apply to this OP, not the whole part. Quoted machine chip shows where the quote says it runs.",
        },
        {
          type: "control",
          name: "Wait OP2",
          does: "Previous timed OP is not marked done. You can still Take and Load (set up is allowed). The badge is a warning, not a lock.",
        },
        {
          type: "control",
          name: "Component",
          does: "This card is a child part of an assembly. Finish its qty, then Done component, then take the next component or the assembly.",
        },
        {
          type: "control",
          name: "Assembly",
          does: "Parent job. May show “Wait components” and a Waiting on: list until every child qty is done.",
        },
        {
          type: "control",
          name: "Wait components",
          does: "Badge on an unreleased assembly that still needs child parts. Take the component cards first.",
        },
      ],
    },
    {
      title: "Filters",
      blocks: [
        {
          type: "control",
          name: "All Jobs",
          does: "Every board card (released or not, yours or not). Default when an office / admin login opens the board.",
        },
        {
          type: "control",
          name: "Available Jobs",
          does: "Only released cards nobody has checked out. This is the take pile.",
        },
        {
          type: "control",
          name: "My Jobs",
          does: "Only cards checked out to your signed-in name. Default when a floor operator opens the board. Use this when you are ready to Load, Request cut, or Done.",
        },
        {
          type: "control",
          name: "Machine (optional)",
          does: "Pick the machine you will run. Stored on Take job and used by Load / Load pair / Request cut. If you already took the job, Load uses the checkout machine if one was saved, otherwise this picker. Empty means Load will error “Pick a machine at the top, then Load”.",
        },
        {
          type: "control",
          name: "All POs",
          does: "PO filter. Default is every open PO. Other options are “{PO} · due {date} · {customer} · {n} left”. Narrows the board to that order, still soonest due first.",
        },
        {
          type: "control",
          name: "line(s)",
          does: "Count of cards after filters. Adds “on this PO · soonest due first” when a PO is selected, otherwise reminds you lines are “not released until office checks PDF rev + stock”.",
        },
      ],
    },
    {
      title: "Card body (not buttons)",
      blocks: [
        {
          type: "control",
          name: "PO number + due + customer",
          does: "Header of every card. Due date and customer sit under the PO.",
        },
        {
          type: "control",
          name: "Part number / Rev",
          does: "The job you will load. Description, qty, material, type, and size note sit under it. Assemblies may list Waiting on: child part numbers.",
        },
        {
          type: "control",
          name: "✓ PDF rev / ○ PDF rev",
          does: "Office checked the drawing revision (check) or not (circle). Unchecked lines stay on Hold.",
        },
        {
          type: "control",
          name: "✓ Stock / ○ Stock",
          does: "Office noted stock (check) or not. Needed for release.",
        },
        {
          type: "control",
          name: "✂ cut status",
          does: "If a saw ticket exists: status label, qtyCut/qtyRequested, and how many blanks are ready. Comes from Request cut / the saw page.",
        },
        {
          type: "control",
          name: "✓ CAD / ○ CAD",
          does: "Shown when CAD files are attached. Multi-file shows ×N.",
        },
        {
          type: "control",
          name: "No lines on the board. Import POs, confirm rev/stock on Customer Orders, then lines appear here.",
          does: "Empty state when filters match nothing (or the shop has no released lines).",
        },
      ],
    },
    {
      title: "Card actions",
      blocks: [
        {
          type: "control",
          name: "Take job",
          does: "Shown when the card is released and not checked out. Checks this card (this OP, or the whole part) out to you and stores the machine. On a split card, only that OP is yours — the mill OP stays on the board for the mill person. Toast includes the OP label when present. Errors if someone else already has this OP.",
        },
        {
          type: "control",
          name: "Take pair · {sibling part}",
          does: "Shown next to Take job only when the shop recognizes a nest mate that is also released and free on this board, and this card is not a split OP. Hidden on lathe/mill OP cards.",
        },
        {
          type: "control",
          name: "Load",
          does: "Shown only on your checked-out cards. Sets you as operator on the target machine (quoted machine, checkout machine, or the picker at the top) and loads this part. On a split card, the machine clock only runs that OP. If the previous OP is not done, a toast warns “usually waits on OPn — you can still set up.” Then opens the machine station.",
        },
        {
          type: "control",
          name: "Load pair",
          does: "Shown on your card when a pair hint exists. Loads this part and the nest mate onto the same machine with one clock. Same machine-picker rules as Load.",
        },
        {
          type: "control",
          name: "Request cut",
          does: "Shown on your cards. Opens Request saw cut once. After any ticket exists (requested, cutting, partial, done, or skipped) the button greys out: Cut requested, Cut done, or Cut skipped. Cancelled tickets do not lock it — those are gone from the queue.",
        },
        {
          type: "control",
          name: "Return job",
          does: "Shown on your cards. Puts the card back on Available Jobs and clears the desk assign for that OP / line. Load Lanes drop those hours as soon as you return it. Does not unload a machine (Clear on the station if it is still loaded).",
        },
        {
          type: "control",
          name: "Done OP2",
          does: "On a split card. Marks that OP complete. The card leaves. Other OPs stay. The last remaining OP also finishes the component (Done component) or sends the line to pack (Done → pack).",
        },
        {
          type: "control",
          name: "Done component",
          does: "Shown on your component cards. Marks that child qty complete so the assembly can move. Toast tells you to take the next component or the assembly. Errors if the line cannot be marked ready.",
        },
        {
          type: "control",
          name: "Done → pack",
          does: "Shown on your non-component cards (regular line or assembly). Marks the line ready for pack so shipping can take it. Errors if it cannot be marked ready.",
        },
        {
          type: "control",
          name: "Shop WO",
          does: "Always on the card. Prints the shop work-order sheet for this PO line. Browser print dialog.",
        },
        {
          type: "control",
          name: "Drawing",
          does: "Opens the attached drawing. If several drawings exist the buttons read Draw 1, Draw 2, …. Errors “No drawing” if the file is missing.",
        },
        {
          type: "control",
          name: "CAD",
          does: "Opens an attached CAD file. Multiple files read CAD 1, CAD 2, …. Hidden when no CAD is attached. Errors “No CAD” if the file is missing.",
        },
        {
          type: "control",
          name: "Open full PO",
          does: "Opens Customer Orders on this exact PO (not the first order in the list) and expands this line.",
        },
        {
          type: "control",
          name: "Release",
          does: "Editor mode only (admin with editor mode on). Puts a checked-out / messy card back on the board as open. Confirms first. Hidden for everyone else.",
        },
        {
          type: "control",
          name: "Remove",
          does: "Editor mode only. Pulls the line off the board and queues. The customer PO stays; you can assign it again from Customer Orders. Confirms first. Hidden for everyone else.",
        },
      ],
    },
    {
      title: "Request saw cut dialog",
      blocks: [
        {
          type: "p",
          text: "Opens from Request cut. Title is Request saw cut. Subtitle is part · rev — type CAD actuals. X / Y / Z / LOC start blank (quote size is not filled in). Shop sync will not snap numbers back. Tap a number field to highlight all so you can just type. On the rack lists matching Material on hand; the best fit is marked suggested.",
        },
        {
          type: "control",
          name: "Process",
          does: "Dropdown: “Mill (X / Y / Z · pick LOC axis)”, “Lathe (diameter + LOC)”, or “Other”. Switching to Lathe forces LOC axis to diameter; leaving Lathe puts axis back on Z if it was dia.",
        },
        {
          type: "control",
          name: "Diameter",
          does: "Lathe only. Stock diameter in inches.",
        },
        {
          type: "control",
          name: "LOC (length of cut)",
          does: "Lathe only. How long the saw cut is, in inches.",
        },
        {
          type: "control",
          name: "X / Y / Z",
          does: "Mill / Other. The three stock-blank sizes in inches as the part sits.",
        },
        {
          type: "control",
          name: "LOC is which axis?",
          does: "Mill / Other. Three buttons X, Y, Z. None selected at open — pick the saw axis. That axis copies into LOC value when the dim is > 0.",
        },
        {
          type: "control",
          name: "On the rack",
          does: "Only sizes close to what you typed (same or up to ½\" over, order does not matter). Empty until you type a size. Suggested is the best fit.",
        },
        {
          type: "control",
          name: "LOC value (from {axis}, editable)",
          does: "Mill / Other. The cut length, prefilled from the chosen axis, still editable (model 3\" → cut 3.1\").",
        },
        {
          type: "control",
          name: "Qty to cut",
          does: "How many blanks the saw should cut. Defaults from the line qty.",
        },
        {
          type: "control",
          name: "Notes for saw",
          does: "Free text to the saw (leave stock for face, grain, etc.).",
        },
        {
          type: "control",
          name: "When cut is done, write actual size back to quote recipe",
          does: "Checkbox. Size only — never changes quoted prices. Off by default.",
        },
        {
          type: "control",
          name: "Preview",
          does: "Read-only cut label (Ø × LOC or LOC axis=…) and qty so you can catch a bad number before you send.",
        },
        {
          type: "control",
          name: "Send to saw",
          does: "Creates the cut ticket and closes. Ticket shows on Saw / Cut queue and on the board card as ✂ status. Errors if the ticket cannot be created.",
        },
        {
          type: "control",
          name: "Cancel",
          does: "Closes Request saw cut without sending. Clicking the dark backdrop does the same.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Take a regular line and run it",
        },
        {
          type: "ol",
          items: [
            "Set the filter to Available Jobs (or All Jobs).",
            "Pick the machine in Machine (optional).",
            "On the card tap Take job.",
            "Tap Load. The station for that machine opens with the part loaded.",
            "Run Setup then Runtime on the station. When the qty is done, come back here (My Jobs) and tap Done → pack.",
          ],
        },
        {
          type: "h",
          text: "Take a nest pair",
        },
        {
          type: "ol",
          items: [
            "If Take pair · {sibling} is showing, tap it so both cards are yours.",
            "Pick the machine, then tap Load pair (or Load on one card after both are yours).",
            "On the station, one clock runs both parts. Mark good pieces on both.",
          ],
        },
        {
          type: "h",
          text: "Assembly: components first",
        },
        {
          type: "ol",
          items: [
            "Take each Component card, Load, run, then Done component.",
            "When Waiting on: is gone, take the Assembly card.",
            "Bolt together, then Done → pack.",
          ],
        },
        {
          type: "h",
          text: "Send blanks to the saw",
        },
        {
          type: "ol",
          items: [
            "Take the job (or already have it under My Jobs).",
            "Tap Request cut.",
            "Set Process, sizes / LOC, Qty to cut, Notes for saw.",
            "Tap Send to saw.",
            "Saw uses Saw / Cut queue. Your card shows ✂ status and ready count.",
          ],
        },
        {
          type: "h",
          text: "Give the job back",
        },
        {
          type: "ol",
          items: [
            "Open My Jobs.",
            "Tap Return job. The card goes back to Available Jobs.",
          ],
        },
        {
          type: "h",
          text: "Print a traveler",
        },
        {
          type: "ol",
          items: [
            "Tap Shop WO for the shop work order.",
            "Use the browser print dialog. Close it to return to the board.",
            "Box labels print automatically when shipping taps Mark packed on the calendar.",
          ],
        },
      ],
    },
  ],
};
