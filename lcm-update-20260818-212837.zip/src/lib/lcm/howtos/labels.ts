import type { PageHowToDoc } from "./types";

export const labelsHowTo: PageHowToDoc = {
  id: "labels",
  path: "/labels",
  title: "Stock barcode labels",
  tab: "inventory",
  whatThisPageIs:
    "Print rack stickers on the Brother QL-810W. Tape is DK-2210 1.1 × 0.6 in continuous. The app draws the sticker and sends it over Wi-Fi to the printer. Not Windows Print. Not Paint. Not Edge. Not USB. One sticker is a QR (scan URL) plus the barcode text, material line, and a short size like (4\") or (2\" x 4\"). Cuts land on the 0.6\" sides of the QR.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "Open from Inventory → Print labels, from Barcoded pieces → Print all available labels or Label, or from Material buys → Print last labels after a receive. The URL remembers kind (materials or pieces) and optional ids.",
        },
        {
          type: "h",
          text: "Tape and printer — read this once",
        },
        {
          type: "ul",
          items: [
            "DK-2210 1.1 × 0.6 in continuous tape in the QL-810W. Windows paper name is “1.1 x 0.6.” Lid clicked shut.",
            "Printer on shop Wi-Fi, same network as the host PC. LCM talks to the QL by IP. USB is not used.",
            "Set that IP on Sample barcode label (Inventory → Sample label). This page does not have an IP box — it reads the saved address. Empty IP toasts: “Set the QL-810W Wi-Fi address on the sample label page first.”",
            "This PC must be unlocked (PIN). No token toasts: “Unlock this PC first, then print again.” and opens the unlock prompt. Host error if still locked: “Unlock this PC first (Switch user / PIN).”",
            "Do not File → Print this page. Do not paste a PNG into Paint or Edge and print. Those wreck the size and the cut. Tap Print N labels and let the host send raster over Wi-Fi.",
          ],
        },
        {
          type: "h",
          text: "What is on the sticker",
        },
        {
          type: "p",
          text: "QR first (scans to the shop scan URL for that code), then the barcode text, then line 1 (material + type), then line 2 (short size). The draw is 0.6\" wide so the QR fills the tape width. The host rotates the bitmap so the printer feed / cut is the 0.6\" sides of the QR — you get a cut on each side of the QR, text stacked under it along the 1.1\" direction.",
        },
        {
          type: "h",
          text: "Size line — short on purpose",
        },
        {
          type: "ul",
          items: [
            "Round / hex / “dia”: (4\") — no word “dia”, no 12 ft.",
            "Square: (2\" x 2\").",
            "Rect / plate / tube / anything with two sizes: (2\" x 4\").",
            "A trailing feet / long number is dropped so 1.5\" dia x 12 ft does not print the 144\".",
            "Materials kind builds line 2 from size note + stock shape. Pieces kind does the same from the piece.",
          ],
        },
        {
          type: "h",
          text: "Materials vs Pieces",
        },
        {
          type: "p",
          text: "Two different books. Materials prints one sticker per Material stock line with on-hand greater than zero. The barcode is a generated LCMM… code for that stock id — it is not a per-bar serial. Pieces prints individual received bars (their real barcode). Empty ids on Pieces means every available piece. ids=… (from Label or Print last labels) means only those piece ids / barcodes.",
        },
        {
          type: "warn",
          text: "Printing Materials does not create barcoded pieces. Printing Pieces does not change Material on hand. If you have no piece rows, receive a Material buy line first, or print from Materials for rack-size stickers.",
        },
        {
          type: "note",
          text: "Previews are tiny on screen (0.6 in wide) so you can see they drew. Wait until the gray empty boxes become stickers. Print before they finish toasts “Wait for barcodes to finish drawing.”",
        },
      ],
    },
    {
      title: "Page chrome",
      blocks: [
        {
          type: "control",
          name: "Stock barcode labels",
          does: "Page title. Under it: “One 1.1 × 0.6 sticker per material on hand (N).” on Materials, or “Barcoded pieces (N).” on Pieces, then “Size prints as (4\") or (2\" x 4\").”",
        },
        {
          type: "control",
          name: "Materials",
          does: "Switches to kind=materials, no id filter. One job per Material stock row with onHand > 0. Line 1 is material + type. Line 2 is the short size. Barcode is LCMM + stock id (max 18). Active link is dark and underlined.",
        },
        {
          type: "control",
          name: "Pieces",
          does: "Switches to kind=pieces, no id filter. Every stock piece with status available. If you arrived with ids in the URL (Label, Print last labels), those ids stay until you tap Pieces (which clears ids) or Materials. Active when you are on pieces.",
        },
        {
          type: "control",
          name: "Print N labels",
          does: "Sends every job on the sheet to the QL-810W, one after another, over Wi-Fi. Disabled when busy or when there are zero jobs. While sending the label is Sending…. Success: “N label(s) sent to {ip}.” Stops on the first failure and shows the printer / unlock error. Requires PIN unlock and a saved QL IP.",
        },
        {
          type: "control",
          name: "Sending…",
          does: "Same button while the host is pushing rasters. Do not mash it. Do not keep sending if the QL light is blinking — tape, lid, or jam.",
        },
        {
          type: "control",
          name: "Test print",
          does: "Opens /sample-label. Set the QL-810W Wi-Fi address there and fire one known sticker (LCM-SAMPLE-01) before a big Materials run.",
        },
        {
          type: "control",
          name: "No material on hand to label.",
          does: "Empty state on Materials. Add qty on Inventory → Material stock (or In / Receive) so on-hand is greater than zero.",
        },
        {
          type: "control",
          name: "No barcoded pieces. Receive a PO line, or print from Materials.",
          does: "Empty state on Pieces when there are no matching piece rows. Office: Material buys → Receive & barcodes. Or tap Materials for rack-size stickers.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "One-time: tape, Wi-Fi, PIN, sample",
        },
        {
          type: "ol",
          items: [
            "Load DK-2210 1.1 × 0.6 continuous in the QL-810W. Close the lid until it clicks. Printer on shop Wi-Fi.",
            "Unlock this PC (Switch user / PIN) so the host will accept print jobs.",
            "Inventory → Sample label (or Test print on this page).",
            "QL-810W Wi-Fi address — type the IP from the printer Menu / Wi-Fi / TCP/IP, or tap a Found on this PC address.",
            "Print on Wi-Fi. You want QR, cuts on the 0.6\" sides of the QR, then code / Aluminum T6 6061 / size under it. If that sample is wrong, do not print the whole rack.",
          ],
        },
        {
          type: "h",
          text: "Print the rack (Materials)",
        },
        {
          type: "ol",
          items: [
            "Inventory → Print labels, or on this page tap Materials.",
            "Wait until every gray box is a preview.",
            "Stand at the QL. Tap Print N labels.",
            "If it says unlock, PIN then print again. If it says set the address, go to Test print / Sample label.",
            "Stick one per size on the rack. These are size stickers (LCMM…), not per-bar serials.",
          ],
        },
        {
          type: "h",
          text: "Print bars that were received (Pieces)",
        },
        {
          type: "ol",
          items: [
            "Inventory → Barcoded pieces → Print all available labels, or tap Pieces here.",
            "For one bar: that row’s Label (ids= that piece). After a buy: Print last labels (N).",
            "Wait for previews. Print N labels. Put each sticker on that physical bar — Remaining and Scan / cut follow this barcode.",
          ],
        },
        {
          type: "h",
          text: "If print fails",
        },
        {
          type: "ol",
          items: [
            "Unlock this PC if asked.",
            "Confirm QL-810W Wi-Fi address on Sample label. Same subnet as the host.",
            "Power light blinking = printer rejected the job (wrong tape, cover, jam). Fix the printer, then Test print one sample. Do not keep hitting Print N labels.",
            "“Wait for barcodes to finish drawing” = wait, then print.",
          ],
        },
        {
          type: "warn",
          text: "No Edge. No Paint. No USB. No Windows print dialog on this page. Wi-Fi raster from LCM to the QL-810W only.",
        },
      ],
    },
  ],
};

export const sampleLabelHowTo: PageHowToDoc = {
  id: "sample-label",
  path: "/sample-label",
  title: "Sample barcode label",
  tab: "inventory",
  whatThisPageIs:
    "One test sticker and the only place you set the QL-810W Wi-Fi address. Same DK-2210 1.1 × 0.6 tape, same Wi-Fi path as Stock barcode labels. No Edge. No Paint. No USB. Print this once after you load tape or move the printer, then go back to Inventory / Print labels.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "The sample is always barcode LCM-SAMPLE-01. If a stock piece with that barcode exists, line 1 / size / location come from that piece. Otherwise the page uses a built-in Aluminum T6 6061 Round Stock 1.5\" dia x 12 ft, 144\" remaining, Rack A-1. The QR encodes the shop scan URL for LCM-SAMPLE-01.",
        },
        {
          type: "p",
          text: "QL-810W Wi-Fi address is stored in this browser (lcm-ql-ip) and reused by Stock barcode labels → Print N labels. Type it once. If this PC is unlocked, the page asks the host for printers it can see and lists them under Found on this PC. The first found IP fills an empty box.",
        },
        {
          type: "p",
          text: "Print on Wi-Fi draws the same 0.6 × 1.1 view as production labels, rotates it so cuts are the 0.6\" sides of the QR, and sends mono raster to that IP. Save PNG downloads the on-screen (unrotated) preview as LCM-SAMPLE-01.png — that file is for looking, not for Paint / Edge printing.",
        },
        {
          type: "warn",
          text: "Goes to the QL-810W over Wi-Fi. No Edge. No Paint. No USB. If you print the PNG from Windows you will get the wrong size and the wrong cut.",
        },
      ],
    },
    {
      title: "Page chrome",
      blocks: [
        {
          type: "control",
          name: "Inventory",
          does: "Back link (arrow) to /inventory. Does not print.",
        },
        {
          type: "control",
          name: "Sample barcode label",
          does: "Title. Subtitle: “Goes to the QL-810W over Wi-Fi. No Edge. No Paint. No USB.”",
        },
        {
          type: "control",
          name: "QL-810W Wi-Fi address",
          does: "Mono box. Placeholder 10.200.1.50. Saves as you type. Print on Wi-Fi and the Inventory labels page both use this. Empty print toasts: “Type the QL-810W Wi-Fi address first.”",
        },
        {
          type: "control",
          name: "Found on this PC: {ip}",
          does: "Shows when the unlocked host discovered one or more printer IPs. Each address is a button — tap to fill QL-810W Wi-Fi address and save it. Hidden until unlock + discovery succeed.",
        },
        {
          type: "control",
          name: "On the printer: Menu / Wi-Fi / TCP/IP — copy the IP here.",
          does: "Hint when no IPs were found. Walk to the QL, open Menu → Wi-Fi → TCP/IP, type that address in QL-810W Wi-Fi address.",
        },
        {
          type: "control",
          name: "preview",
          does: "The 0.6 in wide sticker image (QR + LCM-SAMPLE-01 + Aluminum T6 6061 + size). Gray 0.6 × 1.1 box until it draws. Same layout the QL will cut, before the host rotates for feed.",
        },
        {
          type: "control",
          name: "Print on Wi-Fi",
          does: "Sends this one sample to the address in QL-810W Wi-Fi address. Saves the IP first. Requires the QR to be drawn (“Wait for the barcode to finish drawing”) and a shop PIN (“Unlock this PC first, then print again.”). Success: “Sent over Wi-Fi to {ip}.” While working the label is Sending….",
        },
        {
          type: "control",
          name: "Sending…",
          does: "Print on Wi-Fi while the host is talking to the QL. Wait.",
        },
        {
          type: "control",
          name: "Save PNG",
          does: "Downloads {barcode}.png (LCM-SAMPLE-01.png) of the preview. For checking the draw on another screen — not a Windows print path.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Set the printer and prove the tape",
        },
        {
          type: "ol",
          items: [
            "Unlock this PC (PIN).",
            "Inventory → Sample label.",
            "Put DK-2210 1.1 × 0.6 in the QL-810W. Lid clicked. Printer on shop Wi-Fi.",
            "If Found on this PC shows an address, tap it. Else type QL-810W Wi-Fi address from Menu / Wi-Fi / TCP/IP.",
            "Wait for the preview. Print on Wi-Fi.",
            "Check the sticker: QR, cuts on the 0.6\" sides of the QR, then LCM-SAMPLE-01, Aluminum T6 6061, and a short size. Then Inventory → Print labels for the rack.",
          ],
        },
        {
          type: "h",
          text: "Printer moved or IP changed",
        },
        {
          type: "ol",
          items: [
            "Come back to this page. Do not hunt an IP box on Stock barcode labels — there isn’t one.",
            "Replace QL-810W Wi-Fi address. Print on Wi-Fi one sample before anyone prints 40 Materials labels.",
          ],
        },
        {
          type: "h",
          text: "Unlock / wait errors",
        },
        {
          type: "ol",
          items: [
            "“Unlock this PC first, then print again.” — PIN, then Print on Wi-Fi again.",
            "“Wait for the barcode to finish drawing” — wait for the preview, then print.",
            "“Type the QL-810W Wi-Fi address first.” — fill the box.",
            "Blinking QL light — tape, cover, jam. Fix hardware, then one sample. Do not print from Edge or Paint.",
          ],
        },
      ],
    },
  ],
};
