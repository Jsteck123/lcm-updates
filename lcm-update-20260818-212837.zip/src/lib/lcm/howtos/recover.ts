import type { PageHowToDoc } from "./types";

export const recoverHowTo: PageHowToDoc = {
  id: "recover",
  path: "/recover",
  title: "Recover shop",
  audience: "admin",
  tab: "settings",
  whatThisPageIs:
    "Use this if Settings will not load or the shop looks empty/wrong. Unlock with your admin PIN, then restore or download a host backup. Restore replaces live shop data (a snapshot of current data is taken first). Admin-only.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "This screen talks to the host backup folder (data/backups on the host PC) even when the rest of Settings is hard to reach. You must unlock as an admin. A shop login is rejected: Use an admin account to recover.",
        },
        {
          type: "p",
          text: "Unlock lists backups on this host. Each row can Download (JSON onto this computer) or Restore this (roll the live book back to that moment). Restore confirms: Restore shop data from [when]? Current data is snapshotted first.",
        },
        {
          type: "warn",
          text: "Do this on purpose. Restore replaces live data on the host. Every other screen will then load that older book. Never treat an update zip as a backup. Never treat a backup zip as Update app.",
        },
        {
          type: "note",
          text: "Same PIN you use to switch into your admin user. Host folder is next to the running app: data/backups.",
        },
      ],
    },
    {
      title: "Admin unlock",
      blocks: [
        {
          type: "control",
          name: "Recover shop",
          does: "Page title. Use this if Settings will not load or the shop looks empty/wrong.",
        },
        {
          type: "control",
          name: "Admin unlock",
          does: "Card before you have a token. Same PIN as Switch user for your admin.",
        },
        {
          type: "control",
          name: "Email",
          does: "Admin email. Prefills the signed-in address. Placeholder you@shop.",
        },
        {
          type: "control",
          name: "PIN",
          does: "Admin PIN. Enter submits Unlock backups.",
        },
        {
          type: "control",
          name: "Unlock backups",
          does: "Claims an admin session, then lists host backups. Success: Unlocked — pick a backup. Wrong PIN or a shop login stays locked.",
        },
      ],
    },
    {
      title: "Backups on this host",
      blocks: [
        {
          type: "control",
          name: "Backups on this host",
          does: "After unlock. Also on disk: [folder], or Files live in data/backups on the host PC.",
        },
        {
          type: "control",
          name: "Download",
          does: "Saves that backup JSON onto this computer. Does not change live data.",
        },
        {
          type: "control",
          name: "Restore this",
          does: "After confirm, restores that file to the live shop book, then reloads Dashboard. Current data is snapshotted first.",
        },
        {
          type: "control",
          name: "Back to Settings",
          does: "Link at the bottom when you can reach Settings again.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Shop looks empty or wrong",
        },
        {
          type: "ol",
          items: [
            "Open Recover shop (/recover) on a station that can reach the host.",
            "Enter admin Email and PIN. Unlock backups.",
            "Read the timestamps and labels. Download a copy off the machine if you want one first.",
            "Restore this only on the snapshot you mean. Confirm the dialog.",
            "Wait for Restored — reloading. Check Job Board and Customer Orders.",
          ],
        },
        {
          type: "h",
          text: "Just grab a file off the host",
        },
        {
          type: "ol",
          items: [
            "Unlock backups.",
            "Download the row you want.",
            "Keep that JSON with the USB full backups — it is data only, not the program.",
          ],
        },
        {
          type: "note",
          text: "Settings → Host backups is the same folder when Settings will load. Prefer that screen for everyday Backup now / Restore. Use Recover shop when Settings itself is the problem.",
        },
      ],
    },
  ],
};
