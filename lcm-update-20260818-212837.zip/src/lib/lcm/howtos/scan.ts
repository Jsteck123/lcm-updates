import type { PageHowToDoc } from "./types";

export const scanHowTo: PageHowToDoc = {
  id: "scan-stock",
  path: "/scan",
  title: "Scan stock",
  tab: "inventory",
  whatThisPageIs:
    "Phone / saw station for a sticker on a bar. Rack size labels (LCMM) and leftover-bar labels (LCM) list every open cut-queue job that uses that material. Pick the job, see cut length and leftover qty, enter how many you just cut. Other stickers (job, PO, ship) have their own instructions and will not open this cut list.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "A phone camera QR on a rack or leftover-bar sticker opens this page with the code already in the box (?c=). The sticker kind prints its own instructions. Matching cut-queue jobs show as cards — tap one to cut.",
        },
        {
          type: "ul",
          items: [
            "Find looks up the code in both books: leftover bars (LCM…) and Material on hand rack labels (LCMM).",
            "Jobs that use that alloy and a compatible shape are listed. Same type and closest size sort first. Due date is next.",
            "Pick the job. Cut length (LOC) and leftover qty fill in. Enter how many you just cut — 1, 5, All, or type the number.",
            "Cut N marks the ticket and spends the inches. If a pending hold is on that job, the hold is consumed (available goes back up). A leftover-bar sticker also shortens remaining length on that bar.",
            "No matching job: Request cut from the job board. Deduct does not run until a job is picked.",
          ],
        },
        {
          type: "note",
          text: "Every label kind has its own instructions. Only rack and leftover-bar stickers open this cut list. Job / PO / ship labels will not.",
        },
        {
          type: "warn",
          text: "Cut stays disabled until a matching available bar or a pending hold is on the picked job. A consumed or unknown code will not spend stock.",
        },
      ],
    },
    {
      title: "Sticker card",
      blocks: [
        {
          type: "control",
          name: "Scan stock",
          does: "Page title. Subtitle: scan the sticker; matching cut-queue jobs come up so you can pick what you are running.",
        },
        {
          type: "control",
          name: "Sticker",
          does: "Card title. Description: phone camera QR on a rack or leftover-bar sticker fills the code. Other labels have their own instructions.",
        },
        {
          type: "control",
          name: "LCMM… or LCM…",
          does: "Barcode field. Auto-focus. Enter runs Find. Forced uppercase. Changing the code clears the picked job.",
        },
        {
          type: "control",
          name: "Find",
          does: "Looks up the code. Toast names leftover bar or rack. Error if the kind is unknown or not on the book.",
        },
        {
          type: "control",
          name: "Rack size sticker / Leftover bar sticker / Unknown sticker",
          does: "Title for this label kind, plus its own instructions. Rack and leftover list cut-queue jobs. Unknown will not open the cut list.",
        },
      ],
    },
    {
      title: "Cut queue cards",
      blocks: [
        {
          type: "control",
          name: "Cut queue · N jobs",
          does: "List of open tickets that use this material. Each card: part / rev, customer, PO, due, cut length, qty cut / requested / left. Tap picks the job.",
        },
        {
          type: "control",
          name: "This cut",
          does: "After you pick a job: cut length, qty cut / requested, left, available for the machine.",
        },
        {
          type: "control",
          name: "← All matching jobs",
          does: "Back to the list so you can pick a different job on the same bar.",
        },
        {
          type: "control",
          name: "How many just cut",
          does: "Number of blanks you just cut. − / + , 5, All leftover, or type. Default 1.",
        },
        {
          type: "control",
          name: "Cut N",
          does: "Marks N on the ticket under your name and spends the inches. Toast: remaining on the bar (if leftover) plus cut/requested. Resets qty to 1. When the ticket is finished it returns to the job list.",
        },
        {
          type: "control",
          name: "No open cut-queue jobs use this material.",
          does: "Empty state. Link to the saw queue. Request cut from the job board if this bar is for a job.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Cut from a bar on the ground",
        },
        {
          type: "ol",
          items: [
            "Scan the QR on the rack sticker or leftover bar (or type the code and tap Find).",
            "Confirm material, size, and on-hand / remaining.",
            "Tap the job you are running.",
            "Read cut length and leftover qty.",
            "Set how many you just cut and tap Cut N.",
            "Repeat or pick another job on the same bar.",
          ],
        },
      ],
    },
  ],
};
