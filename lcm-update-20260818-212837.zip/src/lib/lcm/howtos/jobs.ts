import type { PageHowToDoc } from "./types";

export const jobHistoryHowTo: PageHowToDoc = {
  id: "job-history",
  path: "/jobs",
  title: "Job History",
  tab: "jobs",
  whatThisPageIs:
    "Every job run is saved here. Click a part to see all runs and shop averages. Office / admin also sees quote prices for requote decisions and bonus dollars. Completing a job updates that part’s setup/run times in the database (rolling average). Shop logins never see prices or bonus.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "This is the book of runs — not the live Job Board. Newest start time at the top. Filter by part, operator, machine, customer, or rev. Narrow by status. Click any row to open the part run report on the right: quote at a glance, shop-average setup/run vs what is on the quote now, and every completed run for that P/N + rev.",
        },
        {
          type: "p",
          text: "If that exact rev has no completed runs, the report falls back to all revs of the same P/N. Quote match prefers same P/N + rev, then any quote with that P/N. Completing a job on the floor is what feeds the rolling averages — you do not type averages here.",
        },
        {
          type: "note",
          text: "Shop view hides quote prices, Open in quoter, bonus dollars, and the “raise/sharpen price” wording on the trend line. You still see times, efficiency, and who ran it.",
        },
        {
          type: "warn",
          text: "Q → Act compares quoted time to actual time. Red actual means slower than quote (>5%). Green means faster (<95% of quote). Efficiency is stored on the job. Do not treat a single slow run as the new quote without reading the whole report.",
        },
      ],
    },
    {
      title: "Filters",
      blocks: [
        {
          type: "control",
          name: "Filter part, operator, machine…",
          does: "Text filter. Matches part number, operator, machine, customer, or revision (case-insensitive). Does not search notes. Clear the box to see every job again.",
        },
        {
          type: "control",
          name: "Status",
          does: "Dropdown (label is screen-reader only). All statuses, In Progress, Completed, or Downtime. All statuses is the default. In Progress is a live run that has not been completed. Completed is a finished run. Downtime is a run that ended as downtime.",
        },
      ],
    },
    {
      title: "Job list",
      blocks: [
        {
          type: "p",
          text: "Card title is “N job(s)”. Subtitle: Click a row to open the part run report. Empty: No jobs match. Clicking a row selects that P/N + rev and opens the report. The table shrinks to the left column while the report is open.",
        },
        {
          type: "control",
          name: "Start",
          does: "When the run started. Date and time. Sort of the list is newest start first — this column is not a sort button.",
        },
        {
          type: "control",
          name: "Part",
          does: "Part number plus rev {rev} (or —). This is what the report keys off when you click the row.",
        },
        {
          type: "control",
          name: "Operator",
          does: "Who was signed in on the run. Dash if none was stored.",
        },
        {
          type: "control",
          name: "Machine",
          does: "Which machine ran it.",
        },
        {
          type: "control",
          name: "Qty",
          does: "quantityCompleted / quantity. If completed is short, the run did not finish the full order qty.",
        },
        {
          type: "control",
          name: "Q → Act",
          does: "Quoted time → actual time for that run. Quoted is muted. Actual turns red if more than 5% over quote, green if under 95% of quote and a quote time exists.",
        },
        {
          type: "control",
          name: "Eff",
          does: "Efficiency stored on the job, shown as a percent. Values stored as 0–100 or 0–1 are both handled.",
        },
        {
          type: "control",
          name: "Status",
          does: "Badge: Completed (green), In Progress (blue), or Downtime (amber). Same words as the Status filter.",
        },
      ],
    },
    {
      title: "Part run report",
      blocks: [
        {
          type: "p",
          text: "Right card. Title is the P/N with rev {rev}. Subtitle: N completed run(s) · avg eff {percent}. Close (X) dismisses the report and the list goes full width again.",
        },
        {
          type: "control",
          name: "Close",
          does: "Closes the part report. Does not delete any runs.",
        },
        {
          type: "h",
          text: "Requote at a glance",
        },
        {
          type: "p",
          text: "If a quote exists: “Quote in DB · {customer} · {date}.” If not: “No quote row for this part yet — complete runs still show below” (office also sees “; add a quote to lock prices.”).",
        },
        {
          type: "control",
          name: "qty {n} {price} ea",
          does: "Admin / price-visible only. One chip per quote qty break. Empty: No qty/price breaks on quote. Shop logins do not see these chips.",
        },
        {
          type: "control",
          name: "Open in quoter →",
          does: "Admin / price-visible only. Link to Quoting so office can reprice from this history. Hidden on shop logins.",
        },
        {
          type: "p",
          text: "Trend line (needs at least two completed runs). Runs are taking longer than earlier jobs — office also sees “consider raising price or process time.” Runs are faster than earlier jobs — office also sees “room to sharpen price if you want.” Or “Time is fairly steady across runs.”",
        },
        {
          type: "h",
          text: "Shop average times (in part DB after completes)",
        },
        {
          type: "control",
          name: "Op",
          does: "OP1, OP2, … up to the shop max-operations setting. Rows with no average and no quote time are hidden.",
        },
        {
          type: "control",
          name: "Avg setup",
          does: "Rolling average setup minutes from completed runs, written into the part database when a job completes. Dash if none.",
        },
        {
          type: "control",
          name: "Avg run /pc",
          does: "Rolling average run minutes per piece from completed runs. This is what the quoter can pick up as shop time.",
        },
        {
          type: "control",
          name: "Quote now",
          does: "Setup / run minutes currently stored on the matching quote. Compare this to the two average columns before you change a price. Dash if that op is empty on the quote.",
        },
        {
          type: "h",
          text: "Each job run",
        },
        {
          type: "p",
          text: "One card per completed run for this part (exact rev if any exist, otherwise all revs). Empty: No completed runs for this part yet. In-progress rows in the left table do not appear here until they are completed.",
        },
        {
          type: "control",
          name: "{date} · {±N}% vs quote time",
          does: "End time (or start if no end). Badge is red if more than 5% over quote time, green if more than 5% under, otherwise neutral. Body: operator · machine · qty completed/ordered. Then Quoted {time} → Actual {time} · Eff {percent}. Admin also sees · Bonus {$}.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Look up a past run",
        },
        {
          type: "ol",
          items: [
            "Sidebar → Job History.",
            "Type the part number (or operator / machine) in Filter part, operator, machine…",
            "Set Status to Completed if you only want finished runs.",
            "Read Start, who ran it, machine, Qty, Q → Act, and Eff on the row.",
          ],
        },
        {
          type: "h",
          text: "Open the part report before a requote (office)",
        },
        {
          type: "ol",
          items: [
            "Click any row for that P/N.",
            "Read Requote at a glance — customer, date, qty breaks (admin / price-visible).",
            "Compare Avg setup and Avg run /pc to Quote now on each op.",
            "Read the trend line (longer / faster / steady) and each run’s % vs quote time.",
            "Admin: Open in quoter → to reprice from these times. Shop logins stop at the times.",
          ],
        },
        {
          type: "h",
          text: "See who last ran a part",
        },
        {
          type: "ol",
          items: [
            "Filter to the P/N.",
            "Click the newest Completed row.",
            "The top card under Each job run is the latest complete — operator, machine, qty, and times.",
          ],
        },
        {
          type: "h",
          text: "Why a number looks off",
        },
        {
          type: "ol",
          items: [
            "If Q → Act is red, open the report and see whether every run is slow or just one.",
            "If Avg setup / run is empty, not enough completed runs have been saved for that op yet — finish jobs on the floor; do not type averages here.",
            "If the quote block is missing, there is no quote row for this P/N. Completes still list. Office adds the quote on Quoting.",
            "Bonus dollars are admin only. Shop logins will not see them on the run cards.",
          ],
        },
      ],
    },
  ],
};
