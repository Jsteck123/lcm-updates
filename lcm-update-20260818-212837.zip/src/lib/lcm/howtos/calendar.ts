import type { PageHowToDoc } from "./types";

export const shipCalendarHowTo: PageHowToDoc = {
  id: "ship-calendar",
  path: "/calendar",
  title: "Ship Calendar",
  tab: "calendar",
  whatThisPageIs:
    "Due dates from customer orders — pack, verify, Friday delivery run, then mark delivered / attach signed slip / QB invoice flags. This replaces the Friday post-it board. Colors match the rest of the shop. Office-only: Invoiced in QB and Payment received. Shop logins pack, print, deliver, and attach the signed slip.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "Each calendar day shows the PO #s whose Date required / due date lands that day. Tap a day and the right card lists those orders with lines and qty. Pack flow is Shop packed → Office verified → Delivered. Completing a job on the floor flips the line to ready for pack so packing can see it.",
        },
        {
          type: "p",
          text: "The Friday delivery run strip is this week’s truck plus anything already packed or verified. Print slips Thursday / Friday morning, QC, load the bay. After the truck, mark Delivered and attach the signed packing slip when the driver brings it back.",
        },
        {
          type: "note",
          text: "Packing slip and Ship WO print through the browser. Mark packed prints the 1.1×2 box label on the QL-810W (customer, PO, part, rev, qty + QR). Scan that QR to see what is in the box and check it onto the truck.",
        },
        {
          type: "warn",
          text: "Do not mark Shop packed until the carton is closed and on the outgoing cart. Do not mark Office verified until qty and part are checked against the slip. Invoiced in QB and Payment received are admin only — shop logins will not see those buttons.",
        },
      ],
    },
    {
      title: "Color legend",
      blocks: [
        {
          type: "p",
          text: "Same status colors as the Job Board. The chips under the title are a legend, not buttons.",
        },
        {
          type: "control",
          name: "Hold / need pack",
          does: "Amber. Nothing packed yet, or the line is still Hold on the order.",
        },
        {
          type: "control",
          name: "Due ≤2 days",
          does: "Soon. That day’s POs are due within about two days.",
        },
        {
          type: "control",
          name: "Overdue",
          does: "Red. That day’s due date is already past and there are still POs on it.",
        },
        {
          type: "control",
          name: "Packed / in progress",
          does: "Blue. Carton is on the outgoing cart (Shop packed) or work is still moving.",
        },
        {
          type: "control",
          name: "Verified / delivered",
          does: "Teal. Office verified the cart, or the order is marked delivered.",
        },
        {
          type: "control",
          name: "Invoiced (office)",
          does: "Office color. Admin flagged Invoiced in QB. Shop logins do not see the QB flags on the order card.",
        },
        {
          type: "control",
          name: "Paid",
          does: "Done green. Admin flagged Payment received — job closed in the books.",
        },
      ],
    },
    {
      title: "Friday delivery run",
      blocks: [
        {
          type: "p",
          text: "Card title: Friday delivery run · {this Friday’s date}. Description: This week ({week start} → {week end}) + packed/verified. Print slips Thursday/Friday morning, QC, load bay. Includes any non-cancelled, not-yet-delivered PO that is due this week, or already packed / verified / has a ready-for-pack or line-packed line. Empty: No deliveries queued this week.",
        },
        {
          type: "control",
          name: "Slip",
          does: "Prints that order’s PACKING SLIP: ship-to / customer, SO #, status, lines (Part #, Rev, Description, Qty, Packed ☐, OK ☐), plus sign-off boxes for Shop — packed on cart and Office — verified ready. No prices.",
        },
        {
          type: "control",
          name: "Ship WO",
          does: "Prints the SHIPPING WORK ORDER clipboard: PO, due, customer, lines with Part # / Rev / Description / Qty / Ready / Packed. No drawings, no prices. Pack against this list.",
        },
        {
          type: "control",
          name: "Delivered",
          does: "Only when pack status is verified and the order is not already delivered. Marks delivered under your signed-in name. Toast: “Marked delivered.” Same action as Delivered on the day card.",
        },
      ],
    },
    {
      title: "Month calendar",
      blocks: [
        {
          type: "p",
          text: "Card title is the month name and year. Description: PO #s on each day · colors: need pack / packed / verified. Day headers: Sun Mon Tue Wed Thu Fri Sat. Empty cells are other months. Today has a ring. The selected day is highlighted. A day with POs and a past due date tints overdue; due within two days tints soon.",
        },
        {
          type: "control",
          name: "◀",
          does: "Previous month. From January this goes to December of the prior year.",
        },
        {
          type: "control",
          name: "Today",
          does: "Jumps the calendar to this month and selects today’s date.",
        },
        {
          type: "control",
          name: "▶",
          does: "Next month. From December this goes to January of the next year.",
        },
        {
          type: "control",
          name: "Day cell",
          does: "Tap to select that date. Shows the day number, “N PO” when anything is due, up to three PO #s, “+N more” if there are more than three, and color ticks: amber Need pack, sky Packed, emerald Verified. Selecting a day fills the right-hand list.",
        },
      ],
    },
    {
      title: "Selected day",
      blocks: [
        {
          type: "p",
          text: "Right card title is the long date (or Select a day). Description: Line items & qty · filter ready-for-pack · packing slip / ship WO / labels · pack → verify → deliver. Empty: Nothing due this day.",
        },
        {
          type: "control",
          name: "Ready for pack only (from shop complete)",
          does: "Checkbox. When on, each order on that day only shows lines that are readyForPack and not yet linePacked, and orders with no such lines disappear. Use this when you are packing, not when you are planning the week.",
        },
      ],
    },
    {
      title: "Order card on a day",
      blocks: [
        {
          type: "p",
          text: "One card per PO due that day. Header: PO # (or “(no PO #)”), customer, open order link to Customer Orders, delivered if already out, admin badges Invoiced QB and Paid, and the pack badge: Need pack / Packed on cart / Ready / verified.",
        },
        {
          type: "control",
          name: "open order",
          does: "Opens this PO on Customer Orders so you can check rev, qty, or the original PDF.",
        },
        {
          type: "h",
          text: "Line table",
        },
        {
          type: "control",
          name: "Part",
          does: "Part number. Green “ready for pack” under it when the floor completed the job and it is waiting on the cart.",
        },
        {
          type: "control",
          name: "Rev",
          does: "Drawing rev to pack against. Match the print in the carton.",
        },
        {
          type: "control",
          name: "Description",
          does: "Line description from the PO.",
        },
        {
          type: "control",
          name: "Qty",
          does: "Pieces to pack for that line. This is the number on the slip.",
        },
        {
          type: "control",
          name: "Pack",
          does: "✓ if the line is already packed, plus Reprint to fire the 1.1×2 box label again. Mark packed if it is ready for pack. Dash if the shop has not finished the line.",
        },
        {
          type: "control",
          name: "Mark packed",
          does: "On a ready-for-pack line. Creates a packed-box record (customer, PO, part, rev, qty), marks the line packed under your name, and prints a 1.1×2 QL-810W label with a QR. Scan the QR to see what is in the box and check it off when it loads on the truck. Does not flip the whole-order pack status — still tap Shop packed when the carton is closed.",
        },
      ],
    },
    {
      title: "Pack and print buttons",
      blocks: [
        {
          type: "control",
          name: "Reprint",
          does: "On a packed line. Sends the same 1.1×2 box label to the QL-810W again. Use this if the first print jammed.",
        },
        {
          type: "control",
          name: "Packing slip",
          does: "Prints the customer packing slip for this order (same sheet as Friday Slip): ship-to, SO #, status, every line with Packed / OK check boxes, shop packed-on-cart sign-off, office verified sign-off.",
        },
        {
          type: "control",
          name: "Ship WO",
          does: "Prints the shop shipping work order (no prices, no drawings). Pack against Part # / Rev / Qty / Ready / Packed.",
        },
        {
          type: "control",
          name: "Drawing",
          does: "Opens the shop print for that line (same file as the job board Drawing). One button per print if the line has several. Also a Draw column on the line table. Hidden / — when that line has no drawing.",
        },
        {
          type: "control",
          name: "Shop packed",
          does: "Only while pack status is pending (Need pack). Marks the order packed under your name. Toast: “Marked packed — on outgoing cart.” Badge becomes Packed on cart. Next button is Office verified.",
        },
        {
          type: "control",
          name: "Office verified",
          does: "Only while pack status is packed. Marks verified under your name. Toast: “Office verified — ready to load.” Badge becomes Ready / verified. Next button is Delivered.",
        },
        {
          type: "control",
          name: "Delivered",
          does: "Only when verified and not already delivered. Marks delivered under your name. Toast: “Delivered.” Friday strip hides this PO once delivered.",
        },
        {
          type: "control",
          name: "Reset pack",
          does: "Shows when status is not pending, or always for admin. Sets pack status back to pending and clears the Pack check on every line so Mark packed shows again. Toast: “Pack status reset.” Use if the carton was pulled apart or packed under the wrong PO. Does not clear Delivered / signed slip / QB flags. Reprint still works after they mark packed again.",
        },
      ],
    },
    {
      title: "Close-out (slip, invoice, paid)",
      blocks: [
        {
          type: "control",
          name: "Signed slip",
          does: "File picker, PDF or image. Uploads to the host and attaches as the signed packing slip on this order. Toast: “Signed packing slip attached” or the upload error. After a successful attach the card shows Slip on file.",
        },
        {
          type: "control",
          name: "Invoiced in QB",
          does: "Admin only. Shows after the order is delivered and not yet invoiced. Flags invoicedInQb. Toast: “Marked invoiced in QB.” Shop logins never see this.",
        },
        {
          type: "control",
          name: "Payment received",
          does: "Admin only. Shows after Invoiced in QB and before paid. Flags paymentReceived. Toast: “Payment received — job closed.” Shop logins never see this.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Pack a day’s orders",
        },
        {
          type: "ol",
          items: [
            "Open Ship Calendar. Tap Today if you are not on this month.",
            "Tap the day you are packing (usually Friday, or the customer due date).",
            "Check Ready for pack only (from shop complete) so you only see finished lines.",
            "On each order: Packing slip and/or Ship WO.",
            "Pack the carton against the slip. On each ready line tap Mark packed — the 1.1×2 box label prints (customer, PO, part, rev, qty + QR).",
            "When the carton is closed and on the outgoing cart, tap Shop packed.",
            "At the truck, scan the box QR and tap Loaded on truck.",
          ],
        },
        {
          type: "h",
          text: "Friday delivery run",
        },
        {
          type: "ol",
          items: [
            "Read Friday delivery run at the top — that is this week’s truck plus anything already packed/verified.",
            "Thursday or Friday morning, tap Slip (and Ship WO if the driver wants the clipboard) on each row.",
            "QC the cart against the slips. On each order card tap Office verified.",
            "Load the bay. After the stop, tap Delivered on the strip or the day card.",
            "When the signed slip comes back, use Signed slip on that order card.",
          ],
        },
        {
          type: "h",
          text: "Office verify, then books (admin)",
        },
        {
          type: "ol",
          items: [
            "After Shop packed, check qty and P/N against the packing slip.",
            "Tap Office verified — ready to load.",
            "After the truck, Delivered.",
            "Attach Signed slip.",
            "Admin: Invoiced in QB, then Payment received when the check clears.",
          ],
        },
        {
          type: "h",
          text: "Wrong carton / need to re-pack",
        },
        {
          type: "ol",
          items: [
            "Open the order on that due day.",
            "Tap Reset pack. Status goes back to Need pack.",
            "Re-pack, Mark packed on the lines, then Shop packed again.",
          ],
        },
        {
          type: "h",
          text: "Look up a PO from the calendar",
        },
        {
          type: "ol",
          items: [
            "Find the due day (PO #s are printed on the cell).",
            "Tap the day, find the card, tap open order.",
            "That opens Customer Orders on this PO — original PDF, rev, and lines.",
          ],
        },
      ],
    },
  ],
};
