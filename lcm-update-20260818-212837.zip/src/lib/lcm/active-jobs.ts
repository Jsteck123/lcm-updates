import type { ActiveTimer, MachineSession } from "./types";

export function sameOperatorName(a: string, b: string): boolean {
  return (a || "").trim().toLowerCase() === (b || "").trim().toLowerCase();
}

export type MyActiveJob = {
  machine: string;
  session: MachineSession;
  timer: ActiveTimer | null;
};

/** Machines this operator has loaded, paused, or running. */
export function listMyActiveJobs(
  machines: string[],
  sessions: Record<string, MachineSession | undefined>,
  timers: Record<string, ActiveTimer | null | undefined>,
  operatorName: string,
): MyActiveJob[] {
  const name = (operatorName || "").trim();
  if (!name) return [];
  const rows: MyActiveJob[] = [];
  for (const machine of machines) {
    const session = sessions[machine];
    if (!session) continue;
    if (!sameOperatorName(session.operatorName || "", name)) continue;
    const timer = timers[machine] || null;
    if (!session.jobId && !timer && !session.paused) continue;
    rows.push({ machine, session, timer });
  }
  rows.sort((a, b) => {
    const ar = a.timer ? 0 : a.session.paused ? 1 : 2;
    const br = b.timer ? 0 : b.session.paused ? 1 : 2;
    if (ar !== br) return ar - br;
    return a.machine.localeCompare(b.machine);
  });
  return rows;
}
