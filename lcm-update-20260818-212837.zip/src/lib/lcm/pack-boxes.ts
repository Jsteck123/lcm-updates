import { uid } from "@/lib/utils";
import type { PackBox, ShopOrder, ShopOrderLine } from "./types";

export function packBoxBarcode(id: string): string {
  const clean = String(id || "")
    .replace(/[^a-zA-Z0-9]/g, "")
    .toUpperCase();
  return ("LCMBOX" + clean).slice(0, 20);
}

export function boxUrlForBarcode(barcode: string, origin?: string): string {
  const path = `/box?c=${encodeURIComponent(barcode)}`;
  const base = String(origin || "").replace(/\/+$/, "");
  return base ? `${base}${path}` : path;
}

export function findPackBox(
  list: PackBox[] | undefined,
  code: string,
): PackBox | undefined {
  const raw = (code || "").trim();
  if (!raw) return undefined;
  const up = raw.toUpperCase();
  return (list || []).find(
    (b) => b.id === raw || (b.barcode || "").toUpperCase() === up,
  );
}

export function boxesForLine(
  list: PackBox[] | undefined,
  orderId: string,
  lineId: string,
): PackBox[] {
  return (list || []).filter(
    (b) => b.orderId === orderId && b.lineId === lineId,
  );
}

export function boxesForOrder(
  list: PackBox[] | undefined,
  orderId: string,
): PackBox[] {
  return (list || []).filter((b) => b.orderId === orderId);
}

export function emptyPackBox(partial?: Partial<PackBox>): PackBox {
  const id = partial?.id || uid();
  return {
    id,
    barcode: partial?.barcode || packBoxBarcode(id),
    orderId: partial?.orderId || "",
    lineId: partial?.lineId || "",
    customer: partial?.customer || "",
    poNumber: partial?.poNumber || "",
    partNumber: partial?.partNumber || "",
    revision: partial?.revision || "",
    qty: Math.max(0, Math.floor(Number(partial?.qty) || 0)),
    packedBy: partial?.packedBy || "",
    packedAt: partial?.packedAt || "",
    loaded: Boolean(partial?.loaded),
    loadedBy: partial?.loadedBy || "",
    loadedAt: partial?.loadedAt || "",
  };
}

export function packBoxFromLine(opts: {
  order: ShopOrder;
  line: ShopOrderLine;
  byName: string;
  qty?: number;
}): PackBox {
  const qty =
    opts.qty != null && Number(opts.qty) > 0
      ? Math.floor(Number(opts.qty))
      : Math.max(1, Math.floor(Number(opts.line.qty) || 1));
  return emptyPackBox({
    orderId: opts.order.id,
    lineId: opts.line.id,
    customer: opts.order.customer || "",
    poNumber: opts.order.poNumber || "",
    partNumber: opts.line.partNumber || "",
    revision: opts.line.revision || "",
    qty,
    packedBy: opts.byName,
    packedAt: new Date().toISOString(),
  });
}
