import { attachmentHttpUrl } from "./open-attachment";
import { getShopToken } from "./shop-sync";

const cache = new Map<string, Promise<string | null>>();

export function looksLikeImage(name: string, mime = "") {
  const n = (name || "").toLowerCase();
  const m = (mime || "").toLowerCase();
  return (
    m.startsWith("image/") ||
    /\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(n)
  );
}

export function looksLikePdf(name: string, mime = "") {
  const n = (name || "").toLowerCase();
  const m = (mime || "").toLowerCase();
  return m.includes("pdf") || n.endsWith(".pdf");
}

/** Drop the white sheet; keep ink as light ghost lines. */
function ghostLineArt(ctx: CanvasRenderingContext2D, w: number, h: number) {
  const img = ctx.getImageData(0, 0, w, h);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const l = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
    const ink = Math.max(0, 232 - l);
    if (ink < 16) {
      d[i + 3] = 0;
    } else {
      d[i] = 198;
      d[i + 1] = 214;
      d[i + 2] = 236;
      d[i + 3] = Math.min(185, Math.round(ink * 1.35));
    }
  }
  ctx.putImageData(img, 0, 0);
}

async function rasterizePdfFirstPage(
  data: ArrayBuffer,
  ghost: boolean,
): Promise<string | null> {
  const pdfjs = await import("pdfjs-dist");
  try {
    const worker = await import("pdfjs-dist/build/pdf.worker.min.mjs?url");
    pdfjs.GlobalWorkerOptions.workerSrc = worker.default as string;
  } catch {
    /* worker optional */
  }
  const doc = await pdfjs.getDocument({ data }).promise;
  const page = await doc.getPage(1);
  const base = page.getViewport({ scale: 1 });
  const scale = Math.min(1.35, 420 / Math.max(1, base.width));
  const viewport = page.getViewport({ scale });
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.floor(viewport.width));
  canvas.height = Math.max(1, Math.floor(viewport.height));
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return null;
  await page.render({ canvasContext: ctx, viewport, canvas }).promise;
  if (ghost) {
    ghostLineArt(ctx, canvas.width, canvas.height);
    return canvas.toDataURL("image/png");
  }
  return canvas.toDataURL("image/jpeg", 0.72);
}

async function resolveDrawingPreview(
  id: string,
  name: string,
  ghost: boolean,
): Promise<string | null> {
  const url = attachmentHttpUrl(id);
  if (looksLikeImage(name) && !looksLikePdf(name)) return url;
  const token = getShopToken();
  const res = await fetch(url, {
    headers: token ? { "x-lcm-shop-token": token } : undefined,
  });
  if (!res.ok) return null;
  const mime = res.headers.get("content-type") || "";
  if (looksLikeImage(name, mime) && !looksLikePdf(name, mime)) {
    const blob = await res.blob();
    return URL.createObjectURL(blob);
  }
  if (looksLikePdf(name, mime)) {
    const buf = await res.arrayBuffer();
    return rasterizePdfFirstPage(buf, ghost);
  }
  return null;
}

/** Cached preview URL. ghost=true knocks out paper (job board). ghost=false keeps the white sheet (thumbs). */
export function loadDrawingPreview(
  id: string,
  name?: string,
  opts?: { ghost?: boolean },
): Promise<string | null> {
  const key = `${opts?.ghost === false ? "paper" : "ghost"}:${(id || "").trim()}`;
  const fileId = (id || "").trim();
  if (!fileId) return Promise.resolve(null);
  const hit = cache.get(key);
  if (hit) return hit;
  const p = resolveDrawingPreview(fileId, name || "", opts?.ghost !== false).catch(
    () => null,
  );
  cache.set(key, p);
  return p;
}
