import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Factory, Pause, Play, Square, Timer } from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { allMachines, normalizeCustomLists } from "@/lib/lcm/lists";
import { machineToSlug } from "@/lib/lcm/machines";
import { getOperatorByEmail } from "@/lib/lcm/permissions";
import { listMyActiveJobs } from "@/lib/lcm/active-jobs";
import { formatSeconds, cn } from "@/lib/utils";
import { opLabel } from "@/lib/lcm/ops";
import {
  machineSessionStatus,
  statusSurfaceClass,
  statusToBadgeTone,
} from "@/lib/lcm/status-colors";
import type { ActiveTimer } from "@/lib/lcm/types";

export const Route = createFileRoute("/active")({
  component: ActiveJobsPage,
});

function timerLabel(timer: ActiveTimer | null, live: number | null) {
  if (!timer) return "Timer off";
  const op = timer.operation != null ? opLabel(Number(timer.operation)) : "";
  return `${timer.type}${op ? ` · ${op}` : ""} · ${formatSeconds(live || 0)}`;
}

function ActiveJobsPage() {
  const sessions = useLcmStore((s) => s.sessions);
  const activeTimers = useLcmStore((s) => s.activeTimers);
  const customLists = useLcmStore((s) => s.settings.customLists);
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  const getLive = useLcmStore((s) => s.getLiveElapsedSeconds);
  const smartStart = useLcmStore((s) => s.smartStart);
  const smartStop = useLcmStore((s) => s.smartStop);
  const navigate = useNavigate();
  const [, tick] = useState(0);

  const me = useMemo(
    () => getOperatorByEmail(operators, email),
    [operators, email],
  );
  const myName = me?.name || email.split("@")[0] || "";
  const machines = useMemo(
    () => allMachines(normalizeCustomLists(customLists)),
    [customLists],
  );

  useEffect(() => {
    const id = window.setInterval(() => tick((n) => n + 1), 1000);
    return () => window.clearInterval(id);
  }, []);

  const mine = useMemo(
    () => listMyActiveJobs(machines, sessions, activeTimers, myName),
    [machines, sessions, activeTimers, myName],
  );

  function goMachine(machine: string) {
    void navigate({
      to: "/machines/$machineId",
      params: { machineId: machineToSlug(machine) },
    });
  }

  return (
    <div className="p-3 sm:p-5 space-y-4 max-w-[1400px] mx-auto">
      <div>
        <h1 className="text-xl sm:text-2xl font-semibold tracking-tight">
          My Active Jobs
        </h1>
        <p className="text-sm text-[var(--color-muted)] mt-0.5">
          Jobs {myName || "you"} have loaded on a machine. Pulled board lines
          stay on the Job Board until you Load them.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
        {mine.map((row) => {
          const live = getLive(row.machine);
          const st = machineSessionStatus({
            hasJob: Boolean(row.session.jobId),
            running: Boolean(row.timer),
            paused: Boolean(row.session.paused),
          });
          return (
            <Card
              key={row.machine}
              className={cn("border", statusSurfaceClass(st))}
            >
              <CardHeader className="pb-2 space-y-1">
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Factory className="h-4 w-4 shrink-0" />
                    {row.machine}
                  </CardTitle>
                  <Badge tone={statusToBadgeTone(st)}>
                    {row.timer ? (
                      <>
                        <Play className="h-3 w-3 mr-1" /> Live
                      </>
                    ) : row.session.paused ? (
                      <>
                        <Pause className="h-3 w-3 mr-1" /> Paused
                      </>
                    ) : (
                      "Loaded"
                    )}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <div className="font-mono font-semibold text-base">
                    {row.session.partNumber || "—"}{" "}
                    <span className="text-xs font-normal">
                      Rev {row.session.revision || "—"}
                    </span>
                  </div>
                  <div className="text-xs text-[var(--color-muted)]">
                    Qty {row.session.quantity || 0}
                    {row.session.customer ? ` · ${row.session.customer}` : ""}
                  </div>
                </div>
                <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 flex items-center gap-2">
                  <Timer className="h-4 w-4 text-[var(--color-status-active)] shrink-0" />
                  <span className="text-sm tabular font-medium">
                    {timerLabel(row.timer, live)}
                  </span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  <Button
                    size="sm"
                    type="button"
                    className="min-h-11"
                    onClick={() => goMachine(row.machine)}
                  >
                    Open machine
                  </Button>
                  {!row.timer ? (
                    <Button
                      size="sm"
                      variant="secondary"
                      type="button"
                      className="min-h-11"
                      onClick={() => {
                        const r = smartStart(row.machine);
                        if (!r.ok) toast.error(r.error || "Cannot start");
                        else toast.success(r.message || "Started");
                      }}
                    >
                      <Play className="h-3.5 w-3.5" /> Start
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      variant="outline"
                      type="button"
                      className="min-h-11"
                      onClick={() => {
                        const r = smartStop(row.machine);
                        if (r.needsUnits) {
                          toast.message("Enter completed qty on the machine");
                          goMachine(row.machine);
                          return;
                        }
                        if (!r.ok) toast.error(r.error || "Cannot stop");
                        else toast.success("Timer stopped");
                      }}
                    >
                      <Square className="h-3.5 w-3.5" /> Stop
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {mine.length === 0 && (
        <p className="text-sm text-[var(--color-muted)] text-center py-8">
          No jobs running. Load a pulled line from the Job Board onto a
          machine and it will show here.
        </p>
      )}
    </div>
  );
}
