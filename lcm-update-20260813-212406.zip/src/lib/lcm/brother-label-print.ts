/** Brother QL-810W tape sizes (die-cut / continuous). */

export const QL_TAPES = [
  { id: "dk2210", label: "DK-2210 1.1 x 0.6 in compact", w: "1.1in", h: "0.6in" },
  { id: "dk1201", label: "DK-1201 Address 1.1 x 3.5 in", w: "1.1in", h: "3.5in" },
  { id: "dk1209", label: "DK-1209 1.1 x 2.4 in", w: "1.1in", h: "2.4in" },
  { id: "custom116", label: "1.1 x 1.6 in (Windows list)", w: "1.1in", h: "1.6in" },
  { id: "dk1202", label: "DK-1202 Shipping 2.4 x 3.9 in", w: "2.4in", h: "3.9in" },
  { id: "dk2205", label: "DK-2205 2.4 in continuous", w: "2.4in", h: "2.0in" },
] as const;

export type QlTapeId = (typeof QL_TAPES)[number]["id"];

export function tapeById(id: string) {
  return QL_TAPES.find((t) => t.id === id) || QL_TAPES[0]!;
}

function esc(s: string) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export type StockLabelItem = {
  barcode: string;
  qrDataUrl: string;
  line1: string;
  line2: string;
  line3?: string;
};

function isCompact(tape: { w: string; h: string }) {
  return parseFloat(tape.h) <= 1;
}

function labelCss(tape: { w: string; h: string }) {
  const compact = isCompact(tape);
  const page =
    "@page { size: " + tape.w + " " + tape.h + "; margin: 0; }" +
    "html, body { margin: 0; padding: 0; background: #fff; color: #000; }";
  const last =
    ".label:last-child { page-break-after: auto; break-after: auto; }";
  if (compact) {
    return (
      page +
      ".label { width: " +
      tape.w +
      "; height: " +
      tape.h +
      "; box-sizing: border-box; padding: 0.03in 0.03in; display: flex; flex-direction: row; align-items: center; gap: 0.03in; overflow: hidden; font-family: Arial, Helvetica, sans-serif; page-break-after: always; break-after: page; }" +
      last +
      ".qr { width: 0.5in; height: 0.5in; object-fit: contain; flex-shrink: 0; }" +
      ".text { flex: 1; min-width: 0; display: flex; flex-direction: column; justify-content: center; text-align: left; line-height: 1.05; }" +
      ".code { font-family: Consolas, monospace; font-size: 11px; font-weight: 800; }" +
      ".mat { font-size: 10px; font-weight: 800; }" +
      ".size { font-size: 9px; font-weight: 700; }" +
      ".loc { font-size: 8px; font-weight: 600; }"
    );
  }
  return (
    page +
    ".label { width: " +
    tape.w +
    "; height: " +
    tape.h +
    "; box-sizing: border-box; padding: 0.08in 0.06in; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; overflow: hidden; font-family: Arial, Helvetica, sans-serif; page-break-after: always; break-after: page; }" +
    last +
    ".name { font-size: 7px; font-weight: 700; letter-spacing: 0.03em; }" +
    ".code { font-family: Consolas, monospace; font-size: 9px; font-weight: 700; margin-top: 0.03in; }" +
    ".qr { width: 0.9in; height: 0.9in; object-fit: contain; margin: 0.05in 0; }" +
    ".mat { font-size: 8px; font-weight: 700; }" +
    ".size { font-size: 7px; }" +
    ".loc { font-size: 6px; margin-top: 0.02in; }"
  );
}

function labelHtml(item: StockLabelItem, compact: boolean) {
  const qr = item.qrDataUrl
    ? '<img class="qr" src="' + item.qrDataUrl + '" alt=""/>'
    : "";
  const loc = item.line3 ? '<div class="loc">' + esc(item.line3) + "</div>" : "";
  if (compact) {
    return (
      '<div class="label">' +
      qr +
      '<div class="text">' +
      '<div class="code">' +
      esc(item.barcode) +
      "</div>" +
      '<div class="mat">' +
      esc(item.line1) +
      "</div>" +
      '<div class="size">' +
      esc(item.line2) +
      "</div>" +
      loc +
      "</div></div>"
    );
  }
  return (
    '<div class="label">' +
    '<div class="name">LAKE COUNTRY MACHINE</div>' +
    '<div class="code">' +
    esc(item.barcode) +
    "</div>" +
    qr +
    '<div class="mat">' +
    esc(item.line1) +
    "</div>" +
    '<div class="size">' +
    esc(item.line2) +
    "</div>" +
    loc +
    "</div>"
  );
}

function openPrintHtml(html: string): { ok: boolean; error?: string } {
  const w = window.open("", "_blank", "noopener,noreferrer,width=480,height=640");
  if (!w) {
    return { ok: false, error: "Pop-up blocked — allow pop-ups for LCM, then try again" };
  }
  w.document.open();
  w.document.write(html);
  w.document.close();
  return { ok: true };
}

export function printBrotherSampleLabel(opts: {
  tapeId: string;
  barcode: string;
  qrDataUrl: string;
  line1: string;
  line2: string;
}): { ok: boolean; error?: string } {
  return printBrotherStockLabels(opts.tapeId, [
    {
      barcode: opts.barcode,
      qrDataUrl: opts.qrDataUrl,
      line1: opts.line1,
      line2: opts.line2,
    },
  ]);
}

export function printBrotherStockLabels(
  tapeId: string,
  items: StockLabelItem[],
): { ok: boolean; error?: string } {
  if (!items.length) return { ok: false, error: "No labels to print" };
  const tape = tapeById(tapeId);
  const title = items.length === 1 ? items[0]!.barcode : String(items.length) + " stock labels";
  const body = items.map((item) => labelHtml(item, isCompact(tape))).join("");
  const html =
    "<!doctype html><html><head><meta charset=\"utf-8\"/><title>" +
    esc(title) +
    "</title><style>" +
    labelCss(tape) +
    "</style></head><body>" +
    body +
    "<script>window.onload=function(){setTimeout(function(){window.print();},300);};</script></body></html>";
  return openPrintHtml(html);
}
