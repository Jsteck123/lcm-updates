import type { PageHowToDoc } from "./types";

export const loadLanesHowTo: PageHowToDoc = {
  id: "load-lanes",
  path: "/lanes",
  title: "Load lanes",
  tab: "lanes",
  audience: "admin",
  whatThisPageIs:
    "Office lookahead: each person (or machine) is a lane. Jobs they already hold are stacked as quoted-hour blocks on the next work days, soonest ship first. Use it to tell a customer where a rush might fit. It does not start a timer and it does not replace Ship Calendar. Admin only.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "A block’s width is quote setup + run × leftover qty — the same hours as Assign Queue charts. Jobs with no quote still show on the lane list as “no quote” but they do not draw a bar and they do not eat squeeze math.",
        },
        {
          type: "p",
          text: "Order is: whatever is already on a machine first, then soonest due date, then part number. That is due-date order, not a promised 7:32 start. Operators still pull.",
        },
        {
          type: "note",
          text: "The window is the next five weekdays from today (or next Monday if you open this on Saturday). Previous / next week steps that window by seven days. This week jumps back to now.",
        },
        {
          type: "warn",
          text: "A hole is leftover hours after the stack on that day. It is quoted, on pace — not a promise. Setup overrun, lunch, and unquoted work are not in the bar.",
        },
      ],
    },
    {
      title: "Top of the page",
      blocks: [
        {
          type: "control",
          name: "Load lanes",
          does: "Title. Subtitle points at Ship Calendar (when it leaves) and Assign Queue (who gets the part).",
        },
        {
          type: "control",
          name: "Legend",
          does: "On machine (blue) = loaded / running. Assigned (green) = handed or pulled, not on a clock. Due ≤2 days (amber). Misses due (red) = even on quote the stack finishes after the ship date.",
        },
        {
          type: "control",
          name: "People / Machines",
          does: "People is the phone-call view. Active shop people always appear, even if empty (that empty lane is a hole). James/Pam and other unused admins stay off the grid unless they already hold a job. Machines is the same stack by floor-list station. Names not on your machine list (old quote nicknames) do not get a machine lane. Jobs with no station sit on No machine.",
        },
        {
          type: "control",
          name: "This week / arrows",
          does: "Move the five-weekday window. This week resets to today.",
        },
        {
          type: "control",
          name: "Hours",
          does: "Type the rush hours (2.4). First hole uses this number.",
        },
        {
          type: "control",
          name: "Or P/N",
          does: "If Hours is empty, hours come from the quote book for that part at qty 1. Shows “Quote Nh” when a quote exists.",
        },
        {
          type: "control",
          name: "First hole",
          does: "Green strip: First hole {n}h · {weekday date} · {person or machine} · {open}h open that day. Quoted, on pace — not a promise. If nothing fits: “No {n}h hole in this window — try next week, or a different person.”",
        },
      ],
    },
    {
      title: "The grid",
      blocks: [
        {
          type: "control",
          name: "Lane name",
          does: "Person or machine. Under it: {n}h booked and how many no-quote chips.",
        },
        {
          type: "control",
          name: "Day cells",
          does: "Mon–Fri (or the five weekdays in the window). Blocks sit in the day they consume. A job longer than one shift spills into the next day. Hover a block: P/N · hours · due · misses due if it overruns the ship date.",
        },
        {
          type: "control",
          name: "hole",
          does: "Dashed mark on the day Find hole picked for that lane.",
        },
        {
          type: "control",
          name: "Tap a lane",
          does: "Opens the job list under the grid. Tap again to close.",
        },
      ],
    },
    {
      title: "Lane list",
      blocks: [
        {
          type: "p",
          text: "Each row: P/N, PO, customer, machine if named, due, quoted hours or “no quote”, and a badge — On machine / Pulled / Assigned.",
        },
        {
          type: "note",
          text: "Hours shrink later only if leftover qty drops (they finish / Confirm stop). Good-so-far taps do not rewrite this stack yet.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "ol",
          items: [
            "Customer asks if you can sneak a job in.",
            "Open Load lanes.",
            "Type the quoted hours, or the P/N if it is already in the quote book.",
            "Read First hole — day and person (or machine).",
            "If that is acceptable, Assign Queue that person the usual way. This page does not assign.",
            "Friday pack / delivery still lives on Ship Calendar.",
          ],
        },
      ],
    },
  ],
};
