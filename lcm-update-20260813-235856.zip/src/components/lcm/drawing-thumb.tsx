import { useEffect, useRef, useState, type MouseEvent } from "react";
import { toast } from "sonner";
import type { LineFileRef } from "@/lib/lcm/types";
import { loadDrawingPreview } from "@/lib/lcm/drawing-preview";
import { openPoAttachment } from "@/lib/lcm/open-attachment";
import { cn } from "@/lib/utils";

/** Small clickable drawing preview. Stops parent link/card clicks. */
export function DrawingThumb({
  file,
  className,
}: {
  file?: LineFileRef | null;
  className?: string;
}) {
  const ref = useRef<HTMLButtonElement>(null);
  const [visible, setVisible] = useState(false);
  const [src, setSrc] = useState("");

  useEffect(() => {
    const el = ref.current;
    if (!el || !file?.id) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) setVisible(true);
      },
      { rootMargin: "80px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [file?.id]);

  useEffect(() => {
    if (!visible || !file?.id) return;
    let cancelled = false;
    void loadDrawingPreview(file.id, file.name, { ghost: false }).then((url) => {
      if (!cancelled && url) setSrc(url);
    });
    return () => {
      cancelled = true;
    };
  }, [visible, file?.id, file?.name]);

  if (!file?.id) return null;

  async function open(e: MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    const r = await openPoAttachment({
      id: file!.id,
      name: file!.name || "drawing",
    });
    if (!r.ok) toast.error(r.error || "Could not open drawing");
  }

  return (
    <button
      ref={ref}
      type="button"
      title="Open drawing"
      className={cn("drawing-thumb", className)}
      onClick={(e) => void open(e)}
    >
      {src ? <img src={src} alt="" /> : <span className="drawing-thumb-empty" />}
    </button>
  );
}
