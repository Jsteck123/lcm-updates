import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/input";
import { CreatableSelect } from "@/components/ui/creatable-select";
import { SmartNumberInput } from "@/components/ui/smart-number-input";
import {
  EMPTY_GUIDED_MATERIAL,
  type GuidedMaterialValue,
} from "@/components/lcm/guided-material-form";
import {
  axisLabels,
  canonicalizeShape,
  defaultLocAxis,
  describeStock,
  guessProcess,
  locChoices,
  locValue,
} from "@/lib/lcm/stock-standard";
import { allMaterialTypes } from "@/lib/lcm/lists";
import { cn } from "@/lib/utils";
import type { CustomLists } from "@/lib/lcm/types";

type StepId =
  | "material"
  | "type"
  | "shape"
  | "process"
  | "size"
  | "loc"
  | "review";

const JOB_STEPS: StepId[] = [
  "material",
  "type",
  "shape",
  "process",
  "size",
  "loc",
  "review",
];
const INV_STEPS: StepId[] = [
  "material",
  "type",
  "shape",
  "process",
  "size",
  "review",
];

const TITLES: Record<StepId, string> = {
  material: "Material",
  type: "Material type",
  shape: "Stock shape",
  process: "Mill or lathe",
  size: "Size in the machine",
  loc: "Length of cut (LOC)",
  review: "Check stock",
};

export function GuidedMaterialTour({
  open,
  title,
  value,
  onChange,
  onClose,
  onDone,
  materialOptions,
  shapeOptions,
  customLists,
  onCreateMaterial,
  onCreateType,
  onCreateShape,
  machines,
  mode = "job",
}: {
  open: boolean;
  title?: string;
  value: GuidedMaterialValue;
  onChange: (next: GuidedMaterialValue) => void;
  onClose: () => void;
  onDone?: (next: GuidedMaterialValue) => void;
  materialOptions: string[];
  shapeOptions: string[];
  customLists?: CustomLists;
  onCreateMaterial?: (name: string) => boolean | void;
  onCreateType?: (name: string) => boolean | void;
  onCreateShape?: (name: string) => boolean | void;
  machines?: string[];
  mode?: "job" | "quote" | "inventory";
}) {
  const steps = mode === "inventory" ? INV_STEPS : JOB_STEPS;
  const [i, setI] = useState(0);
  useEffect(() => {
    if (open) setI(0);
  }, [open]);
  if (!open) return null;

  const step = steps[Math.min(i, steps.length - 1)]!;
  const typeOptions = allMaterialTypes(value.material || "Aluminum", customLists);
  const process =
    value.stockProcess ||
    guessProcess({
      process: value.stockProcess,
      machines,
      stockShape: value.stockShape,
    });
  const loc = (value.locAxis || defaultLocAxis(value.stockShape, process)) as
    | "x"
    | "y"
    | "z"
    | "dia";
  const labels = axisLabels(value.stockShape, process);
  const lathe = process === "lathe";
  const axes: ("x" | "y" | "z")[] = lathe ? ["x", "z"] : ["x", "y", "z"];

  function patch(p: Partial<GuidedMaterialValue>) {
    const next = { ...value, ...p };
    if (p.stockShape != null) next.stockShape = canonicalizeShape(p.stockShape);
    if (p.stockProcess === "lathe") {
      next.locAxis = "z";
      next.dimY = 0;
    }
    if (p.partLengthEach != null && p.partLengthEach > 0) {
      const axis = (next.locAxis || loc) as "x" | "y" | "z" | "dia";
      if (axis === "x") next.dimX = p.partLengthEach;
      if (axis === "y") next.dimY = p.partLengthEach;
      if (axis === "z") next.dimZ = p.partLengthEach;
    }
    onChange(next);
  }

  function canNext() {
    if (step === "material") return Boolean(value.material.trim());
    if (step === "shape") return Boolean(canonicalizeShape(value.stockShape));
    if (step === "process") return process === "mill" || process === "lathe";
    return true;
  }

  return (
    <div
      className="fixed inset-0 z-[90] flex items-end sm:items-center justify-center bg-black/65 p-3 sm:p-4 print:hidden"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md max-h-[92vh] overflow-y-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 space-y-4 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div>
          <p className="text-[11px] uppercase tracking-wide text-[var(--color-muted)]">
            {title || "Stock"} · {i + 1} of {steps.length}
          </p>
          <h2 className="text-lg font-semibold mt-0.5">{TITLES[step]}</h2>
        </div>
        <div className="flex gap-1">
          {steps.map((s, n) => (
            <span
              key={s}
              className={cn(
                "h-1.5 flex-1 rounded-full",
                n <= i
                  ? "bg-[var(--color-primary)]"
                  : "bg-[var(--color-surface-3)]",
              )}
            />
          ))}
        </div>

        {step === "material" && (
          <div className="space-y-2">
            <Label>What material?</Label>
            <CreatableSelect
              value={value.material}
              options={materialOptions}
              onChange={(v) =>
                patch({
                  material: v,
                  materialType: v !== value.material ? "" : value.materialType,
                })
              }
              onCreate={(v) => {
                if (onCreateMaterial?.(v) === false) return false;
                patch({ material: v, materialType: "" });
                return true;
              }}
              createTitle="Add material"
            />
          </div>
        )}

        {step === "type" && (
          <div className="space-y-2">
            <Label>Material type / temper</Label>
            <CreatableSelect
              value={value.materialType}
              options={typeOptions}
              onChange={(v) => patch({ materialType: v })}
              onCreate={(v) => {
                if (onCreateType?.(v) === false) return false;
                patch({ materialType: v });
                return true;
              }}
              createTitle="Add type"
            />
          </div>
        )}

        {step === "shape" && (
          <div className="space-y-2">
            <Label>Stock shape</Label>
            <CreatableSelect
              value={canonicalizeShape(value.stockShape)}
              options={shapeOptions}
              onChange={(v) => patch({ stockShape: v })}
              onCreate={(v) => {
                if (onCreateShape?.(v) === false) return false;
                patch({ stockShape: v });
                return true;
              }}
              createTitle="Add shape"
            />
          </div>
        )}

        {step === "process" && (
          <div className="space-y-2">
            <p className="text-sm text-[var(--color-muted)]">
              How does this blank sit in the machine?
            </p>
            <div className="grid gap-2">
              {(
                [
                  ["mill", "Mill", "X Y Z as it sits in the vise"],
                  ["lathe", "Lathe", "X is diameter. Z is length of cut."],
                ] as const
              ).map(([id, name, hint]) => (
                <button
                  key={id}
                  type="button"
                  className={cn(
                    "min-h-14 rounded-[var(--radius-md)] border px-3 py-2 text-left",
                    process === id
                      ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_12%,transparent)]"
                      : "border-[var(--color-border)]",
                  )}
                  onClick={() => patch({ stockProcess: id })}
                >
                  <div className="font-semibold">{name}</div>
                  <div className="text-xs text-[var(--color-muted)]">{hint}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === "size" && (
          <div className="space-y-3">
            <p className="text-sm text-[var(--color-muted)] leading-snug">
              Stock blank in the machine — not the finished model.
              {lathe
                ? " X = diameter. Z = length (you set LOC next)."
                : " Enter X Y Z as it sits in the vise."}
            </p>
            <div className={lathe ? "grid grid-cols-2 gap-2" : "grid grid-cols-3 gap-2"}>
              {axes.map((axis) => {
                const key =
                  axis === "x" ? "dimX" : axis === "y" ? "dimY" : "dimZ";
                return (
                  <div key={axis} className="space-y-1">
                    <Label className="text-[10px] leading-tight">
                      {labels[axis]}
                    </Label>
                    <SmartNumberInput
                      format="inches"
                      value={Number(value[key]) || 0}
                      placeholder="—"
                      onValueChange={(n) => patch({ [key]: n })}
                    />
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {step === "loc" && (
          <div className="space-y-3">
            <p className="text-sm text-[var(--color-muted)] leading-snug">
              LOC is <strong className="text-[var(--color-fg)]">length of cut</strong>{" "}
              — the axis the saw cuts, and how long that cut is. Model 3"? Cut
              3.1" so you can take .05" off each end. Do not pick a face that
              must stay stock.
            </p>
            {!lathe && (
              <div className="grid gap-1.5">
                {locChoices(value.stockShape, process).map((c) => (
                  <label
                    key={c.axis}
                    className={cn(
                      "flex items-start gap-2 rounded-[var(--radius-md)] border px-2.5 py-2 text-sm min-h-11 cursor-pointer",
                      loc === c.axis
                        ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_10%,transparent)]"
                        : "border-[var(--color-border)]",
                    )}
                  >
                    <input
                      type="radio"
                      className="mt-1"
                      name="lcm-loc-tour"
                      checked={loc === c.axis}
                      onChange={() =>
                        patch({
                          locAxis: c.axis,
                          partLengthEach:
                            locValue(c.axis, value) || value.partLengthEach,
                        })
                      }
                    />
                    <span>{c.label}</span>
                  </label>
                ))}
              </div>
            )}
            <div className="space-y-1">
              <Label>
                Length of cut
                {loc && loc !== "dia" ? ` (${loc.toUpperCase()})` : ""} "
              </Label>
              <SmartNumberInput
                format="inches"
                value={value.partLengthEach || locValue(loc, value) || 0}
                placeholder="e.g. 3.1"
                onValueChange={(partLengthEach) => patch({ partLengthEach })}
              />
            </div>
            <div className="space-y-1">
              <Label>Full bar on the rack (")</Label>
              <SmartNumberInput
                format="inches"
                value={value.rawMaterialLength || 0}
                placeholder="144"
                onValueChange={(rawMaterialLength) =>
                  patch({ rawMaterialLength })
                }
              />
            </div>
          </div>
        )}

        {step === "review" && (
          <p className="text-sm rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-3 leading-relaxed">
            {describeStock({ ...value, locAxis: loc, stockProcess: process }) ||
              "Nothing entered yet."}
          </p>
        )}

        <div className="flex justify-between gap-2 pt-1">
          <Button
            type="button"
            variant="ghost"
            onClick={() => (i === 0 ? onClose() : setI((n) => n - 1))}
          >
            {i === 0 ? "Cancel" : "Back"}
          </Button>
          {step === "review" ? (
            <Button
              type="button"
              onClick={() => {
                onDone?.(value);
                onClose();
              }}
            >
              Done
            </Button>
          ) : (
            <Button
              type="button"
              disabled={!canNext()}
              onClick={() => setI((n) => Math.min(n + 1, steps.length - 1))}
            >
              Next
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

export function stockValueFrom(partial: Partial<GuidedMaterialValue>): GuidedMaterialValue {
  return { ...EMPTY_GUIDED_MATERIAL, ...partial };
}

export function StockPickButton({
  label = "Pick stock",
  summary,
  onClick,
}: {
  label?: string;
  summary?: string;
  onClick: () => void;
}) {
  return (
    <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-2">
      {summary ? (
        <p className="text-sm leading-snug">{summary}</p>
      ) : (
        <p className="text-sm text-[var(--color-muted)]">No stock picked yet.</p>
      )}
      <Button type="button" onClick={onClick}>
        {label}
      </Button>
    </div>
  );
}