/**
 * Build a zip from a folder in Node (Windows shop PCs have Node, often not Python).
 * ZIP timestamps only allow 1980–2107 — clamp so old/future file dates cannot crash.
 */
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";

function ensureDir(p: string) {
  fs.mkdirSync(p, { recursive: true });
}

/** MS-DOS date/time. ZIP rejects dates before 1980-01-01. */
function dosDateTime(d: Date): { time: number; date: number } {
  let year = d.getFullYear();
  let month = d.getMonth() + 1;
  let day = d.getDate();
  let hours = d.getHours();
  let minutes = d.getMinutes();
  let seconds = Math.floor(d.getSeconds() / 2);
  if (!Number.isFinite(year) || year < 1980) {
    year = 1980;
    month = 1;
    day = 1;
    hours = 0;
    minutes = 0;
    seconds = 0;
  }
  if (year > 2107) {
    year = 2107;
    month = 12;
    day = 31;
  }
  const date = ((year - 1980) << 9) | (month << 5) | day;
  const time = (hours << 11) | (minutes << 5) | seconds;
  return { time, date };
}

type ZipEntry = {
  name: string;
  crc: number;
  method: number;
  compSize: number;
  uncompSize: number;
  time: number;
  date: number;
  localOffset: number;
};

function walkFiles(dir: string, rel = "", acc: { abs: string; rel: string }[] = []) {
  if (!fs.existsSync(dir)) return acc;
  for (const name of fs.readdirSync(dir)) {
    const abs = path.join(dir, name);
    const nextRel = rel ? `${rel}/${name}` : name;
    let st: fs.Stats;
    try {
      st = fs.statSync(abs);
    } catch {
      continue;
    }
    if (st.isDirectory()) {
      walkFiles(abs, nextRel, acc);
    } else if (st.isFile()) {
      acc.push({ abs, rel: nextRel.replace(/\\/g, "/") });
    }
  }
  return acc;
}

function u16(n: number) {
  const b = Buffer.alloc(2);
  b.writeUInt16LE(n >>> 0, 0);
  return b;
}
function u32(n: number) {
  const b = Buffer.alloc(4);
  b.writeUInt32LE(n >>> 0, 0);
  return b;
}

/**
 * Zip every file under srcDir into outZip (deflate). Overwrites outZip.
 */
export function createZipFromFolder(
  srcDir: string,
  outZip: string,
): { ok: true; files: number } | { ok: false; error: string } {
  try {
    const files = walkFiles(srcDir);
    if (!files.length) return { ok: false, error: "Nothing to zip" };
    ensureDir(path.dirname(outZip));
    if (fs.existsSync(outZip)) fs.unlinkSync(outZip);

    const fd = fs.openSync(outZip, "w");
    const entries: ZipEntry[] = [];
    let offset = 0;

    const write = (buf: Buffer) => {
      fs.writeSync(fd, buf);
      offset += buf.length;
    };

    for (const f of files) {
      let raw: Buffer;
      try {
        raw = fs.readFileSync(f.abs);
      } catch (e) {
        fs.closeSync(fd);
        try {
          fs.unlinkSync(outZip);
        } catch {
          /* ignore */
        }
        return {
          ok: false,
          error: `Could not read ${f.rel}: ${e instanceof Error ? e.message : "error"}`,
        };
      }
      const crc = zlib.crc32(raw) >>> 0;
      let method = 8;
      let payload: Buffer;
      if (raw.length === 0) {
        method = 0;
        payload = raw;
      } else {
        try {
          payload = zlib.deflateRawSync(raw, { level: 6 });
          if (payload.length >= raw.length) {
            method = 0;
            payload = raw;
          }
        } catch {
          method = 0;
          payload = raw;
        }
      }
      let mtime = new Date();
      try {
        mtime = fs.statSync(f.abs).mtime;
      } catch {
        /* now */
      }
      const { time, date } = dosDateTime(mtime);
      const nameBuf = Buffer.from(f.rel, "utf8");
      const localOffset = offset;
      const flags = 0x0800; // UTF-8 names
      write(Buffer.from([0x50, 0x4b, 0x03, 0x04]));
      write(u16(20));
      write(u16(flags));
      write(u16(method));
      write(u16(time));
      write(u16(date));
      write(u32(crc));
      write(u32(payload.length));
      write(u32(raw.length));
      write(u16(nameBuf.length));
      write(u16(0));
      write(nameBuf);
      write(payload);
      entries.push({
        name: f.rel,
        crc,
        method,
        compSize: payload.length,
        uncompSize: raw.length,
        time,
        date,
        localOffset,
      });
    }

    const cdStart = offset;
    for (const e of entries) {
      const nameBuf = Buffer.from(e.name, "utf8");
      write(Buffer.from([0x50, 0x4b, 0x01, 0x02]));
      write(u16(20)); // made by
      write(u16(20)); // needed
      write(u16(0x0800));
      write(u16(e.method));
      write(u16(e.time));
      write(u16(e.date));
      write(u32(e.crc));
      write(u32(e.compSize));
      write(u32(e.uncompSize));
      write(u16(nameBuf.length));
      write(u16(0));
      write(u16(0));
      write(u16(0));
      write(u16(0));
      write(u32(0));
      write(u32(e.localOffset));
      write(nameBuf);
    }
    const cdSize = offset - cdStart;
    write(Buffer.from([0x50, 0x4b, 0x05, 0x06]));
    write(u16(0));
    write(u16(0));
    write(u16(entries.length));
    write(u16(entries.length));
    write(u32(cdSize));
    write(u32(cdStart));
    write(u16(0));
    fs.closeSync(fd);
    return { ok: true, files: entries.length };
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : "Zip failed",
    };
  }
}
