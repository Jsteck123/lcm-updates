import type { PageHowToDoc } from "./types";

export const settingsHowTo: PageHowToDoc = {
  id: "settings",
  path: "/settings",
  title: "Settings",
  audience: "admin",
  tab: "settings",
  whatThisPageIs:
    "Office desk for people, PINs, tab access, shop network, bonus day, material $/lb, logo, Beta vs Production, backups, USB dump, shop averages, and the audit log. Admins always keep this tab so they cannot lock themselves out. Money and payouts stay here and on Reports. Program updates never include shop data. Backups are how you sleep at night.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "Titles only until you tap one — that section opens and the others stay shut. Tap the same title again to close it. Most writes are live (network URL, customers, logo, Beta). Some need an explicit save: Save PIN, Save settings (shifts / tiers / max ops / edit password), Save average rules. Host backups and USB need this PC unlocked with an admin PIN.",
        },
        {
          type: "control",
          name: "Section title",
          does: "One row per Settings block (Update app, Shop network, Operators, backups, …). Closed = title only. Tap to expand just that window. Tap again to collapse. Opening another title closes the one that was open.",
        },
        {
          type: "p",
          text: "Shop logins can open Settings only if office left the tab on, but they cannot add operators, import quotes, update the app, change the logo, switch Production, reset, or build backups. Those cards say Admin only — switch to an admin account…",
        },
        {
          type: "warn",
          text: "Never treat an update zip as a backup. Never treat a backup zip as an Update app file. Update replaces program files only (src/, UI, scripts). data/ (quotes, inventory, orders, drawings, logo) is never touched. Reset demo data wipes live shop data on every PC — type RESET first.",
        },
        {
          type: "note",
          text: "Recover shop (/recover) is the same host backup folder when this page will not load. Beta cleanup desk closes leftover practice clocks without deleting records.",
        },
      ],
    },
    {
      title: "Beta cleanup desk",
      blocks: [
        {
          type: "control",
          name: "Beta cleanup desk",
          does: "Admin card. Close leftover practice clocks, unpack half-finished POs, and keep TEST jobs out of averages. Nothing is deleted.",
        },
        {
          type: "control",
          name: "Open cleanup desk",
          does: "Opens /cleanup. Full how-to is Beta cleanup desk in this book.",
        },
      ],
    },
    {
      title: "Update app",
      blocks: [
        {
          type: "control",
          name: "Update app",
          does: "Install a new version from an lcm-update-*.zip package (the file from chat). Replaces program files only — shop database under data/ is never touched. A safety backup is taken first.",
        },
        {
          type: "control",
          name: "Installed package",
          does: "Current version, or base install. Applied [when] · note when the host has logged an install.",
        },
        {
          type: "control",
          name: "What’s new",
          does: "Changelog rows on this card (version + note). Same notes the header What’s new dialog shows.",
        },
        {
          type: "ol",
          items: [
            "Download the lcm-update-*.zip we send you.",
            "Click Update app and choose that zip (about 0.5 MB).",
            "Confirm — only program files are replaced (never the database).",
            "Restart from Restart LCM below (or reboot this PC). Other screens tap Refresh when ready.",
          ],
        },
        {
          type: "note",
          text: "If Update says unzip failed (older installs on Windows): copy the zip into the app folder and run node scripts/apply-lcm-update.mjs lcm-update-….zip from that folder, then restart the app once. Newer packages fix in-app update so next time Settings works.",
        },
        {
          type: "control",
          name: "Update app…",
          does: "Opens Install app update. Select the lcm-update-…zip. Your shop database will not be replaced. A host backup is created first when possible.",
        },
        {
          type: "control",
          name: "Update package",
          does: "File picker on the dialog. Accepts .zip. Shows Selected: name (KB).",
        },
        {
          type: "control",
          name: "Cancel",
          does: "Closes Install app update without installing.",
        },
        {
          type: "control",
          name: "Install update",
          does: "Runs the zip. Busy: Installing…. Floor stations then show Refresh when ready. Safe: updates src/, UI, scripts, config. Never overwrites quotes, inventory, orders, or drawings.",
        },
        {
          type: "control",
          name: "Restart LCM",
          does: "Restarts the shop host process. Busy: Restarting…. Use after a successful install. Other screens refresh; they do not lose jobs.",
        },
        {
          type: "control",
          name: "Editor mode",
          does: "Same as the header Editor pill. Lights as Editor on. Remove stale jobs from the board and queues. Does not delete POs.",
        },
        {
          type: "control",
          name: "Editor on",
          does: "Editor mode is active. Tap again to turn it off.",
        },
        {
          type: "control",
          name: "Download update zip",
          does: "Shown only when the host is serving /lcm-update-latest.zip (copied there after a successful install). Downloads that package under the real version name. Not a data backup.",
        },
        {
          type: "control",
          name: "Refresh status",
          does: "Re-reads installed version and changelog from the host.",
        },
      ],
    },
    {
      title: "Shop network + Label / phone address",
      blocks: [
        {
          type: "control",
          name: "Shop network (LAN)",
          does: "One PC hosts the app. Every other computer on your network opens that PC address in a browser. All data lives in one file on the host — jobs, quotes, timers update live for everyone. Screens check for changes every few seconds and only download the shop when something actually changed.",
        },
        {
          type: "control",
          name: "Status",
          does: "Connected · revision N, or the error, or Connecting…. Mode: Shared shop database or Local fallback.",
        },
        {
          type: "ol",
          items: [
            "Pick one always-on shop PC as the host (office desktop or small server).",
            "Run this app on the host so it listens on the network (port 8080).",
            "On the host, open a command prompt and run ipconfig — note the IPv4 address (e.g. 192.168.1.50).",
            "On every other PC / tablet, open Edge or Chrome to http://192.168.x.x:8080 (use your host IP).",
            "Windows Firewall: allow the app / port 8080 on the host (Private network).",
          ],
        },
        {
          type: "control",
          name: "Label / phone address",
          does: "QR codes open this host + /scan?c=the sticker code. Type only the host (http://10.x.x.x:8080), not Ship Calendar or any other page. Saved as origin only. Reprint labels after you change it.",
        },
        {
          type: "p",
          text: "Database file on the host: data/lcm-shop.json — back that file up. Only run one host; everyone else connects to it.",
        },
      ],
    },
    {
      title: "Who am I",
      blocks: [
        {
          type: "control",
          name: "Who am I? (this station)",
          does: "Signed-in user stays on this PC only. Shop data is shared; identity is not.",
        },
        {
          type: "control",
          name: "Signed in as",
          does: "Same list as sidebar Switch user (active people). Admins show (Admin). Changing it here does not ask for a PIN — use the sidebar Switch user when you need the PIN gate.",
        },
      ],
    },
    {
      title: "Operators & access + PIN + tab chips",
      blocks: [
        {
          type: "control",
          name: "Operators & access",
          does: "Who can open Quoting, Email, Settings, etc. Admins need a PIN. Money tabs cannot stay on an operator.",
        },
        {
          type: "control",
          name: "Name",
          does: "New person display name. Admin add row.",
        },
        {
          type: "control",
          name: "email@shop.com",
          does: "Login email. Must be unique. This is what Switch user and Recover shop use.",
        },
        {
          type: "control",
          name: "Operator",
          does: "Role. Shop login. Money tabs (Quoting, Parts & Quotes, Email Quotes, Reports) are stripped even if you try to chip them on. Assign Queue is admin-only.",
        },
        {
          type: "control",
          name: "Admin",
          does: "Role. Always keeps Settings and Assign Queue. Always requires a PIN to switch.",
        },
        {
          type: "control",
          name: "PIN (optional)",
          does: "PIN on the add row. Optional for operators. Admins should get one immediately (Save PIN on the card).",
        },
        {
          type: "control",
          name: "Add",
          does: "Creates the operator. Then set tab chips and Save PIN on their card.",
        },
        {
          type: "control",
          name: "Remove",
          does: "Trash on that person. Hidden on yourself so you cannot delete the signed-in account.",
        },
        {
          type: "p",
          text: "Tab chips are the exact sidebar labels. Tap to toggle. On = that person may open the tab. Off = it is hidden. Admin Settings chip cannot be turned off. Operator cards never show money-tab chips.",
        },
        {
          type: "ul",
          items: [
            "Dashboard",
            "Shop Floor",
            "Job History",
            "Quoting (admin / money)",
            "Parts & Quotes (admin / money)",
            "Inventory / Buy",
            "Customer Orders",
            "Assign Queue (admin)",
            "Ship Calendar",
            "Job Board",
            "Active Jobs",
            "Saw / Cut queue",
            "Feedback (always kept on everyone)",
            "Email Quotes (admin / money)",
            "Reports (admin / money)",
            "Settings (admins always keep)",
          ],
        },
        {
          type: "control",
          name: "PIN",
          does: "Per-person box. Label is PIN (required) when that person already has / needs a PIN (every admin). Placeholder •••• if set, none if not. Type the new number; it does not show the old one.",
        },
        {
          type: "control",
          name: "PIN (required)",
          does: "Same box when requiresPinToSwitch is true for that person.",
        },
        {
          type: "control",
          name: "Save PIN",
          does: "Writes the typed PIN. Empty Save on an operator can clear a shop PIN (open switch). Admins should not be left without a PIN.",
        },
      ],
    },
    {
      title: "Customers & emails",
      blocks: [
        {
          type: "control",
          name: "Customers & emails",
          does: "Names Email Quotes should offer, plus the From display on the letter.",
        },
        {
          type: "control",
          name: "Customer name",
          does: "Add-row box. Plus button adds the customer.",
        },
        {
          type: "control",
          name: "Primary email for quotes",
          does: "Per-customer email. Email Quotes uses this list (plus extras saved from Or type email → Save).",
        },
        {
          type: "control",
          name: "Remove",
          does: "Trash on that customer.",
        },
        {
          type: "control",
          name: "Quote From email (display)",
          does: "From (your shop) on Email Quotes. Placeholder you@lakecountrymachine.com. Display / .eml From — not a mailbox login.",
        },
      ],
    },
    {
      title: "Shifts & bonus",
      blocks: [
        {
          type: "control",
          name: "Shifts & bonus",
          does: "Day and night each have their own window. Bonus only counts work inside that shift (overnight night shift OK). Full shift required. Lunch excluded. Paid weekly — not per job.",
        },
        {
          type: "p",
          text: "Each shift card is titled [name] shift · start–end, with (overnight) when the window crosses midnight.",
        },
        {
          type: "control",
          name: "Enabled",
          does: "Include that shift in bonus math. Admin only.",
        },
        {
          type: "control",
          name: "Start",
          does: "Shift start time. Time before this does not count.",
        },
        {
          type: "control",
          name: "End",
          does: "Shift end time. Finalize [shift] on Reports is available after this.",
        },
        {
          type: "control",
          name: "Lunch (hours, unpaid)",
          does: "Excluded so a 7–4 day is 8 hours when lunch is 1.",
        },
        {
          type: "control",
          name: "Hourly rate ($)",
          does: "Admin. Dollars used in the earned-hour pool. Shop logins never see bonus $.",
        },
        {
          type: "control",
          name: "Max operations (OP slots)",
          does: "How many OP columns Master Quoter shows (OP1–OPn). Raise this before you quote a 7th op. Draft until Save settings.",
        },
        {
          type: "control",
          name: "Edit password",
          does: "Legacy edit password field on this card. Draft until Save settings.",
        },
        {
          type: "control",
          name: "Bonus tiers (min efficiency → percentage)",
          does: "Rows of Min eff (1 = 100%) and % of pool. Bonus = earned-hour pool × the matching tier %. Draft until Save settings.",
        },
        {
          type: "control",
          name: "Save settings",
          does: "Writes hourly rate (already live on change), max ops, edit password, and bonus tiers. Do this after you change tiers or OP slots.",
        },
      ],
    },
    {
      title: "LCM material Calculator",
      blocks: [
        {
          type: "control",
          name: "LCM material Calculator",
          does: "Going $/lb for the material calculator. Weights use theoretical lb/ft tables × stock length × this rate. Quotes still store the raw material $ you accept — this book only estimates. Same box on Master Quoter.",
        },
        {
          type: "control",
          name: "Family",
          does: "Aluminum / Steel / Stainless / Other. Matches Material on the quoter.",
        },
        {
          type: "control",
          name: "Grade",
          does: "Grade string the calculator matches to Material type.",
        },
        {
          type: "control",
          name: "$/lb",
          does: "Going rate. Update when the vendor book changes.",
        },
        {
          type: "control",
          name: "Density",
          does: "lb/in³ used when the shape table needs density.",
        },
        {
          type: "control",
          name: "Notes",
          does: "Vendor / date note on that grade.",
        },
        {
          type: "control",
          name: "Add grade",
          does: "New empty Aluminum row (density 0.098) for you to fill.",
        },
        {
          type: "control",
          name: "Restore starter book",
          does: "Puts the built-in starter price book back. Toast: Starter price book restored. Does not change quotes already saved.",
        },
      ],
    },
    {
      title: "Help tips",
      blocks: [
        {
          type: "control",
          name: "Help tips",
          does: "Blue ? icons explain buttons and areas. Hover or tap for details. Hide a tip when you know it — it stays hidden for you on this PC. Full how-to guide: How to use (/help).",
        },
        {
          type: "control",
          name: "Show help tip icons",
          does: "Master checkbox for ? tips on this browser.",
        },
        {
          type: "control",
          name: "Show all tips again",
          does: "Unhides every tip you dismissed. Toast: All help tips restored. Count line: N tip(s) hidden for you, or No tips hidden.",
        },
        {
          type: "control",
          name: "How to use",
          does: "Link to the shop-manual index (same as the header How to use).",
        },
      ],
    },
    {
      title: "Import historical quotes",
      blocks: [
        {
          type: "control",
          name: "Import historical quotes (Google Sheets)",
          does: "Export your Google Sheet DATABASE or Historical Quotes tab as CSV, then import here. Use Update existing to re-import and fix Machine % / Material % (keeps values like 1.1) and blank stock shapes (not forced to Round Stock — missing shape shows yellow).",
        },
        {
          type: "ol",
          items: [
            "Open your Google Sheet with the old LCM data.",
            "Open the DATABASE tab (or Historical Quotes).",
            "File → Download → Comma Separated Values (.csv).",
            "Upload that file below, preview, then Import.",
          ],
        },
        {
          type: "control",
          name: "If part # + rev already exists",
          does: "Update existing (recommended) / Skip duplicates / Keep both rows.",
        },
        {
          type: "control",
          name: "Update existing (recommended)",
          does: "Re-import overwrites the matching part+rev (Machine %, Material %, stock, times). Does not invent a shape when the sheet left it blank.",
        },
        {
          type: "control",
          name: "Skip duplicates",
          does: "Leaves the live quote alone when part+rev already exists.",
        },
        {
          type: "control",
          name: "Keep both rows",
          does: "Imports another row even if part+rev exists.",
        },
        {
          type: "control",
          name: "CSV file from Google Sheets",
          does: "File picker. Builds Preview: N part row(s) · app currently has M quotes, plus a sample list and any parse errors.",
        },
        {
          type: "control",
          name: "Import into database",
          does: "Writes the preview into the live quote book and flushes to the host. Busy: Working…. Other PCs refresh in a few seconds. Disabled until a preview has rows.",
        },
        {
          type: "control",
          name: "Sample CSV format",
          does: "Downloads lcm-historical-quotes-sample.csv so you can match columns.",
        },
        {
          type: "note",
          text: "Tip: use Export JSON under Backup first. Times can be HH:MM:SS or decimal minutes. Machine % / Material % use 1 = cost, 1.25 = 25% markup (same as the old sheet).",
        },
      ],
    },
    {
      title: "Company logo",
      blocks: [
        {
          type: "control",
          name: "Company logo",
          does: "Upload your real logo (PNG or JPG). Used on Sales Orders, the sidebar, and printouts. Stored on the shop host under data/branding/ so app updates do not wipe it.",
        },
        {
          type: "control",
          name: "Print / light",
          does: "Preview of the wide logo on a white field (packing slips, quote letters).",
        },
        {
          type: "control",
          name: "App header",
          does: "Preview of the mark used in the sidebar.",
        },
        {
          type: "control",
          name: "Upload logo",
          does: "PNG, JPG, WebP, or SVG. Max 6 MB. Best: transparent PNG, wide letterhead style. Every shop PC uses this file from the host. Busy: Uploading….",
        },
        {
          type: "control",
          name: "Remove custom logo",
          does: "Clears the host file. Using built-in art until you upload. Toast: Custom logo removed — using built-in art.",
        },
      ],
    },
    {
      title: "Beta / Production",
      blocks: [
        {
          type: "control",
          name: "App mode · Beta / Production",
          does: "First shop rollout should stay in Beta. Timers, quotes, inventory, and orders work for real. Bonuses still calculate and show, but you cannot mark them paid until you switch to Production.",
        },
        {
          type: "control",
          name: "Beta (test)",
          does: "Turns Beta on. Header shows BETA. Toast: Beta mode on — bonuses are practice only. Train the crew, import POs, run timers. Mark paid is locked.",
        },
        {
          type: "control",
          name: "Production (live)",
          does: "Confirm: Switch to Production? Weekly bonus Mark paid will count as real payouts. Then live mode. Toast: Production mode — bonuses can be marked paid. Same app, real weekly bonus payouts allowed.",
        },
        {
          type: "p",
          text: "Current: Beta (test) or Production (live) is written under the pills.",
        },
      ],
    },
    {
      title: "Backup & reset",
      blocks: [
        {
          type: "control",
          name: "Backup & reset",
          does: "Export downloads the full live shop slice (quotes, inventory, orders, chat). Prefer Host backups or a USB full backup to restore a PC.",
        },
        {
          type: "control",
          name: "Export JSON",
          does: "Downloads lcm-backup-YYYY-MM-DD.json on this computer. Data only — not a program zip.",
        },
        {
          type: "control",
          name: "Import JSON",
          does: "Reads an Export JSON file back in. Toast: Backup restored. This replaces the live slice you imported — know what file you picked.",
        },
        {
          type: "control",
          name: "Type RESET",
          does: "Enables Reset demo data. Danger: reset wipes live shop data on every PC. Type RESET to enable. Case-sensitive RESET.",
        },
        {
          type: "control",
          name: "Reset demo data",
          does: "Takes a pre-reset host backup when possible, then restores seed data and syncs to all PCs. Disabled until the box is exactly RESET. This is not cleanup — it wipes live work.",
        },
      ],
    },
    {
      title: "Host backups",
      blocks: [
        {
          type: "control",
          name: "Host backups",
          does: "Copies of the live shop database on the office/host PC (last 30, plus one every hour when the shop is saving). Unlock with your PIN on this PC first. Restore only when you mean it — a safety copy is taken first.",
        },
        {
          type: "p",
          text: "If LCM will not open at all, on the host PC open Recover shop or copy the files in data/backups. Download a copy to a USB stick whenever you want one off the machine.",
        },
        {
          type: "control",
          name: "Backup now",
          does: "Creates a manual snapshot on the host. Needs admin PIN session — otherwise: Enter your PIN, then try Backup now again. Toast: Backup created on host.",
        },
        {
          type: "control",
          name: "Refresh list",
          does: "Re-reads host backups and USB full backups. Asks for PIN if this PC has no session.",
        },
        {
          type: "control",
          name: "Download",
          does: "Saves that host JSON onto this computer. Toast: Backup saved on this computer.",
        },
        {
          type: "control",
          name: "Restore",
          does: "Confirm: Restore backup from [when]? Current data will be snapshotted first. Then reloads the page. Admin only.",
        },
        {
          type: "control",
          name: "Recover shop",
          does: "Link to /recover for when Settings itself will not load.",
        },
      ],
    },
    {
      title: "USB full backup",
      blocks: [
        {
          type: "control",
          name: "USB full backup",
          does: "Everything needed to put LCM on a new PC or undo a bad update: the app, shop database, drawings/prints/photos, logo, and the last installed version name. Does not pack node_modules, leftover update zips, or old USB zips (those made the stick jump to ~200 MB). Save the zip to a USB stick.",
        },
        {
          type: "p",
          text: "On a new computer: install Node.js LTS from nodejs.org, unzip the USB file, double-click INSTALL-FROM-USB.cmd. It copies to C:\\LCM and starts the shop. Does not include Node itself — that one install is from the website.",
        },
        {
          type: "control",
          name: "Build & download USB backup",
          does: "Builds the zip on the host and downloads it. Busy: Building USB zip…. Needs admin PIN. Toast includes size in MB — save it to the stick. Label the stick with the date. Keep it off-site or in the office safe. File dates before 1980 (or far in the future) used to crash Windows zip — the host now zips in Node and clamps those dates.",
        },
        {
          type: "control",
          name: "Download",
          does: "Re-downloads a previous USB zip already on the host.",
        },
      ],
    },
    {
      title: "Shop average rules",
      blocks: [
        {
          type: "control",
          name: "Shop average rules",
          does: "How completed jobs update process times on the part (prices never auto-change). Master Quoter Shop evidence explains the effect on Price each.",
        },
        {
          type: "control",
          name: "Runs in average (max)",
          does: "Newest good runs to include (1–50). Default 10. Cleanup may recommend resetting a practice value.",
        },
        {
          type: "control",
          name: "Shop weight (0–1)",
          does: "0.7 = 70% shop avg + 30% prior recipe.",
        },
        {
          type: "control",
          name: "Outlier limit (× quote)",
          does: "Runs slower than this × quoted time are skipped (left out of the average). Default 1.5.",
        },
        {
          type: "control",
          name: "Save average rules",
          does: "Writes the three numbers. Prices on existing quotes do not jump until you open / save the part and the times actually change.",
        },
      ],
    },
    {
      title: "Audit log",
      blocks: [
        {
          type: "control",
          name: "Recent audit log",
          does: "Last 40 events: action, user · details, timestamp. Switch User, App mode, Reset, and other office actions land here. Empty: No events.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Add a shop person",
        },
        {
          type: "ol",
          items: [
            "Operators & access: Name, email@shop.com, Operator, optional PIN (optional).",
            "Add.",
            "Tap the tab chips they may open. Leave money tabs off — they cannot stay on anyway.",
            "If this station should lock when they leave, type a PIN and Save PIN. Otherwise they are Open switch.",
          ],
        },
        {
          type: "h",
          text: "Add an office admin",
        },
        {
          type: "ol",
          items: [
            "Role Admin. Add.",
            "Settings and Assign Queue stay on. Leave Quoting / Email Quotes / Reports on unless you truly want that person off money.",
            "Type a PIN. Save PIN. They cannot switch in without it.",
          ],
        },
        {
          type: "h",
          text: "Install a program update (not a backup)",
        },
        {
          type: "ol",
          items: [
            "Confirm you have lcm-update-*.zip — not a USB backup and not lcm-backup-*.json.",
            "Update app… → Update package → Install update.",
            "Restart LCM on the host if the screen asks.",
            "Floor stations tap Refresh when ready. Data stays. What’s new may open.",
          ],
        },
        {
          type: "h",
          text: "Point phones at this host",
        },
        {
          type: "ol",
          items: [
            "On the host, ipconfig → IPv4.",
            "Label / phone address = http://THAT-IP:8080",
            "Reprint material labels. Old stickers still open the old address.",
          ],
        },
        {
          type: "h",
          text: "Import the old Google Sheet",
        },
        {
          type: "ol",
          items: [
            "Export JSON first (or Backup now) so you can undo.",
            "Download DATABASE / Historical Quotes as CSV.",
            "If part # + rev already exists = Update existing (recommended).",
            "CSV file from Google Sheets → read Preview.",
            "Import into database. Open Parts & Quotes and Master Quoter to spot-check Machine %, Material %, Shape?.",
          ],
        },
        {
          type: "h",
          text: "Go live for real bonus pay",
        },
        {
          type: "ol",
          items: [
            "Open cleanup desk — close leftover practice clocks. Nothing is deleted.",
            "Confirm Shifts & bonus windows, Hourly rate ($), Bonus tiers. Save settings.",
            "Production (live) — confirm the payout warning.",
            "BETA pill leaves the header. Reports → Mark paid is now real.",
          ],
        },
        {
          type: "h",
          text: "Weekly host + USB copy",
        },
        {
          type: "ol",
          items: [
            "Unlock this PC (admin PIN) so Backup now works.",
            "Backup now. Download a row onto an office drive.",
            "Build & download USB backup onto a dated stick. Keep it off the host.",
          ],
        },
        {
          type: "warn",
          text: "Reset demo data after Type RESET wipes the live book on every PC. Use Beta cleanup desk to close practice clocks instead. Use Restore on Host backups to roll back to a moment — not Reset.",
        },
      ],
    },
  ],
};
