/** Brother QL-810W — paper names match the Windows print dropdown. */

export const QL_TAPES = [
  {
    id: "dk2210",
    label: "DK-2210 1.1 x 0.6 in",
    w: "0.6in",
    h: "1.1in",
    kind: "continuous" as const,
    windowsPaper: "1.1 x 0.6",
  },
] as const;

export type QlTapeId = (typeof QL_TAPES)[number]["id"];
export type QlTape = (typeof QL_TAPES)[number];

const TAPE_STORE_KEY = "lcm-ql-tape";
const DPI = 300;
const QL_PRINTABLE_W = 306;

export function tapeById(id: string): QlTape {
  return QL_TAPES.find((t) => t.id === id) || QL_TAPES[0]!;
}

export function loadSavedTapeId(): QlTapeId {
  if (typeof window === "undefined") return "dk2210";
  try {
    const v = localStorage.getItem(TAPE_STORE_KEY) || "";
    if (QL_TAPES.some((t) => t.id === v)) return v as QlTapeId;
  } catch {
    /* ignore */
  }
  return "dk2210";
}

export function saveTapeId(id: string) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(TAPE_STORE_KEY, id);
  } catch {
    /* ignore */
  }
}

function esc(s: string) {
  return String(s || "")
    .replace(/&/g, "\u0026amp;")
    .replace(/</g, "\u0026lt;")
    .replace(/>/g, "\u0026gt;")
    .replace(/"/g, "\u0026quot;");
}

export type StockLabelItem = {
  barcode: string;
  qrDataUrl: string;
  line1: string;
  line2: string;
  line3?: string;
};

function fmtInch(n: number): string {
  const x = Math.round(n * 1000) / 1000;
  if (!Number.isFinite(x) || x <= 0) return "";
  return String(x).replace(/(\d\.\d*?)0+$/, "$1").replace(/\.$/, "");
}

function parseInchNumbers(raw: string): number[] {
  const s = String(raw || "").replace(/\u00d7/g, "x");
  const out: number[] = [];
  const re =
    /(\d+)\s*-\s*(\d+)\s*\/\s*(\d+)|(\d+)\s*\/\s*(\d+)|(\d+(?:\.\d+)?)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(s))) {
    let n = 0;
    if (m[1]) n = Number(m[1]) + Number(m[2]) / Number(m[3]);
    else if (m[4]) n = Number(m[4]) / Number(m[5]);
    else n = Number(m[6]);
    if (n > 0) out.push(n);
  }
  return out;
}

/** Short size for the 1.1 x 0.6 sticker: (4") or (2" x 4"). No "dia". */
export function labelSizeLine(opts: {
  sizeNote?: string;
  stockShape?: string;
}): string {
  const note = String(opts.sizeNote || "").trim();
  const shape = String(opts.stockShape || "").toLowerCase();
  const blob = (shape + " " + note).toLowerCase();
  let nums = parseInchNumbers(note);
  if (/ft|feet|long/.test(blob) && nums.length >= 2) {
    nums = nums.slice(0, -1);
  }
  const isRound =
    (/\b(round|dia|hex)\b/.test(blob) || /\bdia\b/.test(blob)) &&
    !/\b(rect|square|flat|plate|sheet)\b/.test(shape);
  const isSquare = /\b(square|sq)\b/.test(blob);
  if (isRound) {
    const d = nums[0];
    return d ? "(" + fmtInch(d) + '\")' : "";
  }
  if (isSquare) {
    const a = nums[0];
    if (!a) return "";
    const b = nums[1] && Math.abs(nums[1] - a) < 0.02 ? nums[1] : a;
    return "(" + fmtInch(a) + '\" x ' + fmtInch(b) + '\")';
  }
  if (nums.length >= 2) {
    return "(" + fmtInch(nums[0]!) + '\" x ' + fmtInch(nums[1]!) + '\")';
  }
  if (nums[0]) return "(" + fmtInch(nums[0]) + '\")';
  return "";
}

export function isCompactTape(tape: Pick<QlTape, "w" | "h" | "kind">) {
  return parseFloat(tape.w) <= 1.15;
}

function loadImg(src: string): Promise<HTMLImageElement | null> {
  if (!src) return Promise.resolve(null);
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

function breakLong(ctx: CanvasRenderingContext2D, word: string, maxW: number): string[] {
  if (ctx.measureText(word).width <= maxW) return [word];
  const out: string[] = [];
  let cur = "";
  for (const ch of word) {
    const trial = cur + ch;
    if (ctx.measureText(trial).width <= maxW) cur = trial;
    else {
      if (cur) out.push(cur);
      cur = ch;
    }
  }
  if (cur) out.push(cur);
  return out.length ? out : [word];
}

function wrapText(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxW: number,
): string[] {
  const words = String(text || "").split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let cur = "";
  for (const w of words) {
    const parts = breakLong(ctx, w, maxW);
    for (const part of parts) {
      const trial = cur ? cur + " " + part : part;
      if (ctx.measureText(trial).width <= maxW) {
        cur = trial;
      } else {
        if (cur) lines.push(cur);
        cur = part;
      }
    }
  }
  if (cur) lines.push(cur);
  return lines.length ? lines : [""];
}

const FEED_DOTS = Math.round(0.6 * DPI); // cut length — sides of the QR
const PAD_DOTS = Math.round(0.05 * DPI);

async function composeLabelView(item: StockLabelItem): Promise<HTMLCanvasElement> {
  const w = FEED_DOTS;
  const h = QL_PRINTABLE_W;
  const pad = PAD_DOTS;
  const qrSize = w - pad * 2;
  const gap = Math.round(0.03 * DPI);

  const scratch = document.createElement("canvas").getContext("2d");
  if (!scratch) throw new Error("Could not draw label");
  const maxTextW = w - pad * 2;
  function linesFor(px: number, family: string, weight: string, text: string) {
    scratch!.font = weight + " " + px + "px " + family;
    return wrapText(scratch!, text, maxTextW);
  }
  function fitOneLine(
    text: string,
    family: string,
    weight: string,
    startPx: number,
    minPx: number,
  ) {
    let px = startPx;
    while (px > minPx) {
      scratch!.font = weight + " " + px + "px " + family;
      if (scratch!.measureText(text).width <= maxTextW) return px;
      px -= 1;
    }
    return minPx;
  }

  const textBudget = h - pad - qrSize - gap - pad;
  const codePx = fitOneLine(
    item.barcode,
    "Consolas, monospace",
    "700",
    Math.round(0.07 * DPI),
    8,
  );
  const codeLines = [item.barcode];
  let matPx = Math.round(0.08 * DPI);
  let sizePx = Math.round(0.11 * DPI);
  let matLines: string[] = [];
  let sizeLines: string[] = [];
  let extraLines: string[] = [];
  const codeH = Math.round(codePx * 1.12);
  let matH = 0;
  let sizeH = 0;
  for (let step = 0; step < 12; step++) {
    matH = Math.round(matPx * 1.16);
    sizeH = Math.round(sizePx * 1.16);
    matLines = linesFor(matPx, "Arial, Helvetica, sans-serif", "800", item.line1);
    sizeLines = linesFor(sizePx, "Arial, Helvetica, sans-serif", "800", item.line2);
    extraLines = item.line3
      ? linesFor(matPx, "Arial, Helvetica, sans-serif", "700", item.line3)
      : [];
    const textH =
      codeH +
      matLines.length * matH +
      sizeLines.length * sizeH +
      extraLines.length * matH;
    if (textH <= textBudget) break;
    matPx = Math.max(10, matPx - 1);
    sizePx = Math.max(12, sizePx - 1);
  }

  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not draw label");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = "#000000";
  ctx.textAlign = "center";
  ctx.textBaseline = "top";

  const qrImg = await loadImg(item.qrDataUrl);
  const qx = pad;
  const qy = pad;
  if (qrImg) ctx.drawImage(qrImg, qx, qy, qrSize, qrSize);
  else ctx.strokeRect(qx, qy, qrSize, qrSize);

  const cx = Math.round(w / 2);
  let y = qy + qrSize + gap;
  ctx.font = "700 " + codePx + "px Consolas, monospace";
  for (const line of codeLines) {
    ctx.fillText(line, cx, y);
    y += codeH;
  }
  ctx.font = "800 " + matPx + "px Arial, Helvetica, sans-serif";
  for (const line of matLines) {
    ctx.fillText(line, cx, y);
    y += matH;
  }
  ctx.font = "800 " + sizePx + "px Arial, Helvetica, sans-serif";
  for (const line of sizeLines) {
    ctx.fillText(line, cx, y);
    y += sizeH;
  }
  ctx.font = "700 " + matPx + "px Arial, Helvetica, sans-serif";
  for (const line of extraLines) {
    ctx.fillText(line, cx, y);
    y += matH;
  }
  return canvas;
}

/** Rotate the readable 0.6 x 1.1 view so feed (cut) is the 0.6 in sides of the QR. */
function rotateViewToPrinter(view: HTMLCanvasElement): HTMLCanvasElement {
  const out = document.createElement("canvas");
  out.width = view.height;
  out.height = view.width;
  const ctx = out.getContext("2d");
  if (!ctx) throw new Error("Could not rotate label");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, out.width, out.height);
  ctx.translate(0, out.height);
  ctx.rotate(-Math.PI / 2);
  ctx.drawImage(view, 0, 0);
  return out;
}

function canvasToMono(canvas: HTMLCanvasElement): {
  width: number;
  height: number;
  pixelsB64: string;
} {
  const w = canvas.width;
  const h = canvas.height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not read label");
  const data = ctx.getImageData(0, 0, w, h).data;
  const pixels = new Uint8Array(w * h);
  for (let i = 0; i < pixels.length; i++) {
    const o = i * 4;
    const lum = (data[o] || 0) + (data[o + 1] || 0) + (data[o + 2] || 0);
    pixels[i] = lum < 384 ? 1 : 0;
  }
  let bin = "";
  for (let i = 0; i < pixels.length; i++) bin += String.fromCharCode(pixels[i]!);
  return { width: w, height: h, pixelsB64: btoa(bin) };
}

export async function renderLabelPng(
  item: StockLabelItem,
  _tape: QlTape,
): Promise<string> {
  const view = await composeLabelView(item);
  return view.toDataURL("image/png");
}

function openPrintHtml(html: string): { ok: boolean; error?: string } {
  if (typeof document === "undefined") {
    return { ok: false, error: "Print is only available in the app window" };
  }
  const blob = new Blob([html], { type: "text/html" });
  const url = URL.createObjectURL(blob);
  const win = window.open(url, "lcm-ql-label", "width=480,height=320,menubar=no,toolbar=no");
  if (!win) {
    URL.revokeObjectURL(url);
    return {
      ok: false,
      error: "Allow pop-ups for this site — the app must open a small sticker window, not print the whole page.",
    };
  }
  const start = () => {
    try {
      win.focus();
      win.print();
    } catch {
      /* ignore */
    }
    window.setTimeout(() => URL.revokeObjectURL(url), 8000);
  };
  win.addEventListener("load", () => window.setTimeout(start, 250));
  window.setTimeout(start, 800);
  return { ok: true };
}

function printSheetHtml(tape: QlTape, pngs: string[], title: string) {
  const w = tape.w;
  const h = tape.h;
  const imgs = pngs
    .map((src) => '<img class="sticker" src="' + src + '" alt=""/>')
    .join("");
  return (
    "<!doctype html><html><head><meta charset=\"utf-8\"/><title>" +
    esc(title) +
    "</title><style>" +
    "@page { size: " +
    w +
    " " +
    h +
    "; margin: 0; }" +
    "html, body { margin: 0; padding: 0; background: #fff; width: " +
    w +
    "; height: " +
    h +
    "; }" +
    "img.sticker { width: " +
    w +
    "; height: " +
    h +
    "; display: block; page-break-after: always; break-after: page; }" +
    "img.sticker:last-child { page-break-after: auto; }" +
    "</style></head><body>" +
    imgs +
    "</body></html>"
  );
}

export async function printBrotherSampleLabel(opts: {
  tapeId: string;
  barcode: string;
  qrDataUrl: string;
  line1: string;
  line2: string;
}): Promise<{ ok: boolean; error?: string }> {
  return printBrotherStockLabels(opts.tapeId, [
    {
      barcode: opts.barcode,
      qrDataUrl: opts.qrDataUrl,
      line1: opts.line1,
      line2: opts.line2,
    },
  ]);
}

export async function printBrotherStockLabels(
  tapeId: string,
  items: StockLabelItem[],
): Promise<{ ok: boolean; error?: string }> {
  if (!items.length) return { ok: false, error: "No labels to print" };
  if (typeof document === "undefined") {
    return { ok: false, error: "Print is only available in the app window" };
  }
  const tape = tapeById(tapeId);
  try {
    const pngs: string[] = [];
    for (const item of items) pngs.push(await renderLabelPng(item, tape));
    const title = items.length === 1 ? items[0]!.barcode : String(items.length) + " stock labels";
    return openPrintHtml(printSheetHtml(tape, pngs, title));
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not draw label" };
  }
}

export async function downloadLabelPng(opts: {
  tapeId: string;
  barcode: string;
  qrDataUrl: string;
  line1: string;
  line2: string;
  line3?: string;
}): Promise<{ ok: boolean; error?: string }> {
  if (typeof document === "undefined") {
    return { ok: false, error: "Save is only available in the app window" };
  }
  try {
    const tape = tapeById(opts.tapeId);
    const png = await renderLabelPng(
      {
        barcode: opts.barcode,
        qrDataUrl: opts.qrDataUrl,
        line1: opts.line1,
        line2: opts.line2,
        line3: opts.line3,
      },
      tape,
    );
    const a = document.createElement("a");
    a.href = png;
    a.download = (opts.barcode || "label") + ".png";
    a.click();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not save PNG" };
  }
}

export async function renderLabelMono(opts: {
  tapeId: string;
  barcode: string;
  qrDataUrl: string;
  line1: string;
  line2: string;
  line3?: string;
}): Promise<{ width: number; height: number; pixelsB64: string }> {
  if (typeof document === "undefined") {
    throw new Error("Label draw is only available in the app window");
  }
  const view = await composeLabelView({
    barcode: opts.barcode,
    qrDataUrl: opts.qrDataUrl,
    line1: opts.line1,
    line2: opts.line2,
    line3: opts.line3,
  });
  return canvasToMono(rotateViewToPrinter(view));
}
