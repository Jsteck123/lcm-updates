import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ScanBarcode, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHowTo } from "@/components/lcm/page-howto";

export const Route = createFileRoute("/scan")({
  validateSearch: (search: Record<string, unknown>) => ({
    c: typeof search.c === "string" ? search.c : "",
  }),
  component: ScanPage,
});

function ScanPage() {
  const { c } = Route.useSearch();
  const getPieceByBarcode = useLcmStore((s) => s.getPieceByBarcode);
  const consumePiece = useLcmStore((s) => s.consumePiece);
  const stockPieces = useLcmStore((s) => s.stockPieces || []);

  const [code, setCode] = useState(c || "");
  const [lengthUsed, setLengthUsed] = useState("");
  const [qty, setQty] = useState("1");
  const [jobRef, setJobRef] = useState("");
  const [reason, setReason] = useState("");
  const [lastOk, setLastOk] = useState<string | null>(null);

  useEffect(() => {
    if (c) setCode(c);
  }, [c]);

  const piece = code.trim() ? getPieceByBarcode(code) : undefined;

  function lookup() {
    const p = getPieceByBarcode(code);
    if (!p) {
      toast.error("Barcode not found");
      return;
    }
    toast.message(`Found ${p.material} ${p.materialType}`);
  }

  function submitUse() {
    const res = consumePiece({
      barcode: code,
      lengthUsed: Number(lengthUsed),
      qty: Number(qty) || 1,
      jobRef,
      reason: reason || "Shop cut",
    });
    if (!res.ok) {
      toast.error(res.error || "Failed");
      return;
    }
    const p = res.piece!;
    const msg =
      p.status === "consumed"
        ? `${p.barcode} fully used`
        : `${p.barcode}: ${p.remainingLength}" remaining`;
    toast.success(msg);
    setLastOk(msg);
    setLengthUsed("");
  }

  const recent = stockPieces.slice(0, 12);

  return (
    <div className="mx-auto max-w-lg space-y-5 pb-10">
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
        <div>
        <h1 className="text-2xl font-semibold tracking-tight flex items-center gap-2">
          <ScanBarcode className="h-6 w-6 text-[var(--color-primary)]" />
          Scan stock
        </h1>
        <p className="text-sm text-[var(--color-muted)] mt-1">
          Scan or type the barcode on the sticker, enter length used (inches),
          deduct inventory.
        </p>
        </div>
        <PageHowTo id="scan-stock" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Barcode</CardTitle>
          <CardDescription>
            Phone camera QR opens this page with the code filled in.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex gap-2">
            <Input
              autoFocus
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="LCM-XXXXXXXX"
              className="font-mono"
              onKeyDown={(e) => {
                if (e.key === "Enter") lookup();
              }}
            />
            <Button variant="secondary" onClick={lookup}>
              Find
            </Button>
          </div>

          {piece ? (
            <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-1 text-sm">
              <div className="flex items-center justify-between gap-2">
                <span className="font-mono font-medium">{piece.barcode}</span>
                <Badge
                  tone={piece.status === "available" ? "success" : "neutral"}
                >
                  {piece.status}
                </Badge>
              </div>
              <div>
                {piece.material} {piece.materialType} · {piece.stockShape}
              </div>
              <div className="text-[var(--color-muted)]">
                {piece.sizeNote || "—"} · {piece.location}
              </div>
              <div className="tabular font-semibold">
                {piece.remainingLength}" remaining of{" "}
                {piece.originalLength}"
              </div>
            </div>
          ) : code.trim() ? (
            <p className="text-sm text-[var(--color-warn)]">
              No piece matches this code yet.
            </p>
          ) : null}

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Length used (in)</Label>
              <Input
                type="number"
                inputMode="decimal"
                value={lengthUsed}
                onChange={(e) => setLengthUsed(e.target.value)}
                placeholder="24"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Qty (same length)</Label>
              <Input
                type="number"
                value={qty}
                onChange={(e) => setQty(e.target.value)}
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Job / part ref</Label>
            <Input
              value={jobRef}
              onChange={(e) => setJobRef(e.target.value)}
              placeholder="AF-4421"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Note</Label>
            <Input
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Saw cut"
            />
          </div>
          <Button
            className="w-full min-h-12 text-base"
            disabled={!piece || piece.status !== "available"}
            onClick={submitUse}
          >
            Deduct from inventory
          </Button>
          {lastOk && (
            <p className="text-sm text-[var(--color-success)] flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4" />
              {lastOk}
            </p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Recent pieces</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          {recent.map((p) => (
            <button
              key={p.id}
              type="button"
              className="w-full text-left rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2"
              onClick={() => setCode(p.barcode)}
            >
              <div className="font-mono text-xs">{p.barcode}</div>
              <div className="text-[var(--color-muted)]">
                {p.material} {p.materialType} · {p.remainingLength}" left
              </div>
            </button>
          ))}
          {recent.length === 0 && (
            <p className="text-[var(--color-muted)]">
              No barcoded pieces yet. Receive a PO to create stickers.{" "}
              <Link to="/po" className="text-[var(--color-primary)] underline">
                Open POs
              </Link>
            </p>
          )}
        </CardContent>
      </Card>

      <div className="flex gap-2">
        <Link
          to="/inventory"
          className="text-sm text-[var(--color-primary)] underline"
        >
          Inventory
        </Link>
        <Link
          to="/labels"
          search={{ ids: "", kind: "materials" }}
          className="text-sm text-[var(--color-primary)] underline"
        >
          Print labels
        </Link>
      </div>
    </div>
  );
}
