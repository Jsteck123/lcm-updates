import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useLcmStore } from "@/store/lcm-store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { formatCurrency, formatDate } from "@/lib/utils";
import { PageHowTo } from "@/components/lcm/page-howto";

export const Route = createFileRoute("/database")({
  component: DatabasePage,
});

function DatabasePage() {
  const quotes = useLcmStore((s) => s.quotes);
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    const terms = q
      .toLowerCase()
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean);
    if (!terms.length) return quotes;
    return quotes.filter((row) => {
      const hay = [
        row.partNumber,
        row.customer,
        row.material,
        row.revision,
        row.materialType,
        row.kind,
        ...(row.bom || []).map((b) => b.partNumber),
        ...(row.machines || []),
      ]
        .join(" ")
        .toLowerCase();
      return terms.every((t) => hay.includes(t));
    });
  }, [quotes, q]);

  return (
    <div className="mx-auto max-w-7xl space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight">Parts & Quotes</h1>
          <p className="text-sm text-[var(--color-muted)] mt-1">
            Search quotes (comma-separated terms = AND). {filtered.length} of {quotes.length}{" "}
            shown. Assemblies use -01 with BOM children (-02, -03…).
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <PageHowTo id="parts-quotes" />
          <Link
            to="/quoting"
            className="inline-flex items-center justify-center rounded-[var(--radius-md)] bg-[var(--color-primary)] text-[var(--color-primary-fg)] px-4 py-2.5 text-sm font-medium min-h-11"
          >
            Open Master Quoter
          </Link>
        </div>
      </div>

      <Input
        placeholder="Search e.g. assembly, NS-2200, aluminum"
        value={q}
        onChange={(e) => setQ(e.target.value)}
        className="max-w-xl"
      />

      <Card>
        <CardHeader>
          <CardTitle>Part / quote database</CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full text-sm min-w-[880px]">
            <thead>
              <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
                <th className="pb-2 font-medium">Date</th>
                <th className="pb-2 font-medium">Part #</th>
                <th className="pb-2 font-medium">Type</th>
                <th className="pb-2 font-medium">Rev</th>
                <th className="pb-2 font-medium">Customer</th>
                <th className="pb-2 font-medium">Material</th>
                <th className="pb-2 font-medium">Type</th>
                <th className="pb-2 font-medium">Stock</th>
                <th className="pb-2 font-medium">Machines</th>
                <th className="pb-2 font-medium text-right">Price @ qty1</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((row) => (
                <tr
                  key={row.id}
                  className="border-b border-[var(--color-border)] last:border-0 hover:bg-[var(--color-surface-2)]"
                >
                  <td className="py-2.5 text-[var(--color-muted)]">
                    {formatDate(row.date)}
                  </td>
                  <td className="py-2.5 font-medium">{row.partNumber}</td>
                  <td className="py-2.5">
                    {row.kind === "assembly" ? (
                      <Badge tone="info">Assembly</Badge>
                    ) : (
                      <Badge tone="neutral">Part</Badge>
                    )}
                  </td>
                  <td className="py-2.5">
                    <Badge tone="neutral">{row.revision}</Badge>
                  </td>
                  <td className="py-2.5">{row.customer}</td>
                  <td className="py-2.5">{row.material || "—"}</td>
                  <td className="py-2.5 text-[var(--color-muted)]">
                    {row.kind === "assembly"
                      ? (row.bom || []).map((b) => b.partNumber).join(", ") || "—"
                      : row.materialType || "—"}
                  </td>
                  <td className="py-2.5 text-xs">
                    {row.kind === "assembly" ? (
                      "—"
                    ) : (row.stockShape || "").trim() ? (
                      row.stockShape
                    ) : (
                      <span className="inline-flex items-center rounded-full border border-amber-500/50 bg-amber-500/15 px-2 py-0.5 text-[10px] font-semibold text-amber-300">
                        Shape?
                      </span>
                    )}
                  </td>
                  <td className="py-2.5 text-xs text-[var(--color-muted)]">
                    {(row.machines || []).join(", ") || "—"}
                  </td>
                  <td className="py-2.5 text-right tabular">
                    {row.prices?.[0] ? formatCurrency(row.prices[0]) : "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
