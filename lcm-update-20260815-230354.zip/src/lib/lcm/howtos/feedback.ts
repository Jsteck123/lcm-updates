import type { PageHowToDoc } from "./types";

export const feedbackHowTo: PageHowToDoc = {
  id: "feedback",
  path: "/feedback",
  title: "Feedback",
  tab: "feedback",
  whatThisPageIs:
    "The shop’s bug-and-idea box. Floor and office use the same list. You send “something’s broken” or “I have an idea” with an optional photo, page, and machine. The office sees it here, sets status, and replies. You can add more detail on the ticket. This page does not change jobs, timers, or stock.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "Two compose cards start a ticket. After you send, the ticket opens so you can see it. The list below is every ticket this shop has, filtered. Tap a row to open or close the detail sheet.",
        },
        {
          type: "ul",
          items: [
            "Open = New, Looking at it, or On the list. Closed = Done or Not doing.",
            "Mine is tickets you created (your email).",
            "Photos need the shop PIN unlocked — otherwise attach is blocked until you unlock.",
            "Max 5 files, 12 MB each, images or PDF.",
            "Status buttons on the open ticket are admin only. Anyone can Reply.",
          ],
        },
        {
          type: "note",
          text: "A photo of the frozen screen or the wrong badge is worth more than a long story. Short title first, then what you were doing.",
        },
        {
          type: "warn",
          text: "If Add photo says enter your PIN first, unlock this device, then attach again. Files do not sit in a pending pile.",
        },
      ],
    },
    {
      title: "Start a ticket",
      blocks: [
        {
          type: "control",
          name: "Feedback",
          does: "Page title. Subtitle: something broken or an idea — send it here with a photo. The office sees the same list.",
        },
        {
          type: "control",
          name: "Something’s broken",
          does: "Opens the bug compose card (Report a bug). Hidden while a compose card is already open.",
        },
        {
          type: "control",
          name: "I have an idea",
          does: "Opens the feature compose card (Request a feature). Hidden while compose is open.",
        },
        {
          type: "control",
          name: "Report a bug",
          does: "Compose card title when you picked Something’s broken.",
        },
        {
          type: "control",
          name: "Request a feature",
          does: "Compose card title when you picked I have an idea.",
        },
        {
          type: "control",
          name: "Short title",
          does: "Required-style title field. Placeholders: “e.g. Pause didn’t stop the clock on VF-2” (bug) or “e.g. Need a way to reprint a label” (idea).",
        },
        {
          type: "control",
          name: "What happened / what you want",
          does: "Body. What you were doing, what you expected, what you got.",
        },
        {
          type: "control",
          name: "Page (optional)",
          does: "Free text for which screen (Shop Floor, Job Board…). Helps the office find the code.",
        },
        {
          type: "control",
          name: "Machine (optional)",
          does: "Dropdown of machine names that currently have a session, plus a blank “—”. Use it when the bug is on a station.",
        },
        {
          type: "control",
          name: "Photo / screenshot",
          does: "Section label. The file picker itself is hidden; use Add photo.",
        },
        {
          type: "control",
          name: "Add photo",
          does: "Opens the device file picker (images + PDF, multiple). Requires shop PIN unlock. While upload runs the button reads Uploading… and is disabled. Errors: max 5 files, file too large (12 MB), attach failed.",
        },
        {
          type: "control",
          name: "Uploading…",
          does: "Add photo label while a file is going up. You cannot Send to office until it finishes (button disabled).",
        },
        {
          type: "control",
          name: "Remove file",
          does: "X on an attached file row. Drops that file from the ticket before send. Aria label is “Remove file”.",
        },
        {
          type: "control",
          name: "Cancel",
          does: "Closes compose and clears title, body, page, machine, and files without sending.",
        },
        {
          type: "control",
          name: "Send to office",
          does: "Creates the ticket. Toast: “Bug report sent” or “Idea sent to the office”. Opens the new ticket. Disabled while uploading. Errors if title/body fail validation.",
        },
      ],
    },
    {
      title: "List filters and rows",
      blocks: [
        {
          type: "control",
          name: "Open",
          does: "Filter. New + Looking at it + On the list. Default.",
        },
        {
          type: "control",
          name: "Mine",
          does: "Filter. Only tickets you created.",
        },
        {
          type: "control",
          name: "All",
          does: "Filter. Every ticket, any status.",
        },
        {
          type: "control",
          name: "Closed",
          does: "Filter. Done and Not doing.",
        },
        {
          type: "control",
          name: "Bugs & ideas",
          does: "Kind cycle (default). Tap once → Bugs only, again → Ideas only, again → Bugs & ideas.",
        },
        {
          type: "control",
          name: "Bugs only",
          does: "Kind filter showing only Bug tickets. Tap to cycle to Ideas only.",
        },
        {
          type: "control",
          name: "Ideas only",
          does: "Kind filter showing only Idea tickets. Tap to cycle back to Bugs & ideas.",
        },
        {
          type: "control",
          name: "Nothing here yet. Use the buttons above when you hit a snag or have an idea.",
          does: "Empty state when the current filters match no tickets.",
        },
        {
          type: "control",
          name: "Bug",
          does: "Kind badge on a list row (and on the detail sheet) for a broken-report.",
        },
        {
          type: "control",
          name: "Idea",
          does: "Kind badge for a feature request.",
        },
        {
          type: "control",
          name: "New",
          does: "Status badge (and admin status button). Fresh ticket, nobody has touched it.",
        },
        {
          type: "control",
          name: "Looking at it",
          does: "Status badge / admin button. Office is investigating.",
        },
        {
          type: "control",
          name: "On the list",
          does: "Status badge / admin button. Accepted, not built yet.",
        },
        {
          type: "control",
          name: "Done",
          does: "Status badge / admin button. Fixed or shipped.",
        },
        {
          type: "control",
          name: "Not doing",
          does: "Status badge / admin button. Won’t fix / out of scope.",
        },
      ],
    },
    {
      title: "Ticket detail sheet",
      blocks: [
        {
          type: "p",
          text: "Opens when you tap a list row (tap again to collapse, or use the X). Dark backdrop also closes. Title, who opened it, when, machine, page, body, and attachments.",
        },
        {
          type: "control",
          name: "X (close)",
          does: "Ghost button on the sheet. Closes detail. Backdrop click does the same.",
        },
        {
          type: "control",
          name: "Attachment file name",
          does: "Outline button per photo/PDF. Opens the file. Errors if the attachment cannot be opened.",
        },
        {
          type: "control",
          name: "New / Looking at it / On the list / Done / Not doing",
          does: "Admin-only status buttons on the open ticket. Current status is filled in. Tap sets status and toasts “Marked {label}”. Hidden for floor logins.",
        },
        {
          type: "control",
          name: "Reply",
          does: "Text area. Admin placeholder: “Ask a question or say what you’ll do…”. Floor: “Add more detail if they ask…”.",
        },
        {
          type: "control",
          name: "Reply",
          does: "Send button under the box (same label as the field). Posts the comment under your name. Toast “Reply posted”. Errors if empty or save fails. Anyone can use it.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Report a broken screen",
        },
        {
          type: "ol",
          items: [
            "Tap Something’s broken.",
            "Fill Short title and What happened / what you want.",
            "Optionally set Page and Machine.",
            "Tap Add photo (unlock PIN if asked) and attach a screenshot.",
            "Tap Send to office.",
          ],
        },
        {
          type: "h",
          text: "Send an idea",
        },
        {
          type: "ol",
          items: [
            "Tap I have an idea.",
            "Fill Short title and what you want.",
            "Tap Send to office.",
          ],
        },
        {
          type: "h",
          text: "Office: move a ticket",
        },
        {
          type: "ol",
          items: [
            "Filter Open (or All).",
            "Tap the row.",
            "Tap Looking at it, On the list, Done, or Not doing.",
            "Type in Reply and tap Reply so the floor sees what you will do.",
          ],
        },
        {
          type: "h",
          text: "Add more after they ask",
        },
        {
          type: "ol",
          items: [
            "Filter Mine or Open and tap your ticket.",
            "Type in Reply and tap Reply.",
          ],
        },
      ],
    },
  ],
};
