/** Brother QL-810W tape sizes (die-cut / continuous). */

export const QL_TAPES = [
  { id: "dk1201", label: "DK-1201 Address 1.1 x 3.5 in", w: "1.1in", h: "3.5in" },
  { id: "dk1209", label: "DK-1209 1.1 x 2.4 in", w: "1.1in", h: "2.4in" },
  { id: "custom116", label: "1.1 x 1.6 in (Windows list)", w: "1.1in", h: "1.6in" },
  { id: "dk1202", label: "DK-1202 Shipping 2.4 x 3.9 in", w: "2.4in", h: "3.9in" },
  { id: "dk2205", label: "DK-2205 2.4 in continuous", w: "2.4in", h: "2.0in" },
] as const;

export type QlTapeId = (typeof QL_TAPES)[number]["id"];

export function tapeById(id: string) {
  return QL_TAPES.find((t) => t.id === id) || QL_TAPES[0]!;
}

function esc(s: string) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export function printBrotherSampleLabel(opts: {
  tapeId: string;
  barcode: string;
  qrDataUrl: string;
  line1: string;
  line2: string;
}): { ok: boolean; error?: string } {
  const tape = tapeById(opts.tapeId);
  const qrTag = opts.qrDataUrl
    ? `<img class="qr" src="${opts.qrDataUrl}" alt=""/>`
    : "";
  const html = `<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>${esc(opts.barcode)}</title>
<style>
  @page { size: ${tape.w} ${tape.h}; margin: 0; }
  html, body { margin: 0; padding: 0; width: ${tape.w}; height: ${tape.h}; background: #fff; color: #000; }
  .label { width: ${tape.w}; height: ${tape.h}; box-sizing: border-box; padding: 0.06in 0.05in; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; overflow: hidden; font-family: Arial, Helvetica, sans-serif; }
  .name { font-size: 7px; font-weight: 700; letter-spacing: 0.03em; }
  .code { font-family: Consolas, monospace; font-size: 9px; font-weight: 700; margin-top: 0.03in; }
  .qr { width: 0.85in; height: 0.85in; object-fit: contain; margin: 0.04in 0; }
  .mat { font-size: 7px; font-weight: 700; }
  .size { font-size: 6px; }
</style>
</head>
<body>
  <div class="label">
    <div class="name">LAKE COUNTRY MACHINE</div>
    <div class="code">${esc(opts.barcode)}</div>
    ${qrTag}
    <div class="mat">${esc(opts.line1)}</div>
    <div class="size">${esc(opts.line2)}</div>
  </div>
  <script>window.onload=function(){setTimeout(function(){window.print();},250);};</script>
</body>
</html>`;

  const w = window.open("", "_blank", "noopener,noreferrer,width=480,height=640");
  if (!w) {
    return { ok: false, error: "Pop-up blocked — allow pop-ups for LCM, then try again" };
  }
  w.document.open();
  w.document.write(html);
  w.document.close();
  return { ok: true };
}
