import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Printer, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { barcodeToDataUrl, scanUrlForBarcode } from "@/lib/lcm/barcode";
import { Button } from "@/components/ui/button";
import { Label, Select } from "@/components/ui/input";
import { useLcmStore } from "@/store/lcm-store";
import {
  QL_TAPES,
  printBrotherSampleLabel,
} from "@/lib/lcm/brother-label-print";

/** Practice barcode for printing a test label — not auto-written into live inventory */
export const SAMPLE_BARCODE = "LCM-SAMPLE-01";

const LOCAL_SAMPLE = {
  barcode: SAMPLE_BARCODE,
  material: "Aluminum",
  materialType: "T6 6061",
  stockShape: "Round Stock",
  sizeNote: '1.5" dia x 12 ft',
  remainingLength: 144,
  originalLength: 144,
  location: "Rack A-1",
  unit: "in" as const,
};

export const Route = createFileRoute("/sample-label")({
  component: SampleLabelPage,
});

function SampleLabelPage() {
  const stockPieces = useLcmStore((s) => s.stockPieces || []);
  const [qr, setQr] = useState("");
  const [tapeId, setTapeId] = useState<string>("dk1201");

  const piece =
    stockPieces.find((p) => p.barcode === SAMPLE_BARCODE) || LOCAL_SAMPLE;
  const tape = QL_TAPES.find((t) => t.id === tapeId) || QL_TAPES[0]!;

  useEffect(() => {
    const url = scanUrlForBarcode(SAMPLE_BARCODE, window.location.origin);
    void barcodeToDataUrl(url, 220).then(setQr);
  }, []);

  function printNow() {
    if (!qr) {
      toast.error("Wait for the barcode to finish drawing");
      return;
    }
    const r = printBrotherSampleLabel({
      tapeId,
      barcode: piece.barcode,
      qrDataUrl: qr,
      line1: `${piece.material} ${piece.materialType}`,
      line2: piece.sizeNote,
    });
    if (!r.ok) toast.error(r.error || "Could not open print");
    else
      toast.message(
        "Print window opened. Paper size must match the DK roll in the printer.",
      );
  }

  return (
    <div className="mx-auto max-w-lg space-y-5 pb-10">
      <div className="flex items-center gap-2">
        <Link
          to="/inventory"
          className="inline-flex items-center justify-center gap-1.5 text-sm text-[var(--color-muted)] hover:text-[var(--color-fg)] min-h-11"
        >
          <ArrowLeft className="h-4 w-4" /> Inventory
        </Link>
      </div>

      <div className="space-y-2">
        <h1 className="text-2xl font-semibold tracking-tight">
          Sample barcode label
        </h1>
        <p className="text-sm text-[var(--color-muted)]">
          Look at the black cassette in the QL-810W — the DK number is printed
          on it. Pick that size below. If the size is wrong, the printer takes
          the job and prints nothing.
        </p>
      </div>

      <div className="space-y-1.5">
        <Label>Tape in the printer</Label>
        <Select
          className="h-11"
          value={tapeId}
          onChange={(e) => setTapeId(e.target.value)}
        >
          {QL_TAPES.map((t) => (
            <option key={t.id} value={t.id}>
              {t.label}
            </option>
          ))}
        </Select>
      </div>

      <div
        className="sample-ql-label"
        style={{ width: tape.w, height: tape.h }}
      >
        <div className="sample-ql-name">LAKE COUNTRY MACHINE</div>
        <div className="sample-ql-code">{piece.barcode}</div>
        {qr ? (
          <img src={qr} alt="" className="sample-ql-qr" />
        ) : (
          <div className="sample-ql-qr sample-ql-qr-empty" />
        )}
        <div className="sample-ql-mat">
          {piece.material} {piece.materialType}
        </div>
        <div className="sample-ql-size">{piece.sizeNote}</div>
      </div>

      <div className="flex flex-wrap gap-2">
        <Button type="button" className="min-h-11" onClick={printNow}>
          <Printer className="h-4 w-4" /> Print 1 label
        </Button>
      </div>

      <div className="text-sm text-[var(--color-muted)] space-y-1">
        <p>In the print window:</p>
        <ul className="list-disc pl-5 space-y-0.5">
          <li>Printer: Brother QL-810W</li>
          <li>Layout: Portrait</li>
          <li>Paper: same size as the tape you picked</li>
          <li>Margins: None · Headers: Off</li>
        </ul>
        <p>
          Still nothing? Windows search → <strong>Printers & scanners</strong>{" "}
          → Brother QL-810W → open queue. If a job is stuck, cancel it. Then
          print a Windows test page to that printer. If the test page also
          fails, the printer is asleep or Wi-Fi dropped — not LCM.
        </p>
      </div>

      <style>{`
        .sample-ql-label {
          box-sizing: border-box;
          padding: 0.06in 0.05in;
          border: 1px solid var(--color-border);
          background: #fff;
          color: #000;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          text-align: center;
          overflow: hidden;
        }
        .sample-ql-name {
          font-size: 6px;
          font-weight: 700;
          letter-spacing: 0.04em;
          line-height: 1.1;
        }
        .sample-ql-code {
          font-family: ui-monospace, monospace;
          font-size: 8px;
          font-weight: 700;
          line-height: 1.15;
          margin-top: 0.03in;
        }
        .sample-ql-qr {
          width: 0.78in;
          height: 0.78in;
          object-fit: contain;
          margin: 0.04in 0;
        }
        .sample-ql-qr-empty { background: #eee; }
        .sample-ql-mat {
          font-size: 6.5px;
          font-weight: 600;
          line-height: 1.1;
          max-width: 100%;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .sample-ql-size {
          font-size: 5.5px;
          line-height: 1.1;
          max-width: 100%;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
      `}</style>
    </div>
  );
}
