import type { PageHowToDoc } from "./types";

export const customerOrdersHowTo: PageHowToDoc = {
  id: "customer-orders",
  path: "/po",
  title: "Customer Orders",
  tab: "po",
  whatThisPageIs:
    "Customer purchase orders coming into the shop — not vendor metal buys. The customer PDF is the source of truth. This page only tracks customer, PO #, PO rev, date required, rating, and the part lines. Office / admin sees costs, extensions, Sales Order / QuickBooks, and vendor RFQs. Shop logins never see prices.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "Left side is the list of every customer PO. Click one and the form opens on the right. Pick a line, match stock, attach the print, check the release boxes, then Assign so someone on the floor can take it. Material still to buy sits under the order. Jobs already handed to a machine sit in Running order for this PO.",
        },
        {
          type: "p",
          text: "A new PO starts open, Attn Pam Steck, terms N30, FOB Origin. Opening a PO rematches saved inventory picks so leftover 3\" stock does not get treated as 1\" stock. Changing part #, rev, qty, or stock fields re-runs the material plan. Changing part # or rev clears the material-reviewed check so office has to look again.",
        },
        {
          type: "note",
          text: "Shop view: costs, Tax?, Extension, Lines total, Sales Order / QB, and RFQ vendors are hidden on a shop login. You still see qty, open, material, drawings, and Assign.",
        },
        {
          type: "warn",
          text: "A line stays Hold on the Job Board until PDF rev matches PO and Stock size noted are both checked. If CAD is attached, CAD rev OK is also required. Take job is one line — never the whole PO.",
        },
      ],
    },
    {
      title: "Top of the page",
      blocks: [
        {
          type: "control",
          name: "New customer PO",
          does: "Creates a blank open order and selects it. Header and lines are empty — type Customer, PO #, Date required, then Add line. Toast: “New customer PO — enter header and part lines.”",
        },
        {
          type: "control",
          name: "Import PO file",
          does: "Opens Import customer package. Drop the PO PDF plus drawings and CAD in one shot. The importer picks the PO by filename (PO-26-…) or by PDF text, matches files to P/N, and will revise an existing same-number PO instead of making a duplicate. Cost is never auto-changed.",
        },
        {
          type: "control",
          name: "Print",
          does: "Opens the browser print dialog. List, banners, and action buttons are print-hidden so the selected order is what you put on paper.",
        },
        {
          type: "control",
          name: "Assign queue",
          does: "Jumps to Assign queue (/assign). Admin desk walk: open the drawing full screen and hand the part to a person without leaving the print. Shop logins hitting that page see “Admin only.”",
        },
        {
          type: "control",
          name: "Material buys",
          does: "Jumps to Inventory. Shop-wide buys, Vendor RFQs, and rack stock live there. This page only shows what the selected PO still needs.",
        },
      ],
    },
    {
      title: "Shop stats",
      blocks: [
        {
          type: "p",
          text: "Four cards sit under the buttons. They are counts, not buttons.",
        },
        {
          type: "control",
          name: "Open POs",
          does: "How many customer orders are status open or in_progress.",
        },
        {
          type: "control",
          name: "Total POs",
          does: "Every customer PO on file, including complete and cancelled.",
        },
        {
          type: "control",
          name: "Open line qty",
          does: "Pieces still open across every order (qty minus done, skipping cancelled lines).",
        },
        {
          type: "control",
          name: "This PO to buy",
          does: "How many distinct stock rows on the selected PO still have a buy qty, ignoring customer-supplied material.",
        },
      ],
    },
    {
      title: "Follow-up banner",
      blocks: [
        {
          type: "p",
          text: "Amber strip at the top when import left open follow-ups (missing drawing, missing CAD, not in the quote book, rev mismatch, unmatched file, missing P/N, missing qty, no date required, or an import note). Shows up to eight open reports.",
        },
        {
          type: "control",
          name: "Review & email",
          does: "Opens Customer follow-up for that report so office can email the customer, copy the letter, or mark it Resolved. Each row shows PO #, item count, and customer.",
        },
      ],
    },
    {
      title: "Customer POs list",
      blocks: [
        {
          type: "p",
          text: "Card title Customer POs. Subtitle: Select to open the form. Empty state: No customer POs yet.",
        },
        {
          type: "control",
          name: "Customer POs",
          does: "Tap a row to select that order. The selected row is highlighted. Other rows tint by pack status (need pack / packed / verified). Each row shows PO # (or “(no PO #)”), PO rev if set, status badge (open / in_progress / complete / cancelled / draft), customer or “No customer”, active line count, and Need by {date} when Date required is set.",
        },
      ],
    },
    {
      title: "Order header",
      blocks: [
        {
          type: "p",
          text: "Right-hand card. Title is the PO # (or “New PO”) plus rev and a status badge. Subtitle is customer · need by date · rating. If nothing is selected: Select or create a customer PO.",
        },
        {
          type: "control",
          name: "Original PO PDF",
          does: "Only shows when a source file was saved on import. Opens the customer PDF that was used as the PO. Error toast if the file is missing on the host.",
        },
        {
          type: "control",
          name: "Attach drawings/CAD",
          does: "Multi-select file picker. Accepts PDF, images, DXF/DWG/TIF, and CAD (x_t, x_b, STEP, IGES, SLDPRT, SLDASM, PRT, F3D, SAT, STL, OBJ). Each file is stored on the host, classified as drawing or CAD, then matched to a line by P/N in the filename. Assembly children (-02, -03) hang on the parent line. Toast reports drawings added, CAD added, and how many names did not match a P/N.",
        },
        {
          type: "control",
          name: "Sales Order / QB",
          does: "Admin / price-visible only. Opens Sales Order / QuickBooks built from this PO — print the office form or download a QuickBooks invoice CSV.",
        },
        {
          type: "control",
          name: "draft / open / in progress / complete / cancelled",
          does: "Status dropdown on the header. draft = not released. open = live. in progress = shop is running something. complete = lines are done. cancelled = do not run. Changing it saves immediately.",
        },
        {
          type: "control",
          name: "Customer",
          does: "Creatable list of shop customers. Pick one or type a new name. Add customer creates the customer in the book and writes it on this PO.",
        },
        {
          type: "control",
          name: "PO #",
          does: "Customer purchase-order number. Forced uppercase. Placeholder PO-26-X679. This is the key used to find an existing order when you import a revise.",
        },
        {
          type: "control",
          name: "PO rev",
          does: "Document revision of the customer PO — not the part drawing rev. Blank = original PO. First customer change is A, then B, C…. Forced uppercase. Hint under the box: “Blank = original PO. A = first customer revise.”",
        },
        {
          type: "control",
          name: "Date required",
          does: "Need-by date from the customer. Also writes Due date (same value) so Ship Calendar parks this PO on that day.",
        },
        {
          type: "control",
          name: "Rating",
          does: "Optional customer or office rating pulled from the PO. Placeholder Optional. Does not change shop priority by itself.",
        },
      ],
    },
    {
      title: "Material attention banner",
      blocks: [
        {
          type: "p",
          text: "Yellow strip above the lines when any line is needs_attention or is not marked reviewed and is not already OK. “N line(s) need material attention (marked ?). Matched lines show a check when stock is planned.” Tap the ? on a line to open Stock for {P/N}.",
        },
      ],
    },
    {
      title: "Line columns",
      blocks: [
        {
          type: "p",
          text: "One row per line item. A cancelled / Dropped line greys out and you cannot edit Item. Empty table: No line items — add parts from the customer PO.",
        },
        {
          type: "control",
          name: "Item",
          does: "Line number from the customer PO. Number box. On a dropped line this is read-only and a red Dropped badge sits under it.",
        },
        {
          type: "control",
          name: "Mat",
          does: "Checkbox. Check when material is planned (title “Check when material is planned”; checked title “Marked OK”). That sets materialReviewed. A green check means status is ok or the box is checked. A ? means it needs attention — tap ? to open the stock dialog. Changing stock or rev unchecks this.",
        },
        {
          type: "control",
          name: "Part #",
          does: "Creatable part-number box. Pick from quotes and other POs, or New part # to type one (forced uppercase). Picking a known P/N fills from the quote book and rematches stock. Chevron to the left expands Description, drawings, release checks, CAD, assembly, and material. Under the P/N: stock summary (tap to open Stock for {P/N}), paperclip if files are attached, red BUY {n}\" if need > on hand (inches of that stock size), and a Hold or Released badge.",
        },
        {
          type: "control",
          name: "Rev",
          does: "Part drawing revision. Forced uppercase, max 6 characters. Changing it unchecks Mat so office re-confirms stock and PDF rev.",
        },
        {
          type: "control",
          name: "Cost",
          does: "Admin / price-visible only. Unit cost. Highlights amber if $0.00 (Need cost — quote $X.XX (@ qty N) or Need cost ($0.00)). Highlights orange if it does not match the quote break (≠ quote $X.XX (@ qty N)). Shop logins do not see this column.",
        },
        {
          type: "control",
          name: "Qty",
          does: "Order quantity from the customer PO. Digits only. Changing qty recalculates material needed from part length × qty.",
        },
        {
          type: "control",
          name: "Units",
          does: "Unit of measure as written on the PO (EA, PCS, etc.). Free text.",
        },
        {
          type: "control",
          name: "Done",
          does: "Qty completed so far. Writes through shop progress. Open = Qty − Done. Do not type Done to close a job that is still on a machine — complete it on the floor.",
        },
        {
          type: "control",
          name: "Open",
          does: "Read-only remaining qty. Amber if still open, green at zero. Assign uses this number as the default Qty to run.",
        },
        {
          type: "control",
          name: "Tax?",
          does: "Admin / price-visible only. N or Y. Marks the line taxable on the Sales Order / QuickBooks export.",
        },
        {
          type: "control",
          name: "Extension",
          does: "Admin / price-visible only. Read-only Cost × Qty. Shop logins never see it.",
        },
        {
          type: "control",
          name: "Assign",
          does: "Opens Assign job for this line. Disabled when Open is 0 or Part # is blank. Prefills Qty to run with open qty, machine with the first machine on the matching quote (if any), operator and note blank.",
        },
        {
          type: "control",
          name: "Remove line",
          does: "Trash on the row. Deletes this line from the PO immediately. Does not cancel shop jobs already loaded on a machine. Prefer a PO revise (Dropped) if the customer pulled the line after work started.",
        },
      ],
    },
    {
      title: "Expanded line",
      blocks: [
        {
          type: "p",
          text: "Tap the chevron by Part # (title “Description, drawing, material” / “Hide details”). Extra row opens under the line.",
        },
        {
          type: "control",
          name: "Description",
          does: "Optional text from the PO or typed in. Placeholder Description (optional). Does not drive stock matching.",
        },
        {
          type: "control",
          name: "Drawings (assembly may have several)",
          does: "Every drawing on this line. Empty: No drawing. Tap a name to open the file. × removes that drawing (title Remove). Assembly files show related P/N: filename.",
        },
        {
          type: "control",
          name: "Add drawing",
          does: "Attach one or more PDF / image / DXF / DWG / TIF files to this line only. Stored on the host. Related assembly P/N is read from the filename. Toast: Drawing(s) added.",
        },
        {
          type: "h",
          text: "Release to job board",
        },
        {
          type: "control",
          name: "PDF rev matches PO",
          does: "Check after you open the print and confirm the drawing rev matches the PO line. Required before the line leaves Hold.",
        },
        {
          type: "control",
          name: "Stock size noted",
          does: "Check after stock size is set and matches the rack (or you marked customer-supplied). Required before the line leaves Hold.",
        },
        {
          type: "control",
          name: "CAD rev OK",
          does: "Check after you confirm the CAD file rev. Required when CAD is attached. Not required if there is no CAD.",
        },
        {
          type: "p",
          text: "Note under the checks: Line appears on Job Board only after PDF rev + stock note (and CAD rev if CAD attached). Take job is one line — not the whole PO.",
        },
        {
          type: "control",
          name: "CAD files",
          does: "Optional CAD on this line. Empty: No CAD (optional). Tap a name to open. × removes that CAD file.",
        },
        {
          type: "control",
          name: "Add CAD",
          does: "Attach x_t, x_b, STEP, IGES, SolidWorks, PRT, Fusion, SAT, STL, or OBJ. Same matching rules as drawings. Toast: CAD file(s) added.",
        },
        {
          type: "control",
          name: "Assembly components (job board)",
          does: "Shows when related files were promoted to components (child P/Ns under a parent). Shop takes each component job first, then the assembly line to bolt together. Each row: P/N, qty, drawing count, CAD count, and Complete / {name} / On board.",
        },
        {
          type: "control",
          name: "Material",
          does: "Stock summary for the line: material · type · shape · size. Need {n} · On hand {n} @ location · BUY {n}\" if short (inches) · Finished: {n} if finished parts are on the shelf. Attention reason shows until Mat is checked. Edit (when OK) or Fix (when not) opens Stock for {P/N}.",
        },
      ],
    },
    {
      title: "Line actions under the table",
      blocks: [
        {
          type: "control",
          name: "Add line",
          does: "Appends a blank line with the next Item number, qty 1, and runs the material matcher (quote book + rack + part recipe). Description stays empty unless a quote match fills rev.",
        },
        {
          type: "control",
          name: "Check materials",
          does: "Re-runs every line against the part database and stock. Toast: “Checked all lines against part database & stock.” Use this after a rack receive or a quote change.",
        },
        {
          type: "control",
          name: "Delete PO",
          does: "Opens Delete this PO? It permanently removes the order and its lines. Jobs already on machines are not deleted. Only office should delete a live customer PO.",
        },
        {
          type: "control",
          name: "Lines total",
          does: "Admin / price-visible only. Sum of extensions. Labeled (office only). Shop logins do not see it.",
        },
      ],
    },
    {
      title: "Import customer package",
      blocks: [
        {
          type: "p",
          text: "Dialog title: Import customer package. Drop everything at once — PO PDF, drawings, and CAD. The importer picks the PO by name (e.g. PO-26-X679.pdf) or by contents, then matches files to P/N. Assembly children (-02, -03) attach under the parent line (-01). Multiple drawings/CAD per line. Cost is never auto-changed.",
        },
        {
          type: "control",
          name: "Drop PO + drawings + CAD here",
          does: "Dashed drop zone, or click to multi-select. Accepts PDF, images, TXT, DXF/DWG/TIF, and CAD types. Files are saved to the host first, then PDFs are read for line items. Tip on the zone: keep “PO” in the purchase order filename when you can. Status line shows Saving n/m, Reading {file}, then the package note.",
        },
        {
          type: "warn",
          text: "If no PO is recognized: “Could not spot a Purchase Order in that batch. Include a file named like PO-26-XXXX.pdf, or drop the PO by itself.” If the best file looks like a drawing: “That package looked like a drawing, not a PO. Include a PO PDF (name it with PO-…) and try again.”",
        },
        {
          type: "control",
          name: "Customer",
          does: "Parsed customer. Fix it before you create. Creating the order also Add-customers this name if it is new.",
        },
        {
          type: "control",
          name: "PO #",
          does: "Parsed PO number, forced uppercase. This is what the revise matcher uses against orders already on file.",
        },
        {
          type: "control",
          name: "Date required",
          does: "Parsed need-by date. Review it — a missing date becomes a follow-up item (No date required).",
        },
        {
          type: "control",
          name: "Rating",
          does: "Parsed rating. Placeholder Optional.",
        },
        {
          type: "p",
          text: "PO file used: {filename} shows which PDF won the PO contest. Package note: PO: {file} · N line(s) · N drawing · N CAD matched · N unmatched.",
        },
        {
          type: "h",
          text: "Lines table on the import",
        },
        {
          type: "control",
          name: "#",
          does: "Item number from the parse. Read-only here.",
        },
        {
          type: "control",
          name: "P/N",
          does: "Part number. Edit if the PDF OCR missed a character. Forced uppercase. Matching drawings/CAD key off this value.",
        },
        {
          type: "control",
          name: "Description",
          does: "Parsed description. Fix typos before you create.",
        },
        {
          type: "control",
          name: "Rev",
          does: "Parsed drawing rev. Forced uppercase.",
        },
        {
          type: "control",
          name: "Qty",
          does: "Parsed quantity. Digits only.",
        },
        {
          type: "control",
          name: "Cost",
          does: "Admin / price-visible only. Parsed unit cost, read-only on this table. Import never overwrites a cost you already have on a revise.",
        },
        {
          type: "control",
          name: "Drawing",
          does: "Shows the matched drawing name, “N drawings”, or “drop drawing” if unmatched files are waiting. Drop a file chip on this cell to add a drawing without removing ones already there. +related means an assembly child file is hanging on this parent.",
        },
        {
          type: "control",
          name: "CAD",
          does: "Same as Drawing, for CAD. Drop on this cell to force CAD. Adds — never silently replaces.",
        },
        {
          type: "control",
          name: "I checked customer, PO #, dates, lines, and file matches",
          does: "Required checkbox before Create customer order / Apply PO revision will enable. On a revise the hint is “Confirm the change list before applying this PO revision.” On a new order: “Confirm the right PDF was used as the PO and drawings/CAD look correct before creating.”",
        },
        {
          type: "control",
          name: "Clear form",
          does: "Wipes the parse, file maps, unmatched list, and revise flags. Toast: “Import form cleared — ready for a new package.” Does not delete anything already created.",
        },
        {
          type: "control",
          name: "Cancel",
          does: "Clears quietly and closes the dialog. Nothing is written to the shop book.",
        },
        {
          type: "control",
          name: "Create customer order",
          does: "Writes a new open shop order with parsed header + lines, attaches the source PDF, promotes assembly-related files to components, enriches material from the part book, and may open a follow-up report. Disabled until the confirm box is checked and there is a PO # or at least one line. Toast lists material / drawing / CAD counts.",
        },
      ],
    },
    {
      title: "Unmatched files on import",
      blocks: [
        {
          type: "p",
          text: "Amber box: Unmatched files — drag onto a line, or use Attach. “Drag a file chip onto the line row (Drawing / CAD column), or pick the P/N and click Attach.”",
        },
        {
          type: "control",
          name: "Auto type",
          does: "Keeps the file as whatever the importer classified (drawing vs CAD) when you Attach.",
        },
        {
          type: "control",
          name: "As drawing",
          does: "Force this unmatched file onto the chosen line as a drawing.",
        },
        {
          type: "control",
          name: "As CAD",
          does: "Force this unmatched file onto the chosen line as CAD.",
        },
        {
          type: "control",
          name: "Attach",
          does: "Adds the file to the P/N selected in the line dropdown (#item P/N). Toast: “Added drawing/CAD to {P/N} (file for {related}) · {filename}.” Grip the chip and drop it on a line row if you would rather not use the dropdown.",
        },
      ],
    },
    {
      title: "Revise an existing PO",
      blocks: [
        {
          type: "p",
          text: "If PO # is already on file, the dialog switches to revise instead of create. Banner: “PO {#} is already on file (document rev X)” or “(original — no rev yet).” Import will revise that order — same job board lines, shop progress kept. Dropped lines are cancelled (not deleted). Part rev changes clear PDF/CAD OK checks. Original POs have no rev; the first customer change is A, then B, C…",
        },
        {
          type: "control",
          name: "New PO document rev",
          does: "The rev that will be written on the existing order. Defaults to the next letter (A if the original was blank). Forced uppercase. Placeholder A.",
        },
        {
          type: "control",
          name: "Review changes",
          does: "Shows (or Hide change list hides) the revise plan: counts for same / changed / added / dropped, header field diffs, and a line table (#, P/N, Change). Added shows “Add qty N”. Dropped shows “Drop (cancel)” or “Drop — {block reason}” if shop work is already on that line. Changed lists each field from → to.",
        },
        {
          type: "control",
          name: "Create as new order instead",
          does: "Turns off revise and will create a separate order with the same PO #. Toast: “Will create a separate order — only use if this is not the same PO.” A note then offers Switch back to revise.",
        },
        {
          type: "control",
          name: "Switch back to revise",
          does: "Puts the importer back on the existing-order path.",
        },
        {
          type: "control",
          name: "Cancel N line(s) that already have shop work (stays in history as Dropped)",
          does: "Required if the revise wants to drop a line that already has floor work. Without this box, Apply is blocked: “Some dropped lines have shop work — check the box to cancel them, or keep them.”",
        },
        {
          type: "control",
          name: "Review & revise existing PO",
          does: "First press when a match exists and the change list is hidden — opens the list and toasts “PO {#} is already on file — review changes, then apply.” After the list is open the same button becomes Apply PO revision.",
        },
        {
          type: "control",
          name: "Apply PO revision",
          does: "Merges the new PDF into the existing order: header updates, qty/rev/desc changes, new lines added, dropped lines cancelled, drawings/CAD added (never silently removed), document rev written. Material is re-enriched but reviewed flags are preserved. Writes an audit line “PO revise”. May open a follow-up report. Toast: “Revised {PO} → document rev X · N changed · N added · N dropped.”",
        },
      ],
    },
    {
      title: "Customer follow-up",
      blocks: [
        {
          type: "p",
          text: "Opens from the banner Review & email after an import left issues. Title: Customer follow-up. Subtitle: PO {#} · customer · N item(s). Each issue shows a badge (Missing drawing, Missing CAD, File not matched to a line, Not in our quote book, Revision mismatch, Missing part number, Missing / zero qty, No date required, Import note) plus P/N and detail.",
        },
        {
          type: "control",
          name: "Send to",
          does: "Customer email. Prefills from the customer book. Required for Email customer.",
        },
        {
          type: "control",
          name: "Extra note (optional)",
          does: "Office note appended to the letter and saved on the report.",
        },
        {
          type: "control",
          name: "Email customer",
          does: "Opens your mail app with the follow-up subject and body. Marks the report sent and logs the email. Needs Send to filled. Toast: “Email drafted — send from your mail app.”",
        },
        {
          type: "control",
          name: "Copy",
          does: "Copies To / Subject / body to the clipboard, marks the report sent, logs the email. Toast: “Copied — paste into email.”",
        },
        {
          type: "control",
          name: "Resolved",
          does: "Marks the report resolved (no email) and closes. Toast: “Marked resolved.” Use when you fixed the files yourself and do not need to ping the customer.",
        },
        {
          type: "control",
          name: "Close",
          does: "Closes without changing status. The banner stays until sent or resolved.",
        },
      ],
    },
    {
      title: "Assign job",
      blocks: [
        {
          type: "p",
          text: "Dialog from the line Assign button. “{P/N} · open qty N. Pick who runs it (Job Board / My Jobs). Machine is optional — adds it to that machine’s queue.”",
        },
        {
          type: "control",
          name: "Operator",
          does: "Who this job is for. First option: Select operator. List is active operators. Required if you want it on that person’s My Jobs. You can leave it blank to only queue the machine.",
        },
        {
          type: "control",
          name: "Machine (optional)",
          does: "First option: No machine yet. Picking one adds the job to that machine queue. Quote’s preferred machine is prefilled when Assign was clicked.",
        },
        {
          type: "control",
          name: "Qty to run",
          does: "How many of the open qty to hand out. Defaults to full open qty. You can split a line across people by assigning a smaller qty more than once.",
        },
        {
          type: "control",
          name: "Note",
          does: "Shows on the running-order row and the floor card. Placeholder: Op 2 only, heat treat first...",
        },
        {
          type: "control",
          name: "Cancel",
          does: "Closes without assigning.",
        },
        {
          type: "control",
          name: "Assign job",
          does: "Writes the assignment. Toast: “{P/N} is {name}’s job · {machine}” or “Queued {P/N} on {machine}.” Error toast if assign fails. The line then appears under Running order for this PO.",
        },
      ],
    },
    {
      title: "Stock for this line",
      blocks: [
        {
          type: "p",
          text: "Dialog title: Stock for {P/N} rev {rev} · {qty} pcs. This is the bar / sheet on the rack, not the finished part. Last-used stock for this P/N — change it only if the last run was wrong. If the saved rack row no longer matches the recipe, the pick is cleared and materialReviewed is turned off.",
        },
        {
          type: "control",
          name: "Drawing",
          does: "Opens the first drawing on the line so you can read stock size off the print. Shows (N) when there are several. Error if no drawing is attached: “No drawing on this line — attach it on the PO.”",
        },
        {
          type: "control",
          name: "Material",
          does: "Alloy / family (Aluminum, Steel, Stainless, …). Creatable. Add material adds to the list. Picking a customer-supplied material (wording the shop treats as customer-supplied) clears type, size, buy qty, and rack match and marks Mat OK.",
        },
        {
          type: "control",
          name: "Material type",
          does: "Grade / temper for that family (6061-T6, 304, etc.). Creatable. Add type. Hidden when material is customer-supplied.",
        },
        {
          type: "control",
          name: "Stock shape",
          does: "Round, hex, plate, sheet, rectangular, etc. Creatable. Add shape. Drives which size boxes show and whether need is inches or pieces.",
        },
        {
          type: "control",
          name: "How it sits",
          does: "Two buttons: Mill — X Y Z in the vise, or Lathe — X diameter, Z length. Changes axis labels and which face is LOC (the saw cut).",
        },
        {
          type: "h",
          text: "Size in the machine",
        },
        {
          type: "p",
          text: "These numbers are the stock blank as it sits in the machine. The highlighted axis is LOC — the one the saw cuts. Lathe: X is diameter (stays stock). Z is length of cut. Mill: pick which axis is the cut. The other faces stay stock.",
        },
        {
          type: "control",
          name: "LOC — length of cut",
          does: "The axis being sawed, and how long that cut is. If the model is 3\", cut 3.1\" so you can machine .05\" off each end. Do not pick an axis that must stay stock (a model surface). Radio choices come from shape + mill/lathe. Hidden for sheet/plate and in inventory mode.",
        },
        {
          type: "control",
          name: "Length of cut (X/Y/Z) \"",
          does: "Inches of stock used per part along the saw axis. Example placeholder 3.1. Feeds Stock used per part and the auto need math.",
        },
        {
          type: "control",
          name: "Full bar on the rack (\")",
          does: "Length of the raw bar you pull, in inches. Placeholder 144 (12 ft). Used when matching rack inches to need. Sheet/plate does not use this.",
        },
        {
          type: "h",
          text: "How much stock to pull / buy",
        },
        {
          type: "control",
          name: "Order qty",
          does: "Read-only. Pieces on the PO line. Sheet/plate view only.",
        },
        {
          type: "control",
          name: "Sheet / plate pieces (auto)",
          does: "Need in pieces. Defaults to the formula (usually one piece per part). Override if you nest more than one on a sheet. Editing unchecks Mat.",
        },
        {
          type: "control",
          name: "Stock used per part (\")",
          does: "Bar/round/hex/rect: inches of bar each part consumes (usually LOC). Editing zeros materialNeeded so the auto math reruns and unchecks Mat.",
        },
        {
          type: "control",
          name: "Inches needed (auto)",
          does: "Total inches to pull / buy. Shows the formula under the boxes. Everything is inches — no bar/foot conversion. Override if the formula is wrong. Editing unchecks Mat.",
        },
        {
          type: "control",
          name: "On the rack (matched stock)",
          does: "Dropdown of inventory rows that match this recipe. First option: “— Matching stock first — pick if last run was wrong —” or “— No inventory for this stock size —”. ★ / Best: marks the row that matches size. Picking a row copies material, type, shape, size, on-hand, location, and bar length onto the line and unchecks Mat. Other sizes of the same alloy do not count.",
        },
        {
          type: "note",
          text: "Customer-supplied material: “Customer supplies this stock. No type, size, buy qty, or rack match is needed.” Only Material stays visible.",
        },
        {
          type: "warn",
          text: "If last-used stock is not on the rack: “Last-used stock {size} is not on the rack. Other sizes of the same alloy do not count — buy this stock size.” Need vs on-hand shows Buy {n}\" (or pc) in the hint under the dropdown.",
        },
        {
          type: "control",
          name: "Close",
          does: "Closes without marking reviewed. Typed sizes are already saved as you go.",
        },
        {
          type: "control",
          name: "Mark OK",
          does: "Sets materialReviewed on this line and closes. Toast: “Marked stock OK for this line.” Check Stock size noted on the expanded line after this if the size is final.",
        },
      ],
    },
    {
      title: "Delete this PO?",
      blocks: [
        {
          type: "p",
          text: "Red title. “This permanently removes {PO #} for {customer} and all of its lines. Jobs already on machines are not deleted.”",
        },
        {
          type: "control",
          name: "Cancel",
          does: "Closes the dialog. The PO stays.",
        },
        {
          type: "control",
          name: "Yes, delete",
          does: "Removes the order from the shop book, clears the selection, toast “Deleted PO {#}.” Use the in-app dialog — not the browser back button.",
        },
      ],
    },
    {
      title: "Sales Order / QuickBooks",
      blocks: [
        {
          type: "p",
          text: "Admin / price-visible only. Title: Sales Order / QuickBooks. “Built from this customer PO — print for the office form or export CSV for QuickBooks.” Shop logins do not get this button.",
        },
        {
          type: "control",
          name: "S.O. #",
          does: "Sales-order number. Prefills a suggested number from existing SOs. Saved onto the customer PO when you print or export.",
        },
        {
          type: "control",
          name: "Sales tax %",
          does: "Tax percent used on the printed form and the QB CSV. Default is the shop sales-tax rate.",
        },
        {
          type: "control",
          name: "Close",
          does: "Closes the dialog. SO # is only saved if you printed or exported.",
        },
        {
          type: "control",
          name: "QuickBooks CSV",
          does: "Admin / price-visible only. Saves SO #, downloads QB-Invoice-SO-{number}.csv, toast “QuickBooks CSV downloaded.” Shop logins get “Price export is admin-only” if they somehow hit this.",
        },
        {
          type: "control",
          name: "Print Sales Order",
          does: "Saves SO # then prints the letterhead form: Date, S.O. #, Name / Address, Ship To, Due Date, P.O. No., Item / Description / Rev / Qty / Rate / Amount, Sales Tax, Total. Rate, Amount, tax, and Total hide on a shop login.",
        },
      ],
    },
    {
      title: "Material for this PO",
      blocks: [
        {
          type: "p",
          text: "Card under the order: Material for this PO · {PO #}. “What this order still needs to buy. Customer-supplied is listed separately. Shop-wide buys stay under Inventory.” Empty: No material set on open lines yet — open a line and fill material. If everything left is customer-supplied: Remaining open lines are customer-supplied — nothing to RFQ.",
        },
        {
          type: "control",
          name: "Stock",
          does: "Material + type on the first line, shape · size (or “size missing”) under it.",
        },
        {
          type: "control",
          name: "Parts",
          does: "Which P/Ns on this PO share that stock row.",
        },
        {
          type: "control",
          name: "Need",
          does: "Total qty needed in that row’s unit (in, sheet, etc.).",
        },
        {
          type: "control",
          name: "On hand",
          does: "Rack qty that matches this exact stock size.",
        },
        {
          type: "control",
          name: "Buy",
          does: "Customer supplied badge, or the short qty in that unit, or Covered when the rack has enough.",
        },
        {
          type: "control",
          name: "RFQ vendors",
          does: "Admin / price-visible only. Opens Send RFQ. Creates a draft vendor RFQ for this PO if one is not already open. Disabled path toasts “Nothing to buy on this PO.” After a send the same button reads Edit / resend RFQ.",
        },
        {
          type: "control",
          name: "Edit / resend RFQ",
          does: "Same as RFQ vendors once an RFQ is already status sent. Reopens the compose dialog on that RFQ.",
        },
        {
          type: "control",
          name: "Inventory → Vendor RFQs",
          does: "Link to Inventory so you can enter vendor bids after the email goes out. Badge on this card shows {RFQ #} · draft/sent/quoted/awarded.",
        },
      ],
    },
    {
      title: "Send RFQ",
      blocks: [
        {
          type: "p",
          text: "Dialog: Send RFQ · {RFQ #}. “Pick vendors, fix the lines, attach prints. Email stays plain — drawings download so you can drop them on the mail.” Admin / price-visible only.",
        },
        {
          type: "control",
          name: "Vendors",
          does: "Toggle chips for every vendor already on stock rows or past RFQs. Selected chips show a check. Empty state: No vendors on file yet — type one below.",
        },
        {
          type: "control",
          name: "Add a vendor",
          does: "Type a name not on the list. Enter or Add puts it on the chip row and selects it.",
        },
        {
          type: "control",
          name: "Add",
          does: "Adds the typed vendor name to the list and marks it selected.",
        },
        {
          type: "control",
          name: "Lines",
          does: "RFQ line list. Prefills from this PO’s buy rows (or the existing RFQ). Line adds a blank row.",
        },
        {
          type: "control",
          name: "Line",
          does: "Appends an empty material line you can type by hand.",
        },
        {
          type: "control",
          name: "Material",
          does: "Alloy / family on that RFQ line.",
        },
        {
          type: "control",
          name: "Type",
          does: "Grade / temper.",
        },
        {
          type: "control",
          name: "Shape",
          does: "Bar, plate, sheet, etc.",
        },
        {
          type: "control",
          name: "Size",
          does: "Size note the vendor will see.",
        },
        {
          type: "control",
          name: "Qty",
          does: "Buy qty for this RFQ line.",
        },
        {
          type: "control",
          name: "Unit",
          does: "in, ft, sheet, lbs, etc.",
        },
        {
          type: "control",
          name: "Part",
          does: "P/N (or list of P/Ns) this stock is for. Prefills from the buy row.",
        },
        {
          type: "control",
          name: "Note",
          does: "Line note. Prefills “Size TBD — confirm before buying” when size is missing.",
        },
        {
          type: "control",
          name: "Drawings",
          does: "Prints attached to this RFQ line. Empty: None — add the print if the vendor needs it. Tap a name to open. × is Remove from RFQ (does not delete the shop file).",
        },
        {
          type: "control",
          name: "Add drawing",
          does: "Upload PDF / image / DXF / DWG / TIF onto this RFQ line.",
        },
        {
          type: "control",
          name: "Email they will see",
          does: "Live preview of the plain-text RFQ body (company name, RFQ #, lines, vendors). Read-only.",
        },
        {
          type: "control",
          name: "Cancel",
          does: "Closes compose without sending. A newly created draft RFQ stays on file.",
        },
        {
          type: "control",
          name: "Send RFQ",
          does: "Requires at least one vendor and one material line. Downloads attached drawings so you can drop them on the email, marks the RFQ sent, opens mailto (or copies if the URL is too long: “RFQ copied — paste into one email and BCC your vendors”). Button reads Send RFQ + N drawing(s) when files are attached, or Sending… while it works. Toast: “{RFQ #} ready — send, then enter bids under Inventory → Vendor RFQs.” Errors: “Pick at least one vendor” / “Need at least one material line.”",
        },
      ],
    },
    {
      title: "Running order for this PO",
      blocks: [
        {
          type: "p",
          text: "Card under material. Only shows when this PO has open work-queue items. “Assigned to machines / people. Start here or from Shop Floor.” Each row: P/N × qty, machine or No machine, operator, status, note.",
        },
        {
          type: "control",
          name: "Up",
          does: "Moves that queue item earlier in this PO’s running order.",
        },
        {
          type: "control",
          name: "Down",
          does: "Moves that queue item later.",
        },
        {
          type: "control",
          name: "Load / start",
          does: "Starts the queue item on its machine. Disabled when status is done. Toast: “Loaded {P/N} on {machine}.” Error if the floor cannot start it (already running, machine busy, etc.).",
        },
        {
          type: "control",
          name: "Open machine",
          does: "Only if a machine is set. Opens that machine’s floor page.",
        },
        {
          type: "control",
          name: "Remove",
          does: "Pulls this assignment off the running order. The PO line stays. Assign again if you still need it run.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Enter a customer PO by hand",
        },
        {
          type: "ol",
          items: [
            "Tap New customer PO.",
            "Set Customer (create if they are new), PO #, Date required, Rating if the PO has one.",
            "Leave PO rev blank on the original.",
            "Tap Add line for each customer line. Type Part #, Rev, Qty, Units. Office types Cost and Tax?.",
            "Attach drawings/CAD (header multi-select or Add drawing / Add CAD on the expanded line). Name files with the P/N.",
            "Open Stock for each line (tap the stock text, ?, Fix, or Edit). Set material, size, LOC, and pick the rack row. Mark OK.",
            "Expand the line. Check PDF rev matches PO and Stock size noted (and CAD rev OK if CAD is attached) so the badge flips from Hold to Released.",
            "Assign the line, or leave it for Assign queue.",
          ],
        },
        {
          type: "h",
          text: "Import a customer package",
        },
        {
          type: "ol",
          items: [
            "Tap Import PO file.",
            "Drop the PO PDF plus every drawing and CAD file together. Keep “PO” in the purchase-order filename.",
            "Wait for the package note. Fix Customer, PO #, Date required, Rating, and any bad P/N / rev / qty.",
            "Drag unmatched files onto the Drawing or CAD cell, or pick the P/N and Attach.",
            "Check I checked customer, PO #, dates, lines, and file matches.",
            "Tap Create customer order. The new PO is selected. If the importer found problems, the follow-up banner appears — Review & email the customer.",
            "Walk each line: Check materials, Mark OK, then the three release checkboxes.",
          ],
        },
        {
          type: "h",
          text: "Revise a PO the customer already sent",
        },
        {
          type: "ol",
          items: [
            "Import the new package. Same PO # is already on file — do not Create as new order instead unless it really is a different job.",
            "Confirm New PO document rev (A on the first change).",
            "Tap Review & revise existing PO, read same / changed / added / dropped.",
            "If a dropped line already has shop work, either keep it or check Cancel N line(s) that already have shop work.",
            "Check the confirm box. Tap Apply PO revision.",
            "Re-check PDF rev / CAD rev on any line whose part rev changed — those checks were cleared.",
          ],
        },
        {
          type: "h",
          text: "Match stock and release a line",
        },
        {
          type: "ol",
          items: [
            "Tap Check materials if the rack or quote book just changed.",
            "On a ? line, tap Fix (or the stock text) to open Stock for {P/N}.",
            "Open Drawing. Set Material, Material type, Stock shape, How it sits, size, and LOC.",
            "Pick On the rack (matched stock). If nothing matches that exact size, the buy list will show a Buy qty — do not Mark OK and hope.",
            "Mark OK. Expand the line. Check PDF rev matches PO, Stock size noted, and CAD rev OK if CAD is attached.",
            "Badge must read Released before the floor should take it. Assign, or let Assign queue hand it out.",
          ],
        },
        {
          type: "h",
          text: "Hand a line to a person from this page",
        },
        {
          type: "ol",
          items: [
            "Confirm the line is Released and Open > 0.",
            "Tap Assign. Pick Operator. Machine (optional) if you already know which one.",
            "Set Qty to run if you are splitting the line. Add a Note if they should only run Op 2, wait on heat treat, etc.",
            "Tap Assign job. The row appears under Running order for this PO.",
            "They take it from My Jobs / the machine queue. Load / start from this card only if you are standing at the machine.",
          ],
        },
        {
          type: "h",
          text: "RFQ vendors for short material (office)",
        },
        {
          type: "ol",
          items: [
            "Finish stock on every line so Material for this PO is honest.",
            "Tap RFQ vendors (hidden on shop logins).",
            "Check the vendor chips. Add a vendor if they are not on file.",
            "Fix Size / Qty / Note. Add drawing if the mill needs the print.",
            "Read Email they will see. Tap Send RFQ (or Send RFQ + N drawings).",
            "Send the mail from your mail app. Enter bids later under Inventory → Vendor RFQs.",
          ],
        },
        {
          type: "h",
          text: "Follow up with the customer after a messy import",
        },
        {
          type: "ol",
          items: [
            "Use the amber banner, not a one-off email from memory.",
            "Tap Review & email. Read every issue badge.",
            "Confirm Send to. Add Extra note if needed.",
            "Email customer or Copy. Or Resolved if you already got the files another way.",
          ],
        },
        {
          type: "h",
          text: "Print a sales order or export QuickBooks (office)",
        },
        {
          type: "ol",
          items: [
            "Open the PO. Tap Sales Order / QB (hidden on shop logins).",
            "Confirm S.O. # and Sales tax %.",
            "Print Sales Order for the paper form, or QuickBooks CSV for QB.",
          ],
        },
        {
          type: "h",
          text: "Delete a PO",
        },
        {
          type: "ol",
          items: [
            "Only office. Prefer a revise (Dropped lines) if the customer cancelled after work started.",
            "Tap Delete PO. Read the warning — jobs on machines stay.",
            "Yes, delete. The list selection clears.",
          ],
        },
      ],
    },
  ],
};
