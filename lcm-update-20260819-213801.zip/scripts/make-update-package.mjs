#!/usr/bin/env node
/**
 * Build an LCM app update package for Settings → Update app.
 * Usage: node scripts/make-update-package.mjs [note]
 * Output: artifacts/lcm-update-YYYYMMDD-HHMMSS.zip
 *
 * Install on the shop PC: Settings → Update app → choose this zip.
 * Never include data/ (quotes, inventory, orders, drawings stay on the host).
 */
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const note = process.argv.slice(2).join(" ") || "App update";
const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\..+/, "").replace("T", "-");
const outDir =
  process.env.LCM_UPDATE_OUT ||
  (function pickOut() {
    const preferred = path.join(root, "artifacts");
    try {
      fs.mkdirSync(preferred, { recursive: true });
      fs.accessSync(preferred, fs.constants.W_OK);
      return preferred;
    } catch {
      const fallback = "/tmp/lcm-artifacts";
      fs.mkdirSync(fallback, { recursive: true });
      return fallback;
    }
  })();
const outZip = path.join(outDir, `lcm-update-${stamp}.zip`);

const REQUIRED_SRC = [
  "src/routes/quoting.tsx",
  "src/routes/po.tsx",
  "src/routes/board.tsx",
  "src/routes/machines.$machineId.tsx",
  "src/routes/inventory.tsx",
  "src/routes/lanes.tsx",
  "src/routes/assign.tsx",
  "src/routes/calendar.tsx",
  "src/store/lcm-store.ts",
  "src/components/lcm/guided-material-form.tsx",
  "src/components/lcm/guided-quote-wizard.tsx",
  "src/lib/lcm/job-board.ts",
  "src/lib/lcm/load-lanes.ts",
  "src/lib/lcm/op-slots.ts",
];

function countSrcFiles(dir) {
  if (!fs.existsSync(dir)) return 0;
  let n = 0;
  for (const name of fs.readdirSync(dir)) {
    const abs = path.join(dir, name);
    const st = fs.statSync(abs);
    if (st.isDirectory()) n += countSrcFiles(abs);
    else n += 1;
  }
  return n;
}

const srcCount = countSrcFiles(path.join(root, "src"));
const missing = REQUIRED_SRC.filter((rel) => !fs.existsSync(path.join(root, rel)));
if (srcCount < 180 || missing.length) {
  console.error(
    JSON.stringify(
      {
        ok: false,
        error:
          "Refusing to build update — this workspace is missing shop source. Restore the USB backup first; do not ship a scaffold.",
        srcFileCount: srcCount,
        missing,
      },
      null,
      2,
    ),
  );
  process.exit(1);
}

const guard = spawnSync(process.execPath, [path.join(root, "scripts", "patch-guard.mjs"), "check"], {
  encoding: "utf8",
});
if (guard.status !== 0) {
  console.error(
    JSON.stringify(
      {
        ok: false,
        error:
          "Refusing to build update — patch-guard check failed (wipe, missing file, or no feature lock). Restore with: node scripts/patch-guard.mjs abort",
        check: guard.stdout || guard.stderr,
      },
      null,
      2,
    ),
  );
  process.exit(1);
}

const version = stamp;
const lockSrc = path.join(root, "docs", "LCM-FEATURE-LOCK.md");
if (fs.existsSync(lockSrc)) {
  let lock = fs.readFileSync(lockSrc, "utf8");
  lock = lock.replace(
    /Last reviewed:.*$/m,
    `Last reviewed: ${new Date().toISOString().slice(0, 10)} · shipped in ${stamp}`,
  );
  fs.writeFileSync(lockSrc, lock);
  fs.mkdirSync(path.join(root, "artifacts"), { recursive: true });
  fs.writeFileSync(path.join(root, "artifacts", "LCM-FEATURE-LOCK.md"), lock);
}

// Keep a copy in artifacts (new Grok project) so the lock travels even if src is missing
const retain = [
  ["docs/LCM-FEATURE-LOCK.md", "artifacts/LCM-FEATURE-LOCK.md"],
  ["docs/LCM-PATCH-WORKFLOW.md", "artifacts/LCM-PATCH-WORKFLOW.md"],
  ["docs/LCM-START-HERE.md", "artifacts/LCM-START-HERE.md"],
  ["AGENTS.project.md", "artifacts/AGENTS.project.md"],
  ["scripts/patch-guard.mjs", "artifacts/scripts/patch-guard.mjs"],
];
for (const [from, to] of retain) {
  const src = path.join(root, from);
  const dest = path.join(root, to);
  if (!fs.existsSync(src)) continue;
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(src, dest);
}

const manifest = {
  appId: "lcm-data-management",
  format: 1,
  version,
  createdAt: new Date().toISOString(),
  note,
  // Relative paths included in the package (never data/ or node_modules/)
  include: [
    "src",
    "public",
    "scripts",
    "package.json",
    "package-lock.json",
    "vite.config.ts",
    "tsconfig.json",
    "startup.sh",
    "eslint.config.mjs",
    ".prettierrc",
    "HOW-TO-UPDATE.txt",
    "docs",
    "AGENTS.project.md",
  ],
};

const stage = path.join(root, "data", "updates", `_build-${stamp}`);
fs.rmSync(stage, { recursive: true, force: true });
fs.mkdirSync(stage, { recursive: true });
fs.writeFileSync(path.join(stage, "lcm-update.json"), JSON.stringify(manifest, null, 2));

// Heavy / non-essential paths — keep update zips small for browser upload
const EXCLUDE_DIR_NAMES = new Set(["node_modules", ".git", "data", "screenshots", "artifacts"]);

function shouldExclude(absPath) {
  const norm = absPath.replace(/\\/g, "/");
  if (norm.includes("/public/tutorial/")) return true;
  if (/\.(mp4|webm|zip|7z|rar|tar|gz)$/i.test(norm)) return true;
  if (/\/public\/lcm-update-/i.test(norm)) return true;
  return false;
}

function copyRecursive(src, dest) {
  const st = fs.statSync(src);
  if (st.isDirectory()) {
    const base = path.basename(src);
    if (EXCLUDE_DIR_NAMES.has(base)) return;
    fs.mkdirSync(dest, { recursive: true });
    for (const name of fs.readdirSync(src)) {
      if (EXCLUDE_DIR_NAMES.has(name)) continue;
      copyRecursive(path.join(src, name), path.join(dest, name));
    }
  } else {
    if (shouldExclude(src)) return;
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(src, dest);
  }
}

for (const rel of manifest.include) {
  const abs = path.join(root, rel);
  if (!fs.existsSync(abs)) {
    console.warn("skip missing", rel);
    continue;
  }
  copyRecursive(abs, path.join(stage, rel));
}

const py = `
import zipfile, os, sys
stage, out = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(stage):
        for f in files:
            p = os.path.join(root, f)
            z.write(p, os.path.relpath(p, stage))
print(out)
`;
const r = spawnSync("python3", ["-c", py, stage, outZip], { encoding: "utf8" });
if (r.status !== 0) {
  console.error(r.stderr || r.stdout);
  process.exit(1);
}
fs.rmSync(stage, { recursive: true, force: true });
const size = fs.statSync(outZip).size;
console.log(JSON.stringify({ ok: true, file: outZip, version, bytes: size, note }, null, 2));
console.log("\nGive this zip to the shop: Settings → Update app → Choose file");
try {
  const snap = spawnSync(process.execPath, [path.join(root, "scripts", "snapshot-live-src.mjs")], {
    encoding: "utf8",
  });
  if (snap.status === 0) {
    console.log("live src snapshot updated");
  } else {
    console.warn("live src snapshot skipped:", (snap.stderr || snap.stdout || "").slice(0, 200));
  }
} catch {
  /* optional */
}
