import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { useLcmStore } from "@/store/lcm-store";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { formatDate } from "@/lib/utils";

export const Route = createFileRoute("/uin")({
  validateSearch: (search: Record<string, unknown>): { c?: string } => {
    const out: { c?: string } = {};
    if (typeof search.c === "string" && search.c.trim()) out.c = search.c.trim();
    return out;
  },
  component: UinLookupPage,
});

function UinLookupPage() {
  const { c } = Route.useSearch();
  const getPartUnitByUin = useLcmStore((s) => s.getPartUnitByUin);
  const [code, setCode] = useState(c || "");
  const hit = useMemo(
    () => getPartUnitByUin(code || c || ""),
    [code, c, getPartUnitByUin],
  );

  return (
    <div className="mx-auto max-w-lg space-y-5 pb-10">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight flex items-center gap-2">
          <Search className="h-6 w-6 text-[var(--color-primary)]" />
          Extra part · UIN
        </h1>
        <p className="text-sm text-[var(--color-muted)] mt-1">
          Sharpie number on an extra part. Who ran it, when, part, rev, notes.
        </p>
      </div>
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">UIN</CardTitle>
          <CardDescription>Type or scan the 4-digit code.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Input
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="UIN"
            className="font-mono tracking-widest"
            autoFocus
          />
          {!hit && code.trim() ? (
            <p className="text-sm text-[var(--color-muted)]">No part for that UIN</p>
          ) : null}
          {hit ? (
            <div className="space-y-2 text-sm">
              <div className="font-mono text-2xl font-bold tracking-[0.2em]">
                {hit.uin}
              </div>
              <div className="font-mono font-semibold">
                {hit.partNumber} · Rev {hit.revision || "—"}
              </div>
              <Badge tone={hit.quality === "second" ? "warn" : "success"}>
                {hit.quality === "second" ? "Minor issues" : "Good extra"}
              </Badge>
              <div>
                Ran by {hit.operatorName || hit.stockedBy || "—"}
                {hit.stockedAt ? ` · ${formatDate(hit.stockedAt)}` : ""}
              </div>
              {hit.defectNote ? <p>{hit.defectNote}</p> : null}
              {hit.notes ? (
                <p className="text-[var(--color-muted)]">{hit.notes}</p>
              ) : null}
              <Link
                to="/pack"
                className="text-[var(--color-primary)] underline text-xs"
              >
                Open packing table
              </Link>
            </div>
          ) : null}
        </CardContent>
      </Card>
    </div>
  );
}
