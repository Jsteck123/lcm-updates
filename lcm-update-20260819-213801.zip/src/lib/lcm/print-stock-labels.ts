import { toast } from "sonner";
import { barcodeToDataUrl, scanUrlForBarcode } from "./barcode";
import {
  labelSizeLine,
  materialLabelBarcode,
  renderLabelMono,
} from "./brother-label-print";
import { printLabelOnShopHost } from "./print-label-api";
import { loadQlPrinterIp } from "./ql-printer";
import {
  ensureShopUnlocked,
  getShopToken,
  setShopToken,
  shopUnlockFromHostError,
} from "./shop-sync";
import type { MaterialStock } from "./types";

const MAX_COPIES = 40;

export function clampLabelCopies(raw: string | number): number {
  const n = Math.floor(Number(raw));
  if (!Number.isFinite(n) || n < 1) return 1;
  return Math.min(MAX_COPIES, n);
}

/** Print N copies of the same rack-size sticker for one Material stock line. Does not change on-hand. */
export async function printMaterialStockCopies(
  item: MaterialStock,
  copiesRaw: string | number,
  shopPublicUrl?: string,
): Promise<{ ok: true; printed: number; ip: string } | { ok: false; error: string }> {
  const copies = clampLabelCopies(copiesRaw);
  if (
    !(await ensureShopUnlocked("Unlock to print labels, then printing continues"))
  ) {
    return { ok: false, error: "Unlock this PC first, then print again." };
  }
  const ip = loadQlPrinterIp();
  if (!ip) {
    return {
      ok: false,
      error: "Set the QL-810W Wi-Fi address on the sample label page first.",
    };
  }
  const barcode = materialLabelBarcode(item.id);
  const qrDataUrl = await barcodeToDataUrl(
    scanUrlForBarcode(barcode, shopPublicUrl),
    220,
  );
  const line1 = `${item.material} ${item.materialType}`.trim();
  const line2 = labelSizeLine({
    sizeNote: item.sizeNote,
    stockShape: item.stockShape,
  });
  let last = ip;
  for (let i = 0; i < copies; i++) {
    const mono = await renderLabelMono({
      tapeId: "dk2210",
      barcode,
      qrDataUrl,
      line1,
      line2,
    });
    const r = await printLabelOnShopHost({
      data: {
        token: getShopToken() || undefined,
        ip,
        width: mono.width,
        height: mono.height,
        pixelsB64: mono.pixelsB64,
      },
    });
    if (!r.ok && shopUnlockFromHostError(r.error)) {
      setShopToken(null);
      if (
        !(await ensureShopUnlocked(
          "Unlock to print labels, then printing continues",
        ))
      ) {
        return { ok: false, error: r.error || "Unlock this PC first" };
      }
      const retry = await printLabelOnShopHost({
        data: {
          token: getShopToken() || undefined,
          ip,
          width: mono.width,
          height: mono.height,
          pixelsB64: mono.pixelsB64,
        },
      });
      if (!retry.ok) {
        return { ok: false, error: retry.error || "Print failed" };
      }
      last = retry.ip || last;
      continue;
    }
    if (!r.ok) {
      return { ok: false, error: r.error || "Print failed" };
    }
    last = r.ip || last;
  }
  return { ok: true, printed: copies, ip: last };
}

export async function printMaterialStockCopiesOrToast(
  item: MaterialStock,
  copiesRaw: string | number,
  shopPublicUrl?: string,
) {
  const r = await printMaterialStockCopies(item, copiesRaw, shopPublicUrl);
  if (!r.ok) {
    toast.error(r.error);
    return r;
  }
  toast.success(
    `${r.printed} label${r.printed === 1 ? "" : "s"} sent to ${r.ip}`,
  );
  return r;
}
