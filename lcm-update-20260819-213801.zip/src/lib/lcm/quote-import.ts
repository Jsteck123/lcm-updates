/**
 * Import historical quotes from Lake Country Machine Google Sheets.
 * Matches DATABASE / Historical Quotes headers from the original Apps Script:
 *
 * Date, Customer, Part #, Rev., Machines×3, Machine %, Material, Material Type,
 * Material %, Material Vendor, X, Y, Z, Raw Material Length, Rd/Sq/Ang Stock,
 * Raw Material Cost, Calculate Material Drop, Material Drop Multiplier,
 * Part Length Each, Setup Op1–6, Run Time Op1–6, Part Qty Placeholder 1–6,
 * Value Qty 1–6, QTY RUN, PART EFF %, …, OPERATOR, PART BONUS
 */

import type { Quote } from "./types";
import { DEFAULT_OPERATIONS, padSlots } from "./ops";
import { uid } from "@/lib/utils";
import { quoteKey } from "./po-material";

/** Exact header row from MAIN.GS dbHeaders (51 cols) */
export const LCM_DB_HEADERS = [
  "Date",
  "Customer",
  "Part #",
  "Rev.",
  "Machines",
  "Machines",
  "Machines",
  "Machine %",
  "Material",
  "Material Type",
  "Material %",
  "Material Vendor",
  "X",
  "Y",
  "Z",
  "Raw Material Length",
  "Rd/Sq/Ang Stock",
  "Raw Material Cost",
  "Calculate Material Drop",
  "Material Drop Multiplier",
  "Part Length Each",
  "Setup Op1",
  "Setup Op2",
  "Setup Op3",
  "Setup Op4",
  "Setup Op5",
  "Setup Op6",
  "Run Time Op1",
  "Run Time Op2",
  "Run Time Op3",
  "Run Time Op4",
  "Run Time Op5",
  "Run Time Op6",
  "Part Qty Placeholder 1",
  "Part Qty Placeholder 2",
  "Part Qty Placeholder 3",
  "Part Qty Placeholder 4",
  "Part Qty Placeholder 5",
  "Part Qty Placeholder 6",
  "Value Qty 1",
  "Value Qty 2",
  "Value Qty 3",
  "Value Qty 4",
  "Value Qty 5",
  "Value Qty 6",
  "QTY RUN",
  "PART EFF %",
  "PART START TIME",
  "PART STOP TIME",
  "OPERATOR",
  "PART BONUS",
] as const;

export type QuoteImportMode = "skip" | "update" | "keep_both";

export type QuoteImportResult = {
  created: number;
  updated: number;
  skipped: number;
  errors: string[];
  quotes: Quote[];
  /** Unique customer names on imported rows (for customer list upsert). */
  customerNames?: string[];
  preview: Array<{
    partNumber: string;
    revision: string;
    customer: string;
    action: "create" | "update" | "skip" | "error";
    note?: string;
  }>;
};

function normHeader(h: string): string {
  return String(h || "")
    .replace(/^\uFEFF/, "")
    .trim()
    .toLowerCase()
    // Keep Machine % / Material % distinct from Material; slash shapes → spaces
    .replace(/%/g, " pct")
    .replace(/[/\\]+/g, " ")
    .replace(/[.\s_#]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Map flexible / LCM headers to field keys */
const HEADER_ALIASES: Record<string, string> = {
  date: "date",
  customer: "customer",
  "part": "partNumber",
  "part number": "partNumber",
  "part #": "partNumber",
  "part no": "partNumber",
  "p n": "partNumber",
  "pn": "partNumber",
  rev: "revision",
  "rev ": "revision",
  revision: "revision",
  "machine %": "machineRate",
  "machine rate": "machineRate",
  "machine pct": "machineRate",
  material: "material",
  "material type": "materialType",
  "material %": "materialPct",
  "material pct": "materialPct",
  "material vendor": "materialVendor",
  vendor: "materialVendor",
  x: "dimX",
  diameter: "dimX",
  width: "dimX",
  y: "dimY",
  length: "dimY",
  z: "dimZ",
  height: "dimZ",
  thickness: "dimZ",
  "raw material length": "rawMaterialLength",
  "rd sq ang stock": "stockShape",
  "rd/sq/ang stock": "stockShape",
  "stock shape": "stockShape",
  "material shape": "stockShape",
  "stock type": "stockShape",
  shape: "stockShape",
  "raw material cost": "rawMaterialCost",
  "calculate material drop": "calculateMaterialDrop",
  "material drop multiplier": "dropMultiplier",
  "part length each": "partLengthEach",
  "qty run": "qtyRun",
  "part eff %": "partEff",
  "part eff": "partEff",
  operator: "operator",
  "part bonus": "partBonus",
};

function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let inQuotes = false;
  const s = text.replace(/^\uFEFF/, "");

  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    const next = s[i + 1];
    if (inQuotes) {
      if (ch === '"' && next === '"') {
        cell += '"';
        i++;
      } else if (ch === '"') {
        inQuotes = false;
      } else {
        cell += ch;
      }
      continue;
    }
    if (ch === '"') {
      inQuotes = true;
      continue;
    }
    if (ch === ",") {
      row.push(cell);
      cell = "";
      continue;
    }
    if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && next === "\n") i++;
      row.push(cell);
      cell = "";
      // skip fully empty trailing rows
      if (row.some((c) => String(c).trim())) rows.push(row);
      row = [];
      continue;
    }
    cell += ch;
  }
  row.push(cell);
  if (row.some((c) => String(c).trim())) rows.push(row);
  return rows;
}

/** HH:MM:SS, H:MM, decimal minutes, or Excel serial-ish → decimal minutes */
export function timeToMinutes(raw: unknown): number {
  if (raw == null || raw === "") return 0;
  if (typeof raw === "number" && Number.isFinite(raw)) {
    // Google Sheets time serial (fraction of day) if 0 < n < 1
    if (raw > 0 && raw < 1) return raw * 24 * 60;
    return raw;
  }
  const s = String(raw).trim();
  if (!s) return 0;
  // HH:MM:SS or H:MM
  const m = s.match(/^(\d+):(\d{1,2})(?::(\d{1,2}(?:\.\d+)?))?$/);
  if (m) {
    const h = Number(m[1]) || 0;
    const min = Number(m[2]) || 0;
    const sec = Number(m[3]) || 0;
    return h * 60 + min + sec / 60;
  }
  const n = Number(s.replace(/,/g, ""));
  return Number.isFinite(n) ? n : 0;
}

function num(raw: unknown): number {
  if (raw == null || raw === "") return 0;
  if (typeof raw === "number") return Number.isFinite(raw) ? raw : 0;
  let s = String(raw).replace(/[$%\s]/g, "").trim();
  // European decimal 1,1 / 1,25
  if (/^\d+,\d+$/.test(s)) s = s.replace(",", ".");
  else s = s.replace(/,/g, "");
  const n = Number(s);
  return Number.isFinite(n) ? n : 0;
}

/**
 * Machine % / Material %: sheet uses 1 = cost, 1.1 = 10% markup.
 * Accepts 1.1, 1.25, 110, "110%". Blank → null (caller defaults).
 */
export function parseRateMultiplier(raw: unknown): number | null {
  if (raw == null) return null;
  const original = String(raw).trim();
  if (!original) return null;
  const hasPct = /%/.test(original);
  const n = num(original);
  if (!Number.isFinite(n) || n <= 0) return null;
  if (hasPct) {
    // 110% → 1.1; leave small values alone
    const v = n > 5 ? n / 100 : n;
    return Math.round(v * 10000) / 10000;
  }
  // Whole percent points only (110 → 1.1). Keep 1.1 / 1.25 as-is.
  if (Number.isInteger(n) && n >= 10 && n <= 999) {
    return Math.round((n / 100) * 10000) / 10000;
  }
  return Math.round(n * 10000) / 10000;
}

export function normalizeImportedStockShape(raw: unknown): string {
  const s = String(raw ?? "").trim();
  if (!s) return "";
  const low = s.toLowerCase();
  if (
    low === "n/a" ||
    low === "na" ||
    low === "none" ||
    low === "-" ||
    low === "select" ||
    low === "rd/sq/ang stock" ||
    low === "rd sq ang stock"
  ) {
    return "";
  }
  return s;
}

function bool(raw: unknown): boolean {
  const s = String(raw ?? "")
    .trim()
    .toLowerCase();
  return s === "true" || s === "yes" || s === "1" || s === "y" || s === "TRUE";
}

function parseDate(raw: unknown): string {
  if (!raw) return new Date().toISOString().slice(0, 10);
  if (raw instanceof Date && !isNaN(raw.getTime())) {
    return raw.toISOString().slice(0, 10);
  }
  const s = String(raw).trim();
  // M/D/YYYY or MM/DD/YYYY
  const m = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/);
  if (m) {
    let y = m[3];
    if (y.length === 2) y = `20${y}`;
    return `${y}-${m[1].padStart(2, "0")}-${m[2].padStart(2, "0")}`;
  }
  // ISO
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
  const d = new Date(s);
  if (!isNaN(d.getTime())) return d.toISOString().slice(0, 10);
  return new Date().toISOString().slice(0, 10);
}

type ColMap = {
  byName: Record<string, number>;
  machineCols: number[];
  setupCols: number[];
  runCols: number[];
  qtyCols: number[];
  priceCols: number[];
};

function buildColMap(headers: string[]): ColMap {
  const byName: Record<string, number> = {};
  const machineCols: number[] = [];
  const setupCols: number[] = [];
  const runCols: number[] = [];
  const qtyCols: number[] = [];
  const priceCols: number[] = [];

  headers.forEach((h, i) => {
    const n = normHeader(h);
    if (n === "machines" || n === "machine") {
      machineCols.push(i);
      return;
    }
    const setupM = n.match(/^setup op\s*(\d+)$/);
    if (setupM) {
      setupCols[Number(setupM[1]) - 1] = i;
      return;
    }
    const runM = n.match(/^run time op\s*(\d+)$/) || n.match(/^runtime op\s*(\d+)$/);
    if (runM) {
      runCols[Number(runM[1]) - 1] = i;
      return;
    }
    const qtyM =
      n.match(/^part qty placeholder\s*(\d+)$/) ||
      n.match(/^qty\s*(\d+)$/) ||
      n.match(/^quantity\s*(\d+)$/);
    if (qtyM) {
      qtyCols[Number(qtyM[1]) - 1] = i;
      return;
    }
    const priceM =
      n.match(/^value qty\s*(\d+)$/) ||
      n.match(/^price\s*(\d+)$/) ||
      n.match(/^each\s*(\d+)$/);
    if (priceM) {
      priceCols[Number(priceM[1]) - 1] = i;
      return;
    }
    const key = HEADER_ALIASES[n];
    if (key && byName[key] == null) byName[key] = i;
  });

  return { byName, machineCols, setupCols, runCols, qtyCols, priceCols };
}

function cell(row: string[], idx: number | undefined): string {
  if (idx == null || idx < 0) return "";
  return String(row[idx] ?? "").trim();
}

export function rowToQuote(
  row: string[],
  map: ColMap,
  opCount = DEFAULT_OPERATIONS,
): Quote | null {
  const g = (key: string) => cell(row, map.byName[key]);
  const partNumber = g("partNumber").toUpperCase();
  if (!partNumber) return null;

  const machines = map.machineCols
    .map((i) => cell(row, i))
    .filter(Boolean);

  const setups: number[] = [];
  const runs: number[] = [];
  for (let i = 0; i < 6; i++) {
    setups.push(timeToMinutes(cell(row, map.setupCols[i])));
    runs.push(timeToMinutes(cell(row, map.runCols[i])));
  }

  const quantities: number[] = [];
  const prices: number[] = [];
  for (let i = 0; i < 6; i++) {
    quantities.push(num(cell(row, map.qtyCols[i])));
    prices.push(num(cell(row, map.priceCols[i])));
  }

  // Preserve 1.1 / 1.25 exactly — only convert clear percent-points (110) or "110%"
  const machineRate = parseRateMultiplier(g("machineRate")) ?? 1;
  const materialPct = parseRateMultiplier(g("materialPct")) ?? 1;

  const quote: Quote = {
    id: uid(),
    date: parseDate(g("date")),
    customer: g("customer"),
    partNumber,
    revision: g("revision").toUpperCase(),
    kind: "part",
    bom: [],
    benchAssembleMinutes: 0,
    machines: machines.length ? machines : [""],
    machineRate,
    material: g("material"),
    materialType: g("materialType"),
    materialPct,
    materialVendor: g("materialVendor"),
    dimX: num(g("dimX")),
    dimY: num(g("dimY")),
    dimZ: num(g("dimZ")),
    rawMaterialLength: num(g("rawMaterialLength")),
    stockShape: normalizeImportedStockShape(g("stockShape")),
    rawMaterialCost: num(g("rawMaterialCost")),
    calculateMaterialDrop: bool(g("calculateMaterialDrop")),
    dropMultiplier: num(g("dropMultiplier")) || 1,
    partLengthEach: num(g("partLengthEach")),
    setupTimes: padSlots(setups, opCount, 0),
    runTimes: padSlots(runs, opCount, 0),
    quantities: padSlots(quantities, 6, 0).slice(0, 6),
    prices: padSlots(prices, 6, 0).slice(0, 6),
    toolingCharges: [],
    qtyRun: num(g("qtyRun")) || undefined,
    partEff: num(g("partEff")) || undefined,
    operator: g("operator") || undefined,
    partBonus: num(g("partBonus")) || undefined,
  };
  return quote;
}

export function parseQuoteCsv(
  text: string,
  opCount = DEFAULT_OPERATIONS,
): { headers: string[]; quotes: Quote[]; errors: string[] } {
  const table = parseCsv(text);
  const errors: string[] = [];
  if (table.length < 2) {
    return {
      headers: [],
      quotes: [],
      errors: ["CSV is empty or has no data rows. Export DATABASE with header row."],
    };
  }
  const headers = table[0].map((h) => String(h || "").trim());
  const map = buildColMap(headers);
  if (map.byName.partNumber == null) {
    // try positional LCM layout: col C = index 2
    if (headers.length >= 3 && normHeader(headers[2]).includes("part")) {
      map.byName.partNumber = 2;
    } else if (headers.length >= 45) {
      // assume standard LCM order even if headers mangled
      map.byName.date = 0;
      map.byName.customer = 1;
      map.byName.partNumber = 2;
      map.byName.revision = 3;
      map.machineCols = [4, 5, 6];
      map.byName.machineRate = 7;
      map.byName.material = 8;
      map.byName.materialType = 9;
      map.byName.materialPct = 10;
      map.byName.materialVendor = 11;
      map.byName.dimX = 12;
      map.byName.dimY = 13;
      map.byName.dimZ = 14;
      map.byName.rawMaterialLength = 15;
      map.byName.stockShape = 16;
      map.byName.rawMaterialCost = 17;
      map.byName.calculateMaterialDrop = 18;
      map.byName.dropMultiplier = 19;
      map.byName.partLengthEach = 20;
      map.setupCols = [21, 22, 23, 24, 25, 26];
      map.runCols = [27, 28, 29, 30, 31, 32];
      map.qtyCols = [33, 34, 35, 36, 37, 38];
      map.priceCols = [39, 40, 41, 42, 43, 44];
      errors.push("Used standard LCM column order (headers not fully recognized).");
    } else {
      return {
        headers,
        quotes: [],
        errors: [
          'Could not find "Part #" column. Export the DATABASE or Historical Quotes sheet as CSV with the header row.',
        ],
      };
    }
  }

  const quotes: Quote[] = [];
  for (let r = 1; r < table.length; r++) {
    try {
      const q = rowToQuote(table[r], map, opCount);
      if (q) quotes.push(q);
    } catch (e) {
      errors.push(`Row ${r + 1}: ${e instanceof Error ? e.message : "parse error"}`);
    }
  }
  if (!quotes.length) {
    errors.push("No part rows found in CSV.");
  }
  return { headers, quotes, errors };
}

export function mergeQuotes(opts: {
  existing: Quote[];
  incoming: Quote[];
  mode: QuoteImportMode;
}): QuoteImportResult {
  const list = [...(opts.existing || [])];
  let created = 0;
  let updated = 0;
  let skipped = 0;
  const errors: string[] = [];
  const preview: QuoteImportResult["preview"] = [];

  const findIdx = (pn: string, rev: string) =>
    list.findIndex((q) => quoteKey(q) === quoteKey({ partNumber: pn, revision: rev, id: "" }));

  // Prefer newest date if multiple same pn without rev match — also match pn-only for update
  const findIdxPartOnly = (pn: string) =>
    list.findIndex((q) => q.partNumber.toUpperCase() === pn.toUpperCase());

  for (const q of opts.incoming) {
    let idx = findIdx(q.partNumber, q.revision);
    if (idx < 0 && !q.revision) idx = findIdxPartOnly(q.partNumber);

    if (idx < 0) {
      list.push(q);
      created++;
      preview.push({
        partNumber: q.partNumber,
        revision: q.revision,
        customer: q.customer,
        action: "create",
      });
      continue;
    }

    if (opts.mode === "skip") {
      skipped++;
      preview.push({
        partNumber: q.partNumber,
        revision: q.revision,
        customer: q.customer,
        action: "skip",
        note: "Already in database",
      });
      continue;
    }
    if (opts.mode === "keep_both") {
      // Same part #+rev is one recipe — never a second row.
      const prev = list[idx];
      list[idx] = {
        ...q,
        id: prev.id,
        kind: prev.kind === "assembly" ? "assembly" : q.kind,
        bom: prev.kind === "assembly" ? prev.bom : q.bom,
      };
      updated++;
      preview.push({
        partNumber: q.partNumber,
        revision: q.revision,
        customer: q.customer,
        action: "update",
        note: "Same part #+rev — updated existing",
      });
      continue;
    }
    // update — preserve id
    const prev = list[idx];
    list[idx] = {
      ...q,
      id: prev.id,
      kind: prev.kind === "assembly" ? "assembly" : q.kind,
      bom: prev.kind === "assembly" ? prev.bom : q.bom,
    };
    updated++;
    preview.push({
      partNumber: q.partNumber,
      revision: q.revision,
      customer: q.customer,
      action: "update",
    });
  }

  const customerNames = Array.from(
    new Set(
      list
        .map((q) => (q.customer || "").trim())
        .filter(Boolean),
    ),
  ).sort((a, b) => a.localeCompare(b));

  return {
    created,
    updated,
    skipped,
    errors,
    quotes: list,
    customerNames,
    preview,
  };
}

export function downloadSampleCsv(): string {
  const headers = [...LCM_DB_HEADERS];
  const sample = [
    "8/4/2026",
    "Sat-Lite Technologies",
    "SAMPLE-0001-01",
    "A",
    "HAAS VF2 MILL",
    "",
    "",
    "1.25",
    "Aluminum",
    "T6 6061",
    "1.25",
    "",
    "1.5",
    "0",
    "12",
    "144",
    "Round Stock",
    "40",
    "FALSE",
    "1",
    "2.5",
    "0:15:00",
    "0:10:00",
    "",
    "",
    "",
    "",
    "0:05:00",
    "0:04:00",
    "",
    "",
    "",
    "",
    "1",
    "5",
    "10",
    "25",
    "50",
    "100",
    "125",
    "95",
    "80",
    "70",
    "65",
    "60",
    "",
    "",
    "",
    "",
    "",
    "",
  ];
  const esc = (c: string) =>
    /[",\n]/.test(c) ? `"${c.replace(/"/g, '""')}"` : c;
  return [headers.map(esc).join(","), sample.map(esc).join(",")].join("\n");
}
