/**
 * Every sticker kind has its own scan landing and instructions.
 * Material / leftover-bar stickers open the cut-queue picker.
 * Job, PO, and ship labels will not use this page when we print them.
 */

export type LabelKind = "material" | "piece" | "box" | "uin" | "unknown";

export type LabelKindInfo = {
  kind: LabelKind;
  title: string;
  /** Floor-facing. Shown after the camera opens the sticker. */
  instructions: string;
};

export function classifyLabelCode(code: string): LabelKind {
  const up = (code || "").trim().toUpperCase();
  if (!up) return "unknown";
  if (up.startsWith("LCMBOX")) return "box";
  if (up.startsWith("LCMM")) return "material";
  if (up.startsWith("LCM")) return "piece";
  if (/^\d{4}$/.test(up) || /^[A-Z0-9]{4}$/.test(up)) return "uin";
  return "unknown";
}

export function labelKindInfo(kind: LabelKind): LabelKindInfo {
  if (kind === "box") {
    return {
      kind,
      title: "Packed box sticker",
      instructions:
        "This is a packed carton. The page shows customer, PO, part, rev, and qty. Check it off when it is loaded on the truck.",
    };
  }
  if (kind === "material") {
    return {
      kind,
      title: "Rack size sticker",
      instructions:
        "Jobs in the cut queue that use this material are listed. Pick the job you are running. Cut length and leftover qty fill in. Enter how many you just cut.",
    };
  }
  if (kind === "piece") {
    return {
      kind,
      title: "Leftover bar sticker",
      instructions:
        "This is one leftover bar. Matching cut-queue jobs are listed. Pick the job, enter how many you just cut. Remaining length on this bar drops by cut length × qty.",
    };
  }
  if (kind === "uin") {
    return {
      kind,
      title: "Extra part UIN",
      instructions:
        "This is an extra finished part. The page shows who ran it, when, part, rev, and notes. Packing Table prints this sticker — not the machine.",
    };
  }
  return {
    kind: "unknown",
    title: "Unknown sticker",
    instructions:
      "This code is not a rack, leftover-bar, packed-box, or extra-part sticker. Each label kind has its own instructions.",
  };
}
