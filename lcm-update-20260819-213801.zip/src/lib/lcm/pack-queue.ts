/**
 * Packing table: PO lines office/floor marked ready for pack, not yet boxed.
 * Extra parts the operator sent (UIN) show as soon as they hit Send to packing.
 */
import type { LineFileRef, PartUnit, ShopOrder, WorkQueueItem } from "./types";
import { lineDrawings } from "./line-files";
import { lineShipDate } from "./shipping-calendar";

export type PackTableLine = {
  orderId: string;
  lineId: string;
  poNumber: string;
  customer: string;
  partNumber: string;
  revision: string;
  description: string;
  qty: number;
  qtyCompleted: number;
  dueDate: string;
  readyForPackBy: string;
  drawings: LineFileRef[];
  packed: boolean;
};

export type PackTableOrder = {
  orderId: string;
  poNumber: string;
  customer: string;
  dueDate: string;
  lines: PackTableLine[];
};

export function packingTableOrders(
  orders: ShopOrder[],
  units: PartUnit[] = [],
): PackTableOrder[] {
  const out: PackTableOrder[] = [];
  for (const order of orders || []) {
    if (order.status === "cancelled" || order.deliveredAt) continue;
    const lines: PackTableLine[] = [];
    for (const line of order.lines || []) {
      if (line.lineStatus === "cancelled") continue;
      const extras = extrasForPackLine(units, {
        orderId: order.id,
        lineId: line.id,
        partNumber: line.partNumber || "",
      });
      const waiting = Boolean(line.readyForPack && !line.linePacked);
      if (!waiting && !extras.length) continue;
      lines.push({
        orderId: order.id,
        lineId: line.id,
        poNumber: order.poNumber || "(no PO)",
        customer: order.customer || "",
        partNumber: line.partNumber || "",
        revision: line.revision || "",
        description: line.description || "",
        qty: Number(line.qty) || 0,
        qtyCompleted: Number(line.qtyCompleted) || 0,
        dueDate: lineShipDate(order, line),
        readyForPackBy: line.readyForPackBy || "",
        drawings: lineDrawings(line),
        packed: Boolean(line.linePacked),
      });
    }
    if (!lines.length) continue;
    const due =
      lines.map((l) => l.dueDate).filter(Boolean).sort()[0] || "";
    out.push({
      orderId: order.id,
      poNumber: order.poNumber || "(no PO)",
      customer: order.customer || "",
      dueDate: due,
      lines,
    });
  }
  out.sort((a, b) => {
    const da = a.dueDate || "9999-12-31";
    const db = b.dueDate || "9999-12-31";
    if (da !== db) return da.localeCompare(db);
    return a.poNumber.localeCompare(b.poNumber);
  });
  return out;
}

export function packingTableLineCount(groups: PackTableOrder[]): number {
  return groups.reduce((n, g) => n + g.lines.length, 0);
}

function samePn(a: string, b: string) {
  return (a || "").trim().toUpperCase() === (b || "").trim().toUpperCase();
}

/** Extras sent to the packing table for this PO line (good / minor issues). */
export function extrasForPackLine(
  units: PartUnit[] | undefined,
  line: { orderId: string; lineId: string; partNumber: string },
): PartUnit[] {
  return (units || []).filter((u) => {
    if (u.status === "scrapped" || u.status === "issued") return false;
    if (u.lineId && u.lineId === line.lineId) return true;
    if (
      u.orderId &&
      u.orderId === line.orderId &&
      samePn(u.partNumber, line.partNumber)
    )
      return true;
    return false;
  });
}

function isPackingExtra(u: PartUnit): boolean {
  if (u.status === "scrapped" || u.status === "issued") return false;
  const loc = (u.location || "").toLowerCase();
  if (loc.includes("packing")) return true;
  if ((u.operatorName || "").trim()) return true;
  if ((u.jobRef || "").trim()) return true;
  return false;
}

/** Extras at packing that did not attach to an open PO line. */
export function packingTableLooseExtras(
  orders: ShopOrder[],
  units: PartUnit[] = [],
): PartUnit[] {
  const attached = new Set<string>();
  for (const g of packingTableOrders(orders, units)) {
    for (const l of g.lines) {
      for (const u of extrasForPackLine(units, l)) attached.add(u.id);
    }
  }
  return (units || []).filter(
    (u) => isPackingExtra(u) && !attached.has(u.id),
  );
}

/**
 * Tie a machine over-run to the PO line packing should see.
 * Prefer the loaded work-queue row, then open shop lines for that P/N.
 */
export function findShopLineForMachineJob(
  orders: ShopOrder[],
  queue: WorkQueueItem[],
  opts: {
    jobId?: string | null;
    machine?: string;
    partNumber: string;
    customer?: string;
  },
): { orderId: string; lineId: string } | null {
  const pn = (opts.partNumber || "").trim().toUpperCase();
  if (!pn) return null;
  const q = (queue || []).filter(
    (x) => (x.partNumber || "").toUpperCase() === pn,
  );
  const pick = (row?: WorkQueueItem) =>
    row && row.shopOrderId && row.shopOrderLineId
      ? { orderId: row.shopOrderId, lineId: row.shopOrderLineId }
      : null;
  const byJob = opts.jobId
    ? pick(q.find((x) => x.jobId && x.jobId === opts.jobId))
    : null;
  if (byJob) return byJob;
  const byMachine = opts.machine
    ? pick(
        q.find(
          (x) =>
            x.machine === opts.machine &&
            x.status !== "cancelled" &&
            x.status !== "done",
        ),
      )
    : null;
  if (byMachine) return byMachine;
  const anyQ = pick(
    q.find((x) => x.status !== "cancelled" && x.shopOrderId && x.shopOrderLineId),
  );
  if (anyQ) return anyQ;

  const cust = (opts.customer || "").trim().toLowerCase();
  const hits: { orderId: string; lineId: string; score: number }[] = [];
  for (const o of orders || []) {
    if (o.status === "cancelled" || o.deliveredAt) continue;
    for (const l of o.lines || []) {
      if (l.lineStatus === "cancelled") continue;
      if ((l.partNumber || "").toUpperCase() !== pn) continue;
      let score = 1;
      if (cust && (o.customer || "").trim().toLowerCase() === cust) score += 3;
      if (!l.linePacked) score += 2;
      if (l.readyForPack) score += 1;
      hits.push({ orderId: o.id, lineId: l.id, score });
    }
  }
  hits.sort((a, b) => b.score - a.score);
  return hits[0]
    ? { orderId: hits[0].orderId, lineId: hits[0].lineId }
    : null;
}
