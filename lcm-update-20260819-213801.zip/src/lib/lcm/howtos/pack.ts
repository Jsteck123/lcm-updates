import type { PageHowToDoc } from "./types";

export const packingTableHowTo: PageHowToDoc = {
  id: "packing-table",
  path: "/pack",
  title: "Packing Table",
  tab: "pack",
  whatThisPageIs:
    "The packer’s cut-queue. Ready-for-pack jobs sit here with a drawing. Pack the ordered qty (example: ordered 10, ran 11 → pack 10). Packed prints the 1.1×2 box label, then a UIN sticker for each extra (who, when, part, rev, notes, QR). Extra parts the operator sent (4-digit sharpie UIN) show as Good / Minor issues as soon as they send them. Print extra labels only here — machines do not print UIN stickers. Pam scans the box QR onto the truck.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "Soonest due first. One card per PO that has something on the table. Ordered / ran / pack counts sit on the line. Extra UIN rows stay after the box is packed so you can still print the extra sticker. After Packed, Ship Calendar still has the order for office verify / Friday run. The QR is Pam’s truck scan — not this page.",
        },
        {
          type: "ul",
          items: [
            "Picture is the line drawing. Tap it to open the print.",
            "Packed uses the same box label as Ship Calendar Mark packed.",
            "Reset pack on the calendar puts a line back on this table.",
          ],
        },
      ],
    },
    {
      title: "Page chrome",
      blocks: [
        {
          type: "control",
          name: "Packing Table",
          does: "Page title. Subtitle: pack, print the box label, stick it on. Pam scans the QR to load the truck.",
        },
        {
          type: "control",
          name: "N orders on the table",
          does: "How many POs have at least one unpacked ready line, plus how many lines are waiting.",
        },
      ],
    },
    {
      title: "Order card",
      blocks: [
        {
          type: "control",
          name: "PO #",
          does: "Customer PO. Due date is the PO calendar day. Open full PO jumps to Customer Orders on this order.",
        },
        {
          type: "control",
          name: "Line row",
          does: "Drawing thumb, part #, rev, description, ordered / ran / pack qty, extras, who marked ready. Packed prints the box label (order qty) then extra UIN labels.",
        },
        {
          type: "control",
          name: "Packed",
          does: "Marks the line packed, prints the 1.1×2 box label (QR left, text right). If extras are on the line it then prints a UIN sticker for each extra (who ran it, when, part, rev, notes, QR). Needs PIN if this PC is locked. Same printer as inventory.",
        },
        {
          type: "control",
          name: "Extra UIN row",
          does: "One row per extra the operator sent: 4-digit UIN, Good or Minor issues, who, when, notes. Print extra label reprints that sticker. Machines never print these.",
        },
        {
          type: "control",
          name: "Look up UIN",
          does: "Type the 4-digit sharpie number. Shows who ran it, when, part, rev, and notes. Print extra label from the hit. Same lookup as scanning the extra QR (/uin).",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Pack a job",
        },
        {
          type: "ol",
          items: [
            "Open Packing Table. Find the PO.",
            "Match the picture and part # to the parts on the table.",
            "Put the ordered qty in the box. Tap Packed.",
            "Stick the box label on. Extra UIN stickers print after the box label — stick those on the extra parts.",
            "The order line leaves the pack queue (extras stay until labeled). Leave the box for Pam’s truck scan.",
          ],
        },
        {
          type: "h",
          text: "Extra good / minor-issue part",
        },
        {
          type: "ol",
          items: [
            "Operator already wrote the 4-digit UIN on the part and sent it here.",
            "Match ordered vs ran on the line (10 ordered, 11 ran → pack 10, 1 extra).",
            "Tap Packed (prints box + extra labels) or Print extra label on that UIN row.",
            "Look up UIN later if you need the notes.",
          ],
        },
      ],
    },
  ],
};
