/**
 * One shop language for stock.
 *
 * X Y Z = the blank sitting in the machine (not the finished model).
 * LOC   = stock length used per part (the cut you take off the bar/plate).
 * Mill: pick which axis is that LOC. Lathe: Z is the length / LOC. X is diameter.
 */
import type { LocAxis, ShopOrder, ShopOrderLine } from "./types";
import { profileForShape, isSheetOrPlate } from "./stock-shapes";

export type StockProcess = "mill" | "lathe" | "";

const SHAPE_ALIASES: Record<string, string> = {
  rd: "Round Stock",
  round: "Round Stock",
  "round stock": "Round Stock",
  "round bar": "Round Stock",
  bar: "Round Stock",
  "bar stock": "Round Stock",
  hex: "Hex Stock",
  "hex stock": "Hex Stock",
  sq: "Square Stock",
  square: "Square Stock",
  "square stock": "Square Stock",
  rect: "Rectangular Stock",
  rectangle: "Rectangular Stock",
  "rectangle stock": "Rectangular Stock",
  "rectangular stock": "Rectangular Stock",
  flat: "Flat Bar",
  "flat bar": "Flat Bar",
  "flat stock": "Flat Bar",
  plate: "Plate",
  sheet: "Flat Sheet",
  "flat sheet": "Flat Sheet",
  "cast plate": "Cast Plate",
  tube: "Round Tube",
  "round tube": "Round Tube",
  "square tube": "Square Tube",
  pipe: "Pipe",
  angle: "Angle Stock",
  "angle stock": "Angle Stock",
  channel: "Channel",
};

const PLACEHOLDER = new Set([
  "",
  "material shape",
  "material type",
  "rd/sq/ang stock",
  "rd sq ang stock",
  "stock shape",
  "shape",
  "n/a",
  "na",
  "none",
  "-",
  "select",
]);

export function isPlaceholderShape(raw: string): boolean {
  return PLACEHOLDER.has((raw || "").trim().toLowerCase());
}

export function canonicalizeShape(raw: string): string {
  const s = (raw || "").trim();
  if (isPlaceholderShape(s)) return "";
  const hit = SHAPE_ALIASES[s.toLowerCase()];
  return hit || s;
}

export function guessProcess(opts: {
  process?: StockProcess;
  machines?: string[];
  stockShape?: string;
}): StockProcess {
  if (opts.process === "mill" || opts.process === "lathe") return opts.process;
  const machines = opts.machines || [];
  const millish = machines.some((m) => /mill|vf|vm|umc|dt|dmtg/i.test(m));
  const latheish = machines.some((m) => /lathe|sl-|st-|ds\d|tl-/i.test(m));
  if (latheish && !millish) return "lathe";
  if (millish && !latheish) return "mill";
  const id = profileForShape(canonicalizeShape(opts.stockShape || "")).id;
  if (id === "round" || id === "hex" || id === "round-tube" || id === "pipe")
    return "lathe";
  if (id === "sheet" || id === "rectangular" || id === "flat-bar" || id === "square")
    return "mill";
  return "";
}

export function guessShapeFromDims(opts: {
  dimX: number;
  dimY: number;
  dimZ: number;
  machines?: string[];
}): string {
  const x = Number(opts.dimX) || 0;
  const y = Number(opts.dimY) || 0;
  const z = Number(opts.dimZ) || 0;
  const proc = guessProcess({ machines: opts.machines });
  if (proc === "lathe") return "Round Stock";
  if (x > 0 && !(y > 0)) return "Round Stock";
  if (x > 0 && y > 0 && Math.abs(x - y) < 0.02) return "Square Stock";
  if (z > 0 && z < 1 && (x >= 6 || y >= 6)) return "Plate";
  if (x > 0 && y > 0) return "Rectangular Stock";
  return "";
}

export type AxisKey = "x" | "y" | "z";

export function axisLabels(
  shape: string,
  process: StockProcess = "",
): Record<AxisKey, string> {
  if (process === "lathe") {
    return {
      x: "X · diameter",
      y: "Y · (not used)",
      z: "Z · length / LOC",
    };
  }
  const id = profileForShape(shape).id;
  if (id === "round" || id === "hex") {
    return {
      x: id === "hex" ? "X · across flats" : "X · diameter",
      y: "Y · (not used)",
      z: "Z · length in the machine",
    };
  }
  if (id === "sheet") {
    return {
      x: "X · width in the machine",
      y: "Y · length in the machine",
      z: "Z · thickness",
    };
  }
  return {
    x: "X · as it sits in the mill",
    y: "Y · as it sits in the mill",
    z: "Z · as it sits in the mill",
  };
}

export function defaultLocAxis(
  shape: string,
  process: StockProcess = "",
): LocAxis {
  if (process === "lathe") return "z";
  const id = profileForShape(shape).id;
  if (id === "round" || id === "hex" || id === "round-tube" || id === "pipe")
    return "z";
  if (id === "sheet") return "x";
  return "z";
}

export function locChoices(
  shape: string,
  process: StockProcess = "",
): { axis: LocAxis; label: string }[] {
  if (process === "lathe") {
    return [{ axis: "z", label: "Z · stock length used per part (LOC)" }];
  }
  return [
    { axis: "x", label: "X · stock used per part (LOC)" },
    { axis: "y", label: "Y · stock used per part (LOC)" },
    { axis: "z", label: "Z · stock used per part (LOC)" },
  ];
}

export function locValue(
  axis: LocAxis | "",
  dims: { dimX: number; dimY: number; dimZ: number },
): number {
  if (axis === "x") return Number(dims.dimX) || 0;
  if (axis === "y") return Number(dims.dimY) || 0;
  if (axis === "z") return Number(dims.dimZ) || 0;
  return 0;
}

export function describeStock(opts: {
  material?: string;
  materialType?: string;
  stockShape: string;
  dimX: number;
  dimY: number;
  dimZ: number;
  locAxis?: LocAxis | "";
  partLengthEach?: number;
  stockProcess?: StockProcess;
}): string {
  const alloy = [opts.material, opts.materialType].filter(Boolean).join(" ");
  const shape = canonicalizeShape(opts.stockShape) || "stock";
  const proc = opts.stockProcess || "";
  const x = Number(opts.dimX) || 0;
  const y = Number(opts.dimY) || 0;
  const z = Number(opts.dimZ) || 0;
  let size = "";
  if (proc === "lathe" || profileForShape(shape).id === "round") {
    size = x ? `${x}" Ø` : "";
    if (z) size += size ? ` × ${z}" long` : `${z}" long`;
  } else {
    size = [x, y, z].filter((n) => n > 0).map((n) => `${n}"`).join(" × ");
  }
  const loc = Number(opts.partLengthEach) || locValue(opts.locAxis || "", opts);
  const locBit = loc
    ? ` LOC ${loc}" per part${opts.locAxis && opts.locAxis !== "dia" ? ` (${opts.locAxis.toUpperCase()})` : ""}.`
    : "";
  return [alloy, shape, size].filter(Boolean).join(" · ") + locBit;
}

export function findShopLineForPart(
  orders: ShopOrder[],
  partNumber: string,
  revision?: string,
): { orderId: string; line: ShopOrderLine } | null {
  const pn = (partNumber || "").trim().toUpperCase();
  if (!pn) return null;
  const rev = (revision || "").trim().toUpperCase();
  let loose: { orderId: string; line: ShopOrderLine } | null = null;
  for (const o of orders || []) {
    for (const line of o.lines || []) {
      if ((line.partNumber || "").trim().toUpperCase() !== pn) continue;
      if (rev && (line.revision || "").trim().toUpperCase() === rev) {
        return { orderId: o.id, line };
      }
      if (!loose) loose = { orderId: o.id, line };
    }
  }
  return loose;
}

export function stockIsPicked(line: {
  material?: string;
  dimX?: number;
  dimY?: number;
  dimZ?: number;
  partLengthEach?: number;
  locAxis?: string;
  materialReviewed?: boolean;
}): boolean {
  if (line.materialReviewed) return true;
  if ((Number(line.partLengthEach) || 0) > 0) return true;
  if (line.locAxis) return true;
  return (
    Boolean((line.material || "").trim()) &&
    ((Number(line.dimX) || 0) > 0 ||
      (Number(line.dimY) || 0) > 0 ||
      (Number(line.dimZ) || 0) > 0)
  );
}

export { isSheetOrPlate };
