import type { PageHowToDoc } from "./types";

export const assignQueueHowTo: PageHowToDoc = {
  id: "assign-queue",
  path: "/assign",
  title: "Assign queue",
  tab: "assign",
  audience: "admin",
  whatThisPageIs:
    "Admin desk queue: walk released customer-order parts, open the drawing full screen, and hand each one to a person (machine optional) without leaving the print. Skip bumps a part to the bottom. Charts show booked hours from quoted setup + run. Shop logins see “Admin only — desk walkthrough to hand parts to people” and cannot use this page.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "The list is built from open customer POs. Cancelled orders, delivered orders, cancelled lines, packed lines, and lines with no P/N or description do not show. Assemblies split: each component job first, then the parent assembly to bolt together. A quote that uses two or more machines (lathe then mill then lathe) splits into one row per remaining timed OP — assign Luke OP1, Gayle OP2, Luke OP3. A 3-op mill job on one machine stays one row. A row stays here until it is both office-assigned and actually pulled onto that person’s board.",
        },
        {
          type: "p",
          text: "Click a part. The drawing opens full screen with the assign bar at the bottom. Operator is required. Machine is optional — if you pick one, the job also goes on that machine’s queue. On a split OP row the quoted machine is prefilled (you can change it). Assign & next writes that OP (or the whole part) to My Jobs. If the same part still has another OP in the queue, the modal stays open on the next OP. Skip for later keeps it in the queue but parks it at the bottom for this browser session.",
        },
        {
          type: "p",
          text: "Sort is soonest ship date, then part number. Filter is local. Skips are stored in this browser’s session only — they are not shop-wide, and skip markers for parts that left the queue are dropped automatically.",
        },
        {
          type: "note",
          text: "Admin only. Hours on the charts and the ~Nh badge come from the quote book (setup + run × qty). No quote for that P/N means no hours — the part still assigns.",
        },
        {
          type: "warn",
          text: "Assigning here is the desk hand-off. It does not start a timer. The operator still takes the job on the Job Board / machine page. A badge “{name} — tap to put on board” means you already named a person but they have not pulled it yet — tap again to finish putting it on their board.",
        },
      ],
    },
    {
      title: "Top of the page",
      blocks: [
        {
          type: "p",
          text: "Title Assign queue. Subtitle: Open drawing → pick person (machine optional) without leaving the print. Skip bumps to the bottom. Charts show booked hours from quoted setup + run. Link: Load lanes lays those hours on the week.",
        },
        {
          type: "control",
          name: "{n} waiting · {n} skipped",
          does: "Badge. Waiting is how many rows are in the filtered list. Skipped is how many you bumped to the bottom this session. Hidden skip count when none are skipped.",
        },
      ],
    },
    {
      title: "Workload charts",
      blocks: [
        {
          type: "control",
          name: "Machine workload",
          does: "Bar chart of quoted hours on open assignments + the running order, by machine. Only names on your machine list (Settings / Shop Floor list) get a bar. Old quote nicknames like Haas Lathe or Mazak Mill are ignored — they are not stations. Description on the card: Quoted hours on open assignments + running order. Empty: “No machines booked yet — assign with a machine to fill this.” Hover a bar: “N h · N job(s).” Up to 12 machines. Y axis is hours.",
        },
        {
          type: "control",
          name: "Operator workload",
          does: "Bar chart of quoted hours already handed to each person. Description: Quoted hours handed to each person. Empty: “No operators assigned yet.” Same hover format. Use this before you pile a fourth job on someone who is already booked.",
        },
      ],
    },
    {
      title: "Filter and skips",
      blocks: [
        {
          type: "control",
          name: "Filter part #, PO, customer…",
          does: "Narrows the list to rows whose part number, PO #, customer, or description contains what you type. Case-insensitive. Does not change the skip order — skipped matches still sit at the bottom.",
        },
        {
          type: "control",
          name: "Clear skips",
          does: "Only shows when something is skipped. Restores normal due-date order for every skipped part in this session. Toast: “Skipped items restored to normal order.”",
        },
      ],
    },
    {
      title: "Parts to assign",
      blocks: [
        {
          type: "p",
          text: "Card title Parts to assign. “Click a line to open the drawing and assign. Skipped items stay at the bottom.” Empty: “Nothing waiting. When orders land with part numbers, they show here.”",
        },
        {
          type: "control",
          name: "Parts to assign",
          does: "Each row is a button. Click opens the drawing modal and selects that part. Shows #order in the current list, P/N (or “(no P/N)”), Rev {rev}, OP1 / OP2 when the quote splits by machine, quoted machine chip, kind badge (component / assembly / part), skipped · later if you bumped it, {name} — tap to put on board if office already named a person, and ~Nh for that OP (or the whole part). Second line: PO {#} · customer · qty N · under {parent} for components. File chips: Drawing names (up to 3), CAD (up to 2), or red No drawing. Dashed / faded = skipped. Selected row is highlighted.",
        },
        {
          type: "control",
          name: "Remove",
          does: "Editor mode only (admin editor). Hides this part from the board / queue. Confirm: “Remove this from the board / queue? The customer PO stays. You can assign it again later from Customer Orders.” Toast “Removed {P/N}” or the error. The PO line is not deleted.",
        },
      ],
    },
    {
      title: "How it works (side card)",
      blocks: [
        {
          type: "p",
          text: "Wide screens only. Title How it works. The three steps on the card: 1. Click a part — drawing opens full screen with assign bar at the bottom. 2. Choose operator (required) and machine (optional) while you look at the print. 3. Assign & next puts it on that person’s Job Board (My Jobs) and their machine queue if you pick a machine. Charts update from quoted setup + runtime when that part is in the quote book.",
        },
        {
          type: "control",
          name: "Open drawing & assign",
          does: "Opens the selected part’s drawing modal. Same as clicking the row. Only shows when a row is selected.",
        },
        {
          type: "control",
          name: "Skip for later",
          does: "On the side card. Parks the selected part at the bottom, closes nothing if the modal is not open, toast “{P/N} moved to bottom of queue,” and jumps selection to the next non-skipped row.",
        },
      ],
    },
    {
      title: "Assign from drawing",
      blocks: [
        {
          type: "p",
          text: "Full-screen dialog (aria-label Assign from drawing). Top bar: P/N · Rev · PO · customer · qty · ~Nh quoted. Escape or Close dismisses without assigning. If several files are on the part, tabs switch between them. CAD tabs are labeled CAD; drawings use the file name.",
        },
        {
          type: "control",
          name: "CAD / drawing tabs",
          does: "When more than one file is attached, tap a tab to preview that file. Images and PDFs preview in place. Other types show “Preview not available for this file type” plus Download {filename}. Loading drawing… while the host fetches. “No drawing attached — still assign from the bar below” if there is no file.",
        },
        {
          type: "control",
          name: "Close",
          does: "Closes the modal. Operator / machine / note on the page reset the next time you open a row. The part stays in the queue.",
        },
        {
          type: "control",
          name: "Operator (required)",
          does: "Who this part is for. First option: — Who runs this? — Active operators, A–Z. Assign & next stays disabled until you pick a name. Confirm with no name toasts “Pick who this part is for.”",
        },
        {
          type: "control",
          name: "Machine (optional)",
          does: "First option: — None / later —. Shop machine list. Leave none if you only want it on that person’s My Jobs. Pick one to also park it on that machine’s queue.",
        },
        {
          type: "control",
          name: "Note",
          does: "Optional. Rides with the assignment. Placeholder: Op 2 only…",
        },
        {
          type: "control",
          name: "Skip for later",
          does: "On the assign bar (title “Keep in queue, move to bottom”). Same as the side-card skip: part goes to the bottom, modal closes, fields clear, next non-skipped part is selected. Toast: “{P/N} moved to bottom of queue.”",
        },
        {
          type: "control",
          name: "Assign & next",
          does: "Writes the desk assignment (operator required, machine and note optional). On a split row this is that OP only. Toast: “{P/N} {OPn} is {name}’s job · {machine}.” If the same part still has a later OP waiting, the modal stays open and prefills that OP’s quoted machine. Otherwise it closes and clears the fields. Error toast if assign fails.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Walk the pile",
        },
        {
          type: "ol",
          items: [
            "Sign in as admin. Shop logins cannot open this queue.",
            "Glance at Machine workload and Operator workload so you do not overload one person or one mill.",
            "Click the first part. Read the print. Confirm rev and qty on the top bar.",
            "Pick Operator (required). Pick Machine if you already know which one.",
            "Type a Note only if they should not run the whole job as-is.",
            "Tap Assign & next. Repeat until the waiting badge is 0.",
          ],
        },
        {
          type: "h",
          text: "Skip a part you cannot assign yet",
        },
        {
          type: "ol",
          items: [
            "Open the part. If the print is missing, the rev is wrong, or you need to ask the office, tap Skip for later.",
            "The row goes dashed at the bottom with skipped · later.",
            "Finish the rest of the pile, then come back to the skipped rows — or Clear skips to put them back in due-date order.",
            "Skips die when you close this browser tab. They are not saved for the next person.",
          ],
        },
        {
          type: "h",
          text: "Finish a name you already wrote",
        },
        {
          type: "ol",
          items: [
            "If a row already shows “{name} — tap to put on board,” that person was named but the job is not on their board yet.",
            "Click the row. Confirm Operator (and machine if you want).",
            "Assign & next puts it on My Jobs / the machine queue.",
          ],
        },
        {
          type: "h",
          text: "Find one PO or part",
        },
        {
          type: "ol",
          items: [
            "Type in Filter part #, PO, customer…",
            "Click the match. Assign or skip as usual.",
            "Clear the filter to see the full pile again.",
          ],
        },
        {
          type: "h",
          text: "Hide a line from the queue (editor)",
        },
        {
          type: "ol",
          items: [
            "Turn on editor mode.",
            "On the row, tap Remove. Confirm the dialog — the customer PO stays.",
            "Re-assign later from Customer Orders if the part still needs to run.",
          ],
        },
      ],
    },
  ],
};
