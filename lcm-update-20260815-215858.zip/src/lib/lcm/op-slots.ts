/**
 * Per-OP assign / pull for jobs that run on more than one machine.
 * Single-machine parts stay one card (Gayle still takes the whole mill job).
 */
import type { Quote, ShopOpAssignment } from "./types";
import { opLabel } from "./ops";

export function emptyOpAssignment(
  partial?: Partial<ShopOpAssignment>,
): ShopOpAssignment {
  return {
    opIndex: Math.max(0, Math.floor(Number(partial?.opIndex) || 0)),
    officeAssignedTo: partial?.officeAssignedTo || "",
    officeAssignedMachine: partial?.officeAssignedMachine || "",
    officeAssignedAt: partial?.officeAssignedAt || "",
    officeAssignNotes: partial?.officeAssignNotes || "",
    checkedOutBy: partial?.checkedOutBy || "",
    checkedOutAt: partial?.checkedOutAt || "",
    checkedOutMachine: partial?.checkedOutMachine || "",
    complete: Boolean(partial?.complete),
    completedAt: partial?.completedAt || "",
    completedBy: partial?.completedBy || "",
  };
}

export function normalizeOpAssignments(
  list: ShopOpAssignment[] | undefined | null,
): ShopOpAssignment[] {
  if (!Array.isArray(list)) return [];
  const seen = new Set<number>();
  const out: ShopOpAssignment[] = [];
  for (const raw of list) {
    if (!raw || typeof raw !== "object") continue;
    const slot = emptyOpAssignment(raw);
    if (seen.has(slot.opIndex)) continue;
    seen.add(slot.opIndex);
    out.push(slot);
  }
  return out.sort((a, b) => a.opIndex - b.opIndex);
}

export function upsertOpAssignment(
  list: ShopOpAssignment[] | undefined,
  opIndex: number,
  patch: Partial<ShopOpAssignment>,
): ShopOpAssignment[] {
  const next = normalizeOpAssignments(list);
  const i = next.findIndex((s) => s.opIndex === opIndex);
  const merged = emptyOpAssignment({
    ...(i >= 0 ? next[i] : { opIndex }),
    ...patch,
    opIndex,
  });
  if (i >= 0) {
    next[i] = merged;
    return next;
  }
  return [...next, merged].sort((a, b) => a.opIndex - b.opIndex);
}

export function getOpAssignment(
  list: ShopOpAssignment[] | undefined,
  opIndex: number,
): ShopOpAssignment | undefined {
  return normalizeOpAssignments(list).find((s) => s.opIndex === opIndex);
}

/** Timed quote slots (setup or run > 0). */
export function timedOpIndexes(q: Quote | undefined | null): number[] {
  if (!q) return [];
  const setups = q.setupTimes || [];
  const runs = q.runTimes || [];
  const n = Math.max(setups.length, runs.length);
  const out: number[] = [];
  for (let i = 0; i < n; i++) {
    if ((Number(setups[i]) || 0) > 0 || (Number(runs[i]) || 0) > 0) out.push(i);
  }
  return out;
}

function uniqueMachines(names: string[]): string[] {
  const out: string[] = [];
  for (const raw of names) {
    const t = String(raw || "").trim();
    if (!t) continue;
    if (out.some((x) => x.toLowerCase() === t.toLowerCase())) continue;
    out.push(t);
  }
  return out;
}

/** Machine named on this OP — explicit opMachines, else 1:1 machines bag, else single-machine bag. */
export function quoteOpMachine(
  q: Quote | undefined | null,
  opIndex: number,
): string {
  if (!q) return "";
  const explicit = String((q.opMachines || [])[opIndex] || "").trim();
  if (explicit) return explicit;
  const timed = timedOpIndexes(q);
  const bag = uniqueMachines(q.machines || []);
  if (bag.length === timed.length) {
    const pos = timed.indexOf(opIndex);
    if (pos >= 0 && bag[pos]) return bag[pos]!;
  }
  if (bag.length === 1) return bag[0]!;
  return "";
}

/**
 * True when this part should split into per-OP cards.
 * 2+ timed ops and 2+ distinct machines (mapped or listed).
 */
export function isMultiMachinePart(q: Quote | undefined | null): boolean {
  const timed = timedOpIndexes(q);
  if (timed.length < 2) return false;
  const mapped = uniqueMachines(timed.map((i) => quoteOpMachine(q, i)));
  if (mapped.length >= 2) return true;
  const bag = uniqueMachines(q?.machines || []);
  return bag.length >= 2;
}

export function quoteForPn(
  quotes: Quote[] | undefined,
  partNumber: string,
): Quote | undefined {
  const pn = String(partNumber || "")
    .trim()
    .toUpperCase();
  if (!pn) return undefined;
  const exact = (quotes || []).filter(
    (q) =>
      String(q.partNumber || "")
        .trim()
        .toUpperCase() === pn,
  );
  if (exact.length === 1) return exact[0];
  if (exact.length > 1) {
    return [...exact].sort((a, b) =>
      String(b.date || "").localeCompare(String(a.date || "")),
    )[0];
  }
  return undefined;
}

export function partIsMultiMachine(
  quotes: Quote[] | undefined,
  partNumber: string,
): boolean {
  return isMultiMachinePart(quoteForPn(quotes, partNumber));
}

export function quotedHoursForOp(
  q: Quote | undefined | null,
  opIndex: number,
  qty: number,
): number {
  if (!q) return 0;
  const setup = Number(q.setupTimes?.[opIndex]) || 0;
  const run = Number(q.runTimes?.[opIndex]) || 0;
  const n = Math.max(1, Number(qty) || 1);
  return Math.round(((setup + run * n) / 60) * 10) / 10;
}

export function quotedHoursForOpOnPart(
  quotes: Quote[],
  partNumber: string,
  qty: number,
  opIndex: number,
): number {
  return quotedHoursForOp(quoteForPn(quotes, partNumber), opIndex, qty);
}

export function previousTimedOpIndex(
  q: Quote | undefined | null,
  opIndex: number,
): number | null {
  const timed = timedOpIndexes(q);
  const prev = [...timed].reverse().find((i) => i < opIndex);
  return prev == null ? null : prev;
}

export function previousTimedOpComplete(
  q: Quote | undefined | null,
  slots: ShopOpAssignment[] | undefined,
  opIndex: number,
): boolean {
  const prev = previousTimedOpIndex(q, opIndex);
  if (prev == null) return true;
  return Boolean(getOpAssignment(slots, prev)?.complete);
}

export function waitOnOpLabel(
  q: Quote | undefined | null,
  slots: ShopOpAssignment[] | undefined,
  opIndex: number,
): string {
  if (previousTimedOpComplete(q, slots, opIndex)) return "";
  const prev = previousTimedOpIndex(q, opIndex);
  return prev == null ? "" : opLabel(prev);
}

export function allTimedOpsComplete(
  q: Quote | undefined | null,
  slots: ShopOpAssignment[] | undefined,
): boolean {
  const timed = timedOpIndexes(q);
  if (!timed.length) return true;
  return timed.every((i) => Boolean(getOpAssignment(slots, i)?.complete));
}

export function remainingTimedOps(
  q: Quote | undefined | null,
  slots: ShopOpAssignment[] | undefined,
): number[] {
  return timedOpIndexes(q).filter((i) => !getOpAssignment(slots, i)?.complete);
}

export function isLastOpenOp(
  q: Quote | undefined | null,
  slots: ShopOpAssignment[] | undefined,
  opIndex: number,
): boolean {
  const open = remainingTimedOps(q, slots);
  return open.length === 1 && open[0] === opIndex;
}

export function opSlotHostFields(slot: ShopOpAssignment): {
  checkedOutBy: string;
  checkedOutAt: string;
  checkedOutMachine: string;
  officeAssignedTo: string;
  officeAssignedMachine: string;
} {
  return {
    checkedOutBy: slot.checkedOutBy || "",
    checkedOutAt: slot.checkedOutAt || "",
    checkedOutMachine: slot.checkedOutMachine || "",
    officeAssignedTo: slot.officeAssignedTo || "",
    officeAssignedMachine: slot.officeAssignedMachine || "",
  };
}

/**
 * Which OPs to write on assign.
 * null = whole part (single-machine). Array = those OP indexes.
 * No requested index on a multi-machine part = every remaining timed OP.
 */
export function resolveAssignOpIndexes(
  q: Quote | undefined | null,
  slots: ShopOpAssignment[] | undefined,
  requested?: number | null,
): number[] | null {
  if (!isMultiMachinePart(q)) return null;
  if (typeof requested === "number" && Number.isFinite(requested)) {
    return [Math.max(0, Math.floor(requested))];
  }
  const open = remainingTimedOps(q, slots);
  return open.length ? open : timedOpIndexes(q);
}

export function workQueueMatchesOp(
  item: {
    shopOrderId?: string;
    shopOrderLineId?: string;
    partNumber?: string;
    opIndex?: number;
    status?: string;
  },
  opts: {
    orderId: string;
    lineId: string;
    partNumber: string;
    opIndex?: number | null;
    statuses?: string[];
  },
): boolean {
  if (item.shopOrderId !== opts.orderId) return false;
  if (item.shopOrderLineId !== opts.lineId) return false;
  const a = String(item.partNumber || "")
    .trim()
    .toUpperCase();
  const b = String(opts.partNumber || "")
    .trim()
    .toUpperCase();
  if (a !== b) return false;
  const statuses = opts.statuses || ["queued", "held", "active"];
  if (item.status && !statuses.includes(item.status)) return false;
  const itemOp =
    typeof item.opIndex === "number" && Number.isFinite(item.opIndex)
      ? item.opIndex
      : null;
  const want =
    typeof opts.opIndex === "number" && Number.isFinite(opts.opIndex)
      ? opts.opIndex
      : null;
  return itemOp === want;
}

export function machineForAssignedOp(
  q: Quote | undefined | null,
  opIndex: number,
  pickedMachine: string,
  singleOp: boolean,
): string {
  const picked = String(pickedMachine || "").trim();
  const quoted = quoteOpMachine(q, opIndex);
  if (singleOp) return picked || quoted;
  return quoted || picked;
}
