import { readFileSync } from "node:fs";
import {
  isMultiMachinePart,
  quoteOpMachine,
  remainingTimedOps,
  timedOpIndexes,
} from "../src/lib/lcm/op-slots.ts";
import { buildAssignQueue } from "../src/lib/lcm/assign-queue.ts";
import { buildJobBoard } from "../src/lib/lcm/job-board.ts";
import type { Quote, ShopOrder } from "../src/lib/lcm/types.ts";

const millOnly: Quote = {
  id: "t1",
  date: "",
  customer: "",
  partNumber: "MILL3",
  revision: "A",
  kind: "part",
  bom: [],
  benchAssembleMinutes: 0,
  machines: ["Haas VF4"],
  machineRate: 1,
  material: "",
  materialType: "",
  materialPct: 0,
  materialVendor: "",
  dimX: 0,
  dimY: 0,
  dimZ: 0,
  rawMaterialLength: 0,
  stockShape: "",
  rawMaterialCost: 0,
  calculateMaterialDrop: false,
  dropMultiplier: 1,
  partLengthEach: 0,
  setupTimes: [20, 15, 10],
  runTimes: [5, 4, 3],
  quantities: [],
  prices: [],
} as Quote;

const latheMill: Quote = {
  ...millOnly,
  id: "t2",
  partNumber: "LM3",
  machines: ["Haas ST20", "Haas VF4"],
  opMachines: ["Haas ST20", "Haas VF4", "Haas ST20"],
};

const bagOnly: Quote = {
  ...millOnly,
  id: "t3",
  partNumber: "BAG2",
  machines: ["Haas ST20", "Haas VF4"],
  setupTimes: [20, 15],
  runTimes: [5, 4],
};

function assert(cond: boolean, msg: string) {
  if (!cond) throw new Error(msg);
}

assert(!isMultiMachinePart(millOnly), "single-machine 3-op must stay one card");
assert(isMultiMachinePart(latheMill), "opMachines lathe/mill/lathe must split");
assert(isMultiMachinePart(bagOnly), "2+ machine bag + 2 timed ops must split");
assert(quoteOpMachine(latheMill, 0) === "Haas ST20", "OP1 lathe");
assert(quoteOpMachine(latheMill, 1) === "Haas VF4", "OP2 mill");
assert(quoteOpMachine(latheMill, 2) === "Haas ST20", "OP3 lathe");
assert(timedOpIndexes(latheMill).length === 3, "3 timed ops");
assert(remainingTimedOps(latheMill, [{ opIndex: 0, complete: true } as never]).length === 2, "one done");

const raw = JSON.parse(readFileSync("data/lcm-shop.json", "utf8"));
const quotes: Quote[] = raw?.state?.quotes || raw?.quotes || [];
const orders: ShopOrder[] = raw?.state?.shopOrders || raw?.shopOrders || [];
const multi = quotes.filter((q) => isMultiMachinePart(q));
console.log(
  `quotes ${quotes.length} · multi-machine ${multi.length} · orders ${orders.length}`,
);
for (const q of multi.slice(0, 12)) {
  const ops = timedOpIndexes(q)
    .map((i) => `OP${i + 1}=${quoteOpMachine(q, i) || "?"}`)
    .join(" ");
  console.log(`  ${q.partNumber}  ${ops}`);
}
const aq = buildAssignQueue(orders, quotes);
const splitRows = aq.filter((i) => i.opIndex != null);
const board = buildJobBoard(orders, quotes);
const splitCards = board.filter((c) => c.opIndex != null);
console.log(
  `assign rows ${aq.length} (${splitRows.length} OP rows) · board ${board.length} (${splitCards.length} OP cards)`,
);
console.log("ok");
