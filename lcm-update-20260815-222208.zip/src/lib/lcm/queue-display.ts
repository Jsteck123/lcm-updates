import type {
  LineFileRef,
  Quote,
  ShopOrder,
  ShopOrderLine,
  WorkQueueItem,
} from "./types";
import { normalizeComponents, normalizeLineFiles } from "./line-files";
import { getOpAssignment } from "./op-slots";

export type QueueItemDisplay = {
  dueDate: string;
  estMinutes: number | null;
  drawings: LineFileRef[];
};

function samePart(a: string, b: string) {
  return (a || "").trim().toUpperCase() === (b || "").trim().toUpperCase();
}

function sameRev(a: string, b: string) {
  const x = (a || "").trim().toUpperCase();
  const y = (b || "").trim().toUpperCase();
  if (!x || !y) return true;
  return x === y;
}

export function findQueueOrderLine(
  item: WorkQueueItem,
  orders: ShopOrder[],
): { order: ShopOrder | null; line: ShopOrderLine | null } {
  const list = orders || [];
  const order =
    list.find((o) => o.id === item.shopOrderId) ||
    list.find((o) => (o.poNumber || "") === (item.poNumber || "") && item.poNumber) ||
    null;
  if (!order) return { order: null, line: null };
  const lines = order.lines || [];
  const line =
    lines.find((l) => l.id === item.shopOrderLineId) ||
    lines.find(
      (l) =>
        samePart(l.partNumber, item.partNumber) &&
        sameRev(l.revision, item.revision),
    ) ||
    lines.find((l) => samePart(l.partNumber, item.partNumber)) ||
    null;
  return { order, line };
}

/**
 * True when this queue row still matches who holds the PO line / OP.
 * After Return or a re-assign, leftover queue rows must not book Load Lanes.
 */
export function workQueueItemStillAssigned(
  item: WorkQueueItem,
  orders: ShopOrder[],
): boolean {
  const status = item.status;
  if (status === "done" || status === "cancelled") return false;
  const { order, line } = findQueueOrderLine(item, orders);
  if (!order || !line) return Boolean((item.operatorName || "").trim());
  if (order.status === "cancelled" || order.deliveredAt) return false;
  if (line.lineStatus === "cancelled" || line.readyForPack || line.linePacked)
    return false;
  const comps = normalizeComponents(line);
  const host =
    comps.find((c) => samePart(c.partNumber, item.partNumber)) ||
    (samePart(line.partNumber, item.partNumber) ? line : null);
  if (!host) return Boolean((item.operatorName || "").trim());
  if ("complete" in host && host.complete) return false;
  const focus =
    typeof item.opIndex === "number" && Number.isFinite(item.opIndex)
      ? item.opIndex
      : null;
  const whoOnHost = (
    focus != null
      ? (() => {
          const slot = getOpAssignment(host.opAssignments, focus);
          if (slot?.complete) return "";
          return slot?.officeAssignedTo || slot?.checkedOutBy || "";
        })()
      : host.officeAssignedTo || host.checkedOutBy || ""
  ).trim();
  if (!whoOnHost) return false;
  const queued = (item.operatorName || "").trim();
  if (queued && whoOnHost.toLowerCase() !== queued.toLowerCase()) return false;
  return true;
}

export function drawingsForQueueItem(
  item: WorkQueueItem,
  line: ShopOrderLine | null,
): LineFileRef[] {
  if (!line) return [];
  const files = normalizeLineFiles(line);
  const pn = (item.partNumber || "").trim().toUpperCase();
  const fromLine = files.drawings.filter((d) => {
    const related = (d.relatedPartNumber || "").trim().toUpperCase();
    return !related || related === pn;
  });
  const fromComp = (line.components || [])
    .filter((c) => samePart(c.partNumber, item.partNumber))
    .flatMap((c) => c.drawings || []);
  const seen = new Set<string>();
  const out: LineFileRef[] = [];
  for (const d of [...fromLine, ...fromComp]) {
    if (!d?.id || seen.has(d.id)) continue;
    seen.add(d.id);
    out.push(d);
  }
  return out;
}

export function quoteForQueueItem(
  item: WorkQueueItem,
  quotes: Quote[],
): Quote | null {
  const list = quotes || [];
  const exact = list.find(
    (q) =>
      samePart(q.partNumber, item.partNumber) &&
      sameRev(q.revision, item.revision),
  );
  if (exact) return exact;
  return list.find((q) => samePart(q.partNumber, item.partNumber)) || null;
}

/** Setup + run×qty from the quote recipe. Minutes. Null when nothing is quoted. */
export function estimateQueueMinutes(
  item: WorkQueueItem,
  quote: Quote | null,
): number | null {
  if (!quote) return null;
  const opIndex =
    typeof item.opIndex === "number" && Number.isFinite(item.opIndex)
      ? item.opIndex
      : null;
  if (opIndex != null) {
    const setup = Number(quote.setupTimes?.[opIndex]) || 0;
    const runEach = Number(quote.runTimes?.[opIndex]) || 0;
    if (setup <= 0 && runEach <= 0) return null;
    const qty = Math.max(1, Number(item.qty) || 1);
    return setup + runEach * qty;
  }
  const setup = (quote.setupTimes || []).reduce((a, b) => a + (b || 0), 0);
  const runEach = (quote.runTimes || []).reduce((a, b) => a + (b || 0), 0);
  if (setup <= 0 && runEach <= 0) return null;
  const qty = Math.max(1, Number(item.qty) || 1);
  return setup + runEach * qty;
}

export function queueItemDisplay(
  item: WorkQueueItem,
  orders: ShopOrder[],
  quotes: Quote[],
): QueueItemDisplay {
  const { order, line } = findQueueOrderLine(item, orders);
  const dueDate = (line?.dueDate || order?.dueDate || order?.dateRequired || "").trim();
  return {
    dueDate,
    estMinutes: estimateQueueMinutes(item, quoteForQueueItem(item, quotes)),
    drawings: drawingsForQueueItem(item, line),
  };
}

export function formatQueueEst(mins: number | null): string {
  if (mins == null || !Number.isFinite(mins) || mins <= 0) return "";
  if (mins < 60) return `${Math.round(mins)} min`;
  const h = Math.floor(mins / 60);
  const m = Math.round(mins % 60);
  return m ? `${h}h ${m}m` : `${h}h`;
}

function ymdLocal(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function dueKey(raw: string) {
  const s = (raw || "").trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
  return s || "9999-12-31";
}

export type QueueDueFilter = "next" | "overdue" | "today" | "week";

export function filterAndSortQueueByDue(
  items: WorkQueueItem[],
  orders: ShopOrder[],
  quotes: Quote[],
  filter: QueueDueFilter = "next",
): WorkQueueItem[] {
  const today = ymdLocal();
  const weekEnd = (() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return ymdLocal(d);
  })();

  const withDue = items.map((item) => ({
    item,
    due: dueKey(queueItemDisplay(item, orders, quotes).dueDate),
  }));

  const filtered = withDue.filter(({ due }) => {
    if (filter === "overdue") return due < today;
    if (filter === "today") return due === today;
    if (filter === "week") return due <= weekEnd;
    return true;
  });

  filtered.sort((a, b) => {
    const c = a.due.localeCompare(b.due);
    if (c) return c;
    return (a.item.partNumber || "").localeCompare(b.item.partNumber || "");
  });
  return filtered.map((x) => x.item);
}
