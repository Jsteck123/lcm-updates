import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState, useEffect } from "react";
import {
  Plus,
  ClipboardList,
  Package,
  Printer,
  FileUp,
  UserCheck,
} from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { WithHelp } from "@/components/ui/help-tip";
import {
  emptyShopOrderLine,
  shopLineOpenQty,
  shopOrderSubtotal,
} from "@/lib/lcm/po";
import type { ShopOrder, ShopOrderLine } from "@/lib/lcm/types";
import { uid } from "@/lib/utils";
import { allMachines, allMaterials, allStockShapes } from "@/lib/lcm/lists";
import { openQueue } from "@/lib/lcm/work-queue";
import { PoImportDialog } from "@/components/lcm/po-import-dialog";
import { PoFollowupDialog } from "@/components/lcm/po-followup-dialog";
import { SalesOrderDialog } from "@/components/lcm/sales-order-print";
import { PageHowTo } from "@/components/lcm/page-howto";
import {
  applyMaterialPlanToLine,
  resolveLineMaterial,
  estimateMaterialUnits,
} from "@/lib/lcm/po-material";
import { computeShopOrderBuyList } from "@/lib/lcm/order-material-needs";
import { OrderListPanel } from "@/components/lcm/customer-orders/order-list-panel";
import { OrderDetailPanel } from "@/components/lcm/customer-orders/order-detail-panel";
import { MaterialNeededPanel } from "@/components/lcm/customer-orders/material-needed-panel";
import { OrderQueuePanel } from "@/components/lcm/customer-orders/order-queue-panel";
import { AssignLineDialog } from "@/components/lcm/customer-orders/assign-line-dialog";
import { MaterialLineDialog } from "@/components/lcm/customer-orders/material-line-dialog";
import { DeleteOrderDialog } from "@/components/lcm/customer-orders/delete-order-dialog";
import { Stat } from "@/components/lcm/customer-orders/meta-widgets";

export const Route = createFileRoute("/po")({
  component: ShopOrdersPage,
});

function ShopOrdersPage() {
  const shopOrders = useLcmStore((s) => s.shopOrders || []);
  const purchaseOrders = useLcmStore((s) => s.purchaseOrders || []);
  const materialStock = useLcmStore((s) => s.materialStock || []);
  const jobs = useLcmStore((s) => s.jobs);
  const quotes = useLcmStore((s) => s.quotes);
  const customers = useLcmStore((s) => s.customers);
  const settings = useLcmStore((s) => s.settings);
  const operators = useLcmStore((s) => s.operators);
  const currentUserEmail = useLcmStore((s) => s.currentUserEmail);
  const createShopOrder = useLcmStore((s) => s.createShopOrder);
  const upsertShopOrder = useLcmStore((s) => s.upsertShopOrder);
  const removeShopOrder = useLcmStore((s) => s.removeShopOrder);
  const enrichShopOrderMaterial = useLcmStore((s) => s.enrichShopOrderMaterial);
  const syncPartMaterialRecipe = useLcmStore((s) => s.syncPartMaterialRecipe);
  const setShopLineMaterialReviewed = useLcmStore(
    (s) => s.setShopLineMaterialReviewed,
  );
  const partStock = useLcmStore((s) => s.partStock || []);
  const customLists = useLcmStore((s) => s.settings.customLists);

  const updateShopOrderLineProgress = useLcmStore(
    (s) => s.updateShopOrderLineProgress,
  );
  const addCustomerQuick = useLcmStore((s) => s.addCustomerQuick);
  const assignShopOrderLine = useLcmStore((s) => s.assignShopOrderLine);
  const workQueue = useLcmStore((s) => s.workQueue || []);
  const startWorkQueueItem = useLcmStore((s) => s.startWorkQueueItem);
  const removeWorkQueueItem = useLcmStore((s) => s.removeWorkQueueItem);
  const moveWorkQueueItem = useLcmStore((s) => s.moveWorkQueueItem);
  const vendorRfqs = useLcmStore((s) => s.vendorRfqs || []);
  const createVendorRfq = useLcmStore((s) => s.createVendorRfq);
  const upsertVendorRfq = useLcmStore((s) => s.upsertVendorRfq);

  const me = operators.find(
    (o) => o.email.toLowerCase() === currentUserEmail.toLowerCase(),
  );
  /** Office/admin sees costs; shop operators never see prices */
  const canSeePrices = me?.role === "admin";

  const [assignLine, setAssignLine] = useState<{
    lineId: string;
    partNumber: string;
    openQty: number;
  } | null>(null);
  const [assignMachine, setAssignMachine] = useState("");
  const [assignOperator, setAssignOperator] = useState("");
  const [assignQty, setAssignQty] = useState("1");
  const [assignNotes, setAssignNotes] = useState("");
  const [importOpen, setImportOpen] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const [materialEditLineId, setMaterialEditLineId] = useState<string | null>(
    null,
  );
  const [expandedLines, setExpandedLines] = useState<Record<string, boolean>>(
    {},
  );
  const [salesOrderOpen, setSalesOrderOpen] = useState(false);
  const [followupId, setFollowupId] = useState<string | null>(null);
  const poFollowups = useLcmStore((s) => s.poFollowups || []);
  const openFollowups = useMemo(
    () => (poFollowups || []).filter((r) => r.status === "open"),
    [poFollowups],
  );
  const reviewFollowup = useMemo(
    () => (poFollowups || []).find((r) => r.id === followupId) || null,
    [poFollowups, followupId],
  );

  const [selectedId, setSelectedId] = useState<string | null>(
    shopOrders[0]?.id || null,
  );
  const selected =
    shopOrders.find((o) => o.id === selectedId) || shopOrders[0] || null;

  useEffect(() => {
    if (selected?.id) enrichShopOrderMaterial(selected.id);
    // Rematch saved inventory picks when opening a PO (drops 3"→1" leftovers).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected?.id]);

  const orderBuyList = useMemo(
    () => computeShopOrderBuyList(selected, materialStock),
    [selected, materialStock],
  );
  const vendorNames = useMemo(() => {
    const set = new Set<string>();
    for (const s of materialStock) {
      if (s.vendor?.trim()) set.add(s.vendor.trim());
    }
    for (const r of vendorRfqs) {
      for (const v of r.vendorsRequested || []) if (v.trim()) set.add(v.trim());
    }
    return [...set].sort((a, b) => a.localeCompare(b));
  }, [materialStock, vendorRfqs]);

  const partNumbers = useMemo(() => {
    const set = new Set<string>();
    for (const q of quotes) {
      if (q.partNumber) set.add(q.partNumber);
      for (const b of q.bom || []) if (b.partNumber) set.add(b.partNumber);
    }
    for (const o of shopOrders) {
      for (const l of o.lines || []) if (l.partNumber) set.add(l.partNumber);
    }
    return [...set].sort();
  }, [quotes, shopOrders]);

  const customerNames = useMemo(
    () => customers.map((c) => c.name).filter(Boolean),
    [customers],
  );

  const machines = useMemo(() => allMachines(customLists), [customLists]);
  const operatorNames = useMemo(
    () => operators.filter((o) => o.active).map((o) => o.name),
    [operators],
  );
  const orderQueue = useMemo(
    () =>
      selected
        ? openQueue(workQueue).filter((q) => q.shopOrderId === selected.id)
        : [],
    [workQueue, selected],
  );

  const openOrders = shopOrders.filter(
    (o) => o.status === "open" || o.status === "in_progress",
  );

  function newOrder() {
    const order = createShopOrder({
      poNumber: "",
      customer: "",
      status: "open",
      attn: "Pam Steck",
      terms: "N30",
      fob: "Origin",
      lines: [],
    });
    setSelectedId(order.id);
    toast.success("New customer PO — enter header and part lines");
  }

  function updateSelected(patch: Partial<ShopOrder>) {
    if (!selected) return;
    upsertShopOrder({ ...selected, ...patch });
  }

  function updateLine(lineId: string, patch: Partial<ShopOrderLine>) {
    if (!selected) return;
    const touchMaterial =
      "partNumber" in patch ||
      "revision" in patch ||
      "qty" in patch ||
      "material" in patch ||
      "materialType" in patch ||
      "stockShape" in patch ||
      "sizeNote" in patch ||
      "dimX" in patch ||
      "dimY" in patch ||
      "dimZ" in patch ||
      "partLengthEach" in patch ||
      "rawMaterialLength" in patch ||
      "materialStockId" in patch ||
      "materialNeeded" in patch;
    const lines = selected.lines.map((l) => {
      if (l.id !== lineId) return l;
      let next = { ...l, ...patch };
      if (touchMaterial) {
        const plan = resolveLineMaterial({
          line: next,
          quotes,
          materialStock,
          partStock,
          shopOrders,
          preserveReviewed: !("partNumber" in patch || "revision" in patch),
        });
        next = applyMaterialPlanToLine(next, plan);
        // Never let re-resolve clobber fields the user just typed
        const preserveKeys: (keyof ShopOrderLine)[] = [
          "dimX",
          "dimY",
          "dimZ",
          "partLengthEach",
          "rawMaterialLength",
          "sizeNote",
          "material",
          "materialType",
          "stockShape",
          "materialNeeded",
        ];
        for (const k of preserveKeys) {
          if (k in patch) {
            (next as Record<string, unknown>)[k] = patch[k];
          }
        }
        // Recompute need from preserved lengths if user edited those
        if (
          "partLengthEach" in patch ||
          "rawMaterialLength" in patch ||
          "qty" in patch ||
          "dimX" in patch ||
          "dimY" in patch ||
          "dimZ" in patch
        ) {
          const est = estimateMaterialUnits({
            orderQty: next.qty,
            partLengthEach: next.partLengthEach || 0,
            rawMaterialLength: next.rawMaterialLength || 0,
            stockShape: next.stockShape,
          });
          if (!("materialNeeded" in patch) || !patch.materialNeeded) {
            next.materialNeeded = est.needed;
          }
        }
        // Persist recipe to part DB when material+size are set so next import auto-fills
        if (
          touchMaterial &&
          next.partNumber &&
          (next.material || next.sizeNote || next.dimX) &&
          (next.dimX || next.sizeNote || next.stockShape)
        ) {
          syncPartMaterialRecipe(next);
        }
      }
      return next;
    });
    upsertShopOrder({ ...selected, lines });
  }

  function addLine(partNumber = "") {
    if (!selected) return;
    const nextNo =
      selected.lines.reduce((m, l) => Math.max(m, l.itemNo || 0), 0) + 1;
    let line = emptyShopOrderLine({
      id: uid(),
      itemNo: nextNo,
      partNumber,
      qty: 1,
    });
    const plan = resolveLineMaterial({
      line,
      quotes,
      materialStock,
      partStock,
    });
    line = applyMaterialPlanToLine(line, plan);
    if (plan.match !== "none" && !line.description) {
      line = {
        ...line,
        description: line.description || "",
        revision: line.revision || plan.match === "exact"
          ? line.revision
          : line.revision,
      };
      // fill desc from quote title fields if empty
      const q = quotes.find((x) => x.id === plan.quoteId);
      if (q && !line.description) {
        // keep PO description empty; material shown in plan row
      }
      if (q && !line.revision) line = { ...line, revision: q.revision || "" };
    }
    upsertShopOrder({
      ...selected,
      lines: [...selected.lines, line],
    });
  }

  function fillFromQuote(lineId: string, partNumber: string) {
    updateLine(lineId, {
      partNumber: partNumber.toUpperCase(),
      materialReviewed: false,
    });
  }

  function checkAllMaterials() {
    if (!selected) return;
    enrichShopOrderMaterial(selected.id);
    toast.success("Checked all lines against part database & stock");
  }

  function statusTone(status: string) {
    if (status === "complete") return "success" as const;
    if (status === "in_progress") return "info" as const;
    if (status === "open") return "warn" as const;
    if (status === "cancelled") return "danger" as const;
    return "neutral" as const;
  }

  const company = settings.companyName || "Lake Country Machine LLC";
  const subtotal = selected ? shopOrderSubtotal(selected) : 0;
  const attentionCount = selected
    ? selected.lines.filter(
        (l) =>
          l.materialStatus === "needs_attention" ||
          (!l.materialReviewed && l.materialStatus !== "ok"),
      ).length
    : 0;
  const materialOptions = useMemo(
    () => allMaterials(customLists),
    [customLists],
  );
  const stockShapeOptions = useMemo(
    () => allStockShapes(customLists),
    [customLists],
  );

  return (
    <div className="mx-auto w-full max-w-none space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 print:hidden">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight flex items-center gap-2">
            <ClipboardList className="h-7 w-7 text-[var(--color-primary)]" />
            Customer Orders
          </h1>
          <p className="text-sm text-[var(--color-muted)] mt-1">
            Customer POs for the shop floor. PDF is the source of truth — we
            only track customer, PO #, date required, rating, and lines.
          </p>
          {!canSeePrices && (
            <p className="text-xs text-[var(--color-warn)] mt-1">
              Shop view: costs and extensions are hidden on this account.
            </p>
          )}
        </div>
        <div className="flex flex-wrap gap-2">
          <PageHowTo id="customer-orders" />
          <Button onClick={newOrder}>
            <Plus className="h-4 w-4" /> New customer PO
          </Button>
          <WithHelp id="po-import">
            <Button variant="secondary" onClick={() => setImportOpen(true)}>
              <FileUp className="h-4 w-4" /> Import PO file
            </Button>
          </WithHelp>
          <Button variant="outline" onClick={() => window.print()}>
            <Printer className="h-4 w-4" /> Print
          </Button>
          <Link
            to="/assign"
            className="inline-flex items-center gap-2 rounded-[var(--radius-md)] border border-[var(--color-border)] px-4 py-2.5 text-sm min-h-11"
          >
            <UserCheck className="h-4 w-4" /> Assign queue
          </Link>
          <Link
            to="/inventory"
            className="inline-flex items-center gap-2 rounded-[var(--radius-md)] border border-[var(--color-border)] px-4 py-2.5 text-sm min-h-11"
          >
            <Package className="h-4 w-4" /> Material buys
          </Link>
        </div>
      </div>

      {openFollowups.length > 0 && (
        <div className="rounded-[var(--radius-md)] border border-amber-500/40 bg-amber-500/10 px-3 py-2 print:hidden">
          <div className="text-sm font-medium">
            {openFollowups.length} customer follow-up
            {openFollowups.length === 1 ? "" : "s"} waiting
          </div>
          <ul className="mt-1.5 space-y-1">
            {openFollowups.slice(0, 8).map((r) => (
              <li key={r.id} className="flex flex-wrap items-center gap-2 text-sm">
                <span className="font-mono">
                  {r.poNumber || "PO"}
                </span>
                <span className="text-[var(--color-muted)]">
                  {r.issues.length} item(s)
                  {r.customer ? ` · ${r.customer}` : ""}
                </span>
                <button
                  type="button"
                  className="text-[var(--color-primary)] underline underline-offset-2 text-xs"
                  onClick={() => setFollowupId(r.id)}
                >
                  Review & email
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 print:hidden">
        <Stat label="Open POs" value={String(openOrders.length)} />
        <Stat label="Total POs" value={String(shopOrders.length)} />
        <Stat
          label="Open line qty"
          value={String(
            shopOrders.reduce(
              (s, o) =>
                s + o.lines.reduce((a, l) => a + shopLineOpenQty(l), 0),
              0,
            ),
          )}
        />
        <Stat
          label="This PO to buy"
          value={String(
            orderBuyList.filter((n) => n.toBuy > 0 && !n.customerSupplied)
              .length,
          )}
        />
      </div>

      <div className="grid lg:grid-cols-12 gap-4">
        <OrderListPanel
          shopOrders={shopOrders}
          selectedId={selectedId}
          selected={selected}
          onSelect={setSelectedId}
          statusTone={statusTone}
        />
        <OrderDetailPanel
          selected={selected}
          canSeePrices={canSeePrices}
          company={company}
          customerNames={customerNames}
          partNumbers={partNumbers}
          materialStock={materialStock}
          quotes={quotes}
          customLists={customLists}
          settings={settings}
          attentionCount={attentionCount}
          materialOptions={materialOptions}
          materialEditLineId={materialEditLineId}
          setMaterialEditLineId={setMaterialEditLineId}
          expandedLines={expandedLines}
          setExpandedLines={setExpandedLines}
          deleteConfirm={deleteConfirm}
          setDeleteConfirm={setDeleteConfirm}
          setSalesOrderOpen={setSalesOrderOpen}
          setImportOpen={setImportOpen}
          updateSelected={updateSelected}
          updateLine={updateLine}
          addLine={addLine}
          fillFromQuote={fillFromQuote}
          checkAllMaterials={checkAllMaterials}
          enrichShopOrderMaterial={enrichShopOrderMaterial}
          syncPartMaterialRecipe={syncPartMaterialRecipe}
          setShopLineMaterialReviewed={setShopLineMaterialReviewed}
          updateShopOrderLineProgress={updateShopOrderLineProgress}
          addCustomerQuick={addCustomerQuick}
          assignShopOrderLine={assignShopOrderLine}
          setAssignLine={setAssignLine}
          setAssignMachine={setAssignMachine}
          setAssignOperator={setAssignOperator}
          setAssignQty={setAssignQty}
          setAssignNotes={setAssignNotes}
          machines={machines}
          operatorNames={operatorNames}
          removeShopOrder={removeShopOrder}
          statusTone={statusTone}
        />
      </div>

      <MaterialNeededPanel
        order={selected}
        materialStock={materialStock}
        vendorRfqs={vendorRfqs}
        vendorNames={vendorNames}
        company={settings.companyName || "Lake Country Machine"}
        canSend={canSeePrices}
        createVendorRfq={createVendorRfq}
        upsertVendorRfq={upsertVendorRfq}
      />

      {selected && (
        <OrderQueuePanel
          orderQueue={orderQueue}
          startWorkQueueItem={startWorkQueueItem}
          removeWorkQueueItem={removeWorkQueueItem}
          moveWorkQueueItem={moveWorkQueueItem}
        />
      )}

      {assignLine && selected && (
        <AssignLineDialog
          assignLine={assignLine}
          selected={selected}
          assignMachine={assignMachine}
          setAssignMachine={setAssignMachine}
          assignOperator={assignOperator}
          setAssignOperator={setAssignOperator}
          assignQty={assignQty}
          setAssignQty={setAssignQty}
          assignNotes={assignNotes}
          setAssignNotes={setAssignNotes}
          machines={machines}
          operatorNames={operatorNames}
          onClose={() => setAssignLine(null)}
          onAssign={() => {
            const r = assignShopOrderLine({
              orderId: selected.id,
              lineId: assignLine.lineId,
              machine: assignMachine,
              operatorName: assignOperator,
              qty: Number(assignQty),
              notes: assignNotes,
            });
            if (!r.ok) {
              toast.error(r.error || "Assign failed");
              return;
            }
            toast.success(
              assignOperator
                ? `${assignLine.partNumber} is ${assignOperator}'s job` +
                    (assignMachine ? ` · ${assignMachine}` : "")
                : `Queued ${assignLine.partNumber}` +
                    (assignMachine ? ` on ${assignMachine}` : ""),
            );
            setAssignLine(null);
          }}
        />
      )}

      {materialEditLineId && selected && (
        <MaterialLineDialog
          selected={selected}
          lineId={materialEditLineId}
          materialStock={materialStock}
          customLists={customLists}
          settings={settings}
          updateLine={updateLine}
          setShopLineMaterialReviewed={setShopLineMaterialReviewed}
          onClose={() => setMaterialEditLineId(null)}
        />
      )}

      {deleteConfirm && selected && (
        <DeleteOrderDialog
          selected={selected}
          onCancel={() => setDeleteConfirm(false)}
          onConfirm={() => {
            const id = selected.id;
            const label = selected.poNumber || id.slice(0, 8);
            removeShopOrder(id);
            setDeleteConfirm(false);
            setSelectedId(null);
            toast.success(`Deleted PO ${label}`);
          }}
        />
      )}

      {salesOrderOpen && selected && (
        <SalesOrderDialog
          order={selected}
          allOrders={shopOrders}
          canSeePrices={canSeePrices}
          onClose={() => setSalesOrderOpen(false)}
          onSaveSoNumber={(soNumber) => {
            updateSelected({ soNumber });
          }}
        />
      )}
      <PoImportDialog
        open={importOpen}
        onClose={() => setImportOpen(false)}
        canSeePrices={canSeePrices}
        onCreated={(id, fid) => {
          setSelectedId(id);
          if (fid) setFollowupId(fid);
        }}
      />
      {reviewFollowup && (
        <PoFollowupDialog
          report={reviewFollowup}
          onClose={() => setFollowupId(null)}
        />
      )}

      <style>{`
        @media print {
          body * { visibility: hidden; }
          .po-print, .po-print * { visibility: visible; }
          .po-print {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            border: none !important;
            box-shadow: none !important;
          }
          .print\\:hidden { display: none !important; }
        }
      `}</style>
    </div>
  );
}
