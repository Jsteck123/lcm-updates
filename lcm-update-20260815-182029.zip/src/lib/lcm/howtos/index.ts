import type { AppTab } from "../types";
import type { PageHowToDoc } from "./types";
import { signInHowTo, shopChatHowTo } from "./chrome";
import { dashboardHowTo } from "./dashboard";
import { jobBoardHowTo } from "./board";
import { activeJobsHowTo } from "./active";
import { shopFloorHowTo, machineStationHowTo } from "./machines";
import { sawHowTo } from "./saw";
import { scanHowTo } from "./scan";
import { feedbackHowTo } from "./feedback";
import { inventoryHowTo } from "./inventory";
import { labelsHowTo, sampleLabelHowTo } from "./labels";
import { customerOrdersHowTo } from "./po";
import { assignQueueHowTo } from "./assign";
import { shipCalendarHowTo } from "./calendar";
import { jobHistoryHowTo } from "./jobs";
import { quotingHowTo } from "./quoting";
import { partsQuotesHowTo } from "./database";
import { emailQuotesHowTo } from "./email";
import { reportsHowTo } from "./reports";
import { settingsHowTo } from "./settings";
import { cleanupHowTo } from "./cleanup";
import { recoverHowTo } from "./recover";

export type { HowToAudience, HowToBlock, HowToSection, PageHowToDoc } from "./types";

export type HowToGroup = {
  id: string;
  title: string;
  blurb: string;
  ids: string[];
};

/** Order is the shop-manual index (Help). */
export const PAGE_HOWTOS: PageHowToDoc[] = [
  signInHowTo,
  shopChatHowTo,
  dashboardHowTo,
  jobBoardHowTo,
  activeJobsHowTo,
  shopFloorHowTo,
  machineStationHowTo,
  sawHowTo,
  scanHowTo,
  feedbackHowTo,
  inventoryHowTo,
  labelsHowTo,
  sampleLabelHowTo,
  customerOrdersHowTo,
  assignQueueHowTo,
  shipCalendarHowTo,
  jobHistoryHowTo,
  quotingHowTo,
  partsQuotesHowTo,
  emailQuotesHowTo,
  reportsHowTo,
  settingsHowTo,
  cleanupHowTo,
  recoverHowTo,
];

export const HOWTO_GROUPS: HowToGroup[] = [
  {
    id: "every-screen",
    title: "Every screen",
    blurb:
      "The sidebar, who is signed in, PIN unlock, live shop save, and Chat. Same on every page.",
    ids: ["sign-in", "shop-chat"],
  },
  {
    id: "floor",
    title: "Floor",
    blurb:
      "Take a job, load a machine, run Setup / Runtime, send sizes to the saw, and tell office when something is wrong.",
    ids: [
      "dashboard",
      "job-board",
      "active-jobs",
      "shop-floor",
      "machine-station",
      "saw",
      "feedback",
    ],
  },
  {
    id: "stock",
    title: "Stock & labels",
    blurb:
      "Rack book, barcoded pieces, scan-cut, and the Brother 1.1 × 0.6 stickers. Pieces are not on-hand.",
    ids: ["inventory", "scan-stock", "labels", "sample-label"],
  },
  {
    id: "orders",
    title: "Orders & ship",
    blurb:
      "Customer POs, assign who runs a part, pack, Friday delivery, and the job-run ledger.",
    ids: ["customer-orders", "assign-queue", "ship-calendar", "job-history"],
  },
  {
    id: "office",
    title: "Office",
    blurb:
      "Quotes, email letters, reports, users, backups, and app updates. Money stays with admin.",
    ids: [
      "quoting",
      "parts-quotes",
      "email-quotes",
      "reports",
      "settings",
      "cleanup",
      "recover",
    ],
  },
];

const BY_ID = new Map(PAGE_HOWTOS.map((d) => [d.id, d]));

export function getPageHowTo(id: string): PageHowToDoc | undefined {
  return BY_ID.get(id);
}

export function listPageHowTos(): PageHowToDoc[] {
  return PAGE_HOWTOS;
}

export function listHowToGroups(): HowToGroup[] {
  return HOWTO_GROUPS;
}

export function howtoTabForPath(path: string): AppTab | undefined {
  const hit = PAGE_HOWTOS.find((d) => d.path === path);
  return hit?.tab;
}
