import type { MouseEvent } from "react";
import { FileText } from "lucide-react";
import { toast } from "sonner";
import type { LineFileRef } from "@/lib/lcm/types";
import { openPoAttachment } from "@/lib/lcm/open-attachment";
import { formatDate } from "@/lib/utils";
import { formatQueueEst } from "@/lib/lcm/queue-display";

export function QueueJobMeta({
  dueDate,
  estMinutes,
  drawings,
  compact,
}: {
  dueDate: string;
  estMinutes: number | null;
  drawings: LineFileRef[];
  compact?: boolean;
}) {
  const due = dueDate ? formatDate(dueDate) : "";
  const est = formatQueueEst(estMinutes);
  const drawing = drawings[0];
  if (!due && !est && !drawing) return null;

  async function openDrawing(e: MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    if (!drawing) return;
    const r = await openPoAttachment({ id: drawing.id, name: drawing.name });
    if (!r.ok) toast.error(r.error || "Could not open drawing");
  }

  return (
    <div
      className={
        compact
          ? "flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[10px] text-[var(--color-muted)]"
          : "flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-[var(--color-muted)]"
      }
    >
      {due ? <span>Due {due}</span> : null}
      {est ? <span>Est {est}</span> : null}
      {drawing ? (
        <button
          type="button"
          className="inline-flex items-center gap-1 text-[var(--color-primary)] underline underline-offset-2 min-h-8"
          onClick={(e) => void openDrawing(e)}
        >
          <FileText className="h-3 w-3" />
          Drawing{drawings.length > 1 ? ` (${drawings.length})` : ""}
        </button>
      ) : null}
    </div>
  );
}
