import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import {
  Bug,
  Lightbulb,
  Paperclip,
  Camera,
  X,
  Send,
  Image as ImageIcon,
} from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { Input, Label, Textarea, Select } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { getOperatorByEmail } from "@/lib/lcm/permissions";
import { getShopToken, requestShopUnlock } from "@/lib/lcm/shop-sync";
import { savePoAttachment } from "@/lib/lcm/po-files-api";
import { openPoAttachment } from "@/lib/lcm/open-attachment";
import { formatDateTime } from "@/lib/utils";
import type {
  FeedbackAttachment,
  FeedbackKind,
  FeedbackStatus,
  FeedbackTicket,
} from "@/lib/lcm/types";

export const Route = createFileRoute("/feedback")({
  component: FeedbackPage,
});

const STATUS_LABEL: Record<FeedbackStatus, string> = {
  new: "New",
  looking: "Looking at it",
  planned: "On the list",
  done: "Done",
  wont: "Not doing",
};

const STATUS_TONE: Record<
  FeedbackStatus,
  "open" | "soon" | "office" | "done" | "hold"
> = {
  new: "open",
  looking: "soon",
  planned: "office",
  done: "done",
  wont: "hold",
};

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const s = String(reader.result || "");
      const i = s.indexOf(",");
      resolve(i >= 0 ? s.slice(i + 1) : s);
    };
    reader.onerror = () => reject(new Error("Could not read file"));
    reader.readAsDataURL(file);
  });
}

const EMPTY_TICKETS: FeedbackTicket[] = [];

function FeedbackPage() {
  const tickets = useLcmStore((s) => s.feedbackTickets);
  const email = useLcmStore((s) => s.currentUserEmail);
  const operators = useLcmStore((s) => s.operators);
  const sessions = useLcmStore((s) => s.sessions);
  const addTicket = useLcmStore((s) => s.addFeedbackTicket);
  const addComment = useLcmStore((s) => s.addFeedbackComment);
  const setStatus = useLcmStore((s) => s.setFeedbackStatus);
  const me = getOperatorByEmail(operators, email);
  const isAdmin = me?.role === "admin";

  const machineNames = useMemo(
    () => Object.keys(sessions || {}).sort((a, b) => a.localeCompare(b)),
    [sessions],
  );

  const [compose, setCompose] = useState<FeedbackKind | null>(null);

  const [compose, setCompose] = useState<FeedbackKind | null>(null);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [page, setPage] = useState("");
  const [machine, setMachine] = useState("");
  const [files, setFiles] = useState<FeedbackAttachment[]>([]);
  const [uploading, setUploading] = useState(false);
  const [filter, setFilter] = useState<"open" | "mine" | "all" | "done">(
    "open",
  );
  const [kindFilter, setKindFilter] = useState<"all" | FeedbackKind>("all");
  const [openId, setOpenId] = useState<string | null>(null);
  const [reply, setReply] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const ticketList = tickets ?? EMPTY_TICKETS;

  const shown = useMemo(() => {
    return [...ticketList]
      .filter((t) => {
        if (kindFilter !== "all" && t.kind !== kindFilter) return false;
        if (filter === "mine")
          return t.createdByEmail.toLowerCase() === email.toLowerCase();
        if (filter === "open")
          return t.status === "new" || t.status === "looking" || t.status === "planned";
        if (filter === "done")
          return t.status === "done" || t.status === "wont";
        return true;
      })
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }, [ticketList, filter, kindFilter, email]);

  const openTicket = ticketList.find((t) => t.id === openId) || null;

  function resetForm() {
    setTitle("");
    setBody("");
    setPage("");
    setMachine("");
    setFiles([]);
    setCompose(null);
  }

  async function attachFiles(list: FileList | null) {
    if (!list?.length) return;
    if (!getShopToken()) {
      requestShopUnlock("Unlock with your PIN so photos reach the office");
      toast.message("Enter your PIN first — then attach again");
      return;
    }
    setUploading(true);
    try {
      const next = [...files];
      for (const file of Array.from(list)) {
        if (next.length >= 5) {
          toast.error("Max 5 photos / files");
          break;
        }
        if (file.size > 12_000_000) {
          toast.error(`${file.name} is too large (max 12 MB)`);
          continue;
        }
        const b64 = await fileToBase64(file);
        const saved = await savePoAttachment({
          data: {
            name: file.name,
            mime: file.type || "application/octet-stream",
            base64: b64,
            token: getShopToken() || undefined,
          },
        });
        if (!saved.ok) {
          toast.error(saved.error || `Could not attach ${file.name}`);
          continue;
        }
        next.push({
          id: saved.meta.id,
          name: saved.meta.name || file.name,
          mime: saved.meta.mime || file.type || "application/octet-stream",
          size: saved.meta.size || file.size,
        });
      }
      setFiles(next);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Attach failed");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  function submit() {
    const r = addTicket({
      kind: compose || "bug",
      title,
      body,
      page,
      machine,
      attachments: files,
    });
    if (!r.ok) {
      toast.error(r.error);
      return;
    }
    toast.success(
      compose === "feature" ? "Idea sent to the office" : "Bug report sent",
    );
    resetForm();
    if (r.id) setOpenId(r.id);
  }

  return (
    <div className="p-3 sm:p-5 space-y-4 max-w-3xl mx-auto">
      <div>
        <h1 className="text-xl font-semibold">Feedback</h1>
        <p className="text-sm text-[var(--color-muted)] mt-0.5">
          Something broken? An idea that would help on the floor? Send it here
          with a photo if you have one. The office will see it on this same list.
        </p>
      </div>

      {!compose && (
        <div className="grid sm:grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => setCompose("bug")}
            className="rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-surface)] p-4 text-left min-h-[5.5rem] hover:bg-[var(--color-surface-2)]"
          >
            <div className="flex items-center gap-2 font-semibold">
              <Bug className="h-4 w-4" />
              Something’s broken
            </div>
            <p className="text-xs text-[var(--color-muted)] mt-1">
              Timer flipped back, button missing, page froze — tell us what you
              saw.
            </p>
          </button>
          <button
            type="button"
            onClick={() => setCompose("feature")}
            className="rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-surface)] p-4 text-left min-h-[5.5rem] hover:bg-[var(--color-surface-2)]"
          >
            <div className="flex items-center gap-2 font-semibold">
              <Lightbulb className="h-4 w-4" />
              I have an idea
            </div>
            <p className="text-xs text-[var(--color-muted)] mt-1">
              A change that would make the shop faster or clearer.
            </p>
          </button>
        </div>
      )}

      {compose && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">
              {compose === "bug" ? "Report a bug" : "Request a feature"}
            </CardTitle>
            <CardDescription>
              Short title, then what happened. Photo or screenshot helps a lot.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-1">
              <Label>Short title</Label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={
                  compose === "bug"
                    ? "e.g. Pause didn’t stop the clock on VF-2"
                    : "e.g. Need a way to reprint a label"
                }
              />
            </div>
            <div className="space-y-1">
              <Label>What happened / what you want</Label>
              <Textarea
                rows={5}
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="What you were doing, what you expected, what you got."
              />
            </div>
            <div className="grid sm:grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label>Page (optional)</Label>
                <Input
                  value={page}
                  onChange={(e) => setPage(e.target.value)}
                  placeholder="Shop Floor, Job Board…"
                />
              </div>
              <div className="space-y-1">
                <Label>Machine (optional)</Label>
                <Select
                  value={machine}
                  onChange={(e) => setMachine(e.target.value)}
                >
                  <option value="">—</option>
                  {machineNames.map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Photo / screenshot</Label>
              <input
                ref={fileRef}
                type="file"
                accept="image/*,application/pdf"
                multiple
                className="hidden"
                onChange={(e) => void attachFiles(e.target.files)}
              />
              <div className="flex flex-wrap gap-2">
                <Button
                  type="button"
                  variant="secondary"
                  disabled={uploading}
                  onClick={() => fileRef.current?.click()}
                >
                  <Camera className="h-4 w-4" />
                  {uploading ? "Uploading…" : "Add photo"}
                </Button>
              </div>
              {files.length > 0 && (
                <ul className="space-y-1">
                  {files.map((f) => (
                    <li
                      key={f.id}
                      className="flex items-center gap-2 text-sm rounded-[var(--radius-md)] border border-[var(--color-border)] px-2 py-1.5"
                    >
                      <Paperclip className="h-3.5 w-3.5 shrink-0" />
                      <span className="truncate flex-1">{f.name}</span>
                      <button
                        type="button"
                        className="p-1"
                        onClick={() =>
                          setFiles((cur) => cur.filter((x) => x.id !== f.id))
                        }
                        aria-label="Remove file"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="ghost" onClick={resetForm}>
                Cancel
              </Button>
              <Button onClick={submit} disabled={uploading}>
                <Send className="h-4 w-4" />
                Send to office
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex flex-wrap gap-2">
        {(
          [
            ["open", "Open"],
            ["mine", "Mine"],
            ["all", "All"],
            ["done", "Closed"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setFilter(id)}
            className={`rounded-full px-3 py-1.5 text-sm border min-h-9 ${
              filter === id
                ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)] text-[var(--color-primary)]"
                : "border-[var(--color-border)] text-[var(--color-muted)]"
            }`}
          >
            {label}
          </button>
        ))}
        <button
          type="button"
          onClick={() =>
            setKindFilter((k) =>
              k === "all" ? "bug" : k === "bug" ? "feature" : "all",
            )
          }
          className="rounded-full px-3 py-1.5 text-sm border min-h-9 border-[var(--color-border)] text-[var(--color-muted)]"
        >
          {kindFilter === "all"
            ? "Bugs & ideas"
            : kindFilter === "bug"
              ? "Bugs only"
              : "Ideas only"}
        </button>
      </div>

      {shown.length === 0 ? (
        <Card>
          <CardContent className="py-10 text-center text-sm text-[var(--color-muted)]">
            Nothing here yet. Use the buttons above when you hit a snag or have
            an idea.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {shown.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => {
                setOpenId(t.id === openId ? null : t.id);
                setReply("");
              }}
              className="w-full text-left rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-surface)] px-3 py-3 hover:bg-[var(--color-surface-2)]"
            >
              <div className="flex flex-wrap items-center gap-2">
                <Badge tone={t.kind === "bug" ? "overdue" : "office"}>
                  {t.kind === "bug" ? "Bug" : "Idea"}
                </Badge>
                <Badge tone={STATUS_TONE[t.status]}>{STATUS_LABEL[t.status]}</Badge>
                <span className="font-medium text-sm flex-1 min-w-0 truncate">
                  {t.title}
                </span>
              </div>
              <div className="text-[11px] text-[var(--color-muted)] mt-1">
                {t.createdByName}
                {t.machine ? ` · ${t.machine}` : ""}
                {t.page ? ` · ${t.page}` : ""}
                {" · "}
                {formatDateTime(t.updatedAt)}
                {t.attachments?.length
                  ? ` · ${t.attachments.length} file${t.attachments.length === 1 ? "" : "s"}`
                  : ""}
              </div>
            </button>
          ))}
        </div>
      )}

      {openTicket && (
        <TicketDetail
          ticket={openTicket}
          isAdmin={Boolean(isAdmin)}
          reply={reply}
          setReply={setReply}
          onClose={() => setOpenId(null)}
          onStatus={(st) => {
            const r = setStatus(openTicket.id, st);
            if (!r.ok) toast.error(r.error);
            else toast.success(`Marked ${STATUS_LABEL[st]}`);
          }}
          onReply={() => {
            const r = addComment(openTicket.id, reply);
            if (!r.ok) toast.error(r.error);
            else {
              setReply("");
              toast.success("Reply posted");
            }
          }}
        />
      )}
    </div>
  );
}

function TicketDetail({
  ticket,
  isAdmin,
  reply,
  setReply,
  onClose,
  onStatus,
  onReply,
}: {
  ticket: FeedbackTicket;
  isAdmin: boolean;
  reply: string;
  setReply: (v: string) => void;
  onClose: () => void;
  onStatus: (s: FeedbackStatus) => void;
  onReply: () => void;
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-3 print:hidden"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-4 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start gap-2 mb-3">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap gap-1.5 mb-1">
              <Badge tone={ticket.kind === "bug" ? "overdue" : "office"}>
                {ticket.kind === "bug" ? "Bug" : "Idea"}
              </Badge>
              <Badge tone={STATUS_TONE[ticket.status]}>
                {STATUS_LABEL[ticket.status]}
              </Badge>
            </div>
            <h2 className="text-lg font-semibold leading-snug">{ticket.title}</h2>
            <p className="text-xs text-[var(--color-muted)] mt-1">
              {ticket.createdByName} · {formatDateTime(ticket.createdAt)}
              {ticket.machine ? ` · ${ticket.machine}` : ""}
              {ticket.page ? ` · ${ticket.page}` : ""}
            </p>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <p className="text-sm whitespace-pre-wrap mb-3">{ticket.body}</p>

        {ticket.attachments?.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-3">
            {ticket.attachments.map((a) => (
              <Button
                key={a.id}
                size="sm"
                variant="outline"
                type="button"
                onClick={async () => {
                  const r = await openPoAttachment({
                    id: a.id,
                    name: a.name,
                  });
                  if (!r.ok) toast.error(r.error || "Could not open file");
                }}
              >
                <ImageIcon className="h-3.5 w-3.5" />
                {a.name}
              </Button>
            ))}
          </div>
        )}

        {isAdmin && (
          <div className="flex flex-wrap gap-1.5 mb-4">
            {(
              [
                "new",
                "looking",
                "planned",
                "done",
                "wont",
              ] as FeedbackStatus[]
            ).map((st) => (
              <Button
                key={st}
                size="sm"
                variant={ticket.status === st ? "default" : "outline"}
                type="button"
                onClick={() => onStatus(st)}
              >
                {STATUS_LABEL[st]}
              </Button>
            ))}
          </div>
        )}

        <div className="space-y-2 mb-3">
          {(ticket.comments || []).map((c) => (
            <div
              key={c.id}
              className="rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2 text-sm"
            >
              <div className="text-[11px] text-[var(--color-muted)]">
                {c.byName} · {formatDateTime(c.at)}
              </div>
              <div className="whitespace-pre-wrap mt-0.5">{c.body}</div>
            </div>
          ))}
        </div>

        <div className="space-y-2">
          <Label>Reply</Label>
          <Textarea
            rows={3}
            value={reply}
            onChange={(e) => setReply(e.target.value)}
            placeholder={
              isAdmin
                ? "Ask a question or say what you’ll do…"
                : "Add more detail if they ask…"
            }
          />
          <div className="flex justify-end">
            <Button type="button" onClick={onReply}>
              <Send className="h-4 w-4" />
              Reply
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
