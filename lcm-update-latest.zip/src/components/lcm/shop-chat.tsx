import { useEffect, useMemo, useRef, useState } from "react";
import {
  MessageCircle,
  X,
  Send,
  Users,
  User,
  Lock,
  Paperclip,
  FileText,
  Image as ImageIcon,
} from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  chatVisibleTo,
  isChatUnread,
  sameDmThread,
} from "@/lib/lcm/chat";
import {
  getShopToken,
  requestShopUnlock,
  waitForShopUnlock,
  useShopSyncStatus,
} from "@/lib/lcm/shop-sync";
import { postChatMessage } from "@/lib/lcm/shop-api";
import { savePoAttachment } from "@/lib/lcm/po-files-api";
import { fileToBase64 } from "@/lib/lcm/po-import";
import { openPoAttachment } from "@/lib/lcm/open-attachment";
import type { ChatAttachment } from "@/lib/lcm/types";
import { cn } from "@/lib/utils";

type Thread = { kind: "shop" } | { kind: "dm"; email: string; name: string };

/**
 * Floating shop chat — every signed-in user on the LAN.
 * Shop channel + DMs (e.g. floor → office for a tool).
 * Requires a shop session (PIN unlock) so messages push to the host.
 */
export function ShopChat() {
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  const chatMessages = useLcmStore((s) => s.chatMessages || []);
  const sendChatMessage = useLcmStore((s) => s.sendChatMessage);
  const markChatRead = useLcmStore((s) => s.markChatRead);
  const shopSync = useShopSyncStatus();

  const [open, setOpen] = useState(false);
  const [thread, setThread] = useState<Thread>({ kind: "shop" });
  const [text, setText] = useState("");
  const [context, setContext] = useState("");
  const [sending, setSending] = useState(false);
  const [pendingFiles, setPendingFiles] = useState<ChatAttachment[]>([]);
  const [uploading, setUploading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const me = useMemo(
    () =>
      operators.find((o) => o.email.toLowerCase() === email.toLowerCase()),
    [operators, email],
  );

  const others = useMemo(
    () =>
      operators
        .filter((o) => o.active && o.email.toLowerCase() !== email.toLowerCase())
        .sort((a, b) => a.name.localeCompare(b.name)),
    [operators, email],
  );

  const visible = useMemo(
    () => chatMessages.filter((m) => chatVisibleTo(m, email)),
    [chatMessages, email],
  );

  const threadMessages = useMemo(() => {
    if (thread.kind === "shop") {
      return visible.filter((m) => m.channel === "shop" || !m.toEmail);
    }
    return visible.filter((m) => sameDmThread(m, email, thread.email));
  }, [visible, thread, email]);

  const unreadTotal = useMemo(
    () => visible.filter((m) => isChatUnread(m, email)).length,
    [visible, email],
  );

  const unreadShop = useMemo(
    () =>
      visible.filter(
        (m) =>
          (m.channel === "shop" || !m.toEmail) && isChatUnread(m, email),
      ).length,
    [visible, email],
  );

  function unreadDm(to: string) {
    return visible.filter(
      (m) => sameDmThread(m, email, to) && isChatUnread(m, email),
    ).length;
  }

  // Mark thread read when open
  useEffect(() => {
    if (!open) return;
    const ids = threadMessages
      .filter((m) => isChatUnread(m, email))
      .map((m) => m.id);
    if (ids.length) markChatRead(ids);
  }, [open, thread, threadMessages, email, markChatRead]);

  useEffect(() => {
    if (open) {
      bottomRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [open, threadMessages.length, thread]);

  async function attachFiles(list: FileList | null) {
    if (!list?.length) return;
    const token = getShopToken();
    if (!token && !shopSync.hasSession) {
      const unlocked = await waitForShopUnlock(
        "Unlock with your PIN before attaching files",
      );
      if (!unlocked && !getShopToken()) {
        toast.message("Unlock cancelled — attach again when ready");
        if (fileInputRef.current) fileInputRef.current.value = "";
        return;
      }
    }
    if (pendingFiles.length >= 5) {
      toast.error("Max 5 files per message");
      return;
    }
    setUploading(true);
    try {
      const next = [...pendingFiles];
      for (const file of Array.from(list)) {
        if (next.length >= 5) break;
        if (file.size > 12_000_000) {
          toast.error(`${file.name} is too large (max 12 MB)`);
          continue;
        }
        const b64 = await fileToBase64(file);
        const saved = await savePoAttachment({
          data: {
            name: file.name,
            mime: file.type || "application/octet-stream",
            base64: b64,
            token: getShopToken() || undefined,
          },
        });
        if (!saved.ok) {
          toast.error(saved.error || `Could not attach ${file.name}`);
          continue;
        }
        next.push({
          id: saved.meta.id,
          name: saved.meta.name || file.name,
          mime: saved.meta.mime || file.type || "application/octet-stream",
          size: saved.meta.size || file.size,
        });
      }
      setPendingFiles(next);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Attach failed");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function send() {
    if (sending || uploading) return;
    const token = getShopToken();
    if (!token && !shopSync.hasSession) {
      const unlocked = await waitForShopUnlock(
        "Unlock with your PIN so chat from this phone/PC reaches the whole shop",
      );
      if (!unlocked && !getShopToken()) {
        toast.message("Unlock cancelled — press send again when ready");
        return;
      }
    }

    const attachments = [...pendingFiles];
    const res = sendChatMessage({
      body: text,
      toEmail: thread.kind === "dm" ? thread.email : undefined,
      context: context.trim() || undefined,
      attachments,
    });
    if (!res.ok) {
      toast.error(res.error || "Could not send");
      return;
    }
    const sentBody = text;
    const sentFiles = attachments;
    setText("");
    setPendingFiles([]);
    setSending(true);
    try {
      const msgs = useLcmStore.getState().chatMessages || [];
      const just = msgs.find((m) => m.id === res.id) || msgs[msgs.length - 1];
      if (!just) {
        toast.error("Could not build message");
        return;
      }
      const remote = await postChatMessage({
        data: {
          token: getShopToken() || undefined,
          message: {
            id: just.id,
            channel: just.channel,
            fromEmail: just.fromEmail,
            fromName: just.fromName,
            toEmail: just.toEmail || "",
            body: just.body,
            createdAt: just.createdAt,
            context: just.context || "",
            readBy: just.readBy || [],
            attachments: just.attachments || [],
          },
        },
      });
      if (!remote.ok) {
        if ("needsPin" in remote && remote.needsPin) {
          requestShopUnlock(
            "Unlock with your PIN so this message reaches the shop",
          );
          toast.error("PIN required on this PC — unlock, then send again");
        } else {
          toast.error(remote.error || "Could not reach the shop host");
          setText(sentBody);
          setPendingFiles(sentFiles);
        }
      }
    } catch (e) {
      toast.error(
        e instanceof Error ? e.message : "Could not reach the shop host",
      );
      setText(sentBody);
      setPendingFiles(sentFiles);
    } finally {
      setSending(false);
    }
  }

  async function openAttachment(a: ChatAttachment) {
    const r = await openPoAttachment({ id: a.id, name: a.name });
    if (!r.ok) toast.error(r.error || "Could not open file");
  }

  function formatSize(n: number) {
    if (!n) return "";
    if (n < 1024) return `${n} B`;
    if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`;
    return `${(n / (1024 * 1024)).toFixed(1)} MB`;
  }

  function formatTime(iso: string) {
    try {
      const d = new Date(iso);
      return d.toLocaleString(undefined, {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      });
    } catch {
      return iso;
    }
  }

  const canSend = shopSync.hasSession || Boolean(getShopToken());

  return (
    <div className="fixed bottom-4 right-4 z-40 print:hidden flex flex-col items-end gap-2">
      {open && (
        <div className="w-[min(100vw-1.5rem,22rem)] sm:w-[24rem] h-[min(70vh,32rem)] rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] shadow-2xl flex flex-col overflow-hidden">
          <div className="flex items-center justify-between gap-2 px-3 py-2.5 border-b border-[var(--color-border)] bg-[var(--color-surface-2)]">
            <div className="min-w-0">
              <div className="font-semibold text-sm truncate">Shop Chat</div>
              <div className="text-[10px] text-[var(--color-muted)] truncate">
                {me?.name || email} ·{" "}
                {canSend ? "live on the network" : "unlock PIN to send"}
              </div>
            </div>
            <button
              type="button"
              className="p-2 rounded-[var(--radius-md)] hover:bg-[var(--color-bg)]"
              onClick={() => setOpen(false)}
              aria-label="Close chat"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {!canSend && (
            <button
              type="button"
              onClick={() =>
                requestShopUnlock(
                  "Unlock with your PIN so chat reaches other phones and PCs",
                )
              }
              className="flex items-center gap-2 px-3 py-2 text-xs text-amber-100 bg-amber-500/15 border-b border-amber-500/40 text-left"
            >
              <Lock className="h-3.5 w-3.5 shrink-0" />
              <span>
                This PC is not unlocked for chat. Tap here, enter your PIN
                (same as Switch user), then send again. You can still read
                messages without unlocking.
              </span>
            </button>
          )}

          <div className="flex flex-1 min-h-0">
            {/* People list */}
            <div className="w-[38%] border-r border-[var(--color-border)] overflow-y-auto shrink-0">
              <button
                type="button"
                onClick={() => setThread({ kind: "shop" })}
                className={cn(
                  "w-full text-left px-2 py-2.5 text-xs border-b border-[var(--color-border)] flex items-start gap-1.5",
                  thread.kind === "shop"
                    ? "bg-[color-mix(in_oklab,var(--color-primary)_12%,transparent)]"
                    : "hover:bg-[var(--color-surface-2)]",
                )}
              >
                <Users className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                <span className="min-w-0">
                  <span className="font-semibold block">Everyone</span>
                  <span className="text-[var(--color-muted)]">Shop channel</span>
                </span>
                {unreadShop > 0 && (
                  <span className="ml-auto text-[10px] font-bold text-amber-300">
                    {unreadShop}
                  </span>
                )}
              </button>
              {others.map((o) => {
                const n = unreadDm(o.email);
                return (
                  <button
                    key={o.id}
                    type="button"
                    onClick={() =>
                      setThread({
                        kind: "dm",
                        email: o.email,
                        name: o.name,
                      })
                    }
                    className={cn(
                      "w-full text-left px-2 py-2.5 text-xs border-b border-[var(--color-border)] flex items-start gap-1.5",
                      thread.kind === "dm" &&
                        thread.email.toLowerCase() === o.email.toLowerCase()
                        ? "bg-[color-mix(in_oklab,var(--color-primary)_12%,transparent)]"
                        : "hover:bg-[var(--color-surface-2)]",
                    )}
                  >
                    <User className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                    <span className="min-w-0 truncate">
                      <span className="font-semibold block truncate">
                        {o.name}
                      </span>
                      <span className="text-[var(--color-muted)]">
                        {o.role === "admin" ? "Office / admin" : "Shop"}
                      </span>
                    </span>
                    {n > 0 && (
                      <span className="ml-auto text-[10px] font-bold text-amber-300">
                        {n}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Messages */}
            <div className="flex-1 flex flex-col min-w-0">
              <div className="px-2.5 py-1.5 border-b border-[var(--color-border)] text-xs font-medium truncate">
                {thread.kind === "shop"
                  ? "Everyone (shop floor + office)"
                  : `Chat with ${thread.name}`}
              </div>
              <div className="flex-1 overflow-y-auto p-2 space-y-2">
                {threadMessages.length === 0 && (
                  <p className="text-xs text-[var(--color-muted)] p-2 leading-relaxed">
                    {thread.kind === "shop"
                      ? "Ask for tools, share job notes, or ping the whole crew here."
                      : `Private messages with ${thread.name}. Only you two see this.`}
                  </p>
                )}
                {threadMessages.map((m) => {
                  const mine =
                    m.fromEmail.toLowerCase() === email.toLowerCase();
                  return (
                    <div
                      key={m.id}
                      className={cn(
                        "rounded-lg px-2.5 py-1.5 text-xs max-w-[95%]",
                        mine
                          ? "ml-auto bg-[color-mix(in_oklab,var(--color-primary)_22%,transparent)]"
                          : "mr-auto bg-[var(--color-surface-2)] border border-[var(--color-border)]",
                      )}
                    >
                      <div className="flex items-baseline justify-between gap-2 mb-0.5">
                        <span className="font-semibold truncate">
                          {mine ? "You" : m.fromName}
                        </span>
                        <span className="text-[9px] text-[var(--color-muted)] shrink-0">
                          {formatTime(m.createdAt)}
                        </span>
                      </div>
                      {m.context ? (
                        <div className="text-[10px] text-[var(--color-muted)] mb-0.5">
                          Re: {m.context}
                        </div>
                      ) : null}
                      {m.body && m.body !== "(attachment)" ? (
                        <div className="whitespace-pre-wrap break-words leading-snug">
                          {m.body}
                        </div>
                      ) : null}
                      {(m.attachments || []).length > 0 && (
                        <div className="mt-1.5 space-y-1">
                          {(m.attachments || []).map((a) => {
                            const isImg = /^image\//i.test(a.mime || "");
                            return (
                              <button
                                key={a.id}
                                type="button"
                                onClick={() => void openAttachment(a)}
                                className="flex items-center gap-1.5 w-full text-left rounded-md border border-[var(--color-border)] bg-[var(--color-bg)]/40 px-2 py-1.5 hover:bg-[var(--color-surface-2)]"
                                title="Open attachment"
                              >
                                {isImg ? (
                                  <ImageIcon className="h-3.5 w-3.5 shrink-0 text-[var(--color-primary)]" />
                                ) : (
                                  <FileText className="h-3.5 w-3.5 shrink-0 text-[var(--color-primary)]" />
                                )}
                                <span className="min-w-0 flex-1">
                                  <span className="block truncate font-medium text-[11px]">
                                    {a.name}
                                  </span>
                                  <span className="text-[9px] text-[var(--color-muted)]">
                                    {formatSize(a.size)} · tap to preview
                                  </span>
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
                <div ref={bottomRef} />
              </div>
              <div className="border-t border-[var(--color-border)] p-2 space-y-1.5">
                <Input
                  className="h-8 text-xs"
                  placeholder="Job / machine / tool (optional)"
                  value={context}
                  onChange={(e) => setContext(e.target.value)}
                />
                {pendingFiles.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {pendingFiles.map((f) => (
                      <span
                        key={f.id}
                        className="inline-flex items-center gap-1 max-w-full rounded-full border border-[var(--color-border)] bg-[var(--color-surface-2)] px-2 py-0.5 text-[10px]"
                      >
                        <Paperclip className="h-3 w-3 shrink-0" />
                        <span className="truncate max-w-[9rem]">{f.name}</span>
                        <button
                          type="button"
                          className="opacity-70 hover:opacity-100"
                          aria-label="Remove attachment"
                          onClick={() =>
                            setPendingFiles((prev) =>
                              prev.filter((x) => x.id !== f.id),
                            )
                          }
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                )}
                <div className="flex gap-1.5 items-center">
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    className="hidden"
                    accept=".pdf,.png,.jpg,.jpeg,.webp,.gif,.txt,.csv,.dxf,.dwg,image/*,application/pdf"
                    onChange={(e) => void attachFiles(e.target.files)}
                  />
                  <Button
                    type="button"
                    size="icon"
                    variant="outline"
                    className="h-9 w-9 shrink-0"
                    disabled={!canSend || uploading || sending}
                    onClick={() => fileInputRef.current?.click()}
                    aria-label="Attach file"
                    title="Attach PDF, photo, or drawing"
                  >
                    {uploading ? (
                      <span className="text-[10px]">…</span>
                    ) : (
                      <Paperclip className="h-4 w-4" />
                    )}
                  </Button>
                  <Input
                    className="h-9 text-sm flex-1"
                    placeholder={
                      !canSend
                        ? "Unlock PIN to send…"
                        : thread.kind === "shop"
                          ? "Message or attach…"
                          : `Message ${thread.name}…`
                    }
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        void send();
                      }
                    }}
                  />
                  <Button
                    type="button"
                    size="icon"
                    className="h-9 w-9 shrink-0"
                    onClick={() => void send()}
                    disabled={
                      sending ||
                      uploading ||
                      (!text.trim() && pendingFiles.length === 0)
                    }
                    aria-label="Send"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-[9px] text-[var(--color-muted)] px-0.5">
                  Paperclip: PDF / photo / drawing · max 5 files · 12 MB each
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="relative inline-flex items-center gap-2 rounded-full border border-[var(--color-border)] bg-[var(--color-primary)] text-[var(--color-primary-fg)] px-4 py-3 shadow-lg font-semibold text-sm min-h-12 hover:opacity-95"
        aria-label="Open shop chat"
      >
        <MessageCircle className="h-5 w-5" />
        <span className="hidden sm:inline">Chat</span>
        {unreadTotal > 0 && !open && (
          <span className="absolute -top-1 -right-1 min-w-5 h-5 px-1 rounded-full bg-amber-400 text-black text-[11px] font-bold flex items-center justify-center">
            {unreadTotal > 99 ? "99+" : unreadTotal}
          </span>
        )}
      </button>
    </div>
  );
}
