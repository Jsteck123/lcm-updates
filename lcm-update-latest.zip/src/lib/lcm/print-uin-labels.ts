import { toast } from "sonner";
import { barcodeToDataUrl, uinUrlForCode } from "./barcode";
import { renderLabelMono } from "./brother-label-print";
import { printLabelOnShopHost } from "./print-label-api";
import { loadQlPrinterIp } from "./ql-printer";
import {
  ensureShopUnlocked,
  getShopToken,
  setShopToken,
  shopUnlockFromHostError,
} from "./shop-sync";
import type { PartUnit } from "./types";

function ranWhen(iso: string): string {
  const s = String(iso || "").trim();
  if (!s) return "";
  const m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) return `${m[2]}/${m[3]}/${m[1]}`;
  return s.slice(0, 10);
}

export async function printUinPartLabel(
  unit: PartUnit,
  shopPublicUrl?: string,
): Promise<{ ok: true; ip: string } | { ok: false; error: string }> {
  if (
    !(await ensureShopUnlocked(
      "Unlock to print the extra-part label from the packing table",
    ))
  ) {
    return { ok: false, error: "Unlock this PC first, then print again." };
  }
  const ip = loadQlPrinterIp();
  if (!ip) {
    return {
      ok: false,
      error: "Set the QL-810W Wi-Fi address on the sample label page first.",
    };
  }
  const qrDataUrl = await barcodeToDataUrl(
    uinUrlForCode(unit.uin, shopPublicUrl),
    220,
  );
  const who = unit.operatorName || unit.stockedBy || "";
  const line3 = [who, ranWhen(unit.stockedAt)].filter(Boolean).join(" · ");
  const mono = await renderLabelMono({
    tapeId: "dk2210",
    barcode: unit.uin,
    qrDataUrl,
    line1: `${unit.partNumber} Rev ${unit.revision || "—"}`,
    line2:
      unit.quality === "second"
        ? `UIN ${unit.uin} · minor`
        : `UIN ${unit.uin} · good`,
    line3: line3 || undefined,
  });
  const send = () =>
    printLabelOnShopHost({
      data: {
        token: getShopToken() || undefined,
        ip,
        width: mono.width,
        height: mono.height,
        pixelsB64: mono.pixelsB64,
      },
    });
  let r = await send();
  if (!r.ok && shopUnlockFromHostError(r.error)) {
    setShopToken(null);
    if (
      !(await ensureShopUnlocked(
        "Unlock to print the extra-part label from the packing table",
      ))
    ) {
      return { ok: false, error: r.error || "Unlock this PC first" };
    }
    r = await send();
  }
  if (!r.ok) return { ok: false, error: r.error || "Print failed" };
  return { ok: true, ip: r.ip || ip };
}

export async function printUinPartLabelOrToast(
  unit: PartUnit,
  shopPublicUrl?: string,
) {
  const r = await printUinPartLabel(unit, shopPublicUrl);
  if (!r.ok) {
    toast.error(r.error);
    return r;
  }
  toast.success(`UIN ${unit.uin} label sent to ${r.ip}`);
  return r;
}
