/**
 * Client sync: one host PC runs the app; every browser on the LAN
 * pulls/pushes the shared shop database so everyone sees the same data live.
 * Pushes require a shop session token (from PIN claim).
 */
import { useEffect, useState } from "react";
import { useLcmStore } from "@/store/lcm-store";
import { pullShopState, pushShopState } from "./shop-api";
import type { ShopSharedState } from "./shop-types";
import { cloneShared, threeWayMergeShop } from "./shop-merge";

const TOKEN_KEY = "lcm-shop-token";

export type ShopSyncStatus = {
  connected: boolean;
  rev: number;
  lastSyncAt: string | null;
  error: string | null;
  mode: "shared" | "local-fallback";
  hasSession: boolean;
};

export type FlushResult =
  | { ok: true; rev: number }
  | { ok: false; error: string; needsPin?: boolean };

let sharedRev = 0;
let applyingRemote = false;
let dirty = false;
let pushing = false;
let lastAcked: ShopSharedState | null = null;
let pushTimer: ReturnType<typeof setTimeout> | null = null;
let pollTimer: ReturnType<typeof setTimeout> | null = null;
let bootstrapped = false;
/** After host offline / restart, pull full DB before any push. */
let needPullBeforePush = true;
let unsubStore: (() => void) | null = null;
let statusListeners = new Set<(s: ShopSyncStatus) => void>();
let status: ShopSyncStatus = {
  connected: false,
  rev: 0,
  lastSyncAt: null,
  error: null,
  mode: "local-fallback",
  hasSession: false,
};

/** App shell registers this so chat / saves can re-open the PIN unlock dialog. */
let unlockRequestHandler: ((reason?: string) => void) | null = null;
let queuedUnlockReason: string | undefined;
const unlockWaiters: Array<(ok: boolean) => void> = [];

function setStatus(patch: Partial<ShopSyncStatus>) {
  status = { ...status, ...patch };
  statusListeners.forEach((fn) => fn(status));
}

export function getShopSyncStatus() {
  return status;
}

export function subscribeShopSync(fn: (s: ShopSyncStatus) => void) {
  statusListeners.add(fn);
  fn(status);
  return () => {
    statusListeners.delete(fn);
  };
}

export function getShopToken(): string | null {
  if (typeof window === "undefined") return null;
  try {
    // Prefer localStorage so unlock survives closing the browser (still expires on server ~12h)
    return (
      localStorage.getItem(TOKEN_KEY) ||
      sessionStorage.getItem(TOKEN_KEY) ||
      null
    );
  } catch {
    try {
      return sessionStorage.getItem(TOKEN_KEY);
    } catch {
      return null;
    }
  }
}

export function setShopToken(token: string | null) {
  if (typeof window === "undefined") return;
  try {
    if (token) {
      localStorage.setItem(TOKEN_KEY, token);
      sessionStorage.setItem(TOKEN_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_KEY);
      sessionStorage.removeItem(TOKEN_KEY);
    }
  } catch {
    try {
      if (token) sessionStorage.setItem(TOKEN_KEY, token);
      else sessionStorage.removeItem(TOKEN_KEY);
    } catch {
      /* private mode */
    }
  }
  setStatus({
    hasSession: Boolean(token),
    error: token
      ? status.error?.includes("PIN")
        ? null
        : status.error
      : status.error,
  });
}

/** Register the app-shell PIN unlock UI (one handler). */
export function registerShopUnlockHandler(
  handler: ((reason?: string) => void) | null,
) {
  unlockRequestHandler = handler;
  if (handler && queuedUnlockReason !== undefined) {
    const reason = queuedUnlockReason;
    queuedUnlockReason = undefined;
    handler(reason);
  }
}

export function shopUnlockFromHostError(error?: string): boolean {
  return /unlock this pc|shop session|enter your pin|switch user|needs? pin/i.test(
    error || "",
  );
}

/** Ask the user to enter PIN so this device can write to the shop DB. */
export function requestShopUnlock(reason?: string) {
  if (unlockRequestHandler) {
    unlockRequestHandler(reason);
    return true;
  }
  queuedUnlockReason = reason || "";
  return false;
}

/** Open the PIN dialog and wait until they unlock (true) or cancel (false). */
export function waitForShopUnlock(reason?: string): Promise<boolean> {
  if (getShopToken()) return Promise.resolve(true);
  requestShopUnlock(reason);
  return new Promise((resolve) => {
    unlockWaiters.push(resolve);
  });
}

export async function ensureShopUnlocked(reason?: string): Promise<boolean> {
  if (getShopToken()) return true;
  return waitForShopUnlock(reason);
}

export function notifyShopUnlocked() {
  const waiters = unlockWaiters.splice(0);
  for (const fn of waiters) fn(true);
  if (dirty) schedulePush(80);
}

export function notifyShopUnlockCancelled() {
  const waiters = unlockWaiters.splice(0);
  for (const fn of waiters) fn(false);
}

function sharedEqual(a: ShopSharedState | null, b: ShopSharedState | null): boolean {
  if (a === b) return true;
  if (!a || !b) return false;
  try {
    return JSON.stringify(a) === JSON.stringify(b);
  } catch {
    return false;
  }
}

function snapshotNow(): ShopSharedState {
  return cloneShared(useLcmStore.getState().getSharedState());
}

function applyRemote(
  state: ShopSharedState,
  rev: number,
  updatedAt: string,
  opts?: { mergeLocal?: boolean },
) {
  applyingRemote = true;
  try {
    const local = useLcmStore.getState().getSharedState();
    const merged = threeWayMergeShop(lastAcked, local, state);
    useLcmStore.getState().replaceSharedState(merged);
    const filled = useLcmStore.getState().backfillOpenMaterialHolds();
    if (filled.added > 0) dirty = true;
    sharedRev = rev;
    lastAcked = snapshotNow();
    const stillDirty = dirty;
    dirty = stillDirty;
    setStatus({
      connected: true,
      rev,
      lastSyncAt: updatedAt,
      error: getShopToken()
        ? null
        : "Enter your PIN so this device can send chat and save changes",
      mode: "shared",
      hasSession: Boolean(getShopToken()),
    });
    if (stillDirty && getShopToken()) schedulePush(100);
  } finally {
    setTimeout(() => {
      applyingRemote = false;
    }, 0);
  }
}

async function pullOnce() {
  try {
    const snap = await pullShopState({
      data: {
        token: getShopToken() || undefined,
        sinceRev: sharedRev > 0 ? sharedRev : undefined,
      },
    });

    if (snap.unchanged) {
      setStatus({
        connected: true,
        rev: snap.rev,
        lastSyncAt: snap.updatedAt,
        error: getShopToken()
          ? null
          : "Enter your PIN so this device can send chat and save changes",
        mode: "shared",
        hasSession: Boolean(getShopToken()),
      });
      needPullBeforePush = false;
      if (dirty) schedulePush(50);
      return;
    }

    if (!snap.state) {
      setStatus({
        connected: true,
        rev: snap.rev,
        lastSyncAt: snap.updatedAt,
        error: getShopToken()
          ? null
          : "Enter your PIN so this device can send chat and save changes",
        mode: "shared",
        hasSession: Boolean(getShopToken()),
      });
      return;
    }

    // Guard: never apply an empty/seed snapshot over a full local shop view
    const remoteEmpty =
      (snap.state?.quotes?.length || 0) === 0 &&
      (snap.state?.jobs?.length || 0) === 0 &&
      (snap.state?.customers?.length || 0) === 0;
    const local = useLcmStore.getState().getSharedState();
    const localHasData =
      (local.quotes?.length || 0) +
        (local.jobs?.length || 0) +
        (local.customers?.length || 0) >
      0;

    if (remoteEmpty && localHasData && sharedRev > 0) {
      // Host likely still booting after restart — wait, do not wipe UI
      setStatus({
        connected: true,
        rev: sharedRev,
        error: "Host is restarting — waiting for shop data…",
        mode: "shared",
        hasSession: Boolean(getShopToken()),
      });
      needPullBeforePush = true;
      return;
    }

    if (snap.rev > sharedRev) {
      applyRemote(snap.state, snap.rev, snap.updatedAt, {
        mergeLocal: dirty,
      });
      needPullBeforePush = false;
    } else if (snap.rev === sharedRev) {
      setStatus({
        connected: true,
        rev: snap.rev,
        lastSyncAt: snap.updatedAt,
        error: getShopToken()
          ? null
          : "Enter your PIN so this device can send chat and save changes",
        mode: "shared",
        hasSession: Boolean(getShopToken()),
      });
      needPullBeforePush = false;
      if (dirty) schedulePush(50);
    } else {
      // Host rev behind our last known — do NOT push until we understand (host restored backup?)
      needPullBeforePush = false;
      dirty = true;
      applyRemote(snap.state, snap.rev, snap.updatedAt, { mergeLocal: true });
      schedulePush(200);
    }
  } catch (e) {
    needPullBeforePush = true;
    setStatus({
      connected: false,
      error: e instanceof Error ? e.message : "Cannot reach shop server",
      mode: sharedRev > 0 ? "shared" : "local-fallback",
      hasSession: Boolean(getShopToken()),
    });
  }
}

async function pushOnce(): Promise<FlushResult> {
  if (applyingRemote || pushing) {
    schedulePush(120);
    return { ok: false, error: "Syncing… try again" };
  }
  if (needPullBeforePush) {
    // Host was offline / restarted — pull first so we never push a partial wipe
    await pullOnce();
    if (needPullBeforePush) {
      return { ok: false, error: "Waiting for shop host…" };
    }
  }
  if (!dirty && sharedRev > 0) {
    return { ok: true, rev: sharedRev };
  }

  const token = getShopToken();
  if (!token) {
    setStatus({
      hasSession: false,
      error: "Enter your PIN so this device can send chat and save changes",
    });
    requestShopUnlock("Enter your PIN so this device can send chat and save changes");
    return {
      ok: false,
      error: "Enter your PIN so this device can send chat and save changes",
      needsPin: true,
    };
  }

  const slice = useLcmStore.getState().getSharedState();
  if (sharedRev > 0 && lastAcked && sharedEqual(slice, lastAcked)) {
    dirty = false;
    return { ok: true, rev: sharedRev };
  }
  pushing = true;
  try {
    const result = await pushShopState({
      data: { baseRev: sharedRev, state: slice, token },
    });
    if (result.ok === true) {
      sharedRev = result.rev;
      dirty = false;
      lastAcked = cloneShared(slice);
      setStatus({
        connected: true,
        rev: result.rev,
        lastSyncAt: result.updatedAt,
        error: null,
        mode: "shared",
        hasSession: true,
      });
      return { ok: true, rev: result.rev };
    }
    if ("conflict" in result && result.conflict) {
      dirty = true;
      applyRemote(result.state, result.rev, result.updatedAt, {
        mergeLocal: true,
      });
      schedulePush(200);
      return { ok: false, error: "Conflict — retrying sync…" };
    }
    if ("error" in result) {
      const needsPin =
        /session|PIN|sign in/i.test(result.error || "") ||
        result.error?.includes("Shop session");
      if (needsPin) {
        setShopToken(null);
        requestShopUnlock(result.error || "Enter your PIN to save");
      }
      setStatus({
        connected: false,
        error: result.error,
        hasSession: Boolean(getShopToken()),
      });
      return {
        ok: false,
        error: result.error || "Save failed",
        needsPin,
      };
    }
    return { ok: false, error: "Save failed" };
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Push failed";
    setStatus({
      connected: false,
      error: msg,
      hasSession: Boolean(token),
    });
    return { ok: false, error: msg };
  } finally {
    pushing = false;
  }
}

function schedulePush(ms = 400) {
  if (pushTimer) clearTimeout(pushTimer);
  pushTimer = setTimeout(() => {
    void pushOnce();
  }, ms);
}

function pollMs() {
  if (typeof document !== "undefined" && document.visibilityState === "hidden") {
    return 5000;
  }
  return 2000;
}

function armPoll() {
  if (pollTimer) clearTimeout(pollTimer);
  pollTimer = setTimeout(() => {
    void pullOnce().finally(() => {
      if (bootstrapped) armPoll();
    });
  }, pollMs());
}

let visibilityHandler: (() => void) | null = null;

/** Start (or re-arm) client shop sync — safe to call multiple times. */
export function startShopSync() {
  if (typeof window === "undefined") return;

  setStatus({ hasSession: Boolean(getShopToken()) });

  if (!bootstrapped) {
    bootstrapped = true;
    unsubStore = useLcmStore.subscribe(() => {
      if (applyingRemote) return;
      const slice = useLcmStore.getState().getSharedState();
      if (lastAcked && sharedEqual(slice, lastAcked)) return;
      dirty = true;
      schedulePush(500);
    });
  }

  if (!pollTimer) {
    armPoll();
    if (typeof document !== "undefined" && !visibilityHandler) {
      visibilityHandler = () => {
        if (document.visibilityState === "visible") void pullOnce();
      };
      document.addEventListener("visibilitychange", visibilityHandler);
    }
  }

  void pullOnce();
}

/** Await a push so chat / saves hit the host DB. */
export async function flushShopSync(): Promise<FlushResult> {
  dirty = true;
  if (pushTimer) {
    clearTimeout(pushTimer);
    pushTimer = null;
  }
  // Retry once on conflict
  let last = await pushOnce();
  if (!last.ok && last.error?.includes("Conflict")) {
    await new Promise((r) => setTimeout(r, 250));
    dirty = true;
    last = await pushOnce();
  }
  return last;
}

export function stopShopSync() {
  if (pollTimer) clearTimeout(pollTimer);
  pollTimer = null;
  if (pushTimer) clearTimeout(pushTimer);
  pushTimer = null;
  if (visibilityHandler && typeof document !== "undefined") {
    document.removeEventListener("visibilitychange", visibilityHandler);
    visibilityHandler = null;
  }
  if (unsubStore) {
    unsubStore();
    unsubStore = null;
  }
  bootstrapped = false;
}

export function useShopSyncStatus(): ShopSyncStatus {
  const [s, setS] = useState(status);
  useEffect(() => subscribeShopSync(setS), []);
  return s;
}
