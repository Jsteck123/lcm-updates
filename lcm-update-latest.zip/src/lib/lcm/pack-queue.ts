/**
 * Packing table: PO lines office/floor marked ready for pack, not yet boxed.
 */
import type { LineFileRef, PartUnit, ShopOrder } from "./types";
import { lineDrawings } from "./line-files";
import { lineShipDate } from "./shipping-calendar";

export type PackTableLine = {
  orderId: string;
  lineId: string;
  poNumber: string;
  customer: string;
  partNumber: string;
  revision: string;
  description: string;
  qty: number;
  qtyCompleted: number;
  dueDate: string;
  readyForPackBy: string;
  drawings: LineFileRef[];
  packed: boolean;
};

export type PackTableOrder = {
  orderId: string;
  poNumber: string;
  customer: string;
  dueDate: string;
  lines: PackTableLine[];
};

export function packingTableOrders(
  orders: ShopOrder[],
  units: PartUnit[] = [],
): PackTableOrder[] {
  const out: PackTableOrder[] = [];
  for (const order of orders || []) {
    if (order.status === "cancelled" || order.deliveredAt) continue;
    const lines: PackTableLine[] = [];
    for (const line of order.lines || []) {
      if (line.lineStatus === "cancelled") continue;
      const extras = extrasForPackLine(units, {
        orderId: order.id,
        lineId: line.id,
        partNumber: line.partNumber || "",
      });
      const waiting = Boolean(line.readyForPack && !line.linePacked);
      if (!waiting && !extras.length) continue;
      lines.push({
        orderId: order.id,
        lineId: line.id,
        poNumber: order.poNumber || "(no PO)",
        customer: order.customer || "",
        partNumber: line.partNumber || "",
        revision: line.revision || "",
        description: line.description || "",
        qty: Number(line.qty) || 0,
        qtyCompleted: Number(line.qtyCompleted) || 0,
        dueDate: lineShipDate(order, line),
        readyForPackBy: line.readyForPackBy || "",
        drawings: lineDrawings(line),
        packed: Boolean(line.linePacked),
      });
    }
    if (!lines.length) continue;
    const due =
      lines.map((l) => l.dueDate).filter(Boolean).sort()[0] || "";
    out.push({
      orderId: order.id,
      poNumber: order.poNumber || "(no PO)",
      customer: order.customer || "",
      dueDate: due,
      lines,
    });
  }
  out.sort((a, b) => {
    const da = a.dueDate || "9999-12-31";
    const db = b.dueDate || "9999-12-31";
    if (da !== db) return da.localeCompare(db);
    return a.poNumber.localeCompare(b.poNumber);
  });
  return out;
}

export function packingTableLineCount(groups: PackTableOrder[]): number {
  return groups.reduce((n, g) => n + g.lines.length, 0);
}

function samePn(a: string, b: string) {
  return (a || "").trim().toUpperCase() === (b || "").trim().toUpperCase();
}

/** Extras sent to the packing table for this PO line (good / minor issues). */
export function extrasForPackLine(
  units: PartUnit[] | undefined,
  line: { orderId: string; lineId: string; partNumber: string },
): PartUnit[] {
  return (units || []).filter((u) => {
    if (u.status === "scrapped" || u.status === "issued") return false;
    if (u.lineId && u.lineId === line.lineId) return true;
    if (u.orderId && u.orderId === line.orderId && samePn(u.partNumber, line.partNumber))
      return true;
    const loc = (u.location || "").toLowerCase();
    if (loc.includes("packing") && samePn(u.partNumber, line.partNumber)) return true;
    return false;
  });
}
