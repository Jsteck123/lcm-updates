import { createFileRoute, Link } from "@tanstack/react-router";
import { Package, Printer, Search } from "lucide-react";
import { toast } from "sonner";
import { useMemo, useState } from "react";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { PageHowTo } from "@/components/lcm/page-howto";
import { DrawingThumb } from "@/components/lcm/drawing-thumb";
import { getOperatorByEmail } from "@/lib/lcm/permissions";
import {
  extrasForPackLine,
  packingTableLineCount,
  packingTableOrders,
} from "@/lib/lcm/pack-queue";
import { printPackBoxLabelOrToast } from "@/lib/lcm/print-box-labels";
import { printUinPartLabelOrToast } from "@/lib/lcm/print-uin-labels";
import { formatDate } from "@/lib/utils";

export const Route = createFileRoute("/pack")({
  component: PackingTablePage,
});

function PackingTablePage() {
  const shopOrders = useLcmStore((s) => s.shopOrders || []);
  const partUnits = useLcmStore((s) => s.partUnits || []);
  const getPartUnitByUin = useLcmStore((s) => s.getPartUnitByUin);
  const packLineIntoBox = useLcmStore((s) => s.packLineIntoBox);
  const shopPublicUrl = useLcmStore((s) => s.settings.shopPublicUrl);
  const email = useLcmStore((s) => s.currentUserEmail);
  const operators = useLcmStore((s) => s.operators);
  const me = getOperatorByEmail(operators, email);
  const myName = me?.name || "";
  const [uinLookup, setUinLookup] = useState("");
  const uinHit = getPartUnitByUin(uinLookup);

  const groups = useMemo(
    () => packingTableOrders(shopOrders, partUnits),
    [shopOrders, partUnits],
  );
  const lineCount = packingTableLineCount(groups);

  async function markPacked(orderId: string, lineId: string) {
    const r = packLineIntoBox(orderId, lineId, myName);
    if (!r.ok || !r.box) {
      toast.error(r.error || "Could not pack");
      return;
    }
    toast.success(`Packed ${r.box.partNumber} · qty ${r.box.qty}`);
    await printPackBoxLabelOrToast(r.box, shopPublicUrl);
  }

  return (
    <div className="mx-auto max-w-5xl space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight flex items-center gap-2">
            <Package className="h-7 w-7 text-[var(--color-primary)]" />
            Packing Table
          </h1>
          <p className="text-sm text-[var(--color-muted)] mt-1">
            Jobs ready to pack. Pack the order qty, tap Packed for the box
            label. Extra parts (UIN on them) get a small QR sticker from this
            page only. Pam scans the box QR to load the truck.
          </p>
        </div>
        <PageHowTo id="packing-table" />
      </div>

      <div className="flex flex-wrap items-center gap-2 text-sm">
        <Badge tone={groups.length ? "ready" : "neutral"}>
          {groups.length} order{groups.length === 1 ? "" : "s"} on the table
        </Badge>
        <span className="text-[var(--color-muted)]">
          {lineCount} line{lineCount === 1 ? "" : "s"} waiting
        </span>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Search className="h-4 w-4" /> Look up UIN
          </CardTitle>
          <CardDescription>
            Type the 4-digit sharpie number to see who ran it, when, and notes.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <Input
            value={uinLookup}
            onChange={(e) => setUinLookup(e.target.value)}
            placeholder="UIN"
            className="max-w-xs font-mono tracking-widest"
            inputMode="numeric"
          />
          {uinLookup.trim() && !uinHit ? (
            <p className="text-xs text-[var(--color-muted)]">No part for that UIN</p>
          ) : null}
          {uinHit ? (
            <div className="text-sm space-y-1">
              <div className="font-mono font-semibold">
                {uinHit.partNumber} Rev {uinHit.revision || "—"} · UIN {uinHit.uin}
              </div>
              <div>
                {uinHit.operatorName || uinHit.stockedBy || "—"}
                {uinHit.stockedAt
                  ? ` · ${formatDate(uinHit.stockedAt)}`
                  : ""}
              </div>
              <Badge tone={uinHit.quality === "second" ? "warn" : "success"}>
                {uinHit.quality === "second" ? "Minor issues" : "Good"}
              </Badge>
              {uinHit.defectNote ? (
                <p className="text-xs">{uinHit.defectNote}</p>
              ) : null}
              {uinHit.notes ? (
                <p className="text-xs text-[var(--color-muted)]">{uinHit.notes}</p>
              ) : null}
              <Button
                type="button"
                size="sm"
                onClick={() => void printUinPartLabelOrToast(uinHit, shopPublicUrl)}
              >
                <Printer className="h-3.5 w-3.5" /> Print extra label
              </Button>
            </div>
          ) : null}
        </CardContent>
      </Card>

      {groups.length === 0 ? (
        <p className="text-sm text-[var(--color-muted)] text-center py-12">
          Nothing on the packing table. Finished jobs show here after they are
          marked ready for pack.
        </p>
      ) : (
        <div className="space-y-4">
          {groups.map((g) => (
            <Card key={g.orderId}>
              <CardHeader className="pb-2">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <CardTitle className="font-mono text-base">
                      {g.poNumber}
                    </CardTitle>
                    <CardDescription>
                      {g.customer || "—"}
                      {g.dueDate ? ` · Due ${formatDate(g.dueDate)}` : ""}
                    </CardDescription>
                  </div>
                  <Link
                    to="/po"
                    search={{ order: g.orderId }}
                    className="text-[10px] text-[var(--color-primary)]"
                  >
                    Open full PO
                  </Link>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                {g.lines.map((l) => {
                  const extras = extrasForPackLine(partUnits, l);
                  const ran = Math.max(
                    l.qtyCompleted,
                    l.qty + extras.length,
                  );
                  return (
                  <div
                    key={l.lineId}
                    className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] px-2.5 py-2 space-y-2"
                  >
                    <div className="flex items-center gap-3">
                    <DrawingThumb size="lg" file={l.drawings[0]} />
                    <div className="min-w-0 flex-1">
                      <div className="font-mono font-semibold text-sm">
                        {l.partNumber || "—"}{" "}
                        <span className="text-xs font-normal">
                          Rev {l.revision || "—"}
                        </span>
                      </div>
                      <div className="text-xs text-[var(--color-muted)] line-clamp-2">
                        {l.description}
                      </div>
                      <div className="text-[11px] mt-0.5">
                        Ordered <strong>{l.qty}</strong>
                        {" · "}
                        ran <strong>{ran}</strong>
                        {" · pack "}
                        <strong>{l.qty}</strong>
                        {extras.length ? (
                          <>
                            {" · extra "}
                            <strong>{extras.length}</strong>
                          </>
                        ) : null}
                        {l.readyForPackBy ? (
                          <span className="text-[var(--color-muted)]">
                            {" "}
                            · ready by {l.readyForPackBy}
                          </span>
                        ) : null}
                      </div>
                    </div>
                    <Button
                      type="button"
                      className="shrink-0 min-h-11"
                      disabled={l.packed}
                      onClick={() => void markPacked(l.orderId, l.lineId)}
                    >
                      <Printer className="h-4 w-4" /> {l.packed ? "Box done" : "Packed"}
                    </Button>
                    </div>
                    {extras.map((u) => (
                      <div
                        key={u.id}
                        className="ml-1 flex flex-wrap items-center gap-2 rounded-md border border-[var(--color-border)] bg-[var(--color-surface)] px-2 py-1.5 text-xs"
                      >
                        <span className="font-mono font-bold tracking-widest">
                          UIN {u.uin}
                        </span>
                        <Badge
                          tone={u.quality === "second" ? "warn" : "success"}
                        >
                          {u.quality === "second" ? "Minor issues" : "Good extra"}
                        </Badge>
                        <span className="text-[var(--color-muted)]">
                          {u.operatorName || u.stockedBy || ""}
                          {u.stockedAt ? ` · ${formatDate(u.stockedAt)}` : ""}
                        </span>
                        {u.defectNote ? (
                          <span className="w-full">{u.defectNote}</span>
                        ) : null}
                        <Button
                          type="button"
                          size="sm"
                          variant="secondary"
                          className="ml-auto min-h-9"
                          onClick={() =>
                            void printUinPartLabelOrToast(u, shopPublicUrl)
                          }
                        >
                          Print extra label
                        </Button>
                      </div>
                    ))}
                  </div>
                  );
                })}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
