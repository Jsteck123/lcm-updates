import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  ChevronLeft,
  ChevronRight,
  Printer,
  Package,
  CheckCircle2,
  RotateCcw,
  Truck,
  FileText,
} from "lucide-react";
import { toast } from "sonner";
import { PageHowTo } from "@/components/lcm/page-howto";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import {
  formatMonthTitle,
  monthDaySummaries,
  monthMatrix,
  ordersForDate,
  todayYmd,
  lineShipDate,
} from "@/lib/lcm/shipping-calendar";
import { fridayOfWeek, weekRangeContaining } from "@/lib/lcm/job-board";
import {
  ShippingWorkOrderSheet,
  ShipLabelSheet,
} from "@/components/lcm/work-order-print";
import { savePoAttachment } from "@/lib/lcm/po-files-api";
import { openPoAttachment } from "@/lib/lcm/open-attachment";
import { lineDrawings } from "@/lib/lcm/line-files";
import { getShopToken } from "@/lib/lcm/shop-sync";
import type { ShopOrder } from "@/lib/lcm/types";
import { CompanyLogo } from "@/components/lcm/company-logo";
import { getOperatorByEmail } from "@/lib/lcm/permissions";
import {
  dueUrgency,
  packStatusToShop,
  deliveryCloseoutStatus,
  statusSurfaceClass,
  statusToBadgeTone,
} from "@/lib/lcm/status-colors";

export const Route = createFileRoute("/calendar")({
  component: ShipCalendarPage,
});

const DOW = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function packTone(status: string | undefined) {
  return statusToBadgeTone(packStatusToShop(status));
}

function packLabel(status: string | undefined) {
  if (status === "verified") return "Ready / verified";
  if (status === "packed") return "Packed on cart";
  return "Need pack";
}

function ShipCalendarPage() {
  const shopOrders = useLcmStore((s) => s.shopOrders || []);
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  const setPack = useLcmStore((s) => s.setShopOrderPackStatus);
  const setDelivery = useLcmStore((s) => s.setOrderDelivery);
  const patchLine = useLcmStore((s) => s.patchShopOrderLine);
  const me = getOperatorByEmail(operators, email);
  const myName = me?.name || email.split("@")[0] || "User";
  const isAdmin = me?.role === "admin";

  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth());
  const [selected, setSelected] = useState<string | null>(todayYmd());
  const [printOrderId, setPrintOrderId] = useState<string | null>(null);
  const [printMode, setPrintMode] = useState<"pack" | "shipwo" | "labels">("pack");
  const [readyOnly, setReadyOnly] = useState(false);
  const fri = fridayOfWeek();
  const week = weekRangeContaining();

  const summaries = useMemo(
    () => monthDaySummaries(shopOrders, year, month),
    [shopOrders, year, month],
  );
  const weeks = useMemo(() => monthMatrix(year, month), [year, month]);
  const today = todayYmd();

  const dayOrders = useMemo(() => {
    if (!selected) return [];
    let list = ordersForDate(shopOrders, selected);
    if (readyOnly) {
      list = list
        .map((x) => ({
          ...x,
          lines: x.lines.filter((l) => l.readyForPack && !l.linePacked),
        }))
        .filter((x) => x.lines.length > 0);
    }
    return list;
  }, [shopOrders, selected, readyOnly]);

  const printOrder = useMemo(
    () => shopOrders.find((o) => o.id === printOrderId) || null,
    [shopOrders, printOrderId],
  );

  function prevMonth() {
    if (month === 0) {
      setMonth(11);
      setYear((y) => y - 1);
    } else setMonth((m) => m - 1);
  }
  function nextMonth() {
    if (month === 11) {
      setMonth(0);
      setYear((y) => y + 1);
    } else setMonth((m) => m + 1);
  }

  function markPacked(orderId: string) {
    const r = setPack(orderId, "packed", myName);
    if (r.ok) toast.success("Marked packed — on outgoing cart");
    else toast.error(r.error || "Failed");
  }
  function markVerified(orderId: string) {
    const r = setPack(orderId, "verified", myName);
    if (r.ok) toast.success("Office verified — ready to load");
    else toast.error(r.error || "Failed");
  }
  function resetPack(orderId: string) {
    const r = setPack(orderId, "pending", myName);
    if (r.ok) toast.message("Pack status reset");
    else toast.error(r.error || "Failed");
  }

  function doPrint(orderId: string) {
    setPrintOrderId(orderId);
    window.setTimeout(() => window.print(), 80);
  }

  return (
    <div className="p-3 sm:p-5 space-y-4 max-w-[1400px] mx-auto">
      <div className="print:hidden space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold tracking-tight">Ship Calendar</h1>
          <p className="text-sm text-[var(--color-muted)] mt-0.5">
            Due dates from customer orders — pack, verify, Friday delivery run,
            then mark delivered / attach signed slip / QB invoice flags.
          </p>
          <div className="flex flex-wrap gap-1.5 mt-2 text-[10px]">
            <Badge tone="hold">Hold / need pack</Badge>
            <Badge tone="soon">Due ≤2 days</Badge>
            <Badge tone="overdue">Overdue</Badge>
            <Badge tone="active">Packed / in progress</Badge>
            <Badge tone="ready">Verified / delivered</Badge>
            <Badge tone="office">Invoiced (office)</Badge>
            <Badge tone="done">Paid</Badge>
          </div>
        </div>
        <PageHowTo id="ship-calendar" />
        </div>
        <FridayDeliveryStrip
          shopOrders={shopOrders}
          weekStart={week.start}
          weekEnd={week.end}
          friday={fri}
          myName={myName}
          onPrintPack={(id) => {
            setPrintMode("pack");
            setPrintOrderId(id);
            window.setTimeout(() => window.print(), 80);
          }}
          onPrintShipWo={(id) => {
            setPrintMode("shipwo");
            setPrintOrderId(id);
            window.setTimeout(() => window.print(), 80);
          }}
          onDelivered={(id) => {
            const r = setDelivery(id, { delivered: true, deliveredBy: myName });
            if (r.ok) toast.success("Marked delivered");
            else toast.error(r.error || "Failed");
          }}
        />
      </div>

      <div className="grid lg:grid-cols-12 gap-4 print:hidden">
        <Card className="lg:col-span-7">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between gap-2">
              <CardTitle className="text-base">
                {formatMonthTitle(year, month)}
              </CardTitle>
              <div className="flex gap-1">
                <Button size="sm" variant="outline" type="button" onClick={prevMonth}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  type="button"
                  onClick={() => {
                    const d = new Date();
                    setYear(d.getFullYear());
                    setMonth(d.getMonth());
                    setSelected(todayYmd());
                  }}
                >
                  Today
                </Button>
                <Button size="sm" variant="outline" type="button" onClick={nextMonth}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <CardDescription>
              PO #s on each day · colors: need pack / packed / verified
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-1 mb-1">
              {DOW.map((d) => (
                <div
                  key={d}
                  className="text-center text-[10px] font-semibold uppercase text-[var(--color-muted)] py-1"
                >
                  {d}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-1">
              {weeks.flat().map((dateKey, i) => {
                if (!dateKey) {
                  return (
                    <div
                      key={`e-${i}`}
                      className="min-h-[5.5rem] rounded-[var(--radius-md)] bg-[var(--color-surface-2)]/40"
                    />
                  );
                }
                const sum = summaries.get(dateKey);
                const isSel = selected === dateKey;
                const isToday = dateKey === today;
                const dayNum = Number(dateKey.slice(-2));
                return (
                  <button
                    key={dateKey}
                    type="button"
                    onClick={() => setSelected(dateKey)}
                    className={cn(
                      "min-h-[5.5rem] rounded-[var(--radius-md)] border p-1.5 text-left transition-colors",
                      isSel
                        ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_12%,transparent)]"
                        : "border-[var(--color-border)] hover:bg-[var(--color-surface-2)]",
                      isToday && !isSel && "ring-1 ring-[var(--color-primary)]/40",
                      !isSel &&
                        dueUrgency(dateKey) === "overdue" &&
                        sum &&
                        sum.poCount > 0 &&
                        "status-surface-danger",
                      !isSel &&
                        dueUrgency(dateKey) === "soon" &&
                        sum &&
                        sum.poCount > 0 &&
                        "status-surface-soon",
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className={cn(
                          "text-xs font-semibold tabular-nums",
                          isToday && "text-[var(--color-primary)]",
                        )}
                      >
                        {dayNum}
                      </span>
                      {sum && sum.poCount > 0 && (
                        <span className="text-[9px] text-[var(--color-muted)]">
                          {sum.poCount} PO
                        </span>
                      )}
                    </div>
                    {sum && sum.poNumbers.length > 0 && (
                      <div className="mt-1 space-y-0.5">
                        {sum.poNumbers.slice(0, 3).map((po) => (
                          <div
                            key={po}
                            className="text-[9px] font-mono truncate leading-tight text-[var(--color-fg)]"
                          >
                            {po}
                          </div>
                        ))}
                        {sum.poNumbers.length > 3 && (
                          <div className="text-[9px] text-[var(--color-muted)]">
                            +{sum.poNumbers.length - 3} more
                          </div>
                        )}
                        <div className="flex gap-0.5 pt-0.5">
                          {sum.pending > 0 && (
                            <span className="h-1.5 flex-1 rounded-full bg-amber-500/70" title="Need pack" />
                          )}
                          {sum.packed > 0 && (
                            <span className="h-1.5 flex-1 rounded-full bg-sky-500/70" title="Packed" />
                          )}
                          {sum.verified > 0 && (
                            <span className="h-1.5 flex-1 rounded-full bg-emerald-500/70" title="Verified" />
                          )}
                        </div>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <div className="lg:col-span-5 space-y-3">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Truck className="h-4 w-4" />
                {selected
                  ? new Date(selected + "T12:00:00").toLocaleDateString(
                      undefined,
                      {
                        weekday: "long",
                        month: "long",
                        day: "numeric",
                        year: "numeric",
                      },
                    )
                  : "Select a day"}
              </CardTitle>
              <CardDescription>
                Line items & qty · filter ready-for-pack · packing slip / ship WO /
                labels · pack → verify → deliver
              </CardDescription>
              <label className="flex items-center gap-2 text-xs mt-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={readyOnly}
                  onChange={(e) => setReadyOnly(e.target.checked)}
                />
                Ready for pack only (from shop complete)
              </label>
            </CardHeader>
            <CardContent className="space-y-4 max-h-[70vh] overflow-y-auto">
              {dayOrders.length === 0 && (
                <p className="text-sm text-[var(--color-muted)] py-6 text-center">
                  Nothing due this day.
                </p>
              )}
              {dayOrders.map(({ order, lines }) => (
                <OrderShipCard
                  key={order.id}
                  order={order}
                  lines={lines}
                  isAdmin={!!isAdmin}
                  myName={myName}
                  onPrint={() => {
                    setPrintMode("pack");
                    doPrint(order.id);
                  }}
                  onShipWo={() => {
                    setPrintMode("shipwo");
                    doPrint(order.id);
                  }}
                  onLabels={() => {
                    setPrintMode("labels");
                    doPrint(order.id);
                  }}
                  onPacked={() => markPacked(order.id)}
                  onVerified={() => markVerified(order.id)}
                  onReset={() => resetPack(order.id)}
                  onLinePacked={(lineId) => {
                    patchLine(order.id, lineId, {
                      linePacked: true,
                      linePackedAt: new Date().toISOString(),
                      linePackedBy: myName,
                    });
                    toast.success("Line marked packed");
                  }}
                  onDelivered={() => {
                    const r = setDelivery(order.id, {
                      delivered: true,
                      deliveredBy: myName,
                    });
                    if (r.ok) toast.success("Delivered");
                    else toast.error(r.error || "Failed");
                  }}
                  onInvoiced={() => {
                    setDelivery(order.id, { invoicedInQb: true });
                    toast.success("Marked invoiced in QB");
                  }}
                  onPaid={() => {
                    setDelivery(order.id, { paymentReceived: true });
                    toast.success("Payment received — job closed");
                  }}
                  onSignedSlip={async (file: File) => {
                    const buf = await file.arrayBuffer();
                    const bytes = new Uint8Array(buf);
                    let binary = "";
                    const chunk = 0x8000;
                    for (let i = 0; i < bytes.length; i += chunk) {
                      binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
                    }
                    const up = await savePoAttachment({
                      data: {
                        name: file.name,
                        mime: file.type || "application/pdf",
                        base64: btoa(binary),
                        token: getShopToken() || undefined,
                      },
                    });
                    if (!up.ok) {
                      toast.error(up.error || "Upload failed");
                      return;
                    }
                    setDelivery(order.id, {
                      signedSlipFileId: up.meta.id,
                      signedSlipName: up.meta.name,
                      signedSlipMime: up.meta.mime,
                    });
                    toast.success("Signed packing slip attached");
                  }}
                />
              ))}
            </CardContent>
          </Card>
        </div>
      </div>

      
      {/* Print sheets */}
      <div id="lcm-packing-slip" className="hidden print:block">
        {printOrder && printMode === "pack" && (
          <div className="bg-white text-black p-8">
            <div className="flex justify-between items-start border-b border-neutral-400 pb-4">
              <div>
                <CompanyLogo variant="wide" className="h-14 w-auto max-w-[240px]" />
                <div className="text-sm mt-2 text-neutral-700">Packing Slip</div>
              </div>
              <div className="text-right text-sm">
                <div className="text-xl font-bold">PACKING SLIP</div>
                <div className="mt-2 font-mono font-semibold text-lg">
                  {printOrder.poNumber || "—"}
                </div>
                <div>
                  Due:{" "}
                  {printOrder.dueDate || printOrder.dateRequired || selected || "—"}
                </div>
                <div>Printed: {new Date().toLocaleString()}</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 mt-4 text-sm">
              <div className="border border-neutral-400 rounded p-2">
                <div className="font-semibold text-xs uppercase text-neutral-600">
                  Ship to / Customer
                </div>
                <div className="whitespace-pre-wrap mt-1">
                  {[printOrder.customer, printOrder.shipToName, printOrder.shipToAddress]
                    .filter(Boolean)
                    .join("\n") || "—"}
                </div>
              </div>
              <div className="border border-neutral-400 rounded p-2 space-y-1">
                <div>SO #: {printOrder.soNumber || "—"}</div>
                <div>Status: {printOrder.status}</div>
              </div>
            </div>
            <table className="w-full mt-4 text-sm border border-neutral-400">
              <thead>
                <tr className="bg-neutral-100">
                  <th className="border border-neutral-400 px-2 py-1 text-left">Part #</th>
                  <th className="border border-neutral-400 px-2 py-1">Rev</th>
                  <th className="border border-neutral-400 px-2 py-1 text-left">Description</th>
                  <th className="border border-neutral-400 px-2 py-1 text-right">Qty</th>
                  <th className="border border-neutral-400 px-2 py-1 text-center">Packed</th>
                  <th className="border border-neutral-400 px-2 py-1 text-center">OK</th>
                </tr>
              </thead>
              <tbody>
                {(printOrder.lines || []).map((l) => (
                  <tr key={l.id}>
                    <td className="border border-neutral-400 px-2 py-2 font-mono">{l.partNumber}</td>
                    <td className="border border-neutral-400 px-2 py-2 text-center">{l.revision}</td>
                    <td className="border border-neutral-400 px-2 py-2">{l.description}</td>
                    <td className="border border-neutral-400 px-2 py-2 text-right">{l.qty}</td>
                    <td className="border border-neutral-400 px-2 py-2 text-center">☐</td>
                    <td className="border border-neutral-400 px-2 py-2 text-center">☐</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="mt-6 grid grid-cols-2 gap-6 text-sm">
              <div className="border border-neutral-400 rounded p-3">
                <div className="font-semibold">Shop — packed on cart</div>
                <div className="mt-3">Name: _______________</div>
                <div className="mt-2">☐ All lines packed</div>
              </div>
              <div className="border border-neutral-400 rounded p-3">
                <div className="font-semibold">Office — verified ready</div>
                <div className="mt-3">Name: _______________</div>
                <div className="mt-2">☐ Cart checked against this slip</div>
              </div>
            </div>
          </div>
        )}
        {printOrder && printMode === "shipwo" && (
          <ShippingWorkOrderSheet order={printOrder} />
        )}
        {printOrder && printMode === "labels" && (
          <div className="p-4 flex flex-wrap gap-4">
            {(printOrder.lines || []).map((l) => (
              <ShipLabelSheet key={l.id} order={printOrder} line={l} />
            ))}
          </div>
        )}
      </div>

      <style>{`
        @media print {
          body * { visibility: hidden !important; }
          #lcm-packing-slip, #lcm-packing-slip * { visibility: visible !important; }
          #lcm-packing-slip {
            position: absolute !important;
            left: 0; top: 0; width: 100%;
            display: block !important;
          }
        }
      `}</style>

    </div>
  );
}

function FridayDeliveryStrip({
  shopOrders,
  weekStart,
  weekEnd,
  friday,
  myName,
  onPrintPack,
  onPrintShipWo,
  onDelivered,
}: {
  shopOrders: ShopOrder[];
  weekStart: string;
  weekEnd: string;
  friday: string;
  myName: string;
  onPrintPack: (id: string) => void;
  onPrintShipWo: (id: string) => void;
  onDelivered: (id: string) => void;
}) {
  const batch = useMemo(() => {
    return shopOrders.filter((o) => {
      if (o.status === "cancelled") return false;
      if (o.deliveredAt) return false;
      const due = o.dueDate || o.dateRequired || "";
      const inWeek = due >= weekStart && due <= weekEnd;
      const ready =
        o.packStatus === "verified" ||
        o.packStatus === "packed" ||
        (o.lines || []).some((l) => l.readyForPack || l.linePacked);
      return inWeek || ready;
    });
  }, [shopOrders, weekStart, weekEnd]);

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">
          Friday delivery run · {friday}
        </CardTitle>
        <CardDescription>
          This week ({weekStart} → {weekEnd}) + packed/verified. Print slips
          Thursday/Friday morning, QC, load bay.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-2">
        {batch.length === 0 && (
          <p className="text-sm text-[var(--color-muted)]">No deliveries queued this week.</p>
        )}
        {batch.map((o) => (
          <div
            key={o.id}
            className="flex flex-wrap items-center justify-between gap-2 border border-[var(--color-border)] rounded-md px-3 py-2 text-sm"
          >
            <div>
              <span className="font-mono font-semibold">{o.poNumber || o.id.slice(0, 6)}</span>
              <span className="text-[var(--color-muted)] text-xs ml-2">
                {o.customer} · due {o.dueDate || o.dateRequired || "—"} ·{" "}
                {packLabel(o.packStatus)}
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              <Button size="sm" variant="secondary" type="button" onClick={() => onPrintPack(o.id)}>
                <Printer className="h-3.5 w-3.5" /> Slip
              </Button>
              <Button size="sm" variant="outline" type="button" onClick={() => onPrintShipWo(o.id)}>
                Ship WO
              </Button>
              {o.packStatus === "verified" && !o.deliveredAt && (
                <Button size="sm" type="button" onClick={() => onDelivered(o.id)}>
                  Delivered
                </Button>
              )}
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

function OrderShipCard({
  order,
  lines,
  isAdmin,
  myName,
  onPrint,
  onShipWo,
  onLabels,
  onPacked,
  onVerified,
  onReset,
  onLinePacked,
  onDelivered,
  onInvoiced,
  onPaid,
  onSignedSlip,
}: {
  order: ShopOrder;
  lines: ShopOrder["lines"];
  isAdmin: boolean;
  myName: string;
  onPrint: () => void;
  onShipWo: () => void;
  onLabels: () => void;
  onPacked: () => void;
  onVerified: () => void;
  onReset: () => void;
  onLinePacked: (lineId: string) => void;
  onDelivered: () => void;
  onInvoiced: () => void;
  onPaid: () => void;
  onSignedSlip: (file: File) => void;
}) {
  const status = order.packStatus || "pending";
  const closeStatus = deliveryCloseoutStatus(order);
  return (
    <div
      className={
        "rounded-[var(--radius-md)] border border-[var(--color-border)] p-3 space-y-2 " +
        statusSurfaceClass(closeStatus)
      }
    >
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <div className="font-mono font-semibold">
            {order.poNumber || "(no PO #)"}
          </div>
          <div className="text-xs text-[var(--color-muted)]">
            {order.customer || "Customer"} ·{" "}
            <Link
              to="/po"
              className="text-[var(--color-primary)] underline-offset-2 hover:underline"
            >
              open order
            </Link>
            {order.deliveredAt ? " · delivered" : ""}
            {isAdmin && order.invoicedInQb ? (
              <Badge tone="office" className="ml-1">
                Invoiced QB
              </Badge>
            ) : null}
            {isAdmin && order.paymentReceived ? (
              <Badge tone="done" className="ml-1">
                Paid
              </Badge>
            ) : null}
          </div>
        </div>
        <Badge tone={packTone(status)}>{packLabel(status)}</Badge>
      </div>

      <div className="rounded border border-[var(--color-border)] overflow-hidden">
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-[var(--color-surface-2)] text-left">
              <th className="px-2 py-1.5 font-medium">Part</th>
              <th className="px-2 py-1.5 font-medium">Rev</th>
              <th className="px-2 py-1.5 font-medium">Description</th>
              <th className="px-2 py-1.5 font-medium text-right">Qty</th>
              <th className="px-2 py-1.5 font-medium">Pack</th>
              <th className="px-2 py-1.5 font-medium">Print</th>
            </tr>
          </thead>
          <tbody>
            {lines.map((l) => (
              <tr key={l.id} className="border-t border-[var(--color-border)]">
                <td className="px-2 py-1.5 font-mono">
                  {l.partNumber}
                  {l.readyForPack ? (
                    <span className="block text-[9px] text-[var(--color-success)]">
                      ready for pack
                    </span>
                  ) : null}
                </td>
                <td className="px-2 py-1.5">{l.revision}</td>
                <td className="px-2 py-1.5 text-[var(--color-muted)]">
                  {l.description}
                </td>
                <td className="px-2 py-1.5 text-right tabular-nums font-semibold">
                  {l.qty}
                </td>
                <td className="px-2 py-1.5">
                  {l.linePacked ? (
                    <span className="text-[var(--color-success)]">✓</span>
                  ) : l.readyForPack ? (
                    <button
                      type="button"
                      className="text-[var(--color-primary)] underline text-[10px]"
                      onClick={() => onLinePacked(l.id)}
                    >
                      Mark packed
                    </button>
                  ) : (
                    "—"
                  )}
                </td>
                <td className="px-2 py-1.5">
                  {(() => {
                    const draws = lineDrawings(l);
                    if (!draws.length) {
                      return (
                        <span className="text-[var(--color-subtle)]">—</span>
                      );
                    }
                    return (
                      <div className="flex flex-wrap gap-1">
                        {draws.map((d, i) => (
                          <button
                            key={d.id}
                            type="button"
                            className="text-[var(--color-primary)] underline text-[10px]"
                            onClick={async () => {
                              const r = await openPoAttachment({
                                id: d.id,
                                name: d.name || "drawing",
                              });
                              if (!r.ok) toast.error(r.error || "No drawing");
                            }}
                          >
                            {draws.length > 1 ? `Draw ${i + 1}` : "Drawing"}
                          </button>
                        ))}
                      </div>
                    );
                  })()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex flex-wrap gap-2">
        <Button size="sm" variant="secondary" type="button" onClick={onPrint}>
          <Printer className="h-3.5 w-3.5" /> Packing slip
        </Button>
        <Button size="sm" variant="outline" type="button" onClick={onShipWo}>
          Ship WO
        </Button>
        <Button size="sm" variant="outline" type="button" onClick={onLabels}>
          Labels
        </Button>
        {lines.some((l) => lineDrawings(l).length > 0) &&
          lines.flatMap((l) => lineDrawings(l)).slice(0, 4).map((d, i, all) => (
            <Button
              key={d.id}
              size="sm"
              variant="outline"
              type="button"
              onClick={async () => {
                const r = await openPoAttachment({
                  id: d.id,
                  name: d.name || "drawing",
                });
                if (!r.ok) toast.error(r.error || "No drawing");
              }}
            >
              <FileText className="h-3.5 w-3.5" />{" "}
              {all.length > 1 ? `Drawing ${i + 1}` : "Drawing"}
            </Button>
          ))}
        {status === "pending" && (
          <Button size="sm" type="button" onClick={onPacked}>
            <Package className="h-3.5 w-3.5" /> Shop packed
          </Button>
        )}
        {status === "packed" && (
          <Button size="sm" type="button" onClick={onVerified}>
            <CheckCircle2 className="h-3.5 w-3.5" /> Office verified
          </Button>
        )}
        {status === "verified" && !order.deliveredAt && (
          <Button size="sm" type="button" onClick={onDelivered}>
            Delivered
          </Button>
        )}
        {(status !== "pending" || isAdmin) && (
          <Button size="sm" variant="outline" type="button" onClick={onReset}>
            <RotateCcw className="h-3.5 w-3.5" /> Reset pack
          </Button>
        )}
      </div>

      <div className="flex flex-wrap gap-2 items-center pt-1 border-t border-[var(--color-border)]">
        <label className="text-xs text-[var(--color-muted)]">
          Signed slip{" "}
          <input
            type="file"
            accept=".pdf,image/*"
            className="text-xs"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onSignedSlip(f);
              e.target.value = "";
            }}
          />
        </label>
        {order.signedSlipFileId && (
          <span className="text-[10px] text-[var(--color-success)]">
            Slip on file
          </span>
        )}
        {isAdmin && !order.invoicedInQb && order.deliveredAt && (
          <Button size="sm" variant="secondary" type="button" onClick={onInvoiced}>
            Invoiced in QB
          </Button>
        )}
        {isAdmin && order.invoicedInQb && !order.paymentReceived && (
          <Button size="sm" type="button" onClick={onPaid}>
            Payment received
          </Button>
        )}
      </div>
    </div>
  );
}
