import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ScanBarcode, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHowTo } from "@/components/lcm/page-howto";
import { getOperatorByEmail } from "@/lib/lcm/permissions";
import { cutTicketLabel } from "@/lib/lcm/cut-tickets";
import {
  leftoverCut,
  matchingOpenCuts,
  resolveScanCode,
} from "@/lib/lcm/scan-stock";

export const Route = createFileRoute("/scan")({
  validateSearch: (search: Record<string, unknown>): {
    c?: string;
    ticket?: string;
  } => {
    const out: { c?: string; ticket?: string } = {};
    if (typeof search.c === "string" && search.c.trim()) out.c = search.c.trim();
    if (typeof search.ticket === "string" && search.ticket.trim())
      out.ticket = search.ticket.trim();
    return out;
  },
  component: ScanPage,
});

function ScanPage() {
  const { c, ticket: ticketQ } = Route.useSearch();
  const consumePiece = useLcmStore((s) => s.consumePiece);
  const inventoryMove = useLcmStore((s) => s.inventoryMove);
  const recordCutProgress = useLcmStore((s) => s.recordCutProgress);
  const stockPieces = useLcmStore((s) => s.stockPieces || []);
  const materialStock = useLcmStore((s) => s.materialStock || []);
  const cutTickets = useLcmStore((s) => s.cutTickets || []);
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  const me = getOperatorByEmail(operators, email);
  const myName = me?.name || email.split("@")[0] || "Saw";

  const [code, setCode] = useState(c || "");
  const [lengthUsed, setLengthUsed] = useState("");
  const [qty, setQty] = useState("1");
  const [jobRef, setJobRef] = useState("");
  const [reason, setReason] = useState("");
  const [lastOk, setLastOk] = useState<string | null>(null);
  const [ticketId, setTicketId] = useState(ticketQ || "");

  useEffect(() => {
    if (c) setCode(c);
  }, [c]);
  useEffect(() => {
    if (ticketQ) setTicketId(ticketQ);
  }, [ticketQ]);

  const hit = useMemo(
    () => resolveScanCode(code, stockPieces, materialStock),
    [code, stockPieces, materialStock],
  );
  const piece = hit?.kind === "piece" ? hit.piece : undefined;
  const rack = hit?.kind === "material" ? hit.material : undefined;

  const ticketChoices = useMemo(() => {
    if (hit) return matchingOpenCuts(hit, cutTickets);
    return [];
  }, [hit, cutTickets]);

  const boundTicket = useMemo(() => {
    if (ticketId) {
      return cutTickets.find((t) => t.id === ticketId) || null;
    }
    if (ticketChoices.length === 1) return ticketChoices[0]!;
    return null;
  }, [ticketId, cutTickets, ticketChoices]);

  useEffect(() => {
    if (!boundTicket) return;
    if (!(Number(lengthUsed) > 0) && boundTicket.locValue > 0) {
      setLengthUsed(String(boundTicket.locValue));
    }
    if (!jobRef) setJobRef(boundTicket.partNumber || "");
    if (!reason) setReason(`Saw cut ${boundTicket.partNumber}`);
  }, [boundTicket?.id]);

  useEffect(() => {
    if (!ticketId && ticketChoices.length === 1) {
      setTicketId(ticketChoices[0]!.id);
    }
  }, [ticketChoices, ticketId]);

  function lookup() {
    const found = resolveScanCode(code, stockPieces, materialStock);
    if (!found) {
      toast.error(
        "Not on the rack or piece book. Rack stickers start LCMM. Piece stickers start LCM-.",
      );
      return;
    }
    if (found.kind === "piece") {
      toast.message(`Found piece ${found.piece.material} ${found.piece.materialType}`);
    } else {
      toast.message(
        `Found rack ${found.material.material} ${found.material.materialType} · ${found.material.sizeNote || found.material.stockShape}`,
      );
    }
  }

  function submitUse() {
    const nLen = Number(lengthUsed);
    const nQty = Number(qty) || 1;
    if (!(nLen > 0)) {
      toast.error("Enter length used");
      return;
    }
    let spent = "";
    if (piece) {
      const res = consumePiece({
        barcode: code,
        lengthUsed: nLen,
        qty: nQty,
        jobRef,
        reason: reason || "Shop cut",
      });
      if (!res.ok) {
        toast.error(res.error || "Failed");
        return;
      }
      const p = res.piece!;
      spent =
        p.status === "consumed"
          ? `${p.barcode} fully used`
          : `${p.barcode}: ${p.remainingLength}" remaining`;
    } else if (rack) {
      const inches = nLen * nQty;
      const res = inventoryMove({
        itemKind: "material",
        itemId: rack.id,
        kind: "issue",
        qty: inches,
        reason: reason || "Shop cut",
        ref: jobRef || boundTicket?.partNumber || "",
      });
      if (!res.ok) {
        toast.error(res.error || "Failed");
        return;
      }
      spent = `${rack.material} ${rack.sizeNote || ""} · −${inches}" · ${res.balance}" on hand`;
    } else {
      toast.error(
        "Not on the rack or piece book. Scan the sticker on the bar you are cutting.",
      );
      return;
    }

    if (boundTicket && leftoverCut(boundTicket) > 0) {
      const r = recordCutProgress(boundTicket.id, nQty, myName);
      if (r.ok) {
        spent += ` · cut ${r.ticket?.qtyCut}/${r.ticket?.qtyRequested} on ${boundTicket.partNumber}`;
      } else if (r.error) {
        toast.error(r.error);
      }
    }

    toast.success(spent);
    setLastOk(spent);
    setLengthUsed(boundTicket?.locValue ? String(boundTicket.locValue) : "");
  }

  const canDeduct = Boolean(
    (piece && piece.status === "available") ||
      (rack && (rack.onHand || 0) > 0),
  );

  const pinnedTicket = ticketQ
    ? cutTickets.find((t) => t.id === ticketQ)
    : null;

  return (
    <div className="mx-auto max-w-lg space-y-5 pb-10">
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
        <div>
        <h1 className="text-2xl font-semibold tracking-tight flex items-center gap-2">
          <ScanBarcode className="h-6 w-6 text-[var(--color-primary)]" />
          Scan stock
        </h1>
        <p className="text-sm text-[var(--color-muted)] mt-1">
          Scan the sticker on the bar. Rack size labels (LCMM) and piece
          barcodes (LCM-) both work. An open saw ticket for that material
          attaches so the cut is marked.
        </p>
        </div>
        <PageHowTo id="scan-stock" />
      </div>

      {pinnedTicket || boundTicket ? (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">This cut</CardTitle>
            <CardDescription>
              {(boundTicket || pinnedTicket)!.partNumber} ·{" "}
              {cutTicketLabel(boundTicket || pinnedTicket!)}
            </CardDescription>
          </CardHeader>
          <CardContent className="text-sm text-[var(--color-muted)]">
            {(boundTicket || pinnedTicket)!.material}{" "}
            {(boundTicket || pinnedTicket)!.materialType} · left to cut{" "}
            {leftoverCut(boundTicket || pinnedTicket!)}
          </CardContent>
        </Card>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Barcode</CardTitle>
          <CardDescription>
            Phone camera on the rack sticker opens this page with the code
            filled in.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex gap-2">
            <Input
              autoFocus
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="LCMM… or LCM-XXXXXXXX"
              className="font-mono"
              onKeyDown={(e) => {
                if (e.key === "Enter") lookup();
              }}
            />
            <Button variant="secondary" onClick={lookup}>
              Find
            </Button>
          </div>

          {piece ? (
            <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-1 text-sm">
              <div className="flex items-center justify-between gap-2">
                <span className="font-mono font-medium">{piece.barcode}</span>
                <Badge
                  tone={piece.status === "available" ? "success" : "neutral"}
                >
                  {piece.status}
                </Badge>
              </div>
              <div>
                {piece.material} {piece.materialType} · {piece.stockShape}
              </div>
              <div className="text-[var(--color-muted)]">
                {piece.sizeNote || "—"} · {piece.location}
              </div>
              <div className="tabular font-semibold">
                {piece.remainingLength}" remaining of{" "}
                {piece.originalLength}"
              </div>
            </div>
          ) : rack ? (
            <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-1 text-sm">
              <div className="flex items-center justify-between gap-2">
                <span className="font-medium">
                  {rack.material} {rack.materialType}
                </span>
                <Badge tone="success">rack</Badge>
              </div>
              <div className="text-[var(--color-muted)]">
                {rack.stockShape} · {rack.sizeNote || "—"} · {rack.location || "—"}
              </div>
              <div className="tabular font-semibold">
                {rack.onHand} {rack.unit} on hand
              </div>
            </div>
          ) : code.trim() ? (
            <p className="text-sm text-[var(--color-warn)]">
              Not on the rack book or piece book. Rack stickers start LCMM.
              Piece stickers start LCM-.
            </p>
          ) : null}

          {hit && ticketChoices.length > 1 ? (
            <div className="space-y-1.5">
              <Label>Attach to saw ticket</Label>
              <Select
                value={ticketId}
                onChange={(e) => setTicketId(e.target.value)}
              >
                <option value="">— pick the cut —</option>
                {ticketChoices.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.partNumber} · {cutTicketLabel(t)} · {leftoverCut(t)} left
                  </option>
                ))}
              </Select>
            </div>
          ) : hit && ticketChoices.length === 0 && !boundTicket ? (
            <p className="text-xs text-[var(--color-muted)]">
              No open saw ticket for this material. Deduct still works. Request
              cut from the job board if this is for a job.
            </p>
          ) : null}

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Length used (in)</Label>
              <Input
                type="number"
                inputMode="decimal"
                value={lengthUsed}
                onChange={(e) => setLengthUsed(e.target.value)}
                placeholder="24"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Qty (same length)</Label>
              <Input
                type="number"
                value={qty}
                onChange={(e) => setQty(e.target.value)}
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Job / part ref</Label>
            <Input
              value={jobRef}
              onChange={(e) => setJobRef(e.target.value)}
              placeholder="AF-4421"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Note</Label>
            <Input
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Saw cut"
            />
          </div>
          <Button
            className="w-full min-h-12 text-base"
            disabled={!canDeduct}
            onClick={submitUse}
          >
            Deduct from inventory
          </Button>
          {lastOk && (
            <p className="text-sm text-[var(--color-success)] flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4" />
              {lastOk}
            </p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Recent pieces</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          {recentPieces(stockPieces).map((p) => (
            <button
              key={p.id}
              type="button"
              className="w-full text-left rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2"
              onClick={() => setCode(p.barcode)}
            >
              <div className="font-mono text-xs">{p.barcode}</div>
              <div className="text-[var(--color-muted)]">
                {p.material} {p.materialType} · {p.remainingLength}" left
              </div>
            </button>
          ))}
          {stockPieces.length === 0 && (
            <p className="text-[var(--color-muted)]">
              No barcoded pieces. Rack stickers still scan — they hit Material
              on hand.{" "}
              <Link to="/saw" className="text-[var(--color-primary)] underline">
                Open saw
              </Link>
            </p>
          )}
        </CardContent>
      </Card>

      <div className="flex gap-2">
        <Link
          to="/saw"
          className="text-sm text-[var(--color-primary)] underline"
        >
          Saw queue
        </Link>
        <Link
          to="/inventory"
          className="text-sm text-[var(--color-primary)] underline"
        >
          Inventory
        </Link>
        <Link
          to="/labels"
          search={{ ids: "", kind: "materials" }}
          className="text-sm text-[var(--color-primary)] underline"
        >
          Print labels
        </Link>
      </div>
    </div>
  );
}

function recentPieces(stockPieces: { id: string; barcode: string; material: string; materialType: string; remainingLength: number }[]) {
  return stockPieces.slice(0, 12);
}
