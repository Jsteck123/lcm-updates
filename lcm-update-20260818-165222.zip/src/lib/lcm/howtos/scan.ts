import type { PageHowToDoc } from "./types";

export const scanHowTo: PageHowToDoc = {
  id: "scan-stock",
  path: "/scan",
  title: "Scan stock",
  tab: "inventory",
  whatThisPageIs:
    "The phone / saw station for spending stock. Scan the sticker on the bar — rack size labels (LCMM…) and piece barcodes (LCM-) both work. If an open saw ticket matches that material, the cut attaches: length of cut fills in, deduct spends the inches, and the ticket is marked cut. Receiving a vendor PO is what creates piece stickers. Rack labels come from Material on hand → Print.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "A phone camera QR on the sticker can open this page with the code already in the box (?c=). Otherwise tap the barcode field and scan or type. Codes are forced to uppercase.",
        },
        {
          type: "ul",
          items: [
            "Find looks up the code in both books: barcoded pieces (LCM-) and Material on hand rack labels (LCMM). Toast names what it found.",
            "An open saw ticket for that material attaches automatically. Several tickets: pick which cut. None: deduct still works.",
            "Deduct spends inches (length × qty). Piece stickers shorten Remaining. Rack labels Out the Material on hand line. Then the attached ticket is marked cut.",
            "If remaining length hits zero the piece status becomes consumed and you cannot deduct again.",
            "Recent pieces are the last twelve stock pieces in memory — tap one to load its barcode.",
          ],
        },
        {
          type: "note",
          text: "Default note if you leave Note blank is “Shop cut”. Length is inches.",
        },
        {
          type: "warn",
          text: "Deduct from inventory stays disabled until a matching available piece is on screen. A consumed or unknown code will not spend stock.",
        },
      ],
    },
    {
      title: "Barcode card",
      blocks: [
        {
          type: "control",
          name: "Scan stock",
          does: "Page title. Subtitle: scan or type the barcode, enter length used (inches), deduct inventory.",
        },
        {
          type: "control",
          name: "Barcode",
          does: "Card title. Description: phone camera QR opens this page with the code filled in.",
        },
        {
          type: "control",
          name: "LCM-XXXXXXXX",
          does: "Barcode field placeholder. Auto-focus. Enter key runs the same lookup as Find. Value is stored uppercase.",
        },
        {
          type: "control",
          name: "Find",
          does: "Looks up the code. Toast “Found piece …” or “Found rack …”. Error if neither book has it: “Not on the rack or piece book.” Does not deduct.",
        },
        {
          type: "control",
          name: "available",
          does: "Status badge on a found piece that can still be used. Other statuses print as stored (consumed, etc.) with a neutral badge.",
        },
        {
          type: "control",
          name: "No piece matches this code yet.",
          does: "Warning under the field when the code is not a piece barcode and not a rack LCMM label.",
        },
        {
          type: "control",
          name: "Length used (in)",
          does: "Inches you just cut off this bar (or each cut if Qty > 1). Decimal allowed.",
        },
        {
          type: "control",
          name: "Qty (same length)",
          does: "How many cuts of that same length. Default 1. Total deducted length is length × qty.",
        },
        {
          type: "control",
          name: "Job / part ref",
          does: "Optional. What job or part this bar went to (placeholder AF-4421). Stored on the consume.",
        },
        {
          type: "control",
          name: "Note",
          does: "Optional reason. Placeholder “Saw cut”. If you leave it blank the consume is stored as “Shop cut”.",
        },
        {
          type: "control",
          name: "Deduct from inventory",
          does: "Full-width spend button. Disabled until a found piece is status available. Success toast: fully used, or remaining inches. Clears Length used and shows the green last-ok line. Errors if the consume fails.",
        },
      ],
    },
    {
      title: "Recent pieces and links",
      blocks: [
        {
          type: "control",
          name: "Recent pieces",
          does: "List of the newest stock pieces (up to 12). Each row is a button: barcode + material/type + remaining inches. Tap loads that barcode into the field so you can Find / deduct.",
        },
        {
          type: "control",
          name: "No barcoded pieces yet. Receive a PO to create stickers.",
          does: "Empty state. Includes an Open POs link to /po.",
        },
        {
          type: "control",
          name: "Open POs",
          does: "Link inside the empty recent list. Goes to Customer Orders so office can receive and print stickers.",
        },
        {
          type: "control",
          name: "Inventory",
          does: "Footer link to the full inventory screen.",
        },
        {
          type: "control",
          name: "Print labels",
          does: "Footer link to /labels so you can reprint stickers.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Spend a bar from the sticker",
        },
        {
          type: "ol",
          items: [
            "Scan the QR or type the code in the barcode box.",
            "Tap Find (or press Enter) and confirm material, size, and remaining length.",
            "Enter Length used (in) and Qty (same length) if you cut more than one.",
            "Optionally fill Job / part ref and Note.",
            "Tap Deduct from inventory.",
            "Write the new remaining length on the sticker if the bar is still on the rack.",
          ],
        },
        {
          type: "h",
          text: "Re-open a piece you just used",
        },
        {
          type: "ol",
          items: [
            "Under Recent pieces tap the barcode row.",
            "The field fills. Tap Find if you need the details again.",
          ],
        },
      ],
    },
  ],
};
