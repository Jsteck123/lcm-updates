import { normalizeLineFiles } from "./line-files";
import { normalizeOpAssignments } from "./op-slots";
import { estimateMaterialUnits } from "./po-material";
import type {
  JobRun,
  MaterialStock,
  PurchaseOrder,
  PoLine,
  Quote,
  ShopOrder,
  ShopOrderLine,
} from "./types";

export type MaterialKey = string;

export type OrderNeedRow = {
  key: MaterialKey;
  material: string;
  materialType: string;
  stockShape: string;
  onHand: number;
  minQty: number;
  jobDemand: number;
  onOrder: number;
  /** Qty still to buy (same as shortfall) */
  toOrder: number;
  shortfall: number;
  sources: string[];
};

export function materialKey(
  material: string,
  materialType: string,
  stockShape: string,
): MaterialKey {
  return `${(material || "").trim().toLowerCase()}|${(materialType || "").trim().toLowerCase()}|${(stockShape || "").trim().toLowerCase()}`;
}

export function emptyPoLine(
  partial?: Partial<PoLine>,
): PoLine {
  return {
    id: partial?.id || "",
    material: partial?.material || "",
    materialType: partial?.materialType || "",
    stockShape: partial?.stockShape || "Round Stock",
    sizeNote: partial?.sizeNote || "",
    unit: partial?.unit || "pcs",
    qtyOrdered: partial?.qtyOrdered ?? 0,
    qtyReceived: partial?.qtyReceived ?? 0,
    lengthEach: partial?.lengthEach ?? 0,
    unitCost: partial?.unitCost ?? 0,
    partNumber: partial?.partNumber || "",
    jobRef: partial?.jobRef || "",
    notes: partial?.notes || "",
  };
}

export function emptyPurchaseOrder(
  partial?: Partial<PurchaseOrder>,
): PurchaseOrder {
  const now = new Date().toISOString();
  return {
    id: partial?.id || "",
    poNumber: partial?.poNumber || "",
    vendor: partial?.vendor || "",
    date: partial?.date || now.slice(0, 10),
    status: partial?.status || "draft",
    notes: partial?.notes || "",
    lines: partial?.lines || [],
    createdAt: partial?.createdAt || now,
    updatedAt: partial?.updatedAt || now,
    createdBy: partial?.createdBy || "",
  };
}

export function emptyShopOrderLine(
  partial?: Partial<ShopOrderLine>,
): ShopOrderLine {
  const base: ShopOrderLine = {
    id: partial?.id || "",
    itemNo: partial?.itemNo ?? 1,
    partNumber: partial?.partNumber || "",
    description: partial?.description || "",
    revision: partial?.revision || "",
    unitCost: partial?.unitCost ?? 0,
    qty: partial?.qty ?? 1,
    qtyCompleted: partial?.qtyCompleted ?? 0,
    units: partial?.units || "each",
    taxable: partial?.taxable ?? false,
    notes: partial?.notes || "",
    dueDate: partial?.dueDate || "",
    drawingId: partial?.drawingId || "",
    drawingName: partial?.drawingName || "",
    drawingMime: partial?.drawingMime || "",
    drawings: partial?.drawings || (partial?.drawingId
      ? [{ id: partial.drawingId, name: partial.drawingName || "", mime: partial.drawingMime || "" }]
      : []),
    material: partial?.material || "",
    materialType: partial?.materialType || "",
    stockShape: partial?.stockShape || "",
    materialVendor: partial?.materialVendor || "",
    materialNeeded: partial?.materialNeeded ?? 0,
    materialOnHand: partial?.materialOnHand ?? 0,
    materialStockId: partial?.materialStockId || "",
    materialLocation: partial?.materialLocation || "",
    finishedOnHand: partial?.finishedOnHand ?? 0,
    finishedStockId: partial?.finishedStockId || "",
    materialMatch: partial?.materialMatch || "none",
    materialStatus: partial?.materialStatus || "unchecked",
    attentionReason: partial?.attentionReason || "",
    materialReviewed: partial?.materialReviewed ?? false,
    quoteId: partial?.quoteId || "",
    sizeNote: partial?.sizeNote || "",
    dimX: partial?.dimX ?? 0,
    dimY: partial?.dimY ?? 0,
    dimZ: partial?.dimZ ?? 0,
    partLengthEach: partial?.partLengthEach ?? 0,
    rawMaterialLength: partial?.rawMaterialLength ?? 0,
    locAxis: partial?.locAxis || "",
    stockProcess: partial?.stockProcess || "",
    revPdfOk: partial?.revPdfOk ?? false,
    revCadOk: partial?.revCadOk ?? false,
    stockNoted: partial?.stockNoted ?? false,
    cadFileId: partial?.cadFileId || "",
    cadFileName: partial?.cadFileName || "",
    cadFileMime: partial?.cadFileMime || "",
    cadFiles: partial?.cadFiles || (partial?.cadFileId
      ? [{ id: partial.cadFileId, name: partial.cadFileName || "", mime: partial.cadFileMime || "" }]
      : []),
    components: partial?.components || [],
    checkedOutBy: partial?.checkedOutBy || "",
    checkedOutAt: partial?.checkedOutAt || "",
    checkedOutMachine: partial?.checkedOutMachine || "",
    officeAssignedTo: partial?.officeAssignedTo || "",
    officeAssignedMachine: partial?.officeAssignedMachine || "",
    officeAssignedAt: partial?.officeAssignedAt || "",
    officeAssignNotes: partial?.officeAssignNotes || "",
    opAssignments: normalizeOpAssignments(partial?.opAssignments),
    boardHidden: Boolean(partial?.boardHidden),
    readyForPack: partial?.readyForPack ?? false,
    readyForPackAt: partial?.readyForPackAt || "",
    readyForPackBy: partial?.readyForPackBy || "",
    linePacked: partial?.linePacked ?? false,
    linePackedAt: partial?.linePackedAt || "",
    linePackedBy: partial?.linePackedBy || "",
    lineStatus: partial?.lineStatus === "cancelled" ? "cancelled" : "active",
    cancelledAt: partial?.cancelledAt || "",
    cancelledReason: partial?.cancelledReason || "",
  };
  return { ...base, ...normalizeLineFiles({ ...base, ...partial }) };
}

export function emptyShopOrder(partial?: Partial<ShopOrder>): ShopOrder {
  const now = new Date().toISOString();
  return {
    id: partial?.id || "",
    poNumber: partial?.poNumber || "",
    poRevision: partial?.poRevision || "",
    soNumber: partial?.soNumber || "",
    customer: partial?.customer || "",
    customerAddress: partial?.customerAddress || "",
    customerPhone: partial?.customerPhone || "",
    shipToName: partial?.shipToName || "",
    shipToAddress: partial?.shipToAddress || "",
    attn: partial?.attn || "",
    buyer: partial?.buyer || "",
    techContact: partial?.techContact || "",
    account: partial?.account || "",
    dateRequired: partial?.dateRequired || "",
    fob: partial?.fob || "Origin",
    shippingMethod: partial?.shippingMethod || "",
    terms: partial?.terms || "N30",
    date: partial?.date || now.slice(0, 10),
    dueDate: partial?.dueDate || "",
    rating: partial?.rating || "",
    shippingAcct: partial?.shippingAcct || "",
    status: partial?.status || "open",
    notes: partial?.notes || "",
    footerNote:
      partial?.footerNote ||
      "PLEASE CHECK PO FOR CURRENT REVISIONS PRIOR TO CUTTING/MACHINING PARTS",
    lines: partial?.lines || [],
    sourceFileId: partial?.sourceFileId || "",
    sourceFileName: partial?.sourceFileName || "",
    sourceFileMime: partial?.sourceFileMime || "",
    priorPoFiles: Array.isArray(partial?.priorPoFiles)
      ? partial!.priorPoFiles!
      : [],
    packStatus: partial?.packStatus || "pending",
    packedBy: partial?.packedBy || "",
    packedAt: partial?.packedAt || "",
    verifiedBy: partial?.verifiedBy || "",
    verifiedAt: partial?.verifiedAt || "",
    deliveredAt: partial?.deliveredAt || "",
    deliveredBy: partial?.deliveredBy || "",
    signedSlipFileId: partial?.signedSlipFileId || "",
    signedSlipName: partial?.signedSlipName || "",
    signedSlipMime: partial?.signedSlipMime || "",
    invoicedInQb: partial?.invoicedInQb ?? false,
    invoicedAt: partial?.invoicedAt || "",
    paymentReceived: partial?.paymentReceived ?? false,
    paymentReceivedAt: partial?.paymentReceivedAt || "",
    closedAt: partial?.closedAt || "",
    createdAt: partial?.createdAt || now,
    updatedAt: partial?.updatedAt || now,
    createdBy: partial?.createdBy || "",
  };
}

export function poLineOpenQty(line: PoLine): number {
  return Math.max(0, (line.qtyOrdered || 0) - (line.qtyReceived || 0));
}

export function shopLineOpenQty(line: ShopOrderLine): number {
  if (line.lineStatus === "cancelled") return 0;
  return Math.max(0, (line.qty || 0) - (line.qtyCompleted || 0));
}

export function shopLineExtension(line: ShopOrderLine): number {
  return (Number(line.unitCost) || 0) * (Number(line.qty) || 0);
}

export function shopOrderSubtotal(order: ShopOrder): number {
  return (order.lines || [])
    .filter((l) => l.lineStatus !== "cancelled")
    .reduce((s, l) => s + shopLineExtension(l), 0);
}

export function derivePoStatus(
  po: PurchaseOrder,
): PurchaseOrder["status"] {
  if (po.status === "cancelled") return "cancelled";
  const lines = po.lines || [];
  if (!lines.length) return po.status === "ordered" ? "ordered" : "draft";
  const anyRecv = lines.some((l) => (l.qtyReceived || 0) > 0);
  const allRecv = lines.every(
    (l) => (l.qtyReceived || 0) >= (l.qtyOrdered || 0) && (l.qtyOrdered || 0) > 0,
  );
  if (allRecv && lines.some((l) => (l.qtyOrdered || 0) > 0)) return "received";
  if (anyRecv) return "partial";
  if (po.status === "ordered" || po.status === "partial") return po.status;
  return po.status === "draft" ? "draft" : po.status || "ordered";
}

export function deriveShopOrderStatus(order: ShopOrder): ShopOrder["status"] {
  if (order.status === "cancelled") return "cancelled";
  if (order.status === "draft") return "draft";
  const lines = (order.lines || []).filter((l) => l.lineStatus !== "cancelled");
  if (!lines.length) {
    // All lines cancelled → stay open/cancelled? Prefer open so office can still see it.
    return order.status === "open" || order.status === "in_progress"
      ? order.status
      : order.status || "open";
  }
  const opens = lines.map(shopLineOpenQty);
  const anyDone = lines.some((l) => (l.qtyCompleted || 0) > 0);
  const allDone = opens.every((o) => o <= 0) && lines.some((l) => (l.qty || 0) > 0);
  if (allDone) return "complete";
  if (anyDone || order.status === "in_progress") return "in_progress";
  return order.status === "complete" ? "open" : order.status || "open";
}

export function nextPoNumber(existing: PurchaseOrder[]): string {
  const year = new Date().getFullYear().toString().slice(-2);
  let max = 0;
  for (const p of existing || []) {
    const m = String(p.poNumber || "").match(/PO-?(\d{2})-?(\d+)/i);
    if (m) {
      const n = Number(m[2]);
      if (Number.isFinite(n) && n > max) max = n;
    }
  }
  const next = String(max + 1).padStart(4, "0");
  return `PO-${year}-${next}`;
}

/** Simple barcode from id (Code128-friendly alnum) */
export function generateBarcode(id: string): string {
  const clean = String(id || "")
    .replace(/[^a-zA-Z0-9]/g, "")
    .toUpperCase()
    .slice(0, 12);
  const stamp = Date.now().toString(36).toUpperCase().slice(-6);
  return `LCM${clean.slice(0, 8)}${stamp}`.slice(0, 20);
}

export function findOrCreateStockId(
  stock: MaterialStock[],
  line: {
    material: string;
    materialType: string;
    stockShape: string;
    sizeNote?: string;
    unit?: MaterialStock["unit"];
    vendor?: string;
    location?: string;
    costPerUnit?: number;
    unitCost?: number;
    lengthEach?: number;
  },
  newId: string,
): { stockId: string; created?: MaterialStock } {
  const m = (line.material || "").trim().toLowerCase();
  const t = (line.materialType || "").trim().toLowerCase();
  const s = (line.stockShape || "").trim().toLowerCase();
  const size = (line.sizeNote || "").trim().toLowerCase();
  const hit = (stock || []).find(
    (x) =>
      (x.material || "").trim().toLowerCase() === m &&
      (x.materialType || "").trim().toLowerCase() === t &&
      (x.stockShape || "").trim().toLowerCase() === s &&
      (!size || (x.sizeNote || "").trim().toLowerCase() === size),
  );
  if (hit) return { stockId: hit.id };

  const created: MaterialStock = {
    id: newId,
    material: line.material || "",
    materialType: line.materialType || "",
    stockShape: line.stockShape || "Round Stock",
    sizeNote: line.sizeNote || "",
    dimX: 0,
    dimY: 0,
    dimZ: line.lengthEach || 0,
    unit: line.unit || "pcs",
    onHand: 0,
    minQty: 0,
    location: line.location || "",
    vendor: line.vendor || "",
    costPerUnit: line.costPerUnit ?? line.unitCost ?? 0,
    notes: "",
    updatedAt: new Date().toISOString(),
  };
  return { stockId: created.id, created };
}

/**
 * Material shortfalls from open shop orders + jobs vs on-hand and open material buys.
 */
export function computeOrderNeeds(opts: {
  materialStock: MaterialStock[];
  purchaseOrders: PurchaseOrder[];
  shopOrders?: ShopOrder[];
  jobs: JobRun[];
  quotes: Quote[];
}): OrderNeedRow[] {
  const map = new Map<
    MaterialKey,
    {
      material: string;
      materialType: string;
      stockShape: string;
      onHand: number;
      minQty: number;
      jobDemand: number;
      onOrder: number;
      sources: Set<string>;
    }
  >();

  const ensure = (
    material: string,
    materialType: string,
    stockShape: string,
  ) => {
    const key = materialKey(material, materialType, stockShape);
    let row = map.get(key);
    if (!row) {
      row = {
        material,
        materialType,
        stockShape,
        onHand: 0,
        minQty: 0,
        jobDemand: 0,
        onOrder: 0,
        sources: new Set(),
      };
      map.set(key, row);
    }
    return row;
  };

  for (const s of opts.materialStock || []) {
    const row = ensure(s.material, s.materialType, s.stockShape);
    row.onHand += s.onHand || 0;
    row.minQty = Math.max(row.minQty, s.minQty || 0);
  }

  for (const po of opts.purchaseOrders || []) {
    if (po.status === "cancelled" || po.status === "received") continue;
    for (const line of po.lines || []) {
      const open = poLineOpenQty(line);
      if (open <= 0) continue;
      const row = ensure(line.material, line.materialType, line.stockShape);
      row.onOrder += open;
      row.sources.add(`Mat ${po.poNumber}`);
    }
  }

  const quoteByPn = new Map<string, Quote>();
  for (const q of opts.quotes || []) {
    const pn = (q.partNumber || "").trim().toUpperCase();
    if (!pn) continue;
    const prev = quoteByPn.get(pn);
    if (!prev || new Date(q.date).getTime() > new Date(prev.date).getTime()) {
      quoteByPn.set(pn, q);
    }
  }

  const demandFromPart = (
    partNumber: string,
    openQty: number,
    source: string,
    line?: ShopOrderLine,
  ) => {
    if (openQty <= 0) return;
    // Prefer material already on the shop line
    if (line?.material) {
      let units = line.materialNeeded || 0;
      if (!units) {
        units = estimateMaterialUnits({
          orderQty: openQty,
          partLengthEach: line.partLengthEach || 0,
          rawMaterialLength: line.rawMaterialLength || 0,
          stockShape: line.stockShape,
        }).needed;
      }
      if (!units) units = openQty;
      const row = ensure(line.material, line.materialType, line.stockShape);
      row.jobDemand += units;
      row.sources.add(source);
      return;
    }
    const q = quoteByPn.get((partNumber || "").trim().toUpperCase());
    if (!q || !q.material) return;
    let units = estimateMaterialUnits({
      orderQty: openQty,
      partLengthEach: q.partLengthEach || 0,
      rawMaterialLength: q.rawMaterialLength || 0,
      stockShape: q.stockShape,
    }).needed;
    if (!units) units = openQty;
    const row = ensure(q.material, q.materialType, q.stockShape);
    row.jobDemand += units;
    row.sources.add(source);
  };

  for (const order of opts.shopOrders || []) {
    if (
      order.status === "cancelled" ||
      order.status === "complete" ||
      order.status === "draft"
    ) {
      continue;
    }
    for (const line of order.lines || []) {
      const open = shopLineOpenQty(line);
      demandFromPart(
        line.partNumber,
        open,
        `SO ${order.poNumber || order.id.slice(0, 6)}`,
        line,
      );
    }
  }

  for (const job of opts.jobs || []) {
    if (job.status === "Completed" || job.endTime) continue;
    const open = Math.max(
      0,
      (job.quantity || 0) - (job.quantityCompleted || 0),
    );
    demandFromPart(job.partNumber, open, `Job ${job.partNumber}`);
  }

  // Min stock also creates demand
  for (const row of map.values()) {
    if (row.minQty > 0 && row.onHand < row.minQty) {
      row.jobDemand = Math.max(row.jobDemand, row.minQty);
      row.sources.add("Min stock");
    }
  }

  const out: OrderNeedRow[] = [];
  for (const row of map.values()) {
    const shortfall = Math.max(
      0,
      row.jobDemand + row.minQty * 0 - row.onHand - row.onOrder,
    );
    // shortfall vs demand only (min already folded above loosely)
    const need = Math.max(0, row.jobDemand - row.onHand - row.onOrder);
    if (row.jobDemand <= 0 && row.onHand > row.minQty) continue;
    out.push({
      key: materialKey(row.material, row.materialType, row.stockShape),
      material: row.material,
      materialType: row.materialType,
      stockShape: row.stockShape,
      onHand: row.onHand,
      minQty: row.minQty,
      jobDemand: row.jobDemand,
      onOrder: row.onOrder,
      toOrder: need,
      shortfall: need,
      sources: [...row.sources],
    });
  }

  return out.sort((a, b) => b.shortfall - a.shortfall || a.material.localeCompare(b.material));
}


/** True when line is still on the live customer order (not dropped by a PO rev). */
export function isActiveShopLine(line: Pick<ShopOrderLine, "lineStatus"> | undefined | null): boolean {
  return !line || line.lineStatus !== "cancelled";
}

/** Count of live (non-cancelled) lines on a customer PO. */
export function activeShopLineCount(order: Pick<ShopOrder, "lines">): number {
  return (order.lines || []).filter((l) => isActiveShopLine(l)).length;
}
