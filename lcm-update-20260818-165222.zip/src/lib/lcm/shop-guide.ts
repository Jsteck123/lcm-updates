import type { AppTab } from "./types";

export type GuideAudience = "all" | "floor" | "admin";

export type GuideStep = {
  title: string;
  body: string[];
};

export type GuideChapter = {
  id: string;
  title: string;
  path?: string;
  audience?: GuideAudience;
  tab?: AppTab;
  intro: string;
  steps: GuideStep[];
  notes?: string[];
};

export type GuideSection = {
  id: string;
  title: string;
  blurb: string;
  audience?: GuideAudience;
  chapters: GuideChapter[];
};

export const SHOP_GUIDE: GuideSection[] = [
  {
    id: "start",
    title: "Getting started",
    blurb: "How the shop computer works, who you are, and what the colors mean.",
    chapters: [
      {
        id: "what-lcm-is",
        title: "What this system is",
        path: "/",
        intro:
          "LCM is the shop’s shared book: jobs, timers, stock, labels, packing, and (for office) quotes. One host PC holds the database. Every other computer and phone on the shop network opens the same live book.",
        steps: [
          {
            title: "One shop, one book",
            body: [
              "Do not keep a private copy. If you type on this screen, everyone else sees it after a moment.",
              "The host PC must stay on and unlocked for the shop. If the host is off, other screens cannot save.",
            ],
          },
          {
            title: "Two kinds of login",
            body: [
              "Shop / operator — Job Board, machines, saw, inventory, packing. No prices, markups, or bonus dollars.",
              "Office / admin — everything the floor has, plus Quoting, Parts & Quotes, Email, Reports, and Settings.",
            ],
          },
          {
            title: "The usual path of a job",
            body: [
              "Customer PO lands on Customer Orders.",
              "Office matches material, checks the drawing rev, and releases the line.",
              "The line shows on the Job Board (soonest due first).",
              "You take one job, load it on a machine, run Setup then Runtime, and complete it.",
              "It goes to Ship Calendar as Ready for pack. Pack, verify, deliver, attach the signed slip.",
            ],
          },
        ],
        notes: [
          "Paper travelers can still ride with the part until the floor is comfortable without them.",
        ],
      },
      {
        id: "sign-in",
        title: "Sign in and switch user",
        path: "/",
        intro:
          "Every station has a person signed in. Timers, cuts, and audit log use that name.",
        steps: [
          {
            title: "See who is signed in",
            body: [
              "Look at the bottom of the left sidebar. Your name is there.",
            ],
          },
          {
            title: "Switch to yourself",
            body: [
              "Tap Switch user (or the name) at the bottom of the sidebar.",
              "Pick your name.",
              "If the next person is office / admin, the station will ask for that PIN. Shop logins usually do not.",
            ],
          },
          {
            title: "If a tab is missing",
            body: [
              "The sidebar only shows tabs your login is allowed to use.",
              "Ask the office to turn the tab on in Settings → Operators if you need it.",
            ],
          },
          {
            title: "Unlock this PC (first time on a station)",
            body: [
              "The first time a computer talks to the shop host, it may ask you to unlock.",
              "An admin enters the shop PIN. After that, this PC can print labels and save to the host.",
            ],
          },
        ],
      },
      {
        id: "colors",
        title: "Status colors",
        path: "/board",
        intro:
          "The same colors are used on the Job Board, Ship Calendar, floor, inventory, and orders. The legend sits at the bottom of the sidebar.",
        steps: [
          {
            title: "Read the badge, then act",
            body: [
              "Hold (amber) — blocked. Rev or stock not confirmed, paused, or waiting on pack.",
              "Open (green) — available / released / material OK. You can take this job.",
              "Due soon — due within about 2 days. Work these before later jobs.",
              "Overdue (red) — past the due date. These go first unless the office says otherwise.",
              "Active (blue) — someone has it, a timer is running, or it is packed on the cart.",
              "Ready (teal) — next step is waiting (usually pack or ship).",
              "Done (deep green) — closed.",
              "Problem (red) — out of stock or material short. Do not start until the office clears it.",
            ],
          },
        ],
      },
      {
        id: "chat",
        title: "Shop chat",
        path: "/",
        intro:
          "Bottom-right bubble. Shop-only — it does not go to the public internet.",
        steps: [
          {
            title: "Open chat",
            body: [
              "Tap Chat in the bottom-right corner.",
              "A yellow badge means unread messages. You do not have to open chat to see that someone pinged the shop.",
            ],
          },
          {
            title: "Shop channel vs a person",
            body: [
              "Shop channel is the floor bullhorn — tool requests, “who has the ½\" end mill,” job questions.",
              "Pick a name for a direct message when it is only for that person.",
            ],
          },
        ],
      },
      {
        id: "updates",
        title: "App updates and Refresh",
        path: "/settings",
        audience: "all",
        intro:
          "Office installs a program zip. Your screen does not wipe shop data.",
        steps: [
          {
            title: "When you see a yellow Refresh banner",
            body: [
              "Finish or save any form you are in the middle of.",
              "Running timers are safe. Tap Refresh.",
              "You get the new screens; jobs and inventory stay.",
            ],
          },
          {
            title: "How office installs an update (admin)",
            body: [
              "Settings — tap Update app (titles only until you tap).",
              "Choose the zip they were given (program only — not a data backup).",
              "Wait for success, then Restart LCM on the host if the screen asks.",
              "Floor stations refresh when the yellow banner appears.",
            ],
          },
        ],
      },
    ],
  },
  {
    id: "floor-jobs",
    title: "Jobs on the floor",
    blurb: "Take work, run machines, cut stock, finish the job.",
    chapters: [
      {
        id: "dashboard",
        title: "Dashboard",
        path: "/",
        tab: "dashboard",
        intro:
          "Home screen. What needs eyes, what is live on the floor, and (for you) the job you are running.",
        steps: [
          {
            title: "Start here at the beginning of a shift",
            body: [
              "Open Dashboard from the top of the sidebar.",
              "Scan the flags: open work, material problems, machines that are live or idle.",
            ],
          },
          {
            title: "Jump to the work",
            body: [
              "Need a job? Open Job Board.",
              "Already have a machine loaded? Open Shop Floor or Active Jobs.",
              "Packing today? Open Ship Calendar.",
            ],
          },
        ],
      },
      {
        id: "job-board",
        title: "Job Board",
        path: "/board",
        tab: "board",
        intro:
          "The digital wall board. Each card is one PO line (one part / rev / qty), not the whole customer PO. Soonest due is first.",
        steps: [
          {
            title: "Read a card",
            body: [
              "Part number, revision, quantity, customer, due date.",
              "Hold = office has not released it. Do not take it.",
              "Open / Available = you may take it.",
              "A name on the card means that person already has it. Leave it unless you are covering for them.",
              "OP1 / OP2 on a card means that job uses more than one machine. Take only the OP you run. Wait OPn means the previous OP is not done — you can still set up.",
            ],
          },
          {
            title: "Filter the board",
            body: [
              "Available Jobs — only work nobody has taken.",
              "My Jobs — only cards you took.",
              "Active Jobs — machines that are loaded and running (also its own tab).",
            ],
          },
          {
            title: "Take one job",
            body: [
              "Open the card.",
              "Tap Take job. Optionally pick a machine now, or pick it when you load.",
              "Only take one job you will actually run. Other lines on that same PO stay on the board for someone else.",
            ],
          },
          {
            title: "Load it on a machine",
            body: [
              "After Take job, tap Load (or open Shop Floor → that machine).",
              "Confirm part #, rev, and qty.",
              "The job leaves “available” and shows on Active Jobs and that machine.",
            ],
          },
          {
            title: "Paper and files from the card",
            body: [
              "Shop WO — traveler for the tote.",
              "Labels — PO · P/N · Rev · Qty for the parts.",
              "Drawing — opens the attached PDF. If there is no drawing, tell the office before you cut.",
            ],
          },
          {
            title: "Return a job you are not running",
            body: [
              "Open the card → Return job.",
              "It goes back to Available Jobs and comes off Load Lanes. Do this if you took the wrong card or you are leaving early. Clear the machine separately if it is still loaded.",
            ],
          },
          {
            title: "Finish from the board",
            body: [
              "Prefer Complete on the machine page so time is saved.",
              "Done / pack on the board also sends the line to packing if the office set it up that way.",
            ],
          },
        ],
        notes: [
          "If every card is Hold, the office has not released work — ping them in chat, do not guess the rev.",
        ],
      },
      {
        id: "active-jobs",
        title: "Active Jobs",
        path: "/active",
        tab: "active",
        intro:
          "Only jobs you have loaded on a machine. Taking a card on the board is not enough — you must Load it.",
        steps: [
          {
            title: "Open your running work",
            body: [
              "Sidebar → Active Jobs.",
              "You should see each machine you have loaded.",
            ],
          },
          {
            title: "Switch between two machines",
            body: [
              "Open one machine.",
              "Use the job pills on that page to hop to the other without going back to the board.",
            ],
          },
          {
            title: "If the list is empty",
            body: [
              "You took a job but never loaded a machine. Go to Job Board → My Jobs → Load, or pick a machine at the top of Active Jobs.",
            ],
          },
        ],
      },
      {
        id: "shop-floor",
        title: "Shop Floor (machines and timers)",
        path: "/machines",
        tab: "machines",
        intro:
          "This is the machine. Setup time and runtime are how the shop knows how long the job really took.",
        steps: [
          {
            title: "Open the machine",
            body: [
              "Sidebar → Shop Floor.",
              "Tap the machine you are standing at.",
              "Cards show Live, Paused, On job, or Idle.",
            ],
          },
          {
            title: "Load the job on this machine",
            body: [
              "If you already took it on the Job Board, it may be waiting to load.",
              "Otherwise type or pick part # / rev / qty and load.",
              "Wrong part? Unload / return before you start the clock.",
            ],
          },
          {
            title: "Run Setup",
            body: [
              "Tap Start on Setup when you begin indicating, tooling, and first-article.",
              "Stop Setup when the machine is ready to make chips for real.",
              "Do not leave Setup running through the whole lot.",
            ],
          },
          {
            title: "Run Runtime",
            body: [
              "Start Runtime when you begin the production lot.",
              "Pause if you walk away, wait on inspection, or the machine is down.",
              "Add a downtime / pause reason when the screen asks — that keeps bonus and reports honest.",
            ],
          },
          {
            title: "Two vises, one cycle",
            body: [
              "If vise 1 is OP1 and vise 2 is OP2 of the same part (or a nest pair), check Two vises, one cycle on the station.",
              "One Setup, then one Runtime. Do not start a second op timer.",
              "Tap Good so far for the pieces that finish (the OP2 vise), not both vises added together.",
              "Leave the clock running while you reload the fixture. Pause for lunch.",
            ],
          },
          {
            title: "Soft jaws or extra tooling",
            body: [
              "Use Soft jaws / other timer only when you are making jaws or a special tool.",
              "That time is not Setup and not Runtime. Office can bill it as its own line.",
            ],
          },
          {
            title: "Notes while it runs",
            body: [
              "Job details and Notes collapse so Start / Stop stay big.",
              "Open Notes to write a problem, a tool that died, or a size that was short.",
            ],
          },
          {
            title: "Complete the job",
            body: [
              "Stop the timer first.",
              "Tap Complete job.",
              "Matching Customer Order lines flip to Ready for pack.",
              "The machine goes Idle. Take the next job from the board.",
            ],
          },
        ],
        notes: [
          "If you forget to stop the timer overnight, tell the office — they can correct time. Do not “make it look right” by deleting the job.",
        ],
      },
      {
        id: "saw",
        title: "Saw / Cut queue",
        path: "/saw",
        tab: "saw",
        intro:
          "Cut tickets from the floor (CAD / job sizes). Mills can start before the full qty is sawed.",
        steps: [
          {
            title: "See what to cut",
            body: [
              "Sidebar → Saw / Cut queue.",
              "Active = still open. All = including finished / skipped.",
              "Soonest due is first.",
            ],
          },
          {
            title: "Print the ticket",
            body: [
              "Open the ticket → print the sheet for the saw bench.",
              "It shows size, length of cut, qty, and who asked.",
            ],
          },
          {
            title: "Mark blanks as they come off",
            body: [
              "After each blank (or a handful), type how many you just cut.",
              "Tap the mark-cut control.",
              "Qty cut goes up. Available for the mill goes up the same amount. You do not have to finish the whole lot before they start.",
            ],
          },
          {
            title: "Skip or cancel",
            body: [
              "Skip if this ticket is not needed (wrong size, job pulled).",
              "Cancel if it was created by mistake.",
              "Say so in chat if a mill is waiting on those blanks.",
            ],
          },
        ],
      },
      {
        id: "scan-cut",
        title: "Scan a bar and cut length",
        path: "/scan",
        tab: "inventory",
        intro:
          "Barcoded pieces are individual bars. Scanning deducts inches from that bar and from material on hand.",
        steps: [
          {
            title: "Get the barcode on the screen",
            body: [
              "Phone camera on the sticker QR opens Scan with the code filled in.",
              "Or type / paste the code (LCM…) and tap Find.",
            ],
          },
          {
            title: "Confirm you have the right bar",
            body: [
              "Material, type, size, location, and remaining length must match the bar in your hand.",
              "Wrong code? You are on the wrong sticker — stop.",
            ],
          },
          {
            title: "Enter what you used",
            body: [
              "Length used in inches (the cut plus drop you are charging to the job).",
              "Optional job / reason.",
              "Save. Remaining length drops. If it hits zero, the piece is consumed.",
            ],
          },
        ],
        notes: [
          "Material on hand (the 63 sizes) is the rack book. Barcoded pieces are only bars that were received with stickers. Most rack material will not have a piece row until you receive a PO that way.",
        ],
      },
    ],
  },
  {
    id: "inventory-labels",
    title: "Inventory and labels",
    blurb: "What is on the rack, how to buy, and how to print stickers.",
    chapters: [
      {
        id: "inventory-tabs",
        title: "Inventory / Buy — the tabs",
        path: "/inventory",
        tab: "inventory",
        intro:
          "This is the rack book. Low stock is amber. Zero is red. It is not the same list as Barcoded pieces.",
        steps: [
          {
            title: "Material stock",
            body: [
              "Every size you keep: material, type / grade, shape, size, on hand, min, location, vendor, value.",
              "Filter by column or type in the search (4×2 finds 2×4; .75 and 3/4 match; the odd leftover is the cut).",
              "Low only hides everything that is still above min.",
            ],
          },
          {
            title: "In, Out, Edit, Delete",
            body: [
              "In — you put more on the rack (found a bar, vendor drop-off without a PO).",
              "Out — you used it and are not scanning a piece barcode.",
              "Edit — fix size, location, min, vendor, cost.",
              "Delete — removes the row. Use only if the size should not exist. Confirm in the dialog.",
            ],
          },
          {
            title: "Add a new size",
            body: [
              "Use the add / new material control on this tab.",
              "Fill material, type, shape, then size. Shape drives whether you enter dia or X × Y.",
              "Set min so Low lights up before you run out.",
              "Save. It now shows in Customer Orders material match.",
            ],
          },
          {
            title: "Parts & hardware",
            body: [
              "Finished parts, hardware, inserts, fixtures — counted in pieces, not inches.",
              "Second-quality / blemish can carry a short UIN and a defect note.",
            ],
          },
          {
            title: "Barcoded pieces",
            body: [
              "Created only when a PO line is received — one barcode per bar.",
              "Use these to scan-cut length.",
              "If a receive was a test, Remove or Remove all pieces. That does not change Material on hand.",
            ],
          },
          {
            title: "Order needs, Vendor RFQs, Material buys",
            body: [
              "Order needs — what jobs are short.",
              "Vendor RFQs — ask vendors for price; award a bid.",
              "Material buys — turn an award into stock on the rack and (if you receive qty) barcodes.",
            ],
          },
          {
            title: "History",
            body: [
              "Every in / out / receive / adjust with who and why.",
              "Use this when a count looks wrong.",
            ],
          },
        ],
      },
      {
        id: "print-labels",
        title: "Print stock labels (QL-810W)",
        path: "/labels",
        tab: "inventory",
        intro:
          "Stickers are 1.1\" × 0.6\" DK-2210 continuous tape. Wi-Fi to the Brother QL-810W. Same layout as the sample.",
        steps: [
          {
            title: "One-time printer setup",
            body: [
              "Put DK-2210 1.1\" continuous tape in the QL-810W. Close the lid until it clicks.",
              "Printer on the shop Wi-Fi, same network as the host PC.",
              "Open Sample label (Inventory → Sample label, or How to use → this chapter’s Open link).",
              "Set the printer’s Wi-Fi address if it is empty. Discover / pick the QL if the shop host found it.",
              "Print one sample. You want QR on the tape, cuts on the 0.6\" sides of the QR, type under it: code, material, size like (4\") or (2\" x 4\").",
            ],
          },
          {
            title: "Print the rack (materials)",
            body: [
              "Inventory → Print labels.",
              "You should see Materials selected — one sticker per material that has on-hand qty.",
              "Size line is short on purpose: (4\") not (4\" dia); (2\" x 2\") or (2\" x 4\") for square / rect / tube.",
              "Tap Print. Stand at the printer. If the light blinks, tape or lid is wrong — do not keep sending.",
            ],
          },
          {
            title: "Print individual bars (pieces)",
            body: [
              "On the labels page tap Pieces, or from Barcoded pieces tap Label / Print all available labels.",
              "Only bars that were received with a barcode print here.",
            ],
          },
          {
            title: "If print fails",
            body: [
              "Unlock this PC if the app asks (admin PIN).",
              "Confirm the Wi-Fi address on Sample label.",
              "Power light blinking = printer rejected the job (wrong tape, cover, or jam). Fix the printer, then try one sample.",
            ],
          },
        ],
        notes: [
          "Do not use Windows Print / Paint. LCM talks to the printer itself over Wi-Fi.",
        ],
      },
    ],
  },
  {
    id: "orders-ship",
    title: "Orders, packing, and shipping",
    blurb: "Work coming in, who runs it, and what leaves on Friday.",
    chapters: [
      {
        id: "customer-orders",
        title: "Customer Orders",
        path: "/po",
        tab: "po",
        intro:
          "Customer POs coming into the shop — not vendor metal buys. Shop logins do not see prices.",
        steps: [
          {
            title: "Find the order",
            body: [
              "Sidebar → Customer Orders.",
              "Open the customer PO. You see PO #, dates, rating, and lines.",
              "The PDF (if attached) is the full document — use it to check rev and qty.",
            ],
          },
          {
            title: "Match material on each line",
            body: [
              "Expand the line.",
              "Set stock shape and size so it matches a row in Material on hand.",
              "A ? means it is not matched. Fix every ? before release.",
            ],
          },
          {
            title: "Release to the Job Board",
            body: [
              "Checks: PDF rev matches the line, stock size is noted, CAD rev if a CAD file is attached.",
              "Until those pass, the line stays Hold.",
              "Release. The line appears on the Job Board by due date.",
            ],
          },
          {
            title: "If you are short material",
            body: [
              "The line flags Problem / short.",
              "Office uses Order needs / RFQ / Material buys. Do not release and hope.",
            ],
          },
          {
            title: "Delete an order",
            body: [
              "Use the in-app delete dialog — not the browser back button.",
              "Only office should delete a live customer PO.",
            ],
          },
        ],
      },
      {
        id: "assign-queue",
        title: "Assign Queue",
        path: "/assign",
        tab: "assign",
        intro:
          "Office / lead hands out released parts while looking at the drawing.",
        steps: [
          {
            title: "Open a part",
            body: [
              "Click the part. The drawing goes full screen. The assign bar is at the bottom.",
            ],
          },
          {
            title: "Assign it",
            body: [
              "Choose operator (required).",
              "Choose machine if you already know which one (optional). Multi-machine quotes show one row per OP — assign OP1 to the lathe person, OP2 to the mill.",
              "Assign & next puts that OP on that person’s Job Board (My Jobs) and on their machine queue if you picked a machine. The next OP on the same part stays open if it is still waiting.",
            ],
          },
          {
            title: "Work down the list",
            body: [
              "Assign & next jumps to the next part so you can clear the pile in one sitting.",
            ],
          },
        ],
      },
      {
        id: "load-lanes",
        title: "Load lanes",
        path: "/lanes",
        tab: "lanes",
        intro:
          "Office lookahead — who is stacked through which day, and where a rush might fit. Quoted hours, not a promised start.",
        steps: [
          {
            title: "Read the lanes",
            body: [
              "Each person (or machine) is a row. Blocks are quote setup + run × leftover qty, soonest due first.",
              "Blue is on the machine. Green is assigned. Amber is due in two days. Red means even on quote it misses the ship date.",
            ],
          },
          {
            title: "Find a hole",
            body: [
              "Type the rush hours, or a P/N from the quote book.",
              "First hole is the first leftover day that fits — quoted, on pace, not a promise.",
              "Then assign the usual way. This page does not hand the job out.",
            ],
          },
        ],
      },
      {
        id: "ship-calendar",
        title: "Ship Calendar",
        path: "/calendar",
        tab: "calendar",
        intro:
          "What ships when. This replaces the Friday post-it board.",
        steps: [
          {
            title: "Read the month",
            body: [
              "Each day shows PO #s due that day. Tap a day for lines and quantities.",
              "Friday delivery run strip = this week’s truck — pack Thursday / Friday.",
            ],
          },
          {
            title: "Filter Ready for pack",
            body: [
              "Turn on Ready for pack only to hide jobs still on a machine.",
            ],
          },
          {
            title: "Print paper for the carton",
            body: [
              "Packing slip — what the customer sees.",
              "Ship WO — shop copy, no prices.",
              "Labels — box / part labels.",
            ],
          },
          {
            title: "Shop packed",
            body: [
              "When the carton is closed and on the cart, mark Shop packed.",
            ],
          },
          {
            title: "Office verified",
            body: [
              "Office double-checks qty and part against the slip, then marks Office verified.",
            ],
          },
          {
            title: "After the truck",
            body: [
              "Mark Delivered.",
              "Attach the signed packing slip when the driver brings it back.",
            ],
          },
        ],
      },
      {
        id: "job-history",
        title: "Job History",
        path: "/jobs",
        tab: "jobs",
        intro: "Finished runs — who ran what, setup vs runtime, notes.",
        steps: [
          {
            title: "Look up a past run",
            body: [
              "Sidebar → Job History.",
              "Search part number or date.",
              "Open a card to see times and notes. Office uses this before they requote.",
            ],
          },
        ],
      },
      {
        id: "feedback",
        title: "Feedback",
        path: "/feedback",
        tab: "feedback",
        intro: "Something broken or an idea for the floor. This goes to the people building the system.",
        steps: [
          {
            title: "Send it",
            body: [
              "Sidebar → Feedback.",
              "Short title, then what happened (which screen, what you tapped, what you expected).",
              "A photo or screenshot helps. Submit.",
            ],
          },
        ],
      },
    ],
  },
  {
    id: "office",
    title: "Office and management",
    blurb: "Quotes, email, reports, people, backups. Shop logins do not see this section.",
    audience: "admin",
    chapters: [
      {
        id: "quoting",
        title: "Quoting",
        path: "/quoting",
        tab: "quoting",
        audience: "admin",
        intro:
          "Master quoter. Typing a part number loads history. Shop averages help you reprice from real time.",
        steps: [
          {
            title: "Load a part",
            body: [
              "Type the part number. Matches fill the form from the live database.",
              "New part — fill customer, rev, material family, then type / grade.",
            ],
          },
          {
            title: "Material and size",
            body: [
              "Family vs type (Aluminum / T6 6061).",
              "Shape drives the size fields. Changing shape clears them so you do not keep a leftover dia on a rectangle.",
              "In a size box you can type 12*12 — it does the math.",
            ],
          },
          {
            title: "Operations",
            body: [
              "More than 6 ops are allowed.",
              "Assemblies: -01 assembly, -02 / -03 pieces, then remaining ops.",
            ],
          },
          {
            title: "Markups",
            body: [
              "Machine % and Material %: 1 = actual, 1.25 = 25% markup.",
              "Do not roll the mouse wheel on those fields.",
            ],
          },
          {
            title: "Soft jaws and special tools",
            body: [
              "Bill as their own lines. Do not bury them in the part each.",
            ],
          },
          {
            title: "Save",
            body: [
              "Submit / Update writes the live database.",
              "Floor material match, email quotes, and later requotes all read this record.",
            ],
          },
        ],
      },
      {
        id: "parts-db",
        title: "Parts & Quotes",
        path: "/database",
        tab: "database",
        audience: "admin",
        intro: "Browse the full quote book.",
        steps: [
          {
            title: "Search",
            body: [
              "Part number, customer, or material.",
              "Same records the quoter saves and the historical CSV import fills.",
            ],
          },
        ],
      },
      {
        id: "email-quotes",
        title: "Email Quotes",
        path: "/email",
        tab: "email",
        audience: "admin",
        intro: "Batch a customer letter: part, rev, qty, price each.",
        steps: [
          {
            title: "Build the letter",
            body: [
              "Filter by customer and date quoted.",
              "Check the lines to send.",
              "Pick the recipient (recent addresses first).",
              "Preview. Logo comes from Settings if you uploaded one.",
              "Send. Tooling charges show as separate lines when they exist on the quote.",
            ],
          },
        ],
      },
      {
        id: "reports",
        title: "Reports and bonuses",
        path: "/reports",
        tab: "reports",
        audience: "admin",
        intro: "Who ran what versus quote. Weekly bonus closeout is live only when Beta is off.",
        steps: [
          {
            title: "Read the floor",
            body: [
              "Machine utilization, operator performance, quoted vs actual, downtime log.",
            ],
          },
          {
            title: "Day / week bonus",
            body: [
              "Shifts, lunch, and tiers live in Settings.",
              "While Beta mode is on, numbers are practice — they do not pay.",
              "Turn Beta off before a real closeout week.",
            ],
          },
        ],
      },
      {
        id: "settings-people",
        title: "Settings — people and access",
        path: "/settings",
        tab: "settings",
        audience: "admin",
        intro: "Who can open which tab, and who needs a PIN. Settings is titles only — tap a title to open that window.",
        steps: [
          {
            title: "Add or edit an operator",
            body: [
              "Settings → Operators.",
              "Name, email, role (operator vs admin).",
              "Check the tabs they may open. Money tabs (Quoting, Parts & Quotes, Email, Reports) cannot stay on an operator.",
              "Set or reset PIN for admins.",
              "Save.",
            ],
          },
          {
            title: "Customers & emails",
            body: [
              "Add the customer and the addresses Email Quotes should offer.",
            ],
          },
        ],
      },
      {
        id: "settings-shop",
        title: "Settings — shop, beta, logo, lists",
        path: "/settings",
        tab: "settings",
        audience: "admin",
        intro: "How the shop runs day to day.",
        steps: [
          {
            title: "Shop network",
            body: [
              "Shop public URL is what goes in label QR codes so a phone opens Scan on this host.",
              "After you change it, reprint labels.",
            ],
          },
          {
            title: "Beta vs production",
            body: [
              "Beta on — practice. Bonuses do not pay. Good while you clean stale data.",
              "Beta off — live floor. Closeouts are real.",
            ],
          },
          {
            title: "Beta cleanup desk",
            body: [
              "Settings links to the cleanup desk.",
              "It lists leftover practice rows. Use the in-app actions. It does not silently delete shop data.",
            ],
          },
          {
            title: "Shifts & bonus rules",
            body: [
              "Day / night windows, lunch, rates, efficiency tiers.",
              "Shop average rules sit lower on the same page.",
            ],
          },
          {
            title: "Company logo",
            body: [
              "Upload once. Packing slips, sales orders, and quote emails use it.",
            ],
          },
          {
            title: "Help tips",
            body: [
              "Show or hide the little ? tips.",
              "Restore all tips if someone hid them and now the floor is lost.",
            ],
          },
        ],
      },
      {
        id: "settings-backup",
        title: "Settings — update, backup, recover",
        path: "/settings",
        tab: "settings",
        audience: "admin",
        intro: "Program updates never include shop data. Backups are how you sleep at night.",
        steps: [
          {
            title: "Update the program",
            body: [
              "Settings → Update app… → choose the zip → wait for success.",
              "Restart LCM if asked.",
              "Floor stations show Refresh. Data stays.",
            ],
          },
          {
            title: "Host backups",
            body: [
              "Create a backup on the host on a regular schedule.",
              "Download a copy off the machine (another drive or office PC).",
              "Restore only if you intend to roll the whole shop back to that moment.",
            ],
          },
          {
            title: "USB full backup",
            body: [
              "Makes a full zip for a USB stick (program + data style dump).",
              "Label the stick with the date. Keep it off-site or in the office safe.",
            ],
          },
          {
            title: "Recover shop",
            body: [
              "If a station cannot see the host, open Recover shop.",
              "Admin unlock, then pick a host backup.",
              "Do this on purpose — restore replaces live data.",
            ],
          },
          {
            title: "Import historical quotes",
            body: [
              "Download the sample CSV.",
              "Match columns from your Google Sheet.",
              "Import after go-live so the quoter has history.",
            ],
          },
        ],
        notes: [
          "Never treat an update zip as a backup. Never treat a backup zip as an Update app file.",
        ],
      },
    ],
  },
  {
    id: "loops",
    title: "Do this, in order",
    blurb: "The full loops so a new person can walk a job from paper to truck.",
    chapters: [
      {
        id: "loop-job",
        title: "A part, start to truck",
        path: "/board",
        intro: "Follow this when you are training someone new.",
        steps: [
          {
            title: "Office — land the PO",
            body: [
              "Customer Orders → import or enter the PO and attach the PDF.",
              "Match material on every line. Fix every ?.",
              "Confirm rev. Release. Line appears on the Job Board.",
            ],
          },
          {
            title: "If material is short",
            body: [
              "Order needs → RFQ or Material buys.",
              "Receive the buy. On-hand goes up. If you receive bars, barcodes appear under Barcoded pieces.",
              "Print labels. Stick them. Then release the job.",
            ],
          },
          {
            title: "Saw (if the mill needs blanks)",
            body: [
              "Cut ticket shows on Saw / Cut queue.",
              "Print ticket, cut, mark qty as blanks come off.",
            ],
          },
          {
            title: "Floor — take and run",
            body: [
              "Job Board → take one job → Load on the machine.",
              "Setup → stop. Runtime → pause when you leave. Complete.",
              "Line is Ready for pack.",
            ],
          },
          {
            title: "Pack and ship",
            body: [
              "Ship Calendar → that due day → Ready for pack.",
              "Print slip and labels. Shop packed. Office verified.",
              "Truck leaves. Delivered. Attach signed slip.",
            ],
          },
        ],
      },
      {
        id: "loop-label",
        title: "First label on a new printer",
        path: "/sample-label",
        tab: "inventory",
        intro: "Do this once per printer. Do not skip to 21 labels.",
        steps: [
          {
            title: "Tape and network",
            body: [
              "DK-2210 1.1\" continuous in the QL-810W.",
              "Printer on shop Wi-Fi. Host PC on the same Wi-Fi.",
            ],
          },
          {
            title: "Sample",
            body: [
              "Sample label → set Wi-Fi address → Print on Wi-Fi.",
              "You want a 1.1 × 0.6 sticker, QR readable, size like (1.5\").",
            ],
          },
          {
            title: "Then the rack",
            body: [
              "Inventory → Print labels (Materials).",
              "Print. Stick on the rack locations or the bars.",
            ],
          },
        ],
      },
    ],
  },
];
