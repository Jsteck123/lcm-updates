import { materialLabelBarcode } from "./brother-label-print";
import { activeCutTickets } from "./cut-tickets";
import { canonicalizeShape } from "./stock-standard";
import type { CutTicket, MaterialStock, StockPiece } from "./types";

export type ScanHit =
  | { kind: "piece"; piece: StockPiece }
  | { kind: "material"; material: MaterialStock };

export function resolveScanCode(
  code: string,
  pieces: StockPiece[],
  stock: MaterialStock[],
): ScanHit | null {
  const raw = (code || "").trim();
  if (!raw) return null;
  const up = raw.toUpperCase();
  const piece = (pieces || []).find(
    (p) => (p.barcode || "").toUpperCase() === up || p.id === raw,
  );
  if (piece) return { kind: "piece", piece };
  const material = (stock || []).find(
    (m) => materialLabelBarcode(m.id) === up || m.id === raw,
  );
  if (material) return { kind: "material", material };
  return null;
}

function norm(s: string) {
  return (s || "").trim().toLowerCase();
}

export function ticketMatchesHit(t: CutTicket, hit: ScanHit): boolean {
  const mat = hit.kind === "piece" ? hit.piece.material : hit.material.material;
  const typ =
    hit.kind === "piece" ? hit.piece.materialType : hit.material.materialType;
  const shp =
    hit.kind === "piece" ? hit.piece.stockShape : hit.material.stockShape;
  if (t.material && norm(t.material) !== norm(mat)) return false;
  if (t.materialType && typ && norm(t.materialType) !== norm(typ)) return false;
  if (
    t.stockShape &&
    shp &&
    canonicalizeShape(t.stockShape) !== canonicalizeShape(shp)
  ) {
    return false;
  }
  return Boolean(t.material || mat);
}

export function matchingOpenCuts(hit: ScanHit, tickets: CutTicket[]): CutTicket[] {
  return activeCutTickets(tickets || []).filter((t) => ticketMatchesHit(t, hit));
}

export function leftoverCut(t: CutTicket): number {
  return Math.max(0, (Number(t.qtyRequested) || 0) - (Number(t.qtyCut) || 0));
}
