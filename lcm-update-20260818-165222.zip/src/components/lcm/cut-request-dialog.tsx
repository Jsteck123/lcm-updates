import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import { SmartNumberInput } from "@/components/ui/smart-number-input";
import { useLcmStore } from "@/store/lcm-store";
import type { CutProcess, LocAxis } from "@/lib/lcm/types";
import {
  cutTicketLabel,
  locValueFromDims,
  ticketFromLine,
} from "@/lib/lcm/cut-tickets";

type Props = {
  open: boolean;
  onClose: () => void;
  orderId: string;
  lineId: string;
  componentId?: string;
  byName: string;
  machine?: string;
};

export function CutRequestDialog({
  open,
  onClose,
  orderId,
  lineId,
  componentId,
  byName,
  machine,
}: Props) {
  const shopOrders = useLcmStore((s) => s.shopOrders || []);
  const createCutTicketFromLine = useLcmStore((s) => s.createCutTicketFromLine);

  const order = shopOrders.find((o) => o.id === orderId);
  const line = order?.lines?.find((l) => l.id === lineId);

  const [process, setProcess] = useState<CutProcess>("mill");
  const [dimX, setDimX] = useState(0);
  const [dimY, setDimY] = useState(0);
  const [dimZ, setDimZ] = useState(0);
  const [diameter, setDiameter] = useState(0);
  const [locAxis, setLocAxis] = useState<LocAxis>("z");
  const [locValue, setLocValue] = useState(0);
  const [qty, setQty] = useState(1);
  const [notes, setNotes] = useState("");
  const [writeBack, setWriteBack] = useState(false);
  const seededKey = useRef("");

  useEffect(() => {
    if (!open) {
      seededKey.current = "";
      return;
    }
    const key = `${orderId}:${lineId}:${componentId || ""}`;
    if (seededKey.current === key) return;
    const s = useLcmStore.getState();
    const ord = (s.shopOrders || []).find((o) => o.id === orderId);
    const ln = ord?.lines?.find((l) => l.id === lineId);
    if (!ord || !ln) return;
    const qs = s.quotes || [];
    const q =
      (ln.quoteId && qs.find((x) => x.id === ln.quoteId)) ||
      qs.find(
        (x) =>
          x.partNumber.toLowerCase() === (ln.partNumber || "").toLowerCase() &&
          (!ln.revision ||
            x.revision.toLowerCase() === ln.revision.toLowerCase()),
      ) ||
      null;
    const pre = ticketFromLine({
      order: ord,
      line: ln,
      byName,
      machine,
      componentId,
      quote: q,
    });
    seededKey.current = key;
    setProcess(pre.process);
    setDimX(pre.dimX);
    setDimY(pre.dimY);
    setDimZ(pre.dimZ);
    setDiameter(pre.diameter);
    setLocAxis(pre.locAxis);
    setLocValue(pre.locValue);
    setQty(pre.qtyRequested || 1);
    setNotes("");
    setWriteBack(false);
  }, [open, orderId, lineId, componentId, byName, machine]);

  // When mill axis changes, sync LOC value from that dim
  useEffect(() => {
    if (process === "lathe") return;
    const v = locValueFromDims(process, locAxis, {
      dimX,
      dimY,
      dimZ,
      diameter,
    });
    if (v > 0) setLocValue(v);
  }, [locAxis, dimX, dimY, dimZ, process, diameter]);

  if (!open || !order || !line) return null;

  function submit() {
    const r = createCutTicketFromLine({
      orderId,
      lineId,
      componentId,
      byName,
      machine,
      process,
      dimX,
      dimY,
      dimZ,
      diameter,
      locAxis: process === "lathe" ? "dia" : locAxis,
      locValue,
      qtyRequested: qty,
      notes,
      writeBackToQuote: writeBack,
    });
    if (!r.ok) {
      toast.error(r.error || "Could not create ticket");
      return;
    }
    toast.success(
      `Cut ticket sent · ${r.ticket?.partNumber} · ${cutTicketLabel(r.ticket!)} · qty ${qty}`,
    );
    onClose();
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-3 print:hidden"
      role="dialog"
      aria-modal="true"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md max-h-[92vh] overflow-y-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] shadow-xl p-4 space-y-3"
        onClick={(e) => e.stopPropagation()}
      >
        <div>
          <h2 className="text-lg font-semibold">Request saw cut</h2>
          <p className="text-xs text-[var(--color-muted)] mt-0.5">
            {line.partNumber} Rev {line.revision || "—"} · enter CAD actuals
            (quote size is only a starting guess)
          </p>
        </div>

        <div className="space-y-1.5">
          <Label>Process</Label>
          <Select
            value={process}
            onChange={(e) => {
              const p = e.target.value as CutProcess;
              setProcess(p);
              if (p === "lathe") setLocAxis("dia");
              else if (locAxis === "dia") setLocAxis("z");
            }}
          >
            <option value="mill">Mill (X / Y / Z · pick LOC axis)</option>
            <option value="lathe">Lathe (diameter + LOC)</option>
            <option value="other">Other</option>
          </Select>
        </div>

        {process === "lathe" ? (
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Diameter</Label>
              <SmartNumberInput
                value={diameter}
                onValueChange={setDiameter}
                format="inches"
              />
            </div>
            <div className="space-y-1">
              <Label>LOC (length of cut)</Label>
              <SmartNumberInput
                value={locValue}
                onValueChange={setLocValue}
                format="inches"
              />
            </div>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-3 gap-2">
              <div className="space-y-1">
                <Label>X</Label>
                <SmartNumberInput
                  value={dimX}
                  onValueChange={setDimX}
                  format="inches"
                />
              </div>
              <div className="space-y-1">
                <Label>Y</Label>
                <SmartNumberInput
                  value={dimY}
                  onValueChange={setDimY}
                  format="inches"
                />
              </div>
              <div className="space-y-1">
                <Label>Z</Label>
                <SmartNumberInput
                  value={dimZ}
                  onValueChange={setDimZ}
                  format="inches"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>LOC is which axis?</Label>
              <div className="flex gap-2">
                {(["x", "y", "z"] as const).map((a) => (
                  <button
                    key={a}
                    type="button"
                    className={
                      "flex-1 rounded-[var(--radius-md)] border px-3 py-2.5 text-sm font-semibold min-h-11 " +
                      (locAxis === a
                        ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)]"
                        : "border-[var(--color-border)]")
                    }
                    onClick={() => setLocAxis(a)}
                  >
                    {a.toUpperCase()}
                  </button>
                ))}
              </div>
              <div className="space-y-1">
                <Label>LOC value (from {locAxis.toUpperCase()}, editable)</Label>
                <SmartNumberInput
                  value={locValue}
                  onValueChange={setLocValue}
                  format="inches"
                />
              </div>
            </div>
          </>
        )}

        <div className="space-y-1">
          <Label>Qty to cut</Label>
          <SmartNumberInput value={qty} onValueChange={setQty} format="plain" />
        </div>

        <div className="space-y-1">
          <Label>Notes for saw</Label>
          <Input
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Leave 0.05 for face, grain, etc."
          />
        </div>

        <label className="flex items-start gap-2 text-sm cursor-pointer">
          <input
            type="checkbox"
            className="mt-1"
            checked={writeBack}
            onChange={(e) => setWriteBack(e.target.checked)}
          />
          <span>
            When cut is done, write actual size back to quote recipe
            <span className="block text-[11px] text-[var(--color-muted)]">
              Size only — never changes quoted prices
            </span>
          </span>
        </label>

        <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 text-xs text-[var(--color-muted)]">
          Preview:{" "}
          <strong className="text-[var(--color-fg)]">
            {cutTicketLabel({
              process,
              locAxis: process === "lathe" ? "dia" : locAxis,
              locValue,
              dimX,
              dimY,
              dimZ,
              diameter,
            })}
          </strong>{" "}
          · qty {qty}
        </div>

        <div className="flex gap-2 pt-1">
          <Button type="button" className="flex-1 min-h-11" onClick={submit}>
            Send to saw
          </Button>
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
        </div>
      </div>
    </div>
  );
}
