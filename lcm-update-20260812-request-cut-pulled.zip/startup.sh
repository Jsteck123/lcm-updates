#!/bin/sh
set -eu
cd /workspace
code=$(curl -sf -o /dev/null -w "%{http_code}" --max-time 2 http://127.0.0.1:8080/ 2>/dev/null || echo 000)
if [ "$code" = "200" ]; then exit 0; fi
export PATH="/workspace/node_modules/.bin:/opt/app-template/node_modules/.bin:$PATH"
npm run dev >>/tmp/app-startup.log 2>&1 &
