# Manual start helper (console). Prefer start-host.cmd for Task Scheduler.
$Root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$Cmd = Join-Path $Root "scripts\host\start-host.cmd"
& $Cmd
