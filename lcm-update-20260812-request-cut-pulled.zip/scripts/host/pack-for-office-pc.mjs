#!/usr/bin/env node
/**
 * Zip the app for copy to an office PC (excludes node_modules, .git, caches).
 * Output: data/updates/lcm-office-pc-YYYYMMDD.zip
 */
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";

const root = process.cwd();
const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, "");
const outDir = path.join(root, "data", "updates");
fs.mkdirSync(outDir, { recursive: true });
const outZip = path.join(outDir, `lcm-office-pc-${stamp}.zip`);

const excludeDirs = new Set([
  "node_modules",
  ".git",
  "artifacts",
  ".output",
  "dist",
  "screenshots",
  ".nitro",
  ".vinxi",
  ".cache",
  "updates", // avoid packing staging / old zips
  "_office-pack",
]);

const stage = path.join(os.tmpdir(), `lcm-office-pack-${stamp}-${process.pid}`);
fs.rmSync(stage, { recursive: true, force: true });
fs.mkdirSync(stage, { recursive: true });

function copy(src, dest) {
  const st = fs.statSync(src);
  const base = path.basename(src);
  if (excludeDirs.has(base)) return;
  if (base.startsWith("_office-pack")) return;
  if (st.isDirectory()) {
    fs.mkdirSync(dest, { recursive: true });
    for (const name of fs.readdirSync(src)) {
      if (excludeDirs.has(name)) continue;
      if (name.startsWith("_office-pack")) continue;
      copy(path.join(src, name), path.join(dest, name));
    }
  } else {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(src, dest);
  }
}

for (const name of fs.readdirSync(root)) {
  if (excludeDirs.has(name)) continue;
  // Skip packing huge public tutorial video? keep it for help page
  copy(path.join(root, name), path.join(stage, name));
}

// Ensure empty runtime dirs exist in the zip
for (const d of ["data/backups", "data/po-files", "data/logs", "data/updates"]) {
  fs.mkdirSync(path.join(stage, d), { recursive: true });
}

const py = `
import zipfile, os, sys
stage, out = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(stage):
        dirs[:] = [d for d in dirs if d not in ("node_modules", ".git")]
        for f in files:
            p = os.path.join(root, f)
            z.write(p, os.path.relpath(p, stage))
print(out)
`;
const r = spawnSync("python3", ["-c", py, stage, outZip], { encoding: "utf8" });
fs.rmSync(stage, { recursive: true, force: true });
if (r.status !== 0) {
  console.error(r.stderr || r.stdout);
  process.exit(1);
}
console.log("Created", outZip);
console.log("Copy that zip to the office PC, unzip, then run:");
console.log("  powershell -ExecutionPolicy Bypass -File scripts\\host\\Install-On-My-PC.ps1");
