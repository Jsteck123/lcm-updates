@echo off
setlocal EnableExtensions
cd /d "%~dp0..\.."
title LCM Restore data only
echo Restores NEWEST data\backups\backup-*.json -> data\lcm-shop.json
echo Does NOT change program files.
echo.
pause
taskkill /F /IM node.exe >NUL 2>&1
timeout /t 1 /nobreak >NUL
if exist "data\lcm-shop.json" (
  copy /Y "data\lcm-shop.json" "data\lcm-shop.before-restore.json" >NUL
)
set "NEWEST="
for /f "delims=" %%F in ('dir /b /o-d "data\backups\backup-*.json" 2^>NUL') do (
  set "NEWEST=%%F"
  goto :g
)
:g
if not defined NEWEST (
  echo No backup-*.json found.
  pause
  exit /b 1
)
echo Using %NEWEST%
copy /Y "data\backups\%NEWEST%" "data\lcm-shop.json"
echo Done. Now run scripts\host\start-host.cmd
pause
