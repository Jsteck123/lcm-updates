@echo off
setlocal EnableExtensions EnableDelayedExpansion
title LCM Shop RECOVERY
echo.
echo ============================================
echo  Lake Country Machine - SHOP RECOVERY
echo ============================================
echo.

REM ---- Find the real app folder (has package.json) ----
set "HERE=%~dp0"
cd /d "%HERE%"

if exist "package.json" goto :found_root
if exist "..\..\package.json" (
  cd /d "%HERE%..\.."
  goto :found_root
)
if exist "..\package.json" (
  cd /d "%HERE%.."
  goto :found_root
)
if exist "scripts\host" if exist "package.json" goto :found_root

echo ERROR: Cannot find package.json near this script.
echo.
echo You must put RECOVER-SHOP.cmd INSIDE the LCM app folder
echo (the folder that already has package.json, node_modules, and data).
echo.
echo Current script location: %HERE%
echo Current directory: %CD%
echo.
echo Example good place:
echo   C:\Users\jamessteck\...\lcm-data-management\RECOVER-SHOP.cmd
echo   (same folder as package.json)
echo.
pause
exit /b 1

:found_root
echo App folder: %CD%
if not exist "package.json" (
  echo Still no package.json - aborting.
  pause
  exit /b 1
)
echo Found package.json - good.
echo.
echo This will:
echo   1. Stop stuck Node
echo   2. Restore newest data\backups\backup-*.json -^> data\lcm-shop.json
echo   3. Apply lcm-update-*.zip if it is in THIS folder
echo   4. Start the shop app
echo.
pause

if not exist "data" mkdir "data"
if not exist "data\logs" mkdir "data\logs"
if not exist "data\backups" mkdir "data\backups"

echo.
echo [1/4] Stopping Node...
taskkill /F /IM node.exe >NUL 2>&1
timeout /t 2 /nobreak >NUL

echo [2/4] Restoring newest backup JSON (if any)...
dir /b "data\backups\*.json" 2>NUL
set "NEWEST="
for /f "delims=" %%F in ('dir /b /o-d "data\backups\backup-*.json" 2^>NUL') do (
  set "NEWEST=%%F"
  goto :got_newest
)
:got_newest
if not defined NEWEST (
  REM also accept any *.json in backups
  for /f "delims=" %%F in ('dir /b /o-d "data\backups\*.json" 2^>NUL') do (
    set "NEWEST=%%F"
    goto :got_newest2
  )
)
:got_newest2
if not defined NEWEST (
  echo   No JSON backups in data\backups\
  if exist "data\lcm-shop.json" (
    echo   Keeping existing data\lcm-shop.json
  ) else (
    echo   WARNING: no data\lcm-shop.json either - app may start empty.
  )
) else (
  echo   Using: data\backups\!NEWEST!
  if exist "data\lcm-shop.json" (
    copy /Y "data\lcm-shop.json" "data\lcm-shop.broken.json" >NUL
  )
  copy /Y "data\backups\!NEWEST!" "data\lcm-shop.json" >NUL
  if errorlevel 1 (echo   COPY FAILED) else (echo   Restored OK.)
)

echo [3/4] Looking for recovery / update zip in app folder...
set "ZIP="
for /f "delims=" %%Z in ('dir /b /o-d "lcm-update-*.zip" 2^>NUL') do (
  set "ZIP=%%Z"
  goto :got_zip
)
:got_zip
if not defined ZIP (
  echo   No lcm-update-*.zip here.
  echo   Copy lcm-update-20260811-123038.zip into:
  echo   %CD%
  echo   then run this script again if the app still crashes.
) else (
  echo   Applying: !ZIP!
  where node >NUL 2>&1
  if errorlevel 1 (
    echo   Node.js not found. Install Node 22 LTS from https://nodejs.org
    pause
    exit /b 1
  )
  if exist "scripts\apply-lcm-update.mjs" (
    node "scripts\apply-lcm-update.mjs" "!ZIP!"
  ) else (
    echo   scripts\apply-lcm-update.mjs missing.
  )
)

echo [4/4] Starting shop app...
echo.
echo   When you see Local: http://localhost:8080
echo   open browser on THIS PC:  http://127.0.0.1:8080
echo   Leave this window OPEN.
echo.

where node >NUL 2>&1
if errorlevel 1 (
  echo Node.js not found. Install Node 22 LTS from https://nodejs.org
  pause
  exit /b 1
)

if not exist "node_modules\" (
  echo Installing packages - first time can take a few minutes...
  call npm install
  if errorlevel 1 (
    echo npm install FAILED - see error above.
    pause
    exit /b 1
  )
)

call npm run dev -- --host 0.0.0.0 --port 8080
echo.
echo App stopped. Scroll up for any red errors and send them in chat.
pause
