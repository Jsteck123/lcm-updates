# Register Windows Task: start LCM shop at boot and keep it running.
# Run ONCE in elevated PowerShell (Run as Administrator) from any folder:
#
#   powershell -ExecutionPolicy Bypass -File C:\LCM\lcm-data-management\scripts\host\install-windows-task.ps1
#
# Requires: Node.js 22 LTS installed for all users.

$ErrorActionPreference = "Stop"

$Root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$Cmd = Join-Path $Root "scripts\host\start-host.cmd"
$TaskName = "LCM-Shop-Host"
$Port = 8080

if (-not (Test-Path $Cmd)) {
  throw "Missing start script: $Cmd"
}

# --- Firewall: allow LAN browsers to reach the shop app ---
$fwName = "LCM Shop App port $Port"
$existing = Get-NetFirewallRule -DisplayName $fwName -ErrorAction SilentlyContinue
if (-not $existing) {
  New-NetFirewallRule `
    -DisplayName $fwName `
    -Direction Inbound `
    -Action Allow `
    -Protocol TCP `
    -LocalPort $Port `
    -Profile Domain,Private `
    -Description "Lake Country Machine shop app — browsers on the LAN" | Out-Null
  Write-Host "[lcm] Firewall rule created: $fwName (Domain + Private)"
} else {
  Write-Host "[lcm] Firewall rule already exists: $fwName"
}

# --- Scheduled task at startup ---
$action = New-ScheduledTaskAction `
  -Execute "cmd.exe" `
  -Argument "/c `"$Cmd`"" `
  -WorkingDirectory $Root

$trigger = New-ScheduledTaskTrigger -AtStartup

# SYSTEM so it runs without anyone logged into the server console
$principal = New-ScheduledTaskPrincipal `
  -UserId "SYSTEM" `
  -LogonType ServiceAccount `
  -RunLevel Highest

$settings = New-ScheduledTaskSettingsSet `
  -AllowStartIfOnBatteries `
  -DontStopIfGoingOnBatteries `
  -StartWhenAvailable `
  -RestartCount 5 `
  -RestartInterval (New-TimeSpan -Minutes 1) `
  -ExecutionTimeLimit ([TimeSpan]::Zero) `
  -MultipleInstances IgnoreNew

Register-ScheduledTask `
  -TaskName $TaskName `
  -Action $action `
  -Trigger $trigger `
  -Principal $principal `
  -Settings $settings `
  -Force | Out-Null

Write-Host ""
Write-Host "[lcm] Task '$TaskName' installed — starts at every reboot."
Write-Host "[lcm] App folder: $Root"
Write-Host ""
Write-Host "Start now:"
Write-Host "  Start-ScheduledTask -TaskName $TaskName"
Write-Host ""
Write-Host "Check status:"
Write-Host "  Get-ScheduledTask -TaskName $TaskName | Get-ScheduledTaskInfo"
Write-Host ""
Write-Host "On shop PCs open:  http://SERVER-IP:$Port"
Write-Host "  (on the server run: ipconfig   — use the Ethernet IPv4 address)"
Write-Host ""
Write-Host "Logs:  $Root\data\logs\host.log"
