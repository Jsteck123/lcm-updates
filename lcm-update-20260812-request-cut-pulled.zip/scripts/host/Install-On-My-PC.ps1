﻿#Requires -Version 5.1
# Lake Country Machine - one-time setup on THIS office PC
# Run:
#   cd C:\LCM
#   powershell -ExecutionPolicy Bypass -File scripts\host\Install-On-My-PC.ps1

$ErrorActionPreference = "Stop"
try {
  $Host.UI.RawUI.WindowTitle = "LCM Shop - Install on this PC"
} catch {}

function Write-Step($n, $msg) {
  Write-Host ""
  Write-Host "[$n] $msg" -ForegroundColor Cyan
}

function Get-LanIPv4 {
  try {
    $addrs = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
      Where-Object {
        $_.IPAddress -notlike "127.*" -and
        $_.IPAddress -notlike "169.254.*" -and
        $_.PrefixOrigin -ne "WellKnown"
      } |
      Sort-Object -Property InterfaceMetric
    if ($addrs) { return $addrs[0].IPAddress }
  } catch {}
  try {
    $line = (ipconfig | Select-String -Pattern "IPv4" | Select-Object -First 1).ToString()
    if ($line -match "(\d+\.\d+\.\d+\.\d+)") { return $Matches[1] }
  } catch {}
  return "YOUR-PC-IP"
}

$Root = $null
$here = $PSScriptRoot
if ($here) {
  $candidate = (Resolve-Path (Join-Path $here "..\..")).Path
  if (Test-Path (Join-Path $candidate "package.json")) { $Root = $candidate }
}
if (-not $Root) {
  $candidate = (Get-Location).Path
  if (Test-Path (Join-Path $candidate "package.json")) { $Root = $candidate }
}
if (-not $Root) {
  Write-Host "Could not find package.json. cd into C:\LCM first." -ForegroundColor Red
  Read-Host "Press Enter to close"
  exit 1
}

Set-Location $Root
Write-Host "========================================" -ForegroundColor Green
Write-Host "  Lake Country Machine - this PC setup" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host "App folder: $Root"

$logDir = Join-Path $Root "data\logs"
New-Item -ItemType Directory -Force -Path $logDir,
  (Join-Path $Root "data\backups"),
  (Join-Path $Root "data\po-files"),
  (Join-Path $Root "data\branding") | Out-Null

Write-Step "1/5" "Checking Node.js..."
$node = Get-Command node -ErrorAction SilentlyContinue
$npm = Get-Command npm -ErrorAction SilentlyContinue
if (-not $node -or -not $npm) {
  Write-Host ""
  Write-Host "Node.js is not installed (or not on PATH)." -ForegroundColor Yellow
  Write-Host "1) Download Node.js LTS:  https://nodejs.org"
  Write-Host "2) Install with default options (Add to PATH)."
  Write-Host "3) CLOSE this window, open a NEW PowerShell, run this script again."
  Write-Host ""
  Start-Process "https://nodejs.org"
  Read-Host "Press Enter to close"
  exit 1
}
Write-Host "  node ok  /  npm ok" -ForegroundColor DarkGray

Write-Step "2/5" "Installing packages (skip if already done)..."
if (-not (Test-Path (Join-Path $Root "node_modules"))) {
  & npm install
  if ($LASTEXITCODE -ne 0) { throw "npm install failed" }
} else {
  Write-Host "  node_modules already present - skip" -ForegroundColor DarkGray
}

Write-Step "3/5" "Build check..."
$hasDist = (Test-Path (Join-Path $Root "dist")) -or (Test-Path (Join-Path $Root ".output")) -or (Test-Path (Join-Path $Root ".vercel"))
if (-not $hasDist) {
  Write-Host "  Running build (optional)..."
  & npm run build
} else {
  Write-Host "  build already present - skip" -ForegroundColor DarkGray
}

Write-Step "4/5" "Start shop app when YOU sign into Windows..."
$TaskName = "LCM-Shop-On-This-PC"
$StartCmd = Join-Path $Root "scripts\host\start-host.cmd"
if (-not (Test-Path $StartCmd)) { throw "Missing $StartCmd" }

# Prefer npm run dev via a tiny launcher cmd that we control
$action = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c `"$StartCmd`"" -WorkingDirectory $Root
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$settings = New-ScheduledTaskSettingsSet `
  -AllowStartIfOnBatteries `
  -DontStopIfGoingOnBatteries `
  -StartWhenAvailable `
  -RestartCount 3 `
  -RestartInterval (New-TimeSpan -Minutes 1) `
  -ExecutionTimeLimit ([TimeSpan]::Zero) `
  -MultipleInstances IgnoreNew

try {
  Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger `
    -Settings $settings -Force | Out-Null
  Write-Host "  Task '$TaskName' registered for user $env:USERNAME" -ForegroundColor Green
} catch {
  Write-Host "  Could not register scheduled task: $($_.Exception.Message)" -ForegroundColor Yellow
  Write-Host "  You can still double-click start-host.cmd each day." -ForegroundColor Yellow
}

try {
  $desktop = [Environment]::GetFolderPath("Desktop")
  $lnkPath = Join-Path $desktop "LCM Shop (start).lnk"
  $w = New-Object -ComObject WScript.Shell
  $sc = $w.CreateShortcut($lnkPath)
  $sc.TargetPath = $StartCmd
  $sc.WorkingDirectory = $Root
  $sc.Description = "Start Lake Country Machine shop app on this PC"
  $sc.Save()
  Write-Host "  Desktop shortcut: LCM Shop (start)" -ForegroundColor Green
} catch {
  Write-Host "  (Shortcut skipped - not required)" -ForegroundColor DarkGray
}

Write-Step "5/5" "Firewall (optional - needs admin)..."
$fwOk = $false
try {
  $fwName = "LCM Shop App port 8080"
  if (-not (Get-NetFirewallRule -DisplayName $fwName -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule -DisplayName $fwName -Direction Inbound -Action Allow `
      -Protocol TCP -LocalPort 8080 -Profile Domain,Private `
      -Description "LCM shop app on this office PC" -ErrorAction Stop | Out-Null
  }
  $fwOk = $true
  Write-Host "  Firewall rule OK (port 8080)" -ForegroundColor Green
} catch {
  Write-Host "  No admin rights for firewall (normal)." -ForegroundColor Yellow
  Write-Host "  This PC still works. Floor PCs: allow Node on Private if Windows asks." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Starting the shop app now..." -ForegroundColor Cyan
try {
  Start-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
} catch {}
Start-Process -FilePath "cmd.exe" -ArgumentList "/c `"$StartCmd`"" -WorkingDirectory $Root -WindowStyle Minimized

$ip = Get-LanIPv4
Start-Sleep -Seconds 3

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  DONE - shop host is on THIS PC" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "On THIS computer open:" -ForegroundColor White
Write-Host "  http://127.0.0.1:8080" -ForegroundColor Yellow
Write-Host ""
Write-Host "On shop floor PCs / tablets open:" -ForegroundColor White
Write-Host "  http://${ip}:8080" -ForegroundColor Yellow
Write-Host ""
Write-Host "Tips:" -ForegroundColor White
Write-Host "  - Leave this PC on (or awake) during shop hours."
Write-Host "  - After reboot / sign-in, the app should start with Windows."
Write-Host "  - Desktop: double-click  LCM Shop (start)  if needed."
Write-Host "  - Admins: James or Pam - change PIN in Settings."
Write-Host "  - Log: $logDir\host.log"
if (-not $fwOk) {
  Write-Host ""
  Write-Host "If floor PCs cannot connect: when Windows Firewall pops up for" -ForegroundColor Yellow
  Write-Host "Node.js, choose Allow on Private networks." -ForegroundColor Yellow
}
Write-Host ""
Read-Host "Press Enter to close this window"
