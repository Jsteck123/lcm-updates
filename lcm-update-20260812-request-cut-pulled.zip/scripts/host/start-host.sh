#!/usr/bin/env bash
# Lake Country Machine — start the shop app on the host (Linux VM / server).
# Listens on all interfaces, port 8080. Safe to re-run (idempotent).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
LOG_DIR="${LCM_LOG_DIR:-$ROOT/data/logs}"
mkdir -p "$LOG_DIR" "$ROOT/data" "$ROOT/data/backups" "$ROOT/data/po-files" "$ROOT/data/branding"

PID_FILE="$LOG_DIR/host.pid"
LOG_FILE="$LOG_DIR/host.log"
PORT="${PORT:-8080}"

is_up() {
  curl -sf -o /dev/null --max-time 2 "http://127.0.0.1:${PORT}/" 2>/dev/null
}

if is_up; then
  echo "[lcm] already running on port ${PORT}"
  exit 0
fi

# Prefer production build serve; build if dist missing
if [ ! -d "$ROOT/dist" ] && [ ! -d "$ROOT/.output" ]; then
  echo "[lcm] building…"
  npm run build
fi

export HOST=0.0.0.0
export PORT

# TanStack/Vite preview after build
nohup npm run preview -- --host 0.0.0.0 --port "$PORT" >>"$LOG_FILE" 2>&1 &
echo $! >"$PID_FILE"
echo "[lcm] started pid $(cat "$PID_FILE") — log $LOG_FILE"

# Wait briefly for health
for i in 1 2 3 4 5 6 7 8 9 10; do
  if is_up; then
    echo "[lcm] healthy on http://0.0.0.0:${PORT}/"
    exit 0
  fi
  sleep 1
done
echo "[lcm] started but not answering yet — check $LOG_FILE" >&2
exit 0
