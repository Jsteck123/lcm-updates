/**
 * Capture fresh How-to-use screenshots from the running app.
 */
import { mkdirSync } from "node:fs";
import { chromium } from "playwright";

const BASE = process.env.TUTORIAL_BASE || "http://127.0.0.1:8080";
const OUT = "/workspace/public/tutorial";
mkdirSync(OUT, { recursive: true });

const slides = [
  { file: "01-overview.png", path: "/", wait: 1200 },
  { file: "02-dashboard.png", path: "/", wait: 800 },
  { file: "03-colors.png", path: "/board", wait: 1200 },
  { file: "04-customer-orders.png", path: "/po", wait: 1500 },
  { file: "05-job-board.png", path: "/board", wait: 1200 },
  { file: "06-shop-floor.png", path: "/machines", wait: 1200 },
  { file: "07-ship-calendar.png", path: "/calendar", wait: 1500 },
  { file: "08-inventory.png", path: "/inventory", wait: 1500 },
  { file: "09-quoting.png", path: "/quoting", wait: 1500 },
  { file: "10-parts-db.png", path: "/database", wait: 1200 },
  { file: "11-email.png", path: "/email", wait: 1200 },
  { file: "12-reports.png", path: "/reports", wait: 1200 },
  { file: "13-settings.png", path: "/settings", wait: 1500 },
  { file: "14-full-loop.png", path: "/calendar", wait: 1000 },
  { file: "15-chat.png", path: "/", wait: 1000, openChat: true },
];

const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});

const page = await browser.newPage({
  viewport: { width: 1440, height: 900 },
  deviceScaleFactor: 1,
});

page.setDefaultTimeout(60000);

async function settle() {
  await page.waitForLoadState("networkidle").catch(() => {});
  await page.waitForTimeout(600);
}

for (const s of slides) {
  const url = BASE + s.path;
  console.log("capture", s.file, url);
  const resp = await page.goto(url, { waitUntil: "domcontentloaded", timeout: 60000 });
  console.log("  status", resp?.status());
  await settle();
  await page.waitForTimeout(s.wait || 1000);

  // dismiss any obvious blocking dialogs
  try {
    const close = page.locator('button:has-text("Close"), button:has-text("Cancel")').first();
    if (await close.isVisible({ timeout: 300 }).catch(() => false)) {
      // don't auto-close real dialogs
    }
  } catch {}

  if (s.openChat) {
    try {
      const chatBtn = page.locator('button:has-text("Chat")').last();
      if (await chatBtn.isVisible({ timeout: 1000 })) {
        await chatBtn.click();
        await page.waitForTimeout(800);
      }
    } catch (e) {
      console.log("  chat open skip", e.message);
    }
  }

  const out = `${OUT}/${s.file}`;
  await page.screenshot({ path: out, fullPage: false });
  console.log("  wrote", out);
}

await browser.close();
console.log("done");
