#!/usr/bin/env node
/**
 * Build an LCM app update package for Settings → Update app.
 * Usage: node scripts/make-update-package.mjs [note]
 * Output: artifacts/lcm-update-YYYYMMDD-HHMMSS.zip
 */
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const note = process.argv.slice(2).join(" ") || "App update";
const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\..+/, "").replace("T", "-");
const outDir = path.join(root, "artifacts");
fs.mkdirSync(outDir, { recursive: true });
const outZip = path.join(outDir, `lcm-update-${stamp}.zip`);

const version = stamp;
const manifest = {
  appId: "lcm-data-management",
  format: 1,
  version,
  createdAt: new Date().toISOString(),
  note,
  // Relative paths included in the package (never data/ or node_modules/)
  include: [
    "src",
    "public",
    "scripts",
    "package.json",
    "package-lock.json",
    "vite.config.ts",
    "tsconfig.json",
    "startup.sh",
    "eslint.config.mjs",
    ".prettierrc",
  ],
};

const stage = path.join(root, "data", "updates", `_build-${stamp}`);
fs.rmSync(stage, { recursive: true, force: true });
fs.mkdirSync(stage, { recursive: true });
fs.writeFileSync(path.join(stage, "lcm-update.json"), JSON.stringify(manifest, null, 2));

// Heavy / non-essential paths — keep update zips small for browser upload
const EXCLUDE_DIR_NAMES = new Set(["node_modules", ".git", "data", "screenshots", "artifacts"]);
const EXCLUDE_PATH_PARTS = [
  `${path.sep}public${path.sep}tutorial${path.sep}`,
  `/public/tutorial/`,
];

function shouldExclude(absPath) {
  const norm = absPath.replace(/\\/g, "/");
  if (norm.includes("/public/tutorial/")) return true;
  if (norm.endsWith(".mp4") || norm.endsWith(".webm")) return true;
  return false;
}

function copyRecursive(src, dest) {
  const st = fs.statSync(src);
  if (st.isDirectory()) {
    const base = path.basename(src);
    if (EXCLUDE_DIR_NAMES.has(base)) return;
    fs.mkdirSync(dest, { recursive: true });
    for (const name of fs.readdirSync(src)) {
      if (EXCLUDE_DIR_NAMES.has(name)) continue;
      copyRecursive(path.join(src, name), path.join(dest, name));
    }
  } else {
    if (shouldExclude(src)) return;
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(src, dest);
  }
}

for (const rel of manifest.include) {
  const abs = path.join(root, rel);
  if (!fs.existsSync(abs)) {
    console.warn("skip missing", rel);
    continue;
  }
  copyRecursive(abs, path.join(stage, rel));
}

const py = `
import zipfile, os, sys
stage, out = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(stage):
        for f in files:
            p = os.path.join(root, f)
            z.write(p, os.path.relpath(p, stage))
print(out)
`;
const r = spawnSync("python3", ["-c", py, stage, outZip], { encoding: "utf8" });
if (r.status !== 0) {
  console.error(r.stderr || r.stdout);
  process.exit(1);
}
fs.rmSync(stage, { recursive: true, force: true });
const size = fs.statSync(outZip).size;
console.log(JSON.stringify({ ok: true, file: outZip, version, bytes: size, note }, null, 2));
console.log("\nGive this zip to the shop: Settings → Update app → Choose file");
