import type {
  ActiveTimer,
  JobRun,
  LcmState,
  MachineSession,
  Quote,
} from "@/lib/lcm/types";
import { emptySession } from "@/lib/lcm/calculations";
import {
  DEFAULT_OPERATIONS,
  clampOpCount,
  padSlots,
} from "@/lib/lcm/ops";
import { createSeedState } from "@/lib/lcm/seed";
import { normalizeOperator } from "@/lib/lcm/permissions";
import type { Operator } from "@/lib/lcm/types";
import { normalizeToolingCharges } from "@/lib/lcm/quote-tooling";

export function operatorEmailMatch(state: LcmState, operatorName: string): boolean {
  const op = state.operators.find((o) => o.name === operatorName);
  if (!op) return false;
  return op.email.toLowerCase() === state.currentUserEmail.toLowerCase();
}

export function migrateOperators(list: Operator[] | undefined): Operator[] {
  if (!Array.isArray(list)) return createSeedState().operators;
  return list.map((o) => normalizeOperator(o as Operator));
}

/** Existing shop DBs may lack betaMode — default ON for safety (no real payouts). */
export function withBetaDefault<T extends { betaMode?: boolean }>(
  settings: T,
): T & { betaMode: boolean } {
  return {
    ...settings,
    betaMode: settings.betaMode != null ? Boolean(settings.betaMode) : true,
  };
}

export function maxOpsFrom(settings: LcmState["settings"] | undefined): number {
  return clampOpCount(settings?.maxOperations ?? DEFAULT_OPERATIONS);
}

export function padQuote(q: Quote, n: number): Quote {
  const kind = q.kind === "assembly" ? "assembly" : "part";
  return {
    ...q,
    kind,
    bom: kind === "assembly" && Array.isArray(q.bom) ? q.bom : [],
    benchAssembleMinutes:
      kind === "assembly" ? Number(q.benchAssembleMinutes) || 0 : 0,
    setupTimes: padSlots(q.setupTimes, n, 0),
    runTimes: padSlots(q.runTimes, n, 0),
    quantities: padSlots(q.quantities, 6, 0),
    prices: padSlots(q.prices, 6, 0),
    toolingCharges: normalizeToolingCharges(q.toolingCharges),
  };
}

export function padJob(j: JobRun, n: number): JobRun {
  return {
    ...j,
    setups: padSlots(j.setups, n, null),
    runtimes: padSlots(j.runtimes, n, null),
    quotedSetups: padSlots(j.quotedSetups, n, 0),
    quotedRuntimes: padSlots(j.quotedRuntimes, n, 0),
    countInAverage: j.countInAverage !== false,
  };
}

export function padSession(s: MachineSession, n: number): MachineSession {
  return {
    ...s,
    setups: padSlots(s.setups, n, null),
    runtimes: padSlots(s.runtimes, n, null),
    quotedSetups: padSlots(s.quotedSetups, n, 0),
    quotedRuntimes: padSlots(s.quotedRuntimes, n, 0),
  };
}

export function ensureMachineSessions(
  sessions: Record<string, MachineSession>,
  activeTimers: Record<string, ActiveTimer | null>,
  machineNames: string[],
  maxOps: number,
) {
  const nextSessions = { ...sessions };
  const nextTimers = { ...activeTimers };
  for (const m of machineNames) {
    if (!nextSessions[m]) nextSessions[m] = emptySession(m, maxOps);
    if (nextTimers[m] === undefined) nextTimers[m] = null;
  }
  return { sessions: nextSessions, activeTimers: nextTimers };
}
