import { useEffect, useState } from "react";

/** Avoid SSR/client mismatch when reading zustand-persist / locale-sensitive values */
export function useHydrated() {
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => {
    setHydrated(true);
  }, []);
  return hydrated;
}
