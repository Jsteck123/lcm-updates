import { useMemo } from "react";
import { useLcmStore } from "@/store/lcm-store";
import { canSeeMoney, getOperatorByEmail } from "@/lib/lcm/permissions";

/** True only for admin role — operators never see $ on any screen. */
export function useCanSeeMoney(): boolean {
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  return useMemo(() => {
    const op = getOperatorByEmail(operators, email);
    return canSeeMoney(op);
  }, [operators, email]);
}
