import { useCallback, useEffect, useState } from "react";
import { useLcmStore } from "@/store/lcm-store";
import {
  isTipVisible,
  loadHelpTipPrefs,
  saveHelpTipPrefs,
  type HelpTipPrefs,
} from "@/lib/lcm/help-tips";

export function useHelpTips() {
  const email = useLcmStore((s) => s.currentUserEmail);
  const [prefs, setPrefs] = useState<HelpTipPrefs>(() =>
    loadHelpTipPrefs(email),
  );

  useEffect(() => {
    setPrefs(loadHelpTipPrefs(email));
  }, [email]);

  const persist = useCallback(
    (next: HelpTipPrefs) => {
      setPrefs(next);
      saveHelpTipPrefs(email, next);
    },
    [email],
  );

  const showTip = useCallback(
    (id: string) => isTipVisible(prefs, id),
    [prefs],
  );

  const hideTip = useCallback(
    (id: string) => {
      if (prefs.hidden.includes(id)) return;
      persist({ ...prefs, hidden: [...prefs.hidden, id] });
    },
    [prefs, persist],
  );

  const showAllTips = useCallback(() => {
    persist({ showTips: true, hidden: [] });
  }, [persist]);

  const setShowTips = useCallback(
    (showTips: boolean) => {
      persist({ ...prefs, showTips });
    },
    [prefs, persist],
  );

  return {
    prefs,
    showTip,
    hideTip,
    showAllTips,
    setShowTips,
    tipsEnabled: prefs.showTips,
    hiddenCount: prefs.hidden.length,
  };
}
