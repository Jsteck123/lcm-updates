import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Cell,
} from "recharts";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { allMachines } from "@/lib/lcm/lists";
import { totalQuotedSeconds } from "@/lib/lcm/calculations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, Label } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  formatCurrency,
  formatPercent,
  formatSeconds,
  formatDateTime,
} from "@/lib/utils";
import { DayBonusPanel } from "@/components/day-bonus-panel";
import { formatWeekLabel, weekKeyFromDate } from "@/lib/lcm/day-bonus";

export const Route = createFileRoute("/reports")({
  component: ReportsPage,
});

type Period = "today" | "week" | "month" | "all";

function periodRange(period: Period): { start: Date; end: Date } {
  const end = new Date();
  end.setHours(23, 59, 59, 999);
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  if (period === "week") start.setDate(start.getDate() - 7);
  if (period === "month") start.setMonth(start.getMonth() - 1);
  if (period === "all") start.setFullYear(2020, 0, 1);
  return { start, end };
}

function ReportsPage() {
  const jobs = useLcmStore((s) => s.jobs);
  const downtimes = useLcmStore((s) => s.downtimes);
  const dayBonuses = useLcmStore((s) => s.dayBonuses);
  const weeklyPayouts = useLcmStore((s) => s.weeklyPayouts);
  const operators = useLcmStore((s) => s.operators);
  const markWeekPaid = useLcmStore((s) => s.markWeekPaid);
  const betaMode = useLcmStore((s) => s.settings.betaMode !== false);
  const settings = useLcmStore((s) => s.settings);
  const customLists = useLcmStore((s) => s.settings.customLists);
  const machines = useMemo(() => allMachines(customLists), [customLists]);
  const [period, setPeriod] = useState<Period>("all");
  const [tab, setTab] = useState<
    "utilization" | "performance" | "bonus" | "downtime" | "variance"
  >("utilization");
  const [bonusOp, setBonusOp] = useState("");

  const { start, end } = periodRange(period);

  const completed = useMemo(
    () =>
      jobs.filter((j) => {
        if (j.status !== "Completed") return false;
        const t = new Date(j.startTime).getTime();
        return t >= start.getTime() && t <= end.getTime();
      }),
    [jobs, start, end],
  );

  const utilData = useMemo(() => {
    return machines.map((m) => {
      const machineJobs = completed.filter(
        (j) => j.machine === m || j.machinesUsed.includes(m),
      );
      const actual = machineJobs.reduce((s, j) => {
        const n = Math.max(1, j.machinesUsed.length || 1);
        return s + (j.actualTime || 0) / n;
      }, 0);
      const quoted = machineJobs.reduce((s, j) => {
        const n = Math.max(1, j.machinesUsed.length || 1);
        return s + totalQuotedSeconds(j) / n;
      }, 0);
      const pause = downtimes
        .filter((d) => {
          if (d.machine !== m || !d.endTime) return false;
          const t = new Date(d.startTime).getTime();
          return t >= start.getTime() && t <= end.getTime();
        })
        .reduce((s, d) => {
          const a = new Date(d.startTime).getTime();
          const b = new Date(d.endTime!).getTime();
          return s + Math.max(0, (b - a) / 1000);
        }, 0);
      return {
        name: m.replace("HAAS ", "").replace("MAZAK ", "").slice(0, 14),
        full: m,
        actualHours: +(actual / 3600).toFixed(2),
        quotedHours: +(quoted / 3600).toFixed(2),
        pauseHours: +(pause / 3600).toFixed(2),
      };
    });
  }, [completed, downtimes, start, end, machines]);

  const operatorPerf = useMemo(() => {
    const map = new Map<
      string,
      { name: string; jobs: number; effSum: number; dayBonus: number }
    >();
    for (const j of completed) {
      const row = map.get(j.operator) || {
        name: j.operator,
        jobs: 0,
        effSum: 0,
        dayBonus: 0,
      };
      row.jobs += 1;
      row.effSum += j.efficiency > 1 ? j.efficiency / 100 : j.efficiency;
      map.set(j.operator, row);
    }
    // Attach finalized day bonuses in period
    for (const d of dayBonuses) {
      if (d.status !== "finalized" || !d.eligible) continue;
      const t = new Date(d.dateKey + "T12:00:00").getTime();
      if (t < start.getTime() || t > end.getTime()) continue;
      const row = map.get(d.operatorName) || {
        name: d.operatorName,
        jobs: 0,
        effSum: 0,
        dayBonus: 0,
      };
      row.dayBonus += d.bonus || 0;
      map.set(d.operatorName, row);
    }
    return [...map.values()]
      .map((r) => ({
        ...r,
        avgEff: r.jobs ? r.effSum / r.jobs : 0,
      }))
      .sort((a, b) => b.dayBonus - a.dayBonus || b.avgEff - a.avgEff);
  }, [completed, dayBonuses, start, end]);

  const variance = useMemo(() => {
    return completed.map((j) => {
      const quoted = totalQuotedSeconds(j);
      const actual = j.actualTime || 0;
      return {
        id: j.id,
        part: j.partNumber,
        operator: j.operator,
        machine: j.machine,
        quoted,
        actual,
        delta: actual - quoted,
        when: j.startTime,
      };
    });
  }, [completed]);

  const periodDt = useMemo(
    () =>
      downtimes.filter((d) => {
        const t = new Date(d.startTime).getTime();
        return t >= start.getTime() && t <= end.getTime();
      }),
    [downtimes, start, end],
  );

  const activeOps = useMemo(
    () => operators.filter((o) => o.active && o.role !== "admin" || o.active),
    [operators],
  );

  const selectedOp =
    bonusOp ||
    activeOps.find((o) => o.role === "operator")?.name ||
    activeOps[0]?.name ||
    "";

  const weekKey = weekKeyFromDate();
  const weeksSorted = useMemo(() => {
    return [...weeklyPayouts].sort((a, b) => b.weekKey.localeCompare(a.weekKey));
  }, [weeklyPayouts]);

  const daysSorted = useMemo(() => {
    return [...dayBonuses]
      .filter((d) => d.status === "finalized")
      .sort((a, b) => b.dateKey.localeCompare(a.dateKey));
  }, [dayBonuses]);

  const tabs = [
    { id: "utilization" as const, label: "Utilization" },
    { id: "performance" as const, label: "Operator perf" },
    { id: "bonus" as const, label: "Day / week bonus" },
    { id: "downtime" as const, label: "Downtime" },
    { id: "variance" as const, label: "Variance" },
  ];

  return (
    <div className="mx-auto max-w-7xl space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight">Reports</h1>
          <p className="text-sm text-[var(--color-muted)] mt-1">
            Utilization, day bonuses (full shift), weekly payouts, downtime
          </p>
        </div>
        <div className="space-y-1.5 w-full sm:w-48">
          <Label>Period</Label>
          <Select value={period} onChange={(e) => setPeriod(e.target.value as Period)}>
            <option value="today">Today</option>
            <option value="week">Last 7 days</option>
            <option value="month">Last 30 days</option>
            <option value="all">All time</option>
          </Select>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={`min-h-10 px-3 rounded-[var(--radius-md)] text-sm font-medium border ${
              tab === t.id
                ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)]"
                : "border-[var(--color-border)] text-[var(--color-muted)] hover:bg-[var(--color-surface-2)]"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "utilization" && (
        <Card>
          <CardHeader>
            <CardTitle>Machine utilization (hours)</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={utilData}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Bar dataKey="quotedHours" name="Quoted" fill="var(--color-primary)" />
                <Bar dataKey="actualHours" name="Actual" fill="var(--color-accent)" />
                <Bar dataKey="pauseHours" name="Pause" fill="var(--color-muted)" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {tab === "performance" && (
        <Card>
          <CardHeader>
            <CardTitle>Operator performance</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <table className="w-full text-sm min-w-[480px]">
              <thead>
                <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
                  <th className="pb-2 font-medium">Operator</th>
                  <th className="pb-2 font-medium">Jobs</th>
                  <th className="pb-2 font-medium">Avg job eff</th>
                  <th className="pb-2 font-medium text-right">Day bonuses</th>
                </tr>
              </thead>
              <tbody>
                {operatorPerf.map((r) => (
                  <tr
                    key={r.name}
                    className="border-b border-[var(--color-border)] last:border-0"
                  >
                    <td className="py-2.5 font-medium">{r.name || "—"}</td>
                    <td className="py-2.5">{r.jobs}</td>
                    <td className="py-2.5 tabular">{formatPercent(r.avgEff)}</td>
                    <td className="py-2.5 text-right tabular">
                      {formatCurrency(r.dayBonus)}
                    </td>
                  </tr>
                ))}
                {operatorPerf.length === 0 && (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-[var(--color-muted)]">
                      No data in this period
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}

      {tab === "bonus" && (
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">How day bonus works</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-[var(--color-muted)] space-y-2">
              <p>
                Bonus window is Settings shift ({settings.workDayStart}–{settings.workDayEnd}).
                Time before start or after end does <strong className="text-[var(--color-fg)]">not</strong> count.
                Lunch ({settings.lunchHours ?? 1}h) is excluded so the work day is{" "}
                <strong className="text-[var(--color-fg)]">8 hours</strong> on a 7–4 schedule.
                Full work day required (work + pause inside the window). Day % = earned ÷ worked.
              </p>
              <p>
                Bonus = earned-hour pool × tier % from Settings. Job numbers on the machine are
                progress only — cash is locked when the day is finalized, then paid{" "}
                <strong className="text-[var(--color-fg)]">weekly</strong>.
              </p>
              <p>
                End of shift: stop timer → pause (End of Shift) → save in progress if the job
                continues tomorrow → Finalize day.
              </p>
            </CardContent>
          </Card>

          <div className="flex flex-col sm:flex-row gap-3 sm:items-end">
            <div className="space-y-1.5 flex-1 max-w-sm">
              <Label>Operator</Label>
              <Select value={selectedOp} onChange={(e) => setBonusOp(e.target.value)}>
                {activeOps.map((o) => (
                  <option key={o.id} value={o.name}>
                    {o.name}
                  </option>
                ))}
              </Select>
            </div>
          </div>

          <DayBonusPanel operatorName={selectedOp} />

          <div className="grid lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Finalized days</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 max-h-80 overflow-y-auto">
                {daysSorted.map((d) => (
                  <div
                    key={d.id}
                    className="flex items-center justify-between gap-3 border-b border-[var(--color-border)] pb-2 last:border-0"
                  >
                    <div className="min-w-0">
                      <div className="font-medium text-sm">
                        {d.operatorName} · {d.dateKey}
                      </div>
                      <div className="text-xs text-[var(--color-muted)]">
                        {formatPercent(d.efficiency)} ·{" "}
                        {d.onShiftHours.toFixed(1)}h / {d.requiredShiftHours.toFixed(1)}h
                        {d.eligible ? "" : ` · ${d.eligibilityReason}`}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="tabular font-medium">
                        {d.eligible ? formatCurrency(d.bonus) : "$0.00"}
                      </div>
                      <Badge tone={d.eligible ? "success" : "neutral"}>
                        {d.eligible ? "Eligible" : "No bonus"}
                      </Badge>
                    </div>
                  </div>
                ))}
                {daysSorted.length === 0 && (
                  <p className="text-sm text-[var(--color-muted)] py-6 text-center">
                    No finalized days yet
                  </p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">
                  Weekly payouts · current {formatWeekLabel(weekKey)}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 max-h-80 overflow-y-auto">
                {weeksSorted.map((w) => (
                  <div
                    key={w.id}
                    className="flex items-center justify-between gap-3 border-b border-[var(--color-border)] pb-2 last:border-0"
                  >
                    <div>
                      <div className="font-medium text-sm">{w.operatorName}</div>
                      <div className="text-xs text-[var(--color-muted)]">
                        {formatWeekLabel(w.weekKey)} · {w.dayIds.length} day(s)
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="tabular font-semibold">
                        {formatCurrency(w.totalBonus)}
                      </span>
                      {w.status === "paid" ? (
                        <Badge tone="success">Paid</Badge>
                      ) : betaMode ? (
                        <Badge tone="warn">Beta · not paid</Badge>
                      ) : (
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => {
                            const res = markWeekPaid(w.operatorName, w.weekKey);
                            if (res.ok) toast.success("Marked paid");
                            else toast.error(res.error || "Failed");
                          }}
                        >
                          Mark paid
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
                {weeksSorted.length === 0 && (
                  <p className="text-sm text-[var(--color-muted)] py-6 text-center">
                    Finalize days to build weekly totals
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {tab === "downtime" && (
        <Card>
          <CardHeader>
            <CardTitle>Downtime log</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {periodDt.map((d) => (
              <div
                key={d.id}
                className="flex items-center justify-between gap-3 border-b border-[var(--color-border)] pb-2 last:border-0 text-sm"
              >
                <div>
                  <div className="font-medium">{d.reason}</div>
                  <div className="text-xs text-[var(--color-muted)]">
                    {d.operator} · {d.machine} · {formatDateTime(d.startTime)}
                  </div>
                </div>
                <div className="text-xs text-[var(--color-muted)]">
                  {d.endTime
                    ? formatSeconds(
                        (new Date(d.endTime).getTime() -
                          new Date(d.startTime).getTime()) /
                          1000,
                      )
                    : "open"}
                </div>
              </div>
            ))}
            {periodDt.length === 0 && (
              <p className="text-sm text-[var(--color-muted)] py-6 text-center">
                No downtime in period
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {tab === "variance" && (
        <Card>
          <CardHeader>
            <CardTitle>Quoted vs actual</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <table className="w-full text-sm min-w-[560px]">
              <thead>
                <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
                  <th className="pb-2 font-medium">Part</th>
                  <th className="pb-2 font-medium">Operator</th>
                  <th className="pb-2 font-medium text-right">Quoted</th>
                  <th className="pb-2 font-medium text-right">Actual</th>
                  <th className="pb-2 font-medium text-right">Δ</th>
                </tr>
              </thead>
              <tbody>
                {variance.map((v) => (
                  <tr
                    key={v.id}
                    className="border-b border-[var(--color-border)] last:border-0"
                  >
                    <td className="py-2.5 font-medium">{v.part}</td>
                    <td className="py-2.5">{v.operator}</td>
                    <td className="py-2.5 text-right tabular">
                      {formatSeconds(v.quoted)}
                    </td>
                    <td className="py-2.5 text-right tabular">
                      {formatSeconds(v.actual)}
                    </td>
                    <td className="py-2.5 text-right tabular">
                      <span
                        className={
                          v.delta > 0
                            ? "text-[var(--color-danger)]"
                            : "text-[var(--color-success)]"
                        }
                      >
                        {v.delta > 0 ? "+" : ""}
                        {formatSeconds(v.delta)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
