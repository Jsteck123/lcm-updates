import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Printer, ArrowLeft } from "lucide-react";
import { barcodeToDataUrl, scanUrlForBarcode } from "@/lib/lcm/barcode";
import { Button } from "@/components/ui/button";
import { useLcmStore } from "@/store/lcm-store";

/** Practice barcode for printing a test label — not auto-written into live inventory */
export const SAMPLE_BARCODE = "LCM-SAMPLE-01";

const LOCAL_SAMPLE = {
  barcode: SAMPLE_BARCODE,
  material: "Aluminum",
  materialType: "T6 6061",
  stockShape: "Round Stock",
  sizeNote: '1.5" dia x 12 ft',
  remainingLength: 144,
  originalLength: 144,
  location: "Rack A-1",
  unit: "in" as const,
};

export const Route = createFileRoute("/sample-label")({
  component: SampleLabelPage,
});

function SampleLabelPage() {
  const stockPieces = useLcmStore((s) => s.stockPieces || []);
  const [qr, setQr] = useState("");
  const [origin, setOrigin] = useState("");

  // Prefer a real piece if you already received one with this barcode; otherwise local print-only sample
  const piece =
    stockPieces.find((p) => p.barcode === SAMPLE_BARCODE) || LOCAL_SAMPLE;

  useEffect(() => {
    const o = window.location.origin;
    setOrigin(o);
    const url = scanUrlForBarcode(SAMPLE_BARCODE, o);
    void barcodeToDataUrl(url, 220).then(setQr);
  }, []);

  return (
    <div className="mx-auto max-w-lg space-y-5 pb-10">
      <div className="print:hidden flex items-center gap-2">
        <Link
          to="/inventory"
          className="inline-flex items-center gap-1.5 text-sm text-[var(--color-muted)] hover:text-[var(--color-fg)] min-h-11"
        >
          <ArrowLeft className="h-4 w-4" /> Inventory
        </Link>
      </div>

      <div className="print:hidden">
        <h1 className="text-2xl font-semibold tracking-tight">
          Sample barcode label
        </h1>
        <p className="text-sm text-[var(--color-muted)] mt-1">
          Print this to test phone scan. It does not add stock to inventory by
          itself — receive real material under Inventory / Buy.
        </p>
      </div>

      <div className="rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-white text-black p-6 print:border-0 print:shadow-none">
        <div className="text-center space-y-3">
          <div className="text-xs font-semibold tracking-wide uppercase">
            Lake Country Machine
          </div>
          <div className="text-lg font-bold font-mono">{piece.barcode}</div>
          {qr ? (
            <img
              src={qr}
              alt="Barcode QR"
              className="mx-auto h-44 w-44 object-contain"
            />
          ) : (
            <div className="h-44 flex items-center justify-center text-sm text-neutral-500">
              Generating…
            </div>
          )}
          <div className="text-sm">
            <div className="font-medium">
              {piece.material} {piece.materialType}
            </div>
            <div>
              {piece.stockShape} · {piece.sizeNote}
            </div>
            <div className="text-xs text-neutral-600 mt-1">
              Loc {piece.location} ·{" "}
              {piece.remainingLength}/{piece.originalLength} {piece.unit}
            </div>
          </div>
          {origin && (
            <div className="text-[10px] text-neutral-500 break-all print:hidden">
              Scan opens: {scanUrlForBarcode(SAMPLE_BARCODE, origin)}
            </div>
          )}
        </div>
      </div>

      <div className="print:hidden flex gap-2">
        <Button type="button" onClick={() => window.print()}>
          <Printer className="h-4 w-4" /> Print label
        </Button>
      </div>
    </div>
  );
}
