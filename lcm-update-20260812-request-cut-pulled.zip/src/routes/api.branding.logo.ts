import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/branding/logo")({
  server: {
    handlers: {
      GET: async () => {
        const { readLogoBinary } = await import("@/lib/lcm/branding.server");
        const file = readLogoBinary();
        if (!file) {
          return new Response("No custom logo", { status: 404 });
        }
        return new Response(new Uint8Array(file.buffer), {
          status: 200,
          headers: {
            "Content-Type": file.meta.mime || "image/png",
            "Content-Length": String(file.buffer.length),
            "Cache-Control": "private, max-age=60",
          },
        });
      },
    },
  },
});
