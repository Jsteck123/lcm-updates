import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Printer } from "lucide-react";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { barcodeToDataUrl, scanUrlForBarcode } from "@/lib/lcm/barcode";

export const Route = createFileRoute("/labels")({
  validateSearch: (search: Record<string, unknown>) => ({
    ids: typeof search.ids === "string" ? search.ids : "",
  }),
  component: LabelsPage,
});

/** 0.5" × 1" sticker sheet — browser print */
function LabelsPage() {
  const { ids } = Route.useSearch();
  const stockPieces = useLcmStore((s) => s.stockPieces || []);
  const [qrMap, setQrMap] = useState<Record<string, string>>({});

  const selected = useMemo(() => {
    const idSet = new Set(
      ids
        .split(",")
        .map((x) => x.trim())
        .filter(Boolean),
    );
    if (idSet.size === 0) {
      const avail = stockPieces.filter((p) => p.status === "available");
      return (avail.length ? avail : stockPieces).slice(0, 40);
    }
    return stockPieces.filter((p) => idSet.has(p.id) || idSet.has(p.barcode));
  }, [ids, stockPieces]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const next: Record<string, string> = {};
      for (const p of selected) {
        const payload = scanUrlForBarcode(p.barcode);
        next[p.id] = await barcodeToDataUrl(payload, 120);
      }
      if (!cancelled) setQrMap(next);
    })();
    return () => {
      cancelled = true;
    };
  }, [selected]);

  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3 print:hidden">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            Stock barcode labels
          </h1>
          <p className="text-xs text-[var(--color-muted)] print:hidden">
            Labels to print: {selected.length} · pieces in shop: {stockPieces.length}
          </p>
          <p className="text-sm text-[var(--color-muted)] mt-1">
            Sized for ~0.5" × 1" stickers. Print, cut, stick on each
            piece. Scan opens the cut page on a phone.
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => window.print()}>
            <Printer className="h-4 w-4" /> Print
          </Button>
          <Link
            to="/scan"
            search={{ c: "" }}
            className="inline-flex items-center rounded-[var(--radius-md)] border border-[var(--color-border)] px-4 py-2.5 text-sm min-h-11"
          >
            Scan page
          </Link>
        </div>
      </div>

      {selected.length === 0 ? (
        <p className="text-[var(--color-muted)] print:hidden">
          No pieces to print. Receive material on a PO first.
        </p>
      ) : (
        <div className="label-sheet">
          {selected.map((p) => (
            <div key={p.id} className="stock-label">
              {qrMap[p.id] ? (
                <img src={qrMap[p.id]} alt={p.barcode} className="label-qr" />
              ) : (
                <div className="label-qr placeholder" />
              )}
              <div className="label-text">
                <div className="label-code">{p.barcode}</div>
                <div className="label-mat">
                  {p.material} {p.materialType}
                </div>
                <div className="label-size">
                  {p.sizeNote || `${p.originalLength}"`}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <style>{`
        .label-sheet {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }
        .stock-label {
          width: 1in;
          height: 0.5in;
          border: 1px solid #222;
          display: flex;
          align-items: center;
          gap: 2px;
          padding: 2px;
          box-sizing: border-box;
          background: #fff;
          color: #000;
          overflow: hidden;
          page-break-inside: avoid;
        }
        .label-qr {
          width: 0.42in;
          height: 0.42in;
          object-fit: contain;
          flex-shrink: 0;
        }
        .label-qr.placeholder {
          background: #eee;
        }
        .label-text {
          min-width: 0;
          flex: 1;
          line-height: 1.05;
        }
        .label-code {
          font-family: ui-monospace, monospace;
          font-size: 6.5px;
          font-weight: 700;
        }
        .label-mat {
          font-size: 5.5px;
          font-weight: 600;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .label-size {
          font-size: 5px;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        @media print {
          body * { visibility: hidden; }
          .label-sheet, .label-sheet * { visibility: visible; }
          .label-sheet {
            position: absolute;
            left: 0;
            top: 0;
            gap: 4px;
          }
          .print\\:hidden { display: none !important; }
        }
      `}</style>
    </div>
  );
}
