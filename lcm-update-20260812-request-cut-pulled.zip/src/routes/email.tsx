import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  Mail,
  Send,
  Copy,
  Printer,
  Check,
  Filter,
  Eye,
} from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { HelpTip } from "@/components/ui/help-tip";
import { Input, Label, Select, Textarea } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatDate } from "@/lib/utils";
import {
  buildQuoteEmailDraft,
  copyQuoteEmailRich,
  customerEmailList,
  localDateKey,
  mailtoUrl,
  openQuoteEmailEml,
  quoteEmailHtml,
  quoteEmailPlainText,
  quoteEmailSubject,
  sortCustomersForEmail,
  todayLocalKey,
} from "@/lib/lcm/quote-email";
import { QuoteLetter } from "@/components/lcm/quote-letter";

export const Route = createFileRoute("/email")({
  validateSearch: (s: Record<string, unknown>) => ({
    quoteId: typeof s.quoteId === "string" ? s.quoteId : "",
    part: typeof s.part === "string" ? s.part : "",
  }),
  component: EmailQuotesPage,
});

function EmailQuotesPage() {
  const { quoteId: preQuoteId, part: prePart } = Route.useSearch();
  const navigate = useNavigate();
  const quotes = useLcmStore((s) => s.quotes);
  const customers = useLcmStore((s) => s.customers);
  const company = useLcmStore((s) => s.settings.companyName);
  const fromEmail = useLcmStore((s) => s.settings.quoteFromEmail || "");
  const markEmailed = useLcmStore((s) => s.markCustomerEmailed);
  const logEmailSend = useLcmStore((s) => s.logEmailSend);
  const emailLog = useLcmStore((s) => s.emailLog || []);
  const upsertCustomer = useLcmStore((s) => s.upsertCustomer);

  const [customerFilter, setCustomerFilter] = useState<string>("all");
  const [dateFilter, setDateFilter] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [recipientCustomerId, setRecipientCustomerId] = useState("");
  const [toEmail, setToEmail] = useState("");
  const [customTo, setCustomTo] = useState("");
  const [notes, setNotes] = useState(
    "Thank you for the opportunity to quote. Lead times confirmed at order. Please reply with PO or questions.",
  );
  const [step, setStep] = useState<"pick" | "send">("pick");

  // From Master Quoter: open with this part already selected
  useEffect(() => {
    if (!preQuoteId && !prePart) return;
    const q =
      (preQuoteId && quotes.find((x) => x.id === preQuoteId)) ||
      (prePart &&
        quotes.find(
          (x) => x.partNumber.toLowerCase() === prePart.toLowerCase(),
        ));
    if (!q) {
      toast.error("Quote not found — save it on Master Quoter first");
      void navigate({ to: "/email", search: { quoteId: "", part: "" }, replace: true });
      return;
    }
    setSelected(new Set([q.id]));
    if (q.customer) setCustomerFilter(q.customer);
    setDateFilter(""); // show regardless of date when deep-linked
    void navigate({ to: "/email", search: { quoteId: "", part: "" }, replace: true });
  }, [preQuoteId, prePart, quotes, navigate]);

  const customerNames = useMemo(() => {
    const set = new Set(quotes.map((q) => q.customer).filter(Boolean));
    return [...set].sort((a, b) => a.localeCompare(b));
  }, [quotes]);

  const filteredQuotes = useMemo(() => {
    return quotes
      .filter((q) => {
        if (customerFilter !== "all" && q.customer !== customerFilter) return false;
        if (dateFilter) {
          const d = localDateKey(q.date);
          if (d !== dateFilter) return false;
        }
        return true;
      })
      .sort((a, b) => {
        const t = new Date(b.date).getTime() - new Date(a.date).getTime();
        if (t !== 0) return t;
        return a.partNumber.localeCompare(b.partNumber);
      });
  }, [quotes, customerFilter, dateFilter]);

  const selectedQuotes = useMemo(
    () => quotes.filter((q) => selected.has(q.id)),
    [quotes, selected],
  );

  const sortedCustomers = useMemo(
    () => sortCustomersForEmail(customers),
    [customers],
  );

  const recipientCustomer = useMemo(
    () => customers.find((c) => c.id === recipientCustomerId),
    [customers, recipientCustomerId],
  );

  const recipientEmails = useMemo(
    () => customerEmailList(recipientCustomer),
    [recipientCustomer],
  );

  const inferredCustomerName = useMemo(() => {
    if (selectedQuotes.length === 0) return "";
    const names = [...new Set(selectedQuotes.map((q) => q.customer).filter(Boolean))];
    return names[0] || "";
  }, [selectedQuotes]);

  const draftCustomerName =
    recipientCustomer?.name ||
    inferredCustomerName ||
    (customerFilter !== "all" ? customerFilter : "Customer");

  const draft = useMemo(
    () =>
      buildQuoteEmailDraft({
        companyName: company,
        customerName: draftCustomerName,
        quotes: selectedQuotes,
        notes,
      }),
    [company, draftCustomerName, selectedQuotes, notes],
  );

  const subject = quoteEmailSubject(draft, draft.parts.length);
  const plain = quoteEmailPlainText(draft);
  const finalTo = (customTo.trim() || toEmail).trim();

  function toggle(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function selectAllFiltered() {
    setSelected(new Set(filteredQuotes.map((q) => q.id)));
  }

  function clearSelection() {
    setSelected(new Set());
  }

  function goToSend() {
    if (selectedQuotes.length === 0) {
      toast.error("Select at least one quote");
      return;
    }
    const name = inferredCustomerName;
    const match = customers.find(
      (c) => c.name.toLowerCase() === name.toLowerCase(),
    );
    if (match) {
      setRecipientCustomerId(match.id);
      const emails = customerEmailList(match);
      setToEmail(emails[0] || "");
      setCustomTo("");
    } else if (sortedCustomers[0]) {
      setRecipientCustomerId(sortedCustomers[0].id);
      const emails = customerEmailList(sortedCustomers[0]);
      setToEmail(emails[0] || "");
    }
    setStep("send");
  }

  function onRecipientCustomerChange(id: string) {
    setRecipientCustomerId(id);
    const c = customers.find((x) => x.id === id);
    const emails = customerEmailList(c);
    setToEmail(emails[0] || "");
    setCustomTo("");
  }

  async function openMailClient() {
    if (!finalTo || !finalTo.includes("@")) {
      toast.error("Choose or enter a recipient email");
      return;
    }
    if (selectedQuotes.length === 0) {
      toast.error("No quotes selected");
      return;
    }

    // Primary: .eml with HTML tables (same boxed layout as print) for Outlook.
    // mailto: cannot carry HTML — that was the plain "QTY 5 10" dump.
    const eml = openQuoteEmailEml({
      to: finalTo,
      from: fromEmail || undefined,
      subject,
      draft,
    });
    // Also put boxed HTML on clipboard for Gmail web / paste if needed
    await copyQuoteEmailRich(draft);

    if (!eml.ok) {
      toast.error(eml.error || "Could not build formatted email");
      return;
    }

    if (recipientCustomerId) {
      markEmailed(recipientCustomerId, finalTo);
    }
    logEmailSend({
      customer: draft.customerName || customerFilter,
      toEmail: finalTo,
      subject,
      quoteIds: selectedQuotes.map((q) => q.id),
      partNumbers: selectedQuotes.map((q) => q.partNumber),
      method: "mailto",
    });
    toast.success(
      "Formatted quote ready — open the .eml download (Outlook shows the boxes). Clipboard has the same letter if you paste.",
    );
  }

  /** Last-resort plain mailto (no tables). Prefer .eml / Copy formatted. */
  function openPlainMailto() {
    if (!finalTo || !finalTo.includes("@")) {
      toast.error("Choose or enter a recipient email");
      return;
    }
    const url = mailtoUrl(finalTo, subject, plain);
    window.location.href = url;
    toast.message("Plain-text mail opened — use Open formatted email for tables");
  }

  async function copyBody() {
    const r = await copyQuoteEmailRich(draft);
    if (!r.ok) {
      toast.error(r.error || "Could not copy");
      return;
    }
    if (selectedQuotes.length) {
      logEmailSend({
        customer: draft.customerName || customerFilter,
        toEmail: finalTo || "(copied)",
        subject,
        quoteIds: selectedQuotes.map((q) => q.id),
        partNumbers: selectedQuotes.map((q) => q.partNumber),
        method: "copy",
      });
    }
    toast.success(
      "Formatted quote copied (tables match print) — paste into Outlook / Gmail",
    );
  }

  async function copyHtmlFile() {
    // Secondary: download .html if user wants to attach or open in browser
    try {
      const html = quoteEmailHtml(draft);
      const blob = new Blob([html], { type: "text/html;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `quote-${(draft.customerName || "customer").replace(/[^a-z0-9]+/gi, "-").slice(0, 40)}.html`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("HTML letter downloaded — open or attach; matches print layout");
    } catch {
      toast.error("Could not download HTML");
    }
  }

  function printPreview() {
    window.print();
    if (selectedQuotes.length) {
      logEmailSend({
        customer: draft.customerName || customerFilter,
        toEmail: finalTo || "(print)",
        subject,
        quoteIds: selectedQuotes.map((q) => q.id),
        partNumbers: selectedQuotes.map((q) => q.partNumber),
        method: "print",
      });
    }
  }

  function saveRecipientEmail() {
    if (!recipientCustomerId || !customTo.trim().includes("@")) {
      toast.error("Enter a valid email");
      return;
    }
    const c = customers.find((x) => x.id === recipientCustomerId);
    if (!c) return;
    const email = customTo.trim();
    const extras = [...(c.emails || [])];
    if (c.email && c.email.toLowerCase() !== email.toLowerCase()) {
      if (!extras.some((e) => e.toLowerCase() === email.toLowerCase())) {
        extras.push(email);
      }
    }
    upsertCustomer({
      ...c,
      email: c.email || email,
      emails: extras,
    });
    setToEmail(email);
    setCustomTo("");
    toast.success("Email saved on customer");
  }

  return (
    <div className="mx-auto max-w-6xl space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 print:hidden">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight flex items-center gap-2">
            <Mail className="h-7 w-7 text-[var(--color-primary)]" />
            Email Quotes
            <HelpTip id="email-batch" />
          </h1>
          <p className="text-sm text-[var(--color-muted)] mt-1">
            Customer sees part #, rev, qty breaks, and price each — plus any
            soft jaws / tools you chose to bill as separate lines. Setup times
            and material costs stay internal. Batch · preview · send via mail.
          </p>
        </div>
        {step === "send" && (
          <Button variant="outline" onClick={() => setStep("pick")}>
            ← Back to selection
          </Button>
        )}
      </div>

      {step === "pick" && (
        <>
          <Card className="print:hidden">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Filter className="h-4 w-4" /> Filter quotes
              </CardTitle>
            </CardHeader>
            <CardContent className="grid sm:grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label>Customer</Label>
                <Select
                  value={customerFilter}
                  onChange={(e) => setCustomerFilter(e.target.value)}
                >
                  <option value="all">All customers</option>
                  {customerNames.map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))}
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Date quoted (blank = any)</Label>
                <Input
                  type="date"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                />
              </div>
              <div className="flex items-end gap-2">
                <Button
                  type="button"
                  variant="secondary"
                  className="flex-1"
                  onClick={() => setDateFilter(todayLocalKey())}
                >
                  Today
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setDateFilter("")}
                >
                  Any date
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="print:hidden">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
              <CardTitle className="text-base">
                Select quotes ({selected.size} selected)
              </CardTitle>
              <div className="flex gap-2">
                <Button type="button" size="sm" variant="outline" onClick={selectAllFiltered}>
                  Select filtered
                </Button>
                <Button type="button" size="sm" variant="ghost" onClick={clearSelection}>
                  Clear
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-2 max-h-[420px] overflow-y-auto">
              {filteredQuotes.length === 0 ? (
                <p className="text-sm text-[var(--color-muted)] py-4">
                  No quotes match. Save quotes on Master Quoter first, or clear
                  the date filter.
                </p>
              ) : (
                filteredQuotes.map((q) => {
                  const on = selected.has(q.id);
                  return (
                    <button
                      key={q.id}
                      type="button"
                      onClick={() => toggle(q.id)}
                      className={`w-full text-left rounded-[var(--radius-md)] border px-3 py-2.5 flex items-start gap-3 min-h-12 transition-colors ${
                        on
                          ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_12%,transparent)]"
                          : "border-[var(--color-border)] hover:bg-[var(--color-surface-2)]"
                      }`}
                    >
                      <span
                        className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border ${
                          on
                            ? "border-[var(--color-primary)] bg-[var(--color-primary)] text-[var(--color-primary-fg)]"
                            : "border-[var(--color-border-strong)]"
                        }`}
                      >
                        {on ? <Check className="h-3.5 w-3.5" /> : null}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="font-mono font-semibold text-sm">
                          {q.partNumber}{" "}
                          <span className="font-sans font-normal text-[var(--color-muted)]">
                            Rev {q.revision || "—"}
                          </span>
                        </div>
                        <div className="text-xs text-[var(--color-muted)]">
                          {q.customer || "No customer"} · {formatDate(q.date)}
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-1 shrink-0">
                        <Badge tone={on ? "info" : "neutral"}>
                          {(q.quantities || []).filter((n) => n > 0).length} qty
                          breaks
                        </Badge>
                        {(q.toolingCharges || []).some((c) => c.billCustomer) ? (
                          <Badge tone="warn">
                            {(q.toolingCharges || []).filter((c) => c.billCustomer).length} tooling
                            bill
                          </Badge>
                        ) : (q.toolingCharges || []).some((c) => (c.shopCost || 0) > 0) ? (
                          <Badge tone="neutral">tooling stored</Badge>
                        ) : null}
                      </div>
                    </button>
                  );
                })
              )}
            </CardContent>
          </Card>

          <div className="flex justify-end print:hidden">
            <Button type="button" onClick={goToSend} disabled={selected.size === 0}>
              Preview & send <Eye className="h-4 w-4" />
            </Button>
          </div>
        </>
      )}

      {step === "send" && (
        <div className="grid lg:grid-cols-2 gap-4">
          <Card className="print:hidden">
            <CardHeader>
              <CardTitle className="text-base">Recipient</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1.5">
                <Label>Customer</Label>
                <Select
                  value={recipientCustomerId}
                  onChange={(e) => onRecipientCustomerChange(e.target.value)}
                >
                  <option value="">— Select —</option>
                  {sortedCustomers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                      {c.lastEmailedAt ? " · recent" : ""}
                    </option>
                  ))}
                </Select>
              </div>
              {recipientEmails.length > 0 && (
                <div className="space-y-1.5">
                  <Label>Their email</Label>
                  <Select value={toEmail} onChange={(e) => setToEmail(e.target.value)}>
                    {recipientEmails.map((e) => (
                      <option key={e} value={e}>
                        {e}
                      </option>
                    ))}
                  </Select>
                </div>
              )}
              <div className="space-y-1.5">
                <Label>Or type email</Label>
                <div className="flex gap-2">
                  <Input
                    type="email"
                    value={customTo}
                    onChange={(e) => setCustomTo(e.target.value)}
                    placeholder="buyer@customer.com"
                  />
                  <Button type="button" variant="outline" onClick={saveRecipientEmail}>
                    Save
                  </Button>
                </div>
              </div>
              {fromEmail ? (
                <p className="text-xs text-[var(--color-subtle)]">
                  From (your shop): {fromEmail}
                </p>
              ) : null}
              <div className="space-y-1.5">
                <Label>Note on email</Label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                />
              </div>
              <div className="flex flex-wrap gap-2 pt-1">
                <Button type="button" onClick={() => void openMailClient()}>
                  <Send className="h-4 w-4" /> Open formatted email
                </Button>
                <Button type="button" variant="secondary" onClick={() => void copyBody()}>
                  <Copy className="h-4 w-4" /> Copy tables
                </Button>
                <Button type="button" variant="outline" onClick={printPreview}>
                  <Printer className="h-4 w-4" /> Print
                </Button>
                <Button type="button" variant="ghost" onClick={() => void copyHtmlFile()}>
                  Download HTML
                </Button>
              </div>
              <p className="text-[11px] text-[var(--color-subtle)] leading-relaxed">
                <strong className="text-[var(--color-fg)]">Open formatted email</strong> downloads
                an Outlook draft (.eml) with the same boxed tables as print — not the plain
                QTY line dump. Open the download if the browser saves it.{" "}
                <button
                  type="button"
                  className="underline underline-offset-2 text-[var(--color-muted)] hover:text-[var(--color-fg)]"
                  onClick={openPlainMailto}
                >
                  Plain mailto only
                </button>
              </p>
            </CardContent>
          </Card>

          <Card className="print:border-0 print:shadow-none print:bg-transparent">
            <CardHeader className="print:hidden">
              <CardTitle className="text-base">Customer preview</CardTitle>
              <p className="text-xs text-[var(--color-muted)]">
                Subject: {subject}
              </p>
              <p className="text-xs text-[var(--color-muted)]">
                This is exactly what print uses — and what Copy formatted puts on the clipboard.
              </p>
            </CardHeader>
            <CardContent className="space-y-4 print:p-0">
              <QuoteLetter draft={draft} printRoot />

              <details className="print:hidden text-xs text-[var(--color-subtle)]">
                <summary className="cursor-pointer hover:text-[var(--color-muted)]">
                  Plain-text fallback (mailto apps that cannot take HTML)
                </summary>
                <pre className="mt-2 whitespace-pre-wrap font-mono leading-relaxed rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3">
                  {plain}
                </pre>
              </details>
              <p className="print:hidden text-[11px] text-[var(--color-subtle)]">
                Customer gets part #, rev, qty, price each, and any billed soft
                jaws / tools as separate lines — not material %, machine times,
                or internal shop costs.
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      <style>{`
        @media print {
          @page { margin: 0.5in; }
          body * { visibility: hidden !important; }
          #quote-email-print,
          #quote-email-print * {
            visibility: visible !important;
          }
          #quote-email-print {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            max-width: none !important;
            margin: 0 !important;
            border: none !important;
            box-shadow: none !important;
            background: white !important;
            color: black !important;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          .quote-part-block {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
          }
          .quote-letter > * {
            break-inside: avoid;
            page-break-inside: avoid;
          }
          /* Allow multi-part letter to flow pages, but never split a part mid-block */
          .quote-letter {
            break-inside: auto;
            page-break-inside: auto;
          }
        }
      `}</style>

      {emailLog.length > 0 && (
        <Card className="print:hidden">
          <CardHeader>
            <CardTitle className="text-base">Recent sends</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-xs">
            {emailLog.slice(0, 8).map((row) => (
              <div
                key={row.id}
                className="flex flex-wrap justify-between gap-2 border-b border-[var(--color-border)] pb-1.5 last:border-0"
              >
                <span>
                  {row.toEmail} · {row.partNumbers?.join(", ")}
                </span>
                <span className="text-[var(--color-muted)]">
                  {formatDate(row.sentAt)} · {row.method}
                </span>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
