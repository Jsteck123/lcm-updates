import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/branding/manifest")({
  server: {
    handlers: {
      GET: async () => {
        const { buildWebManifest } = await import("@/lib/lcm/branding.server");
        const body = buildWebManifest();
        return new Response(body, {
          status: 200,
          headers: {
            "Content-Type": "application/manifest+json; charset=utf-8",
            "Cache-Control": "private, max-age=30",
          },
        });
      },
    },
  },
});
