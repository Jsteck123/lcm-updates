import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Factory, Play, Pause, Plus } from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { allMachines } from "@/lib/lcm/lists";
import { machineToSlug } from "@/lib/lcm/machines";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CreatableSelect } from "@/components/ui/creatable-select";
import { formatPercent, formatSeconds } from "@/lib/utils";
import { queueForMachine, queueForOperator, openQueue } from "@/lib/lcm/work-queue";
import {
  machineSessionStatus,
  statusSurfaceClass,
  statusToBadgeTone,
} from "@/lib/lcm/status-colors";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/machines/")({
  component: MachinesPage,
});

function MachinesPage() {
  const sessions = useLcmStore((s) => s.sessions);
  const activeTimers = useLcmStore((s) => s.activeTimers);
  const customLists = useLcmStore((s) => s.settings.customLists);
  const addCustomListItem = useLcmStore((s) => s.addCustomListItem);
  const getLive = useLcmStore((s) => s.getLiveElapsedSeconds);
  const workQueue = useLcmStore((s) => s.workQueue || []);
  const operators = useLcmStore((s) => s.operators);
  const currentUserEmail = useLcmStore((s) => s.currentUserEmail);
  const startWorkQueueItem = useLcmStore((s) => s.startWorkQueueItem);
  const [, tick] = useState(0);
  const [showAdd, setShowAdd] = useState(false);
  const [viewOp, setViewOp] = useState<string>("");

  const machines = useMemo(() => allMachines(customLists), [customLists]);
  const me = operators.find(
    (o) => o.email.toLowerCase() === currentUserEmail.toLowerCase(),
  );
  const myQueue = useMemo(() => {
    const name = viewOp || me?.name || "";
    return name ? queueForOperator(workQueue, name) : openQueue(workQueue).slice(0, 12);
  }, [workQueue, viewOp, me?.name]);

  useEffect(() => {
    const id = setInterval(() => tick((n) => n + 1), 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight">Shop Floor</h1>
          <p className="text-sm text-[var(--color-muted)] mt-1">
            Select a machine to log in, load a part, and run setup / runtime timers.
          </p>
        </div>
        <Button variant="secondary" onClick={() => setShowAdd((v) => !v)}>
          <Plus className="h-4 w-4" /> Add machine
        </Button>
      </div>

      {showAdd && (
        <Card>
          <CardContent className="p-4 max-w-md space-y-2">
            <p className="text-sm text-[var(--color-muted)]">
              Add a new machine to the floor list (also available from Quoting).
            </p>
            <CreatableSelect
              value=""
              options={machines}
              allowEmpty
              emptyLabel="— Pick Add new… —"
              onChange={() => {}}
              onCreate={(v) => {
                const r = addCustomListItem("machines", v);
                if (!r.ok) {
                  toast.error(r.error);
                  return false;
                }
                toast.success(`Added ${v}`);
                setShowAdd(false);
              }}
              createTitle="Add machine"
              createHint="Appears on shop floor and quoting machine lists."
              normalize={(s) => s.trim().toUpperCase()}
            />
          </CardContent>
        </Card>
      )}

      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <div className="font-semibold text-sm">Running order</div>
              <p className="text-xs text-[var(--color-muted)]">
                What each machine or person is expected to run next (from Shop Orders).
              </p>
            </div>
            <select
              className="h-10 rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface)] px-3 text-sm min-w-[12rem]"
              value={viewOp}
              onChange={(e) => setViewOp(e.target.value)}
            >
              <option value="">All open / my list</option>
              {operators.filter((o) => o.active).map((o) => (
                <option key={o.id} value={o.name}>
                  {o.name}
                </option>
              ))}
            </select>
          </div>
          {myQueue.length === 0 ? (
            <p className="text-sm text-[var(--color-muted)]">
              Nothing queued. Assign lines from Shop Orders.
            </p>
          ) : (
            <div className="space-y-2 max-h-56 overflow-y-auto">
              {myQueue.map((q) => (
                <div
                  key={q.id}
                  className="flex flex-col sm:flex-row sm:items-center gap-2 rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2 text-sm"
                >
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">
                      {q.partNumber}{" "}
                      <span className="text-[var(--color-muted)] font-normal">
                        x{q.qty} · {q.machine}
                      </span>
                    </div>
                    <div className="text-xs text-[var(--color-muted)]">
                      PO {q.poNumber || "—"}
                      {q.operatorName ? ` · ${q.operatorName}` : ""}
                      {" · "}
                      {q.status}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        const r = startWorkQueueItem(q.id);
                        if (!r.ok) toast.error(r.error || "Failed");
                        else toast.success(`Loaded on ${q.machine}`);
                      }}
                    >
                      Load
                    </Button>
                    <Link
                      to="/machines/$machineId"
                      params={{ machineId: machineToSlug(q.machine) }}
                      className="inline-flex items-center rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 text-xs min-h-9"
                      onClick={(e) => e.stopPropagation()}
                    >
                      Machine
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3 sm:gap-4">
        {machines.map((m) => {
          const sess = sessions[m];
          const timer = activeTimers[m];
          const live = getLive(m);
          const qItems = queueForMachine(workQueue, m).slice(0, 3);
          const mStatus = machineSessionStatus({
            hasJob: Boolean(sess?.jobId),
            running: Boolean(timer),
            paused: Boolean(sess?.paused),
          });
          return (
            <Link
              key={m}
              to="/machines/$machineId"
              params={{ machineId: machineToSlug(m) }}
              className="group block"
            >
              <Card
                className={cn(
                  "h-full transition-colors border group-hover:border-[var(--color-border-strong)]",
                  statusSurfaceClass(mStatus),
                )}
              >
                <CardContent className="p-5 space-y-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="flex h-10 w-10 items-center justify-center rounded-[var(--radius-md)] bg-[var(--color-surface-3)] text-[var(--color-status-active)] shrink-0">
                        <Factory className="h-5 w-5" />
                      </div>
                      <div className="min-w-0">
                        <div className="font-semibold text-sm leading-snug">{m}</div>
                        <div className="text-xs text-[var(--color-muted)] truncate">
                          {sess?.operatorName || "No operator"}
                        </div>
                      </div>
                    </div>
                    {timer ? (
                      <Badge tone="active">
                        <Play className="h-3 w-3 mr-1" /> Live
                      </Badge>
                    ) : sess?.paused ? (
                      <Badge tone="hold">
                        <Pause className="h-3 w-3 mr-1" /> Paused
                      </Badge>
                    ) : sess?.jobId ? (
                      <Badge tone="open">On job</Badge>
                    ) : (
                      <Badge tone="neutral">Idle</Badge>
                    )}
                  </div>

                  <div className="rounded-[var(--radius-md)] bg-[var(--color-surface-2)] border border-[var(--color-border)] p-3 space-y-2">
                    <Row label="Part" value={sess?.partNumber || "—"} />
                    <Row
                      label="Rev / Qty"
                      value={`${sess?.revision || "—"} / ${sess?.quantity || 0}`}
                    />
                    <Row
                      label="Timer"
                      value={
                        timer
                          ? `${timer.type} ${timer.operation} · ${formatSeconds(live || 0)}`
                          : "—"
                      }
                      mono
                    />
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <span className="text-[var(--color-muted)]">Efficiency</span>
                    <span className="tabular font-medium">
                      {formatPercent(sess?.efficiency || 0)}
                    </span>
                  </div>

                  {qItems.length > 0 && (
                    <div className="space-y-1 border-t border-[var(--color-border)] pt-3">
                      <div className="text-[10px] uppercase tracking-wide text-[var(--color-muted)]">
                        Up next
                      </div>
                      {qItems.map((q, i) => (
                        <div
                          key={q.id}
                          className="text-xs flex justify-between gap-2"
                        >
                          <span className="truncate">
                            {i + 1}. {q.partNumber}
                            {q.operatorName ? ` (${q.operatorName})` : ""}
                          </span>
                          <span className="text-[var(--color-muted)] shrink-0">
                            x{q.qty}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>
    </div>
  );
}

function Row({
  label,
  value,
  mono,
}: {
  label: string;
  value: string;
  mono?: boolean;
}) {
  return (
    <div className="flex justify-between gap-3 text-xs">
      <span className="text-[var(--color-muted)]">{label}</span>
      <span
        className={
          mono ? "tabular font-medium text-right" : "font-medium text-right truncate"
        }
      >
        {value}
      </span>
    </div>
  );
}
