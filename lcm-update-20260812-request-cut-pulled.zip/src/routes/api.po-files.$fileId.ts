import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/po-files/$fileId")({
  server: {
    handlers: {
      GET: async ({ params, request }) => {
        const { verifyShopToken, readTokenFromHeaders } = await import(
          "@/lib/lcm/shop-session.server"
        );
        const token = readTokenFromHeaders(request.headers);
        const session = verifyShopToken(token);
        // Also accept query token for <img>/<a> navigations that can't set headers
        const url = new URL(request.url);
        const qToken = url.searchParams.get("token");
        const session2 = session || verifyShopToken(qToken);
        if (!session2) {
          return new Response("Unauthorized", { status: 401 });
        }

        const { readPoFileBinary } = await import(
          "@/lib/lcm/file-store.server"
        );
        const file = readPoFileBinary(params.fileId);
        if (!file) {
          return new Response("File not found", { status: 404 });
        }
        const mime = file.meta.mime || "application/octet-stream";
        return new Response(new Uint8Array(file.buffer), {
          status: 200,
          headers: {
            "Content-Type": mime,
            "Content-Length": String(file.buffer.length),
            "Content-Disposition": `inline; filename="${file.meta.name.replace(/"/g, "")}"`,
            "Cache-Control": "private, max-age=120",
          },
        });
      },
    },
  },
});
