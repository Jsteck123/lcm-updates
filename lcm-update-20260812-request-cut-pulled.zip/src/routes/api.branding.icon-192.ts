import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/branding/icon-192")({
  server: {
    handlers: {
      GET: async () => {
        const { readIconBinary } = await import("@/lib/lcm/branding.server");
        const file = readIconBinary(192);
        if (!file) {
          return new Response("No icon", { status: 404 });
        }
        return new Response(new Uint8Array(file.buffer), {
          status: 200,
          headers: {
            "Content-Type": file.mime || "image/png",
            "Content-Length": String(file.buffer.length),
            "Cache-Control": "private, max-age=60",
          },
        });
      },
    },
  },
});
