import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * UUID for clients. crypto.randomUUID is missing on non-HTTPS LAN
 * (e.g. http://192.168.x.x) — fall back so office PCs / phones work.
 */
export function uid() {
  try {
    const c = globalThis.crypto as Crypto | undefined;
    if (c && typeof c.randomUUID === "function") {
      return c.randomUUID();
    }
    if (c && typeof c.getRandomValues === "function") {
      const bytes = new Uint8Array(16);
      c.getRandomValues(bytes);
      bytes[6] = (bytes[6]! & 0x0f) | 0x40;
      bytes[8] = (bytes[8]! & 0x3f) | 0x80;
      const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join(
        "",
      );
      return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
    }
  } catch {
    /* fall through */
  }
  // Last resort — still unique enough for shop chat / local ids
  return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
}

export function formatCurrency(n: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
  }).format(n || 0);
}

export function formatPercent(n: number, digits = 1) {
  return `${((n || 0) * 100).toFixed(digits)}%`;
}

export function pad2(n: number) {
  return String(Math.floor(Math.abs(n))).padStart(2, "0");
}

/** Seconds → HH:MM:SS */
export function formatSeconds(totalSeconds: number) {
  const s = Math.max(0, Math.floor(totalSeconds || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${pad2(h)}:${pad2(m)}:${pad2(sec)}`;
}

/** Decimal minutes → HH:MM:SS */
export function minutesToTimeString(minutes: number) {
  if (!Number.isFinite(minutes) || minutes < 0) return "00:00:00";
  return formatSeconds(Math.round(minutes * 60));
}

/** HH:MM:SS or number(days fraction) or Date → seconds */
export function parseTimeToSeconds(time: unknown): number {
  if (time instanceof Date) {
    return time.getHours() * 3600 + time.getMinutes() * 60 + time.getSeconds();
  }
  if (typeof time === "number" && Number.isFinite(time)) {
    // fractional day (Sheets style) or already seconds if large
    if (time > 0 && time < 2) return time * 86400;
    return time;
  }
  if (typeof time === "string" && time && time !== "STARTED") {
    const parts = time.split(":").map(Number);
    if (parts.length >= 2 && parts.every((p) => !Number.isNaN(p))) {
      return (parts[0] || 0) * 3600 + (parts[1] || 0) * 60 + (parts[2] || 0);
    }
  }
  return 0;
}

/** HH:MM:SS or minutes number → decimal minutes */
export function timeToMinutes(time: unknown): number {
  if (typeof time === "number" && Number.isFinite(time)) return time;
  return parseTimeToSeconds(time) / 60;
}

export function formatDateTime(d: string | Date | null | undefined) {
  if (!d) return "—";
  const date = typeof d === "string" ? new Date(d) : d;
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat("en-US", {
    month: "2-digit",
    day: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export function formatDate(d: string | Date | null | undefined) {
  if (!d) return "—";
  const date = typeof d === "string" ? new Date(d) : d;
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat("en-US", {
    month: "2-digit",
    day: "2-digit",
    year: "numeric",
  }).format(date);
}
