/**
 * Saw cut tickets — quote size is estimate; floor enters CAD actuals.
 * Progressive qtyCut lets mills start before the full batch is sawn.
 */
import type {
  CutTicket,
  CutTicketStatus,
  CutProcess,
  LocAxis,
  ShopOrder,
  ShopOrderLine,
  Quote,
} from "./types";
import { uid } from "@/lib/utils";

export function locValueFromDims(
  process: CutProcess,
  locAxis: LocAxis,
  dims: {
    dimX: number;
    dimY: number;
    dimZ: number;
    diameter: number;
    locValue?: number;
  },
): number {
  if (process === "lathe" || locAxis === "dia") {
    return Number(dims.locValue) || 0;
  }
  if (locAxis === "x") return Number(dims.dimX) || 0;
  if (locAxis === "y") return Number(dims.dimY) || 0;
  if (locAxis === "z") return Number(dims.dimZ) || 0;
  return Number(dims.locValue) || 0;
}

export function cutTicketLabel(t: Pick<CutTicket, "process" | "locAxis" | "locValue" | "dimX" | "dimY" | "dimZ" | "diameter">): string {
  if (t.process === "lathe") {
    return `Ø${fmt(t.diameter)} × ${fmt(t.locValue)}" LOC`;
  }
  const axis = (t.locAxis || "z").toUpperCase();
  const section = [t.dimX, t.dimY, t.dimZ]
    .map((n, i) => ({ n, a: ["X", "Y", "Z"][i]! }))
    .filter((x) => x.n > 0)
    .map((x) => `${x.a}${fmt(x.n)}`)
    .join(" · ");
  return `LOC ${axis}=${fmt(t.locValue)}"${section ? ` · ${section}` : ""}`;
}

function fmt(n: number): string {
  if (!Number.isFinite(n) || n === 0) return "0";
  const r = Math.round(n * 1000) / 1000;
  return String(r);
}

export function qtyAvailable(t: Pick<CutTicket, "qtyCut" | "qtyClaimed">): number {
  return Math.max(0, (Number(t.qtyCut) || 0) - (Number(t.qtyClaimed) || 0));
}

export function deriveCutStatus(t: Pick<CutTicket, "status" | "qtyRequested" | "qtyCut" | "qtyClaimed">): CutTicketStatus {
  if (t.status === "cancelled" || t.status === "skipped") return t.status;
  const req = Number(t.qtyRequested) || 0;
  const cut = Number(t.qtyCut) || 0;
  if (cut <= 0) return "requested";
  if (req > 0 && cut >= req) return "done";
  if (cut > 0 && cut < req) return "partial";
  return t.status === "cutting" ? "cutting" : "partial";
}

export function emptyCutTicket(
  partial?: Partial<CutTicket>,
): CutTicket {
  const process = partial?.process || "mill";
  const locAxis = partial?.locAxis || (process === "lathe" ? "dia" : "z");
  const dims = {
    dimX: partial?.dimX ?? 0,
    dimY: partial?.dimY ?? 0,
    dimZ: partial?.dimZ ?? 0,
    diameter: partial?.diameter ?? 0,
    locValue: partial?.locValue,
  };
  const locValue =
    partial?.locValue != null && partial.locValue > 0
      ? partial.locValue
      : locValueFromDims(process, locAxis, dims);
  return {
    id: partial?.id || uid(),
    shopOrderId: partial?.shopOrderId || "",
    shopOrderLineId: partial?.shopOrderLineId || "",
    componentId: partial?.componentId || "",
    poNumber: partial?.poNumber || "",
    customer: partial?.customer || "",
    partNumber: partial?.partNumber || "",
    revision: partial?.revision || "",
    material: partial?.material || "",
    materialType: partial?.materialType || "",
    stockShape: partial?.stockShape || "",
    process,
    dimX: dims.dimX,
    dimY: dims.dimY,
    dimZ: dims.dimZ,
    diameter: dims.diameter,
    locAxis,
    locValue,
    qtyRequested: partial?.qtyRequested ?? 0,
    qtyCut: partial?.qtyCut ?? 0,
    qtyClaimed: partial?.qtyClaimed ?? 0,
    status: partial?.status || "requested",
    requestedBy: partial?.requestedBy || "",
    requestedAt: partial?.requestedAt || new Date().toISOString(),
    requestedMachine: partial?.requestedMachine || "",
    notes: partial?.notes || "",
    sawOperator: partial?.sawOperator || "",
    completedAt: partial?.completedAt || "",
    writeBackToQuote: Boolean(partial?.writeBackToQuote),
    writtenBackAt: partial?.writtenBackAt || "",
    dueDate: partial?.dueDate || "",
  };
}

/** Prefill ticket from order line + optional quote */
export function ticketFromLine(opts: {
  order: ShopOrder;
  line: ShopOrderLine;
  byName: string;
  machine?: string;
  componentId?: string;
  process?: CutProcess;
  quote?: Quote | null;
}): CutTicket {
  const { order, line, byName, machine, componentId, quote } = opts;
  const process = opts.process || guessProcess(line.stockShape, machine);
  const dimX = Number(line.dimX) || Number(quote?.dimX) || 0;
  const dimY = Number(line.dimY) || Number(quote?.dimY) || 0;
  const dimZ = Number(line.dimZ) || Number(quote?.dimZ) || 0;
  const partLen =
    Number(line.partLengthEach) || Number(quote?.partLengthEach) || 0;
  let locAxis: LocAxis = process === "lathe" ? "dia" : "z";
  let diameter = 0;
  if (process === "lathe") {
    diameter = dimX || dimY || 0;
  } else {
    // Prefer longest non-zero as default LOC axis
    const pairs: [LocAxis, number][] = [
      ["x", dimX],
      ["y", dimY],
      ["z", dimZ || partLen],
    ];
    pairs.sort((a, b) => b[1] - a[1]);
    if (pairs[0] && pairs[0][1] > 0) locAxis = pairs[0][0];
  }
  const locValue =
    process === "lathe"
      ? partLen || dimZ
      : locValueFromDims(process, locAxis, {
          dimX,
          dimY,
          dimZ: dimZ || partLen,
          diameter,
        });

  return emptyCutTicket({
    shopOrderId: order.id,
    shopOrderLineId: line.id,
    componentId: componentId || "",
    poNumber: order.poNumber || "",
    customer: order.customer || "",
    partNumber: line.partNumber || "",
    revision: line.revision || "",
    material: line.material || quote?.material || "",
    materialType: line.materialType || quote?.materialType || "",
    stockShape: line.stockShape || quote?.stockShape || "",
    process,
    dimX,
    dimY,
    dimZ: dimZ || partLen,
    diameter,
    locAxis,
    locValue,
    qtyRequested: Math.max(0, (Number(line.qty) || 0) - (Number(line.qtyCompleted) || 0)) || Number(line.qty) || 1,
    requestedBy: byName,
    requestedMachine: machine || line.checkedOutMachine || "",
    dueDate: line.dueDate || order.dateRequired || order.dueDate || "",
  });
}

function guessProcess(stockShape: string, machine?: string): CutProcess {
  const m = (machine || "").toLowerCase();
  if (m.includes("lathe")) return "lathe";
  if (m.includes("mill")) return "mill";
  const s = (stockShape || "").toLowerCase();
  if (s.includes("round") && !s.includes("tube")) return "lathe";
  return "mill";
}

export function openCutTickets(list: CutTicket[]): CutTicket[] {
  return (list || []).filter(
    (t) =>
      t.status !== "cancelled" &&
      t.status !== "skipped" &&
      !(t.status === "done" && qtyAvailable(t) <= 0 && (Number(t.qtyClaimed) || 0) >= (Number(t.qtyRequested) || 0)),
  );
}

export function activeCutTickets(list: CutTicket[]): CutTicket[] {
  return (list || []).filter(
    (t) =>
      t.status === "requested" ||
      t.status === "cutting" ||
      t.status === "partial" ||
      (t.status === "done" && qtyAvailable(t) > 0),
  );
}

export function ticketsForLine(
  list: CutTicket[],
  orderId: string,
  lineId: string,
  componentId?: string,
): CutTicket[] {
  return (list || []).filter(
    (t) =>
      t.shopOrderId === orderId &&
      t.shopOrderLineId === lineId &&
      (!componentId || t.componentId === componentId) &&
      t.status !== "cancelled",
  );
}

export function ticketsForPart(
  list: CutTicket[],
  partNumber: string,
): CutTicket[] {
  const pn = (partNumber || "").trim().toLowerCase();
  if (!pn) return [];
  return activeCutTickets(list).filter(
    (t) => t.partNumber.toLowerCase() === pn,
  );
}

/** Size-note style string for quote write-back */
export function sizeNoteFromTicket(t: CutTicket): string {
  if (t.process === "lathe") {
    return `Ø${fmt(t.diameter)} × ${fmt(t.locValue)}" LOC`;
  }
  const bits = [
    t.dimX > 0 ? `${fmt(t.dimX)}"` : "",
    t.dimY > 0 ? `${fmt(t.dimY)}"` : "",
    t.dimZ > 0 ? `${fmt(t.dimZ)}"` : "",
  ].filter(Boolean);
  return `${bits.join(" x ")} · LOC ${(t.locAxis || "z").toUpperCase()}=${fmt(t.locValue)}"`;
}

export function applyTicketToQuote(
  quote: Quote,
  t: CutTicket,
): Quote {
  return {
    ...quote,
    material: t.material || quote.material,
    materialType: t.materialType || quote.materialType,
    stockShape: t.stockShape || quote.stockShape,
    dimX: t.process === "lathe" ? t.diameter || t.dimX : t.dimX || quote.dimX,
    dimY: t.process === "lathe" ? quote.dimY : t.dimY || quote.dimY,
    dimZ: t.locValue || t.dimZ || quote.dimZ,
    partLengthEach: t.locValue || quote.partLengthEach,
  };
}

export function statusLabel(s: CutTicketStatus): string {
  switch (s) {
    case "requested":
      return "Waiting on saw";
    case "cutting":
      return "Saw cutting";
    case "partial":
      return "Partial ready";
    case "done":
      return "All cut";
    case "skipped":
      return "Skip saw / on hand";
    case "cancelled":
      return "Cancelled";
    default:
      return s;
  }
}

export function printCutTicketSheet(tickets: CutTicket[], company = "Lake Country Machine") {
  const rows = tickets
    .map((t, i) => {
      const avail = qtyAvailable(t);
      return `<tr>
        <td>${i + 1}</td>
        <td><strong>${esc(t.partNumber)}</strong> Rev ${esc(t.revision || "—")}<br/><span class="muted">${esc(t.customer)} · PO ${esc(t.poNumber)}</span></td>
        <td>${esc(t.material)} ${esc(t.materialType)}<br/>${esc(t.stockShape)}</td>
        <td>${esc(cutTicketLabel(t))}</td>
        <td class="num">${t.qtyCut} / ${t.qtyRequested}<br/><span class="muted">${avail} avail</span></td>
        <td>${esc(t.requestedMachine || "—")}<br/><span class="muted">${esc(t.requestedBy)}</span></td>
        <td>${esc(t.notes)}</td>
      </tr>`;
    })
    .join("");
  const html = `<!doctype html><html><head><meta charset="utf-8"/><title>Cut tickets</title>
  <style>
    body{font-family:system-ui,sans-serif;font-size:12px;color:#111;padding:12px}
    h1{font-size:16px;margin:0 0 4px}
    .meta{color:#444;margin-bottom:10px}
    table{width:100%;border-collapse:collapse}
    th,td{border:1px solid #333;padding:6px;vertical-align:top}
    th{background:#eee;text-align:left;font-size:11px}
    .num{text-align:right;font-variant-numeric:tabular-nums}
    .muted{color:#555;font-size:10px}
    @media print{.noprint{display:none}}
  </style></head><body>
  <h1>${esc(company)} — Saw cut tickets</h1>
  <div class="meta">${tickets.length} ticket(s) · ${esc(new Date().toLocaleString())}</div>
  <table><thead><tr>
    <th>#</th><th>Part</th><th>Material</th><th>Cut size</th><th>Qty cut</th><th>For machine</th><th>Notes</th>
  </tr></thead><tbody>${rows}</tbody></table>
  <p class="noprint"><button onclick="window.print()">Print</button></p>
  <script>setTimeout(function(){window.print()},200)</script>
  </body></html>`;
  const w = window.open("", "_blank", "noopener,noreferrer");
  if (!w) return false;
  w.document.open();
  w.document.write(html);
  w.document.close();
  return true;
}

function esc(s: string) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
