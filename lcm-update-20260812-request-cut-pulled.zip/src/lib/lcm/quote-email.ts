import type { Customer, Quote } from "./types";
import { formatCurrency } from "@/lib/utils";
import { calculateAssemblyAwareCosts } from "./calculations";
import { toolingBillLines } from "./quote-tooling";

/** One part card: qty breaks across columns (how LCM customers receive quotes) */
export type QuotePartBlock = {
  partNumber: string;
  revision: string;
  /** Parallel arrays — only breaks with qty > 0 (and usually a price) */
  quantities: number[];
  prices: number[];
  /**
   * Optional separate bill lines (soft jaws, special tools).
   * Never rolled into price each above.
   */
  extraLines: Array<{
    description: string;
    qty: number;
    unitPrice: number;
  }>;
};

export type QuoteEmailDraft = {
  companyName: string;
  customerName: string;
  dateLabel: string;
  parts: QuotePartBlock[];
  notes?: string;
};

/** Build per-part QTY / Each tables from selected quotes */
export function buildQuotePartBlocks(quotes: Quote[]): QuotePartBlock[] {
  const sorted = [...quotes].sort((a, b) =>
    a.partNumber.localeCompare(b.partNumber, undefined, { sensitivity: "base" }),
  );

  return sorted.map((q) => {
    const quantities: number[] = [];
    const prices: number[] = [];
    const qArr = q.quantities || [];
    // Customer-facing $ always from live quoter math (setup/run/material/qty)
    // Soft jaws / tools are NEVER in these prices — separate extraLines only.
    const live = calculateAssemblyAwareCosts(q, quotes);
    const pArr = live.prices || q.prices || [];
    const n = Math.max(qArr.length, pArr.length, 6);

    for (let i = 0; i < n; i++) {
      const qty = Number(qArr[i]) || 0;
      if (qty <= 0) continue;
      quantities.push(qty);
      prices.push(Number(pArr[i]) || 0);
    }

    // Always show the part even if no breaks filled yet
    if (quantities.length === 0) {
      quantities.push(0);
      prices.push(0);
    }

    const extraLines = toolingBillLines(q.toolingCharges).map((line) => ({
      description: line.description,
      qty: line.qty,
      unitPrice: line.unitPrice,
    }));

    return {
      partNumber: q.partNumber,
      revision: q.revision || "A",
      quantities,
      prices,
      extraLines,
    };
  });
}

export function buildQuoteEmailDraft(opts: {
  companyName: string;
  customerName: string;
  quotes: Quote[];
  now?: Date;
  notes?: string;
}): QuoteEmailDraft {
  const now = opts.now || new Date();
  return {
    companyName: opts.companyName,
    customerName: opts.customerName,
    dateLabel: now.toLocaleDateString(undefined, {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    }),
    parts: buildQuotePartBlocks(opts.quotes),
    notes: opts.notes,
  };
}

export function quoteEmailSubject(draft: QuoteEmailDraft, partCount: number): string {
  if (partCount <= 1 && draft.parts[0]) {
    return `${draft.companyName} Quote — ${draft.parts[0].partNumber} Rev ${draft.parts[0].revision}`;
  }
  return `${draft.companyName} Quote Package — ${draft.customerName} (${partCount} parts)`;
}

function formatPriceCell(n: number): string {
  if (!n || n <= 0) return "TBD";
  return formatCurrency(n);
}

function padCell(s: string, width: number): string {
  const t = String(s);
  if (t.length >= width) return t;
  const pad = width - t.length;
  const left = Math.floor(pad / 2);
  const right = pad - left;
  return " ".repeat(left) + t + " ".repeat(right);
}

/**
 * Plain-text body — same structure as the print letter (tables as aligned columns).
 * Used by mailto: and as text/plain clipboard fallback.
 */
export function quoteEmailPlainText(draft: QuoteEmailDraft): string {
  const blocks: string[] = [
    draft.companyName,
    `Quote date: ${draft.dateLabel}`,
    `Customer: ${draft.customerName}`,
    "",
  ];

  for (const part of draft.parts) {
    blocks.push(`Part #${part.partNumber} — Rev ${part.revision}`);
    const rows = [
      part.quantities.map((q) => (q > 0 ? String(q) : "—")),
      part.prices.map((p) => formatPriceCell(p)),
    ];
    const colW = Math.max(
      8,
      ...rows.flat().map((c) => c.length + 2),
      6,
    );
    const line = (label: string, cells: string[]) =>
      `${label.padEnd(6)}${cells.map((c) => padCell(c, colW)).join("")}`;
    blocks.push(line("QTY", rows[0]!));
    blocks.push(line("Each", rows[1]!));
    blocks.push("");

    for (const el of part.extraLines || []) {
      blocks.push(el.description);
      blocks.push(line("QTY", [String(el.qty)]));
      blocks.push(line("Each", [formatPriceCell(el.unitPrice)]));
      if (el.qty > 0 && el.unitPrice > 0) {
        blocks.push(`Ext   ${formatPriceCell(el.qty * el.unitPrice)}`);
      }
      blocks.push("");
    }
  }

  blocks.push(draft.notes?.trim() || "Thank you for the opportunity to quote.");
  blocks.push("");
  blocks.push(`— ${draft.companyName}`);
  return blocks.join("\n");
}

function escHtml(s: string): string {
  return String(s || "")
    .replace(/&/g, "&" + "amp;")
    .replace(/</g, "&" + "lt;")
    .replace(/>/g, "&" + "gt;")
    .replace(/"/g, "&" + "quot;");
}


/**
 * HTML body matching QuoteLetter / print preview (inline styles for Outlook).
 * Prefer clipboard text/html so paste keeps tables.
 */
export function quoteEmailHtml(draft: QuoteEmailDraft): string {
  const partsHtml = draft.parts
    .map((part) => {
      const qtyCells = part.quantities
        .map(
          (q) =>
            `<td style="border:1px solid #c4c4c4;padding:8px 12px;text-align:center;font-variant-numeric:tabular-nums;font-weight:500;">${
              q > 0 ? q : "—"
            }</td>`,
        )
        .join("");
      const priceCells = part.prices
        .map(
          (p) =>
            `<td style="border:1px solid #c4c4c4;padding:8px 12px;text-align:center;font-variant-numeric:tabular-nums;font-weight:700;">${escHtml(
              p > 0 ? formatPriceCell(p) : "TBD",
            )}</td>`,
        )
        .join("");
      const extras = (part.extraLines || [])
        .map((line) => {
          const ext =
            line.qty > 0 && line.unitPrice > 0
              ? `<span style="color:#555;margin-left:12px;">Ext ${escHtml(
                  formatPriceCell(line.qty * line.unitPrice),
                )}</span>`
              : "";
          return `<div style="border-top:1px solid #c4c4c4;padding:8px 12px;background:#fffbeb;">
  <div style="font-weight:600;font-size:14px;margin-bottom:4px;">${escHtml(line.description)}</div>
  <div style="font-size:14px;">
    <span style="color:#555;">QTY</span> <strong>${line.qty}</strong>
    &nbsp;&nbsp;
    <span style="color:#555;">Each</span> <strong>${escHtml(
      line.unitPrice > 0 ? formatPriceCell(line.unitPrice) : "TBD",
    )}</strong>
    ${ext}
  </div>
</div>`;
        })
        .join("");

      return `<div style="border:1px solid #a3a3a3;border-radius:6px;overflow:hidden;margin:0 0 16px 0;page-break-inside:avoid;break-inside:avoid;">
  <div style="background:#f5f5f5;border-bottom:1px solid #c4c4c4;padding:8px 12px;font-weight:700;font-size:14px;">
    Part #${escHtml(part.partNumber)}
    <span style="font-weight:400;color:#525252;"> — Rev ${escHtml(part.revision)}</span>
  </div>
  <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;font-size:14px;">
    <tr>
      <th style="text-align:left;font-weight:500;color:#525252;border:1px solid #c4c4c4;background:#fafafa;padding:8px 12px;width:56px;">QTY</th>
      ${qtyCells}
    </tr>
    <tr>
      <th style="text-align:left;font-weight:500;color:#525252;border:1px solid #c4c4c4;background:#fafafa;padding:8px 12px;">Each</th>
      ${priceCells}
    </tr>
  </table>
  ${extras}
</div>`;
    })
    .join("\n");

  const notes = draft.notes?.trim()
    ? `<p style="font-size:14px;color:#404040;border-top:1px solid #d4d4d4;padding-top:12px;margin:16px 0 0 0;white-space:pre-wrap;">${escHtml(
        draft.notes.trim(),
      )}</p>`
    : "";

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>${escHtml(quoteEmailSubject(draft, draft.parts.length))}</title>
</head>
<body style="margin:0;padding:0;background:#ffffff;color:#111111;font-family:Segoe UI,Arial,sans-serif;">
  <div style="max-width:720px;margin:0 auto;padding:20px;border:2px solid #a3a3a3;border-radius:8px;">
    <div style="border-bottom:1px solid #d4d4d4;padding-bottom:12px;margin-bottom:16px;">
      <div style="font-size:18px;font-weight:700;letter-spacing:-0.01em;">${escHtml(draft.companyName)}</div>
      <div style="font-size:14px;color:#525252;margin-top:4px;">Quote date: ${escHtml(draft.dateLabel)}</div>
      <div style="font-size:14px;margin-top:2px;">Customer: <strong>${escHtml(draft.customerName)}</strong></div>
    </div>
    ${partsHtml}
    ${notes}
    <p style="font-size:14px;margin:16px 0 0 0;">— ${escHtml(draft.companyName)}</p>
  </div>
</body>
</html>`;
}

/** Fragment only (no html/body) — for clipboard paste into compose windows */
export function quoteEmailHtmlFragment(draft: QuoteEmailDraft): string {
  const full = quoteEmailHtml(draft);
  const m = full.match(/<body[^>]*>([\s\S]*)<\/body>/i);
  return (m?.[1] || full).trim();
}

/**
 * Copy letter as HTML + plain so Outlook/Gmail paste keeps the table layout.
 */
export async function copyQuoteEmailRich(
  draft: QuoteEmailDraft,
): Promise<{ ok: boolean; error?: string }> {
  const plain = quoteEmailPlainText(draft);
  // Full HTML document pastes best into Outlook / Apple Mail as the boxed letter
  const html = quoteEmailHtml(draft);
  try {
    if (typeof ClipboardItem !== "undefined" && navigator.clipboard?.write) {
      const item = new ClipboardItem({
        "text/html": new Blob([html], { type: "text/html" }),
        "text/plain": new Blob([plain], { type: "text/plain" }),
      });
      await navigator.clipboard.write([item]);
      return { ok: true };
    }
    await navigator.clipboard.writeText(plain);
    return { ok: true };
  } catch (e) {
    try {
      await navigator.clipboard.writeText(plain);
      return { ok: true };
    } catch {
      return {
        ok: false,
        error: e instanceof Error ? e.message : "Clipboard failed",
      };
    }
  }
}

function encodeMailHeader(value: string): string {
  const s = String(value || "");
  if (/^[\x20-\x7E]*$/.test(s)) return s;
  // RFC 2047 base64 for non-ASCII subjects
  const bytes = new TextEncoder().encode(s);
  let bin = "";
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]!);
  const b64 =
    typeof btoa !== "undefined"
      ? btoa(bin)
      : Buffer.from(bytes).toString("base64");
  return `=?UTF-8?B?${b64}?=`;
}

/**
 * Outlook-ready .eml draft with HTML tables (same as print).
 * X-Unsent: 1 → opens as a new compose message in Outlook desktop.
 */
export function buildQuoteEmailEml(opts: {
  to: string;
  from?: string;
  subject: string;
  draft: QuoteEmailDraft;
}): string {
  const boundary = `lcm_quote_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
  const plain = quoteEmailPlainText(opts.draft);
  const html = quoteEmailHtml(opts.draft);
  const lines: string[] = [
    "X-Unsent: 1",
    "MIME-Version: 1.0",
  ];
  if (opts.from?.trim()) {
    lines.push(`From: ${opts.from.trim()}`);
  }
  lines.push(`To: ${opts.to.trim()}`);
  lines.push(`Subject: ${encodeMailHeader(opts.subject)}`);
  lines.push(`Content-Type: multipart/alternative; boundary="${boundary}"`);
  lines.push("");
  lines.push(`--${boundary}`);
  lines.push('Content-Type: text/plain; charset="UTF-8"');
  lines.push("Content-Transfer-Encoding: 8bit");
  lines.push("");
  lines.push(plain);
  lines.push("");
  lines.push(`--${boundary}`);
  lines.push('Content-Type: text/html; charset="UTF-8"');
  lines.push("Content-Transfer-Encoding: 8bit");
  lines.push("");
  lines.push(html);
  lines.push("");
  lines.push(`--${boundary}--`);
  lines.push("");
  return lines.join("\r\n");
}

/** Download / open .eml so the mail app shows the boxed HTML letter. */
export function openQuoteEmailEml(opts: {
  to: string;
  from?: string;
  subject: string;
  draft: QuoteEmailDraft;
  fileName?: string;
}): { ok: boolean; error?: string } {
  try {
    const eml = buildQuoteEmailEml(opts);
    const blob = new Blob([eml], { type: "message/rfc822" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const safe =
      opts.fileName ||
      `LCM-Quote-${(opts.draft.customerName || "customer")
        .replace(/[^a-zA-Z0-9]+/g, "-")
        .replace(/^-|-$/g, "")
        .slice(0, 40)}.eml`;
    a.href = url;
    a.download = safe.endsWith(".eml") ? safe : `${safe}.eml`;
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
    // Revoke after a beat so the browser can finish the download
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
    return { ok: true };
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : "Could not build email file",
    };
  }
}

export function mailtoUrl(to: string, subject: string, body: string): string {
  const params = new URLSearchParams();
  params.set("subject", subject);
  params.set("body", body);
  const q = params.toString().replace(/\+/g, "%20");
  return `mailto:${encodeURIComponent(to)}?${q}`;
}

export function customerEmailList(c: Customer | undefined): string[] {
  if (!c) return [];
  const out: string[] = [];
  const seen = new Set<string>();
  for (const raw of [c.email, ...(c.emails || [])]) {
    const e = String(raw || "")
      .trim()
      .toLowerCase();
    if (!e || !e.includes("@") || seen.has(e)) continue;
    seen.add(e);
    out.push(e);
  }
  return out;
}

export function sortCustomersForEmail(customers: Customer[]): Customer[] {
  return [...customers].sort((a, b) => {
    const at = a.lastEmailedAt ? new Date(a.lastEmailedAt).getTime() : 0;
    const bt = b.lastEmailedAt ? new Date(b.lastEmailedAt).getTime() : 0;
    if (bt !== at) return bt - at;
    return a.name.localeCompare(b.name);
  });
}

export function localDateKey(iso: string | Date): string {
  const d = typeof iso === "string" ? new Date(iso) : iso;
  if (Number.isNaN(d.getTime())) return "";
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).toString().padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function todayLocalKey(): string {
  return localDateKey(new Date());
}
