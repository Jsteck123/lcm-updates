import { MACHINES } from "./types";
import { allMachines } from "./lists";
import type { CustomLists } from "./types";

export function machineToSlug(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

export function slugToMachine(
  slug: string,
  custom?: CustomLists | string[],
): string | null {
  const decoded = decodeURIComponent(slug);
  const list = Array.isArray(custom)
    ? custom
    : allMachines(custom);

  if (list.includes(decoded)) return decoded;
  // match built-in constant still
  if ((MACHINES as readonly string[]).includes(decoded)) return decoded;

  const found = list.find(
    (m) => machineToSlug(m) === decoded || machineToSlug(m) === slug,
  );
  return found ?? null;
}
