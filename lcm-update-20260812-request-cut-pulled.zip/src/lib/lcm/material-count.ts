/**
 * Material floor inventory count sheets.
 *
 * Flow:
 *  1. Office downloads / prints a count sheet (system qty filled, counted blank).
 *  2. Floor walks racks, writes actual qty (and optional size/length note).
 *  3. Office uploads the filled CSV (or scans OCR→CSV) → preview → apply.
 *
 * stock_id is the stable key — never rewrite it on paper if you can help it.
 * New materials can be added with empty stock_id (creates a stock row).
 */

import type { MaterialStock } from "./types";
import { emptyMaterial, materialLabel } from "./inventory";
import { uid } from "@/lib/utils";

/** Stable CSV headers — keep order for Excel / Google Sheets */
export const MATERIAL_COUNT_HEADERS = [
  "stock_id",
  "material",
  "material_type",
  "stock_shape",
  "size_note",
  "location",
  "unit",
  "system_qty",
  "counted_qty",
  "counted_size_note",
  "count_notes",
] as const;

export type MaterialCountHeader = (typeof MATERIAL_COUNT_HEADERS)[number];

export type MaterialCountRow = {
  stockId: string;
  material: string;
  materialType: string;
  stockShape: string;
  sizeNote: string;
  location: string;
  unit: string;
  systemQty: number | null;
  countedQty: number | null;
  countedSizeNote: string;
  countNotes: string;
  /** Raw line number in file (1-based data rows) */
  lineNo: number;
};

export type CountApplyAction =
  | {
      kind: "adjust";
      stockId: string;
      label: string;
      fromQty: number;
      toQty: number;
      delta: number;
      sizeNote?: string;
      notes: string;
    }
  | {
      kind: "create";
      tempId: string;
      label: string;
      toQty: number;
      material: string;
      materialType: string;
      stockShape: string;
      sizeNote: string;
      location: string;
      unit: string;
      notes: string;
    }
  | {
      kind: "skip";
      reason: string;
      lineNo: number;
      label: string;
    }
  | {
      kind: "error";
      reason: string;
      lineNo: number;
      label: string;
    };

export type CountApplyPlan = {
  actions: CountApplyAction[];
  adjustCount: number;
  createCount: number;
  skipCount: number;
  errorCount: number;
  unchangedCount: number;
};

function csvEscape(v: string | number | null | undefined): string {
  const s = v == null ? "" : String(v);
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cur = "";
  let inQ = false;
  const src = text.replace(/^\uFEFF/, "");
  for (let i = 0; i < src.length; i++) {
    const c = src[i]!;
    if (inQ) {
      if (c === '"') {
        if (src[i + 1] === '"') {
          cur += '"';
          i++;
        } else inQ = false;
      } else cur += c;
    } else if (c === '"') {
      inQ = true;
    } else if (c === ",") {
      row.push(cur);
      cur = "";
    } else if (c === "\n") {
      row.push(cur);
      rows.push(row);
      row = [];
      cur = "";
    } else if (c === "\r") {
      // ignore
    } else {
      cur += c;
    }
  }
  if (cur.length || row.length) {
    row.push(cur);
    rows.push(row);
  }
  return rows.filter((r) => r.some((c) => String(c).trim() !== ""));
}

function normHeader(h: string): string {
  return h
    .trim()
    .toLowerCase()
    .replace(/[\s\-]+/g, "_")
    .replace(/[^\w]/g, "");
}

const HEADER_ALIASES: Record<string, MaterialCountHeader> = {
  stock_id: "stock_id",
  id: "stock_id",
  material_id: "stock_id",
  material: "material",
  material_type: "material_type",
  type: "material_type",
  stock_shape: "stock_shape",
  shape: "stock_shape",
  size_note: "size_note",
  size: "size_note",
  location: "location",
  loc: "location",
  unit: "unit",
  system_qty: "system_qty",
  system_on_hand: "system_qty",
  expected_qty: "system_qty",
  book_qty: "system_qty",
  counted_qty: "counted_qty",
  actual_qty: "counted_qty",
  count: "counted_qty",
  qty: "counted_qty",
  counted_size_note: "counted_size_note",
  actual_size: "counted_size_note",
  actual_length: "counted_size_note",
  length_note: "counted_size_note",
  count_notes: "count_notes",
  notes: "count_notes",
};

function parseNum(raw: string): number | null {
  const t = String(raw || "").trim();
  if (!t) return null;
  const n = Number(t.replace(/,/g, ""));
  return Number.isFinite(n) ? n : null;
}

/** Count sheet rows from current material stock (counted blank). */
export function buildCountSheetRows(stock: MaterialStock[]): MaterialCountRow[] {
  return (stock || [])
    .slice()
    .sort((a, b) => {
      const la = (a.location || "zzz").toLowerCase();
      const lb = (b.location || "zzz").toLowerCase();
      if (la !== lb) return la.localeCompare(lb);
      return materialLabel(a).localeCompare(materialLabel(b));
    })
    .map((m, i) => ({
      stockId: m.id,
      material: m.material || "",
      materialType: m.materialType || "",
      stockShape: m.stockShape || "",
      sizeNote: m.sizeNote || "",
      location: m.location || "",
      unit: m.unit || "pcs",
      systemQty: Number(m.onHand) || 0,
      countedQty: null,
      countedSizeNote: "",
      countNotes: "",
      lineNo: i + 1,
    }));
}

/** One blank example row for first-time inventory. */
export function blankTemplateRows(): MaterialCountRow[] {
  return [
    {
      stockId: "",
      material: "Aluminum",
      materialType: "T6 6061",
      stockShape: "Round Stock",
      sizeNote: '1" dia x 12 ft',
      location: "Rack A",
      unit: "bar",
      systemQty: null,
      countedQty: null,
      countedSizeNote: "",
      countNotes: "Example — delete or fill. Leave stock_id empty for NEW items.",
      lineNo: 1,
    },
  ];
}

export function countRowsToCsv(rows: MaterialCountRow[]): string {
  const lines = [MATERIAL_COUNT_HEADERS.join(",")];
  for (const r of rows) {
    lines.push(
      [
        r.stockId,
        r.material,
        r.materialType,
        r.stockShape,
        r.sizeNote,
        r.location,
        r.unit,
        r.systemQty == null ? "" : r.systemQty,
        r.countedQty == null ? "" : r.countedQty,
        r.countedSizeNote,
        r.countNotes,
      ]
        .map(csvEscape)
        .join(","),
    );
  }
  return lines.join("\r\n") + "\r\n";
}

export function downloadTextFile(filename: string, text: string, mime = "text/csv;charset=utf-8") {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function parseMaterialCountCsv(text: string): {
  rows: MaterialCountRow[];
  errors: string[];
} {
  const grid = parseCsv(text);
  if (!grid.length) return { rows: [], errors: ["File is empty"] };

  const headerCells = grid[0]!.map(normHeader);
  const col: Partial<Record<MaterialCountHeader, number>> = {};
  headerCells.forEach((h, i) => {
    const key = HEADER_ALIASES[h];
    if (key && col[key] == null) col[key] = i;
  });

  if (col.counted_qty == null && col.stock_id == null && col.material == null) {
    return {
      rows: [],
      errors: [
        "Missing headers. Need at least stock_id (or material) and counted_qty. Download a template from Inventory → Floor count.",
      ],
    };
  }

  const errors: string[] = [];
  const rows: MaterialCountRow[] = [];

  for (let r = 1; r < grid.length; r++) {
    const cells = grid[r]!;
    const get = (k: MaterialCountHeader) => {
      const i = col[k];
      return i == null ? "" : String(cells[i] ?? "").trim();
    };
    const material = get("material");
    const stockId = get("stock_id");
    // skip pure blank lines
    if (!material && !stockId && !get("counted_qty")) continue;

    const systemQty = parseNum(get("system_qty"));
    const countedQty = parseNum(get("counted_qty"));
    if (get("counted_qty") && countedQty == null) {
      errors.push(`Line ${r + 1}: counted_qty "${get("counted_qty")}" is not a number`);
    }

    rows.push({
      stockId,
      material,
      materialType: get("material_type"),
      stockShape: get("stock_shape"),
      sizeNote: get("size_note"),
      location: get("location"),
      unit: get("unit") || "pcs",
      systemQty,
      countedQty,
      countedSizeNote: get("counted_size_note"),
      countNotes: get("count_notes"),
      lineNo: r + 1,
    });
  }

  return { rows, errors };
}

export function buildCountApplyPlan(
  rows: MaterialCountRow[],
  stock: MaterialStock[],
): CountApplyPlan {
  const byId = new Map(stock.map((m) => [m.id, m]));
  const actions: CountApplyAction[] = [];
  let adjustCount = 0;
  let createCount = 0;
  let skipCount = 0;
  let errorCount = 0;
  let unchangedCount = 0;

  for (const row of rows) {
    const labelBits = [
      row.material,
      row.materialType,
      row.stockShape,
      row.sizeNote || row.countedSizeNote,
    ]
      .filter(Boolean)
      .join(" · ");
    const label = labelBits || row.stockId || `Line ${row.lineNo}`;

    if (row.countedQty == null) {
      actions.push({
        kind: "skip",
        reason: "No counted_qty (left blank — not counted)",
        lineNo: row.lineNo,
        label,
      });
      skipCount++;
      continue;
    }

    if (row.countedQty < 0) {
      actions.push({
        kind: "error",
        reason: "counted_qty cannot be negative",
        lineNo: row.lineNo,
        label,
      });
      errorCount++;
      continue;
    }

    if (row.stockId) {
      const existing = byId.get(row.stockId);
      if (!existing) {
        actions.push({
          kind: "error",
          reason: `Unknown stock_id ${row.stockId} — re-download a fresh count sheet`,
          lineNo: row.lineNo,
          label,
        });
        errorCount++;
        continue;
      }
      const fromQty = Number(existing.onHand) || 0;
      const toQty = row.countedQty;
      const sizeNote =
        row.countedSizeNote.trim() &&
        row.countedSizeNote.trim() !== (existing.sizeNote || "").trim()
          ? row.countedSizeNote.trim()
          : undefined;

      if (fromQty === toQty && !sizeNote) {
        actions.push({
          kind: "skip",
          reason: "Matches system qty — no change",
          lineNo: row.lineNo,
          label,
        });
        unchangedCount++;
        skipCount++;
        continue;
      }

      actions.push({
        kind: "adjust",
        stockId: existing.id,
        label: materialLabel(existing),
        fromQty,
        toQty,
        delta: toQty - fromQty,
        sizeNote,
        notes: row.countNotes || "Floor count",
      });
      adjustCount++;
      continue;
    }

    // New material (no stock_id)
    if (!row.material.trim()) {
      actions.push({
        kind: "error",
        reason: "New item needs material name (or a stock_id)",
        lineNo: row.lineNo,
        label,
      });
      errorCount++;
      continue;
    }

    actions.push({
      kind: "create",
      tempId: uid(),
      label,
      toQty: row.countedQty,
      material: row.material.trim(),
      materialType: row.materialType.trim(),
      stockShape: row.stockShape.trim(),
      sizeNote: (row.countedSizeNote || row.sizeNote).trim(),
      location: row.location.trim(),
      unit: row.unit.trim() || "pcs",
      notes: row.countNotes || "Floor count — new item",
    });
    createCount++;
  }

  return {
    actions,
    adjustCount,
    createCount,
    skipCount,
    errorCount,
    unchangedCount,
  };
}

/** Open a print-friendly clipboard sheet in a new window. */
export function printMaterialCountSheet(
  stock: MaterialStock[],
  opts?: { title?: string; company?: string },
) {
  const rows = buildCountSheetRows(stock);
  const title = opts?.title || "Material floor count";
  const company = opts?.company || "Lake Country Machine";
  const date = new Date().toLocaleString();
  const body = rows
    .map((r, i) => {
      const sys =
        r.systemQty == null ? "—" : String(r.systemQty);
      return `<tr>
        <td class="n">${i + 1}</td>
        <td class="loc">${esc(r.location || "—")}</td>
        <td>
          <div class="mat">${esc(r.material)} ${esc(r.materialType)}</div>
          <div class="sub">${esc(r.stockShape)} · ${esc(r.sizeNote || "—")}</div>
          <div class="id">ID ${esc(r.stockId)}</div>
        </td>
        <td class="unit">${esc(r.unit)}</td>
        <td class="sys">${esc(sys)}</td>
        <td class="write"></td>
        <td class="write wide"></td>
        <td class="write wide"></td>
      </tr>`;
    })
    .join("");

  const html = `<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>${esc(title)}</title>
  <style>
    @page { size: letter landscape; margin: 0.4in; }
    body { font-family: system-ui, sans-serif; font-size: 11px; color: #111; }
    h1 { font-size: 16px; margin: 0 0 4px; }
    .meta { color: #444; margin-bottom: 10px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #333; padding: 5px 6px; vertical-align: top; }
    th { background: #eee; font-size: 10px; text-align: left; }
    .n { width: 28px; text-align: center; }
    .loc { width: 70px; font-weight: 600; }
    .unit { width: 40px; text-align: center; }
    .sys { width: 56px; text-align: right; font-variant-numeric: tabular-nums; }
    .write { height: 28px; min-width: 52px; background: #fafafa; }
    .write.wide { min-width: 90px; }
    .mat { font-weight: 600; }
    .sub { color: #333; font-size: 10px; }
    .id { color: #666; font-size: 9px; font-family: ui-monospace, monospace; margin-top: 2px; }
    .howto { font-size: 10px; margin-top: 10px; color: #333; max-width: 900px; }
    @media print { .noprint { display: none; } }
  </style>
</head>
<body>
  <h1>${esc(company)} — ${esc(title)}</h1>
  <div class="meta">Printed ${esc(date)} · ${rows.length} stock lines · Write actuals in the blank boxes · Keep stock ID if typing into CSV later</div>
  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Location</th>
        <th>Material / size (system)</th>
        <th>Unit</th>
        <th>System qty</th>
        <th>Actual qty</th>
        <th>Actual size / length</th>
        <th>Notes</th>
      </tr>
    </thead>
    <tbody>${body}</tbody>
  </table>
  <p class="howto">
    <strong>How to use:</strong> Walk the racks. Write <em>Actual qty</em> in the unit shown
    (bars, ft, pcs…). If a bar is shorter than the size note, write the real length under
    Actual size. Office enters those numbers into the CSV count sheet (or re-types from this
    paper) and imports under Inventory → Floor count. Blank actual = skip that line.
  </p>
  <p class="noprint"><button onclick="window.print()">Print</button></p>
  <script>window.onload = function(){ setTimeout(function(){ window.print(); }, 200); }</script>
</body>
</html>`;

  const w = window.open("", "_blank", "noopener,noreferrer");
  if (!w) return false;
  w.document.open();
  w.document.write(html);
  w.document.close();
  return true;
}

function esc(s: string) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** Build MaterialStock creates from plan actions */
export function materialFromCreateAction(
  a: Extract<CountApplyAction, { kind: "create" }>,
): MaterialStock {
  return emptyMaterial({
    id: a.tempId || uid(),
    material: a.material,
    materialType: a.materialType,
    stockShape: a.stockShape,
    sizeNote: a.sizeNote,
    location: a.location,
    unit: (a.unit as MaterialStock["unit"]) || "pcs",
    onHand: a.toQty,
    notes: a.notes,
    updatedAt: new Date().toISOString(),
  });
}
