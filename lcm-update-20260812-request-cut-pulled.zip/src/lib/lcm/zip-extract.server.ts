/**
 * Minimal ZIP extractor (store + deflate) — no external unzip binary.
 * Works on Windows host PCs where `unzip` is not installed.
 */
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";

function ensureDir(p: string) {
  fs.mkdirSync(p, { recursive: true });
}

function readU16(buf: Buffer, o: number) {
  return buf.readUInt16LE(o);
}
function readU32(buf: Buffer, o: number) {
  return buf.readUInt32LE(o);
}

/**
 * Extract zipPath into destDir. Overwrites existing files.
 */
export function extractZipFile(
  zipPath: string,
  destDir: string,
): { ok: true; files: number } | { ok: false; error: string } {
  try {
    const buf = fs.readFileSync(zipPath);
    return extractZipBuffer(buf, destDir);
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : "Could not read zip",
    };
  }
}

export function extractZipBuffer(
  buf: Buffer,
  destDir: string,
): { ok: true; files: number } | { ok: false; error: string } {
  try {
    if (buf.length < 22 || buf[0] !== 0x50 || buf[1] !== 0x4b) {
      return { ok: false, error: "Not a zip file" };
    }

    // Find End of Central Directory (EOCD)
    let eocd = -1;
    for (let i = buf.length - 22; i >= 0 && i >= buf.length - 22 - 0xffff; i--) {
      if (
        buf[i] === 0x50 &&
        buf[i + 1] === 0x4b &&
        buf[i + 2] === 0x05 &&
        buf[i + 3] === 0x06
      ) {
        eocd = i;
        break;
      }
    }
    if (eocd < 0) {
      return { ok: false, error: "Invalid zip (no end-of-central-directory)" };
    }

    const totalEntries = readU16(buf, eocd + 10);
    let cdOffset = readU32(buf, eocd + 16);
    // Zip64 not supported — fine for our update packages
    if (cdOffset >= buf.length) {
      return { ok: false, error: "Invalid zip central directory offset" };
    }

    ensureDir(destDir);
    let files = 0;
    let pos = cdOffset;

    for (let n = 0; n < totalEntries; n++) {
      if (pos + 46 > buf.length) break;
      if (
        buf[pos] !== 0x50 ||
        buf[pos + 1] !== 0x4b ||
        buf[pos + 2] !== 0x01 ||
        buf[pos + 3] !== 0x02
      ) {
        return { ok: false, error: `Bad central directory entry at ${pos}` };
      }

      const method = readU16(buf, pos + 10);
      const compSize = readU32(buf, pos + 20);
      const uncompSize = readU32(buf, pos + 24);
      const nameLen = readU16(buf, pos + 28);
      const extraLen = readU16(buf, pos + 30);
      const commentLen = readU16(buf, pos + 32);
      const localHeaderOffset = readU32(buf, pos + 42);
      const nameStart = pos + 46;
      const name = buf.subarray(nameStart, nameStart + nameLen).toString("utf8");
      pos = nameStart + nameLen + extraLen + commentLen;

      // Skip directories
      if (name.endsWith("/")) continue;
      // Path traversal guard
      const norm = name.replace(/\\/g, "/");
      if (norm.includes("..") || path.isAbsolute(norm)) continue;

      // Local file header
      const lh = localHeaderOffset;
      if (lh + 30 > buf.length) {
        return { ok: false, error: `Bad local header for ${name}` };
      }
      if (
        buf[lh] !== 0x50 ||
        buf[lh + 1] !== 0x4b ||
        buf[lh + 2] !== 0x03 ||
        buf[lh + 3] !== 0x04
      ) {
        return { ok: false, error: `Bad local header signature for ${name}` };
      }
      const localNameLen = readU16(buf, lh + 26);
      const localExtraLen = readU16(buf, lh + 28);
      const dataStart = lh + 30 + localNameLen + localExtraLen;
      const dataEnd = dataStart + compSize;
      if (dataEnd > buf.length) {
        return { ok: false, error: `Truncated data for ${name}` };
      }
      const compressed = buf.subarray(dataStart, dataEnd);

      let out: Buffer;
      if (method === 0) {
        out = Buffer.from(compressed);
      } else if (method === 8) {
        try {
          out = zlib.inflateRawSync(compressed);
        } catch (e) {
          return {
            ok: false,
            error: `Deflate failed for ${name}: ${
              e instanceof Error ? e.message : "error"
            }`,
          };
        }
      } else {
        return {
          ok: false,
          error: `Unsupported zip compression method ${method} for ${name}`,
        };
      }

      if (uncompSize && out.length !== uncompSize && uncompSize !== 0xffffffff) {
        // Some tools leave size 0; only warn on hard mismatch
        if (out.length < uncompSize * 0.5 && uncompSize > 64) {
          return {
            ok: false,
            error: `Size mismatch for ${name} (${out.length} vs ${uncompSize})`,
          };
        }
      }

      const dest = path.join(destDir, ...norm.split("/"));
      ensureDir(path.dirname(dest));
      fs.writeFileSync(dest, out);
      files++;
    }

    if (!files) {
      return { ok: false, error: "Zip contained no files" };
    }
    return { ok: true, files };
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : "Zip extract failed",
    };
  }
}
