import type { QuoteToolingCharge, QuoteToolingKind } from "./types";
import { uid } from "@/lib/utils";

export const TOOLING_KIND_LABEL: Record<QuoteToolingKind, string> = {
  soft_jaws: "Soft jaws",
  special_tool: "Special tool",
  other: "Other tooling",
};

export function emptyToolingCharge(
  partial?: Partial<QuoteToolingCharge> & { kind?: QuoteToolingKind },
): QuoteToolingCharge {
  const kind = partial?.kind || "soft_jaws";
  const defaultDesc =
    kind === "soft_jaws"
      ? "Soft jaws"
      : kind === "special_tool"
        ? "Special tool"
        : "Tooling";
  return {
    id: partial?.id || uid(),
    kind,
    description: partial?.description ?? defaultDesc,
    shopCost: Number(partial?.shopCost) || 0,
    billCustomer: Boolean(partial?.billCustomer),
    billQty: Math.max(1, Number(partial?.billQty) || 1),
    billUnitPrice: Number(partial?.billUnitPrice) || 0,
    notes: partial?.notes || "",
  };
}

/** Normalize legacy/missing arrays; drop empty junk rows without cost or bill. */
export function normalizeToolingCharges(
  raw: unknown,
): QuoteToolingCharge[] {
  if (!Array.isArray(raw)) return [];
  const out: QuoteToolingCharge[] = [];
  for (const row of raw) {
    if (!row || typeof row !== "object") continue;
    const r = row as Partial<QuoteToolingCharge>;
    const kind: QuoteToolingKind =
      r.kind === "special_tool" || r.kind === "other" || r.kind === "soft_jaws"
        ? r.kind
        : "other";
    const charge = emptyToolingCharge({
      id: typeof r.id === "string" && r.id ? r.id : uid(),
      kind,
      description: String(r.description || "").trim() || TOOLING_KIND_LABEL[kind],
      shopCost: Number(r.shopCost) || 0,
      billCustomer: Boolean(r.billCustomer),
      billQty: Math.max(1, Number(r.billQty) || 1),
      billUnitPrice: Number(r.billUnitPrice) || 0,
      notes: String(r.notes || ""),
    });
    // Keep rows that have shop cost, bill intent, or custom notes
    if (
      charge.shopCost > 0 ||
      charge.billCustomer ||
      charge.billUnitPrice > 0 ||
      charge.notes.trim() ||
      (charge.description &&
        charge.description !== TOOLING_KIND_LABEL[kind])
    ) {
      out.push(charge);
    }
  }
  return out;
}

/** Total internal shop spend on jaws/tools (not in part price). */
export function toolingShopCostTotal(charges: QuoteToolingCharge[] | undefined): number {
  return (charges || []).reduce((s, c) => s + (Number(c.shopCost) || 0), 0);
}

/** Customer-facing bill lines only. */
export function toolingBillLines(
  charges: QuoteToolingCharge[] | undefined,
): Array<{
  kind: QuoteToolingKind;
  description: string;
  qty: number;
  unitPrice: number;
  extension: number;
}> {
  return (charges || [])
    .filter((c) => c.billCustomer && (Number(c.billUnitPrice) > 0 || Number(c.billQty) > 0))
    .map((c) => {
      const qty = Math.max(1, Number(c.billQty) || 1);
      const unitPrice = Number(c.billUnitPrice) || 0;
      const desc =
        (c.description || "").trim() || TOOLING_KIND_LABEL[c.kind] || "Tooling";
      return {
        kind: c.kind,
        description: desc,
        qty,
        unitPrice,
        extension: qty * unitPrice,
      };
    });
}

/** When bill is checked and unit price empty, default bill price to shop cost. */
export function withDefaultBillPrice(c: QuoteToolingCharge): QuoteToolingCharge {
  if (c.billCustomer && !(Number(c.billUnitPrice) > 0) && Number(c.shopCost) > 0) {
    return { ...c, billUnitPrice: Number(c.shopCost) };
  }
  return c;
}
