/** Load / open stored shop files (PO drawings, chat attachments). */

import { getShopToken } from "./shop-sync";
import { showAttachmentPreview } from "./attachment-preview-bus";

export type AttachmentOpenResult =
  | { ok: true; url: string; mime: string; name: string; revoke?: () => void }
  | { ok: false; error: string };

/** Build authenticated URL for a host-stored file. */
export function attachmentHttpUrl(id: string): string {
  const token = getShopToken();
  const q = token ? `?token=${encodeURIComponent(token)}` : "";
  return `/api/po-files/${encodeURIComponent(id)}${q}`;
}

/**
 * Resolve a viewable URL for an attachment (http or blob).
 */
export async function resolveAttachment(opts: {
  id: string;
  name?: string;
}): Promise<AttachmentOpenResult> {
  const id = opts.id?.trim();
  if (!id) return { ok: false, error: "No file id" };

  const token = getShopToken();
  const httpUrl = attachmentHttpUrl(id);

  try {
    const head = await fetch(httpUrl, {
      method: "GET",
      headers: token ? { "x-lcm-shop-token": token } : undefined,
    });
    if (head.ok) {
      const mime =
        head.headers.get("content-type") || "application/octet-stream";
      const buf = await head.arrayBuffer();
      const blob = new Blob([buf], { type: mime });
      const url = URL.createObjectURL(blob);
      return {
        ok: true,
        url,
        mime,
        name: opts.name || "attachment",
        revoke: () => URL.revokeObjectURL(url),
      };
    }
    if (head.status === 401) {
      return { ok: false, error: "Sign in with PIN to open attachments" };
    }
  } catch {
    /* fall through */
  }

  try {
    const { getPoAttachment } = await import("./po-files-api");
    const res = await getPoAttachment({
      data: { id, token: token || undefined },
    });
    if (!res.ok) return { ok: false, error: res.error || "File not found" };

    const mime = res.meta.mime || "application/octet-stream";
    const b64 = res.dataUrl.includes(",")
      ? res.dataUrl.split(",")[1]
      : res.dataUrl.replace(/^data:[^;]+;base64,/, "");
    const binary = atob(b64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const blob = new Blob([bytes], { type: mime });
    const url = URL.createObjectURL(blob);
    return {
      ok: true,
      url,
      mime,
      name: opts.name || res.meta.name || "attachment",
      revoke: () => URL.revokeObjectURL(url),
    };
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : "Could not open file",
    };
  }
}

/**
 * Open attachment in the shared in-app preview (fits screen, easy Close).
 * Used by PO orders, job board, and anywhere else that had a huge new tab.
 */
export async function openPoAttachment(opts: {
  id: string;
  name?: string;
}): Promise<{ ok: true } | { ok: false; error: string }> {
  return showAttachmentPreview(opts);
}
