/**
 * Company logo + PWA icons stored on the host under data/branding/
 * (not wiped by app updates).
 */
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

const ROOT = path.join(process.cwd(), "data", "branding");
const META = path.join(ROOT, "logo-meta.json");

export type LogoMeta = {
  fileName: string;
  mime: string;
  size: number;
  updatedAt: string;
  originalName: string;
};

function ensure() {
  if (!fs.existsSync(ROOT)) fs.mkdirSync(ROOT, { recursive: true });
}

export function getLogoMeta(): LogoMeta | null {
  try {
    if (!fs.existsSync(META)) return null;
    return JSON.parse(fs.readFileSync(META, "utf8")) as LogoMeta;
  } catch {
    return null;
  }
}

export function readLogoBinary(): {
  meta: LogoMeta;
  buffer: Buffer;
} | null {
  const meta = getLogoMeta();
  if (!meta) return null;
  const filePath = path.join(ROOT, meta.fileName);
  if (!fs.existsSync(filePath)) return null;
  if (!filePath.startsWith(ROOT)) return null;
  return { meta, buffer: fs.readFileSync(filePath) };
}

/** PWA / desktop shortcut icons (custom logo when set). */
export function readIconBinary(
  size: 192 | 512,
): { buffer: Buffer; mime: string } | null {
  ensure();
  const preferred = path.join(ROOT, `icon-${size}.png`);
  if (fs.existsSync(preferred)) {
    return { buffer: fs.readFileSync(preferred), mime: "image/png" };
  }
  // Logo uploaded before icon generation existed — build icons once
  const logo = readLogoBinary();
  if (logo) {
    const logoPath = path.join(ROOT, logo.meta.fileName);
    if (fs.existsSync(logoPath)) {
      try {
        generatePwaIcons(logoPath);
      } catch {
        /* ignore */
      }
    }
    if (fs.existsSync(preferred)) {
      return { buffer: fs.readFileSync(preferred), mime: "image/png" };
    }
    return { buffer: logo.buffer, mime: logo.meta.mime || "image/png" };
  }
  // Fall back to bundled public icons
  const pub = path.join(process.cwd(), "public", `icon-${size}.png`);
  if (fs.existsSync(pub)) {
    return { buffer: fs.readFileSync(pub), mime: "image/png" };
  }
  return null;
}

/**
 * Build 192 / 512 square PNGs for desktop shortcuts & home-screen icons.
 * Uses Python PIL when available; otherwise copies the logo as-is.
 */
function generatePwaIcons(logoPath: string) {
  ensure();
  const out192 = path.join(ROOT, "icon-192.png");
  const out512 = path.join(ROOT, "icon-512.png");

  const py = `
import sys
try:
    from PIL import Image
except Exception as e:
    sys.exit(2)
src, a, b = sys.argv[1], sys.argv[2], sys.argv[3]
im = Image.open(src).convert("RGBA")
# contain into square on dark shop background
def make(size, dest):
    canvas = Image.new("RGBA", (size, size), (12, 14, 18, 255))
    im2 = im.copy()
    im2.thumbnail((size - size // 8, size - size // 8), Image.Resampling.LANCZOS)
    x = (size - im2.width) // 2
    y = (size - im2.height) // 2
    canvas.paste(im2, (x, y), im2)
    canvas.save(dest, "PNG")
make(192, a)
make(512, b)
print("ok")
`;
  const r = spawnSync(
    "python3",
    ["-c", py, logoPath, out192, out512],
    { encoding: "utf8" },
  );
  if (r.status === 0 && fs.existsSync(out192) && fs.existsSync(out512)) {
    return;
  }
  // Fallback: use logo bytes for both sizes (browsers scale)
  try {
    const buf = fs.readFileSync(logoPath);
    fs.writeFileSync(out192, buf);
    fs.writeFileSync(out512, buf);
  } catch {
    /* ignore */
  }
}

export function saveCompanyLogo(opts: {
  name: string;
  mime: string;
  base64: string;
}): { ok: true; meta: LogoMeta } | { ok: false; error: string } {
  ensure();
  if (!opts.base64) return { ok: false, error: "Empty file" };
  const buf = Buffer.from(opts.base64, "base64");
  if (buf.length < 32) return { ok: false, error: "File too small" };
  if (buf.length > 6_000_000) return { ok: false, error: "Max logo size is 6 MB" };

  const mime = (opts.mime || "").toLowerCase();
  const name = (opts.name || "").toLowerCase();
  const okMime =
    mime.includes("png") ||
    mime.includes("jpeg") ||
    mime.includes("jpg") ||
    mime.includes("webp") ||
    mime.includes("svg") ||
    /\.(png|jpe?g|webp|svg)$/i.test(name);
  if (!okMime) {
    return { ok: false, error: "Use PNG, JPG, WEBP, or SVG" };
  }

  let ext = "png";
  if (mime.includes("jpeg") || mime.includes("jpg") || /\.jpe?g$/i.test(name))
    ext = "jpg";
  else if (mime.includes("webp") || name.endsWith(".webp")) ext = "webp";
  else if (mime.includes("svg") || name.endsWith(".svg")) ext = "svg";
  else if (mime.includes("png") || name.endsWith(".png")) ext = "png";

  // remove old logo + icon files
  for (const f of fs.readdirSync(ROOT)) {
    if (f.startsWith("logo.") || f.startsWith("icon-")) {
      try {
        fs.unlinkSync(path.join(ROOT, f));
      } catch {
        /* ignore */
      }
    }
  }

  const fileName = `logo.${ext}`;
  const logoPath = path.join(ROOT, fileName);
  fs.writeFileSync(logoPath, buf);
  const meta: LogoMeta = {
    fileName,
    mime:
      mime && mime.startsWith("image/")
        ? mime
        : ext === "jpg"
          ? "image/jpeg"
          : ext === "svg"
            ? "image/svg+xml"
            : `image/${ext}`,
    size: buf.length,
    updatedAt: new Date().toISOString(),
    originalName: (opts.name || fileName).slice(0, 120),
  };
  fs.writeFileSync(META, JSON.stringify(meta, null, 2));

  // Desktop shortcut / PWA icons
  generatePwaIcons(logoPath);

  return { ok: true, meta };
}

export function clearCompanyLogo(): void {
  ensure();
  for (const f of fs.readdirSync(ROOT)) {
    try {
      fs.unlinkSync(path.join(ROOT, f));
    } catch {
      /* ignore */
    }
  }
}

/** Dynamic web app manifest using custom icons when present. */
export function buildWebManifest(): string {
  const meta = getLogoMeta();
  const v = meta ? encodeURIComponent(meta.updatedAt) : "default";
  const hasCustom = Boolean(meta);
  const icon192 = hasCustom
    ? `/api/branding/icon-192?v=${v}`
    : `/icon-192.png?v=${v}`;
  const icon512 = hasCustom
    ? `/api/branding/icon-512?v=${v}`
    : `/icon-512.png?v=${v}`;
  return JSON.stringify(
    {
      name: "LCM Data Management",
      short_name: "LCM",
      description:
        "Lake Country Machine shop floor job tracking, quoting, and reports",
      start_url: "/",
      display: "standalone",
      background_color: "#0c0e12",
      theme_color: "#0c0e12",
      orientation: "any",
      icons: [
        {
          src: icon192,
          sizes: "192x192",
          type: "image/png",
          purpose: "any",
        },
        {
          src: icon512,
          sizes: "512x512",
          type: "image/png",
          purpose: "any",
        },
        {
          src: icon512,
          sizes: "512x512",
          type: "image/png",
          purpose: "maskable",
        },
      ],
    },
    null,
    2,
  );
}
