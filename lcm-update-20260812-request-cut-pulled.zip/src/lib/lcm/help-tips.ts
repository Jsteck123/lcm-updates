/** Per-user help tip visibility (local to this browser/PC). */

export type HelpTipPrefs = {
  /** Master switch — false hides all tip icons */
  showTips: boolean;
  /** Tip ids the user dismissed */
  hidden: string[];
};

const DEFAULT_PREFS: HelpTipPrefs = {
  showTips: true,
  hidden: [],
};

function key(email: string): string {
  const who = (email || "default").trim().toLowerCase() || "default";
  return `lcm-help-tips:v1:${who}`;
}

export function loadHelpTipPrefs(email: string): HelpTipPrefs {
  if (typeof window === "undefined") return { ...DEFAULT_PREFS };
  try {
    const raw = localStorage.getItem(key(email));
    if (!raw) return { ...DEFAULT_PREFS, hidden: [] };
    const parsed = JSON.parse(raw) as Partial<HelpTipPrefs>;
    return {
      showTips: parsed.showTips !== false,
      hidden: Array.isArray(parsed.hidden)
        ? parsed.hidden.map(String)
        : [],
    };
  } catch {
    return { ...DEFAULT_PREFS, hidden: [] };
  }
}

export function saveHelpTipPrefs(email: string, prefs: HelpTipPrefs): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key(email), JSON.stringify(prefs));
  } catch {
    // ignore quota
  }
}

export function isTipVisible(
  prefs: HelpTipPrefs,
  tipId: string,
): boolean {
  if (!prefs.showTips) return false;
  return !prefs.hidden.includes(tipId);
}

/** Built-in tip copy — stable ids for dismiss. Admin-only tips never shown on floor. */
export const HELP_TIPS = {
  "app-update": {
    title: "Update app",
    body: "Admin only. Choose an lcm-update zip from your developer. Program files update; data/ (quotes, inventory, orders) stays put. Restart the host app after install.",
    audience: "admin" as const,
  },

  "nav-switch-user": {
    title: "Switch user",
    body: "Change who is signed in on this PC. Admin accounts need a PIN so operators cannot open them. Each phone/PC must unlock with PIN once so chat and saves reach the shop.",
  },
  "shop-sync": {
    title: "Shop network",
    body: "Green “Shop live” means this device is unlocked and sharing the shop database. Yellow “Unlock PIN” means you can view data but chat/saves stay only on this device until you enter your PIN.",
  },
  "po-import": {
    title: "Import PO file",
    body: "Upload the customer Purchase Order PDF. The PDF stays attached as the full record. We only pull customer, PO #, date required, rating, and lines.",
  },
  "po-material": {
    title: "Material check",
    body: "Matches each line to your part database and stock. Green check = planned. ? = needs size/material attention. Click Fix to set diameter and lengths.",
  },
  "po-assign": {
    title: "Assign to machine",
    body: "Puts this PO line on a machine or person’s queue so the shop floor knows what to run next.",
  },
  "quote-part-search": {
    title: "Part # search",
    body: "Start typing a part number to load a past quote (ops, material, prices) from the database.",
    audience: "admin" as const,
  },
  "quote-ops": {
    title: "Operations",
    body: "Setup and run times per op. You can add more than 6 ops in Settings if needed.",
    audience: "admin" as const,
  },
  "shop-floor-load": {
    title: "Load job",
    body: "Start a job on this machine from a part # or from the queue. Timers track setup and runtime against the plan.",
  },
  "inventory-scan": {
    title: "Scan / issue stock",
    body: "Scan a material barcode sticker and enter length/qty used to deduct from inventory.",
  },
  "settings-import-quotes": {
    title: "Historical quotes import",
    body: "After go-live on your server: export DATABASE from Google Sheets as CSV and import here. Use Update existing for re-imports.",
    audience: "admin" as const,
  },
  "settings-pins": {
    title: "PINs & tabs",
    body: "Admins set PINs and which tabs each person can open (e.g. operators only see Dashboard, Shop Floor, Job History).",
    audience: "admin" as const,
  },
  "email-batch": {
    title: "Email quotes",
    body: "Filter by customer and date, select quotes, pick their email, preview, then send in the format customers already know.",
    audience: "admin" as const,
  },
  "help-master": {
    title: "Help tips",
    body: "Blue ? icons explain buttons and areas. Hide a tip when you know it. Office can turn all tips off/on under Settings.",
  },
} as const;

export type HelpTipId = keyof typeof HELP_TIPS;
