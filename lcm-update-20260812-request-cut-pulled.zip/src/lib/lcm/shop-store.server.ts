/**
 * Shop database: Postgres/PGLite snapshot table is primary when ready;
 * data/lcm-shop.json is the secondary backup/export (always written).
 */
import fs from "node:fs";
import path from "node:path";
import type { ShopSharedState } from "./shop-types";
import { maybeAutoBackup } from "./backup.server";
import { mergeQuoteLists } from "./po-material";
import { mergeChatMessages } from "./chat";
import {
  mergeSharedWithSeed,
  normalizeShopState,
  sliceSharedFromSeed,
  stripSecretsForClient,
} from "./normalize-shop-state";
import { hashSecret, isHashedSecret } from "./crypto";

export type { ShopSharedState };

export type ShopSnapshot = {
  rev: number;
  updatedAt: string;
  state: ShopSharedState;
};

const DATA_DIR = path.join(process.cwd(), "data");
const DATA_FILE = path.join(DATA_DIR, "lcm-shop.json");

const globalRef = globalThis as typeof globalThis & {
  __lcmShopCache__?: ShopSnapshot;
  __lcmShopWriteChain__?: Promise<void>;
  __lcmSecretsMigrated__?: boolean;
};

function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function readFromDisk(): ShopSnapshot | null {
  try {
    if (!fs.existsSync(DATA_FILE)) return null;
    const raw = fs.readFileSync(DATA_FILE, "utf8");
    const parsed = JSON.parse(raw) as ShopSnapshot;
    if (!parsed || typeof parsed.rev !== "number" || !parsed.state) return null;
    return {
      ...parsed,
      state: normalizeShopState(parsed.state as ShopSharedState),
    };
  } catch {
    return null;
  }
}

function writeToDisk(snap: ShopSnapshot) {
  ensureDir();
  const tmp = `${DATA_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(snap), "utf8");
  fs.renameSync(tmp, DATA_FILE);
  try {
    maybeAutoBackup(60 * 60 * 1000);
  } catch {
    /* backup optional */
  }
}

async function readFromSql(): Promise<ShopSnapshot | null> {
  try {
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    const rows = await sql.query<{
      rev: number;
      updated_at: string | Date;
      state: ShopSharedState | string;
    }>("select rev, updated_at, state from shop_snapshot where id = 1");
    const row = rows[0];
    if (!row) return null;
    const state =
      typeof row.state === "string"
        ? (JSON.parse(row.state) as ShopSharedState)
        : row.state;
    const updatedAt =
      row.updated_at instanceof Date
        ? row.updated_at.toISOString()
        : String(row.updated_at);
    return {
      rev: Number(row.rev),
      updatedAt,
      state: normalizeShopState(state),
    };
  } catch (err) {
    // Table missing or DB not ready — fall back to file
    console.warn("[lcm-shop] SQL read skipped:", (err as Error)?.message || err);
    return null;
  }
}

async function writeToSql(snap: ShopSnapshot): Promise<void> {
  try {
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    const stateJson = JSON.stringify(snap.state);
    await sql.query(
      `insert into shop_snapshot (id, rev, updated_at, state)
       values (1, $1, $2::timestamptz, $3::jsonb)
       on conflict (id) do update set
         rev = excluded.rev,
         updated_at = excluded.updated_at,
         state = excluded.state`,
      [snap.rev, snap.updatedAt, stateJson],
    );
  } catch (err) {
    console.warn("[lcm-shop] SQL write skipped:", (err as Error)?.message || err);
  }
}

/** Hash any legacy plaintext PINs / edit password once on load. */
async function migrateSecrets(state: ShopSharedState): Promise<{
  state: ShopSharedState;
  changed: boolean;
}> {
  let changed = false;
  const operators = await Promise.all(
    state.operators.map(async (op) => {
      const pin = (op.pin || "").trim();
      if (!pin || pin === "••••" || isHashedSecret(pin)) return op;
      changed = true;
      return { ...op, pin: await hashSecret(pin) };
    }),
  );
  let editPassword = state.settings?.editPassword || "";
  if (
    editPassword &&
    editPassword !== "••••" &&
    !isHashedSecret(editPassword)
  ) {
    editPassword = await hashSecret(editPassword);
    changed = true;
  }
  if (!changed) return { state, changed: false };
  return {
    changed: true,
    state: {
      ...state,
      operators,
      settings: { ...state.settings, editPassword },
    },
  };
}

function loadCacheSync(): ShopSnapshot {
  const disk = readFromDisk();
  if (
    disk &&
    globalRef.__lcmShopCache__ &&
    disk.rev > globalRef.__lcmShopCache__.rev
  ) {
    const fixed = {
      ...disk,
      state: mergeSharedWithSeed(disk.state as ShopSharedState),
    };
    globalRef.__lcmShopCache__ = fixed;
    return fixed;
  }
  if (globalRef.__lcmShopCache__) return globalRef.__lcmShopCache__;
  if (disk) {
    const fixed = {
      ...disk,
      state: mergeSharedWithSeed(disk.state as ShopSharedState),
    };
    globalRef.__lcmShopCache__ = fixed;
    return fixed;
  }
  const fresh: ShopSnapshot = {
    rev: 1,
    updatedAt: new Date().toISOString(),
    state: sliceSharedFromSeed(),
  };
  try {
    writeToDisk(fresh);
  } catch (err) {
    console.error("[lcm-shop] failed to write initial store", err);
  }
  globalRef.__lcmShopCache__ = fresh;
  return fresh;
}

/** Ensure secrets hashed + SQL hydrated. Call from API handlers. */
export async function ensureShopReady(): Promise<ShopSnapshot> {
  // Prefer SQL if it has a higher rev
  const sqlSnap = await readFromSql();
  const fileSnap = readFromDisk();
  let base: ShopSnapshot;
  if (sqlSnap && fileSnap) {
    base = sqlSnap.rev >= fileSnap.rev ? sqlSnap : fileSnap;
  } else {
    base = sqlSnap || fileSnap || loadCacheSync();
  }
  base = {
    ...base,
    state: mergeSharedWithSeed(base.state),
  };

  if (!globalRef.__lcmSecretsMigrated__) {
    const mig = await migrateSecrets(base.state);
    if (mig.changed) {
      base = {
        rev: base.rev + 1,
        updatedAt: new Date().toISOString(),
        state: mig.state,
      };
      writeToDisk(base);
      await writeToSql(base);
    } else {
      // ensure SQL has a row
      await writeToSql(base);
      if (!fileSnap) writeToDisk(base);
    }
    globalRef.__lcmSecretsMigrated__ = true;
  }

  globalRef.__lcmShopCache__ = base;
  return base;
}

export function getShopSnapshot(): ShopSnapshot {
  return loadCacheSync();
}

export async function getShopSnapshotAsync(): Promise<ShopSnapshot> {
  return ensureShopReady();
}


/** Prefer non-empty server data when a client pushes a thinned/empty snapshot (e.g. mid-update). */
function preferPopulated<T>(incoming: T[] | undefined, current: T[] | undefined): T[] {
  const a = Array.isArray(incoming) ? incoming : [];
  const b = Array.isArray(current) ? current : [];
  if (a.length === 0 && b.length > 0) return b;
  // Client lost most rows while host still has a full set — keep host unless client has more
  if (b.length >= 5 && a.length > 0 && a.length < Math.max(2, Math.floor(b.length * 0.35))) {
    return b;
  }
  return a.length ? a : b;
}

function mergeByIdPreferIncoming<T extends { id?: string }>(
  current: T[] | undefined,
  incoming: T[] | undefined,
): T[] {
  const cur = Array.isArray(current) ? current : [];
  const inc = Array.isArray(incoming) ? incoming : [];
  if (!inc.length) return cur;
  if (!cur.length) return inc;
  const map = new Map<string, T>();
  for (const row of cur) {
    const id = row?.id;
    if (id) map.set(id, row);
  }
  for (const row of inc) {
    const id = row?.id;
    if (!id) continue;
    map.set(id, { ...(map.get(id) as object), ...(row as object) } as T);
  }
  // Keep current-only rows (client push may be partial after a glitch)
  return Array.from(map.values());
}


export function putShopSnapshot(
  baseRev: number,
  state: ShopSharedState,
):
  | { ok: true; rev: number; updatedAt: string }
  | {
      ok: false;
      conflict: true;
      rev: number;
      state: ShopSharedState;
      updatedAt: string;
    } {
  const current = loadCacheSync();
  if (baseRev !== current.rev) {
    return {
      ok: false,
      conflict: true,
      rev: current.rev,
      state: current.state,
      updatedAt: current.updatedAt,
    };
  }
  // Never let a thin/empty client push wipe the host DB (common when host restarts mid-update)
  const mergedState: ShopSharedState = {
    ...state,
    operators: preferPopulated(state.operators, current.state.operators),
    customers: preferPopulated(state.customers, current.state.customers),
    quotes: mergeQuoteLists(current.state.quotes, state.quotes),
    jobs: mergeByIdPreferIncoming(current.state.jobs, state.jobs),
    downtimes: mergeByIdPreferIncoming(current.state.downtimes, state.downtimes),
    operatorTimeLog: preferPopulated(
      state.operatorTimeLog,
      current.state.operatorTimeLog,
    ),
    auditLog: preferPopulated(state.auditLog, current.state.auditLog),
    dayBonuses: preferPopulated(state.dayBonuses, current.state.dayBonuses),
    weeklyPayouts: preferPopulated(
      state.weeklyPayouts,
      current.state.weeklyPayouts,
    ),
    chatMessages: mergeChatMessages(
      current.state.chatMessages,
      state.chatMessages,
    ),
    materialStock: preferPopulated(
      state.materialStock,
      current.state.materialStock,
    ),
    partStock: preferPopulated(state.partStock, current.state.partStock),
    partUnits: preferPopulated(state.partUnits, current.state.partUnits),
    inventoryTxns: preferPopulated(
      state.inventoryTxns,
      current.state.inventoryTxns,
    ),
    purchaseOrders: preferPopulated(
      state.purchaseOrders,
      current.state.purchaseOrders,
    ),
    vendorRfqs: preferPopulated(state.vendorRfqs, current.state.vendorRfqs),
    shopOrders: preferPopulated(state.shopOrders, current.state.shopOrders),
    workQueue: preferPopulated(state.workQueue, current.state.workQueue),
    stockPieces: preferPopulated(state.stockPieces, current.state.stockPieces),
    quoteHistory: preferPopulated(state.quoteHistory, current.state.quoteHistory),
    emailLog: preferPopulated(state.emailLog, current.state.emailLog),
    shopToolingLogs: preferPopulated(
      state.shopToolingLogs,
      current.state.shopToolingLogs,
    ),
    // sessions / activeTimers: take incoming if present, else keep host
    sessions:
      state.sessions && Object.keys(state.sessions).length > 0
        ? state.sessions
        : current.state.sessions,
    activeTimers:
      state.activeTimers && Object.keys(state.activeTimers).length > 0
        ? state.activeTimers
        : current.state.activeTimers,
  };

  // Re-apply secrets from server if client sent masked placeholders
  const secureOps = mergedState.operators.map((op) => {
    const prev = current.state.operators.find((o) => o.id === op.id);
    if (!op.pin || op.pin === "••••") {
      return { ...op, pin: prev?.pin || "" };
    }
    return op;
  });
  let editPassword = mergedState.settings?.editPassword || "";
  if (!editPassword || editPassword === "••••") {
    editPassword = current.state.settings?.editPassword || "";
  }

  const next: ShopSnapshot = {
    rev: current.rev + 1,
    updatedAt: new Date().toISOString(),
    state: mergeSharedWithSeed({
      ...mergedState,
      operators: secureOps,
      settings: { ...mergedState.settings, editPassword },
    }),
  };
  globalRef.__lcmShopCache__ = next;
  const prev = globalRef.__lcmShopWriteChain__ ?? Promise.resolve();
  globalRef.__lcmShopWriteChain__ = prev
    .catch(() => undefined)
    .then(async () => {
      // Hash any new plaintext secrets before disk/SQL
      const mig = await migrateSecrets(next.state);
      if (mig.changed) {
        next.state = mig.state;
        globalRef.__lcmShopCache__ = next;
      }
      writeToDisk(next);
      await writeToSql(next);
    });
  return { ok: true, rev: next.rev, updatedAt: next.updatedAt };
}

/** Async put that awaits secret hashing (preferred for API). */
export async function putShopSnapshotAsync(
  baseRev: number,
  state: ShopSharedState,
): Promise<
  | { ok: true; rev: number; updatedAt: string }
  | {
      ok: false;
      conflict: true;
      rev: number;
      state: ShopSharedState;
      updatedAt: string;
    }
> {
  await ensureShopReady();
  const result = putShopSnapshot(baseRev, state);
  // wait for write chain head
  await (globalRef.__lcmShopWriteChain__ ?? Promise.resolve());
  return result;
}

export function getShopDataPath(): string {
  return DATA_FILE;
}

export { stripSecretsForClient };
