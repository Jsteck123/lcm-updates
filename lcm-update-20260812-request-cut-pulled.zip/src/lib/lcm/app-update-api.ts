import { createServerFn } from "@tanstack/react-start";

export const getAppUpdateInfo = createServerFn({ method: "GET" }).handler(
  async () => {
    const { getInstalledUpdateInfo } = await import("./app-update.server");
    return { ok: true as const, ...getInstalledUpdateInfo() };
  },
);

export const applyAppUpdate = createServerFn({ method: "POST" })
  .validator((data: { base64: string; fileName?: string }) => data)
  .handler(async ({ data }) => {
    const { applyUpdateFromBase64 } = await import("./app-update.server");
    return applyUpdateFromBase64(data.base64 || "", data.fileName || "update.zip");
  });
