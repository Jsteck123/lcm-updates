import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

const ROOT = path.join(process.cwd(), "data", "po-files");

function ensureRoot() {
  if (!fs.existsSync(ROOT)) fs.mkdirSync(ROOT, { recursive: true });
}

export type StoredFileMeta = {
  id: string;
  name: string;
  mime: string;
  size: number;
  savedAt: string;
  contentHash?: string;
};

/** Save a base64 payload; content-addressed so identical PDFs share one blob. */
export function savePoFile(opts: {
  name: string;
  mime: string;
  base64: string;
}): StoredFileMeta {
  ensureRoot();
  const buf = Buffer.from(opts.base64, "base64");
  const contentHash = crypto.createHash("sha256").update(buf).digest("hex").slice(0, 32);
  const safe = (opts.name || "file")
    .replace(/[^a-zA-Z0-9._-]+/g, "_")
    .slice(0, 120);
  const dir = path.join(ROOT, contentHash);
  fs.mkdirSync(dir, { recursive: true });
  const filePath = path.join(dir, safe);
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, buf);
  }
  const meta: StoredFileMeta = {
    id: contentHash,
    name: safe,
    mime: opts.mime || "application/octet-stream",
    size: buf.length,
    savedAt: new Date().toISOString(),
    contentHash,
  };
  fs.writeFileSync(path.join(dir, "meta.json"), JSON.stringify(meta, null, 2));
  return meta;
}

export function readPoFile(
  id: string,
): { meta: StoredFileMeta; base64: string } | null {
  const bin = readPoFileBinary(id);
  if (!bin) return null;
  return { meta: bin.meta, base64: bin.buffer.toString("base64") };
}

export function readPoFileBinary(
  id: string,
): { meta: StoredFileMeta; buffer: Buffer; filePath: string } | null {
  const safeId = String(id || "").replace(/[^a-zA-Z0-9-]/g, "");
  if (!safeId || safeId !== id) return null;
  const dir = path.join(ROOT, safeId);
  const metaPath = path.join(dir, "meta.json");
  if (!fs.existsSync(metaPath)) return null;
  try {
    const meta = JSON.parse(fs.readFileSync(metaPath, "utf8")) as StoredFileMeta;
    const filePath = path.join(dir, meta.name);
    if (!fs.existsSync(filePath)) return null;
    if (!filePath.startsWith(dir)) return null;
    const buffer = fs.readFileSync(filePath);
    return { meta, buffer, filePath };
  } catch {
    return null;
  }
}
