import type {
  InventoryTxn,
  InventoryTxnType,
  InventoryUnit,
  MaterialStock,
  PartStock,
} from "./types";

export const INVENTORY_UNITS: InventoryUnit[] = [
  "pcs",
  "bar",
  "sheet",
  "ft",
  "in",
  "lbs",
];

export const PART_CATEGORIES = [
  "Finished part",
  "Second quality / blemish",
  "WIP / semi-finished",
  "Hardware",
  "Insert / tooling",
  "Bought-out",
  "Fixture",
  "Other",
] as const;

/** Filters for Material on hand table (Inventory tab) */
export type MaterialOnHandFilters = {
  /** Free-text typeahead search across label / size / location / vendor */
  search: string;
  material: string;
  materialType: string;
  stockShape: string;
  sizeNote: string;
  location: string;
  vendor: string;
  lowOnly: boolean;
};

export const EMPTY_MAT_ON_HAND_FILTERS: MaterialOnHandFilters = {
  search: "",
  material: "",
  materialType: "",
  stockShape: "",
  sizeNote: "",
  location: "",
  vendor: "",
  lowOnly: false,
};

export function materialLabel(m: Pick<MaterialStock, "material" | "materialType" | "stockShape" | "sizeNote">): string {
  const bits = [m.material, m.materialType, m.stockShape, m.sizeNote].filter(
    (x) => String(x || "").trim(),
  );
  return bits.join(" · ") || "Material";
}

export function partLabel(p: Pick<PartStock, "partNumber" | "revision" | "description">): string {
  const rev = p.revision ? ` rev ${p.revision}` : "";
  const desc = p.description ? ` — ${p.description}` : "";
  return `${p.partNumber || "Part"}${rev}${desc}`;
}

export function isLowStock(onHand: number, minQty: number): boolean {
  if (minQty <= 0) return false;
  return onHand <= minQty;
}

export function applyQtyChange(
  onHand: number,
  kind: InventoryTxnType,
  qty: number,
): number {
  const q = Math.abs(Number(qty) || 0);
  switch (kind) {
    case "receive":
    case "return":
      return onHand + q;
    case "issue":
    case "scrap":
      return onHand - q;
    case "adjust":
      // qty is the new absolute count for adjust when signed via reason;
      // we use signed qty: positive = set delta add, or pass absolute via adjustAbsolute
      return onHand + (Number(qty) || 0);
    default:
      return onHand;
  }
}

export function emptyMaterial(partial?: Partial<MaterialStock>): MaterialStock {
  return {
    id: partial?.id || "",
    material: partial?.material || "",
    materialType: partial?.materialType || "",
    stockShape: partial?.stockShape || "",
    sizeNote: partial?.sizeNote || "",
    dimX: partial?.dimX ?? 0,
    dimY: partial?.dimY ?? 0,
    dimZ: partial?.dimZ ?? 0,
    unit: partial?.unit || "pcs",
    onHand: partial?.onHand ?? 0,
    minQty: partial?.minQty ?? 0,
    location: partial?.location || "",
    vendor: partial?.vendor || "",
    costPerUnit: partial?.costPerUnit ?? 0,
    notes: partial?.notes || "",
    updatedAt: partial?.updatedAt || new Date().toISOString(),
  };
}

export function emptyPart(partial?: Partial<PartStock>): PartStock {
  return {
    id: partial?.id || "",
    partNumber: partial?.partNumber || "",
    revision: partial?.revision || "",
    description: partial?.description || "",
    category: partial?.category || "Finished part",
    unit: partial?.unit || "pcs",
    onHand: partial?.onHand ?? 0,
    minQty: partial?.minQty ?? 0,
    location: partial?.location || "",
    vendor: partial?.vendor || "",
    costPerUnit: partial?.costPerUnit ?? 0,
    notes: partial?.notes || "",
    updatedAt: partial?.updatedAt || new Date().toISOString(),
  };
}

export function makeTxn(opts: {
  id: string;
  by: string;
  kind: InventoryTxnType;
  itemKind: "material" | "part" | "piece";
  itemId: string;
  label: string;
  qty: number;
  balanceAfter: number;
  reason?: string;
  ref?: string;
}): InventoryTxn {
  return {
    id: opts.id,
    at: new Date().toISOString(),
    by: opts.by,
    kind: opts.kind,
    itemKind: opts.itemKind,
    itemId: opts.itemId,
    label: opts.label,
    qty: opts.qty,
    balanceAfter: opts.balanceAfter,
    reason: opts.reason || "",
    ref: opts.ref || "",
  };
}


/** Alphabet without 0/O/1/I/L so sharpie codes stay readable */
const UIN_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";

/** Short 4-char UIN for marking parts with a sharpie */
export function generatePartUin(existing: Iterable<string> = []): string {
  const taken = new Set(
    [...existing].map((u) => String(u || "").trim().toUpperCase()),
  );
  for (let attempt = 0; attempt < 80; attempt++) {
    let code = "";
    for (let i = 0; i < 4; i++) {
      code += UIN_ALPHABET[Math.floor(Math.random() * UIN_ALPHABET.length)];
    }
    if (!taken.has(code)) return code;
  }
  // fallback longer
  let code = "";
  for (let i = 0; i < 6; i++) {
    code += UIN_ALPHABET[Math.floor(Math.random() * UIN_ALPHABET.length)];
  }
  return code;
}

export function normalizeUin(raw: string): string {
  return String(raw || "")
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "");
}
