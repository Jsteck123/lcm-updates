/** Operation count limits — shop can run more than the original Sheets 6-op cap. */
export const MIN_OPERATIONS = 6;
export const MAX_OPERATIONS = 16;
export const DEFAULT_OPERATIONS = 10;

export type OpKey = `OP${number}`;

export function clampOpCount(n: number | undefined | null): number {
  const v = Math.round(Number(n) || DEFAULT_OPERATIONS);
  return Math.min(MAX_OPERATIONS, Math.max(MIN_OPERATIONS, v));
}

export function opLabel(index: number): OpKey {
  return `OP${index + 1}` as OpKey;
}

export function opIndex(op: string): number {
  const n = Number(String(op).replace(/^OP/i, ""));
  return Number.isFinite(n) && n > 0 ? n - 1 : 0;
}

export function makeOpLabels(count: number): OpKey[] {
  const n = clampOpCount(count);
  return Array.from({ length: n }, (_, i) => opLabel(i));
}

/** Pad or trim a fixed-slot array to `count` length. */
export function padSlots<T>(arr: T[] | null | undefined, count: number, fill: T): T[] {
  const n = clampOpCount(count);
  const src = Array.isArray(arr) ? arr : [];
  const out: T[] = [];
  for (let i = 0; i < n; i++) {
    out.push(i < src.length ? src[i]! : fill);
  }
  return out;
}

export function zeros(count: number): number[] {
  return padSlots<number>([], count, 0);
}

export function nulls(count: number): null[] {
  return padSlots<null>([], count, null);
}

/** Highest op index that has any quoted or actual activity (+1), at least 1. */
export function usedOpCount(params: {
  setups?: (number | string | null)[];
  runtimes?: (number | string | null)[];
  quotedSetups?: number[];
  quotedRuntimes?: number[];
  setupTimes?: number[];
  runTimes?: number[];
  min?: number;
}): number {
  let max = (params.min ?? MIN_OPERATIONS) - 1;
  const arrays = [
    params.setups,
    params.runtimes,
    params.quotedSetups,
    params.quotedRuntimes,
    params.setupTimes,
    params.runTimes,
  ];
  for (const arr of arrays) {
    if (!arr) continue;
    for (let i = 0; i < arr.length; i++) {
      const v = arr[i];
      if (v == null || v === 0 || v === "") continue;
      if (typeof v === "number" && v === 0) continue;
      max = Math.max(max, i);
    }
  }
  return clampOpCount(max + 1);
}
