/**
 * Global in-app attachment preview bus.
 * Any screen (chat, PO, board) can call showAttachmentPreview — AppShell renders it.
 */
import { resolveAttachment } from "./open-attachment";

export type PreviewPayload = {
  url: string;
  mime: string;
  name: string;
  revoke?: () => void;
};

type Listener = (p: PreviewPayload | null) => void;

let current: PreviewPayload | null = null;
const listeners = new Set<Listener>();

export function subscribeAttachmentPreview(fn: Listener) {
  listeners.add(fn);
  fn(current);
  return () => {
    listeners.delete(fn);
  };
}

function emit(p: PreviewPayload | null) {
  current = p;
  listeners.forEach((fn) => fn(p));
}

export function closeAttachmentPreview() {
  current?.revoke?.();
  emit(null);
}

/** Load file from host and open in-app (fits screen). */
export async function showAttachmentPreview(opts: {
  id: string;
  name?: string;
}): Promise<{ ok: true } | { ok: false; error: string }> {
  const r = await resolveAttachment(opts);
  if (!r.ok) return r;
  // replace previous
  current?.revoke?.();
  emit({
    url: r.url,
    mime: r.mime,
    name: r.name || opts.name || "attachment",
    revoke: r.revoke,
  });
  return { ok: true };
}
