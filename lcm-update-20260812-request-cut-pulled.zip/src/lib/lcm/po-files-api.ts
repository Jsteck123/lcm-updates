import { createServerFn } from "@tanstack/react-start";

export const savePoAttachment = createServerFn({ method: "POST" })
  .validator(
    (data: {
      name: string;
      mime: string;
      base64: string;
      token?: string;
    }) => data,
  )
  .handler(async ({ data }) => {
    const { verifyShopToken } = await import("./shop-session.server");
    if (!verifyShopToken(data.token)) {
      return { ok: false as const, error: "Shop session required" };
    }
    if (!data.base64 || data.base64.length > 25_000_000) {
      return { ok: false as const, error: "File too large or empty (max ~18MB)" };
    }
    const { savePoFile } = await import("./file-store.server");
    const meta = savePoFile(data);
    return { ok: true as const, meta };
  });

export const getPoAttachment = createServerFn({ method: "POST" })
  .validator((data: { id: string; token?: string }) => data)
  .handler(async ({ data }) => {
    const { verifyShopToken } = await import("./shop-session.server");
    if (!verifyShopToken(data.token)) {
      return { ok: false as const, error: "Shop session required" };
    }
    const { readPoFile } = await import("./file-store.server");
    const file = readPoFile(data.id);
    if (!file) return { ok: false as const, error: "File not found" };
    return {
      ok: true as const,
      meta: file.meta,
      dataUrl: `data:${file.meta.mime};base64,${file.base64}`,
    };
  });
