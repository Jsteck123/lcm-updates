/**
 * Desk assign workload — hours from quoted setup + run × qty.
 */
import type { Quote, ShopOrder, WorkQueueItem } from "./types";
import { normalizeComponents } from "./line-files";

export type WorkloadBar = {
  name: string;
  hours: number;
  jobs: number;
};

function normPn(pn: string) {
  return String(pn || "")
    .trim()
    .toUpperCase();
}

/** Best quote match for a part number */
export function findQuoteForPart(
  quotes: Quote[],
  partNumber: string,
): Quote | undefined {
  const pn = normPn(partNumber);
  if (!pn) return undefined;
  const exact = quotes.filter((q) => normPn(q.partNumber) === pn);
  if (exact.length === 1) return exact[0];
  if (exact.length > 1) {
    return [...exact].sort((a, b) =>
      String(b.date || "").localeCompare(String(a.date || "")),
    )[0];
  }
  // loose: starts with / ends with
  return quotes.find(
    (q) =>
      normPn(q.partNumber).startsWith(pn) || pn.startsWith(normPn(q.partNumber)),
  );
}

/** Quoted hours: sum(setup min) + sum(run min) × qty  → hours */
export function quotedHoursForPart(
  quotes: Quote[],
  partNumber: string,
  qty: number,
): number {
  const q = findQuoteForPart(quotes, partNumber);
  if (!q) return 0;
  const setupMin = (q.setupTimes || []).reduce((a, b) => a + (Number(b) || 0), 0);
  const runMinEach = (q.runTimes || []).reduce((a, b) => a + (Number(b) || 0), 0);
  const n = Math.max(1, Number(qty) || 1);
  return Math.round(((setupMin + runMinEach * n) / 60) * 10) / 10;
}

type LoadSlice = {
  machine: string;
  operator: string;
  partNumber: string;
  qty: number;
  hours: number;
};

function collectAssignedLoads(
  orders: ShopOrder[],
  quotes: Quote[],
): LoadSlice[] {
  const out: LoadSlice[] = [];
  for (const order of orders || []) {
    if (order.status === "cancelled" || order.deliveredAt) continue;
    for (const line of order.lines || []) {
      if (line.lineStatus === "cancelled") continue;
      if (line.readyForPack || line.linePacked) continue;
      const comps = normalizeComponents(line);
      if (comps.length) {
        for (const c of comps) {
          if (c.complete) continue;
          const op = (c.officeAssignedTo || c.checkedOutBy || "").trim();
          if (!op) continue;
          const qty = c.qty || line.qty || 1;
          out.push({
            machine: (c.officeAssignedMachine || c.checkedOutMachine || "").trim(),
            operator: op,
            partNumber: c.partNumber,
            qty,
            hours: quotedHoursForPart(quotes, c.partNumber, qty),
          });
        }
      }
      const op = (line.officeAssignedTo || line.checkedOutBy || "").trim();
      if (!op) continue;
      // If only components were assigned, still count parent if assigned
      const qty = Math.max(0, (line.qty || 0) - (line.qtyCompleted || 0)) || line.qty || 1;
      out.push({
        machine: (line.officeAssignedMachine || line.checkedOutMachine || "").trim(),
        operator: op,
        partNumber: line.partNumber,
        qty,
        hours: quotedHoursForPart(quotes, line.partNumber, qty),
      });
    }
  }
  return out;
}

function collectQueueLoads(
  workQueue: WorkQueueItem[],
  quotes: Quote[],
): LoadSlice[] {
  return (workQueue || [])
    .filter(
      (q) =>
        q.status === "queued" ||
        q.status === "active" ||
        q.status === "held",
    )
    .map((q) => ({
      machine: (q.machine || "").trim(),
      operator: (q.operatorName || "").trim(),
      partNumber: q.partNumber,
      qty: q.qty || 1,
      hours: quotedHoursForPart(quotes, q.partNumber, q.qty || 1),
    }));
}

function rollup(
  slices: LoadSlice[],
  key: "machine" | "operator",
  minHours = 0,
): WorkloadBar[] {
  const map = new Map<string, { hours: number; jobs: number }>();
  for (const s of slices) {
    const name = (s[key] || "").trim();
    if (!name) continue;
    const cur = map.get(name) || { hours: 0, jobs: 0 };
    cur.hours += s.hours || 0;
    cur.jobs += 1;
    map.set(name, cur);
  }
  return [...map.entries()]
    .map(([name, v]) => ({
      name,
      hours: Math.round(v.hours * 10) / 10,
      jobs: v.jobs,
    }))
    .filter((b) => b.hours >= minHours || b.jobs > 0)
    .sort((a, b) => b.hours - a.hours);
}

/**
 * Machine + operator booked hours from:
 * - work queue (running order)
 * - office / board assignments still open
 * Hours come from historical quote setup + run × qty when available.
 */
export function buildAssignWorkload(opts: {
  shopOrders: ShopOrder[];
  workQueue: WorkQueueItem[];
  quotes: Quote[];
}): { machines: WorkloadBar[]; operators: WorkloadBar[] } {
  const slices = [
    ...collectQueueLoads(opts.workQueue || [], opts.quotes || []),
    ...collectAssignedLoads(opts.shopOrders || [], opts.quotes || []),
  ];
  // de-dupe roughly by machine+operator+part (queue + office double-count)
  const seen = new Set<string>();
  const uniq: LoadSlice[] = [];
  for (const s of slices) {
    const k = `${s.machine}|${s.operator}|${normPn(s.partNumber)}|${s.qty}`;
    if (seen.has(k)) continue;
    seen.add(k);
    uniq.push(s);
  }
  return {
    machines: rollup(uniq, "machine"),
    operators: rollup(uniq, "operator"),
  };
}
