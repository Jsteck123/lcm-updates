/**
 * Admin-only desk queue: walk POs, open drawings, assign part → person (+ optional machine).
 */
import type { ShopOrder, ShopOrderLine } from "./types";
import {
  lineCadFiles,
  lineDrawings,
  normalizeComponents,
  promoteRelatedFilesToComponents,
} from "./line-files";
import { lineShipDate } from "./shipping-calendar";

export type AssignQueueItem = {
  key: string;
  orderId: string;
  lineId: string;
  componentId: string;
  poNumber: string;
  customer: string;
  partNumber: string;
  revision: string;
  description: string;
  qty: number;
  dueDate: string;
  kind: "component" | "assembly" | "part";
  parentPartNumber: string;
  drawings: { id: string; name: string; mime?: string }[];
  cadFiles: { id: string; name: string; mime?: string }[];
  /** Already assigned at desk */
  officeAssignedTo: string;
};

function mapFiles(
  list: { id: string; name: string; mime?: string }[],
) {
  return (list || [])
    .filter((f) => f?.id)
    .map((f) => ({ id: f.id, name: f.name || "file", mime: f.mime }));
}

/** Open items that still need office person assignment */
export function buildAssignQueue(orders: ShopOrder[]): AssignQueueItem[] {
  const out: AssignQueueItem[] = [];
  for (const order of orders || []) {
    if (order.status === "cancelled" || order.deliveredAt) continue;
    for (const raw of order.lines || []) {
      if (raw.lineStatus === "cancelled") continue;
      if (raw.readyForPack || raw.linePacked) continue;
      if (!(raw.partNumber || raw.description)) continue;

      const promoted = promoteRelatedFilesToComponents(raw);
      const line = {
        ...raw,
        ...promoted,
        components: normalizeComponents({ ...raw, ...promoted }),
      } as ShopOrderLine;

      const due =
        lineShipDate(order, line) || order.dateRequired || "9999-12-31";
      const comps = normalizeComponents(line);

      if (comps.length > 0) {
        for (const c of comps) {
          if (c.complete) continue;
          if ((c.officeAssignedTo || "").trim()) continue;
          out.push({
            key: `${order.id}:${line.id}:${c.id}`,
            orderId: order.id,
            lineId: line.id,
            componentId: c.id,
            poNumber: order.poNumber || "(no PO)",
            customer: order.customer || "",
            partNumber: c.partNumber,
            revision: c.revision || line.revision || "",
            description: c.description || line.description || "",
            qty: c.qty || line.qty || 1,
            dueDate: due,
            kind: "component",
            parentPartNumber: line.partNumber,
            drawings: mapFiles(c.drawings || []),
            cadFiles: mapFiles(c.cadFiles || []),
            officeAssignedTo: "",
          });
        }
        // Assembly parent after components — only if not assigned
        if (!(line.officeAssignedTo || "").trim() && !line.readyForPack) {
          out.push({
            key: `${order.id}:${line.id}:`,
            orderId: order.id,
            lineId: line.id,
            componentId: "",
            poNumber: order.poNumber || "(no PO)",
            customer: order.customer || "",
            partNumber: line.partNumber,
            revision: line.revision || "",
            description: line.description || "",
            qty: line.qty || 1,
            dueDate: due,
            kind: "assembly",
            parentPartNumber: "",
            drawings: mapFiles(lineDrawings(line)),
            cadFiles: mapFiles(lineCadFiles(line)),
            officeAssignedTo: "",
          });
        }
      } else {
        if ((line.officeAssignedTo || "").trim()) continue;
        out.push({
          key: `${order.id}:${line.id}:`,
          orderId: order.id,
          lineId: line.id,
          componentId: "",
          poNumber: order.poNumber || "(no PO)",
          customer: order.customer || "",
          partNumber: line.partNumber,
          revision: line.revision || "",
          description: line.description || "",
          qty: line.qty || 1,
          dueDate: due,
          kind: "part",
          parentPartNumber: "",
          drawings: mapFiles(lineDrawings(line)),
          cadFiles: mapFiles(lineCadFiles(line)),
          officeAssignedTo: "",
        });
      }
    }
  }
  out.sort((a, b) => {
    const d = (a.dueDate || "").localeCompare(b.dueDate || "");
    if (d) return d;
    return (a.partNumber || "").localeCompare(b.partNumber || "");
  });
  return out;
}
