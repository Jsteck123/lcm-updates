/**
 * Shop-wide status color language (soft).
 * hold | open | active | ready | done | danger | office | soon | overdue
 */
export type ShopStatus =
  | "hold"
  | "open"
  | "active"
  | "ready"
  | "done"
  | "danger"
  | "office"
  | "soon"
  | "overdue"
  | "neutral";

export type BadgeTone =
  | "neutral"
  | "success"
  | "warn"
  | "danger"
  | "info"
  | "running"
  | "paused"
  | "hold"
  | "open"
  | "active"
  | "ready"
  | "done"
  | "office"
  | "soon"
  | "overdue";

/** Map semantic shop status → Badge tone */
export function statusToBadgeTone(status: ShopStatus): BadgeTone {
  if (status === "neutral") return "neutral";
  return status;
}

/** Soft surface class for cards */
export function statusSurfaceClass(status: ShopStatus): string {
  switch (status) {
    case "hold":
      return "status-surface-hold";
    case "open":
      return "status-surface-open";
    case "active":
      return "status-surface-active";
    case "ready":
      return "status-surface-ready";
    case "done":
      return "status-surface-done";
    case "danger":
    case "overdue":
      return "status-surface-danger";
    case "office":
      return "status-surface-office";
    case "soon":
      return "status-surface-soon";
    default:
      return "";
  }
}

export function todayYmdLocal(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

/** due within 2 days = soon (amber); past = overdue (red) */
export function dueUrgency(dueYmd: string, today = todayYmdLocal()): ShopStatus {
  if (!dueYmd || dueYmd.startsWith("9999")) return "neutral";
  if (dueYmd < today) return "overdue";
  const t = new Date(today + "T12:00:00");
  const d = new Date(dueYmd + "T12:00:00");
  const days = Math.round((d.getTime() - t.getTime()) / 86400000);
  if (days <= 2) return "soon";
  return "neutral";
}

/** Job board card status */
export function boardCardStatus(opts: {
  released: boolean;
  checkedOutBy: string;
  myName: string;
  dueDate: string;
}): ShopStatus {
  if (!opts.released) return "hold";
  if (opts.checkedOutBy) {
    if (
      opts.checkedOutBy.toLowerCase() === (opts.myName || "").toLowerCase()
    ) {
      return "active";
    }
    return "active"; // still active language; UI dims if not mine
  }
  const u = dueUrgency(opts.dueDate);
  if (u === "overdue") return "overdue";
  if (u === "soon") return "soon";
  return "open";
}

export function packStatusToShop(pack?: string): ShopStatus {
  if (pack === "verified") return "ready";
  if (pack === "packed") return "active";
  return "hold";
}

export function materialLineStatus(opts: {
  materialStatus?: string;
  materialNeeded?: number;
  materialOnHand?: number;
  material?: string;
}): ShopStatus {
  if (
    opts.material &&
    (opts.materialNeeded || 0) > (opts.materialOnHand || 0)
  ) {
    return "danger";
  }
  if (opts.materialStatus === "needs_attention") return "hold";
  if (opts.materialStatus === "ok") return "open";
  return "neutral";
}

export function inventoryQtyStatus(onHand: number, minQty?: number): ShopStatus {
  if (onHand <= 0) return "danger";
  if (minQty != null && onHand <= minQty) return "hold";
  return "open";
}

export function machineSessionStatus(opts: {
  hasJob: boolean;
  running: boolean;
  paused: boolean;
}): ShopStatus {
  if (!opts.hasJob) return "neutral";
  if (opts.running) return "active";
  if (opts.paused) return "hold";
  return "open";
}

export function deliveryCloseoutStatus(order: {
  paymentReceived?: boolean;
  invoicedInQb?: boolean;
  deliveredAt?: string;
  packStatus?: string;
}): ShopStatus {
  if (order.paymentReceived) return "done";
  if (order.invoicedInQb) return "office";
  if (order.deliveredAt) return "ready";
  if (order.packStatus === "verified") return "ready";
  if (order.packStatus === "packed") return "active";
  return "hold";
}
