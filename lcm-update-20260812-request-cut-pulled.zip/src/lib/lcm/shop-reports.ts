/**
 * Shop report aggregations for Lake Country Machine.
 * Pure helpers — no React.
 */
import type {
  DayBonusRecord,
  DowntimeEntry,
  EmailSendLog,
  JobRun,
  MaterialStock,
  PartStock,
  PurchaseOrder,
  Quote,
  ShopOrder,
  WeeklyPayout,
} from "./types";
import { totalQuotedSeconds } from "./calculations";
import {
  activeShopLineCount,
  isActiveShopLine,
  shopLineOpenQty,
  shopOrderSubtotal,
} from "./po";
import { lineReleasedToShop } from "./job-board";

export type ReportPeriod = "today" | "week" | "month" | "quarter" | "all";

export function reportPeriodRange(period: ReportPeriod): {
  start: Date;
  end: Date;
  label: string;
} {
  const end = new Date();
  end.setHours(23, 59, 59, 999);
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  let label = "Today";
  if (period === "week") {
    start.setDate(start.getDate() - 7);
    label = "Last 7 days";
  } else if (period === "month") {
    start.setMonth(start.getMonth() - 1);
    label = "Last 30 days";
  } else if (period === "quarter") {
    start.setMonth(start.getMonth() - 3);
    label = "Last 90 days";
  } else if (period === "all") {
    start.setFullYear(2020, 0, 1);
    label = "All time";
  }
  return { start, end, label };
}

function inRange(iso: string | null | undefined, start: Date, end: Date): boolean {
  if (!iso) return false;
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return false;
  return t >= start.getTime() && t <= end.getTime();
}

function jobWhen(j: JobRun): string {
  return j.endTime || j.saveTime || j.startTime;
}

export function completedJobsInPeriod(
  jobs: JobRun[],
  start: Date,
  end: Date,
): JobRun[] {
  return (jobs || []).filter((j) => {
    if (j.status !== "Completed") return false;
    return inRange(jobWhen(j), start, end);
  });
}

export function normEff(raw: number): number {
  // Some older rows store 0–100, newer 0–1
  if (!Number.isFinite(raw)) return 0;
  return raw > 1.5 ? raw / 100 : raw;
}

export type ShopPulse = {
  jobsCompleted: number;
  partsCompleted: number;
  spindleHours: number;
  quotedHours: number;
  avgEfficiency: number;
  openCustomerPos: number;
  openLineCount: number;
  openBookValue: number;
  readyToPackLines: number;
  shipPendingOrders: number;
  quotesInPeriod: number;
  emailsInPeriod: number;
  bonusEarnedInPeriod: number;
  downtimeHours: number;
};

export function buildShopPulse(opts: {
  jobs: JobRun[];
  shopOrders: ShopOrder[];
  quotes: Quote[];
  emailLog: EmailSendLog[];
  dayBonuses: DayBonusRecord[];
  downtimes: DowntimeEntry[];
  start: Date;
  end: Date;
}): ShopPulse {
  const completed = completedJobsInPeriod(opts.jobs, opts.start, opts.end);
  let spindle = 0;
  let quoted = 0;
  let effSum = 0;
  let parts = 0;
  for (const j of completed) {
    spindle += j.actualTime || 0;
    quoted += totalQuotedSeconds(j);
    effSum += normEff(j.efficiency);
    parts += Number(j.quantityCompleted) || Number(j.quantity) || 0;
  }

  const openOrders = (opts.shopOrders || []).filter(
    (o) =>
      o.status !== "cancelled" &&
      o.status !== "complete" &&
      !o.deliveredAt &&
      !o.closedAt,
  );
  let openLines = 0;
  let openBook = 0;
  let readyPack = 0;
  for (const o of openOrders) {
    openLines += activeShopLineCount(o);
    openBook += shopOrderSubtotal(o);
    for (const l of o.lines || []) {
      if (!isActiveShopLine(l)) continue;
      if (l.readyForPack && !l.linePacked) readyPack += 1;
    }
  }

  const shipPending = openOrders.filter(
    (o) => (o.packStatus || "pending") !== "verified" && !o.deliveredAt,
  ).length;

  const quotesInPeriod = (opts.quotes || []).filter((q) =>
    inRange(q.date, opts.start, opts.end),
  ).length;

  const emailsInPeriod = (opts.emailLog || []).filter((e) =>
    inRange(e.sentAt, opts.start, opts.end),
  ).length;

  let bonus = 0;
  for (const d of opts.dayBonuses || []) {
    if (d.status !== "finalized" || !d.eligible) continue;
    const t = new Date(d.dateKey + "T12:00:00").getTime();
    if (t >= opts.start.getTime() && t <= opts.end.getTime()) {
      bonus += d.bonus || 0;
    }
  }

  let dtSec = 0;
  for (const d of opts.downtimes || []) {
    if (!inRange(d.startTime, opts.start, opts.end)) continue;
    if (!d.endTime) continue;
    const a = new Date(d.startTime).getTime();
    const b = new Date(d.endTime).getTime();
    dtSec += Math.max(0, (b - a) / 1000);
  }

  return {
    jobsCompleted: completed.length,
    partsCompleted: parts,
    spindleHours: spindle / 3600,
    quotedHours: quoted / 3600,
    avgEfficiency: completed.length ? effSum / completed.length : 0,
    openCustomerPos: openOrders.length,
    openLineCount: openLines,
    openBookValue: openBook,
    readyToPackLines: readyPack,
    shipPendingOrders: shipPending,
    quotesInPeriod,
    emailsInPeriod,
    bonusEarnedInPeriod: bonus,
    downtimeHours: dtSec / 3600,
  };
}

export type MachineUtilRow = {
  machine: string;
  shortName: string;
  jobs: number;
  actualHours: number;
  quotedHours: number;
  pauseHours: number;
  avgEff: number;
};

export function buildMachineUtilization(
  machines: string[],
  completed: JobRun[],
  downtimes: DowntimeEntry[],
  start: Date,
  end: Date,
): MachineUtilRow[] {
  return machines.map((m) => {
    const machineJobs = completed.filter(
      (j) => j.machine === m || (j.machinesUsed || []).includes(m),
    );
    let actual = 0;
    let quoted = 0;
    let effSum = 0;
    for (const j of machineJobs) {
      const n = Math.max(1, (j.machinesUsed || []).length || 1);
      actual += (j.actualTime || 0) / n;
      quoted += totalQuotedSeconds(j) / n;
      effSum += normEff(j.efficiency);
    }
    const pause = (downtimes || [])
      .filter((d) => {
        if (d.machine !== m || !d.endTime) return false;
        return inRange(d.startTime, start, end);
      })
      .reduce((s, d) => {
        const a = new Date(d.startTime).getTime();
        const b = new Date(d.endTime!).getTime();
        return s + Math.max(0, (b - a) / 1000);
      }, 0);
    return {
      machine: m,
      shortName: m
        .replace("HAAS ", "")
        .replace("MAZAK ", "")
        .slice(0, 16),
      jobs: machineJobs.length,
      actualHours: +(actual / 3600).toFixed(2),
      quotedHours: +(quoted / 3600).toFixed(2),
      pauseHours: +(pause / 3600).toFixed(2),
      avgEff: machineJobs.length ? effSum / machineJobs.length : 0,
    };
  });
}

export type OperatorPerfRow = {
  name: string;
  jobs: number;
  parts: number;
  hours: number;
  avgEff: number;
  dayBonus: number;
};

export function buildOperatorPerformance(
  completed: JobRun[],
  dayBonuses: DayBonusRecord[],
  start: Date,
  end: Date,
): OperatorPerfRow[] {
  const map = new Map<
    string,
    { name: string; jobs: number; parts: number; hours: number; effSum: number; dayBonus: number }
  >();
  for (const j of completed) {
    const name = j.operator || "(unknown)";
    const row = map.get(name) || {
      name,
      jobs: 0,
      parts: 0,
      hours: 0,
      effSum: 0,
      dayBonus: 0,
    };
    row.jobs += 1;
    row.parts += Number(j.quantityCompleted) || Number(j.quantity) || 0;
    row.hours += (j.actualTime || 0) / 3600;
    row.effSum += normEff(j.efficiency);
    map.set(name, row);
  }
  for (const d of dayBonuses || []) {
    if (d.status !== "finalized" || !d.eligible) continue;
    const t = new Date(d.dateKey + "T12:00:00").getTime();
    if (t < start.getTime() || t > end.getTime()) continue;
    const row = map.get(d.operatorName) || {
      name: d.operatorName,
      jobs: 0,
      parts: 0,
      hours: 0,
      effSum: 0,
      dayBonus: 0,
    };
    row.dayBonus += d.bonus || 0;
    map.set(d.operatorName, row);
  }
  return [...map.values()]
    .map((r) => ({
      name: r.name,
      jobs: r.jobs,
      parts: r.parts,
      hours: +r.hours.toFixed(2),
      avgEff: r.jobs ? r.effSum / r.jobs : 0,
      dayBonus: r.dayBonus,
    }))
    .sort((a, b) => b.hours - a.hours || b.jobs - a.jobs);
}

export type CustomerBookRow = {
  customer: string;
  openOrders: number;
  openLines: number;
  openValue: number;
  completedJobs: number;
  quotes: number;
};

export function buildCustomerBook(
  shopOrders: ShopOrder[],
  jobs: JobRun[],
  quotes: Quote[],
  start: Date,
  end: Date,
): CustomerBookRow[] {
  const map = new Map<string, CustomerBookRow>();
  const touch = (name: string) => {
    const key = (name || "Unknown").trim() || "Unknown";
    let row = map.get(key);
    if (!row) {
      row = {
        customer: key,
        openOrders: 0,
        openLines: 0,
        openValue: 0,
        completedJobs: 0,
        quotes: 0,
      };
      map.set(key, row);
    }
    return row;
  };

  for (const o of shopOrders || []) {
    if (o.status === "cancelled") continue;
    const row = touch(o.customer);
    const open =
      o.status !== "complete" && !o.deliveredAt && !o.closedAt;
    if (open) {
      row.openOrders += 1;
      row.openLines += activeShopLineCount(o);
      row.openValue += shopOrderSubtotal(o);
    }
  }

  for (const j of completedJobsInPeriod(jobs, start, end)) {
    touch(j.customer).completedJobs += 1;
  }
  for (const q of quotes || []) {
    if (!inRange(q.date, start, end)) continue;
    touch(q.customer).quotes += 1;
  }

  return [...map.values()].sort(
    (a, b) => b.openValue - a.openValue || b.openOrders - a.openOrders,
  );
}

export type WipPipeline = {
  onHold: number;
  released: number;
  checkedOut: number;
  readyToPack: number;
  packing: number;
  verified: number;
  delivered: number;
  cancelledLines: number;
};

export function buildWipPipeline(shopOrders: ShopOrder[]): WipPipeline {
  const p: WipPipeline = {
    onHold: 0,
    released: 0,
    checkedOut: 0,
    readyToPack: 0,
    packing: 0,
    verified: 0,
    delivered: 0,
    cancelledLines: 0,
  };
  for (const o of shopOrders || []) {
    if (o.status === "cancelled") continue;
    if (o.deliveredAt) {
      p.delivered += activeShopLineCount(o) || 1;
      continue;
    }
    if ((o.packStatus || "pending") === "verified") {
      p.verified += 1;
    } else if ((o.packStatus || "pending") === "packed") {
      p.packing += 1;
    }
    for (const l of o.lines || []) {
      if (l.lineStatus === "cancelled") {
        p.cancelledLines += 1;
        continue;
      }
      if (l.linePacked) continue;
      if (l.readyForPack) {
        p.readyToPack += 1;
        continue;
      }
      if (l.checkedOutBy) {
        p.checkedOut += 1;
        continue;
      }
      if (lineReleasedToShop(l)) p.released += 1;
      else p.onHold += 1;
    }
  }
  return p;
}

export type VarianceRow = {
  id: string;
  part: string;
  rev: string;
  operator: string;
  machine: string;
  customer: string;
  qty: number;
  quoted: number;
  actual: number;
  delta: number;
  eff: number;
  when: string;
};

export function buildVarianceRows(completed: JobRun[]): VarianceRow[] {
  return completed
    .map((j) => {
      const quoted = totalQuotedSeconds(j);
      const actual = j.actualTime || 0;
      return {
        id: j.id,
        part: j.partNumber,
        rev: j.revision || "",
        operator: j.operator,
        machine: j.machine,
        customer: j.customer || "",
        qty: Number(j.quantityCompleted) || Number(j.quantity) || 0,
        quoted,
        actual,
        delta: actual - quoted,
        eff: normEff(j.efficiency),
        when: jobWhen(j),
      };
    })
    .sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta));
}

export type InventoryAlert = {
  kind: "material" | "part";
  label: string;
  onHand: number;
  minQty: number;
  short: number;
  location: string;
  vendor: string;
};

export function buildInventoryAlerts(
  materialStock: MaterialStock[],
  partStock: PartStock[],
): InventoryAlert[] {
  const out: InventoryAlert[] = [];
  for (const m of materialStock || []) {
    const min = Number(m.minQty) || 0;
    const on = Number(m.onHand) || 0;
    if (min > 0 && on <= min) {
      out.push({
        kind: "material",
        label: [m.material, m.materialType, m.stockShape, m.sizeNote]
          .filter(Boolean)
          .join(" · "),
        onHand: on,
        minQty: min,
        short: Math.max(0, min - on),
        location: m.location || "",
        vendor: m.vendor || "",
      });
    }
  }
  for (const p of partStock || []) {
    const min = Number(p.minQty) || 0;
    const on = Number(p.onHand) || 0;
    if (min > 0 && on <= min) {
      out.push({
        kind: "part",
        label: `${p.partNumber}${p.revision ? " rev " + p.revision : ""}${
          p.description ? " — " + p.description : ""
        }`,
        onHand: on,
        minQty: min,
        short: Math.max(0, min - on),
        location: p.location || "",
        vendor: p.vendor || "",
      });
    }
  }
  return out.sort((a, b) => b.short - a.short);
}

export type DowntimeReasonRow = {
  reason: string;
  count: number;
  hours: number;
};

export function buildDowntimeByReason(
  downtimes: DowntimeEntry[],
  start: Date,
  end: Date,
): DowntimeReasonRow[] {
  const map = new Map<string, DowntimeReasonRow>();
  for (const d of downtimes || []) {
    if (!inRange(d.startTime, start, end)) continue;
    const reason = d.reason || "Other";
    const row = map.get(reason) || { reason, count: 0, hours: 0 };
    row.count += 1;
    if (d.endTime) {
      const a = new Date(d.startTime).getTime();
      const b = new Date(d.endTime).getTime();
      row.hours += Math.max(0, (b - a) / 1000) / 3600;
    }
    map.set(reason, row);
  }
  return [...map.values()]
    .map((r) => ({ ...r, hours: +r.hours.toFixed(2) }))
    .sort((a, b) => b.hours - a.hours);
}

export type OpenPoRow = {
  id: string;
  poNumber: string;
  customer: string;
  status: string;
  packStatus: string;
  lines: number;
  openQty: number;
  value: number;
  dateRequired: string;
  overdue: boolean;
};

export function buildOpenPoRows(shopOrders: ShopOrder[], today = new Date()): OpenPoRow[] {
  const day = today.toISOString().slice(0, 10);
  return (shopOrders || [])
    .filter(
      (o) =>
        o.status !== "cancelled" &&
        o.status !== "complete" &&
        !o.deliveredAt &&
        !o.closedAt,
    )
    .map((o) => {
      const lines = (o.lines || []).filter((l) => isActiveShopLine(l));
      const openQty = lines.reduce((s, l) => s + shopLineOpenQty(l), 0);
      const due = o.dateRequired || "";
      return {
        id: o.id,
        poNumber: o.poNumber || "(no PO)",
        customer: o.customer || "",
        status: o.status,
        packStatus: o.packStatus || "pending",
        lines: lines.length,
        openQty,
        value: shopOrderSubtotal(o),
        dateRequired: due,
        overdue: Boolean(due && due < day),
      };
    })
    .sort((a, b) => {
      if (a.overdue !== b.overdue) return a.overdue ? -1 : 1;
      return (a.dateRequired || "9999").localeCompare(b.dateRequired || "9999");
    });
}

/** CSV helper for export buttons */
export function toCsv(headers: string[], rows: (string | number)[][]): string {
  const esc = (v: string | number) => {
    const s = String(v ?? "");
    if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
    return s;
  };
  return [headers.map(esc).join(","), ...rows.map((r) => r.map(esc).join(","))].join(
    "\n",
  );
}

export function downloadTextFile(filename: string, content: string, mime = "text/csv") {
  const blob = new Blob([content], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// silence unused import if PurchaseOrder not used yet
export type _Keep = PurchaseOrder | WeeklyPayout;
