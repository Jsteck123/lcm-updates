import type { Customer } from "./types";

export function normalizeCustomer(
  c: Partial<Customer> & Pick<Customer, "id" | "name">,
): Customer {
  const primary = String(c.email || "").trim();
  const extras = Array.isArray(c.emails)
    ? c.emails.map((e) => String(e || "").trim()).filter(Boolean)
    : [];
  const emails = [...new Set(extras.filter((e) => e.toLowerCase() !== primary.toLowerCase()))];
  return {
    id: c.id,
    name: String(c.name || "").trim(),
    email: primary,
    emails,
    lastEmailedAt: c.lastEmailedAt || null,
  };
}

export function migrateCustomers(list: Customer[] | undefined): Customer[] {
  if (!Array.isArray(list)) return [];
  return list.map((c) => normalizeCustomer(c));
}
