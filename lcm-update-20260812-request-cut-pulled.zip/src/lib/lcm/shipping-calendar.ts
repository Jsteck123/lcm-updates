/**
 * Office shipping calendar — due dates from customer POs / line items.
 */
import type { ShopOrder, ShopOrderLine } from "./types";

export type ShipDayLine = {
  orderId: string;
  lineId: string;
  poNumber: string;
  customer: string;
  partNumber: string;
  revision: string;
  description: string;
  qty: number;
  units: string;
  dueDate: string;
  orderStatus: string;
  packStatus: "pending" | "packed" | "verified";
};

export type ShipDayOrder = {
  order: ShopOrder;
  dueDate: string;
  lines: ShopOrderLine[];
};

function ymd(raw: string): string {
  if (!raw) return "";
  const s = String(raw).trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return "";
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/** Effective ship/due date for a line (line override → order due → date required) */
export function lineShipDate(order: ShopOrder, line: ShopOrderLine): string {
  return (
    ymd(line.dueDate) ||
    ymd(order.dueDate) ||
    ymd(order.dateRequired) ||
    ""
  );
}

export function orderShipDates(order: ShopOrder): string[] {
  const set = new Set<string>();
  for (const line of order.lines || []) {
    const d = lineShipDate(order, line);
    if (d) set.add(d);
  }
  if (!set.size) {
    const d = ymd(order.dueDate) || ymd(order.dateRequired);
    if (d) set.add(d);
  }
  return Array.from(set);
}

export function isActiveShipOrder(order: ShopOrder): boolean {
  return order.status !== "cancelled";
}

/** All shippable lines for a given YYYY-MM-DD */
export function linesForDate(
  orders: ShopOrder[],
  dateKey: string,
): ShipDayLine[] {
  const out: ShipDayLine[] = [];
  const key = ymd(dateKey);
  if (!key) return out;
  for (const order of orders) {
    if (!isActiveShipOrder(order)) continue;
    const packStatus = order.packStatus || "pending";
    for (const line of order.lines || []) {
      if (line.lineStatus === "cancelled") continue;
      if (lineShipDate(order, line) !== key) continue;
      if (!(line.partNumber || line.description)) continue;
      out.push({
        orderId: order.id,
        lineId: line.id,
        poNumber: order.poNumber || "(no PO)",
        customer: order.customer || "",
        partNumber: line.partNumber || "",
        revision: line.revision || "",
        description: line.description || "",
        qty: Number(line.qty) || 0,
        units: line.units || "each",
        dueDate: key,
        orderStatus: order.status,
        packStatus,
      });
    }
    // header-only due with no matching lines still show empty? skip
  }
  return out.sort((a, b) =>
    a.poNumber.localeCompare(b.poNumber) ||
    a.partNumber.localeCompare(b.partNumber),
  );
}

/** Unique orders that have at least one line (or header due) on date */
export function ordersForDate(
  orders: ShopOrder[],
  dateKey: string,
): ShipDayOrder[] {
  const key = ymd(dateKey);
  if (!key) return [];
  const out: ShipDayOrder[] = [];
  for (const order of orders) {
    if (!isActiveShipOrder(order)) continue;
    const lines = (order.lines || []).filter(
      (l) => lineShipDate(order, l) === key,
    );
    const headerOnly =
      !lines.length &&
      (ymd(order.dueDate) === key || ymd(order.dateRequired) === key);
    if (!lines.length && !headerOnly) continue;
    out.push({
      order,
      dueDate: key,
      lines: lines.length ? lines : order.lines || [],
    });
  }
  return out.sort((a, b) =>
    (a.order.poNumber || "").localeCompare(b.order.poNumber || ""),
  );
}

export type DaySummary = {
  dateKey: string;
  poCount: number;
  lineCount: number;
  totalQty: number;
  poNumbers: string[];
  pending: number;
  packed: number;
  verified: number;
};

export function monthDaySummaries(
  orders: ShopOrder[],
  year: number,
  month: number, // 0-11
): Map<string, DaySummary> {
  const map = new Map<string, DaySummary>();
  const prefix = `${year}-${String(month + 1).padStart(2, "0")}-`;
  for (const order of orders) {
    if (!isActiveShipOrder(order)) continue;
    const dates = orderShipDates(order);
    for (const d of dates) {
      if (!d.startsWith(prefix)) continue;
      let s = map.get(d);
      if (!s) {
        s = {
          dateKey: d,
          poCount: 0,
          lineCount: 0,
          totalQty: 0,
          poNumbers: [],
          pending: 0,
          packed: 0,
          verified: 0,
        };
        map.set(d, s);
      }
      if (!s.poNumbers.includes(order.poNumber || order.id)) {
        s.poNumbers.push(order.poNumber || "(no PO)");
        s.poCount += 1;
        const ps = order.packStatus || "pending";
        if (ps === "verified") s.verified += 1;
        else if (ps === "packed") s.packed += 1;
        else s.pending += 1;
      }
      for (const line of order.lines || []) {
        if (lineShipDate(order, line) !== d) continue;
        s.lineCount += 1;
        s.totalQty += Number(line.qty) || 0;
      }
    }
  }
  return map;
}

export function monthMatrix(year: number, month: number): (string | null)[][] {
  // weeks starting Sunday
  const first = new Date(year, month, 1);
  const startPad = first.getDay(); // 0 Sun
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells: (string | null)[] = [];
  for (let i = 0; i < startPad; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) {
    cells.push(
      `${year}-${String(month + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`,
    );
  }
  while (cells.length % 7 !== 0) cells.push(null);
  const weeks: (string | null)[][] = [];
  for (let i = 0; i < cells.length; i += 7) {
    weeks.push(cells.slice(i, i + 7));
  }
  return weeks;
}

export function formatMonthTitle(year: number, month: number): string {
  return new Date(year, month, 1).toLocaleString(undefined, {
    month: "long",
    year: "numeric",
  });
}

export function todayYmd(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
