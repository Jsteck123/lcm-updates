/**
 * Rolling shop averages: completed job times → quote setup/run (minutes).
 * Job timers are seconds; quotes store decimal minutes.
 * Quoted runtimes are per-piece; actual runtimes on a job are total for the qty completed.
 */

import type { AppSettings, JobRun, Quote } from "./types";
import { normalizeToolingCharges } from "./quote-tooling";
import { padSlots } from "./ops";

export type PartRunStats = {
  partNumber: string;
  revision: string;
  completedRuns: number;
  /** runs that counted toward average */
  averagedRuns: number;
  excludedRuns: number;
  /** per op, minutes */
  avgSetupMinutes: number[];
  /** per op, minutes per piece */
  avgRunMinutesEach: number[];
  avgEfficiency: number;
  lastRunAt: string | null;
  totalActualSeconds: number;
  totalQuotedSeconds: number;
};

function norm(s: string): string {
  return (s || "").trim().toUpperCase();
}

function isNum(v: unknown): v is number {
  return typeof v === "number" && Number.isFinite(v) && v > 0;
}

export function completedJobsForPart(
  jobs: JobRun[],
  partNumber: string,
  revision?: string,
  machines?: string[],
): JobRun[] {
  const pn = norm(partNumber);
  const rev = revision != null ? norm(revision) : null;
  const mach = (machines || []).map(norm).filter(Boolean);
  return (jobs || [])
    .filter((j) => j.status === "Completed" && norm(j.partNumber) === pn)
    .filter((j) => (rev == null || rev === "" ? true : norm(j.revision) === rev))
    .filter((j) => {
      if (!mach.length) return true;
      const used = [j.machine, ...(j.machinesUsed || [])].map(norm);
      return mach.some((m) => used.includes(m));
    })
    .sort(
      (a, b) =>
        new Date(b.endTime || b.saveTime || b.startTime).getTime() -
        new Date(a.endTime || a.saveTime || a.startTime).getTime(),
    );
}

export function jobVsQuote(job: JobRun): {
  quotedSeconds: number;
  actualSeconds: number;
  ratio: number;
  deltaSeconds: number;
} {
  const qty = Math.max(1, job.quantityCompleted || job.quantity || 1);
  let quotedSeconds = 0;
  const n = Math.max(
    job.quotedSetups?.length || 0,
    job.quotedRuntimes?.length || 0,
  );
  for (let i = 0; i < n; i++) {
    quotedSeconds += job.quotedSetups[i] || 0;
    quotedSeconds += (job.quotedRuntimes[i] || 0) * qty;
  }
  const actualSeconds = job.actualTime || 0;
  const ratio =
    quotedSeconds > 0
      ? actualSeconds / quotedSeconds
      : actualSeconds > 0
        ? 2
        : 1;
  return {
    quotedSeconds,
    actualSeconds,
    ratio,
    deltaSeconds: actualSeconds - quotedSeconds,
  };
}

function shouldCountInAverage(
  job: JobRun,
  outlierRatio: number,
): { ok: boolean; reason?: string } {
  if (job.countInAverage === false) {
    return { ok: false, reason: "Marked exclude from average" };
  }
  const vs = jobVsQuote(job);
  if (vs.quotedSeconds > 0 && vs.ratio > outlierRatio) {
    return {
      ok: false,
      reason: `Outlier ${vs.ratio.toFixed(2)}× quote (limit ${outlierRatio}×)`,
    };
  }
  return { ok: true };
}

export function computePartRunStats(
  jobs: JobRun[],
  partNumber: string,
  revision: string,
  opCount: number,
  settings?: Partial<
    Pick<AppSettings, "averageMaxRuns" | "averageOutlierRatio">
  >,
): PartRunStats {
  const maxRuns = Math.max(1, settings?.averageMaxRuns ?? 10);
  const outlierRatio = settings?.averageOutlierRatio ?? 1.5;

  const list = completedJobsForPart(jobs, partNumber, revision);
  const runs =
    list.length > 0 ? list : completedJobsForPart(jobs, partNumber, undefined);

  // Newest first already — take window of candidates, then filter
  const window = runs.slice(0, Math.max(maxRuns * 2, maxRuns));
  const counted: JobRun[] = [];
  let excluded = 0;
  for (const j of window) {
    if (counted.length >= maxRuns) break;
    const gate = shouldCountInAverage(j, outlierRatio);
    if (!gate.ok) {
      excluded++;
      continue;
    }
    counted.push(j);
  }

  const setupSums = Array.from({ length: opCount }, () => 0);
  const setupNs = Array.from({ length: opCount }, () => 0);
  const runSums = Array.from({ length: opCount }, () => 0);
  const runNs = Array.from({ length: opCount }, () => 0);

  let effSum = 0;
  let effN = 0;
  let totalActual = 0;
  let totalQuoted = 0;
  let lastRunAt: string | null = null;

  for (const j of counted) {
    const qty = Math.max(1, j.quantityCompleted || j.quantity || 1);
    const n = Math.max(
      opCount,
      j.setups?.length || 0,
      j.runtimes?.length || 0,
    );
    for (let i = 0; i < n && i < opCount; i++) {
      const s = j.setups[i];
      const r = j.runtimes[i];
      if (isNum(s)) {
        setupSums[i] += s;
        setupNs[i] += 1;
      }
      if (isNum(r)) {
        runSums[i] += r / qty;
        runNs[i] += 1;
      }
      totalQuoted += j.quotedSetups[i] || 0;
      totalQuoted += (j.quotedRuntimes[i] || 0) * qty;
    }
    totalActual += j.actualTime || 0;
    const eff = j.efficiency > 1 ? j.efficiency / 100 : j.efficiency;
    if (eff > 0) {
      effSum += eff;
      effN += 1;
    }
    const t = j.endTime || j.saveTime || j.startTime;
    if (t && (!lastRunAt || t > lastRunAt)) lastRunAt = t;
  }

  // Totals across ALL completed for report
  for (const j of runs) {
    const vs = jobVsQuote(j);
    // keep totalActual/quoted from counted for avg context — also expose full:
  }

  let allActual = 0;
  let allQuoted = 0;
  for (const j of runs) {
    const vs = jobVsQuote(j);
    allActual += vs.actualSeconds;
    allQuoted += vs.quotedSeconds;
  }

  const avgSetupMinutes = setupSums.map((sum, i) =>
    setupNs[i] ? sum / setupNs[i] / 60 : 0,
  );
  const avgRunMinutesEach = runSums.map((sum, i) =>
    runNs[i] ? sum / runNs[i] / 60 : 0,
  );

  return {
    partNumber: norm(partNumber),
    revision: norm(revision),
    completedRuns: runs.length,
    averagedRuns: counted.length,
    excludedRuns: excluded,
    avgSetupMinutes: padSlots(avgSetupMinutes, opCount, 0),
    avgRunMinutesEach: padSlots(avgRunMinutesEach, opCount, 0),
    avgEfficiency: effN ? effSum / effN : 0,
    lastRunAt,
    totalActualSeconds: allActual,
    totalQuotedSeconds: allQuoted,
  };
}

function roundMin(m: number): number {
  return Math.round(m * 10) / 10;
}

/**
 * Blend existing quote recipe with shop averages.
 * weightShop: 1 = replace recipe with average; 0.5 = half prior / half shop.
 * Always writes shopAvg* fields for display.
 */
export function applyAveragesToQuote(
  quote: Quote,
  stats: PartRunStats,
  opts?: { weightShop?: number; opCount?: number },
): Quote {
  const w = Math.min(1, Math.max(0, opts?.weightShop ?? 1));
  const n =
    opts?.opCount ??
    Math.max(
      quote.setupTimes?.length || 0,
      quote.runTimes?.length || 0,
      stats.avgSetupMinutes.length,
      6,
    );

  const setupTimes = padSlots(quote.setupTimes, n, 0).map((prev, i) => {
    const avg = stats.avgSetupMinutes[i] || 0;
    if (avg <= 0) return prev || 0;
    if ((prev || 0) <= 0) return roundMin(avg);
    return roundMin(prev * (1 - w) + avg * w);
  });

  const runTimes = padSlots(quote.runTimes, n, 0).map((prev, i) => {
    const avg = stats.avgRunMinutesEach[i] || 0;
    if (avg <= 0) return prev || 0;
    if ((prev || 0) <= 0) return roundMin(avg);
    return roundMin(prev * (1 - w) + avg * w);
  });

  return {
    ...quote,
    setupTimes,
    runTimes,
    shopAvgSetupTimes: padSlots(stats.avgSetupMinutes, n, 0).map(roundMin),
    shopAvgRunTimes: padSlots(stats.avgRunMinutesEach, n, 0).map(roundMin),
    shopAvgUpdatedAt: new Date().toISOString(),
    shopAvgRunCount: stats.averagedRuns,
  };
}

export function freezeQuoteSnapshot(
  quote: Quote,
  opts: {
    id: string;
    reason: "email" | "manual_lock" | "submit";
    emailedTo?: string;
    notes?: string;
  },
): import("./types").QuoteSnapshot {
  return {
    id: opts.id,
    quoteId: quote.id,
    partNumber: quote.partNumber,
    revision: quote.revision,
    customer: quote.customer,
    date: quote.date,
    frozenAt: new Date().toISOString(),
    reason: opts.reason,
    quantities: [...(quote.quantities || [])],
    prices: [...(quote.prices || [])],
    setupTimes: [...(quote.setupTimes || [])],
    runTimes: [...(quote.runTimes || [])],
    toolingCharges: normalizeToolingCharges(quote.toolingCharges),
    notes: opts.notes || "",
    emailedTo: opts.emailedTo,
  };
}
