import { createServerFn } from "@tanstack/react-start";

export const getCompanyLogoInfo = createServerFn({ method: "GET" }).handler(
  async () => {
    const { getLogoMeta } = await import("./branding.server");
    const meta = getLogoMeta();
    if (!meta) return { ok: true as const, hasLogo: false as const };
    return {
      ok: true as const,
      hasLogo: true as const,
      meta,
      /** Cache-busted URL for <img src> */
      url: `/api/branding/logo?v=${encodeURIComponent(meta.updatedAt)}`,
    };
  },
);

export const saveCompanyLogo = createServerFn({ method: "POST" })
  .validator((data: { name: string; mime: string; base64: string }) => data)
  .handler(async ({ data }) => {
    const { saveCompanyLogo: save } = await import("./branding.server");
    return save(data);
  });

export const clearCompanyLogo = createServerFn({ method: "POST" }).handler(
  async () => {
    const { clearCompanyLogo: clear } = await import("./branding.server");
    clear();
    return { ok: true as const };
  },
);
