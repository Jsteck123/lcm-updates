/**
 * Safe customer PO revision (A→B): match lines, build a diff, merge into the
 * existing shop order while preserving line ids and shop progress.
 */
import type {
  LineFileRef,
  PriorPoFile,
  ShopOrder,
  ShopOrderLine,
} from "./types";
import { emptyShopOrderLine } from "./po";
import {
  normalizeLineFiles,
  promoteRelatedFilesToComponents,
} from "./line-files";
import type { ParsedPo, ParsedPoLine } from "./po-import";

export type FieldChange = {
  field: string;
  label: string;
  from: string;
  to: string;
};

export type LineShopProgress = {
  checkedOut: boolean;
  qtyCompleted: number;
  readyForPack: boolean;
  linePacked: boolean;
  componentProgress: boolean;
};

export type PoLineDiffRow = {
  kind: "matched" | "added" | "removed";
  /** Existing line id when matched or removed */
  existingLineId?: string;
  existing?: ShopOrderLine;
  incoming?: ParsedPoLine;
  matchBy?: "item+pn" | "pn" | "item";
  changes: FieldChange[];
  progress: LineShopProgress;
  /** Removed line can be cancelled without wiping active shop work */
  canAutoCancel: boolean;
  blockReason?: string;
};

export type HeaderChange = FieldChange;

export type PoRevisePlan = {
  existingOrderId: string;
  existingPoNumber: string;
  existingPoRevision: string;
  proposedPoRevision: string;
  rows: PoLineDiffRow[];
  headerChanges: HeaderChange[];
  summary: {
    unchanged: number;
    changed: number;
    added: number;
    removed: number;
    blockedRemoves: number;
  };
};

export function normalizePoNumber(po: string): string {
  return String(po || "")
    .toUpperCase()
    .replace(/\s+/g, "")
    .trim();
}

/** Guess next document rev letter: A→B, B→C, empty→B if first known revise. */
export function nextPoRevision(current: string): string {
  const c = String(current || "")
    .trim()
    .toUpperCase();
  if (!c) return "B";
  if (/^[A-Y]$/.test(c)) return String.fromCharCode(c.charCodeAt(0) + 1);
  if (/^\d+$/.test(c)) return String(Number(c) + 1);
  return c + "+";
}

export function lineHasShopProgress(line: ShopOrderLine): LineShopProgress {
  const comps = line.components || [];
  const componentProgress = comps.some(
    (c) =>
      Boolean(c.checkedOutBy) ||
      Boolean(c.complete) ||
      Boolean(c.completedAt),
  );
  return {
    checkedOut: Boolean(line.checkedOutBy),
    qtyCompleted: Number(line.qtyCompleted) || 0,
    readyForPack: Boolean(line.readyForPack),
    linePacked: Boolean(line.linePacked),
    componentProgress,
  };
}

export function canAutoCancelLine(line: ShopOrderLine): boolean {
  const p = lineHasShopProgress(line);
  return (
    !p.checkedOut &&
    p.qtyCompleted <= 0 &&
    !p.readyForPack &&
    !p.linePacked &&
    !p.componentProgress
  );
}

function progressBlockReason(p: LineShopProgress): string {
  const bits: string[] = [];
  if (p.checkedOut) bits.push("checked out on floor");
  if (p.qtyCompleted > 0) bits.push(`${p.qtyCompleted} completed`);
  if (p.readyForPack) bits.push("ready to pack");
  if (p.linePacked) bits.push("already packed");
  if (p.componentProgress) bits.push("component work started");
  return bits.join(", ") || "shop progress";
}

function normPn(s: string): string {
  return String(s || "")
    .toUpperCase()
    .trim();
}

function normRev(s: string): string {
  return String(s || "")
    .toUpperCase()
    .trim();
}

function strNum(n: number): string {
  if (Number.isFinite(n)) return String(n);
  return "0";
}

function fieldChanges(
  existing: ShopOrderLine,
  incoming: ParsedPoLine,
): FieldChange[] {
  const out: FieldChange[] = [];
  if ((existing.itemNo || 0) !== (incoming.itemNo || 0)) {
    out.push({
      field: "itemNo",
      label: "Item #",
      from: String(existing.itemNo || ""),
      to: String(incoming.itemNo || ""),
    });
  }
  if (normPn(existing.partNumber) !== normPn(incoming.partNumber)) {
    out.push({
      field: "partNumber",
      label: "P/N",
      from: existing.partNumber || "",
      to: incoming.partNumber || "",
    });
  }
  if (
    String(existing.description || "").trim() !==
    String(incoming.description || "").trim()
  ) {
    out.push({
      field: "description",
      label: "Description",
      from: existing.description || "",
      to: incoming.description || "",
    });
  }
  if (normRev(existing.revision) !== normRev(incoming.revision)) {
    out.push({
      field: "revision",
      label: "Part rev",
      from: existing.revision || "(blank)",
      to: incoming.revision || "(blank)",
    });
  }
  if ((Number(existing.qty) || 0) !== (Number(incoming.qty) || 0)) {
    out.push({
      field: "qty",
      label: "Qty",
      from: strNum(Number(existing.qty) || 0),
      to: strNum(Number(incoming.qty) || 0),
    });
  }
  // Cost: only flag if both sides have a number and differ > 0.5¢
  const ec = Number(existing.unitCost) || 0;
  const ic = Number(incoming.unitCost) || 0;
  if (Math.abs(ec - ic) > 0.005) {
    out.push({
      field: "unitCost",
      label: "Unit cost",
      from: ec.toFixed(2),
      to: ic.toFixed(2),
    });
  }
  if (
    String(existing.units || "each").toLowerCase() !==
    String(incoming.units || "each").toLowerCase()
  ) {
    out.push({
      field: "units",
      label: "Units",
      from: existing.units || "each",
      to: incoming.units || "each",
    });
  }
  return out;
}

/**
 * Find best open order for this PO # (not cancelled, not closed/delivered preferred).
 */
export function findOrderForPoRevise(
  orders: ShopOrder[],
  poNumber: string,
): ShopOrder | null {
  const key = normalizePoNumber(poNumber);
  if (!key) return null;
  const hits = (orders || [])
    .filter((o) => normalizePoNumber(o.poNumber) === key)
    .filter((o) => o.status !== "cancelled");
  if (!hits.length) return null;
  // Prefer open / in_progress / draft over complete
  const rank = (s: string) =>
    s === "open" || s === "in_progress" || s === "draft"
      ? 0
      : s === "complete"
        ? 2
        : 1;
  hits.sort((a, b) => {
    const r = rank(a.status) - rank(b.status);
    if (r !== 0) return r;
    return String(b.updatedAt || "").localeCompare(String(a.updatedAt || ""));
  });
  return hits[0] || null;
}

type MatchPair = {
  existing: ShopOrderLine;
  incoming: ParsedPoLine;
  matchBy: "item+pn" | "pn" | "item";
};

/**
 * Match existing active lines to incoming parsed lines.
 * Priority: item# + P/N → unique P/N → unique item#.
 */
export function matchPoLines(
  existingLines: ShopOrderLine[],
  incomingLines: ParsedPoLine[],
): {
  pairs: MatchPair[];
  unmatchedExisting: ShopOrderLine[];
  unmatchedIncoming: ParsedPoLine[];
} {
  const active = (existingLines || []).filter(
    (l) => l.lineStatus !== "cancelled",
  );
  const remainingE = [...active];
  const remainingI = [...(incomingLines || [])];
  const pairs: MatchPair[] = [];

  function take(
    ei: number,
    ii: number,
    matchBy: MatchPair["matchBy"],
  ): void {
    const existing = remainingE.splice(ei, 1)[0]!;
    const incoming = remainingI.splice(ii, 1)[0]!;
    pairs.push({ existing, incoming, matchBy });
  }

  // 1) itemNo + partNumber
  for (let ii = remainingI.length - 1; ii >= 0; ii--) {
    const inc = remainingI[ii]!;
    const ei = remainingE.findIndex(
      (e) =>
        (e.itemNo || 0) === (inc.itemNo || 0) &&
        normPn(e.partNumber) === normPn(inc.partNumber) &&
        normPn(e.partNumber),
    );
    if (ei >= 0) take(ei, ii, "item+pn");
  }

  // 2) unique partNumber on both sides
  for (let ii = remainingI.length - 1; ii >= 0; ii--) {
    const inc = remainingI[ii]!;
    const pn = normPn(inc.partNumber);
    if (!pn) continue;
    const eHits = remainingE
      .map((e, idx) => ({ e, idx }))
      .filter((x) => normPn(x.e.partNumber) === pn);
    const iHits = remainingI
      .map((row, idx) => ({ row, idx }))
      .filter((x) => normPn(x.row.partNumber) === pn);
    if (eHits.length === 1 && iHits.length === 1 && iHits[0]!.idx === ii) {
      take(eHits[0]!.idx, ii, "pn");
    }
  }

  // 3) unique itemNo
  for (let ii = remainingI.length - 1; ii >= 0; ii--) {
    const inc = remainingI[ii]!;
    const item = inc.itemNo || 0;
    if (!item) continue;
    const eHits = remainingE
      .map((e, idx) => ({ e, idx }))
      .filter((x) => (x.e.itemNo || 0) === item);
    const iHits = remainingI
      .map((row, idx) => ({ row, idx }))
      .filter((x) => (x.row.itemNo || 0) === item);
    if (eHits.length === 1 && iHits.length === 1 && iHits[0]!.idx === ii) {
      take(eHits[0]!.idx, ii, "item");
    }
  }

  return {
    pairs,
    unmatchedExisting: remainingE,
    unmatchedIncoming: remainingI,
  };
}

function headerDiff(existing: ShopOrder, parsed: ParsedPo): HeaderChange[] {
  const pairs: [string, string, string, string][] = [
    ["customer", "Customer", existing.customer || "", parsed.customer || ""],
    [
      "dateRequired",
      "Date required",
      existing.dateRequired || "",
      parsed.dateRequired || "",
    ],
    ["terms", "Terms", existing.terms || "", parsed.terms || ""],
    ["fob", "FOB", existing.fob || "", parsed.fob || ""],
    [
      "shippingMethod",
      "Ship method",
      existing.shippingMethod || "",
      parsed.shippingMethod || "",
    ],
    ["buyer", "Buyer", existing.buyer || "", parsed.buyer || ""],
    ["rating", "Rating", existing.rating || "", parsed.rating || ""],
    [
      "shipToAddress",
      "Ship-to",
      existing.shipToAddress || "",
      parsed.shipToAddress || "",
    ],
  ];
  const out: HeaderChange[] = [];
  for (const [field, label, from, to] of pairs) {
    if (String(from).trim() === String(to).trim()) continue;
    if (!String(to).trim()) continue; // don't blank out existing with empty parse
    out.push({ field, label, from: from || "(blank)", to });
  }
  return out;
}

export function buildPoRevisePlan(
  existing: ShopOrder,
  parsed: ParsedPo,
  proposedPoRevision?: string,
): PoRevisePlan {
  const { pairs, unmatchedExisting, unmatchedIncoming } = matchPoLines(
    existing.lines || [],
    parsed.lines || [],
  );

  const rows: PoLineDiffRow[] = [];

  for (const p of pairs) {
    const changes = fieldChanges(p.existing, p.incoming);
    const progress = lineHasShopProgress(p.existing);
    rows.push({
      kind: "matched",
      existingLineId: p.existing.id,
      existing: p.existing,
      incoming: p.incoming,
      matchBy: p.matchBy,
      changes,
      progress,
      canAutoCancel: true,
    });
  }

  for (const inc of unmatchedIncoming) {
    rows.push({
      kind: "added",
      incoming: inc,
      changes: [],
      progress: {
        checkedOut: false,
        qtyCompleted: 0,
        readyForPack: false,
        linePacked: false,
        componentProgress: false,
      },
      canAutoCancel: true,
    });
  }

  for (const ex of unmatchedExisting) {
    const progress = lineHasShopProgress(ex);
    const ok = canAutoCancelLine(ex);
    rows.push({
      kind: "removed",
      existingLineId: ex.id,
      existing: ex,
      changes: [],
      progress,
      canAutoCancel: ok,
      blockReason: ok ? undefined : progressBlockReason(progress),
    });
  }

  // Stable sort: item no then kind
  rows.sort((a, b) => {
    const ai = a.incoming?.itemNo || a.existing?.itemNo || 0;
    const bi = b.incoming?.itemNo || b.existing?.itemNo || 0;
    if (ai !== bi) return ai - bi;
    const order = { matched: 0, added: 1, removed: 2 } as const;
    return order[a.kind] - order[b.kind];
  });

  let unchanged = 0;
  let changed = 0;
  let added = 0;
  let removed = 0;
  let blockedRemoves = 0;
  for (const r of rows) {
    if (r.kind === "added") added++;
    else if (r.kind === "removed") {
      removed++;
      if (!r.canAutoCancel) blockedRemoves++;
    } else if (r.changes.length === 0) unchanged++;
    else changed++;
  }

  const proposed =
    (proposedPoRevision || "").trim().toUpperCase() ||
    nextPoRevision(existing.poRevision || "");

  return {
    existingOrderId: existing.id,
    existingPoNumber: existing.poNumber,
    existingPoRevision: existing.poRevision || "",
    proposedPoRevision: proposed,
    rows,
    headerChanges: headerDiff(existing, parsed),
    summary: { unchanged, changed, added, removed, blockedRemoves },
  };
}

function mergeFiles(
  existing: LineFileRef[],
  add: LineFileRef[] | undefined,
): LineFileRef[] {
  const out = [...(existing || [])];
  for (const f of add || []) {
    if (!f?.id) continue;
    if (out.some((x) => x.id === f.id)) continue;
    out.push(f);
  }
  return out;
}

export type ApplyPoReviseOpts = {
  existing: ShopOrder;
  plan: PoRevisePlan;
  parsed: ParsedPo;
  /** New PO document rev letter/number */
  poRevision: string;
  sourceMeta?: { id: string; name: string; mime: string } | null;
  drawingMap?: Record<string, LineFileRef[]>;
  cadMap?: Record<string, LineFileRef[]>;
  /** Allow cancelling lines that have shop progress */
  allowBlockedCancels?: boolean;
  now?: string;
};

/**
 * Apply a confirmed revise plan. Preserves line ids for matches.
 * Removed lines become lineStatus=cancelled (never hard-deleted).
 */
export function applyPoRevise(opts: ApplyPoReviseOpts): {
  order: ShopOrder;
  auditSummary: string;
  warnings: string[];
} {
  const {
    existing,
    plan,
    parsed,
    poRevision,
    sourceMeta,
    drawingMap = {},
    cadMap = {},
    allowBlockedCancels = false,
    now = new Date().toISOString(),
  } = opts;

  const warnings: string[] = [];
  const keptCancelled = (existing.lines || []).filter(
    (l) => l.lineStatus === "cancelled",
  );

  const nextLines: ShopOrderLine[] = [...keptCancelled];
  const auditBits: string[] = [];

  for (const row of plan.rows) {
    if (row.kind === "matched" && row.existing && row.incoming) {
      const inc = row.incoming;
      const prev = row.existing;
      const revChanged =
        normRev(prev.revision) !== normRev(inc.revision);
      const qtyNew = Number(inc.qty) || 0;
      const qtyDone = Number(prev.qtyCompleted) || 0;
      if (qtyNew > 0 && qtyDone > qtyNew) {
        warnings.push(
          `${inc.partNumber || prev.partNumber}: new qty ${qtyNew} is less than completed ${qtyDone}`,
        );
      }
      let attention = prev.attentionReason || "";
      if (qtyDone > qtyNew && qtyNew > 0) {
        attention = [
          attention,
          `PO rev: qty cut to ${qtyNew} but ${qtyDone} already complete`,
        ]
          .filter(Boolean)
          .join("; ");
      }

      const pnKey = normPn(inc.partNumber);
      const drawings = mergeFiles(
        prev.drawings || [],
        drawingMap[pnKey],
      );
      const cads = mergeFiles(prev.cadFiles || [], cadMap[pnKey]);

      let line = emptyShopOrderLine({
        ...prev,
        itemNo: inc.itemNo || prev.itemNo,
        partNumber: inc.partNumber || prev.partNumber,
        description: inc.description || prev.description,
        revision: inc.revision,
        unitCost:
          Number(inc.unitCost) > 0 || inc.unitCost === 0
            ? Number(inc.unitCost) || 0
            : prev.unitCost,
        qty: qtyNew || prev.qty,
        units: inc.units || prev.units,
        taxable: inc.taxable,
        // shop progress preserved
        qtyCompleted: prev.qtyCompleted,
        checkedOutBy: prev.checkedOutBy,
        checkedOutAt: prev.checkedOutAt,
        checkedOutMachine: prev.checkedOutMachine,
        officeAssignedTo: prev.officeAssignedTo,
        officeAssignedMachine: prev.officeAssignedMachine,
        officeAssignedAt: prev.officeAssignedAt,
        officeAssignNotes: prev.officeAssignNotes,
        readyForPack: prev.readyForPack,
        readyForPackAt: prev.readyForPackAt,
        readyForPackBy: prev.readyForPackBy,
        linePacked: prev.linePacked,
        linePackedAt: prev.linePackedAt,
        linePackedBy: prev.linePackedBy,
        components: prev.components,
        material: prev.material,
        materialType: prev.materialType,
        stockShape: prev.stockShape,
        materialVendor: prev.materialVendor,
        materialNeeded: prev.materialNeeded,
        materialOnHand: prev.materialOnHand,
        materialStockId: prev.materialStockId,
        materialLocation: prev.materialLocation,
        finishedOnHand: prev.finishedOnHand,
        finishedStockId: prev.finishedStockId,
        materialMatch: prev.materialMatch,
        materialStatus: prev.materialStatus,
        materialReviewed: prev.materialReviewed,
        quoteId: prev.quoteId,
        sizeNote: prev.sizeNote,
        dimX: prev.dimX,
        dimY: prev.dimY,
        dimZ: prev.dimZ,
        partLengthEach: prev.partLengthEach,
        rawMaterialLength: prev.rawMaterialLength,
        notes: prev.notes,
        dueDate: prev.dueDate,
        // rev change → force re-check of prints
        revPdfOk: revChanged ? false : prev.revPdfOk,
        revCadOk: revChanged ? false : prev.revCadOk,
        stockNoted: prev.stockNoted,
        attentionReason: attention,
        lineStatus: "active",
        cancelledAt: "",
        cancelledReason: "",
        ...normalizeLineFiles({ drawings, cadFiles: cads }),
      });
      line = {
        ...line,
        ...promoteRelatedFilesToComponents(line),
      } as ShopOrderLine;
      nextLines.push(line);
      if (row.changes.length) {
        auditBits.push(
          `line ${line.itemNo} ${line.partNumber}: ${row.changes
            .map((c) => `${c.label} ${c.from}→${c.to}`)
            .join(", ")}`,
        );
      }
    } else if (row.kind === "added" && row.incoming) {
      const inc = row.incoming;
      const pnKey = normPn(inc.partNumber);
      const draws = drawingMap[pnKey] || [];
      const cads = cadMap[pnKey] || [];
      let line = emptyShopOrderLine({
        id: `ln_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
        itemNo: inc.itemNo,
        partNumber: inc.partNumber,
        description: inc.description,
        revision: inc.revision,
        unitCost: inc.unitCost,
        qty: inc.qty,
        units: inc.units,
        taxable: inc.taxable,
        lineStatus: "active",
        ...normalizeLineFiles({ drawings: draws, cadFiles: cads }),
      });
      line = {
        ...line,
        ...promoteRelatedFilesToComponents(line),
      } as ShopOrderLine;
      nextLines.push(line);
      auditBits.push(`added line ${line.itemNo} ${line.partNumber} qty ${line.qty}`);
    } else if (row.kind === "removed" && row.existing) {
      if (!row.canAutoCancel && !allowBlockedCancels) {
        // Keep active — office must resolve
        warnings.push(
          `Kept line ${row.existing.itemNo} ${row.existing.partNumber} active — ${row.blockReason}. Confirm cancel if intentional.`,
        );
        nextLines.push(row.existing);
        continue;
      }
      nextLines.push(
        emptyShopOrderLine({
          ...row.existing,
          lineStatus: "cancelled",
          cancelledAt: now,
          cancelledReason: `Dropped on PO rev ${poRevision || "?"}`.trim(),
        }),
      );
      auditBits.push(
        `cancelled line ${row.existing.itemNo} ${row.existing.partNumber}${
          row.canAutoCancel ? "" : " (had shop work)"
        }`,
      );
    }
  }

  // Sort active by itemNo, cancelled at end
  nextLines.sort((a, b) => {
    const ac = a.lineStatus === "cancelled" ? 1 : 0;
    const bc = b.lineStatus === "cancelled" ? 1 : 0;
    if (ac !== bc) return ac - bc;
    return (a.itemNo || 0) - (b.itemNo || 0);
  });

  const prior: PriorPoFile[] = [...(existing.priorPoFiles || [])];
  if (existing.sourceFileId) {
    prior.unshift({
      id: existing.sourceFileId,
      name: existing.sourceFileName || "prior-po.pdf",
      mime: existing.sourceFileMime || "application/pdf",
      poRevision: existing.poRevision || "",
      replacedAt: now,
    });
  }

  const order: ShopOrder = {
    ...existing,
    poNumber: parsed.poNumber || existing.poNumber,
    poRevision: (poRevision || plan.proposedPoRevision || "").toUpperCase(),
    customer: parsed.customer || existing.customer,
    customerAddress: parsed.customerAddress || existing.customerAddress,
    customerPhone: parsed.customerPhone || existing.customerPhone,
    shipToName: parsed.shipToName || existing.shipToName,
    shipToAddress: parsed.shipToAddress || existing.shipToAddress,
    attn: parsed.attn || existing.attn,
    buyer: parsed.buyer || existing.buyer,
    techContact: parsed.techContact || existing.techContact,
    dateRequired: parsed.dateRequired || existing.dateRequired,
    dueDate: parsed.dateRequired || existing.dueDate,
    fob: parsed.fob || existing.fob,
    shippingMethod: parsed.shippingMethod || existing.shippingMethod,
    terms: parsed.terms || existing.terms,
    date: parsed.date || existing.date,
    rating: parsed.rating || existing.rating,
    lines: nextLines,
    sourceFileId: sourceMeta?.id || existing.sourceFileId,
    sourceFileName: sourceMeta?.name || existing.sourceFileName,
    sourceFileMime: sourceMeta?.mime || existing.sourceFileMime,
    priorPoFiles: prior,
    updatedAt: now,
  };

  const { summary } = plan;
  const auditSummary = [
    `PO ${order.poNumber} rev ${(existing.poRevision || "?").toUpperCase() || "—"}→${order.poRevision || "—"}`,
    `${summary.changed} changed`,
    `${summary.added} added`,
    `${summary.removed} removed`,
    auditBits.slice(0, 12).join("; "),
  ]
    .filter(Boolean)
    .join(" · ");

  return { order, auditSummary, warnings };
}
