/**
 * Customer PO import — tuned for Sat-Lite emailed POs (single + multi-page).
 *
 * With position-aware PDF extraction, lines look like:
 *   1 2411-0167-01 C $115.000 10 each $1,150.00
 *   DET EL CAPSTAN, 2411 PSNR ASSY
 *   2 2411-0175-01 A $106.000 5 each $530.00
 *   DET AZ CAPSTAN, 2411 PSNR ASSY
 */

export type ParsedPoLine = {
  itemNo: number;
  partNumber: string;
  description: string;
  revision: string;
  unitCost: number;
  qty: number;
  units: string;
  taxable: boolean;
};

export type ParsedPo = {
  poNumber: string;
  customer: string;
  customerAddress: string;
  customerPhone: string;
  shipToName: string;
  shipToAddress: string;
  attn: string;
  buyer: string;
  techContact: string;
  dateRequired: string;
  fob: string;
  shippingMethod: string;
  terms: string;
  date: string;
  rating: string;
  lines: ParsedPoLine[];
  rawPreview: string;
  warnings: string[];
  looksLikeDrawing: boolean;
};

const SHOP_HINTS =
  /lake\s*country\s*machine|mineola|bromberg|p\.?o\.?\s*box\s*390/i;

function normDate(s: string): string {
  const m = String(s)
    .trim()
    .match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})$/);
  if (!m) return "";
  let y = m[3];
  if (y.length === 2) y = `20${y}`;
  return `${y}-${m[1].padStart(2, "0")}-${m[2].padStart(2, "0")}`;
}

function money(s: string): number {
  const n = Number(String(s).replace(/[$,\s]/g, ""));
  return Number.isFinite(n) ? n : 0;
}

function cleanField(s: string, max = 80): string {
  return String(s || "")
    .replace(/\s+/g, " ")
    .replace(/\s*[:|]\s*$/, "")
    .trim()
    .slice(0, max);
}

/** Part numbers like 2411-0167-01, TEST-0293-01, MH-8802 — never PO-## */
function isPartNumber(s: string): boolean {
  const t = s.trim().toUpperCase();
  if (!t || t.length < 4) return false;
  if (/^PO[-_]/.test(t)) return false;
  if (/^P\.?O\.?$/.test(t)) return false;
  if (!t.includes("-")) {
    return /^[A-Z]{2,}\d{2,}$/i.test(t);
  }
  return /^[A-Z0-9]{2,}(?:-[A-Z0-9]{1,12}){1,5}$/i.test(t);
}

export function looksLikeEngineeringDrawing(
  text: string,
  fileName = "",
): boolean {
  // Prefer start of document (cover page) — multi-page PO+drawing packets
  // often put the PO first; only use first ~5k of non-drawing-looking pages.
  const t = text.slice(0, 5000);
  const drawingSignals = [
    /DO NOT SCALE DRAWING/i,
    /DATUM REFERENCE FRAME/i,
    /UNLESS OTHERWISE SPECIFIED/i,
    /MACHINE PER CAD FILE/i,
    /TOLERANCES ARE:\s*IN INCHES/i,
    /THREADED HOLE LOCATIONAL/i,
    /EXPORT CONTROL WARNING/i,
    /\bASME Y14\.5/i,
  ].filter((re) => re.test(t)).length;

  const poSignals = [
    /Purchase\s*Order/i,
    /\bP\.?O\.?\s*(No\.?|#|Number)/i,
    /\bPO-\d{2}-[A-Z0-9]+/i,
    /DATE\s*REQUIRED/i,
    /Order\s*Qty/i,
    /SubTotal/i,
    /\bExtension\b/i,
  ].filter((re) => re.test(text.slice(0, 12000))).length;

  // Strong PO signal anywhere in first pages → not "drawing only"
  if (poSignals >= 2) return false;
  if (drawingSignals >= 2 && poSignals === 0) return true;
  if (drawingSignals >= 3 && poSignals < 2) return true;
  const name = fileName.toUpperCase();
  if (
    /^[A-Z0-9]+-\d{3,}-[A-Z0-9]+\.PDF$/i.test(name) &&
    poSignals === 0 &&
    drawingSignals >= 1
  ) {
    return true;
  }
  return false;
}

export function extractPoNumber(text: string): string {
  const patterns = [
    /\b(PO-\d{2}-X\d+)\b/i,
    /\b(PO-\d{4}-\d+)\b/i,
    /\b(PO-\d{2}-[A-Z0-9]+)\b/i,
    /\bP\.?O\.?\s*(?:No\.?|#)?\s*[:\s]*(PO[-\s]?\d{2}[-\s]?[A-Z0-9\-]+)\b/i,
  ];
  for (const re of patterns) {
    const m = text.match(re);
    if (m) return m[1].replace(/\s+/g, "").toUpperCase();
  }
  return "";
}

/** Join broken PDF rows: "1 2411-0167-01 C" + "$115.000 10 each $1,150.00" */
function coalesceSplitRows(lines: string[]): string[] {
  const out: string[] = [];
  const startsItem = (s: string) =>
    /^\d{1,3}\s+[A-Z0-9][A-Z0-9._\-\/]{2,}/i.test(s.trim());
  const looksMoneyQty = (s: string) =>
    /\$?\s*[\d,]+\.\d+\s+\d+/.test(s) ||
    /\b(each|ea|pcs?)\b/i.test(s) ||
    /^\$\s*[\d,]+/.test(s.trim());
  const completeRow = (s: string) =>
    /\b(each|ea|pcs?)\b/i.test(s) && /\$?\s*[\d,]+\.?\d*/.test(s);

  for (let i = 0; i < lines.length; i++) {
    let cur = lines[i].trim();
    if (!cur) continue;

    // Merge up to 3 following fragments into an incomplete item row
    if (startsItem(cur) && !completeRow(cur)) {
      let j = i + 1;
      let merged = cur;
      while (j < lines.length && j <= i + 4) {
        const next = lines[j].trim();
        if (!next) {
          j++;
          continue;
        }
        if (startsItem(next) && completeRow(next)) break;
        if (startsItem(next) && !looksMoneyQty(next)) break;
        // page header noise
        if (
          /^item\b/i.test(next) ||
          /^purchase\s*order/i.test(next) ||
          /^page\s+\d+/i.test(next) ||
          /^date\s*required/i.test(next)
        ) {
          j++;
          continue;
        }
        merged = `${merged} ${next}`.replace(/\s+/g, " ").trim();
        j++;
        if (completeRow(merged)) break;
      }
      out.push(merged);
      i = j - 1;
      continue;
    }
    out.push(cur);
  }
  return out;
}

/**
 * Sat-Lite style rows (description often multi-line under P/N):
 *   1 4201-0200-02 DET REFL LATCH CLEVIS BOLT D $0.00 57 each N $0.00
 *   1/2-13UNC - 4.2M REFL ASSY
 *   [Need cost for qty-50]   ← ignore notes, not description
 *
 * Older format (desc on next line only):
 *   1 2411-0167-01 C $115.000 10 each $1,150.00
 *   DET EL CAPSTAN, 2411 PSNR ASSY
 */
function cleanDescription(raw: string): string {
  let s = String(raw || "")
    .replace(/\r/g, "\n")
    // qty / cost notes that appear in the Order Qty column
    .replace(/\[\s*Need[^\]]*\]/gi, " ")
    .replace(/\bNeed\s+cost\s+for\s+qty[-\s]?\d+\b/gi, " ")
    .replace(/\bNeed\s+\d{1,2}\/\d{1,2}\b/gi, " ")
    // tax letter left alone at end of a fragment
    .replace(/(?:^|\s)[YN](?:\s|$)/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  // drop if it's only money / qty noise
  if (!s || /^[\d$.,\s]+$/.test(s)) return "";
  if (/^(each|ea|pcs?|n|y)$/i.test(s)) return "";
  return cleanField(s, 240);
}

/** Collect following description lines until next item / footer. */
function collectDescriptionLines(
  lines: string[],
  startIdx: number,
  isItemRow: (s: string) => boolean,
): { description: string; nextIndex: number } {
  const parts: string[] = [];
  let i = startIdx;
  while (i < lines.length) {
    const next = lines[i].trim();
    if (!next) {
      i++;
      continue;
    }
    if (isItemRow(next)) break;
    if (/^item\b/i.test(next) && /p\/?n|rev|qty|cost/i.test(next)) break;
    if (
      /^(subtotal|sales\s*tax|total\s*due|amount\s*due|please check|please acknowledge)/i.test(
        next,
      )
    ) {
      break;
    }
    if (/^page\s+\d+/i.test(next)) break;
    if (/^purchase\s*order\b/i.test(next) && next.length < 40) break;
    // bracket notes only — skip, keep scanning for more real desc lines
    if (/^\[\s*Need/i.test(next) || /^Need\s+cost\s+for/i.test(next)) {
      i++;
      continue;
    }
    // pure money / units residue
    if (/^\$?\s*[\d,]+\.?\d*\s*$/.test(next)) {
      i++;
      continue;
    }
    if (/^(each|ea|pcs?)\s*$/i.test(next)) {
      i++;
      continue;
    }
    parts.push(next);
    i++;
    // usually 1–3 description lines
    if (parts.length >= 4) break;
  }
  return {
    description: cleanDescription(parts.join(" ")),
    nextIndex: i - 1,
  };
}

function parseLineItemsFromLines(linesIn: string[]): ParsedPoLine[] {
  const lines = coalesceSplitRows(linesIn);
  const out: ParsedPoLine[] = [];
  const seen = new Set<string>(); // itemNo|part

  // Optional Tax Y/N before extension — we parse it only so the $ columns line up;
  // UI still only stores: part, description, rev, cost, qty, units (taxable bool).
  const taxOpt = `(?:\\s+([YN]))?`;

  // item part rev $cost qty unit [tax] $ext  — description on following lines
  const rowNoDesc = new RegExp(
    `^(\\d{1,3})\\s+([A-Z0-9][A-Z0-9._\\-\\/]{2,})\\s+([A-Z0-9]{1,4})\\s+\\$?\\s*([\\d,]+\\.?\\d*)\\s+(\\d+(?:\\.\\d+)?)\\s*(?:(each|ea|pcs?|pc)\\s*)?${taxOpt}\\s*\\$?\\s*([\\d,]+\\.?\\d*)\\s*$`,
    "i",
  );

  // item part DESCRIPTION rev $cost qty unit [tax] $ext
  // Description is non-greedy middle; rev is short token before first $
  const rowWithDesc = new RegExp(
    `^(\\d{1,3})\\s+([A-Z0-9][A-Z0-9._\\-\\/]{2,})\\s+(.+?)\\s+([A-Z0-9]{1,4})\\s+\\$\\s*([\\d,]+\\.\\d{2,4})\\s+(\\d+(?:\\.\\d+)?)\\s*(?:(each|ea|pcs?|pc)\\s*)?${taxOpt}\\s*\\$?\\s*([\\d,]+\\.?\\d*)\\s*$`,
    "i",
  );

  // Same without requiring $ before unit cost (some extracts drop $)
  const rowWithDescLoose = new RegExp(
    `^(\\d{1,3})\\s+([A-Z0-9][A-Z0-9._\\-\\/]{2,})\\s+(.+?)\\s+([A-Z0-9]{1,4})\\s+([\\d,]+\\.\\d{2,4})\\s+(\\d+(?:\\.\\d+)?)\\s+(each|ea|pcs?|pc)${taxOpt}\\s+\\$?\\s*([\\d,]+\\.?\\d*)\\s*$`,
    "i",
  );

  const skipNoise = (line: string) =>
    /^item\b/i.test(line) && /p\/?n|part|rev|qty|cost|description/i.test(line);

  const isFooter = (line: string) =>
    /^(subtotal|sales\s*tax|total\s*due|amount\s*due)\b/i.test(line) ||
    /^please check|^please acknowledge|^send all invoices/i.test(line);

  const looksLikeItemStart = (s: string) =>
    /^\d{1,3}\s+[A-Z0-9][A-Z0-9._\-\/]{2,}/i.test(s.trim()) &&
    (rowNoDesc.test(s) ||
      rowWithDesc.test(s) ||
      rowWithDescLoose.test(s) ||
      /\$\s*[\d,]+\.\d+/.test(s));

  const badRev = new Set([
    "SCHEDULE",
    "COST",
    "QTY",
    "ITEM",
    "EACH",
    "UNIT",
    "TAX",
    "EXT",
  ]);

  const pushLine = (row: ParsedPoLine) => {
    if (!isPartNumber(row.partNumber)) return;
    const key = `${row.itemNo}|${row.partNumber}`;
    if (seen.has(key)) return;
    seen.add(key);
    seen.add(`*|${row.partNumber}`);
    out.push({
      ...row,
      description: cleanDescription(row.description),
    });
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    if (skipNoise(line)) continue;
    if (isFooter(line)) continue;
    if (/^page\s+\d+\s+of\s+\d+/i.test(line)) continue;
    if (/^purchase\s*order\b/i.test(line) && line.length < 40) continue;

    // Prefer: part + description on same line (Sat-Lite table)
    let m = line.match(rowWithDesc) || line.match(rowWithDescLoose);
    if (m && isPartNumber(m[2])) {
      const rev = m[4].toUpperCase();
      if (!badRev.has(rev)) {
        let desc = cleanDescription(m[3]);
        // Multi-line description under the row
        const more = collectDescriptionLines(
          lines,
          i + 1,
          looksLikeItemStart,
        );
        if (more.description) {
          desc = cleanDescription([desc, more.description].filter(Boolean).join(" "));
          i = more.nextIndex;
        }
        // Tax letter only used for taxable flag; not shown as its own column
        const tax = (m[8] || m[7] || "").toUpperCase();
        const unitsRaw = (m[7] || m[6] || "each").toString();
        const units = /^[YN]$/i.test(unitsRaw)
          ? "each"
          : unitsRaw.toLowerCase().startsWith("ea")
            ? "each"
            : unitsRaw.toLowerCase();
        // rowWithDesc groups: 1 item 2 part 3 desc 4 rev 5 cost 6 qty 7 units 8 tax? 9 ext
        // rowWithDescLoose: same but cost without $
        const unitCost = money(m[5]);
        const qty = Number(m[6]) || 1;
        const taxFlag = (m[8] || "").toUpperCase();
        pushLine({
          itemNo: Number(m[1]) || out.length + 1,
          partNumber: m[2].toUpperCase(),
          description: desc,
          revision: rev,
          unitCost,
          qty,
          units: units === "pc" || units === "pcs" ? "each" : units || "each",
          taxable: taxFlag === "Y",
        });
        continue;
      }
    }

    m = line.match(rowNoDesc);
    if (m && isPartNumber(m[2])) {
      const rev = m[3].toUpperCase();
      if (!badRev.has(rev)) {
        const more = collectDescriptionLines(
          lines,
          i + 1,
          looksLikeItemStart,
        );
        const taxFlag = (m[7] || "").toUpperCase();
        const unitsRaw = (m[6] || "each").toString();
        pushLine({
          itemNo: Number(m[1]) || out.length + 1,
          partNumber: m[2].toUpperCase(),
          description: more.description,
          revision: rev,
          unitCost: money(m[4]),
          qty: Number(m[5]) || 1,
          units: unitsRaw.toLowerCase().startsWith("ea")
            ? "each"
            : unitsRaw.toLowerCase() || "each",
          taxable: taxFlag === "Y",
        });
        i = more.nextIndex >= i ? more.nextIndex : i;
        continue;
      }
    }
  }

  // Flattened fallback — still pick up multi-line desc after match
  if (out.length === 0) {
    const blob = lines.join("\n");
    const re =
      /(\d{1,3})\s+([A-Z0-9][A-Z0-9._\-\/]{2,})\s+([A-Z0-9]{1,4})\s+\$?\s*([\d,]+\.?\d*)\s+(\d+(?:\.\d+)?)\s*(?:(each|ea|pcs?)\s*)?(?:[YN]\s+)?\$?\s*([\d,]+\.?\d*)/gi;
    let m: RegExpExecArray | null;
    while ((m = re.exec(blob)) !== null) {
      if (!isPartNumber(m[2])) continue;
      const partNumber = m[2].toUpperCase();
      const itemNo = Number(m[1]) || out.length + 1;
      const key = `${itemNo}|${partNumber}`;
      if (seen.has(key)) continue;
      const after = blob.slice(m.index + m[0].length, m.index + m[0].length + 200);
      const descM = after.match(
        /^\s*([A-Za-z0-9][^\n\[]{2,120}?)(?=\s*\n\s*\d{1,3}\s+[A-Z0-9]|\s*SubTotal|\s*Sales|\s*PLEASE|\s*$)/i,
      );
      seen.add(key);
      out.push({
        itemNo,
        partNumber,
        description: cleanDescription(descM ? descM[1] : ""),
        revision: m[3].toUpperCase(),
        unitCost: money(m[4]),
        qty: Number(m[5]) || 1,
        units: "each",
        taxable: false,
      });
    }
  }

  if (out.length === 0) {
    const blob = lines.join(" ");
    const re =
      /\b(\d{1,3})\s+([A-Z0-9]{2,}(?:-[A-Z0-9]{1,12}){1,4})\b[^\$]{0,80}\$\s*([\d,]+\.\d{2,4})\s+(\d+(?:\.\d+)?)/gi;
    let m: RegExpExecArray | null;
    while ((m = re.exec(blob)) !== null) {
      if (!isPartNumber(m[2])) continue;
      const partNumber = m[2].toUpperCase();
      const itemNo = Number(m[1]) || out.length + 1;
      const key = `${itemNo}|${partNumber}`;
      if (seen.has(key)) continue;
      // description between part and $
      const between = blob.slice(m.index, m.index + m[0].length);
      const descBetween = between
        .replace(m[0], "")
        .replace(partNumber, "")
        .replace(/^\d+\s*/, "");
      seen.add(key);
      out.push({
        itemNo,
        partNumber,
        description: cleanDescription(descBetween),
        revision: "A",
        unitCost: money(m[3]),
        qty: Number(m[4]) || 1,
        units: "each",
        taxable: false,
      });
    }
  }

  return out.sort((a, b) => a.itemNo - b.itemNo);
}

function fieldAfter(lines: string[], label: RegExp): string {
  for (const line of lines) {
    const m = line.match(label);
    if (!m) continue;
    let rest = line.slice(m.index! + m[0].length).trim();
    rest = rest.split(
      /\b(?:Attn|Account|Buyer|Tech\.?\s*Contact|DATE\s*REQUIRED|F\.?O\.?B|SHIPPING\s*METHOD|TERMS|DATE|P\.?O\.?\s*No|Phone)\s*:/i,
    )[0];
    rest = rest.replace(/^[:\s]+/, "");
    if (rest) return cleanField(rest, 60);
  }
  return "";
}

export function parsePoText(text: string, fileName = ""): ParsedPo {
  const warnings: string[] = [];
  const lines = text
    .replace(/\r/g, "\n")
    .split("\n")
    .map((l) => l.replace(/[ \t]+/g, " ").trim())
    .filter(Boolean);

  const oneLine = lines.join(" ");

  if (looksLikeEngineeringDrawing(text, fileName)) {
    return {
      poNumber: "",
      customer: "",
      customerAddress: "",
      customerPhone: "",
      shipToName: "",
      shipToAddress: "",
      attn: "",
      buyer: "",
      techContact: "",
      dateRequired: "",
      fob: "",
      shippingMethod: "",
      terms: "",
      date: "",
      rating: "",
      lines: [],
      rawPreview: text.slice(0, 1500),
      warnings: [
        "This file looks like an engineering drawing, not a purchase order. Upload the PO PDF in step 1; use drawings in step 2.",
      ],
      looksLikeDrawing: true,
    };
  }

  const poNumber = extractPoNumber(oneLine);

  let customer = "";
  if (/\bSat[-\s]?Lite\s+Technologies\b/i.test(oneLine)) {
    customer = "Sat-Lite Technologies";
  } else {
    const letterhead = oneLine.match(
      /\b([A-Z][A-Za-z0-9 &.\-]{2,40}(?:Technologies|Tech|Hydraulics|Inc\.?|LLC|Corp|Company))\b/,
    );
    if (letterhead && !SHOP_HINTS.test(letterhead[1])) {
      customer = cleanField(letterhead[1], 60);
    }
  }

  let customerAddress = "";
  const satAddr = oneLine.match(
    /(1969\s+Willow\s+Lake\s+(?:Dr|Drive)\.?[,\s]+White\s+Oak,?\s+Tx?\s*\d{5})/i,
  );
  if (satAddr) customerAddress = satAddr[1].replace(/\s+/g, " ").trim();

  let shipToName = customer;
  let shipToAddress = customerAddress;
  for (let i = 0; i < lines.length; i++) {
    if (/^Ship\s*To:/i.test(lines[i]) || /To:\s*Ship\s*To:/i.test(lines[i])) {
      const block = lines.slice(i, i + 6).join(" ");
      if (/Sat[-\s]?Lite/i.test(block)) {
        shipToName = "Sat-Lite Technologies";
        if (satAddr) shipToAddress = customerAddress;
      }
      break;
    }
  }

  let customerPhone = "";
  const phones = [
    ...oneLine.matchAll(/\b(903[-.\s]?\d{3}[-.\s]?\d{4})\b/g),
  ].map((x) => x[1]);
  customerPhone =
    phones.find((p) => /295[-.\s]?3400/.test(p)) || phones[0] || "";

  let attn = fieldAfter(lines, /\bAttn:\s*/i);
  attn = attn.split(/\bBuyer:/i)[0].trim();
  if (/^(Account|DATE|F\.?O\.?B)/i.test(attn)) attn = "";

  let buyer = fieldAfter(lines, /\bBuyer:\s*/i);
  buyer = buyer.split(/\bTech/i)[0].trim();
  if (!buyer && /Michelle\s+Raymond/i.test(oneLine)) {
    buyer = "Michelle Raymond";
  }

  let techContact = fieldAfter(lines, /\bTech\.?\s*Contact:\s*/i);
  if (/^(SHIPPING|TERMS|DATE|P\.?O)/i.test(techContact)) techContact = "";

  let dateRequired = "";
  let fob = "";
  let shippingMethod = "";
  let terms = "";
  let date = "";

  for (let i = 0; i < lines.length; i++) {
    if (/DATE\s*REQUIRED/i.test(lines[i]) && /F\.?O\.?B/i.test(lines[i])) {
      const vals = (lines[i + 1] || "").trim();
      const vm = vals.match(
        /^(\d{1,2}\/\d{1,2}\/\d{2,4})\s+(\S+)\s+(.+?)\s+(N\d+|Net\s*\d+)\s+(\d{1,2}\/\d{1,2}\/\d{2,4})/i,
      );
      if (vm) {
        dateRequired = normDate(vm[1]);
        fob = cleanField(vm[2], 20);
        shippingMethod = cleanField(vm[3], 30);
        terms = cleanField(vm[4], 20);
        date = normDate(vm[5]);
      } else {
        const dates = [...vals.matchAll(/(\d{1,2}\/\d{1,2}\/\d{2,4})/g)].map(
          (x) => x[1],
        );
        if (dates[0]) dateRequired = normDate(dates[0]);
        if (dates[1]) date = normDate(dates[1]);
        if (/\bOrigin\b/i.test(vals)) fob = "Origin";
        const t = vals.match(/\b(N\d{1,3})\b/i);
        if (t) terms = t[1].toUpperCase();
        const ship = vals.match(
          /\b(Drop\s*Off|PFC|UPS|FedEx|Will\s*Call|Pickup)\b/i,
        );
        if (ship) shippingMethod = ship[1];
      }
      break;
    }
  }

  if (!dateRequired) {
    const dr = oneLine.match(
      /DATE\s*REQUIRED[^\d]{0,20}(\d{1,2}\/\d{1,2}\/\d{2,4})/i,
    );
    if (dr) dateRequired = normDate(dr[1]);
  }
  if (!fob && /\bOrigin\b/i.test(oneLine)) fob = "Origin";
  if (!terms) {
    const t =
      oneLine.match(/\bTERMS\s+(N\d{1,3})/i) || oneLine.match(/\b(N30)\b/i);
    if (t) terms = t[1].toUpperCase();
  }
  if (!date) {
    const d = oneLine.match(
      /(\d{1,2}\/\d{1,2}\/\d{2,4})\s+PO-\d{2}-[A-Z0-9]+/i,
    );
    if (d) date = normDate(d[1]);
  }
  if (!shippingMethod) {
    const sm = oneLine.match(
      /SHIPPING\s*METHOD\s+([A-Za-z][A-Za-z0-9 \-]{0,24})/i,
    );
    if (sm) {
      shippingMethod = cleanField(sm[1], 24)
        .split(/\s+(TERMS|DATE|P\.?O)/i)[0]
        .trim();
    }
  }

  const parsedLines = parseLineItemsFromLines(lines);

  if (!poNumber) warnings.push("PO number not found — enter it manually.");
  if (!customer) warnings.push("Customer not found — enter it manually.");
  if (!parsedLines.length) {
    warnings.push(
      "No part lines found. For multi-page POs, upload the full Purchase Order PDF (all pages). If it is a scan/image-only PDF, paste text or enter lines by hand.",
    );
  }

  const safeLines = parsedLines.filter((l) => isPartNumber(l.partNumber));

  return {
    poNumber,
    customer,
    customerAddress,
    customerPhone,
    shipToName: shipToName || customer,
    shipToAddress,
    attn,
    buyer,
    techContact,
    dateRequired,
    fob,
    shippingMethod,
    terms,
    date,
    rating: "",
    lines: safeLines,
    rawPreview: lines.slice(0, 120).join("\n"),
    warnings,
    looksLikeDrawing: false,
  };
}

/** Merge several PO text extracts (multi-file series) into one ParsedPo. */
export function mergeParsedPos(parts: ParsedPo[]): ParsedPo {
  if (!parts.length) {
    return parsePoText("");
  }
  const base = { ...parts[0], lines: [...parts[0].lines], warnings: [...parts[0].warnings] };
  const seen = new Set(base.lines.map((l) => `${l.itemNo}|${l.partNumber}`));
  for (let i = 1; i < parts.length; i++) {
    const p = parts[i];
    if (!base.poNumber && p.poNumber) base.poNumber = p.poNumber;
    if (!base.customer && p.customer) base.customer = p.customer;
    if (!base.dateRequired && p.dateRequired) base.dateRequired = p.dateRequired;
    if (!base.date && p.date) base.date = p.date;
    if (!base.buyer && p.buyer) base.buyer = p.buyer;
    for (const line of p.lines) {
      const key = `${line.itemNo}|${line.partNumber}`;
      if (seen.has(key)) continue;
      // also skip exact same part if item numbers differ but already have part
      if (seen.has(`*|${line.partNumber}`) && line.itemNo === 0) continue;
      seen.add(key);
      seen.add(`*|${line.partNumber}`);
      base.lines.push(line);
    }
    for (const w of p.warnings) {
      if (!base.warnings.includes(w)) base.warnings.push(w);
    }
    if (p.rawPreview) {
      base.rawPreview = `${base.rawPreview}\n---\n${p.rawPreview}`.slice(0, 4000);
    }
  }
  base.lines.sort((a, b) => a.itemNo - b.itemNo);
  base.looksLikeDrawing = parts.every((p) => p.looksLikeDrawing);
  if (base.lines.length) {
    base.warnings = base.warnings.filter((w) => !/no part lines/i.test(w));
  }
  return base;
}

export type PackageFileKind = "po" | "drawing" | "cad" | "unknown";

const CAD_EXT =
  /\.(x_t|x_b|step|stp|iges?|igs|sldprt|sldasm|prt|par|psm|asm|f3d|3dxml|sat|sab|jt|stl|obj|parasolid)$/i;
const DRAWING_EXT = /\.(pdf|png|jpe?g|tif{1,2}|gif|bmp|webp|dxf|dwg)$/i;
/** Strong PO filename signals (customer packages). */
export function looksLikePoFileName(name: string): boolean {
  const n = (name || "").trim();
  if (!n) return false;
  // Explicit drawing/print → not PO
  if (/\b(draw|drawing|print|blueprint|cad\s*file)\b/i.test(n)) return false;
  // Common shop PO patterns: PO-26-X679, PO_26, Purchase Order, P.O. 12345
  if (/\bPO[-_\s]?\d{2}[-_][A-Z0-9]+/i.test(n)) return true;
  if (/\bPO[-_\s]?\d{4,}/i.test(n)) return true;
  if (/purchase[\s_-]*order/i.test(n)) return true;
  if (/\bp\.?o\.?\b/i.test(n) && /\d{3,}/.test(n)) return true;
  if (/\b(po|order)\b/i.test(n) && !/\bpart\b/i.test(n)) return true;
  return false;
}

/** Classify a customer package file (PO vs shop drawing vs CAD solid). */
export function classifyPackageFile(
  name: string,
  mime = "",
): PackageFileKind {
  const n = (name || "").trim();
  const lower = n.toLowerCase();
  const m = (mime || "").toLowerCase();

  if (CAD_EXT.test(lower)) return "cad";
  if (
    m.includes("model") ||
    m.includes("step") ||
    m.includes("x-t") ||
    /solid|parasolid|sldprt/i.test(m)
  ) {
    return "cad";
  }

  if (/\b(cad|solid|model|parasolid)\b/i.test(n) && !DRAWING_EXT.test(lower)) {
    return "cad";
  }

  if (lower.endsWith(".pdf") || m.includes("pdf")) {
    if (looksLikePoFileName(n)) return "po";
    // PDF with part-like name → drawing
    return "drawing";
  }

  if (DRAWING_EXT.test(lower) || m.startsWith("image/")) return "drawing";
  if (m.startsWith("text/") || lower.endsWith(".txt")) {
    return looksLikePoFileName(n) ? "po" : "unknown";
  }
  return "unknown";
}

/** Score a PDF as PO document from filename + parsed text (higher = more PO-like). */
export function scoreAsPurchaseOrder(
  fileName: string,
  parsed: { lines: unknown[]; looksLikeDrawing?: boolean; poNumber?: string; customer?: string },
): number {
  let s = 0;
  if (looksLikePoFileName(fileName)) s += 50;
  if (parsed.looksLikeDrawing) s -= 80;
  const nLines = parsed.lines?.length || 0;
  s += Math.min(40, nLines * 8);
  if (parsed.poNumber) s += 25;
  if (parsed.customer) s += 10;
  return s;
}

/** Normalize part # for filename matching. */
export function normalizePartKey(pn: string): string {
  return String(pn || "")
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, "");
}

/**
 * Score how well a filename matches a part number (higher = better).
 * Prefers full P/N in name; accepts core without trailing -01 revision-ish suffix.
 */
export function scoreFilePartMatch(fileName: string, partNumber: string): number {
  const fname = String(fileName || "").toUpperCase();
  const base = fname.replace(/\.[^.]+$/, ""); // drop extension
  const pnU = String(partNumber || "").toUpperCase().trim();
  if (!pnU || pnU.length < 3) return 0;

  if (base === pnU || base.startsWith(pnU + "_") || base.startsWith(pnU + "-") || base.startsWith(pnU + " "))
    return 100;
  if (fname.includes(pnU)) return 90;

  const pnKey = normalizePartKey(pnU);
  const fKey = normalizePartKey(base);
  if (pnKey.length >= 4 && fKey.includes(pnKey)) return 80;

  // Core without last -## segment (e.g. FD01-0010-01 → FD01-0010)
  const core = pnU.replace(/-\d{2}$/, "");
  if (core.length >= 4 && core !== pnU) {
    if (fname.includes(core)) return 60;
    const coreKey = normalizePartKey(core);
    if (coreKey.length >= 4 && fKey.includes(coreKey)) return 50;
  }

  // First 8 alnum of part in file
  if (pnKey.length >= 6 && fKey.includes(pnKey.slice(0, 8))) return 30;
  return 0;
}

/**
 * Match files to part numbers (best score wins per part).
 * Each file assigned to at most one part (highest score).
 */
export function matchFilesToParts(
  partNumbers: string[],
  files: { name: string; id?: string; mime?: string }[],
): Record<string, { name: string; id?: string; mime?: string }> {
  const parts = [...new Set(partNumbers.map((p) => p.toUpperCase().trim()).filter(Boolean))];
  type Cand = {
    pn: string;
    file: { name: string; id?: string; mime?: string };
    score: number;
  };
  const cands: Cand[] = [];
  for (const pn of parts) {
    for (const f of files) {
      const score = scoreFilePartMatch(f.name, pn);
      if (score > 0) cands.push({ pn, file: f, score });
    }
  }
  cands.sort((a, b) => b.score - a.score || a.pn.localeCompare(b.pn));

  const out: Record<string, { name: string; id?: string; mime?: string }> = {};
  const usedFile = new Set<string>();
  const usedPart = new Set<string>();
  for (const c of cands) {
    const fkey = c.file.id || c.file.name;
    if (usedFile.has(fkey) || usedPart.has(c.pn)) continue;
    out[c.pn] = c.file;
    usedFile.add(fkey);
    usedPart.add(c.pn);
  }
  return out;
}

/** @deprecated use matchFilesToParts */
export function matchDrawingsToParts(
  partNumbers: string[],
  files: { name: string; id?: string; mime?: string }[],
): Record<string, { name: string; id?: string; mime?: string }> {
  return matchFilesToParts(partNumbers, files);
}

export async function extractTextFromPdf(file: ArrayBuffer): Promise<string> {
  const pdfjs = await import("pdfjs-dist");
  try {
    const worker = await import("pdfjs-dist/build/pdf.worker.min.mjs?url");
    pdfjs.GlobalWorkerOptions.workerSrc = worker.default as string;
  } catch {
    // ignore
  }
  const doc = await pdfjs.getDocument({ data: file }).promise;
  const pageTexts: string[] = [];

  for (let i = 1; i <= doc.numPages; i++) {
    const page = await doc.getPage(i);
    const content = await page.getTextContent();
    // Tighter row bucketing for multi-column tables
    const rows = new Map<number, { x: number; s: string }[]>();
    for (const raw of content.items) {
      const it = raw as { str?: string; transform?: number[]; width?: number };
      if (typeof it.str !== "string" || !it.transform) continue;
      if (!it.str.trim()) continue;
      const x = it.transform[4] ?? 0;
      const y = Math.round((it.transform[5] ?? 0) * 4) / 4; // finer Y
      let key = y;
      for (const k of rows.keys()) {
        if (Math.abs(k - y) < 2.5) {
          key = k;
          break;
        }
      }
      if (!rows.has(key)) rows.set(key, []);
      rows.get(key)!.push({ x, s: it.str });
    }
    const sortedY = [...rows.keys()].sort((a, b) => b - a);
    const outLines: string[] = [];
    for (const y of sortedY) {
      const row = rows.get(y)!;
      row.sort((a, b) => a.x - b.x);
      // Insert space between fragments that are far apart in X
      let line = "";
      let prevRight = -Infinity;
      for (const c of row) {
        if (line && c.x - prevRight > 2) line += " ";
        line += c.s;
        prevRight = c.x + (c.s.length * 4); // rough
      }
      outLines.push(line.replace(/\s+/g, " ").trim());
    }
    // Mark page boundaries so headers don't glue to prior page lines
    pageTexts.push(
      [`--- PDF page ${i} of ${doc.numPages} ---`, ...outLines.filter(Boolean)].join(
        "\n",
      ),
    );
  }

  return pageTexts.join("\n");
}

export async function fileToBase64(file: File): Promise<string> {
  const buf = await file.arrayBuffer();
  let binary = "";
  const bytes = new Uint8Array(buf);
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}
