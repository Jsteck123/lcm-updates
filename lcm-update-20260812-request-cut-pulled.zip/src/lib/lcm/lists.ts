import { MACHINES, type CustomLists } from "./types";
import { MATERIALS, materialTypesFor } from "./materials";

export const DEFAULT_STOCK_SHAPES = [
  "Round Stock",
  "Hex Stock",
  "Square Stock",
  "Rectangular Stock",
  "Rectangle Stock",
  "Flat Bar",
  "Flat Sheet",
  "Plate",
  "Round Tube",
  "Square Tube",
  "Rectangular Tube",
  "Pipe",
  "Angle Stock",
  "Channel",
  "Cast Plate",
] as const;

export const DEFAULT_PAUSE_REASONS = [
  "Shift Change",
  "End of Shift",
  "Machine Transfer",
  "Lunch",
  "Shop Help",
  "Tooling",
  "Waiting on Inspection",
  "Waiting on Material",
  "Machine Issue",
] as const;

export const EMPTY_CUSTOM_LISTS: CustomLists = {
  materials: [],
  materialTypes: {},
  machines: [],
  stockShapes: [],
  pauseReasons: [],
  sizeNotes: [],
};

export function mergeUnique(
  ...groups: (string[] | readonly string[] | undefined)[]
): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const group of groups) {
    if (!group) continue;
    for (const raw of group) {
      const v = String(raw ?? "").trim();
      if (!v) continue;
      const key = v.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(v);
    }
  }
  return out;
}

export function allMaterials(custom?: CustomLists): string[] {
  return mergeUnique(MATERIALS, custom?.materials);
}

export function allMaterialTypes(material: string, custom?: CustomLists): string[] {
  const extras: string[] = [];
  if (custom?.materialTypes) {
    for (const [k, list] of Object.entries(custom.materialTypes)) {
      if (k.toLowerCase() === material.toLowerCase()) {
        extras.push(...list);
      }
    }
  }
  return mergeUnique(materialTypesFor(material), extras);
}

export function allMachines(custom?: CustomLists): string[] {
  return mergeUnique(MACHINES, custom?.machines);
}

export function allStockShapes(custom?: CustomLists): string[] {
  return mergeUnique(DEFAULT_STOCK_SHAPES, custom?.stockShapes);
}

export function allPauseReasons(custom?: CustomLists): string[] {
  return mergeUnique(DEFAULT_PAUSE_REASONS, custom?.pauseReasons);
}

export function normalizeCustomLists(raw?: Partial<CustomLists> | null): CustomLists {
  if (!raw || typeof raw !== "object") {
    return {
      materials: [],
      materialTypes: {},
      machines: [],
      stockShapes: [],
      pauseReasons: [],
      sizeNotes: [],
    };
  }
  return {
    materials: Array.isArray(raw.materials) ? raw.materials.map(String) : [],
    materialTypes:
      raw.materialTypes && typeof raw.materialTypes === "object"
        ? Object.fromEntries(
            Object.entries(raw.materialTypes).map(([k, v]) => [
              k,
              Array.isArray(v) ? v.map(String) : [],
            ]),
          )
        : {},
    machines: Array.isArray(raw.machines) ? raw.machines.map(String) : [],
    stockShapes: Array.isArray(raw.stockShapes) ? raw.stockShapes.map(String) : [],
    pauseReasons: Array.isArray(raw.pauseReasons) ? raw.pauseReasons.map(String) : [],
    sizeNotes: Array.isArray(raw.sizeNotes) ? raw.sizeNotes.map(String) : [],
  };
}
