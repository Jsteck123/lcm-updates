/**
 * Material price book + theoretical weights (EMJ Blue Book method).
 *
 * EMJ Weight Tables (theoretical):
 *   Steel density ........ 0.2836 lb/in³
 *   Aluminum base ........ 0.098  lb/in³ (1100 / 6061)
 *   Al 6061 .............. 0.098
 *   Al 7075 .............. 0.101
 *   Al 2024 .............. 0.101
 *   Al 5052 .............. 0.097
 *
 * Lb/ft formulas (EMJ):
 *   Al round .... 0.924 × D²
 *   Al square ... 1.18  × D²
 *   Al hex ...... 1.02  × D²
 *   Al flat ..... 1.18  × T × W
 *   Al tube ..... 3.70  × (OD − wall) × wall
 *   Steel round . 2.6729 × D²
 *   Steel square  3.4032 × D²
 *   Steel hex ... 2.9473 × D²
 *   Steel flat .. 3.4032 × T × W
 *   Steel tube .. 10.68 × (OD − wall) × wall
 *
 * Alloy densities that differ from the base scale the lb/ft result.
 * Weights are for estimating / quoting everyday common stock — not a
 * substitute for vendor quotes on specials or large buys.
 */

import { profileForShape } from "./stock-shapes";
import { uid } from "@/lib/utils";

export type MetalFamily = "aluminum" | "steel" | "stainless" | "other";

export type MaterialPriceEntry = {
  id: string;
  /** Family for density / formulas: aluminum | steel | stainless | other */
  family: MetalFamily;
  /** Display grade e.g. 6061-T6, 1018, 304 */
  grade: string;
  /** Going rate $/lb (shop updates as market moves) */
  pricePerLb: number;
  /** Optional density override lb/in³ */
  densityLbIn3: number;
  notes: string;
  /** When this rate was last confirmed */
  updatedAt: string;
  active: boolean;
};

/** EMJ base densities (lb/in³) */
export const EMJ_DENSITY = {
  steel: 0.2836,
  aluminumBase: 0.098,
  aluminum6061: 0.098,
  aluminum7075: 0.101,
  aluminum2024: 0.101,
  aluminum5052: 0.097,
  aluminum6063: 0.097,
  stainless: 0.29,
} as const;

/** Starter going rates — edit in Settings as market moves. Not a vendor quote. */
export function defaultMaterialPriceBook(now = new Date().toISOString()): MaterialPriceEntry[] {
  const row = (
    family: MetalFamily,
    grade: string,
    pricePerLb: number,
    densityLbIn3: number,
    notes: string,
  ): MaterialPriceEntry => ({
    id: uid(),
    family,
    grade,
    pricePerLb,
    densityLbIn3,
    notes,
    updatedAt: now,
    active: true,
  });

  return [
    row("aluminum", "6061-T6", 4.25, EMJ_DENSITY.aluminum6061, "Common mill bar / plate · EMJ density 0.098"),
    row("aluminum", "6061-T651 plate", 4.5, EMJ_DENSITY.aluminum6061, "Plate / tooling plate"),
    row("aluminum", "7075-T6", 7.5, EMJ_DENSITY.aluminum7075, "High strength · denser than 6061"),
    row("aluminum", "2024-T3", 6.75, EMJ_DENSITY.aluminum2024, "Aerospace bar / plate"),
    row("aluminum", "5052-H32", 3.85, EMJ_DENSITY.aluminum5052, "Sheet / formable"),
    row("steel", "1018 CRS", 0.95, EMJ_DENSITY.steel, "Cold roll bar · EMJ steel 0.2836"),
    row("steel", "1045", 1.05, EMJ_DENSITY.steel, "Medium carbon"),
    row("steel", "4140", 1.35, EMJ_DENSITY.steel, "Alloy bar"),
    row("steel", "A36 plate", 0.85, EMJ_DENSITY.steel, "Structural plate"),
    row("stainless", "304", 2.85, EMJ_DENSITY.stainless, "General SS bar / plate"),
    row("stainless", "316", 3.4, EMJ_DENSITY.stainless, "Marine / corrosion"),
  ];
}

export function normalizeMaterialPriceBook(
  list: MaterialPriceEntry[] | undefined | null,
): MaterialPriceEntry[] {
  if (!Array.isArray(list) || list.length === 0) {
    return defaultMaterialPriceBook();
  }
  return list.map((r) => ({
    id: r.id || uid(),
    family: (["aluminum", "steel", "stainless", "other"].includes(r.family)
      ? r.family
      : "other") as MetalFamily,
    grade: String(r.grade || "").trim() || "Unknown",
    pricePerLb: Number(r.pricePerLb) || 0,
    densityLbIn3: Number(r.densityLbIn3) > 0 ? Number(r.densityLbIn3) : densityForFamily(r.family as MetalFamily),
    notes: String(r.notes || ""),
    updatedAt: r.updatedAt || new Date().toISOString(),
    active: r.active !== false,
  }));
}

export function densityForFamily(family: MetalFamily): number {
  if (family === "aluminum") return EMJ_DENSITY.aluminumBase;
  if (family === "stainless") return EMJ_DENSITY.stainless;
  if (family === "steel") return EMJ_DENSITY.steel;
  return EMJ_DENSITY.steel;
}

/**
 * EMJ theoretical lb per lineal foot for a solid / tube section.
 * Scales Al or Steel base formula by alloy density vs base.
 */
export function emjLbPerFoot(opts: {
  family: MetalFamily;
  densityLbIn3: number;
  shapeId: string;
  /** diameter, AF, thickness, OD — inches */
  dimX: number;
  dimY: number;
  dimZ: number;
}): { lbPerFoot: number; formula: string; ok: boolean; error?: string } {
  const { family, densityLbIn3, shapeId } = opts;
  const x = Number(opts.dimX) || 0;
  const y = Number(opts.dimY) || 0;
  const z = Number(opts.dimZ) || 0;

  const isAl = family === "aluminum";
  const isSs = family === "stainless";
  // Stainless uses steel-style formulas scaled by density
  const useSteelForm = !isAl;
  const baseDensity = isAl ? EMJ_DENSITY.aluminumBase : EMJ_DENSITY.steel;
  const scale = densityLbIn3 > 0 ? densityLbIn3 / baseDensity : 1;

  let base = 0;
  let formula = "";

  switch (shapeId) {
    case "round": {
      if (x <= 0) return fail("Need diameter (OD)");
      base = useSteelForm ? 2.6729 * x * x : 0.924 * x * x;
      formula = useSteelForm
        ? `2.6729 × ${x}² (steel EMJ) × density scale`
        : `0.924 × ${x}² (Al EMJ) × density scale`;
      break;
    }
    case "hex": {
      if (x <= 0) return fail("Need across-flats");
      base = useSteelForm ? 2.9473 * x * x : 1.02 * x * x;
      formula = useSteelForm
        ? `2.9473 × AF² (steel EMJ)`
        : `1.02 × AF² (Al EMJ)`;
      break;
    }
    case "square": {
      // if height missing, treat as square on width
      const w = x;
      const h = y > 0 ? y : x;
      if (w <= 0) return fail("Need width");
      if (Math.abs(w - h) < 1e-6) {
        base = useSteelForm ? 3.4032 * w * w : 1.18 * w * w;
        formula = useSteelForm
          ? `3.4032 × ${w}² (steel square EMJ)`
          : `1.18 × ${w}² (Al square EMJ)`;
      } else {
        // rectangular solid as flat
        base = useSteelForm ? 3.4032 * w * h : 1.18 * w * h;
        formula = useSteelForm
          ? `3.4032 × T × W (steel flat EMJ)`
          : `1.18 × T × W (Al flat EMJ)`;
      }
      break;
    }
    case "flat-bar":
    case "rectangular": {
      const t = x;
      const w = y;
      if (t <= 0 || w <= 0) return fail("Need thickness × width");
      base = useSteelForm ? 3.4032 * t * w : 1.18 * t * w;
      formula = useSteelForm
        ? `3.4032 × ${t} × ${w} (steel flat EMJ)`
        : `1.18 × ${t} × ${w} (Al flat EMJ)`;
      break;
    }
    case "round-tube": {
      const od = x;
      const wall = y > 0 ? y : z > 0 && od > z ? (od - z) / 2 : 0;
      if (od <= 0 || wall <= 0) return fail("Need OD and wall (or OD + ID)");
      base = useSteelForm
        ? 10.68 * (od - wall) * wall
        : 3.7 * (od - wall) * wall;
      formula = useSteelForm
        ? `10.68 × (OD−wall)×wall (steel EMJ)`
        : `3.70 × (OD−wall)×wall (Al EMJ)`;
      break;
    }
    case "square-tube": {
      // approx as round-tube using avg OD and wall
      const od = Math.max(x, y) || x;
      const wall = z;
      if (od <= 0 || wall <= 0) return fail("Need outside size and wall");
      base = useSteelForm
        ? 10.68 * (od - wall) * wall * 1.27
        : 3.7 * (od - wall) * wall * 1.27;
      formula = "Tube approx (EMJ round tube × 1.27 for square)";
      break;
    }
    case "plate":
    case "sheet": {
      // Shop shape profile: dimZ = thickness, dimX = width (blank/sheet)
      // Return lb per lineal foot of a strip of that width (for stock length in inches)
      const thk = z > 0 ? z : x; // thickness
      const w = z > 0 ? x : y > 0 ? y : 12;
      if (thk <= 0) return fail("Need plate/sheet thickness");
      // lb/ft = thk × width × 12 × density
      base = thk * (w > 0 ? w : 12) * 12 * densityLbIn3;
      formula = `${thk}" thk × ${w || 12}" wide × 12 × ${densityLbIn3} lb/in³ (EMJ density)`;
      return {
        lbPerFoot: +base.toFixed(4),
        formula,
        ok: true,
      };
    }
    case "angle": {
      // approximate: (legA + legB - thk) * thk as unfolded flat
      const a = x;
      const b = y > 0 ? y : x;
      const thk = z > 0 ? z : 0.125;
      if (a <= 0) return fail("Need angle legs / thickness");
      const equiv = (a + b - thk) * thk;
      base = useSteelForm ? 3.4032 * equiv : 1.18 * equiv;
      formula = "Angle approx as unfolded flat (EMJ flat)";
      break;
    }
    default: {
      // generic volume: if we have section dims treat as flat/rect
      if (x > 0 && y > 0) {
        base = useSteelForm ? 3.4032 * x * y : 1.18 * x * y;
        formula = "Generic T×W EMJ flat";
      } else if (x > 0) {
        base = useSteelForm ? 2.6729 * x * x : 0.924 * x * x;
        formula = "Generic round EMJ";
      } else {
        return fail("Set stock shape and section sizes");
      }
    }
  }

  // stainless density scale from steel formulas
  const scaled = base * (isSs || isAl || useSteelForm ? scale : scale);
  return {
    lbPerFoot: +scaled.toFixed(4),
    formula: `${formula}${Math.abs(scale - 1) > 0.01 ? ` · scale ${scale.toFixed(3)}` : ""}`,
    ok: true,
  };
}

function fail(error: string) {
  return { lbPerFoot: 0, formula: "", ok: false as const, error };
}

export type MaterialEstimate = {
  ok: boolean;
  error?: string;
  lbPerFoot: number;
  lengthIn: number;
  lengthFt: number;
  totalLb: number;
  pricePerLb: number;
  /** Full stock stick / plate cost → maps to quote rawMaterialCost */
  stockCost: number;
  /** Cost of cut length only (before material %) */
  cutCost: number;
  grade: string;
  family: MetalFamily;
  formula: string;
  densityLbIn3: number;
  shapeId: string;
};

export function matchPriceEntry(
  book: MaterialPriceEntry[],
  material: string,
  materialType: string,
): MaterialPriceEntry | undefined {
  const active = (book || []).filter((r) => r.active);
  if (!active.length) return undefined;
  const blob = `${material || ""} ${materialType || ""}`.toLowerCase();

  // Exact-ish grade in type or material string
  const scored = active
    .map((r) => {
      const g = r.grade.toLowerCase();
      const gCore = g.replace(/[^a-z0-9]/g, "");
      let score = 0;
      if (blob.includes(g.toLowerCase())) score += 10;
      if (gCore && blob.replace(/[^a-z0-9]/g, "").includes(gCore)) score += 8;
      // 6061 match
      const m = g.match(/(\d{4})/);
      if (m && blob.includes(m[1]!)) score += 5;
      if (r.family === "aluminum" && blob.includes("alum")) score += 1;
      if (r.family === "steel" && (blob.includes("steel") || blob.includes("crs")))
        score += 1;
      if (r.family === "stainless" && (blob.includes("stainless") || blob.includes("ss ")))
        score += 1;
      return { r, score };
    })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score);

  return scored[0]?.r;
}

/**
 * Estimate stock $ from shape dims + price book (EMJ weights × $/lb).
 */
export function estimateMaterialFromBook(opts: {
  book: MaterialPriceEntry[];
  material: string;
  materialType: string;
  stockShape: string;
  dimX: number;
  dimY: number;
  dimZ: number;
  rawMaterialLength: number;
  partLengthEach: number;
  /** Force a specific book row */
  entryId?: string;
}): MaterialEstimate {
  const book = opts.book || [];
  const entry =
    (opts.entryId && book.find((r) => r.id === opts.entryId)) ||
    matchPriceEntry(book, opts.material, opts.materialType);

  if (!entry) {
    return {
      ok: false,
      error: "No matching grade in Settings → Material prices. Add 6061, 1018, etc.",
      lbPerFoot: 0,
      lengthIn: 0,
      lengthFt: 0,
      totalLb: 0,
      pricePerLb: 0,
      stockCost: 0,
      cutCost: 0,
      grade: "",
      family: "other",
      formula: "",
      densityLbIn3: 0,
      shapeId: "",
    };
  }

  const profile = profileForShape(opts.stockShape || "");
  const shapeId = profile.id;
  const lengthIn = Number(opts.rawMaterialLength) || 0;
  const cutIn = Number(opts.partLengthEach) || 0;

  if (lengthIn <= 0) {
    return {
      ok: false,
      error: "Set stock / bar length (inches) — e.g. 144 for 12 ft",
      lbPerFoot: 0,
      lengthIn: 0,
      lengthFt: 0,
      totalLb: 0,
      pricePerLb: entry.pricePerLb,
      stockCost: 0,
      cutCost: 0,
      grade: entry.grade,
      family: entry.family,
      formula: "",
      densityLbIn3: entry.densityLbIn3,
      shapeId,
    };
  }

  const w = emjLbPerFoot({
    family: entry.family,
    densityLbIn3: entry.densityLbIn3,
    shapeId,
    dimX: opts.dimX,
    dimY: opts.dimY,
    dimZ: opts.dimZ,
  });

  if (!w.ok) {
    return {
      ok: false,
      error: w.error || "Could not compute weight",
      lbPerFoot: 0,
      lengthIn,
      lengthFt: lengthIn / 12,
      totalLb: 0,
      pricePerLb: entry.pricePerLb,
      stockCost: 0,
      cutCost: 0,
      grade: entry.grade,
      family: entry.family,
      formula: "",
      densityLbIn3: entry.densityLbIn3,
      shapeId,
    };
  }

  const lengthFt = lengthIn / 12;
  const totalLb = w.lbPerFoot * lengthFt;
  const stockCost = totalLb * (entry.pricePerLb || 0);
  const cutFt = cutIn > 0 ? cutIn / 12 : 0;
  const cutCost = cutFt > 0 ? w.lbPerFoot * cutFt * entry.pricePerLb : 0;

  return {
    ok: true,
    lbPerFoot: w.lbPerFoot,
    lengthIn,
    lengthFt,
    totalLb: +totalLb.toFixed(3),
    pricePerLb: entry.pricePerLb,
    stockCost: +stockCost.toFixed(2),
    cutCost: +cutCost.toFixed(2),
    grade: entry.grade,
    family: entry.family,
    formula: w.formula,
    densityLbIn3: entry.densityLbIn3,
    shapeId,
  };
}

/** Compare inventory costPerUnit (if unit is lbs or bar) to book $/lb — rough signal */
export function bookVsStockHint(
  entry: MaterialPriceEntry | undefined,
  costPerUnit: number,
  unit: string,
): string {
  if (!entry || !(costPerUnit > 0)) return "";
  const u = (unit || "").toLowerCase();
  if (u === "lbs" || u === "lb") {
    const delta = costPerUnit - entry.pricePerLb;
    const pct = entry.pricePerLb > 0 ? (delta / entry.pricePerLb) * 100 : 0;
    if (Math.abs(pct) < 5) return "Near book $/lb";
    if (pct > 0) return `${pct.toFixed(0)}% over book $/lb`;
    return `${Math.abs(pct).toFixed(0)}% under book $/lb`;
  }
  return "";
}

/**
 * Pull rough section dims + bar length from a free-form size note
 * e.g. 0.75" dia × 12 ft · 1/2 x 1 x 144" · Ø1.5 x 144
 */
export function parseSizeNoteForEmj(sizeNote: string): {
  dimX: number;
  dimY: number;
  dimZ: number;
  lengthIn: number;
} {
  const s = String(sizeNote || "");
  let lengthIn = 0;
  const ft = s.match(/(\d+(?:\.\d+)?)\s*(?:'|ft|feet)\b/i);
  if (ft) lengthIn = Number(ft[1]) * 12;
  if (!lengthIn) {
    const inchLen = s.match(
      /(?:x|×)\s*(\d+(?:\.\d+)?)\s*(?:"|in|inch)?\s*$/i,
    );
    if (inchLen && Number(inchLen[1]) >= 24) lengthIn = Number(inchLen[1]);
  }
  if (!lengthIn) {
    const bare = s.match(/\b(\d{2,4}(?:\.\d+)?)\s*(?:"|in)?\b/);
    if (bare && Number(bare[1]) >= 36) lengthIn = Number(bare[1]);
  }

  // fractions 1/2, 3/4
  const frac = (raw: string) => {
    const m = raw.match(/^(\d+)\s*\/\s*(\d+)$/);
    if (m) return Number(m[1]) / Number(m[2]);
    return Number(raw) || 0;
  };

  const nums = [
    ...s.matchAll(/(\d+\s*\/\s*\d+|\d+(?:\.\d+)?)/g),
  ].map((m) => frac(m[1]!.replace(/\s/g, "")));

  // Prefer first small number as section (dia/thk), second as width if present
  const section = nums.filter((n) => n > 0 && n < 24);
  const dimX = section[0] || 0;
  const dimY = section[1] && section[1] < 24 ? section[1] : 0;
  const dimZ = section[2] && section[2] < 12 ? section[2] : 0;

  return { dimX, dimY, dimZ, lengthIn };
}

/**
 * Map EMJ stock estimate into inventory costPerUnit for the chosen unit.
 * in/inch → $/inch · ft → $/ft · lb → $/lb · pcs/ea → $ per full bar
 */
export function emjCostPerUnitFromEstimate(
  est: MaterialEstimate,
  unit: string,
): { costPerUnit: number; label: string } {
  const u = (unit || "").toLowerCase().trim();
  if (u === "lb" || u === "lbs" || u === "pound" || u === "pounds") {
    return {
      costPerUnit: +est.pricePerLb.toFixed(4),
      label: `$${est.pricePerLb.toFixed(2)}/lb (book)`,
    };
  }
  const perFt = est.lbPerFoot * est.pricePerLb;
  if (u === "ft" || u === "feet" || u === "foot") {
    return {
      costPerUnit: +perFt.toFixed(4),
      label: `$${perFt.toFixed(2)}/ft (${est.lbPerFoot.toFixed(3)} lb/ft × book)`,
    };
  }
  if (
    u === "in" ||
    u === "inch" ||
    u === "inches" ||
    u === '"' ||
    u === "in."
  ) {
    const perIn = perFt / 12;
    return {
      costPerUnit: +perIn.toFixed(6),
      label: `$${perIn.toFixed(4)}/in (${est.lbPerFoot.toFixed(3)} lb/ft × book ÷ 12)`,
    };
  }
  // pcs / ea / bar / stick / each
  return {
    costPerUnit: +est.stockCost.toFixed(2),
    label: `$${est.stockCost.toFixed(2)} per piece (${est.totalLb} lb bar)`,
  };
}
