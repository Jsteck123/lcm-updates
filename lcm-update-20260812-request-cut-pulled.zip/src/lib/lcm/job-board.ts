/**
 * Digital job board — component pieces first, then assembly, or simple lines.
 * Sorted soonest due → furthest (wall board: top-left next).
 */
import type { ShopOrder, ShopOrderLine, ShopLineComponent } from "./types";
import {
  allComponentsComplete,
  lineCadFiles,
  lineDrawings,
  lineHasCad,
  normalizeComponents,
  promoteRelatedFilesToComponents,
} from "./line-files";
import { lineShipDate } from "./shipping-calendar";

export type BoardCard = {
  orderId: string;
  lineId: string;
  /** Empty = the main PO line / assembly step */
  componentId: string;
  poNumber: string;
  customer: string;
  partNumber: string;
  revision: string;
  description: string;
  qty: number;
  dueDate: string;
  material: string;
  materialType: string;
  sizeNote: string;
  drawingId: string;
  cadFileId: string;
  drawings: { id: string; name: string; relatedPartNumber?: string }[];
  cadFiles: { id: string; name: string; relatedPartNumber?: string }[];
  revPdfOk: boolean;
  revCadOk: boolean;
  stockNoted: boolean;
  checkedOutBy: string;
  checkedOutAt: string;
  checkedOutMachine: string;
  readyForPack: boolean;
  linePacked: boolean;
  released: boolean;
  /** component | assembly | part */
  kind: "component" | "assembly" | "part";
  /** Parent assembly P/N when kind is component */
  parentPartNumber: string;
  /** For assembly cards: which components still open */
  waitingOn: string[];
};

export function lineReleasedToShop(line: ShopOrderLine): boolean {
  if (!line.revPdfOk || !line.stockNoted) return false;
  if (lineHasCad(line) && !line.revCadOk) return false;
  // Components with CAD: require parent CAD rev ok once any CAD exists on components
  const comps = normalizeComponents(line);
  const anyCad = comps.some((c) => (c.cadFiles || []).length > 0);
  if (anyCad && !line.revCadOk) return false;
  return true;
}

function mapFiles(
  list: { id: string; name: string; relatedPartNumber?: string }[],
) {
  return (list || []).map((f) => ({
    id: f.id,
    name: f.name,
    relatedPartNumber: f.relatedPartNumber,
  }));
}

export function buildJobBoard(orders: ShopOrder[]): BoardCard[] {
  const cards: BoardCard[] = [];
  for (const order of orders) {
    if (order.status === "cancelled") continue;
    if (order.deliveredAt) continue;
    for (const raw of order.lines || []) {
      if (raw.lineStatus === "cancelled") continue;
      if (raw.readyForPack || raw.linePacked) continue;
      if (!(raw.partNumber || raw.description)) continue;

      // Ensure related files are components for board display
      const promoted = promoteRelatedFilesToComponents(raw);
      const line: ShopOrderLine = {
        ...raw,
        ...promoted,
        components: normalizeComponents({ ...raw, ...promoted }),
      } as ShopOrderLine;

      const due =
        lineShipDate(order, line) || order.dateRequired || "9999-12-31";
      const released = lineReleasedToShop(line);
      const comps = normalizeComponents(line);
      const base = {
        orderId: order.id,
        lineId: line.id,
        poNumber: order.poNumber || "(no PO)",
        customer: order.customer || "",
        dueDate: due,
        material: line.material || "",
        materialType: line.materialType || "",
        sizeNote: line.sizeNote || "",
        revPdfOk: Boolean(line.revPdfOk),
        revCadOk: Boolean(line.revCadOk),
        stockNoted: Boolean(line.stockNoted),
        readyForPack: Boolean(line.readyForPack),
        linePacked: Boolean(line.linePacked),
      };

      if (comps.length > 0) {
        // Component jobs (machine -02, -03, …)
        for (const c of comps) {
          if (c.complete) continue;
          const draws = mapFiles(c.drawings || []);
          const cads = mapFiles(c.cadFiles || []);
          cards.push({
            ...base,
            componentId: c.id,
            partNumber: c.partNumber,
            revision: c.revision || line.revision || "",
            description:
              c.description ||
              `Make component for assembly ${line.partNumber}`,
            qty: Number(c.qty) || Number(line.qty) || 0,
            drawingId: draws[0]?.id || "",
            cadFileId: cads[0]?.id || "",
            drawings: draws,
            cadFiles: cads,
            checkedOutBy: c.checkedOutBy || "",
            checkedOutAt: c.checkedOutAt || "",
            checkedOutMachine: c.checkedOutMachine || "",
            released,
            kind: "component",
            parentPartNumber: line.partNumber || "",
            waitingOn: [],
          });
        }

        // Assembly job — only after all components complete
        const waiting = comps.filter((c) => !c.complete).map((c) => c.partNumber);
        const draws = mapFiles(lineDrawings(line));
        const cads = mapFiles(lineCadFiles(line));
        cards.push({
          ...base,
          componentId: "",
          partNumber: line.partNumber || "",
          revision: line.revision || "",
          description:
            (line.description || "Assembly") +
            (waiting.length
              ? ` · wait for ${waiting.join(", ")}`
              : " · bolt / assemble"),
          qty: Number(line.qty) || 0,
          drawingId: draws[0]?.id || "",
          cadFileId: cads[0]?.id || "",
          drawings: draws,
          cadFiles: cads,
          checkedOutBy: line.checkedOutBy || "",
          checkedOutAt: line.checkedOutAt || "",
          checkedOutMachine: line.checkedOutMachine || "",
          // Assembly not pullable until components done
          released: released && waiting.length === 0,
          kind: "assembly",
          parentPartNumber: "",
          waitingOn: waiting,
        });
      } else {
        // Simple one-piece line
        const draws = mapFiles(lineDrawings(line));
        const cads = mapFiles(lineCadFiles(line));
        cards.push({
          ...base,
          componentId: "",
          partNumber: line.partNumber || "",
          revision: line.revision || "",
          description: line.description || "",
          qty: Number(line.qty) || 0,
          drawingId: draws[0]?.id || line.drawingId || "",
          cadFileId: cads[0]?.id || line.cadFileId || "",
          drawings: draws,
          cadFiles: cads,
          checkedOutBy: line.checkedOutBy || "",
          checkedOutAt: line.checkedOutAt || "",
          checkedOutMachine: line.checkedOutMachine || "",
          released,
          kind: "part",
          parentPartNumber: "",
          waitingOn: [],
        });
      }
    }
  }
  return cards.sort((a, b) => {
    const d = a.dueDate.localeCompare(b.dueDate);
    if (d) return d;
    // Components before assembly for same PO/line
    if (a.orderId === b.orderId && a.lineId === b.lineId) {
      if (a.kind === "component" && b.kind === "assembly") return -1;
      if (a.kind === "assembly" && b.kind === "component") return 1;
    }
    return (
      a.poNumber.localeCompare(b.poNumber) ||
      a.partNumber.localeCompare(b.partNumber)
    );
  });
}

export function fridayOfWeek(from = new Date()): string {
  const d = new Date(from);
  const day = d.getDay();
  const add = day <= 5 ? 5 - day : 6;
  d.setDate(d.getDate() + add);
  return d.toISOString().slice(0, 10);
}

/** Sunday–Saturday week containing `from` (local dates as YYYY-MM-DD). */
export function weekRangeContaining(from = new Date()): {
  start: string;
  end: string;
} {
  const d = new Date(from);
  d.setHours(12, 0, 0, 0);
  const day = d.getDay(); // 0 Sun
  const start = new Date(d);
  start.setDate(d.getDate() - day);
  const end = new Date(start);
  end.setDate(start.getDate() + 6);
  const ymd = (x: Date) => {
    const y = x.getFullYear();
    const m = String(x.getMonth() + 1).padStart(2, "0");
    const dd = String(x.getDate()).padStart(2, "0");
    return `${y}-${m}-${dd}`;
  };
  return { start: ymd(start), end: ymd(end) };
}
