/**
 * PIN / password hashing — browser + Node.
 * Format: v1$<saltHex>$<hashHex>  (PBKDF2-SHA-256, 120k iterations)
 */
const ITERATIONS = 120_000;
const KEY_LEN = 32;
const SALT_LEN = 16;
const PREFIX = "v1";

function bytesToHex(bytes: Uint8Array): string {
  let out = "";
  for (let i = 0; i < bytes.length; i++) {
    out += bytes[i]!.toString(16).padStart(2, "0");
  }
  return out;
}

function hexToBytes(hex: string): Uint8Array {
  const clean = hex.trim().toLowerCase();
  const out = new Uint8Array(Math.floor(clean.length / 2));
  for (let i = 0; i < out.length; i++) {
    out[i] = parseInt(clean.slice(i * 2, i * 2 + 2), 16);
  }
  return out;
}

function randomSalt(): Uint8Array {
  const salt = new Uint8Array(SALT_LEN);
  if (typeof globalThis.crypto?.getRandomValues !== "function") {
    throw new Error("Web Crypto getRandomValues is required for hashing");
  }
  globalThis.crypto.getRandomValues(salt);
  return salt;
}

async function pbkdf2(secret: string, salt: Uint8Array): Promise<Uint8Array> {
  const enc = new TextEncoder();
  if (typeof globalThis.crypto?.subtle?.importKey === "function") {
    const key = await globalThis.crypto.subtle.importKey(
      "raw",
      enc.encode(secret),
      "PBKDF2",
      false,
      ["deriveBits"],
    );
    const saltBuf = salt.buffer.slice(
      salt.byteOffset,
      salt.byteOffset + salt.byteLength,
    ) as ArrayBuffer;
    const bits = await globalThis.crypto.subtle.deriveBits(
      {
        name: "PBKDF2",
        salt: saltBuf,
        iterations: ITERATIONS,
        hash: "SHA-256",
      },
      key,
      KEY_LEN * 8,
    );
    return new Uint8Array(bits);
  }
  const nodeCrypto = await import("node:crypto");
  return new Promise((resolve, reject) => {
    nodeCrypto.pbkdf2(
      secret,
      Buffer.from(salt),
      ITERATIONS,
      KEY_LEN,
      "sha256",
      (err, derived) => {
        if (err) reject(err);
        else resolve(new Uint8Array(derived));
      },
    );
  });
}

/** True if value already looks like our hash format (not a raw PIN). */
export function isHashedSecret(value: string | undefined | null): boolean {
  if (!value) return false;
  const parts = value.split("$");
  return parts.length === 3 && parts[0] === PREFIX && (parts[1]?.length ?? 0) >= 16;
}

export async function hashSecret(plain: string): Promise<string> {
  const trimmed = plain.trim();
  if (!trimmed) return "";
  if (isHashedSecret(trimmed)) return trimmed;
  const salt = randomSalt();
  const hash = await pbkdf2(trimmed, salt);
  return `${PREFIX}$${bytesToHex(salt)}$${bytesToHex(hash)}`;
}

export async function verifySecret(
  plain: string,
  stored: string | undefined | null,
): Promise<boolean> {
  const p = plain.trim();
  const s = (stored || "").trim();
  if (!s) return p === "";
  if (!isHashedSecret(s)) {
    // Legacy plaintext (pre-migration)
    return s === p;
  }
  if (!p) return false;
  const [, saltHex, hashHex] = s.split("$");
  if (!saltHex || !hashHex) return false;
  const derived = await pbkdf2(p, hexToBytes(saltHex));
  const expected = hexToBytes(hashHex);
  if (derived.length !== expected.length) return false;
  let diff = 0;
  for (let i = 0; i < derived.length; i++) diff |= derived[i]! ^ expected[i]!;
  return diff === 0;
}
