import QRCode from "qrcode";

/** Build QR data URL for a barcode string (used on 0.5"×1" stickers). */
export async function barcodeToDataUrl(
  text: string,
  size = 96,
): Promise<string> {
  return QRCode.toDataURL(text, {
    errorCorrectionLevel: "M",
    margin: 0,
    width: size,
    color: { dark: "#000000", light: "#ffffff" },
  });
}

/** Absolute scan URL when we know the host (for stickers that open the app). */
export function scanUrlForBarcode(barcode: string, origin?: string): string {
  const base =
    origin ||
    (typeof window !== "undefined" ? window.location.origin : "");
  const path = `/scan?c=${encodeURIComponent(barcode)}`;
  return base ? `${base}${path}` : path;
}
