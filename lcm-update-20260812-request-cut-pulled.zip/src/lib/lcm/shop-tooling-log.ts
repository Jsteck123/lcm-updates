import type {
  QuoteToolingKind,
  ShopToolingLog,
  ShopToolingLogStatus,
} from "./types";
import { emptyToolingCharge, TOOLING_KIND_LABEL } from "./quote-tooling";
import { uid } from "@/lib/utils";

/** Same $2/min rate as setup cost — rough shop cost for jaws/tool time. */
export const TOOLING_SHOP_RATE_PER_MIN = 2;

export function emptyShopToolingLog(
  partial?: Partial<ShopToolingLog> & { kind?: QuoteToolingKind },
): ShopToolingLog {
  const kind = partial?.kind || "soft_jaws";
  const now = new Date().toISOString();
  return {
    id: partial?.id || uid(),
    createdAt: partial?.createdAt || now,
    updatedAt: partial?.updatedAt || now,
    machine: partial?.machine || "",
    operator: partial?.operator || "",
    jobId: partial?.jobId ?? null,
    partNumber: (partial?.partNumber || "").toUpperCase(),
    revision: (partial?.revision || "").toUpperCase(),
    customer: partial?.customer || "",
    kind,
    description:
      (partial?.description || "").trim() || TOOLING_KIND_LABEL[kind],
    minutes: Math.max(0, Number(partial?.minutes) || 0),
    timerStartedAt: partial?.timerStartedAt ?? null,
    notes: partial?.notes || "",
    billRequest: Boolean(partial?.billRequest),
    suggestedBillAmount: Number(partial?.suggestedBillAmount) || 0,
    status: (partial?.status as ShopToolingLogStatus) || "open",
    quoteId: partial?.quoteId,
    toolingChargeId: partial?.toolingChargeId,
  };
}

export function normalizeShopToolingLogs(raw: unknown): ShopToolingLog[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((x) => x && typeof x === "object")
    .map((x) => emptyShopToolingLog(x as Partial<ShopToolingLog>));
}

export function liveToolingMinutes(log: ShopToolingLog, nowMs = Date.now()): number {
  let m = Number(log.minutes) || 0;
  if (log.timerStartedAt) {
    const start = new Date(log.timerStartedAt).getTime();
    if (Number.isFinite(start) && start > 0) {
      m += Math.max(0, (nowMs - start) / 60000);
    }
  }
  return Math.round(m * 10) / 10;
}

export function shopCostFromToolingMinutes(minutes: number): number {
  return Math.round(minutes * TOOLING_SHOP_RATE_PER_MIN * 100) / 100;
}

export function openToolingLogsForPart(
  logs: ShopToolingLog[] | undefined,
  partNumber: string,
  revision?: string,
): ShopToolingLog[] {
  const pn = (partNumber || "").trim().toUpperCase();
  if (!pn) return [];
  const rev = (revision || "").trim().toUpperCase();
  return (logs || [])
    .filter((l) => {
      if (l.status !== "open") return false;
      if ((l.partNumber || "").toUpperCase() !== pn) return false;
      if (
        rev &&
        (l.revision || "").toUpperCase() &&
        (l.revision || "").toUpperCase() !== rev
      ) {
        return false;
      }
      return true;
    })
    .sort(
      (a, b) =>
        new Date(b.updatedAt || b.createdAt).getTime() -
        new Date(a.updatedAt || a.createdAt).getTime(),
    );
}

export type ToolingChargeFromLogOpts = {
  /** Override floor minutes (office can adjust before customer quote). */
  minutes?: number;
  /** Customer bill unit price override. */
  billUnitPrice?: number;
  /** Shop cost override (defaults from minutes × rate or bill amount). */
  shopCost?: number;
  billCustomer?: boolean;
  description?: string;
};

/** Build a quote tooling charge from a floor log (does not mutate quote). */
export function toolingChargeFromShopLog(
  log: ShopToolingLog,
  opts?: ToolingChargeFromLogOpts,
) {
  const minutes =
    opts?.minutes != null && Number.isFinite(opts.minutes)
      ? Math.max(0, Number(opts.minutes))
      : liveToolingMinutes(log);
  const fromTime = shopCostFromToolingMinutes(minutes);
  const billCustomer =
    opts?.billCustomer != null ? opts.billCustomer : Boolean(log.billRequest);
  const suggested = Number(log.suggestedBillAmount) || 0;
  const shopCost =
    opts?.shopCost != null && Number.isFinite(opts.shopCost)
      ? Math.max(0, Number(opts.shopCost))
      : fromTime > 0
        ? fromTime
        : suggested;
  const billUnit =
    opts?.billUnitPrice != null && Number.isFinite(opts.billUnitPrice)
      ? Math.max(0, Number(opts.billUnitPrice))
      : suggested > 0
        ? suggested
        : shopCost;
  const description =
    (opts?.description || log.description || "").trim() ||
    TOOLING_KIND_LABEL[log.kind];
  return emptyToolingCharge({
    kind: log.kind === "soft_jaws" ? "soft_jaws" : log.kind === "other" ? "other" : "special_tool",
    description,
    shopCost,
    billCustomer,
    billQty: 1,
    billUnitPrice: billCustomer ? billUnit : 0,
    notes: [
      log.notes?.trim(),
      minutes > 0 ? `Floor time: ${minutes} min` : "",
      log.operator ? `Op: ${log.operator}` : "",
      log.machine ? `Machine: ${log.machine}` : "",
    ]
      .filter(Boolean)
      .join(" · "),
  });
}
