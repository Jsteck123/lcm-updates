/**
 * Shop session tokens for LAN multi-user API protection.
 * HMAC-signed payload stored in an httpOnly-friendly string the client
 * attaches as `x-lcm-shop-token` (and we also accept cookie).
 */
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

const DATA_DIR = path.join(process.cwd(), "data");
const SECRET_FILE = path.join(DATA_DIR, ".shop-secret");
const TOKEN_TTL_MS = 12 * 60 * 60 * 1000; // 12h shop shift

type TokenPayload = {
  email: string;
  role: "admin" | "operator";
  name: string;
  exp: number;
  iat: number;
};

function ensureSecret(): string {
  if (process.env.LCM_SHOP_SECRET?.trim()) {
    return process.env.LCM_SHOP_SECRET.trim();
  }
  try {
    if (fs.existsSync(SECRET_FILE)) {
      const s = fs.readFileSync(SECRET_FILE, "utf8").trim();
      if (s.length >= 32) return s;
    }
  } catch {
    /* fall through */
  }
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  const secret = crypto.randomBytes(32).toString("hex");
  try {
    fs.writeFileSync(SECRET_FILE, secret, { mode: 0o600 });
  } catch {
    /* in-memory only for this process */
  }
  return secret;
}

function b64url(buf: Buffer | string): string {
  const b = typeof buf === "string" ? Buffer.from(buf, "utf8") : buf;
  return b
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function fromB64url(s: string): Buffer {
  const pad = s.length % 4 === 0 ? "" : "=".repeat(4 - (s.length % 4));
  const b64 = s.replace(/-/g, "+").replace(/_/g, "/") + pad;
  return Buffer.from(b64, "base64");
}

export function issueShopToken(opts: {
  email: string;
  role: "admin" | "operator";
  name: string;
}): string {
  const secret = ensureSecret();
  const now = Date.now();
  const payload: TokenPayload = {
    email: opts.email.trim().toLowerCase(),
    role: opts.role,
    name: opts.name,
    iat: now,
    exp: now + TOKEN_TTL_MS,
  };
  const body = b64url(JSON.stringify(payload));
  const sig = b64url(
    crypto.createHmac("sha256", secret).update(body).digest(),
  );
  return `${body}.${sig}`;
}

export function verifyShopToken(
  token: string | null | undefined,
): TokenPayload | null {
  if (!token || typeof token !== "string") return null;
  const parts = token.trim().split(".");
  if (parts.length !== 2) return null;
  const [body, sig] = parts;
  if (!body || !sig) return null;
  const secret = ensureSecret();
  const expected = b64url(
    crypto.createHmac("sha256", secret).update(body).digest(),
  );
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(fromB64url(body).toString("utf8")) as TokenPayload;
    if (!payload.email || !payload.exp || payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

export function readTokenFromHeaders(
  headers: Headers | Record<string, string | string[] | undefined>,
): string | null {
  if (headers instanceof Headers) {
    const h = headers.get("x-lcm-shop-token");
    if (h) return h.trim();
    const cookie = headers.get("cookie") || "";
    const m = cookie.match(/(?:^|;\s*)lcm_shop_token=([^;]+)/);
    return m?.[1] ? decodeURIComponent(m[1]) : null;
  }
  const raw = headers["x-lcm-shop-token"] ?? headers["X-Lcm-Shop-Token"];
  if (typeof raw === "string" && raw.trim()) return raw.trim();
  if (Array.isArray(raw) && raw[0]) return raw[0].trim();
  const cookie = headers.cookie;
  const c = Array.isArray(cookie) ? cookie.join(";") : cookie || "";
  const m = c.match(/(?:^|;\s*)lcm_shop_token=([^;]+)/);
  return m?.[1] ? decodeURIComponent(m[1]) : null;
}

/** Dev / first-boot: allow unauthenticated read only when no operators exist. */
export function isBootstrapOpen(operatorCount: number): boolean {
  return operatorCount === 0;
}
