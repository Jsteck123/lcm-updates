/**
 * Shop LAN chat helpers — merge messages so concurrent sends are not lost.
 */
import type { ChatMessage } from "./types";

const MAX_CHAT = 800;

export function mergeChatMessages(
  ...lists: (ChatMessage[] | undefined)[]
): ChatMessage[] {
  const map = new Map<string, ChatMessage>();
  for (const list of lists) {
    for (const m of list || []) {
      if (!m?.id) continue;
      const prev = map.get(m.id);
      if (!prev) {
        map.set(m.id, {
          ...m,
          readBy: Array.isArray(m.readBy) ? [...m.readBy] : [],
          context: m.context || "",
          toEmail: m.toEmail || "",
          channel: m.channel === "dm" ? "dm" : "shop",
          attachments: Array.isArray(m.attachments) ? m.attachments : [],
        });
        continue;
      }
      // union readBy
      const readBy = Array.from(
        new Set([...(prev.readBy || []), ...(m.readBy || [])]),
      );
      const attachments =
        (m.attachments && m.attachments.length
          ? m.attachments
          : prev.attachments) || [];
      map.set(m.id, { ...prev, ...m, readBy, attachments });
    }
  }
  return Array.from(map.values())
    .sort((a, b) => a.createdAt.localeCompare(b.createdAt))
    .slice(-MAX_CHAT);
}

export function chatVisibleTo(
  m: ChatMessage,
  email: string,
): boolean {
  const me = email.trim().toLowerCase();
  if (!me) return false;
  if (m.channel === "shop" || !m.toEmail) return true;
  const from = (m.fromEmail || "").toLowerCase();
  const to = (m.toEmail || "").toLowerCase();
  return from === me || to === me;
}

export function isChatUnread(m: ChatMessage, email: string): boolean {
  const me = email.trim().toLowerCase();
  if (!me) return false;
  if ((m.fromEmail || "").toLowerCase() === me) return false;
  if (!chatVisibleTo(m, email)) return false;
  return !(m.readBy || []).some((e) => e.toLowerCase() === me);
}

export function dmThreadKey(a: string, b: string): string {
  return [a.trim().toLowerCase(), b.trim().toLowerCase()].sort().join("|");
}

export function sameDmThread(
  m: ChatMessage,
  emailA: string,
  emailB: string,
): boolean {
  if (m.channel !== "dm") return false;
  const key = dmThreadKey(m.fromEmail, m.toEmail);
  return key === dmThreadKey(emailA, emailB);
}
