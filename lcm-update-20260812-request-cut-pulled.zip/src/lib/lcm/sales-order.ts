/**
 * Sales Order + QuickBooks-friendly export from a customer shop order.
 * Paper form layout matches Lake Country Machine sales order style.
 */
import type { ShopOrder, ShopOrderLine } from "./types";
import { shopLineExtension, shopOrderSubtotal } from "./po";
import { formatCurrency } from "@/lib/utils";

export const LCM_LETTERHEAD = {
  companyName: "LAKE COUNTRY MACHINE",
  addressLine: "P O Box 390",
  cityLine: "Mineola, TX 75773",
  phone: "9033695300",
};

/** Default TX sales tax — override per export if needed */
export const DEFAULT_SALES_TAX_RATE = 0.0825;

export function suggestSoNumber(order: ShopOrder, allOrders: ShopOrder[]): string {
  if (order.soNumber?.trim()) return order.soNumber.trim();
  // Prefer numeric max+1 from existing SO numbers
  let max = 1000;
  for (const o of allOrders) {
    const n = Number(String(o.soNumber || "").replace(/\D/g, ""));
    if (Number.isFinite(n) && n > max) max = n;
  }
  return String(max + 1);
}

export function formatSoDate(isoOrYmd: string): string {
  if (!isoOrYmd) return "";
  const d = isoOrYmd.slice(0, 10);
  const [y, m, day] = d.split("-");
  if (y && m && day) return `${Number(m)}/${Number(day)}/${y}`;
  try {
    return new Date(isoOrYmd).toLocaleDateString("en-US");
  } catch {
    return isoOrYmd;
  }
}

export type SoLineView = {
  item: string;
  description: string;
  rev: string;
  qty: number;
  rate: number;
  amount: number;
  taxable: boolean;
};

export function shopLinesToSoLines(lines: ShopOrderLine[]): SoLineView[] {
  return (lines || [])
    .filter((l) => l.lineStatus !== "cancelled")
    .filter((l) => (l.partNumber || l.description || "").trim())
    .map((l) => {
      const item = (l.partNumber || "Item").trim();
      const desc = (l.description || "").trim() || item;
      const rate = Number(l.unitCost) || 0;
      const qty = Number(l.qty) || 0;
      return {
        item,
        description: desc,
        rev: (l.revision || "").trim(),
        qty,
        rate,
        amount: rate * qty,
        taxable: Boolean(l.taxable),
      };
    });
}

export function salesOrderTotals(
  lines: SoLineView[],
  taxRate = DEFAULT_SALES_TAX_RATE,
) {
  const subtotal = lines.reduce((s, l) => s + l.amount, 0);
  const taxableBase = lines
    .filter((l) => l.taxable)
    .reduce((s, l) => s + l.amount, 0);
  // If nothing marked taxable, treat whole order as taxable (walk-in default)
  const base = taxableBase > 0 ? taxableBase : subtotal;
  const tax = Math.round(base * taxRate * 100) / 100;
  const total = Math.round((subtotal + tax) * 100) / 100;
  return { subtotal, tax, taxRate, total, taxBase: base };
}

/** QuickBooks Online–style invoice import CSV (one row per line item). */
export function buildQuickBooksInvoiceCsv(opts: {
  order: ShopOrder;
  soNumber: string;
  companyName?: string;
  taxRate?: number;
}): string {
  const { order, soNumber } = opts;
  const taxRate = opts.taxRate ?? DEFAULT_SALES_TAX_RATE;
  const lines = shopLinesToSoLines(order.lines);
  const date = formatSoDate(order.date || order.createdAt);
  const due = formatSoDate(order.dueDate || order.dateRequired || order.date);
  const customer = order.customer || "Walk-In Customer";

  const headers = [
    "InvoiceNo",
    "Customer",
    "InvoiceDate",
    "DueDate",
    "Terms",
    "Memo",
    "Item(Product/Service)",
    "ItemDescription",
    "ItemQuantity",
    "ItemRate",
    "ItemAmount",
    "ItemTaxCode",
    "CustomerPO",
    "ShipTo",
  ];

  const esc = (v: string | number) => {
    const s = String(v ?? "");
    if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
    return s;
  };

  const rows: string[] = [headers.join(",")];
  for (const l of lines) {
    rows.push(
      [
        soNumber,
        customer,
        date,
        due,
        order.terms || "Net 30",
        order.notes || "",
        l.item,
        l.rev ? `${l.description} (Rev ${l.rev})` : l.description,
        l.qty,
        l.rate.toFixed(2),
        l.amount.toFixed(2),
        l.taxable ? "TAX" : "NON",
        order.poNumber || "",
        order.shipToAddress || order.shipToName || "",
      ]
        .map(esc)
        .join(","),
    );
  }

  // Sales tax as a separate line (common for paper form + some imports)
  const { tax } = salesOrderTotals(lines, taxRate);
  if (tax > 0) {
    rows.push(
      [
        soNumber,
        customer,
        date,
        due,
        order.terms || "Net 30",
        "",
        "Sales Tax",
        `Sales Tax ${(taxRate * 100).toFixed(2)}%`,
        1,
        tax.toFixed(2),
        tax.toFixed(2),
        "NON",
        order.poNumber || "",
        "",
      ]
        .map(esc)
        .join(","),
    );
  }

  return rows.join("\n") + "\n";
}

export function downloadTextFile(filename: string, text: string, mime: string) {
  const blob = new Blob([text], { type: mime });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

export { formatCurrency, shopOrderSubtotal, shopLineExtension };
