/**
 * Industry-standard stock size notes for shop inventory.
 * Ranges sized for a full machine shop (round to 20" dia, flat to 5" thk, etc.).
 * Filtered by stock shape + material; custom sizes always allowed in the UI.
 */

function uniq(list: string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const raw of list) {
    const v = String(raw || "").trim();
    if (!v) continue;
    const k = v.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(v);
  }
  return out;
}

/** Format inches for labels: 1.5 → 1.500" or 1½ style where clean */
function inchLabel(n: number): string {
  const fracMap: Record<string, string> = {
    "0.125": '1/8"',
    "0.1875": '3/16"',
    "0.25": '1/4"',
    "0.3125": '5/16"',
    "0.375": '3/8"',
    "0.4375": '7/16"',
    "0.5": '1/2"',
    "0.5625": '9/16"',
    "0.625": '5/8"',
    "0.75": '3/4"',
    "0.875": '7/8"',
    "1": '1"',
    "1.125": '1-1/8"',
    "1.25": '1-1/4"',
    "1.375": '1-3/8"',
    "1.5": '1-1/2"',
    "1.625": '1-5/8"',
    "1.75": '1-3/4"',
    "1.875": '1-7/8"',
    "2": '2"',
    "2.25": '2-1/4"',
    "2.5": '2-1/2"',
    "2.75": '2-3/4"',
    "3": '3"',
    "3.5": '3-1/2"',
    "4": '4"',
    "4.5": '4-1/2"',
    "5": '5"',
    "6": '6"',
    "8": '8"',
    "10": '10"',
    "12": '12"',
    "14": '14"',
    "16": '16"',
    "18": '18"',
    "20": '20"',
  };
  const key = String(n);
  if (fracMap[key]) return fracMap[key];
  // decimal shop callout
  const d = Number.isInteger(n) ? String(n) : n.toFixed(3).replace(/0+$/, "").replace(/\.$/, "");
  return `${d}"`;
}

/** Build diameter / AF / square list: 1/8" through 20" */
function buildBarSizes(maxIn = 20): string[] {
  const sizes = new Set<number>();
  // fine steps under 4"
  for (let i = 1; i <= 32; i++) sizes.add(i / 8); // 1/8 … 4
  for (let i = 17; i <= 48; i++) sizes.add(i / 4); // 4.25 … 12
  for (let i = 25; i <= maxIn * 2; i++) sizes.add(i / 2); // 12.5 … 20
  for (let i = 1; i <= maxIn; i++) sizes.add(i);
  // common decimals
  for (const d of [0.5, 0.625, 0.75, 1.0, 1.25, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0, 12.0, 14.0, 16.0, 18.0, 20.0]) {
    sizes.add(d);
  }
  return [...sizes]
    .filter((n) => n > 0 && n <= maxIn + 1e-9)
    .sort((a, b) => a - b)
    .map(inchLabel);
}

const BAR_DIAS = buildBarSizes(20);
const BAR_LENGTHS = [
  "12 in",
  "18 in",
  "24 in",
  "36 in",
  "48 in",
  "6 ft",
  "8 ft",
  "10 ft",
  "12 ft",
  "14 ft",
  "16 ft",
  "20 ft",
  "24 ft",
];

function barNotes(kind: "dia" | "af" | "sq"): string[] {
  const label = kind === "dia" ? "dia" : kind === "af" ? "AF" : "sq";
  const out: string[] = [];
  // Always list bare sizes (fast pick)
  for (const d of BAR_DIAS) {
    out.push(`${d} ${label}`);
  }
  // Length combos for a practical subset (every size + common lengths would be huge)
  const lengthSizes = BAR_DIAS.filter((_, i) => i % 2 === 0 || BAR_DIAS[i].includes("1/2") || BAR_DIAS[i].includes('1"') || parseFloat(BAR_DIAS[i]) >= 1);
  const commonL = ["6 ft", "8 ft", "10 ft", "12 ft", "20 ft"];
  for (const d of lengthSizes) {
    for (const L of commonL) {
      out.push(`${d} ${label} × ${L}`);
    }
  }
  return out;
}

const PLATE_THK = buildBarSizes(6); // plate up to 6"
const SHEET_BLANKS = [
  '12" × 12"',
  '12" × 24"',
  '24" × 24"',
  '24" × 36"',
  '24" × 48"',
  '36" × 36"',
  '36" × 48"',
  '48" × 48"',
  '48" × 96"',
  '48" × 120"',
  '60" × 120"',
  '72" × 144"',
];

const STEEL_GAUGE = [
  '7ga (~0.179")',
  '10ga (~0.135")',
  '11ga (~0.120")',
  '12ga (~0.105")',
  '13ga (~0.090")',
  '14ga (~0.075")',
  '16ga (~0.060")',
  '18ga (~0.048")',
  '20ga (~0.036")',
  '22ga (~0.030")',
];

function plateSheetNotes(material: string, materialType: string): string[] {
  const mat = material.toLowerCase();
  const typ = materialType.toLowerCase();
  const out: string[] = [];
  if (mat.includes("steel") || typ.includes("ga") || typ.includes("crs") || typ.includes("hrs")) {
    for (const g of STEEL_GAUGE) {
      out.push(g);
      out.push(`${g} × 48" × 96"`);
      out.push(`${g} × 48" × 120"`);
    }
  }
  for (const t of PLATE_THK) {
    out.push(`${t} thk`);
    for (const blank of ['48" × 96"', '48" × 120"', '60" × 120"']) {
      out.push(`${t} × ${blank}`);
    }
  }
  if (mat.includes("aluminum") || mat.includes("aluminium")) {
    for (const t of ['0.190"', '0.250"', '0.375"', '0.500"', '0.750"', '1.000"', '1.500"', '2.000"', '3.000"']) {
      out.push(`${t} plate × 48" × 96"`);
      out.push(`${t} plate × 48" × 120"`);
    }
  }
  for (const b of SHEET_BLANKS) out.push(`sheet ${b}`);
  return out;
}

/**
 * Flat / rectangular bar size notes.
 * Common shop sizes FIRST so typeahead/slice never only shows 1/8" combos.
 * Covers thickness through 5", width through 12".
 */
function flatNotes(): string[] {
  // Decimal + fraction pairs for thickness (must include 0.5 / 1/2)
  const THICKNESS: number[] = [
    0.125, 0.1875, 0.25, 0.3125, 0.375, 0.4375, 0.5, 0.5625, 0.625, 0.75,
    0.875, 1, 1.125, 1.25, 1.375, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.5, 4,
    4.5, 5,
  ];
  const WIDTH: number[] = [
    0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1, 1.125, 1.25, 1.375, 1.5, 1.75,
    2, 2.25, 2.5, 2.75, 3, 3.5, 4, 4.5, 5, 5.5, 6, 7, 8, 9, 10, 11, 12,
  ];
  // Most-used shop pairs first (including .5" × 1")
  const PRIORITY: [number, number][] = [
    [0.5, 1],
    [0.5, 1.5],
    [0.5, 2],
    [0.25, 1],
    [0.25, 1.5],
    [0.25, 2],
    [0.375, 1],
    [0.375, 1.5],
    [0.375, 2],
    [0.625, 1],
    [0.625, 1.5],
    [0.625, 2],
    [0.75, 1],
    [0.75, 1.5],
    [0.75, 2],
    [0.75, 3],
    [1, 1],
    [1, 1.5],
    [1, 2],
    [1, 3],
    [1, 4],
    [1.25, 2],
    [1.25, 3],
    [1.5, 2],
    [1.5, 3],
    [1.5, 4],
    [2, 2],
    [2, 3],
    [2, 4],
    [2, 6],
    [0.5, 0.75],
    [0.5, 1.25],
    [0.5, 3],
    [0.5, 4],
  ];
  const lengths = ["6 ft", "8 ft", "10 ft", "12 ft", "20 ft", '144"'];
  const out: string[] = [];
  const seen = new Set<string>();

  function pushPair(thkN: number, wN: number, withLengths: boolean) {
    if (thkN > wN + 1e-9) return;
    const thk = inchLabel(thkN);
    const w = inchLabel(wN);
    // Also emit decimal form so typing ".5" or "0.5" matches
    const thkDec =
      Number.isInteger(thkN) ? `${thkN}"` : `${String(thkN).replace(/0+$/, "").replace(/\.$/, "")}"`;
    const wDec =
      Number.isInteger(wN) ? `${wN}"` : `${String(wN).replace(/0+$/, "").replace(/\.$/, "")}"`;
    const variants = [
      `${thk} × ${w}`,
      `${thkDec} × ${wDec}`,
      `${thk} × ${w} rect`,
      `${thk} × ${w} flat`,
      `${thkDec} × ${wDec} rect`,
    ];
    if (withLengths) {
      for (const len of lengths) {
        variants.push(`${thk} × ${w} × ${len}`);
        variants.push(`${thkDec} × ${wDec} × ${len}`);
        variants.push(`${thk} × ${w} rect × ${len}`);
        variants.push(`${thkDec} × ${wDec} × ${len}`);
      }
    }
    for (const v of variants) {
      const k = v.toLowerCase();
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(v);
    }
  }

  // 1) Priority pairs with full length options
  for (const [thkN, wN] of PRIORITY) pushPair(thkN, wN, true);

  // 2) Full grid without exploding every length (base cross-section first)
  for (const thkN of THICKNESS) {
    for (const wN of WIDTH) {
      pushPair(thkN, wN, false);
    }
  }

  // 3) Full grid with 12 ft / 144" only (common stick)
  for (const thkN of THICKNESS) {
    for (const wN of WIDTH) {
      if (thkN > wN + 1e-9) continue;
      const thk = inchLabel(thkN);
      const w = inchLabel(wN);
      const thkDec =
        Number.isInteger(thkN)
          ? `${thkN}"`
          : `${String(thkN).replace(/0+$/, "").replace(/\.$/, "")}"`;
      const wDec =
        Number.isInteger(wN)
          ? `${wN}"`
          : `${String(wN).replace(/0+$/, "").replace(/\.$/, "")}"`;
      for (const len of ['12 ft', '144"', '20 ft']) {
        for (const v of [
          `${thk} × ${w} × ${len}`,
          `${thkDec} × ${wDec} × ${len}`,
        ]) {
          const k = v.toLowerCase();
          if (seen.has(k)) continue;
          seen.add(k);
          out.push(v);
        }
      }
    }
  }

  return out;
}

function parseInch(label: string): number {
  const s = label.replace(/"/g, "").trim();
  if (s.includes("-")) {
    // 1-1/2
    const [a, b] = s.split("-");
    return (parseFloat(a) || 0) + parseFraction(b);
  }
  if (s.includes("/")) return parseFraction(s);
  return parseFloat(s) || 0;
}

function parseFraction(s: string): number {
  const [n, d] = s.split("/").map(Number);
  if (!d) return Number(s) || 0;
  return n / d;
}

const TUBE_OD = buildBarSizes(12).filter((s) => parseInch(s) >= 0.25 && parseInch(s) <= 12);
const TUBE_WALL = [
  '0.035"',
  '0.049"',
  '0.065"',
  '0.083"',
  '0.095"',
  '0.120"',
  '0.125"',
  '0.188"',
  '0.250"',
  '0.375"',
  '0.500"',
  '1/8"',
  '3/16"',
  '1/4"',
  '3/8"',
  '1/2"',
];

function roundTubeNotes(): string[] {
  const out: string[] = [];
  for (const od of TUBE_OD) {
    for (const wall of TUBE_WALL) {
      out.push(`${od} OD × ${wall} wall`);
      out.push(`${od} OD × ${wall} wall × 12 ft`);
      out.push(`${od} OD × ${wall} wall × 20 ft`);
    }
  }
  return out;
}

function squareTubeNotes(): string[] {
  const sides = buildBarSizes(8).filter((s) => parseInch(s) >= 0.5 && parseInch(s) <= 8);
  const walls = TUBE_WALL;
  const out: string[] = [];
  for (const s of sides) {
    for (const w of walls) {
      out.push(`${s} × ${s} × ${w} wall`);
      out.push(`${s} × ${s} × ${w} wall × 20 ft`);
      out.push(`${s} × ${s} × ${w} wall × 24 ft`);
    }
  }
  const rect: [number, number][] = [
    [1, 2],
    [1.5, 3],
    [2, 3],
    [2, 4],
    [3, 4],
    [3, 6],
    [4, 6],
    [4, 8],
    [6, 8],
  ];
  for (const [a, b] of rect) {
    for (const w of ['0.120"', '0.125"', '0.188"', '0.250"', '1/8"', '1/4"']) {
      out.push(`${inchLabel(a)} × ${inchLabel(b)} × ${w} wall`);
      out.push(`${inchLabel(a)} × ${inchLabel(b)} × ${w} wall × 20 ft`);
    }
  }
  return out;
}

function angleNotes(): string[] {
  const equal = [0.5, 0.75, 1, 1.25, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6, 8];
  const thk = [0.125, 0.1875, 0.25, 0.3125, 0.375, 0.5, 0.625, 0.75];
  const out: string[] = [];
  for (const L of equal) {
    for (const t of thk) {
      if (t > L) continue;
      out.push(`${inchLabel(L)} × ${inchLabel(L)} × ${inchLabel(t)} angle`);
      out.push(`${inchLabel(L)} × ${inchLabel(L)} × ${inchLabel(t)} angle × 20 ft`);
    }
  }
  const unequal: [number, number][] = [
    [1, 1.5],
    [1.5, 2],
    [2, 3],
    [3, 4],
    [4, 6],
    [5, 3],
    [6, 4],
  ];
  for (const [a, b] of unequal) {
    for (const t of thk) {
      out.push(`${inchLabel(a)} × ${inchLabel(b)} × ${inchLabel(t)} angle`);
      out.push(`${inchLabel(a)} × ${inchLabel(b)} × ${inchLabel(t)} angle × 20 ft`);
    }
  }
  return out;
}

function channelNotes(): string[] {
  // Imperial channel depth × weight class (common C-channel callouts)
  const depths = ['3"', '4"', '5"', '6"', '8"', '10"', '12"'];
  const out: string[] = [];
  for (const d of depths) {
    out.push(`C${d.replace('"', "")} channel`);
    out.push(`${d} channel × 20 ft`);
    out.push(`${d} channel × 40 ft`);
  }
  // MC / structural-ish shop labels
  for (const w of ["4.1#", "5.4#", "6.5#", "8.2#", "10#", "13#", "15#", "20#"]) {
    out.push(`C6 × ${w}`);
    out.push(`C8 × ${w}`);
    out.push(`C10 × ${w}`);
  }
  return out;
}

function hexNotes(): string[] {
  return barNotes("af").map((s) =>
    s.replace(/ AF/g, " hex AF").replace(/AF ×/g, "hex AF ×"),
  );
}

function pipeNotes(): string[] {
  const nps = [
    '1/4" NPS',
    '3/8" NPS',
    '1/2" NPS',
    '3/4" NPS',
    '1" NPS',
    '1-1/4" NPS',
    '1-1/2" NPS',
    '2" NPS',
    '2-1/2" NPS',
    '3" NPS',
    '4" NPS',
    '6" NPS',
    '8" NPS',
    '10" NPS',
    '12" NPS',
  ];
  const sch = ["Sch 10", "Sch 40", "Sch 80", "Sch 160", "XXH"];
  const out: string[] = [];
  for (const n of nps) {
    for (const s of sch) {
      out.push(`${n} ${s}`);
      out.push(`${n} ${s} × 21 ft`);
    }
  }
  return out;
}

function plasticNotes(materialType: string): string[] {
  const rods = barNotes("dia").slice(0, 120).map((s) => s.replace("dia", "rod"));
  const sheets = plateSheetNotes("Plastic", materialType).map((s) =>
    s.startsWith("plastic") ? s : `plastic ${s}`,
  );
  return uniq([...rods, ...sheets]);
}

/**
 * Size-note options for inventory add form.
 */
export function stockSizeNoteOptions(opts: {
  material?: string;
  materialType?: string;
  stockShape?: string;
  /** Extra shop-saved custom size notes */
  customNotes?: string[];
}): string[] {
  const material = (opts.material || "").trim();
  const materialType = (opts.materialType || "").trim();
  const shape = (opts.stockShape || "").toLowerCase();

  let list: string[] = [];

  // NOTE: "rectangle".includes("angle") is TRUE — never test angle before rect!
  const isTube = shape.includes("tube");
  const isRectBar =
    !isTube &&
    (shape.includes("rect") ||
      shape.includes("rectangle") ||
      (shape.includes("flat") &&
        !shape.includes("sheet") &&
        !shape.includes("plate")));
  // Real angle iron only — not "rectangle"
  const isAngle =
    !isRectBar &&
    (shape === "angle" ||
      shape === "angle stock" ||
      shape.startsWith("angle ") ||
      shape.endsWith(" angle") ||
      /\bangle\b/.test(shape));

  if (shape.includes("hex")) {
    list = hexNotes();
  } else if (shape.includes("rect") && isTube) {
    list = squareTubeNotes();
  } else if (shape.includes("round") && isTube) {
    list = roundTubeNotes();
  } else if (shape.includes("square") && isTube) {
    list = squareTubeNotes();
  } else if (shape.includes("pipe")) {
    list = pipeNotes();
  } else if (isTube) {
    list = uniq([...roundTubeNotes(), ...squareTubeNotes()]);
  } else if (shape.includes("channel") || shape.includes("beam")) {
    list = channelNotes();
  } else if (isRectBar) {
    // Rectangular Stock / Flat Bar / Rectangle — thickness × width
    list = flatNotes();
  } else if (isAngle) {
    list = angleNotes();
  } else if (
    shape.includes("plate") ||
    shape.includes("sheet") ||
    shape.includes("flat sheet")
  ) {
    list = plateSheetNotes(material, materialType);
  } else if (shape.includes("square") && !isTube) {
    list = barNotes("sq");
  } else if (
    (shape.includes("round") && !isTube) ||
    shape === "bar" ||
    shape === "bar stock" ||
    shape === "round stock" ||
    !shape
  ) {
    list = barNotes("dia");
  } else {
    list = uniq([
      ...flatNotes().slice(0, 250),
      ...barNotes("dia").slice(0, 200),
      ...plateSheetNotes(material, materialType).slice(0, 100),
    ]);
  }

  const typ = materialType.toLowerCase();
  const mat = material.toLowerCase();
  if (mat.includes("plastic")) list = plasticNotes(materialType);
  if (typ.includes("ga") || typ.includes("crs") || typ.includes("hrs")) {
    const gauges = STEEL_GAUGE.flatMap((g) => [g, `${g} × 48" × 96"`, `${g} × 48" × 120"`]);
    list = uniq([...gauges, ...list]);
  }

  const custom = (opts.customNotes || []).filter(Boolean);
  // Flat/rect catalogs are ordered with common sizes first — keep a high cap
  // so 0.5" × 1" is never dropped behind thousands of 1/8" combos.
  const cap =
    shape.includes("rect") ||
    (shape.includes("flat") && !shape.includes("sheet"))
      ? 4000
      : 800;
  return uniq([...custom, ...list]).slice(0, cap);
}

export function stockSizeNoteHint(stockShape: string): string {
  const s = (stockShape || "").toLowerCase();
  if (
    s.includes("rect") ||
    s.includes("rectangle") ||
    (s.includes("flat") && !s.includes("sheet"))
  )
    return 'Rectangular / flat bar: thickness × width (e.g. 1/2" × 1" × 12 ft). Not angles or diameters.';
  if (s.includes("tube") && s.includes("square"))
    return "Square/rect tube: side × wall × length.";
  if (s.includes("tube") || s.includes("pipe"))
    return "OD × wall, or NPS × schedule for pipe.";
  if (s.includes("plate") || s.includes("sheet"))
    return "Thickness / gauge × sheet blank.";
  if (/\bangle\b/.test(s) && !s.includes("rect"))
    return "Leg × leg × thickness.";
  if (s.includes("channel")) return "Channel depth / C-channel callouts.";
  if (s.includes("hex")) return "Across-flats hex bar through 20\".";
  if (s.includes("square")) return "Square bar through 20\".";
  return "Round bar diameters through 20\". Type to filter or add custom.";
}
