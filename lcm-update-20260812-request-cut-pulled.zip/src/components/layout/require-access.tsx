import { useEffect } from "react";
import { useNavigate, useRouterState } from "@tanstack/react-router";
import { useLcmStore } from "@/store/lcm-store";
import {
  firstAllowedPath,
  getOperatorByEmail,
  operatorCanAccessTab,
  pathToTab,
} from "@/lib/lcm/permissions";
import { useHydrated } from "@/hooks/use-hydrated";

/** Blocks page content when current user lacks the tab; redirects to first allowed. */
export function RequireAccess({
  children,
  pathname: pathnameProp,
}: {
  children: React.ReactNode;
  pathname?: string;
}) {
  const routerPath = useRouterState({ select: (s) => s.location.pathname });
  const pathname = pathnameProp ?? routerPath ?? "/";
  const hydrated = useHydrated();
  const navigate = useNavigate();
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  const op = getOperatorByEmail(operators, email);
  const tab = pathToTab(pathname);
  const assignBlocked =
    pathname.startsWith("/assign") && op?.role !== "admin";
  const allowed =
    !assignBlocked && (!tab || operatorCanAccessTab(op, tab));

  useEffect(() => {
    if (!hydrated) return;
    if (!allowed) {
      navigate({ to: firstAllowedPath(op) as "/" });
    }
  }, [hydrated, allowed, op, navigate]);

  if (!hydrated) {
    return (
      <div className="mx-auto max-w-md py-16 text-center text-sm text-[var(--color-muted)]">
        Loading…
      </div>
    );
  }
  if (!allowed) {
    return (
      <div className="mx-auto max-w-md py-16 text-center space-y-3">
        <h1 className="text-xl font-semibold">Access restricted</h1>
        <p className="text-sm text-[var(--color-muted)]">
          Your account does not have permission for this page. Ask an admin to grant access in
          Settings.
        </p>
      </div>
    );
  }

  return <>{children}</>;
}
