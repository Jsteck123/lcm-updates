import { useMemo, useState } from "react";
import { Clock, Wrench, Square, Play } from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import type { QuoteToolingKind } from "@/lib/lcm/types";
import { liveToolingMinutes } from "@/lib/lcm/shop-tooling-log";
import { TOOLING_KIND_LABEL } from "@/lib/lcm/quote-tooling";
import { cn, formatSeconds } from "@/lib/utils";

function floorKindLabel(kind: QuoteToolingKind): string {
  return kind === "soft_jaws" ? "Soft jaws" : "Other";
}

/** Floor-only: soft jaws or other tooling timer. No rates, billing, or notes. */
export function ShopToolingFloorPanel({
  machine,
  tick,
}: {
  machine: string;
  /** Parent re-renders every second for live timer display */
  tick?: number;
}) {
  const session = useLcmStore((s) => s.sessions[machine]);
  const logs = useLcmStore((s) => s.shopToolingLogs || []);
  const startShopToolingLog = useLcmStore((s) => s.startShopToolingLog);
  const stopShopToolingTimer = useLcmStore((s) => s.stopShopToolingTimer);

  const [kind, setKind] = useState<QuoteToolingKind>("soft_jaws");

  const running = useMemo(
    () =>
      (logs || []).find(
        (l) =>
          l.machine === machine && l.status === "open" && l.timerStartedAt,
      ),
    [logs, machine, tick],
  );

  function onStart() {
    const r = startShopToolingLog({
      machine,
      kind,
      description: TOOLING_KIND_LABEL[kind],
    });
    if (!r.ok) {
      toast.error(r.error || "Could not start");
      return;
    }
    toast.success(`${floorKindLabel(kind)} timer started`);
  }

  function onStop() {
    if (!running) return;
    const r = stopShopToolingTimer(running.id);
    if (!r.ok) {
      toast.error(r.error || "Could not stop");
      return;
    }
    toast.success("Time saved");
  }

  void tick;

  return (
    <Card className="border-[color-mix(in_oklab,var(--color-warn)_35%,var(--color-border))]">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <Wrench className="h-4 w-4 text-[var(--color-warn)]" />
          Soft jaws / other
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {running ? (
          <div className="rounded-[var(--radius-md)] border border-[color-mix(in_oklab,var(--color-warn)_45%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-warn)_12%,transparent)] p-4 space-y-4">
            <div className="text-center">
              <div className="text-sm font-medium text-[var(--color-muted)]">
                {floorKindLabel(running.kind)}
                {running.partNumber ? ` · ${running.partNumber}` : ""}
              </div>
              <div className="text-4xl font-semibold tabular mt-2 flex items-center justify-center gap-2">
                <Clock className="h-8 w-8" />
                {formatSeconds(Math.floor(liveToolingMinutes(running) * 60))}
              </div>
            </div>
            <Button
              size="lg"
              className="w-full min-h-14 text-base"
              onClick={onStop}
            >
              <Square className="h-5 w-5" /> Stop
            </Button>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-2">
              {(
                [
                  ["soft_jaws", "Soft jaws"],
                  ["other", "Other"],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setKind(id)}
                  className={cn(
                    "min-h-12 rounded-[var(--radius-md)] border px-3 py-2 text-sm font-semibold",
                    kind === id
                      ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)] text-[var(--color-primary)]"
                      : "border-[var(--color-border)] text-[var(--color-muted)]",
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
            <Button
              size="lg"
              className="w-full min-h-14 text-base"
              onClick={onStart}
              disabled={!session?.operatorName || !session?.partNumber?.trim()}
            >
              <Play className="h-5 w-5" /> Start timer
            </Button>
            {(!session?.operatorName || !session?.partNumber?.trim()) && (
              <p className="text-xs text-[var(--color-muted)] text-center">
                Sign in and load a part first
              </p>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
