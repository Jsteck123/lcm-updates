/**
 * Customer-facing quote letter — same layout for screen preview, print, and HTML email.
 * Keep part blocks intact across page breaks (no mid-line splits).
 */
import { formatCurrency } from "@/lib/utils";
import type { QuoteEmailDraft, QuotePartBlock } from "@/lib/lcm/quote-email";
import { cn } from "@/lib/utils";

function PartBlock({ part }: { part: QuotePartBlock }) {
  return (
    <div className="quote-part-block rounded-md border border-neutral-300 overflow-hidden bg-white text-black">
      <div className="border-b border-neutral-300 bg-neutral-100 px-3 py-2 font-semibold text-sm text-black">
        Part #{part.partNumber}
        <span className="font-normal text-neutral-600">
          {" "}
          — Rev {part.revision}
        </span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse">
          <tbody>
            <tr>
              <th className="text-left font-medium text-neutral-600 border border-neutral-300 bg-neutral-50 px-3 py-2 w-16">
                QTY
              </th>
              {part.quantities.map((q, i) => (
                <td
                  key={`q-${i}`}
                  className="border border-neutral-300 px-3 py-2 text-center tabular-nums font-medium text-black"
                >
                  {q > 0 ? q : "—"}
                </td>
              ))}
            </tr>
            <tr>
              <th className="text-left font-medium text-neutral-600 border border-neutral-300 bg-neutral-50 px-3 py-2">
                Each
              </th>
              {part.prices.map((price, i) => (
                <td
                  key={`p-${i}`}
                  className="border border-neutral-300 px-3 py-2 text-center tabular-nums font-semibold text-black"
                >
                  {price > 0 ? formatCurrency(price) : "TBD"}
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>
      {(part.extraLines || []).map((line, li) => (
        <div
          key={`extra-${li}`}
          className="border-t border-neutral-300 px-3 py-2 space-y-1 bg-amber-50/80"
        >
          <div className="text-sm font-medium text-black">{line.description}</div>
          <div className="flex flex-wrap gap-4 text-sm tabular-nums text-black">
            <span>
              <span className="text-neutral-600">QTY</span>{" "}
              <strong>{line.qty}</strong>
            </span>
            <span>
              <span className="text-neutral-600">Each</span>{" "}
              <strong>
                {line.unitPrice > 0 ? formatCurrency(line.unitPrice) : "TBD"}
              </strong>
            </span>
            {line.qty > 0 && line.unitPrice > 0 ? (
              <span className="text-neutral-600">
                Ext {formatCurrency(line.qty * line.unitPrice)}
              </span>
            ) : null}
          </div>
        </div>
      ))}
    </div>
  );
}

export function QuoteLetter({
  draft,
  className,
  /** When true, outer chrome is for print isolation root */
  printRoot = false,
}: {
  draft: QuoteEmailDraft;
  className?: string;
  printRoot?: boolean;
}) {
  return (
    <div
      id={printRoot ? "quote-email-print" : undefined}
      className={cn(
        "quote-letter rounded-md border-2 border-neutral-400 bg-white text-black p-4 sm:p-5 space-y-4",
        className,
      )}
    >
      <div className="border-b border-neutral-300 pb-3">
        <div className="text-lg font-semibold tracking-tight text-black">
          {draft.companyName}
        </div>
        <div className="text-sm text-neutral-600 mt-1">
          Quote date: {draft.dateLabel}
        </div>
        <div className="text-sm mt-0.5 text-black">
          Customer:{" "}
          <span className="font-medium">{draft.customerName}</span>
        </div>
      </div>

      {draft.parts.map((part) => (
        <PartBlock
          key={`${part.partNumber}-${part.revision}`}
          part={part}
        />
      ))}

      {draft.notes?.trim() ? (
        <p className="text-sm text-neutral-700 border-t border-neutral-300 pt-3 whitespace-pre-wrap">
          {draft.notes.trim()}
        </p>
      ) : null}
      <p className="text-sm text-black">— {draft.companyName}</p>
    </div>
  );
}
