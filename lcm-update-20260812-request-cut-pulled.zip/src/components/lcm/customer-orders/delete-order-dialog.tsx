import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { ShopOrder } from "@/lib/lcm/types";

export function DeleteOrderDialog({
  selected,
  onCancel,
  onConfirm,
}: {
  selected: ShopOrder;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  return (
    <div
      className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-black/60 p-4 print:hidden"
      onClick={onCancel}
    >
      <div
        className="relative z-[71] w-full max-w-md rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 space-y-4 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-lg font-semibold text-red-700">Delete this PO?</h2>
        <p className="text-sm text-[var(--color-muted)]">
          This permanently removes{" "}
          <strong className="text-[var(--color-fg)]">
            {selected.poNumber || "this order"}
          </strong>
          {selected.customer ? ` for ${selected.customer}` : ""} and all of its
          lines. Jobs already on machines are not deleted.
        </p>
        <div className="flex justify-end gap-2">
          <Button variant="ghost" type="button" onClick={onCancel}>
            Cancel
          </Button>
          <Button
            type="button"
            className="bg-red-600 text-white hover:bg-red-700"
            onClick={onConfirm}
          >
            <Trash2 className="h-4 w-4" /> Yes, delete
          </Button>
        </div>
      </div>
    </div>
  );
}
