import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { ShopOrder } from "@/lib/lcm/types";
import { cn } from "@/lib/utils";
import { statusSurfaceClass, packStatusToShop } from "@/lib/lcm/status-colors";
import { activeShopLineCount, shopLineOpenQty } from "@/lib/lcm/po";

export function OrderListPanel({
  shopOrders,
  selectedId,
  selected,
  onSelect,
  statusTone,
}: {
  shopOrders: ShopOrder[];
  selectedId: string | null;
  selected: ShopOrder | null;
  onSelect: (id: string) => void;
  statusTone: (status: string) => any;
}) {
  return (
  <Card className="lg:col-span-3 print:hidden">
    <CardHeader className="pb-2">
      <CardTitle className="text-base">Customer POs</CardTitle>
      <CardDescription>Select to open the form</CardDescription>
    </CardHeader>
    <CardContent className="space-y-2 max-h-[36rem] overflow-y-auto">
      {shopOrders.map((o) => (
        <button
          key={o.id}
          type="button"
          onClick={() => onSelect(o.id)}
          className={cn(
            "w-full text-left rounded-[var(--radius-md)] border px-3 py-2 text-sm min-h-11",
            selected?.id === o.id
              ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_10%,transparent)]"
              : "border-[var(--color-border)]",
            selected?.id !== o.id &&
              statusSurfaceClass(packStatusToShop(o.packStatus)),
          )}
        >
          <div className="flex items-center justify-between gap-2">
            <span className="font-semibold font-mono text-xs sm:text-sm">
              {o.poNumber || "(no PO #)"}
              {o.poRevision ? (
                <span className="ml-1 font-sans font-medium text-[var(--color-muted)]">
                  rev {o.poRevision}
                </span>
              ) : null}
            </span>
            <Badge tone={statusTone(o.status)}>{o.status}</Badge>
          </div>
          <div className="text-xs text-[var(--color-muted)] mt-0.5">
            {o.customer || "No customer"} · {activeShopLineCount(o)} line
            {activeShopLineCount(o) === 1 ? "" : "s"}
          </div>
          {o.dateRequired && (
            <div className="text-[10px] text-[var(--color-subtle)]">
              Need by {o.dateRequired}
            </div>
          )}
        </button>
      ))}
      {shopOrders.length === 0 && (
        <p className="text-sm text-[var(--color-muted)]">
          No customer POs yet.
        </p>
      )}
    </CardContent>
  </Card>
  );
}
