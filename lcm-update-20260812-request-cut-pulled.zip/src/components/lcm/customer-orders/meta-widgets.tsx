import { Input, Label } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";

export function MetaCell({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
}) {
  return (
    <div className="px-2 py-1.5 border-r border-b border-[var(--color-border)]">
      <div className="text-[9px] font-bold uppercase text-[var(--color-muted)]">
        {label}
      </div>
      <Input
        type={type}
        className="h-8 text-xs mt-0.5"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}

export function Stat({ label, value }: { label: string; value: string }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="text-xs uppercase tracking-wide text-[var(--color-muted)]">
          {label}
        </div>
        <div className="text-2xl font-semibold tabular mt-1">{value}</div>
      </CardContent>
    </Card>
  );
}
