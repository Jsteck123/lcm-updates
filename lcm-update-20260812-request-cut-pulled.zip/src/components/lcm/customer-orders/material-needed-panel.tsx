import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { computeOrderNeeds } from "@/lib/lcm/po";

export function MaterialNeededPanel({
  needs,
}: {
  needs: ReturnType<typeof computeOrderNeeds>;
}) {
  return (
<Card className="print:hidden">
  <CardHeader className="pb-2">
    <CardTitle className="text-base">Material needed for open POs</CardTitle>
    <CardDescription>
      From open shop order lines + floor jobs. Place buys under Inventory →
      Material buys.
    </CardDescription>
  </CardHeader>
  <CardContent>
    <div className="flex flex-wrap gap-2">
      {needs.filter((n) => n.toOrder > 0).length === 0 && (
        <span className="text-sm text-[var(--color-muted)]">
          Stock covers current demand.
        </span>
      )}
      {needs
        .filter((n) => n.toOrder > 0)
        .slice(0, 12)
        .map((n) => (
          <div
            key={n.key}
            className="rounded-full border border-[var(--color-border)] px-3 py-1 text-xs"
          >
            <span className="font-medium">
              {n.material} {n.materialType}
            </span>
            <span className="text-[var(--color-warn)] font-semibold ml-2">
              order {n.toOrder}
            </span>
          </div>
        ))}
    </div>
  </CardContent>
</Card>
  );
}
