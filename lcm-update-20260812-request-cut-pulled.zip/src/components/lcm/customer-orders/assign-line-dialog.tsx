import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import type { ShopOrder } from "@/lib/lcm/types";

export function AssignLineDialog({
  assignLine,
  selected,
  assignMachine,
  setAssignMachine,
  assignOperator,
  setAssignOperator,
  assignQty,
  setAssignQty,
  assignNotes,
  setAssignNotes,
  machines,
  operatorNames,
  onClose,
  onAssign,
}: {
  assignLine: { lineId: string; partNumber: string; openQty: number };
  selected: ShopOrder;
  assignMachine: string;
  setAssignMachine: (v: string) => void;
  assignOperator: string;
  setAssignOperator: (v: string) => void;
  assignQty: string;
  setAssignQty: (v: string) => void;
  assignNotes: string;
  setAssignNotes: (v: string) => void;
  machines: string[];
  operatorNames: string[];
  onClose: () => void;
  onAssign: () => void;
}) {
  return (
  <div
    className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-4 print:hidden"
    onClick={onClose}
  >
    <div
      className="relative z-[60] w-full max-w-md rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 space-y-3 shadow-xl"
      onClick={(e) => e.stopPropagation()}
    >
      <h2 className="text-lg font-semibold">Assign to machine</h2>
      <p className="text-sm text-[var(--color-muted)]">
        {assignLine.partNumber} · open qty {assignLine.openQty}. Adds to
        that machine's (and optional person's) running order.
      </p>
      <div className="space-y-1.5">
        <Label>Machine</Label>
        <Select
          value={assignMachine}
          onChange={(e) => setAssignMachine(e.target.value)}
        >
          <option value="">Select machine</option>
          {machines.map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </Select>
      </div>
      <div className="space-y-1.5">
        <Label>Operator (optional)</Label>
        <Select
          value={assignOperator}
          onChange={(e) => setAssignOperator(e.target.value)}
        >
          <option value="">Anyone / later</option>
          {operatorNames.map((n) => (
            <option key={n} value={n}>
              {n}
            </option>
          ))}
        </Select>
      </div>
      <div className="space-y-1.5">
        <Label>Qty to run</Label>
        <Input
          type="number"
          value={assignQty}
          onChange={(e) => setAssignQty(e.target.value)}
        />
      </div>
      <div className="space-y-1.5">
        <Label>Note</Label>
        <Input
          value={assignNotes}
          onChange={(e) => setAssignNotes(e.target.value)}
          placeholder="Op 2 only, heat treat first..."
        />
      </div>
      <div className="flex justify-end gap-2 pt-1">
        <Button variant="ghost" onClick={onClose}>
          Cancel
        </Button>
        <Button onClick={onAssign}>
          Add to running order
        </Button>
      </div>
    </div>
  </div>
  );
}
