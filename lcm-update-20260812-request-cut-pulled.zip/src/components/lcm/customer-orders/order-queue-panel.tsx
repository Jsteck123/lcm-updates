import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import type { WorkQueueItem } from "@/lib/lcm/types";
import { machineToSlug } from "@/lib/lcm/machines";
import { toast } from "sonner";

export function OrderQueuePanel({
  orderQueue,
  startWorkQueueItem,
  removeWorkQueueItem,
  moveWorkQueueItem,
}: {
  orderQueue: WorkQueueItem[];
  startWorkQueueItem: (id: string) => { ok: boolean; error?: string };
  removeWorkQueueItem: (id: string) => void;
  moveWorkQueueItem: (id: string, dir: "up" | "down") => void;
}) {
  if (orderQueue.length === 0) return null;
  return (
  <Card className="print:hidden">
    <CardHeader className="pb-2">
      <CardTitle className="text-base">
        Running order for this PO
      </CardTitle>
      <CardDescription>
        Assigned to machines / people. Start here or from Shop Floor. 
      </CardDescription>
    </CardHeader>
    <CardContent className="space-y-2">
      {orderQueue.map((q) => (
        <div
          key={q.id}
          className="flex flex-col sm:flex-row sm:items-center gap-2 rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2 text-sm"
        >
          <div className="flex-1 min-w-0">
            <div className="font-medium">
              {q.partNumber}{" "}
              <span className="text-[var(--color-muted)] font-normal">
                x{q.qty}
              </span>
            </div>
            <div className="text-xs text-[var(--color-muted)]">
              {q.machine || "No machine"}
              {q.operatorName ? ` · ${q.operatorName}` : ""}
              {" · "}
              {q.status}
              {q.notes ? ` · ${q.notes}` : ""}
            </div>
          </div>
          <div className="flex flex-wrap gap-1">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => moveWorkQueueItem(q.id, "up")}
            >
              Up
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => moveWorkQueueItem(q.id, "down")}
            >
              Down
            </Button>
            <Button
              size="sm"
              disabled={q.status === "done"}
              onClick={() => {
                const r = startWorkQueueItem(q.id);
                if (!r.ok) {
                  toast.error(r.error || "Could not start");
                  return;
                }
                toast.success(`Loaded ${q.partNumber} on ${q.machine}`);
              }}
            >
              Load / start
            </Button>
            {q.machine ? (
              <Link
                to="/machines/$machineId"
                params={{ machineId: machineToSlug(q.machine) }}
                className="inline-flex items-center rounded-[var(--radius-md)] border border-[var(--color-border)] px-2 py-1 text-xs min-h-9"
              >
                Open machine
              </Link>
            ) : null}
            <Button
              size="sm"
              variant="ghost"
              onClick={() => removeWorkQueueItem(q.id)}
            >
              Remove
            </Button>
          </div>
        </div>
      ))}
    </CardContent>
  </Card>
  );
}
