import { useEffect, useState } from "react";
import { getCompanyLogoInfo } from "@/lib/lcm/branding-api";
import { cn } from "@/lib/utils";

type Variant = "wide" | "mark" | "auto";

/**
 * Company logo: uses Settings upload when present, else built-in LCM art.
 * - wide: letterhead / print
 * - mark: sidebar / compact
 */
export function CompanyLogo({
  variant = "auto",
  className,
  alt = "Company logo",
  /** Prefer white asset for dark chrome when using built-in fallback */
  invertFallback = false,
}: {
  variant?: Variant;
  className?: string;
  alt?: string;
  invertFallback?: boolean;
}) {
  const [url, setUrl] = useState<string | null>(null);
  const [custom, setCustom] = useState(false);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const r = await getCompanyLogoInfo();
        if (cancelled) return;
        if (r.ok && r.hasLogo && r.url) {
          setUrl(r.url);
          setCustom(true);
        } else {
          setCustom(false);
          setUrl(null);
        }
      } catch {
        if (!cancelled) {
          setCustom(false);
          setUrl(null);
        }
      }
    })();
    // re-check when tab gains focus (after settings upload on another screen)
    const onFocus = () => {
      void getCompanyLogoInfo().then((r) => {
        if (r.ok && r.hasLogo && r.url) {
          setUrl(r.url);
          setCustom(true);
        }
      });
    };
    window.addEventListener("focus", onFocus);
    window.addEventListener("lcm-logo-changed", onFocus);
    return () => {
      cancelled = true;
      window.removeEventListener("focus", onFocus);
      window.removeEventListener("lcm-logo-changed", onFocus);
    };
  }, []);

  const fallback =
    variant === "mark"
      ? invertFallback
        ? "/lcm-logo-white.png"
        : "/lcm-logo.png"
      : invertFallback
        ? "/lcm-logo-wide-white.png"
        : "/lcm-logo-wide.png";

  const src = custom && url ? url : fallback;

  return (
    <img
      src={src}
      alt={alt}
      className={cn("object-contain", className)}
      onError={(e) => {
        // fallback if custom 404
        const el = e.currentTarget;
        if (el.src.includes("/api/branding")) {
          el.src = fallback;
        }
      }}
    />
  );
}

/** Notify other tabs/components after Settings upload */
export function notifyLogoChanged() {
  try {
    window.dispatchEvent(new Event("lcm-logo-changed"));
  } catch {
    /* ignore */
  }
}
