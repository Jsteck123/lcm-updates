import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import type { InventoryTxnType } from "@/lib/lcm/types";

export type MoveState = {
  itemKind: "material" | "part";
  itemId: string;
  label: string;
  kind: InventoryTxnType;
} | null;

export type DeleteTarget = {
  kind: "material" | "part";
  id: string;
  label: string;
} | null;

export function StockMoveDialog({
  move,
  moveQty,
  setMoveQty,
  moveReason,
  setMoveReason,
  moveRef,
  setMoveRef,
  moveAbsolute,
  setMoveAbsolute,
  setMove,
  confirmMove,
}: {
  move: NonNullable<MoveState>;
  moveQty: string;
  setMoveQty: (v: string) => void;
  moveReason: string;
  setMoveReason: (v: string) => void;
  moveRef: string;
  setMoveRef: (v: string) => void;
  moveAbsolute: boolean;
  setMoveAbsolute: (v: boolean) => void;
  setMove: (m: MoveState) => void;
  confirmMove: () => void;
}) {
  return (
  <div
    className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-4"
    onClick={() => setMove(null)}
  >
    <div
      className="w-full max-w-md rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 shadow-xl space-y-3"
      onClick={(e) => e.stopPropagation()}
    >
      <h2 className="text-lg font-semibold capitalize">
        {move.kind} stock
      </h2>
      <p className="text-sm text-[var(--color-muted)]">{move.label}</p>
      <div className="space-y-1.5">
        <Label>
          {move.kind === "adjust" && moveAbsolute
            ? "New on-hand count"
            : "Quantity"}
        </Label>
        <Input
          type="number"
          autoFocus
          value={moveQty}
          onChange={(e) => setMoveQty(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") confirmMove();
          }}
        />
      </div>
      {move.kind === "adjust" && (
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={moveAbsolute}
            onChange={(e) => setMoveAbsolute(e.target.checked)}
          />
          Set absolute count (unchecked = add/subtract)
        </label>
      )}
      <div className="space-y-1.5">
        <Label>Reason / note</Label>
        <Input
          value={moveReason}
          onChange={(e) => setMoveReason(e.target.value)}
          placeholder="PO #, job, scrap, etc."
        />
      </div>
      <div className="space-y-1.5">
        <Label>Reference (optional)</Label>
        <Input
          value={moveRef}
          onChange={(e) => setMoveRef(e.target.value)}
          placeholder="Job or PO"
        />
      </div>
      <div className="flex justify-end gap-2 pt-1">
        <Button variant="ghost" onClick={() => setMove(null)}>
          Cancel
        </Button>
        <Button onClick={confirmMove}>Confirm</Button>
      </div>
    </div>
  </div>
  );
}

export function StockDeleteDialog({
  deleteTarget,
  setDeleteTarget,
  removeMaterialStock,
  removePartStock,
}: {
  deleteTarget: NonNullable<DeleteTarget>;
  setDeleteTarget: (t: DeleteTarget) => void;
  removeMaterialStock: (id: string) => void;
  removePartStock: (id: string) => void;
}) {
  return (
  <div
    className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
    onClick={() => setDeleteTarget(null)}
  >
    <div
      className="w-full max-w-md rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 shadow-xl space-y-4"
      onClick={(e) => e.stopPropagation()}
    >
      <div>
        <h3 className="text-lg font-semibold text-[var(--color-fg)]">
          Delete stock line?
        </h3>
        <p className="text-sm text-[var(--color-muted)] mt-1">
          Remove{" "}
          <strong className="text-[var(--color-fg)]">
            {deleteTarget.label}
          </strong>{" "}
          from inventory. This does not delete the part from Master
          Quoter — only this stock row.
        </p>
      </div>
      <div className="flex justify-end gap-2">
        <Button
          type="button"
          variant="outline"
          onClick={() => setDeleteTarget(null)}
        >
          Cancel
        </Button>
        <Button
          type="button"
          variant="default"
          className="bg-[var(--color-danger)] text-white hover:opacity-90"
          onClick={() => {
            if (deleteTarget.kind === "material") {
              removeMaterialStock(deleteTarget.id);
              toast.success(`Deleted ${deleteTarget.label}`);
            } else {
              removePartStock(deleteTarget.id);
              toast.success(`Deleted ${deleteTarget.label}`);
            }
            setDeleteTarget(null);
          }}
        >
          <Trash2 className="h-4 w-4" />
          Delete
        </Button>
      </div>
    </div>
  </div>
  );
}
