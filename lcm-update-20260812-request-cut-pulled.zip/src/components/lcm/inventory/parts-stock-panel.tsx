import { MoneyInput } from "./material-buys-panel";
import {Trash2, ArrowDownToLine, ArrowUpFromLine, SlidersHorizontal, Plus} from "lucide-react";
// Plus used in save buttons

import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CreatableSelect } from "@/components/ui/creatable-select";
import { Typeahead } from "@/components/ui/typeahead";
import {
  INVENTORY_UNITS,
  PART_CATEGORIES,
  emptyPart,
  isLowStock,
  partLabel,
} from "@/lib/lcm/inventory";
import type { InventoryTxnType, PartStock, PartUnit } from "@/lib/lcm/types";
import { formatCurrency } from "@/lib/utils";
import { useCanSeeMoney } from "@/hooks/use-can-see-money";
import { inventoryQtyStatus, statusSurfaceClass, statusToBadgeTone } from "@/lib/lcm/status-colors";
import { toast } from "sonner";

export type PartsStockPanelProps = {
  partForm: PartStock;
  setPartForm: React.Dispatch<React.SetStateAction<PartStock>>;
  editingPartId: string | null;
  setEditingPartId: (id: string | null) => void;
  partNumbers: string[];
  vendorOptions: string[];
  filteredParts: PartStock[];
  partUnits: PartUnit[];
  uinLookup: string;
  setUinLookup: (v: string) => void;
  uinHit: PartUnit | null;
  setUinHit: (u: PartUnit | null) => void;
  getPartUnitByUin: (uin: string) => PartUnit | undefined;
  issuePartUnit: (
    uin: string,
    opts?: { reason?: string },
  ) => { ok: boolean; error?: string };
  savePart: () => void;
  openMove: (
    itemKind: "material" | "part",
    itemId: string,
    label: string,
    kind: InventoryTxnType,
  ) => void;
  editPart: (p: PartStock) => void;
  setDeleteTarget: (t: { kind: "material" | "part"; id: string; label: string } | null) => void;
};

export function PartsStockPanel({
  partForm,
  setPartForm,
  editingPartId,
  setEditingPartId,
  partNumbers,
  vendorOptions,
  filteredParts,
  partUnits,
  uinLookup,
  setUinLookup,
  uinHit,
  setUinHit,
  getPartUnitByUin,
  issuePartUnit,
  savePart,
  openMove,
  editPart,
  setDeleteTarget,
}: PartsStockPanelProps) {
  const canSeeMoney = useCanSeeMoney();
  return (
  <>
    <Card>
      <CardHeader>
        <CardTitle>
          {editingPartId ? "Edit part / hardware" : "Add part / hardware"}
        </CardTitle>
        <CardDescription>
          Finished goods, WIP, bolts, inserts, bought-outs — anything that
          isn't raw bar/sheet.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          <div className="space-y-1.5">
            <Label>Part number</Label>
            <CreatableSelect
              value={partForm.partNumber}
              options={partNumbers}
              onChange={(v) =>
                setPartForm((f) => ({ ...f, partNumber: v }))
              }
              onCreate={(v) =>
                setPartForm((f) => ({ ...f, partNumber: v }))
              }
              createTitle="New part number"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Revision</Label>
            <Input
              value={partForm.revision}
              onChange={(e) =>
                setPartForm((f) => ({ ...f, revision: e.target.value }))
              }
            />
          </div>
          <div className="space-y-1.5">
            <Label>Category</Label>
            <Select
              value={partForm.category}
              onChange={(e) =>
                setPartForm((f) => ({ ...f, category: e.target.value }))
              }
            >
              {PART_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </Select>
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label>Description</Label>
            <Input
              value={partForm.description}
              onChange={(e) =>
                setPartForm((f) => ({
                  ...f,
                  description: e.target.value,
                }))
              }
            />
          </div>
          <div className="space-y-1.5">
            <Label>Unit</Label>
            <Select
              value={partForm.unit}
              onChange={(e) =>
                setPartForm((f) => ({
                  ...f,
                  unit: e.target.value as PartStock["unit"],
                }))
              }
            >
              {INVENTORY_UNITS.map((u) => (
                <option key={u} value={u}>
                  {u}
                </option>
              ))}
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>On hand</Label>
            <Input
              type="number"
              value={partForm.onHand}
              onChange={(e) =>
                setPartForm((f) => ({
                  ...f,
                  onHand: Number(e.target.value),
                }))
              }
            />
          </div>
          <div className="space-y-1.5">
            <Label>Min qty</Label>
            <Input
              type="number"
              value={partForm.minQty}
              onChange={(e) =>
                setPartForm((f) => ({
                  ...f,
                  minQty: Number(e.target.value),
                }))
              }
            />
          </div>
          <div className="space-y-1.5">
            <Label>Location</Label>
            <Input
              value={partForm.location}
              onChange={(e) =>
                setPartForm((f) => ({ ...f, location: e.target.value }))
              }
            />
          </div>
          <div className="space-y-1.5">
            <Label>Vendor</Label>
            <CreatableSelect
              allowEmpty
              emptyLabel="— Select vendor —"
              value={partForm.vendor || ""}
              options={vendorOptions}
              onChange={(v) =>
                setPartForm((f) => ({ ...f, vendor: v }))
              }
              onCreate={(v) => {
                setPartForm((f) => ({ ...f, vendor: v.trim() }));
                toast.success(`Vendor ${v.trim()} ready to save`);
                return true;
              }}
              createTitle="Add vendor"
              createHint="Who you buy this part / hardware from"
            />
          </div>
          {canSeeMoney && (
          <div className="space-y-1.5">
            <Label>Cost / unit</Label>
            <MoneyInput
              value={partForm.costPerUnit || 0}
              onValueChange={(n) =>
                setPartForm((f) => ({ ...f, costPerUnit: n }))
              }
            />
            <p className="text-[11px] text-[var(--color-subtle)] mt-1">
              Your cost for one unit (not sell price). Value = on hand ×
              this.
            </p>
          </div>
          )}
          <div className="space-y-1.5 sm:col-span-2 lg:col-span-3">
            <Label>Notes</Label>
            <Input
              value={partForm.notes}
              onChange={(e) =>
                setPartForm((f) => ({ ...f, notes: e.target.value }))
              }
            />
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button onClick={savePart}>
            <Plus className="h-4 w-4" />
            {editingPartId ? "Save part" : "Add part"}
          </Button>
          {editingPartId && (
            <Button
              variant="ghost"
              onClick={() => {
                setEditingPartId(null);
                setPartForm(emptyPart({ id: "" }));
              }}
            >
              Cancel edit
            </Button>
          )}
        </div>
      </CardContent>
    </Card>


    <Card>
      <CardHeader>
        <CardTitle className="text-base">Look up part by UIN (sharpie code)</CardTitle>
        <CardDescription>
          Read the short code written on the part, type it here to see defect
          notes and quality before you use or ship it.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-col sm:flex-row gap-2">
          <Input
            className="font-mono tracking-widest uppercase max-w-xs"
            placeholder="e.g. K7M2"
            value={uinLookup}
            onChange={(e) => {
              setUinLookup(e.target.value.toUpperCase());
              setUinHit(null);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                const hit = getPartUnitByUin(uinLookup);
                setUinHit(hit || null);
                if (!hit) toast.error("No part found for that UIN");
              }
            }}
          />
          <Button
            type="button"
            onClick={() => {
              const hit = getPartUnitByUin(uinLookup);
              setUinHit(hit || null);
              if (!hit) toast.error("No part found for that UIN");
            }}
          >
            Look up
          </Button>
        </div>
        {uinHit && (
          <div
            className={`rounded-[var(--radius-md)] border px-3 py-3 text-sm space-y-1 ${
              uinHit.quality === "second"
                ? "border-[var(--color-warn)] bg-[color-mix(in_oklab,var(--color-warn)_10%,transparent)]"
                : "border-[var(--color-border)] bg-[var(--color-surface-2)]"
            }`}
          >
            <div className="font-mono text-2xl font-bold tracking-[0.15em]">
              {uinHit.uin}
            </div>
            <div>
              <span className="font-medium">{uinHit.partNumber}</span>
              {uinHit.revision ? ` · Rev ${uinHit.revision}` : ""}
              {" · "}
              <Badge tone={uinHit.quality === "second" ? "warn" : "success"}>
                {uinHit.quality === "second" ? "Second quality" : "Good"}
              </Badge>
              {" · "}
              <span className="text-[var(--color-muted)]">{uinHit.status}</span>
            </div>
            {uinHit.defectNote ? (
              <p className="text-[var(--color-warn)]">
                <strong>Defect / note:</strong> {uinHit.defectNote}
              </p>
            ) : (
              <p className="text-[var(--color-muted)]">No defect note on file.</p>
            )}
            {uinHit.location ? (
              <p className="text-xs text-[var(--color-muted)]">
                Location: {uinHit.location}
              </p>
            ) : null}
            {uinHit.status === "available" && (
              <Button
                type="button"
                size="sm"
                variant="outline"
                className="mt-2"
                onClick={() => {
                  const r = issuePartUnit(uinHit.uin, {
                    reason: "Pulled from shelf",
                  });
                  if (!r.ok) toast.error(r.error);
                  else {
                    toast.success(`UIN ${uinHit.uin} marked issued`);
                    setUinHit({ ...uinHit, status: "issued" });
                  }
                }}
              >
                Mark issued / used
              </Button>
            )}
          </div>
        )}
        {partUnits.filter((u) => u.status === "available").length > 0 && (
          <div className="pt-2">
            <div className="text-xs font-semibold text-[var(--color-muted)] mb-1">
              Available UINs on shelf (
              {partUnits.filter((u) => u.status === "available").length})
            </div>
            <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto">
              {partUnits
                .filter((u) => u.status === "available")
                .slice(0, 40)
                .map((u) => (
                  <button
                    key={u.id}
                    type="button"
                    className={`font-mono text-xs px-2 py-1 rounded border min-h-9 ${
                      u.quality === "second"
                        ? "border-[var(--color-warn)]/60 text-[var(--color-warn)]"
                        : "border-[var(--color-border)]"
                    }`}
                    onClick={() => {
                      setUinLookup(u.uin);
                      setUinHit(u);
                    }}
                  >
                    {u.uin}
                  </button>
                ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>

    <Card>
      <CardHeader>
        <CardTitle>Parts on hand ({filteredParts.length})</CardTitle>
      </CardHeader>
      <CardContent className="overflow-x-auto">
        <table className="w-full text-sm min-w-[900px]">
          <thead>
            <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
              <th className="pb-2 font-medium">Part</th>
              <th className="pb-2 font-medium">Category</th>
              <th className="pb-2 font-medium">On hand</th>
              <th className="pb-2 font-medium">Min</th>
              <th className="pb-2 font-medium">Location</th>
              {canSeeMoney && <th className="pb-2 font-medium">Value</th>}
              <th className="pb-2 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredParts.map((p) => {
              const low = isLowStock(p.onHand, p.minQty);
              const qStatus = inventoryQtyStatus(p.onHand, p.minQty);
              return (
                <tr
                  key={p.id}
                  className="border-b border-[var(--color-border)]/60"
                >
                  <td className="py-2.5 pr-2">
                    <div className="font-medium">
                      {p.partNumber}
                      {p.revision ? (
                        <span className="text-[var(--color-muted)] font-normal">
                          {" "}
                          rev {p.revision}
                        </span>
                      ) : null}
                    </div>
                    <div className="text-xs text-[var(--color-muted)]">
                      {p.description || "—"}
                    </div>
                  </td>
                  <td className="py-2.5 pr-2 text-[var(--color-muted)]">
                    <div className="flex flex-wrap items-center gap-1">
                      {p.category}
                      {(p.category || "")
                        .toLowerCase()
                        .includes("second") ||
                      (p.category || "")
                        .toLowerCase()
                        .includes("blemish") ? (
                        <Badge tone="hold">Blemish</Badge>
                      ) : null}
                    </div>
                    {p.notes ? (
                      <div className="text-[11px] text-[var(--color-warn)] mt-0.5 max-w-[220px] whitespace-pre-wrap line-clamp-3">
                        {p.notes}
                      </div>
                    ) : null}
                  </td>
                  <td className="py-2.5 pr-2 tabular">
                    <span
                      className={
                        low ? "text-[var(--color-warn)] font-semibold" : ""
                      }
                    >
                      {p.onHand} {p.unit}
                    </span>
                    {qStatus === "danger" && (
                      <Badge tone="danger" className="ml-2">
                        Out
                      </Badge>
                    )}
                    {qStatus === "hold" && (
                      <Badge tone="hold" className="ml-2">
                        Low
                      </Badge>
                    )}
                  </td>
                  <td className="py-2.5 pr-2 tabular text-[var(--color-muted)]">
                    {p.minQty}
                  </td>
                  <td className="py-2.5 pr-2">{p.location || "—"}</td>
                  {canSeeMoney && (
                  <td className="py-2.5 pr-2 tabular">
                    <div>{formatCurrency(p.onHand * (p.costPerUnit || 0))}</div>
                    <div className="text-[10px] text-[var(--color-subtle)]">
                      {p.costPerUnit
                        ? `${formatCurrency(p.costPerUnit)}/${p.unit}`
                        : "no unit cost"}
                    </div>
                  </td>
                  )}
                  <td className="py-2.5">
                    <div className="flex flex-wrap gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          openMove("part", p.id, partLabel(p), "receive")
                        }
                      >
                        <ArrowDownToLine className="h-3.5 w-3.5" />
                        In
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          openMove("part", p.id, partLabel(p), "issue")
                        }
                      >
                        <ArrowUpFromLine className="h-3.5 w-3.5" />
                        Out
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() =>
                          openMove("part", p.id, partLabel(p), "adjust")
                        }
                      >
                        <SlidersHorizontal className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => editPart(p)}
                      >
                        Edit
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        aria-label="Delete part line"
                        title="Delete this stock line"
                        onClick={() =>
                          setDeleteTarget({
                            kind: "part",
                            id: p.id,
                            label: partLabel(p),
                          })
                        }
                      >
                        <Trash2 className="h-4 w-4 text-[var(--color-danger)]" />
                      </Button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {filteredParts.length === 0 && (
              <tr>
                <td
                  colSpan={7}
                  className="py-8 text-center text-[var(--color-muted)]"
                >
                  No parts inventory yet — add a line above.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </CardContent>
    </Card>
  </>
  );
}
