import { Link } from "@tanstack/react-router";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { computeOrderNeeds } from "@/lib/lcm/po";

export function OrderNeedsPanel({
  needs,
}: {
  needs: ReturnType<typeof computeOrderNeeds>;
}) {
  return (
  <Card>
    <CardHeader>
      <CardTitle>What to order</CardTitle>
      <CardDescription>
        Live: min stock + open shop orders + jobs − on hand − material buys. Add lines from
        Purchase Orders.
      </CardDescription>
    </CardHeader>
    <CardContent className="overflow-x-auto">
      <table className="w-full text-sm min-w-[640px]">
        <thead>
          <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
            <th className="pb-2 font-medium">Material</th>
            <th className="pb-2 font-medium">On hand</th>
            <th className="pb-2 font-medium">Min</th>
            <th className="pb-2 font-medium">Job demand</th>
            <th className="pb-2 font-medium">On order</th>
            <th className="pb-2 font-medium">Order</th>
          </tr>
        </thead>
        <tbody>
          {needs.map((n) => (
            <tr key={n.key} className="border-b border-[var(--color-border)]/60">
              <td className="py-2">
                <div className="font-medium">
                  {n.material} {n.materialType}
                </div>
                <div className="text-xs text-[var(--color-muted)]">
                  {n.stockShape} · {n.sources.slice(0, 3).join(", ")}
                </div>
              </td>
              <td className="py-2 tabular">{n.onHand}</td>
              <td className="py-2 tabular">{n.minQty}</td>
              <td className="py-2 tabular">{n.jobDemand}</td>
              <td className="py-2 tabular">{n.onOrder}</td>
              <td className="py-2 tabular font-semibold text-[var(--color-warn)]">
                {n.toOrder}
              </td>
            </tr>
          ))}
          {needs.length === 0 && (
            <tr>
              <td colSpan={6} className="py-8 text-center text-[var(--color-muted)]">
                Stock covers current demand.
              </td>
            </tr>
          )}
        </tbody>
      </table>
      <div className="mt-3">
        <Link to="/po" className="text-sm text-[var(--color-primary)] underline">
          Open Purchase Orders to buy
        </Link>
      </div>
    </CardContent>
  </Card>
  );
}
