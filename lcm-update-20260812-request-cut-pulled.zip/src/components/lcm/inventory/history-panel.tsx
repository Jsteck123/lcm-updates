import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { InventoryTxn } from "@/lib/lcm/types";
import { formatDate } from "@/lib/utils";

export function HistoryPanel({
  inventoryTxns,
}: {
  inventoryTxns: InventoryTxn[];
}) {
  return (
  <Card>
    <CardHeader>
      <CardTitle>Inventory history</CardTitle>
      <CardDescription>
        Receive, issue, adjust, scrap — last 500 moves (shared shop log).
      </CardDescription>
    </CardHeader>
    <CardContent className="overflow-x-auto">
      <table className="w-full text-sm min-w-[720px]">
        <thead>
          <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
            <th className="pb-2 font-medium">When</th>
            <th className="pb-2 font-medium">Kind</th>
            <th className="pb-2 font-medium">Item</th>
            <th className="pb-2 font-medium">Qty</th>
            <th className="pb-2 font-medium">Balance</th>
            <th className="pb-2 font-medium">By / note</th>
          </tr>
        </thead>
        <tbody>
          {inventoryTxns.map((t) => (
            <tr
              key={t.id}
              className="border-b border-[var(--color-border)]/60"
            >
              <td className="py-2 pr-2 whitespace-nowrap text-[var(--color-muted)]">
                {formatDate(t.at)}
              </td>
              <td className="py-2 pr-2 capitalize">
                {t.kind}{" "}
                <span className="text-[var(--color-muted)] text-xs">
                  {t.itemKind}
                </span>
              </td>
              <td className="py-2 pr-2">{t.label}</td>
              <td className="py-2 pr-2 tabular">{t.qty}</td>
              <td className="py-2 pr-2 tabular">{t.balanceAfter}</td>
              <td className="py-2 text-xs text-[var(--color-muted)]">
                {t.by}
                {t.reason ? ` · ${t.reason}` : ""}
                {t.ref ? ` · ${t.ref}` : ""}
              </td>
            </tr>
          ))}
          {inventoryTxns.length === 0 && (
            <tr>
              <td
                colSpan={6}
                className="py-8 text-center text-[var(--color-muted)]"
              >
                No inventory moves yet. Use In / Out on a stock line.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </CardContent>
  </Card>
  );
}
