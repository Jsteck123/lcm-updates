import { useMemo, useRef, useState } from "react";
import {
  ClipboardList,
  Download,
  Printer,
  Upload,
  FileSpreadsheet,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useLcmStore } from "@/store/lcm-store";
import {
  blankTemplateRows,
  buildCountApplyPlan,
  buildCountSheetRows,
  countRowsToCsv,
  downloadTextFile,
  parseMaterialCountCsv,
  printMaterialCountSheet,
  type CountApplyPlan,
  type MaterialCountRow,
} from "@/lib/lcm/material-count";
import { formatDateTime } from "@/lib/utils";

export function MaterialCountPanel() {
  const materialStock = useLcmStore((s) => s.materialStock || []);
  const companyName = useLcmStore((s) => s.settings.companyName || "Lake Country Machine");
  const applyMaterialCount = useLcmStore((s) => s.applyMaterialCount);
  const fileRef = useRef<HTMLInputElement>(null);
  const [paste, setPaste] = useState("");
  const [parsedRows, setParsedRows] = useState<MaterialCountRow[] | null>(null);
  const [plan, setPlan] = useState<CountApplyPlan | null>(null);
  const [parseErrors, setParseErrors] = useState<string[]>([]);

  const sheetRows = useMemo(
    () => buildCountSheetRows(materialStock),
    [materialStock],
  );

  function downloadCountSheet() {
    const csv = countRowsToCsv(sheetRows);
    const stamp = new Date().toISOString().slice(0, 10);
    downloadTextFile(`lcm-material-count-${stamp}.csv`, csv);
    toast.success(
      `Downloaded ${sheetRows.length} lines — fill counted_qty on the floor, then upload`,
    );
  }

  function downloadBlank() {
    downloadTextFile(
      "lcm-material-count-blank-template.csv",
      countRowsToCsv(blankTemplateRows()),
    );
    toast.success("Blank template downloaded (for new items / first inventory)");
  }

  function handlePrint() {
    const ok = printMaterialCountSheet(materialStock, {
      company: companyName,
      title: "Material floor count",
    });
    if (!ok) toast.error("Allow pop-ups to print the count sheet");
    else toast.message("Print dialog opened — landscape works best");
  }

  function runParse(text: string) {
    const { rows, errors } = parseMaterialCountCsv(text);
    setParseErrors(errors);
    setParsedRows(rows);
    if (!rows.length) {
      setPlan(null);
      toast.error(errors[0] || "No data rows found");
      return;
    }
    const p = buildCountApplyPlan(rows, materialStock);
    setPlan(p);
    toast.success(
      `Parsed ${rows.length} rows · ${p.adjustCount} changes · ${p.createCount} new · ${p.skipCount} skip`,
    );
  }

  async function onFile(file: File | null) {
    if (!file) return;
    const text = await file.text();
    runParse(text);
  }

  function applyPlan() {
    if (!plan) return;
    if (plan.errorCount > 0) {
      toast.error(`Fix ${plan.errorCount} error(s) first`);
      return;
    }
    if (plan.adjustCount + plan.createCount === 0) {
      toast.message("Nothing to apply — all rows blank or already match");
      return;
    }
    const r = applyMaterialCount(plan);
    if (!r.ok) {
      toast.error(r.error || "Apply failed");
      return;
    }
    toast.success(
      `Floor count applied · ${r.adjusted} adjusted · ${r.created} new items`,
    );
    setPlan(null);
    setParsedRows(null);
    setPaste("");
    if (fileRef.current) fileRef.current.value = "";
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ClipboardList className="h-5 w-5" />
            Material floor count
          </CardTitle>
          <CardDescription>
            Print or download what the system thinks you have. Floor writes actual
            qty (and lengths). Upload the filled sheet — the app adjusts stock and
            logs history. Reuse anytime for cycle counts.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <ol className="text-sm text-[var(--color-muted)] space-y-1.5 list-decimal pl-5 leading-relaxed">
            <li>
              <strong className="text-[var(--color-fg)]">Office:</strong> Print
              the clipboard sheet or download the CSV (system qty filled, actual
              blank).
            </li>
            <li>
              <strong className="text-[var(--color-fg)]">Floor:</strong> Walk
              racks. Write actual qty in the unit shown. Note shorter bars under
              size/length.
            </li>
            <li>
              <strong className="text-[var(--color-fg)]">Office:</strong> Type
              actuals into the CSV (or scan/OCR into the same columns) → Upload →
              Review → Apply.
            </li>
          </ol>

          <div className="flex flex-wrap gap-2">
            <Button type="button" onClick={handlePrint}>
              <Printer className="h-4 w-4" /> Print count sheet
            </Button>
            <Button type="button" variant="secondary" onClick={downloadCountSheet}>
              <Download className="h-4 w-4" /> Download count CSV
              <span className="text-xs opacity-80 ml-1">({sheetRows.length})</span>
            </Button>
            <Button type="button" variant="outline" onClick={downloadBlank}>
              <FileSpreadsheet className="h-4 w-4" /> Blank template
            </Button>
          </div>

          <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 text-xs text-[var(--color-muted)] leading-relaxed">
            <strong className="text-[var(--color-fg)]">CSV columns:</strong>{" "}
            <code className="text-[10px]">
              stock_id, material, material_type, stock_shape, size_note, location,
              unit, system_qty, counted_qty, counted_size_note, count_notes
            </code>
            . Leave <code className="text-[10px]">counted_qty</code> blank to skip
            a line. Empty <code className="text-[10px]">stock_id</code> + filled
            material + counted qty = add a new stock item. Never change{" "}
            <code className="text-[10px]">stock_id</code> on existing lines.
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Upload className="h-4 w-4" /> Upload counted sheet
          </CardTitle>
          <CardDescription>
            Same template after the floor fills <strong>counted_qty</strong>.
            Preview changes before anything is written.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <input
            ref={fileRef}
            type="file"
            accept=".csv,text/csv,text/plain"
            className="block w-full text-sm file:mr-3 file:rounded-md file:border-0 file:bg-[var(--color-primary)] file:text-[var(--color-primary-fg)] file:px-3 file:py-2 file:text-sm"
            onChange={(e) => void onFile(e.target.files?.[0] || null)}
          />
          <div className="space-y-1.5">
            <div className="text-xs font-medium text-[var(--color-muted)]">
              Or paste CSV
            </div>
            <textarea
              className="w-full min-h-28 rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface)] px-3 py-2 text-xs font-mono"
              placeholder="Paste spreadsheet export here…"
              value={paste}
              onChange={(e) => setPaste(e.target.value)}
            />
            <Button
              type="button"
              size="sm"
              variant="secondary"
              disabled={!paste.trim()}
              onClick={() => runParse(paste)}
            >
              Parse paste
            </Button>
          </div>

          {parseErrors.length > 0 && (
            <div className="text-sm text-[var(--color-danger)] space-y-1">
              {parseErrors.map((e) => (
                <div key={e}>{e}</div>
              ))}
            </div>
          )}

          {plan && (
            <div className="space-y-3 border-t border-[var(--color-border)] pt-3">
              <div className="flex flex-wrap gap-2 text-sm">
                <span className="rounded-full border border-[var(--color-border)] px-2.5 py-1">
                  {plan.adjustCount} qty change
                  {plan.adjustCount === 1 ? "" : "s"}
                </span>
                <span className="rounded-full border border-[var(--color-border)] px-2.5 py-1">
                  {plan.createCount} new
                </span>
                <span className="rounded-full border border-[var(--color-border)] px-2.5 py-1 text-[var(--color-muted)]">
                  {plan.skipCount} skip
                </span>
                {plan.errorCount > 0 && (
                  <span className="rounded-full border border-[var(--color-danger)] px-2.5 py-1 text-[var(--color-danger)]">
                    {plan.errorCount} error
                    {plan.errorCount === 1 ? "" : "s"}
                  </span>
                )}
              </div>

              <div className="overflow-x-auto max-h-80 overflow-y-auto">
                <table className="w-full text-xs sm:text-sm min-w-[640px]">
                  <thead>
                    <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
                      <th className="pb-1.5 font-medium">Action</th>
                      <th className="pb-1.5 font-medium">Item</th>
                      <th className="pb-1.5 font-medium text-right">From</th>
                      <th className="pb-1.5 font-medium text-right">To</th>
                      <th className="pb-1.5 font-medium">Detail</th>
                    </tr>
                  </thead>
                  <tbody>
                    {plan.actions.map((a, i) => {
                      if (a.kind === "adjust") {
                        return (
                          <tr
                            key={`a-${i}`}
                            className="border-b border-[var(--color-border)]/70"
                          >
                            <td className="py-1.5 pr-2 font-medium text-[var(--color-primary)]">
                              Adjust
                            </td>
                            <td className="py-1.5 pr-2">{a.label}</td>
                            <td className="py-1.5 pr-2 text-right tabular">
                              {a.fromQty}
                            </td>
                            <td className="py-1.5 pr-2 text-right tabular font-semibold">
                              {a.toQty}
                              <span className="text-[var(--color-muted)] font-normal ml-1">
                                ({a.delta >= 0 ? "+" : ""}
                                {a.delta})
                              </span>
                            </td>
                            <td className="py-1.5 text-[var(--color-muted)]">
                              {a.sizeNote ? `Size → ${a.sizeNote}. ` : ""}
                              {a.notes}
                            </td>
                          </tr>
                        );
                      }
                      if (a.kind === "create") {
                        return (
                          <tr
                            key={`c-${i}`}
                            className="border-b border-[var(--color-border)]/70"
                          >
                            <td className="py-1.5 pr-2 font-medium text-[var(--color-success)]">
                              New
                            </td>
                            <td className="py-1.5 pr-2">{a.label}</td>
                            <td className="py-1.5 pr-2 text-right tabular">—</td>
                            <td className="py-1.5 pr-2 text-right tabular font-semibold">
                              {a.toQty}
                            </td>
                            <td className="py-1.5 text-[var(--color-muted)]">
                              {a.location || "no loc"} · {a.unit}
                            </td>
                          </tr>
                        );
                      }
                      return (
                        <tr
                          key={`s-${i}`}
                          className="border-b border-[var(--color-border)]/40 text-[var(--color-muted)]"
                        >
                          <td className="py-1.5 pr-2">
                            {a.kind === "error" ? "Error" : "Skip"}
                          </td>
                          <td className="py-1.5 pr-2">{a.label}</td>
                          <td className="py-1.5 pr-2 text-right">—</td>
                          <td className="py-1.5 pr-2 text-right">—</td>
                          <td className="py-1.5">
                            L{a.lineNo}: {a.reason}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div className="flex flex-wrap gap-2">
                <Button
                  type="button"
                  onClick={applyPlan}
                  disabled={
                    plan.errorCount > 0 ||
                    plan.adjustCount + plan.createCount === 0
                  }
                >
                  Apply floor count
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => {
                    setPlan(null);
                    setParsedRows(null);
                  }}
                >
                  Clear preview
                </Button>
              </div>
              {parsedRows && (
                <p className="text-[11px] text-[var(--color-subtle)]">
                  Preview built {formatDateTime(new Date().toISOString())} ·{" "}
                  {parsedRows.length} data rows · applying sets absolute on-hand
                  (adjust) and writes inventory history.
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
