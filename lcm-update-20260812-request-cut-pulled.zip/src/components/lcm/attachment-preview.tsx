import { useEffect, useState } from "react";
import { X, Download, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  closeAttachmentPreview,
  subscribeAttachmentPreview,
  type PreviewPayload,
} from "@/lib/lcm/attachment-preview-bus";

type Props = {
  open: boolean;
  url: string | null;
  mime: string;
  name: string;
  onClose: () => void;
};

/**
 * In-app attachment viewer — fits image/PDF to the screen.
 * Close returns to the app; never replaces the main window.
 */
export function AttachmentPreview({ open, url, mime, name, onClose }: Props) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open || !url) return null;

  const isImage = /^image\//i.test(mime);
  const isPdf =
    /pdf/i.test(mime) || /\.pdf$/i.test(name) || mime === "application/pdf";

  function download() {
    const a = document.createElement("a");
    a.href = url!;
    a.download = name || "attachment";
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  function openPopup() {
    const w = Math.min(960, Math.floor(window.screen.availWidth * 0.7));
    const h = Math.min(720, Math.floor(window.screen.availHeight * 0.75));
    const left = Math.max(0, Math.floor((window.screen.availWidth - w) / 2));
    const top = Math.max(0, Math.floor((window.screen.availHeight - h) / 2));
    window.open(
      url!,
      "lcm-attachment",
      `popup=yes,width=${w},height=${h},left=${left},top=${top},resizable=yes,scrollbars=yes`,
    );
  }

  return (
    <div
      className="fixed inset-0 z-[80] flex items-center justify-center bg-black/80 p-3 sm:p-6 print:hidden"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Attachment preview"
    >
      <div
        className="relative flex flex-col w-full max-w-4xl max-h-[90vh] rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2 px-3 py-2.5 border-b border-[var(--color-border)] bg-[var(--color-surface-2)] shrink-0">
          <div className="min-w-0 flex-1">
            <div className="text-sm font-semibold truncate">
              {name || "Attachment"}
            </div>
            <div className="text-[10px] text-[var(--color-muted)]">
              Fits on screen · Esc or Close to go back
            </div>
          </div>
          <Button
            type="button"
            size="sm"
            variant="outline"
            className="shrink-0 h-9"
            onClick={download}
            title="Download"
          >
            <Download className="h-4 w-4" />
            <span className="hidden sm:inline">Download</span>
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            className="shrink-0 h-9"
            onClick={openPopup}
            title="Open in small window"
          >
            <ExternalLink className="h-4 w-4" />
            <span className="hidden sm:inline">Window</span>
          </Button>
          <Button
            type="button"
            size="sm"
            className="shrink-0 h-9 min-w-[5.5rem]"
            onClick={onClose}
          >
            <X className="h-4 w-4" />
            Close
          </Button>
        </div>

        <div className="flex-1 min-h-0 overflow-auto flex items-center justify-center bg-[var(--color-bg)] p-2 sm:p-4">
          {isImage ? (
            <img
              src={url}
              alt={name}
              className="max-w-full max-h-[min(75vh,720px)] w-auto h-auto object-contain rounded-md"
            />
          ) : isPdf ? (
            <iframe
              title={name}
              src={url}
              className="w-full h-[min(75vh,720px)] min-h-[50vh] rounded-md bg-white"
            />
          ) : (
            <div className="text-center p-8 space-y-3 text-sm text-[var(--color-muted)]">
              <p>Preview not available for this file type.</p>
              <div className="flex justify-center gap-2">
                <Button type="button" onClick={download}>
                  Download {name}
                </Button>
                <Button type="button" variant="outline" onClick={openPopup}>
                  Open in window
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/** Mount once in AppShell — serves PO, chat, board, etc. */
export function GlobalAttachmentPreview() {
  const [payload, setPayload] = useState<PreviewPayload | null>(null);
  useEffect(() => subscribeAttachmentPreview(setPayload), []);
  return (
    <AttachmentPreview
      open={Boolean(payload)}
      url={payload?.url || null}
      mime={payload?.mime || ""}
      name={payload?.name || ""}
      onClose={closeAttachmentPreview}
    />
  );
}
