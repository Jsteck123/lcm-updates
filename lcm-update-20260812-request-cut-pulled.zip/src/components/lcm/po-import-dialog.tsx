import { useEffect, useMemo, useRef, useState } from "react";
import { FileUp, Loader2, Eraser, Paperclip, GripVertical } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import {
  classifyPackageFile,
  extractTextFromPdf,
  fileToBase64,
  matchFilesToParts,
  mergeParsedPos,
  parsePoText,
  scoreAsPurchaseOrder,
  type ParsedPo,
} from "@/lib/lcm/po-import";
import {
  matchFileToAssemblyLine,
  normalizeLineFiles,
  promoteRelatedFilesToComponents,
} from "@/lib/lcm/line-files";
import type { LineFileRef } from "@/lib/lcm/types";
import { savePoAttachment } from "@/lib/lcm/po-files-api";
import { getShopToken } from "@/lib/lcm/shop-sync";
import { useLcmStore } from "@/store/lcm-store";
import { emptyShopOrderLine } from "@/lib/lcm/po";
import { uid } from "@/lib/utils";
import { formatCurrency } from "@/lib/utils";
import {
  applyPoRevise,
  buildPoRevisePlan,
  findOrderForPoRevise,
  nextPoRevision,
  type PoRevisePlan,
} from "@/lib/lcm/po-revise";
import { enrichShopOrderLines } from "@/lib/lcm/po-material";

type FileMeta = { id: string; name: string; mime: string };

type Props = {
  open: boolean;
  onClose: () => void;
  onCreated: (orderId: string) => void;
  canSeePrices: boolean;
};

/**
 * One drop: PO + drawings + CAD together.
 * PO is picked by filename (PO-26-…, Purchase Order…) then by PDF text if needed.
 */
export function PoImportDialog({
  open,
  onClose,
  onCreated,
  canSeePrices,
}: Props) {
  const createShopOrder = useLcmStore((s) => s.createShopOrder);
  const upsertShopOrder = useLcmStore((s) => s.upsertShopOrder);
  const addCustomerQuick = useLcmStore((s) => s.addCustomerQuick);
  const addAudit = useLcmStore((s) => s.addAudit);
  const shopOrders = useLcmStore((s) => s.shopOrders);
  const currentUserEmail = useLcmStore((s) => s.currentUserEmail);

  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("");
  const [parsed, setParsed] = useState<ParsedPo | null>(null);
  const [sourceMeta, setSourceMeta] = useState<FileMeta | null>(null);
  /** Multiple drawings/CAD per line P/N (assemblies). */
  const [drawingMap, setDrawingMap] = useState<Record<string, LineFileRef[]>>(
    {},
  );
  const [cadMap, setCadMap] = useState<Record<string, LineFileRef[]>>({});
  const [unmatched, setUnmatched] = useState<
    { meta: FileMeta; kind: string }[]
  >([]);
  const [packageNote, setPackageNote] = useState("");
  const [confirmReady, setConfirmReady] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  /** Highlight line row while dragging an unmatched file onto it */
  const [dropLineKey, setDropLineKey] = useState<string | null>(null);
  /** When same PO # exists: revise (default) vs force create new */
  const [forceCreateNew, setForceCreateNew] = useState(false);
  const [showReviseDiff, setShowReviseDiff] = useState(false);
  const [proposedPoRev, setProposedPoRev] = useState("");
  const [allowBlockedCancels, setAllowBlockedCancels] = useState(false);
  const allFileRef = useRef<HTMLInputElement>(null);

  const lineCount = parsed?.lines.length || 0;

  const existingOrder = useMemo(() => {
    if (!parsed?.poNumber || forceCreateNew) return null;
    return findOrderForPoRevise(shopOrders || [], parsed.poNumber);
  }, [parsed?.poNumber, shopOrders, forceCreateNew]);

  const revisePlan: PoRevisePlan | null = useMemo(() => {
    if (!existingOrder || !parsed || parsed.looksLikeDrawing) return null;
    return buildPoRevisePlan(existingOrder, parsed, proposedPoRev || undefined);
  }, [existingOrder, parsed, proposedPoRev]);

  // Default proposed rev when a match appears
  useEffect(() => {
    if (existingOrder && !proposedPoRev) {
      setProposedPoRev(nextPoRevision(existingOrder.poRevision || ""));
    }
    if (!existingOrder) {
      setProposedPoRev("");
      setShowReviseDiff(false);
      setAllowBlockedCancels(false);
    }
  }, [existingOrder?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  function clearImportForm(opts?: { quiet?: boolean }) {
    setBusy(false);
    setStatus("");
    setParsed(null);
    setSourceMeta(null);
    setDrawingMap({});
    setCadMap({});
    setUnmatched([]);
    setPackageNote("");
    setConfirmReady(false);
    setDragOver(false);
    setDropLineKey(null);
    setForceCreateNew(false);
    setShowReviseDiff(false);
    setProposedPoRev("");
    setAllowBlockedCancels(false);
    if (allFileRef.current) allFileRef.current.value = "";
    if (!opts?.quiet) toast.message("Import form cleared — ready for a new package");
  }

  useEffect(() => {
    if (open) clearImportForm({ quiet: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  async function uploadFile(file: File): Promise<FileMeta | null> {
    const mime = file.type || "application/octet-stream";
    const b64 = await fileToBase64(file);
    const saved = await savePoAttachment({
      data: {
        name: file.name,
        mime,
        base64: b64,
        token: getShopToken() || undefined,
      },
    });
    if (!saved.ok) {
      toast.error(saved.error || `Could not save ${file.name}`);
      return null;
    }
    return {
      id: saved.meta.id,
      name: saved.meta.name,
      mime: saved.meta.mime,
    };
  }

  async function readTextFromFile(file: File): Promise<string> {
    const mime = file.type || "";
    const lower = file.name.toLowerCase();
    if (mime.includes("pdf") || lower.endsWith(".pdf")) {
      const buf = await file.arrayBuffer();
      return extractTextFromPdf(buf);
    }
    if (mime.startsWith("text/") || lower.endsWith(".txt")) {
      return file.text();
    }
    return "";
  }

  /**
   * Drop everything at once: find PO, parse lines, attach drawings/CAD by P/N.
   */
  async function handleAllFiles(fileList: FileList | File[]) {
    const files = Array.from(fileList || []);
    if (!files.length) return;

    setParsed(null);
    setSourceMeta(null);
    setDrawingMap({});
    setCadMap({});
    setUnmatched([]);
    setPackageNote("");
    setConfirmReady(false);
    setBusy(true);
    setStatus(`Sorting ${files.length} file(s)…`);

    try {
      // Initial classify by name/extension
      type Slot = {
        file: File;
        kind: ReturnType<typeof classifyPackageFile>;
        meta?: FileMeta;
        text?: string;
        parsed?: ParsedPo;
        poScore?: number;
      };
      const slots: Slot[] = files.map((file) => ({
        file,
        kind: classifyPackageFile(file.name, file.type || ""),
      }));

      // Upload all first (host storage)
      for (let i = 0; i < slots.length; i++) {
        const s = slots[i]!;
        setStatus(`Saving ${i + 1}/${slots.length}: ${s.file.name}…`);
        const meta = await uploadFile(s.file);
        if (meta) s.meta = meta;
      }

      // Candidate PO PDFs: name says PO, or every PDF if none named PO
      const pdfSlots = slots.filter(
        (s) =>
          s.meta &&
          (s.kind === "po" ||
            s.file.name.toLowerCase().endsWith(".pdf") ||
            (s.file.type || "").includes("pdf") ||
            s.kind === "unknown"),
      );
      const namedPo = slots.filter((s) => s.kind === "po" && s.meta);
      const toScan =
        namedPo.length > 0
          ? namedPo
          : pdfSlots.filter(
              (s) =>
                s.file.name.toLowerCase().endsWith(".pdf") ||
                (s.file.type || "").includes("pdf") ||
                s.file.name.toLowerCase().endsWith(".txt"),
            );

      // Parse text for PO candidates
      for (const s of toScan) {
        setStatus(`Reading ${s.file.name} for line items…`);
        try {
          const text = await readTextFromFile(s.file);
          s.text = text;
          if (text.trim()) {
            const p = parsePoText(text, s.file.name);
            s.parsed = p;
            s.poScore = scoreAsPurchaseOrder(s.file.name, p);
          } else {
            s.poScore = scoreAsPurchaseOrder(s.file.name, {
              lines: [],
              looksLikeDrawing: false,
            });
          }
        } catch {
          s.poScore = s.kind === "po" ? 10 : -10;
        }
      }

      // Pick best PO document
      const ranked = [...toScan]
        .filter((s) => s.meta)
        .sort((a, b) => (b.poScore || 0) - (a.poScore || 0));
      let poSlot = ranked.find(
        (s) =>
          (s.poScore || 0) > 20 &&
          s.parsed &&
          !s.parsed.looksLikeDrawing &&
          (s.parsed.lines.length > 0 || s.parsed.poNumber),
      );
      // Fallback: best score even if thin
      if (!poSlot && ranked[0] && (ranked[0].poScore || 0) >= 40) {
        poSlot = ranked[0];
      }
      // Fallback: any named PO file
      if (!poSlot) {
        poSlot = namedPo.find((s) => s.meta);
      }

      // If multiple PO-like pages as separate PDFs, merge their parses
      const poLike = ranked.filter(
        (s) =>
          s.parsed &&
          !s.parsed.looksLikeDrawing &&
          (s.parsed.lines.length > 0 || s.kind === "po") &&
          (s.poScore || 0) >= 25,
      );

      let finalParsed: ParsedPo | null = null;
      let firstSource: FileMeta | null = null;

      if (poLike.length > 1) {
        const parts = poLike.map((s) => s.parsed!).filter(Boolean);
        finalParsed = mergeParsedPos(parts);
        firstSource = poLike[0]!.meta || null;
        // Mark these as PO so they aren't also drawings
        for (const s of poLike) s.kind = "po";
      } else if (poSlot?.parsed) {
        finalParsed = poSlot.parsed;
        firstSource = poSlot.meta || null;
        poSlot.kind = "po";
      } else if (poSlot?.meta) {
        firstSource = poSlot.meta;
        poSlot.kind = "po";
        finalParsed = {
          poNumber: "",
          customer: "",
          customerAddress: "",
          customerPhone: "",
          shipToName: "",
          shipToAddress: "",
          attn: "",
          buyer: "",
          techContact: "",
          dateRequired: "",
          fob: "Origin",
          shippingMethod: "",
          terms: "N30",
          date: new Date().toISOString().slice(0, 10),
          rating: "",
          lines: [],
          rawPreview: "",
          warnings: [
            "PO file saved but no line items found — check PDF or fill lines manually.",
          ],
          looksLikeDrawing: false,
        };
      }

      if (!finalParsed) {
        // No PO found — still attach drawings/CAD if any CAD-only package
        toast.error(
          "Could not spot a Purchase Order in that batch. Include a file named like PO-26-XXXX.pdf, or drop the PO by itself.",
        );
        setStatus("No PO recognized — rename PO file or try again");
        // Still process non-PO as package for later? skip without lines
        setBusy(false);
        return;
      }

      setSourceMeta(firstSource);
      setParsed(finalParsed);

      // Everything that is not the PO document(s) → drawing or CAD
      const poIds = new Set(
        (poLike.length > 1 ? poLike : poSlot ? [poSlot] : [])
          .map((s) => s.meta?.id)
          .filter(Boolean) as string[],
      );

      const drawingUploads: FileMeta[] = [];
      const cadUploads: FileMeta[] = [];
      for (const s of slots) {
        if (!s.meta) continue;
        if (poIds.has(s.meta.id)) continue;
        const kind =
          s.kind === "po"
            ? "drawing" // extra PDF that lost PO contest
            : s.kind === "unknown"
              ? classifyPackageFile(s.file.name, s.file.type || "")
              : s.kind;
        if (kind === "cad") cadUploads.push(s.meta);
        else drawingUploads.push(s.meta); // drawing + leftover pdfs
      }

      const parts = finalParsed.lines.map((l) => l.partNumber);
      const nextDraw: Record<string, LineFileRef[]> = {};
      const nextCad: Record<string, LineFileRef[]> = {};
      const used = new Set<string>([...poIds]);

      function pushFile(
        kind: "drawing" | "cad",
        pn: string,
        meta: FileMeta,
        relatedPartNumber?: string,
      ) {
        const key = pn.toUpperCase();
        const ref: LineFileRef = {
          id: meta.id,
          name: meta.name,
          mime: meta.mime || "",
        };
        if (relatedPartNumber && relatedPartNumber.toUpperCase() !== key) {
          ref.relatedPartNumber = relatedPartNumber.toUpperCase();
        }
        const bag = kind === "cad" ? nextCad : nextDraw;
        const list = bag[key] ? [...bag[key]!] : [];
        if (!list.some((f) => f.id === ref.id)) list.push(ref);
        bag[key] = list;
        used.add(meta.id);
      }

      // 1) Exact P/N match (may still be one file per part from matchFilesToParts)
      const drawExact = matchFilesToParts(parts, drawingUploads);
      const cadExact = matchFilesToParts(parts, cadUploads);
      for (const [pn, f] of Object.entries(drawExact)) {
        if (f.id) pushFile("drawing", pn, { id: f.id, name: f.name, mime: f.mime || "" }, pn);
      }
      for (const [pn, f] of Object.entries(cadExact)) {
        if (f.id) pushFile("cad", pn, { id: f.id, name: f.name, mime: f.mime || "" }, pn);
      }

      // 2) Related assembly files: -02/-03 drawings/CAD hang on parent -01 line
      for (const meta of [...drawingUploads, ...cadUploads]) {
        if (used.has(meta.id)) continue;
        const hit = matchFileToAssemblyLine(parts, meta.name);
        if (!hit) continue;
        const kind =
          classifyPackageFile(meta.name, meta.mime) === "cad"
            ? "cad"
            : "drawing";
        // Prefer CAD list if extension is CAD even if in drawingUploads
        const isCad =
          kind === "cad" ||
          cadUploads.some((c) => c.id === meta.id);
        pushFile(
          isCad ? "cad" : "drawing",
          hit.partNumber,
          meta,
          hit.relatedPartNumber,
        );
      }

      const left: { meta: FileMeta; kind: string }[] = [];
      for (const s of slots) {
        if (!s.meta || used.has(s.meta.id)) continue;
        left.push({
          meta: s.meta,
          kind: s.kind === "cad" ? "cad" : "drawing",
        });
      }

      setDrawingMap(nextDraw);
      setCadMap(nextCad);
      setUnmatched(left);

      const dN = Object.values(nextDraw).reduce((n, a) => n + a.length, 0);
      const cN = Object.values(nextCad).reduce((n, a) => n + a.length, 0);
      const note =
        `PO: ${firstSource?.name || "—"} · ${finalParsed.lines.length} line(s)` +
        ` · ${dN} drawing · ${cN} CAD matched` +
        (left.length ? ` · ${left.length} unmatched` : "");
      setPackageNote(note);
      setStatus(note);

      toast.success(
        `Found PO${finalParsed.poNumber ? ` ${finalParsed.poNumber}` : ""} · ${finalParsed.lines.length} lines · ${dN} drawing · ${cN} CAD`,
      );
      if (left.length) {
        toast.message(
          `${left.length} file(s) not matched by P/N — attach on the order later or rename to include the part #`,
        );
      }
      if (finalParsed.warnings[0]) toast.message(finalParsed.warnings[0]);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Import failed");
      setStatus("Failed");
    } finally {
      setBusy(false);
    }
  }

  function updateParsed(patch: Partial<ParsedPo>) {
    if (!parsed) return;
    setParsed({ ...parsed, ...patch });
  }

  function updateLine(idx: number, patch: Partial<ParsedPo["lines"][0]>) {
    if (!parsed) return;
    const lines = parsed.lines.map((l, i) =>
      i === idx ? { ...l, ...patch } : l,
    );
    setParsed({ ...parsed, lines });
  }

  function resolveAttachKind(
    preferred: string,
    fileName: string,
    mime: string,
  ): "drawing" | "cad" {
    if (preferred === "cad" || preferred === "drawing") return preferred;
    const k = classifyPackageFile(fileName, mime);
    return k === "cad" ? "cad" : "drawing";
  }

  /**
   * Attach unmatched file to a line — always ADDS (assemblies need multiple files).
   * Never silently removes existing drawings/CAD.
   */
  function assignUnmatchedToLine(
    fileId: string,
    partNumber: string,
    asKind?: "drawing" | "cad" | "auto",
  ) {
    const pn = (partNumber || "").toUpperCase().trim();
    if (!pn) {
      toast.error("Pick a line / part number");
      return;
    }
    const item = unmatched.find((u) => u.meta.id === fileId);
    if (!item) {
      toast.error("File already assigned or missing");
      return;
    }

    const natural = resolveAttachKind(
      item.kind,
      item.meta.name,
      item.meta.mime,
    );
    const kind: "drawing" | "cad" =
      asKind === "drawing" || asKind === "cad" ? asKind : natural;

    const rel =
      matchFileToAssemblyLine([pn], item.meta.name)?.relatedPartNumber || "";
    const ref: LineFileRef = {
      id: item.meta.id,
      name: item.meta.name,
      mime: item.meta.mime || "",
    };
    if (rel && rel !== pn) ref.relatedPartNumber = rel;

    if (kind === "cad") {
      setCadMap((m) => {
        const list = m[pn] ? [...m[pn]!] : [];
        if (!list.some((f) => f.id === ref.id)) list.push(ref);
        return { ...m, [pn]: list };
      });
    } else {
      setDrawingMap((m) => {
        const list = m[pn] ? [...m[pn]!] : [];
        if (!list.some((f) => f.id === ref.id)) list.push(ref);
        return { ...m, [pn]: list };
      });
    }
    setUnmatched((list) => list.filter((u) => u.meta.id !== fileId));
    toast.success(
      `Added ${kind === "cad" ? "CAD" : "drawing"} to ${pn}` +
        (rel && rel !== pn ? ` (file for ${rel})` : "") +
        ` · ${item.meta.name}`,
    );
  }

  function onUnmatchedDragStart(
    e: React.DragEvent,
    fileId: string,
    kind: string,
  ) {
    e.dataTransfer.setData(
      "application/x-lcm-unmatched",
      JSON.stringify({ id: fileId, kind }),
    );
    e.dataTransfer.setData("text/plain", JSON.stringify({ id: fileId, kind }));
    e.dataTransfer.effectAllowed = "move";
  }

  function hasUnmatchedDrag(e: React.DragEvent) {
    const types = [...e.dataTransfer.types];
    return (
      types.includes("application/x-lcm-unmatched") ||
      types.includes("text/plain")
    );
  }

  function onLineDragOver(e: React.DragEvent, partNumber: string) {
    if (!hasUnmatchedDrag(e)) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    setDropLineKey(partNumber.toUpperCase());
  }

  function parseUnmatchedPayload(e: React.DragEvent): {
    id?: string;
    kind?: string;
  } | null {
    let payload = e.dataTransfer.getData("application/x-lcm-unmatched");
    if (!payload) payload = e.dataTransfer.getData("text/plain");
    if (!payload) return null;
    try {
      return JSON.parse(payload) as { id?: string; kind?: string };
    } catch {
      return null;
    }
  }

  function onLineDrop(
    e: React.DragEvent,
    partNumber: string,
    forceKind?: "drawing" | "cad" | "auto",
  ) {
    e.preventDefault();
    e.stopPropagation();
    setDropLineKey(null);
    const data = parseUnmatchedPayload(e);
    if (!data?.id) return;
    const prefer =
      forceKind ||
      (data.kind === "cad" || data.kind === "drawing" ? data.kind : "auto");
    assignUnmatchedToLine(data.id, partNumber, prefer);
  }

  function applyRevision() {
    if (!parsed || !existingOrder || !revisePlan) {
      toast.error("Nothing to revise");
      return;
    }
    if (revisePlan.summary.blockedRemoves > 0 && !allowBlockedCancels) {
      toast.error(
        "Some dropped lines have shop work — check the box to cancel them, or keep them",
      );
      setShowReviseDiff(true);
      return;
    }
    if (parsed.customer) addCustomerQuick(parsed.customer);

    const { order: merged, auditSummary, warnings } = applyPoRevise({
      existing: existingOrder,
      plan: revisePlan,
      parsed,
      poRevision: proposedPoRev || revisePlan.proposedPoRevision,
      sourceMeta,
      drawingMap,
      cadMap,
      allowBlockedCancels,
    });

    const st = useLcmStore.getState();
    const lines = enrichShopOrderLines(
      merged.lines || [],
      st.quotes || [],
      st.materialStock || [],
      st.partStock || [],
      {
        preserveReviewed: true,
        recomputeNeed: true,
        shopOrders: st.shopOrders || [],
      },
    );
    upsertShopOrder({ ...merged, lines });
    addAudit(
      currentUserEmail || "office",
      "PO revise",
      auditSummary,
    );
    for (const w of warnings) toast.message(w);
    toast.success(
      `Revised ${merged.poNumber || "PO"} → document rev ${merged.poRevision || "—"} · ${revisePlan.summary.changed} changed · ${revisePlan.summary.added} added · ${revisePlan.summary.removed} dropped`,
    );
    onCreated(merged.id);
    clearImportForm({ quiet: true });
    onClose();
  }

  function createOrder() {
    if (!parsed) {
      toast.error("Drop the customer package first");
      return;
    }
    if (parsed.looksLikeDrawing) {
      toast.error("That looked like a drawing, not a PO — check the files");
      return;
    }
    if (!parsed.poNumber && !parsed.lines.length) {
      toast.error("Nothing usable found — check the package or fill fields");
      return;
    }

    // Same PO already on file → revise path (unless office forces new)
    if (existingOrder && !forceCreateNew) {
      if (!showReviseDiff) {
        setShowReviseDiff(true);
        toast.message(
          `PO ${existingOrder.poNumber} is already on file — review changes, then apply`,
        );
        return;
      }
      applyRevision();
      return;
    }

    if (parsed.customer) addCustomerQuick(parsed.customer);

    const lines = parsed.lines.map((l, i) => {
      const key = l.partNumber.toUpperCase();
      const draws = drawingMap[key] || [];
      const cads = cadMap[key] || [];
      const base = emptyShopOrderLine({
        id: uid(),
        itemNo: l.itemNo || i + 1,
        partNumber: l.partNumber,
        description: l.description,
        revision: l.revision,
        unitCost: l.unitCost,
        qty: l.qty,
        units: l.units,
        taxable: l.taxable,
        lineStatus: "active",
        ...normalizeLineFiles({ drawings: draws, cadFiles: cads }),
      });
      return {
        ...base,
        ...promoteRelatedFilesToComponents(base),
      };
    });

    const order = createShopOrder({
      poNumber: parsed.poNumber,
      poRevision: proposedPoRev || "A",
      customer: parsed.customer,
      customerAddress: parsed.customerAddress,
      customerPhone: parsed.customerPhone,
      shipToName: parsed.shipToName || parsed.customer,
      shipToAddress: parsed.shipToAddress,
      attn: parsed.attn || "Pam Steck",
      buyer: parsed.buyer,
      techContact: parsed.techContact,
      dateRequired: parsed.dateRequired,
      dueDate: parsed.dateRequired,
      fob: parsed.fob || "Origin",
      shippingMethod: parsed.shippingMethod,
      terms: parsed.terms || "N30",
      date: parsed.date || new Date().toISOString().slice(0, 10),
      rating: parsed.rating,
      status: "open",
      lines,
      sourceFileId: sourceMeta?.id || "",
      sourceFileName: sourceMeta?.name || "",
      sourceFileMime: sourceMeta?.mime || "",
      priorPoFiles: [],
    });
    upsertShopOrder({
      ...order,
      sourceFileId: sourceMeta?.id || order.sourceFileId || "",
      sourceFileName: sourceMeta?.name || order.sourceFileName || "",
      sourceFileMime: sourceMeta?.mime || order.sourceFileMime || "",
    });
    const withMat = (order.lines || []).filter((l) =>
      Boolean(l.material?.trim()),
    ).length;
    const withDraw = (order.lines || []).reduce(
      (n, l) => n + (l.drawings?.length || (l.drawingId ? 1 : 0)),
      0,
    );
    const withCad = (order.lines || []).reduce(
      (n, l) => n + (l.cadFiles?.length || (l.cadFileId ? 1 : 0)),
      0,
    );
    toast.success(
      `PO ${order.poNumber || order.id.slice(0, 8)} · ${withMat}/${order.lines.length} material · ${withDraw} drawing · ${withCad} CAD`,
    );
    onCreated(order.id);
    clearImportForm({ quiet: true });
    onClose();
  }

  const matchedDraw = useMemo(
    () => Object.values(drawingMap).reduce((n, a) => n + a.length, 0),
    [drawingMap],
  );
  const matchedCad = useMemo(
    () => Object.values(cadMap).reduce((n, a) => n + a.length, 0),
    [cadMap],
  );

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-3 sm:p-4"
      onClick={onClose}
    >
      <div
        className="relative z-[60] w-full max-w-3xl max-h-[92vh] overflow-y-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-4 sm:p-6 space-y-4 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <FileUp className="h-5 w-5 text-[var(--color-primary)]" />
            Import customer package
          </h2>
          <p className="text-sm text-[var(--color-muted)] mt-1">
            Drop <strong>everything at once</strong> — PO PDF, drawings, and
            CAD. We pick the PO by name (e.g.{" "}
            <span className="font-mono text-[11px]">PO-26-X679.pdf</span>) or
            by contents, then match files to P/N. Assembly children
            (e.g. -02, -03) attach under the parent line (-01). Multiple
            drawings/CAD per line. Cost is never auto-changed.
          </p>
        </div>

        <label
          className={
            "flex flex-col items-center justify-center gap-2 rounded-[var(--radius-lg)] border-2 border-dashed p-8 cursor-pointer transition-colors " +
            (dragOver
              ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_12%,transparent)]"
              : "border-[var(--color-border)] hover:bg-[var(--color-surface-2)]")
          }
          onDragEnter={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            if (e.dataTransfer.files?.length)
              void handleAllFiles(e.dataTransfer.files);
          }}
        >
          <FileUp className="h-8 w-8 text-[var(--color-primary)]" />
          <span className="text-sm font-medium text-center">
            Drop PO + drawings + CAD here
          </span>
          <span className="text-xs text-[var(--color-muted)] text-center max-w-md">
            Or click to multi-select. Tip: keep “PO” in the purchase order
            filename when you can.
          </span>
          <Input
            ref={allFileRef}
            type="file"
            multiple
            className="max-w-md"
            disabled={busy}
            accept=".pdf,image/*,.txt,.dxf,.dwg,.tif,.tiff,.x_t,.x_b,.step,.stp,.iges,.igs,.sldprt,.sldasm,.prt,.f3d,.sat,.stl,.obj,application/octet-stream"
            onChange={(e) => {
              const list = e.target.files;
              if (list?.length) void handleAllFiles(list);
            }}
          />
        </label>

        {(busy || status) && (
          <p className="text-xs text-[var(--color-muted)] flex items-center gap-2">
            {busy && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            {status}
          </p>
        )}

        {packageNote && !busy && (
          <p className="text-xs text-[var(--color-fg)] bg-[var(--color-surface-2)] border border-[var(--color-border)] rounded-md px-3 py-2">
            {packageNote}
            {matchedDraw || matchedCad
              ? ` (${matchedDraw} drawing map · ${matchedCad} CAD map)`
              : ""}
          </p>
        )}

        {unmatched.length > 0 && parsed && !parsed.looksLikeDrawing && (
          <div className="rounded-[var(--radius-md)] border border-amber-500/40 bg-amber-500/10 p-3 text-xs space-y-2">
            <div>
              <div className="font-medium text-sm text-amber-100">
                Unmatched files — drag onto a line, or use Attach
              </div>
              <p className="text-[var(--color-muted)] mt-0.5">
                Drag a file chip onto the line row (Drawing / CAD column), or
                pick the P/N and click Attach.
              </p>
            </div>
            <ul className="space-y-2">
              {unmatched.map((u) => (
                <UnmatchedRow
                  key={u.meta.id}
                  item={u}
                  lines={parsed.lines}
                  onDragStart={onUnmatchedDragStart}
                  onAssign={assignUnmatchedToLine}
                />
              ))}
            </ul>
          </div>
        )}
        {unmatched.length > 0 && (!parsed || parsed.looksLikeDrawing) && (
          <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 text-xs">
            <div className="font-medium mb-1">Unmatched files</div>
            <ul className="text-[var(--color-muted)] space-y-0.5">
              {unmatched.map((u) => (
                <li key={u.meta.id}>
                  <span className="uppercase text-[10px] font-semibold">
                    {u.kind}
                  </span>{" "}
                  {u.meta.name}
                </li>
              ))}
            </ul>
          </div>
        )}

        {parsed?.looksLikeDrawing && (
          <div className="rounded-[var(--radius-md)] border border-[var(--color-warn)] bg-[color-mix(in_oklab,var(--color-warn)_12%,transparent)] p-3 text-sm">
            <strong>That package looked like a drawing, not a PO.</strong>{" "}
            Include a PO PDF (name it with PO-…) and try again.
          </div>
        )}

        {parsed && !parsed.looksLikeDrawing && (
          <>
            <div className="grid sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Customer</Label>
                <Input
                  value={parsed.customer}
                  onChange={(e) => updateParsed({ customer: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label>PO #</Label>
                <Input
                  className="font-mono"
                  value={parsed.poNumber}
                  onChange={(e) =>
                    updateParsed({ poNumber: e.target.value.toUpperCase() })
                  }
                />
              </div>
              <div className="space-y-1.5">
                <Label>Date required</Label>
                <Input
                  type="date"
                  value={parsed.dateRequired}
                  onChange={(e) =>
                    updateParsed({ dateRequired: e.target.value })
                  }
                />
              </div>
              <div className="space-y-1.5">
                <Label>Rating</Label>
                <Input
                  value={parsed.rating}
                  onChange={(e) => updateParsed({ rating: e.target.value })}
                  placeholder="Optional"
                />
              </div>
            </div>
            {sourceMeta && (
              <p className="text-xs text-[var(--color-muted)]">
                PO file used:{" "}
                <span className="text-[var(--color-fg)]">{sourceMeta.name}</span>
              </p>
            )}

            {existingOrder && !forceCreateNew && (
              <div className="rounded-[var(--radius-md)] border border-[color-mix(in_oklab,var(--color-primary)_40%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-primary)_10%,transparent)] p-3 space-y-2">
                <div className="text-sm font-semibold text-[var(--color-fg)]">
                  PO {existingOrder.poNumber} is already on file
                  {existingOrder.poRevision
                    ? ` (document rev ${existingOrder.poRevision})`
                    : ""}
                </div>
                <p className="text-xs text-[var(--color-muted)] leading-relaxed">
                  Import will <strong className="text-[var(--color-fg)]">revise</strong> that
                  order — same job board lines, shop progress kept. Dropped lines are
                  cancelled (not deleted). Part rev changes clear PDF/CAD OK checks.
                </p>
                <div className="flex flex-wrap items-end gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs">New PO document rev</Label>
                    <Input
                      className="h-9 w-20 font-mono uppercase"
                      value={proposedPoRev}
                      onChange={(e) =>
                        setProposedPoRev(e.target.value.toUpperCase())
                      }
                      placeholder="B"
                    />
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setShowReviseDiff((v) => !v)}
                  >
                    {showReviseDiff ? "Hide change list" : "Review changes"}
                  </Button>
                  <button
                    type="button"
                    className="text-xs text-[var(--color-muted)] underline underline-offset-2 hover:text-[var(--color-fg)]"
                    onClick={() => {
                      setForceCreateNew(true);
                      setShowReviseDiff(false);
                      toast.message(
                        "Will create a separate order — only use if this is not the same PO",
                      );
                    }}
                  >
                    Create as new order instead
                  </button>
                </div>
                {revisePlan && showReviseDiff && (
                  <div className="mt-2 space-y-2 border-t border-[var(--color-border)] pt-2">
                    <div className="flex flex-wrap gap-2 text-[11px]">
                      <span className="rounded-full bg-[var(--color-surface-2)] px-2 py-0.5">
                        {revisePlan.summary.unchanged} same
                      </span>
                      <span className="rounded-full bg-[color-mix(in_oklab,var(--color-warn)_18%,transparent)] px-2 py-0.5 text-[var(--color-warn)]">
                        {revisePlan.summary.changed} changed
                      </span>
                      <span className="rounded-full bg-[color-mix(in_oklab,var(--color-success)_18%,transparent)] px-2 py-0.5 text-[var(--color-success)]">
                        {revisePlan.summary.added} added
                      </span>
                      <span className="rounded-full bg-[color-mix(in_oklab,var(--color-danger)_18%,transparent)] px-2 py-0.5 text-[var(--color-danger)]">
                        {revisePlan.summary.removed} dropped
                      </span>
                    </div>
                    {revisePlan.headerChanges.length > 0 && (
                      <div className="text-xs">
                        <div className="font-medium mb-1">Header</div>
                        <ul className="space-y-0.5 text-[var(--color-muted)]">
                          {revisePlan.headerChanges.map((h) => (
                            <li key={h.field}>
                              {h.label}:{" "}
                              <span className="line-through">{h.from}</span>
                              {" → "}
                              <span className="text-[var(--color-fg)]">{h.to}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    <div className="max-h-48 overflow-y-auto border border-[var(--color-border)] rounded-[var(--radius-md)]">
                      <table className="w-full text-[11px]">
                        <thead>
                          <tr className="bg-[var(--color-surface-2)] text-left">
                            <th className="p-1.5">#</th>
                            <th className="p-1.5">P/N</th>
                            <th className="p-1.5">Change</th>
                          </tr>
                        </thead>
                        <tbody>
                          {revisePlan.rows.map((row, i) => {
                            const pn =
                              row.incoming?.partNumber ||
                              row.existing?.partNumber ||
                              "";
                            const item =
                              row.incoming?.itemNo ||
                              row.existing?.itemNo ||
                              "";
                            let label = "Unchanged";
                            let tone = "text-[var(--color-muted)]";
                            if (row.kind === "added") {
                              label = `Add qty ${row.incoming?.qty ?? ""}`;
                              tone = "text-[var(--color-success)]";
                            } else if (row.kind === "removed") {
                              label = row.canAutoCancel
                                ? "Drop (cancel)"
                                : `Drop — ${row.blockReason}`;
                              tone = "text-[var(--color-danger)]";
                            } else if (row.changes.length) {
                              label = row.changes
                                .map((c) => `${c.label} ${c.from}→${c.to}`)
                                .join("; ");
                              tone = "text-[var(--color-warn)]";
                            }
                            return (
                              <tr
                                key={`${row.kind}-${row.existingLineId || pn}-${i}`}
                                className="border-t border-[var(--color-border)]"
                              >
                                <td className="p-1.5 font-mono">{item}</td>
                                <td className="p-1.5 font-mono">{pn}</td>
                                <td className={cn("p-1.5", tone)}>{label}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                    {revisePlan.summary.blockedRemoves > 0 && (
                      <label className="flex items-start gap-2 text-xs cursor-pointer rounded-[var(--radius-md)] border border-[color-mix(in_oklab,var(--color-danger)_35%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-danger)_10%,transparent)] p-2">
                        <input
                          type="checkbox"
                          className="mt-0.5 h-4 w-4 accent-[var(--color-danger)]"
                          checked={allowBlockedCancels}
                          onChange={(e) =>
                            setAllowBlockedCancels(e.target.checked)
                          }
                        />
                        <span>
                          Cancel{" "}
                          <strong>{revisePlan.summary.blockedRemoves}</strong>{" "}
                          line
                          {revisePlan.summary.blockedRemoves === 1 ? "" : "s"} that
                          already have shop work (stays in history as Dropped)
                        </span>
                      </label>
                    )}
                  </div>
                )}
              </div>
            )}

            {forceCreateNew && (
              <p className="text-xs text-[var(--color-muted)] rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-2">
                Creating as a <strong>new</strong> separate order (revise disabled).{" "}
                <button
                  type="button"
                  className="underline underline-offset-2"
                  onClick={() => setForceCreateNew(false)}
                >
                  Switch back to revise
                </button>
              </p>
            )}

            <div>
              <div className="text-sm font-medium mb-2">
                Lines ({lineCount})
              </div>
              <div className="overflow-x-auto border border-[var(--color-border)] rounded-[var(--radius-md)]">
                <table className="w-full text-xs min-w-[720px]">
                  <thead>
                    <tr className="bg-[var(--color-surface-2)] text-left">
                      <th className="p-2">#</th>
                      <th className="p-2">P/N</th>
                      <th className="p-2">Description</th>
                      <th className="p-2">Rev</th>
                      <th className="p-2">Qty</th>
                      {canSeePrices && <th className="p-2">Cost</th>}
                      <th className="p-2">Drawing</th>
                      <th className="p-2">CAD</th>
                    </tr>
                  </thead>
                  <tbody>
                    {parsed.lines.map((l, idx) => {
                      const pnKey = l.partNumber.toUpperCase();
                      const dList = drawingMap[pnKey] || [];
                      const cList = cadMap[pnKey] || [];
                      const isDrop = dropLineKey === pnKey;
                      return (
                        <tr
                          key={idx}
                          className={cn(
                            "border-t border-[var(--color-border)]",
                            isDrop &&
                              "bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)] ring-1 ring-inset ring-[var(--color-primary)]",
                          )}
                          onDragOver={(e) => onLineDragOver(e, l.partNumber)}
                          onDragLeave={() =>
                            setDropLineKey((k) =>
                              k === pnKey ? null : k,
                            )
                          }
                          onDrop={(e) => onLineDrop(e, l.partNumber, "auto")}
                        >
                          <td className="p-1.5">{l.itemNo}</td>
                          <td className="p-1.5">
                            <Input
                              className="h-8 text-xs font-mono"
                              value={l.partNumber}
                              onChange={(e) =>
                                updateLine(idx, {
                                  partNumber: e.target.value.toUpperCase(),
                                })
                              }
                            />
                          </td>
                          <td className="p-1.5">
                            <Input
                              className="h-8 text-xs"
                              value={l.description}
                              onChange={(e) =>
                                updateLine(idx, {
                                  description: e.target.value,
                                })
                              }
                            />
                          </td>
                          <td className="p-1.5 w-14">
                            <Input
                              className="h-8 text-xs"
                              value={l.revision}
                              onChange={(e) =>
                                updateLine(idx, {
                                  revision: e.target.value.toUpperCase(),
                                })
                              }
                            />
                          </td>
                          <td className="p-1.5 w-16">
                            <Input
                              type="text"
                              inputMode="numeric"
                              className="h-8 text-xs"
                              value={l.qty === 0 ? "" : String(l.qty)}
                              onChange={(e) =>
                                updateLine(idx, {
                                  qty:
                                    Number(
                                      e.target.value.replace(/[^0-9.]/g, ""),
                                    ) || 0,
                                })
                              }
                            />
                          </td>
                          {canSeePrices && (
                            <td className="p-1.5 w-20 tabular">
                              {formatCurrency(l.unitCost)}
                            </td>
                          )}
                          <td
                            className="p-1.5 text-[10px] max-w-[9rem]"
                            title="Drop drawing here (adds — keeps existing)"
                            onDragOver={(e) => onLineDragOver(e, l.partNumber)}
                            onDrop={(e) =>
                              onLineDrop(e, l.partNumber, "drawing")
                            }
                          >
                            {dList.length ? (
                              <span
                                className="text-[var(--color-success)] block leading-snug"
                                title={dList.map((x) => x.name).join("\n")}
                              >
                                {dList.length === 1
                                  ? dList[0]!.name
                                  : `${dList.length} drawings`}
                                {dList.some((x) => x.relatedPartNumber) ? (
                                  <span className="block text-[9px] text-[var(--color-muted)]">
                                    +related
                                  </span>
                                ) : null}
                              </span>
                            ) : (
                              <span className="text-[var(--color-subtle)] italic">
                                {unmatched.length ? "drop drawing" : "—"}
                              </span>
                            )}
                          </td>
                          <td
                            className="p-1.5 text-[10px] max-w-[9rem]"
                            title="Drop CAD here (adds — keeps existing)"
                            onDragOver={(e) => onLineDragOver(e, l.partNumber)}
                            onDrop={(e) => onLineDrop(e, l.partNumber, "cad")}
                          >
                            {cList.length ? (
                              <span
                                className="text-[var(--color-primary)] block leading-snug"
                                title={cList.map((x) => x.name).join("\n")}
                              >
                                {cList.length === 1
                                  ? cList[0]!.name
                                  : `${cList.length} CAD`}
                                {cList.some((x) => x.relatedPartNumber) ? (
                                  <span className="block text-[9px] text-[var(--color-muted)]">
                                    +related
                                  </span>
                                ) : null}
                              </span>
                            ) : (
                              <span className="text-[var(--color-subtle)] italic">
                                {unmatched.length ? "drop CAD" : "—"}
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              {parsed.warnings.map((w) => (
                <p key={w} className="text-xs text-[var(--color-warn)] mt-1">
                  {w}
                </p>
              ))}
            </div>
          </>
        )}

        {parsed && !parsed.looksLikeDrawing && (
          <label className="flex items-start gap-2 text-sm rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 cursor-pointer">
            <input
              type="checkbox"
              className="mt-1 h-4 w-4 accent-[var(--color-primary)]"
              checked={confirmReady}
              onChange={(e) => setConfirmReady(e.target.checked)}
            />
            <span>
              <span className="font-medium">
                I checked customer, PO #, dates, lines, and file matches
              </span>
              <span className="block text-xs text-[var(--color-muted)] mt-0.5">
                {existingOrder && !forceCreateNew
                  ? "Confirm the change list before applying this PO revision."
                  : "Confirm the right PDF was used as the PO and drawings/CAD look correct before creating."}
              </span>
            </span>
          </label>
        )}

        <div className="flex flex-wrap justify-between gap-2 pt-1">
          <Button
            type="button"
            variant="outline"
            disabled={busy}
            onClick={() => clearImportForm()}
          >
            <Eraser className="h-4 w-4" />
            Clear form
          </Button>
          <div className="flex flex-wrap gap-2 ml-auto">
            <Button
              variant="ghost"
              onClick={() => {
                clearImportForm({ quiet: true });
                onClose();
              }}
              disabled={busy}
            >
              Cancel
            </Button>
            <Button
              onClick={createOrder}
              disabled={
                busy ||
                !parsed ||
                parsed.looksLikeDrawing ||
                (!parsed.lines.length && !parsed.poNumber) ||
                !confirmReady
              }
            >
              {existingOrder && !forceCreateNew
                ? showReviseDiff
                  ? "Apply PO revision"
                  : "Review & revise existing PO"
                : "Create customer order"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

function UnmatchedRow({
  item,
  lines,
  onDragStart,
  onAssign,
}: {
  item: { meta: FileMeta; kind: string };
  lines: ParsedPo["lines"];
  onDragStart: (
    e: React.DragEvent,
    fileId: string,
    kind: string,
  ) => void;
  onAssign: (
    fileId: string,
    partNumber: string,
    asKind?: "drawing" | "cad" | "auto",
  ) => void;
}) {
  const defaultKind =
    item.kind === "cad" ? "cad" : item.kind === "drawing" ? "drawing" : "auto";
  const [pn, setPn] = useState(lines[0]?.partNumber || "");
  const [asKind, setAsKind] = useState<"drawing" | "cad" | "auto">(
    defaultKind as "drawing" | "cad" | "auto",
  );

  return (
    <li className="flex flex-col sm:flex-row sm:items-center gap-2 rounded-md border border-[var(--color-border)] bg-[var(--color-surface)] p-2">
      <div
        draggable
        onDragStart={(e) => onDragStart(e, item.meta.id, item.kind)}
        className="flex items-center gap-1.5 min-w-0 flex-1 cursor-grab active:cursor-grabbing select-none"
        title="Drag onto a line row below"
      >
        <GripVertical className="h-4 w-4 shrink-0 text-[var(--color-subtle)]" />
        <span className="uppercase text-[9px] font-bold tracking-wide text-amber-200/90 shrink-0">
          {item.kind}
        </span>
        <span className="truncate font-medium text-[var(--color-fg)]">
          {item.meta.name}
        </span>
      </div>
      <div className="flex flex-wrap items-center gap-1.5 shrink-0">
        <Select
          className="h-8 text-xs min-w-[8rem] w-auto"
          value={pn}
          onChange={(e) => setPn(e.target.value)}
        >
          {lines.map((l, i) => (
            <option key={`${l.partNumber}-${i}`} value={l.partNumber}>
              #{l.itemNo || i + 1} {l.partNumber || "(no P/N)"}
            </option>
          ))}
        </Select>
        <Select
          className="h-8 text-xs w-auto min-w-[6.5rem]"
          value={asKind}
          onChange={(e) =>
            setAsKind(e.target.value as "drawing" | "cad" | "auto")
          }
        >
          <option value="auto">Auto type</option>
          <option value="drawing">As drawing</option>
          <option value="cad">As CAD</option>
        </Select>
        <Button
          type="button"
          size="sm"
          className="h-8"
          onClick={() => onAssign(item.meta.id, pn, asKind)}
          disabled={!pn}
        >
          <Paperclip className="h-3.5 w-3.5" />
          Attach
        </Button>
      </div>
    </li>
  );
}
