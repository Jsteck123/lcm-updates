/**
 * Full-screen drawing + assign controls for the desk queue.
 * Pick operator/machine while looking at the print; Assign or Skip later.
 */
import { useEffect, useRef, useState } from "react";
import {
  X,
  UserCheck,
  ArrowDownToLine,
  FileText,
  Loader2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import type { AssignQueueItem } from "@/lib/lcm/assign-queue";
import { resolveAttachment } from "@/lib/lcm/open-attachment";

type Props = {
  item: AssignQueueItem;
  operatorNames: string[];
  machines: string[];
  operator: string;
  machine: string;
  notes: string;
  onOperator: (v: string) => void;
  onMachine: (v: string) => void;
  onNotes: (v: string) => void;
  onAssign: () => void;
  onSkip: () => void;
  onClose: () => void;
  estimatedHours?: number;
};

export function AssignDrawingModal({
  item,
  operatorNames,
  machines,
  operator,
  machine,
  notes,
  onOperator,
  onMachine,
  onNotes,
  onAssign,
  onSkip,
  onClose,
  estimatedHours,
}: Props) {
  const files = [
    ...item.drawings.map((d) => ({ ...d, kind: "drawing" as const })),
    ...item.cadFiles.map((d) => ({ ...d, kind: "cad" as const })),
  ];
  const [fileIdx, setFileIdx] = useState(0);
  const [url, setUrl] = useState<string | null>(null);
  const [mime, setMime] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const revokeRef = useRef<(() => void) | null>(null);

  const activeFile = files[fileIdx];

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  useEffect(() => {
    let cancelled = false;
    revokeRef.current?.();
    revokeRef.current = null;
    setUrl(null);
    setErr("");
    if (!activeFile?.id) {
      setLoading(false);
      return;
    }
    setLoading(true);
    void resolveAttachment({ id: activeFile.id, name: activeFile.name }).then(
      (r) => {
        if (cancelled) {
          if (r.ok) r.revoke?.();
          return;
        }
        setLoading(false);
        if (!r.ok) {
          setErr(r.error || "Could not load file");
          return;
        }
        setUrl(r.url);
        setMime(r.mime);
        revokeRef.current = r.revoke || null;
      },
    );
    return () => {
      cancelled = true;
      revokeRef.current?.();
      revokeRef.current = null;
    };
  }, [activeFile?.id, activeFile?.name]);

  const isImage = /^image\//i.test(mime);
  const isPdf =
    /pdf/i.test(mime) ||
    /\.pdf$/i.test(activeFile?.name || "") ||
    mime === "application/pdf";

  return (
    <div
      className="fixed inset-0 z-[90] flex flex-col bg-black/85 print:hidden"
      role="dialog"
      aria-modal="true"
      aria-label="Assign from drawing"
    >
      <div className="shrink-0 flex flex-wrap items-center gap-2 px-3 py-2 bg-[var(--color-surface)] border-b border-[var(--color-border)]">
        <div className="min-w-0 flex-1">
          <div className="font-mono font-semibold text-base truncate">
            {item.partNumber}
            {item.revision ? (
              <span className="text-[var(--color-muted)] font-normal">
                {" "}
                · Rev {item.revision}
              </span>
            ) : null}
          </div>
          <div className="text-xs text-[var(--color-muted)] truncate">
            PO {item.poNumber}
            {item.customer ? ` · ${item.customer}` : ""} · qty {item.qty}
            {typeof estimatedHours === "number" && estimatedHours > 0
              ? ` · ~${estimatedHours}h quoted`
              : ""}
          </div>
        </div>
        {files.length > 1 && (
          <div className="flex flex-wrap gap-1">
            {files.map((f, i) => (
              <Button
                key={f.id}
                type="button"
                size="sm"
                variant={i === fileIdx ? "secondary" : "outline"}
                onClick={() => setFileIdx(i)}
              >
                <FileText className="h-3.5 w-3.5" />
                {f.kind === "cad" ? "CAD" : f.name || "Drawing"}
              </Button>
            ))}
          </div>
        )}
        <Button type="button" size="sm" variant="ghost" onClick={onClose}>
          <X className="h-4 w-4" />
          Close
        </Button>
      </div>

      <div className="flex-1 min-h-0 flex items-center justify-center bg-[var(--color-bg)] p-2 overflow-auto">
        {loading && (
          <div className="flex items-center gap-2 text-[var(--color-muted)]">
            <Loader2 className="h-5 w-5 animate-spin" />
            Loading drawing…
          </div>
        )}
        {!loading && err && (
          <p className="text-sm text-[var(--color-warn)]">{err}</p>
        )}
        {!loading && !err && !activeFile && (
          <p className="text-sm text-[var(--color-muted)]">
            No drawing attached — still assign from the bar below.
          </p>
        )}
        {!loading && url && isImage && (
          <img
            src={url}
            alt={activeFile?.name || "Drawing"}
            className="max-w-full max-h-full object-contain rounded-md"
          />
        )}
        {!loading && url && isPdf && (
          <iframe
            title={activeFile?.name || "Drawing"}
            src={url}
            className="w-full h-full min-h-[50vh] rounded-md bg-white"
          />
        )}
        {!loading && url && !isImage && !isPdf && (
          <div className="text-center text-sm text-[var(--color-muted)] space-y-2">
            <p>Preview not available for this file type.</p>
            <a
              href={url}
              download={activeFile?.name}
              className="text-[var(--color-primary)] underline"
            >
              Download {activeFile?.name}
            </a>
          </div>
        )}
      </div>

      <div className="shrink-0 border-t border-[var(--color-border)] bg-[var(--color-surface)] px-3 py-3 space-y-2">
        <div className="flex flex-wrap items-center gap-2 text-xs text-[var(--color-muted)]">
          <Badge tone="info">{item.kind}</Badge>
          <span>Pick who runs it while you look at the print</span>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-2 items-end">
          <div className="space-y-1">
            <Label className="text-xs">Operator (required)</Label>
            <Select
              value={operator}
              onChange={(e) => onOperator(e.target.value)}
            >
              <option value="">— Who runs this? —</option>
              {operatorNames.map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </Select>
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Machine (optional)</Label>
            <Select
              value={machine}
              onChange={(e) => onMachine(e.target.value)}
            >
              <option value="">— None / later —</option>
              {machines.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </Select>
          </div>
          <div className="space-y-1 sm:col-span-2 lg:col-span-1">
            <Label className="text-xs">Note</Label>
            <Input
              value={notes}
              onChange={(e) => onNotes(e.target.value)}
              placeholder="Op 2 only…"
            />
          </div>
          <div className="flex flex-wrap gap-2 lg:justify-end">
            <Button
              type="button"
              variant="outline"
              className="min-h-11 flex-1 sm:flex-none"
              onClick={onSkip}
              title="Keep in queue, move to bottom"
            >
              <ArrowDownToLine className="h-4 w-4" />
              Skip for later
            </Button>
            <Button
              type="button"
              className="min-h-11 flex-1 sm:flex-none min-w-[8rem]"
              disabled={!operator.trim()}
              onClick={onAssign}
            >
              <UserCheck className="h-4 w-4" />
              Assign & next
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
