import type { ShopOrder, ShopOrderLine } from "@/lib/lcm/types";
import { CompanyLogo } from "@/components/lcm/company-logo";
import { lineShipDate } from "@/lib/lcm/shipping-calendar";

/** Shop traveler — one line (drawing + material + time table for digital coexistence) */
export function ShopWorkOrderSheet({
  order,
  line,
}: {
  order: ShopOrder;
  line: ShopOrderLine;
}) {
  const due = lineShipDate(order, line) || order.dateRequired || "—";
  return (
    <div className="bg-white text-black p-6 text-sm print:p-4">
      <div className="flex justify-between border-b border-black pb-3">
        <div>
          <CompanyLogo variant="wide" className="h-12 w-auto max-w-[220px]" />
          <div className="font-bold text-lg mt-1">SHOP WORK ORDER</div>
          <div className="text-xs text-neutral-600">Traveler · one line item only</div>
        </div>
        <div className="text-right font-mono">
          <div className="text-xl font-bold">{order.poNumber || "—"}</div>
          <div>Due: {due}</div>
          <div>Qty: {line.qty}</div>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3 mt-3">
        <div className="border border-neutral-400 rounded p-2">
          <div className="text-xs font-semibold uppercase text-neutral-600">Part</div>
          <div className="font-mono text-lg font-bold">{line.partNumber}</div>
          <div>Rev {line.revision || "—"}</div>
          <div className="text-neutral-700">{line.description}</div>
        </div>
        <div className="border border-neutral-400 rounded p-2">
          <div className="text-xs font-semibold uppercase text-neutral-600">Material</div>
          <div>
            {line.material || "—"} {line.materialType || ""}
          </div>
          <div className="font-mono text-sm mt-1">{line.sizeNote || "size TBD"}</div>
          <div className="text-xs mt-1">Shape: {line.stockShape || "—"}</div>
        </div>
      </div>
      <div className="mt-3 border border-neutral-400 rounded p-2">
        <div className="text-xs font-semibold uppercase">Customer</div>
        {order.customer || "—"}
      </div>
      <table className="w-full mt-4 border border-neutral-400 text-xs">
        <thead>
          <tr className="bg-neutral-100">
            <th className="border border-neutral-400 px-2 py-1 text-left">Op</th>
            <th className="border border-neutral-400 px-2 py-1">Setup</th>
            <th className="border border-neutral-400 px-2 py-1">Runtime</th>
            <th className="border border-neutral-400 px-2 py-1">Operator</th>
            <th className="border border-neutral-400 px-2 py-1">Notes</th>
          </tr>
        </thead>
        <tbody>
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <tr key={n}>
              <td className="border border-neutral-400 px-2 py-3">Op {n}</td>
              <td className="border border-neutral-400 px-2 py-3" />
              <td className="border border-neutral-400 px-2 py-3" />
              <td className="border border-neutral-400 px-2 py-3" />
              <td className="border border-neutral-400 px-2 py-3" />
            </tr>
          ))}
        </tbody>
      </table>
      <p className="text-xs text-neutral-600 mt-3">
        Prefer digital timers on the Shop Floor tab. Use this table only if needed.
        When done: mark complete in app → goes to packing (Ready for pack).
      </p>
    </div>
  );
}

/** Shipping clipboard — order lines, no prices */
export function ShippingWorkOrderSheet({ order }: { order: ShopOrder }) {
  return (
    <div className="bg-white text-black p-6 text-sm">
      <div className="flex justify-between border-b border-black pb-3">
        <div>
          <CompanyLogo variant="wide" className="h-12 w-auto max-w-[220px]" />
          <div className="font-bold text-lg mt-1">SHIPPING WORK ORDER</div>
          <div className="text-xs text-neutral-600">No drawings · pack against this list</div>
        </div>
        <div className="text-right font-mono">
          <div className="text-xl font-bold">{order.poNumber || "—"}</div>
          <div>Due: {order.dueDate || order.dateRequired || "—"}</div>
          <div>{order.customer}</div>
        </div>
      </div>
      <table className="w-full mt-4 border border-neutral-400 text-sm">
        <thead>
          <tr className="bg-neutral-100">
            <th className="border border-neutral-400 px-2 py-1 text-left">Part #</th>
            <th className="border border-neutral-400 px-2 py-1">Rev</th>
            <th className="border border-neutral-400 px-2 py-1 text-left">Description</th>
            <th className="border border-neutral-400 px-2 py-1 text-right">Qty</th>
            <th className="border border-neutral-400 px-2 py-1">Ready</th>
            <th className="border border-neutral-400 px-2 py-1">Packed</th>
          </tr>
        </thead>
        <tbody>
          {(order.lines || []).map((l) => (
            <tr key={l.id}>
              <td className="border border-neutral-400 px-2 py-2 font-mono">
                {l.partNumber}
              </td>
              <td className="border border-neutral-400 px-2 py-2 text-center">
                {l.revision}
              </td>
              <td className="border border-neutral-400 px-2 py-2">{l.description}</td>
              <td className="border border-neutral-400 px-2 py-2 text-right">
                {l.qty}
              </td>
              <td className="border border-neutral-400 px-2 py-2 text-center">
                {l.readyForPack ? "✓" : "☐"}
              </td>
              <td className="border border-neutral-400 px-2 py-2 text-center">
                {l.linePacked ? "✓" : "☐"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/** Small ship label: PO · PN · Rev · Qty */
export function ShipLabelSheet({
  order,
  line,
}: {
  order: ShopOrder;
  line: ShopOrderLine;
}) {
  return (
    <div className="bg-white text-black border-2 border-black p-3 w-[3.5in] min-h-[2in] font-sans">
      <div className="text-[10px] font-semibold tracking-wide">LAKE COUNTRY MACHINE</div>
      <div className="text-xs mt-1">PO: <span className="font-mono font-bold text-sm">{order.poNumber}</span></div>
      <div className="text-xs">P/N: <span className="font-mono font-bold text-base">{line.partNumber}</span></div>
      <div className="text-xs">Rev: <span className="font-mono font-bold">{line.revision || "—"}</span>
        {" · "}Qty: <span className="font-mono font-bold text-base">{line.qty}</span>
      </div>
      <div className="text-[10px] text-neutral-700 mt-1 truncate">{line.description}</div>
    </div>
  );
}
