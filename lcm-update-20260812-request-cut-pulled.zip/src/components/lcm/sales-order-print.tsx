import { useMemo, useState } from "react";
import { Printer, Download, X } from "lucide-react";
import { toast } from "sonner";
import type { ShopOrder } from "@/lib/lcm/types";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import {
  LCM_LETTERHEAD,
  DEFAULT_SALES_TAX_RATE,
  suggestSoNumber,
  formatSoDate,
  shopLinesToSoLines,
  salesOrderTotals,
  buildQuickBooksInvoiceCsv,
  downloadTextFile,
} from "@/lib/lcm/sales-order";
import { formatCurrency } from "@/lib/utils";
import { CompanyLogo } from "@/components/lcm/company-logo";

type Props = {
  order: ShopOrder;
  allOrders: ShopOrder[];
  canSeePrices: boolean;
  onClose: () => void;
  onSaveSoNumber: (soNumber: string) => void;
};

/**
 * Printable Lake Country Machine Sales Order (paper-form style)
 * + QuickBooks CSV export from the same data.
 */
export function SalesOrderDialog({
  order,
  allOrders,
  canSeePrices,
  onClose,
  onSaveSoNumber,
}: Props) {
  const [soNumber, setSoNumber] = useState(
    () => suggestSoNumber(order, allOrders),
  );
  const [taxPct, setTaxPct] = useState(
    String(Math.round(DEFAULT_SALES_TAX_RATE * 10000) / 100),
  );

  const lines = useMemo(() => shopLinesToSoLines(order.lines), [order.lines]);
  const taxRate = (Number(taxPct) || 0) / 100;
  const totals = useMemo(
    () => salesOrderTotals(lines, taxRate),
    [lines, taxRate],
  );

  const billTo =
    [order.customer, order.customerAddress, order.customerPhone]
      .filter(Boolean)
      .join("\n") || "Walk-In Customer";
  const shipTo =
    [order.shipToName, order.shipToAddress].filter(Boolean).join("\n") || "";

  function handlePrint() {
    onSaveSoNumber(soNumber.trim());
    // slight delay so state can flush label
    window.setTimeout(() => window.print(), 50);
  }

  function handleQbExport() {
    if (!canSeePrices) {
      toast.error("Price export is admin-only");
      return;
    }
    onSaveSoNumber(soNumber.trim());
    const csv = buildQuickBooksInvoiceCsv({
      order,
      soNumber: soNumber.trim() || suggestSoNumber(order, allOrders),
      taxRate,
    });
    const name = `QB-Invoice-SO-${soNumber || order.poNumber || order.id.slice(0, 6)}.csv`;
    downloadTextFile(name, csv, "text/csv;charset=utf-8");
    toast.success("QuickBooks CSV downloaded");
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-2 sm:p-4 print:static print:inset-auto print:bg-white print:p-0">
      <div
        className="relative w-full max-w-4xl max-h-[96vh] overflow-y-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] shadow-xl print:max-w-none print:max-h-none print:rounded-none print:border-0 print:shadow-none print:bg-white"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Controls — hidden when printing */}
        <div className="sticky top-0 z-10 flex flex-wrap items-center justify-between gap-2 border-b border-[var(--color-border)] bg-[var(--color-surface)] px-4 py-3 print:hidden">
          <div>
            <h2 className="font-semibold text-[var(--color-fg)]">
              Sales Order / QuickBooks
            </h2>
            <p className="text-xs text-[var(--color-muted)]">
              Built from this customer PO — print for the office form or export
              CSV for QuickBooks.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              <X className="h-4 w-4" /> Close
            </Button>
            {canSeePrices && (
              <Button type="button" variant="secondary" onClick={handleQbExport}>
                <Download className="h-4 w-4" /> QuickBooks CSV
              </Button>
            )}
            <Button type="button" onClick={handlePrint}>
              <Printer className="h-4 w-4" /> Print Sales Order
            </Button>
          </div>
        </div>

        <div className="p-4 sm:p-6 print:p-0 space-y-4 print:space-y-0">
          <div className="grid sm:grid-cols-3 gap-3 print:hidden">
            <div className="space-y-1">
              <Label>S.O. #</Label>
              <Input
                className="font-mono"
                value={soNumber}
                onChange={(e) => setSoNumber(e.target.value)}
              />
            </div>
            <div className="space-y-1">
              <Label>Sales tax %</Label>
              <Input
                value={taxPct}
                onChange={(e) => setTaxPct(e.target.value)}
                inputMode="decimal"
              />
            </div>
            <div className="space-y-1 text-xs text-[var(--color-muted)] flex items-end pb-2">
              Customer PO:{" "}
              <span className="font-mono text-[var(--color-fg)] ml-1">
                {order.poNumber || "—"}
              </span>
            </div>
          </div>

          {/* PAPER FORM — light for print */}
          <div
            id="lcm-sales-order-sheet"
            className="rounded-lg border border-neutral-300 bg-white text-black p-5 sm:p-8 print:border-0 print:rounded-none print:p-6"
          >
            {/* Header */}
            <div className="flex flex-wrap justify-between gap-4 border-b border-neutral-400 pb-4">
              <div className="flex items-start gap-3 min-w-0">
                <CompanyLogo
                  variant="wide"
                  alt="Lake Country Machine"
                  className="h-14 sm:h-16 w-auto max-w-[min(100%,280px)] object-left"
                />
                <div className="text-xs sm:text-sm text-neutral-700 leading-snug pt-0.5 shrink-0">
                  {LCM_LETTERHEAD.addressLine}
                  <br />
                  {LCM_LETTERHEAD.cityLine}
                  <br />
                  {LCM_LETTERHEAD.phone}
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-neutral-900">
                  Sales Order
                </div>
                <div className="mt-2 inline-grid grid-cols-2 gap-x-3 gap-y-1 text-sm border border-neutral-400 rounded-md overflow-hidden">
                  <div className="bg-neutral-100 px-2 py-1 font-semibold border-b border-r border-neutral-400">
                    Date
                  </div>
                  <div className="bg-neutral-100 px-2 py-1 font-semibold border-b border-neutral-400">
                    S.O. #
                  </div>
                  <div className="px-2 py-1 border-r border-neutral-400 tabular-nums">
                    {formatSoDate(order.date || order.createdAt)}
                  </div>
                  <div className="px-2 py-1 font-mono font-semibold">
                    {soNumber || "—"}
                  </div>
                </div>
              </div>
            </div>

            {/* Bill / Ship */}
            <div className="grid sm:grid-cols-2 gap-4 mt-4">
              <div className="border border-neutral-400 rounded-md min-h-[5.5rem]">
                <div className="bg-neutral-100 text-xs font-semibold px-2 py-1 border-b border-neutral-400">
                  Name / Address
                </div>
                <div className="p-2 text-sm whitespace-pre-wrap leading-snug">
                  {billTo}
                </div>
              </div>
              <div className="border border-neutral-400 rounded-md min-h-[5.5rem]">
                <div className="bg-neutral-100 text-xs font-semibold px-2 py-1 border-b border-neutral-400">
                  Ship To
                </div>
                <div className="p-2 text-sm whitespace-pre-wrap leading-snug">
                  {shipTo || "—"}
                </div>
              </div>
            </div>

            <div className="flex flex-wrap justify-end gap-3 mt-3">
              <div className="inline-grid grid-cols-2 text-sm border border-neutral-400 rounded-md overflow-hidden">
                <div className="bg-neutral-100 px-2 py-1 font-semibold border-b border-r border-neutral-400">
                  Due Date
                </div>
                <div className="bg-neutral-100 px-2 py-1 font-semibold border-b border-neutral-400">
                  P.O. No.
                </div>
                <div className="px-2 py-1 border-r border-neutral-400">
                  {formatSoDate(order.dueDate || order.dateRequired) || "—"}
                </div>
                <div className="px-2 py-1 font-mono">
                  {order.poNumber || "—"}
                </div>
              </div>
            </div>

            {/* Lines */}
            <div className="mt-4 border border-neutral-400 rounded-md overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-neutral-100 text-left">
                    <th className="px-2 py-1.5 border-b border-r border-neutral-400 font-semibold">
                      Item
                    </th>
                    <th className="px-2 py-1.5 border-b border-r border-neutral-400 font-semibold">
                      Description
                    </th>
                    <th className="px-2 py-1.5 border-b border-r border-neutral-400 font-semibold w-12">
                      Rev
                    </th>
                    <th className="px-2 py-1.5 border-b border-r border-neutral-400 font-semibold w-14 text-right">
                      Qty
                    </th>
                    {canSeePrices && (
                      <>
                        <th className="px-2 py-1.5 border-b border-r border-neutral-400 font-semibold w-20 text-right">
                          Rate
                        </th>
                        <th className="px-2 py-1.5 border-b border-neutral-400 font-semibold w-24 text-right">
                          Amount
                        </th>
                      </>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {lines.map((l, i) => (
                    <tr key={i} className="align-top">
                      <td className="px-2 py-1.5 border-b border-r border-neutral-300 font-mono text-xs">
                        {l.item}
                      </td>
                      <td className="px-2 py-1.5 border-b border-r border-neutral-300">
                        {l.description}
                      </td>
                      <td className="px-2 py-1.5 border-b border-r border-neutral-300 text-center">
                        {l.rev || ""}
                      </td>
                      <td className="px-2 py-1.5 border-b border-r border-neutral-300 text-right tabular-nums">
                        {l.qty}
                      </td>
                      {canSeePrices && (
                        <>
                          <td className="px-2 py-1.5 border-b border-r border-neutral-300 text-right tabular-nums">
                            {l.rate.toFixed(2)}
                          </td>
                          <td className="px-2 py-1.5 border-b border-neutral-300 text-right tabular-nums">
                            {l.amount.toFixed(2)}
                          </td>
                        </>
                      )}
                    </tr>
                  ))}
                  {canSeePrices && (
                    <tr>
                      <td
                        className="px-2 py-1.5 border-r border-neutral-300"
                        colSpan={2}
                      >
                        Sales Tax
                      </td>
                      <td className="border-r border-neutral-300" />
                      <td className="border-r border-neutral-300" />
                      <td className="px-2 py-1.5 border-r border-neutral-300 text-right tabular-nums">
                        {(taxRate * 100).toFixed(2)}%
                      </td>
                      <td className="px-2 py-1.5 text-right tabular-nums">
                        {totals.tax.toFixed(2)}
                      </td>
                    </tr>
                  )}
                  {lines.length === 0 && (
                    <tr>
                      <td
                        colSpan={canSeePrices ? 6 : 4}
                        className="px-2 py-6 text-center text-neutral-500"
                      >
                        No line items on this order
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="mt-3 flex flex-wrap items-end justify-between gap-3">
              <p className="text-sm text-neutral-600">
                Thank you for your business.
              </p>
              {canSeePrices && (
                <div className="inline-flex items-center gap-3 border border-neutral-400 rounded-md px-3 py-2">
                  <span className="font-bold text-lg">Total</span>
                  <span className="font-bold text-lg tabular-nums">
                    {formatCurrency(totals.total)}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Print: only show the sheet */}
      <style>{`
        @media print {
          body * { visibility: hidden !important; }
          #lcm-sales-order-sheet, #lcm-sales-order-sheet * { visibility: visible !important; }
          #lcm-sales-order-sheet {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
          }
        }
      `}</style>
    </div>
  );
}
