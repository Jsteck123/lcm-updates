import { useEffect, useMemo, useRef, useState } from "react";
import { Check, ChevronDown, Plus, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

type MultiSelectProps = {
  value: string[];
  options: string[];
  onChange: (next: string[]) => void;
  placeholder?: string;
  /** Allow typing a new option and adding it */
  allowCreate?: boolean;
  /** Accept reorder UI from quote wizard (chips stay in given order). */
  allowReorder?: boolean;
  className?: string;
  disabled?: boolean;
};

/**
 * Multi-select with typeahead + chips. For vendor lists, materials, etc.
 */
export function MultiSelect({
  value,
  options,
  onChange,
  placeholder = "Select…",
  allowCreate = true,
  allowReorder: _allowReorder,
  className,
  disabled,
}: MultiSelectProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");

  const selected = useMemo(
    () => value.map((v) => v.trim()).filter(Boolean),
    [value],
  );

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    const out: string[] = [];
    const seen = new Set(selected.map((s) => s.toLowerCase()));
    for (const o of options) {
      const t = String(o || "").trim();
      if (!t || seen.has(t.toLowerCase())) continue;
      if (term && !t.toLowerCase().includes(term)) continue;
      out.push(t);
      if (out.length >= 50) break;
    }
    return out;
  }, [options, q, selected]);

  const canCreate =
    allowCreate &&
    q.trim().length > 0 &&
    !selected.some((s) => s.toLowerCase() === q.trim().toLowerCase()) &&
    !options.some((o) => o.toLowerCase() === q.trim().toLowerCase());

  useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (!wrapRef.current?.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  function toggle(opt: string) {
    const exists = selected.some((s) => s.toLowerCase() === opt.toLowerCase());
    if (exists) {
      onChange(selected.filter((s) => s.toLowerCase() !== opt.toLowerCase()));
    } else {
      onChange([...selected, opt]);
    }
  }

  function addCreate() {
    const v = q.trim();
    if (!v) return;
    if (!selected.some((s) => s.toLowerCase() === v.toLowerCase())) {
      onChange([...selected, v]);
    }
    setQ("");
  }

  function remove(opt: string) {
    onChange(selected.filter((s) => s.toLowerCase() !== opt.toLowerCase()));
  }

  return (
    <div ref={wrapRef} className={cn("relative", className)}>
      <button
        type="button"
        disabled={disabled}
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "flex min-h-11 w-full flex-wrap items-center gap-1.5 rounded-[var(--radius-md)] border border-[var(--color-border-strong)] bg-[var(--color-surface-2)] px-2 py-1.5 text-left text-sm",
          disabled && "opacity-50 cursor-not-allowed",
        )}
      >
        {selected.length === 0 && (
          <span className="text-[var(--color-muted)] px-1">{placeholder}</span>
        )}
        {selected.map((s) => (
          <span
            key={s}
            className="inline-flex items-center gap-1 rounded-full bg-[var(--color-surface)] border border-[var(--color-border)] px-2 py-0.5 text-xs max-w-full"
          >
            <span className="truncate">{s}</span>
            <span
              role="button"
              tabIndex={0}
              className="text-[var(--color-muted)] hover:text-[var(--color-fg)]"
              onClick={(e) => {
                e.stopPropagation();
                remove(s);
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  e.stopPropagation();
                  remove(s);
                }
              }}
            >
              <X className="h-3 w-3" />
            </span>
          </span>
        ))}
        <ChevronDown className="h-4 w-4 ml-auto shrink-0 text-[var(--color-muted)]" />
      </button>

      {open && !disabled && (
        <div className="absolute z-40 mt-1 w-full rounded-[var(--radius-md)] border border-[var(--color-border-strong)] bg-[var(--color-surface)] shadow-lg p-2">
          <Input
            autoFocus
            value={q}
            placeholder="Type to filter or add…"
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && canCreate) {
                e.preventDefault();
                addCreate();
              }
              if (e.key === "Escape") setOpen(false);
            }}
          />
          <ul className="mt-2 max-h-48 overflow-y-auto space-y-0.5">
            {filtered.map((opt) => {
              const on = selected.some(
                (s) => s.toLowerCase() === opt.toLowerCase(),
              );
              return (
                <li key={opt}>
                  <button
                    type="button"
                    className={cn(
                      "w-full flex items-center gap-2 text-left px-2 py-2 rounded-md text-sm min-h-10 hover:bg-[var(--color-surface-2)]",
                      on && "bg-[var(--color-surface-2)]",
                    )}
                    onClick={() => toggle(opt)}
                  >
                    <span
                      className={cn(
                        "flex h-4 w-4 items-center justify-center rounded border",
                        on
                          ? "border-[var(--color-primary)] bg-[var(--color-primary)] text-[var(--color-primary-fg)]"
                          : "border-[var(--color-border-strong)]",
                      )}
                    >
                      {on ? <Check className="h-3 w-3" /> : null}
                    </span>
                    {opt}
                  </button>
                </li>
              );
            })}
            {canCreate && (
              <li>
                <Button
                  type="button"
                  variant="ghost"
                  className="w-full justify-start"
                  onClick={addCreate}
                >
                  <Plus className="h-4 w-4" /> Add “{q.trim()}”
                </Button>
              </li>
            )}
            {filtered.length === 0 && !canCreate && (
              <li className="px-2 py-2 text-xs text-[var(--color-muted)]">
                No matches
              </li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
}
