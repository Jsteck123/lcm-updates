import { useState } from "react";
import { Input } from "@/components/ui/input";
import { formatCurrency } from "@/lib/utils";

export function evaluateNumericExpression(raw: string): number | null {
  let s = String(raw ?? "")
    .replace(/[$,]/g, "")
    .replace(/\s*in\s*$/i, "")
    .replace(/,/g, "")
    .trim();
  if (!s || s === "-" || s === ".") return null;
  s = s.replace(/×/g, "*");
  s = s.replace(/(\d(?:\.\d+)?)\s*[xX]\s*(\d)/g, "$1*$2");
  s = s.replace(/\s+/g, "");
  if (!/^[\d+\-*/().]+$/.test(s)) return null;
  try {
    // eslint-disable-next-line no-new-func
    const n = Function(`"use strict"; return (${s});`)() as unknown;
    if (typeof n !== "number" || !Number.isFinite(n)) return null;
    return Math.round(n * 10000) / 10000;
  } catch {
    return null;
  }
}

/** Empty when 0; type 0.5 freely; supports 12*12 math on blur/Enter. */
export function SmartNumberInput({
  value,
  onValueChange,
  format = "plain",
  emptyMeans = 0,
  className,
  placeholder,
  disabled,
  autoFocus,
  onEnter,
}: {
  value: number;
  onValueChange: (n: number) => void;
  format?: "plain" | "currency" | "inches";
  emptyMeans?: number;
  className?: string;
  placeholder?: string;
  disabled?: boolean;
  autoFocus?: boolean;
  onEnter?: () => void;
}) {
  const [focused, setFocused] = useState(false);
  const [draft, setDraft] = useState("");

  function formatBlurred(n: number): string {
    if (n === 0 || n == null || Number.isNaN(n)) return "";
    if (format === "currency") return formatCurrency(n);
    if (format === "inches") {
      const s = Number.isInteger(n)
        ? String(n)
        : String(Math.round(n * 1000) / 1000);
      return `${s}"`;
    }
    return String(n);
  }

  function parseDraft(raw: string): number {
    const cleaned = raw
      .replace(/[$,]/g, "")
      .replace(/\s*in\s*$/i, "")
      .replace(/"/g, "")
      .replace(/,/g, "")
      .trim();
    if (cleaned === "" || cleaned === "-" || cleaned === ".") return emptyMeans;
    const expr = evaluateNumericExpression(cleaned);
    if (expr != null) return expr;
    const n = Number(cleaned);
    return Number.isFinite(n) ? n : emptyMeans;
  }

  function commit(raw: string) {
    const n = parseDraft(raw);
    onValueChange(n);
    if (n === emptyMeans && (!raw || !raw.trim())) setDraft("");
    else setDraft(String(n));
    return n;
  }

  const shown = focused
    ? draft
    : formatBlurred(typeof value === "number" ? value : 0);

  return (
    <Input
      type="text"
      inputMode="decimal"
      autoComplete="off"
      spellCheck={false}
      disabled={disabled}
      autoFocus={autoFocus}
      placeholder={placeholder}
      title="Type 0.5 freely. Tip: 12*12 calculates on Enter / leave field"
      className={className}
      value={shown}
      onFocus={() => {
        const n = typeof value === "number" ? value : 0;
        setDraft(n === 0 ? "" : String(n));
        setFocused(true);
      }}
      onChange={(e) => {
        const raw = e.target.value;
        setDraft(raw);
        const cleaned = raw
          .replace(/[$,]/g, "")
          .replace(/\s*in\s*$/i, "")
          .replace(/"/g, "")
          .replace(/,/g, "")
          .trim();
        if (cleaned === "" || cleaned === "-" || cleaned === ".") {
          // Don't push emptyMeans live — wait for blur so quote fill doesn't fight typing
          return;
        }
        // Incomplete decimals / leading zero for 0.5 — keep draft only
        if (
          cleaned === "0" ||
          cleaned === "-0" ||
          /^\d*\.$/.test(cleaned) ||
          /^\.\d*$/.test(cleaned) ||
          /[+\-*/.]$/.test(cleaned)
        ) {
          return;
        }
        const expr = evaluateNumericExpression(cleaned);
        if (expr != null) {
          onValueChange(expr);
          return;
        }
        const n = Number(cleaned);
        if (Number.isFinite(n)) onValueChange(n);
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          commit(draft);
          (e.target as HTMLInputElement).blur();
          onEnter?.();
        }
      }}
      onBlur={() => {
        commit(draft);
        setFocused(false);
      }}
    />
  );
}
