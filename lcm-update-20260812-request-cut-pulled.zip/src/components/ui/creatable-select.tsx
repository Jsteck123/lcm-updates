import { useEffect, useId, useState } from "react";
import { Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const CREATE_VALUE = "__create_new__";

type CreatableSelectProps = {
  value: string;
  options: string[];
  onChange: (value: string) => void;
  /** Called when user confirms a new item. Return false to cancel selection. */
  onCreate: (value: string) => boolean | void;
  placeholder?: string;
  allowEmpty?: boolean;
  emptyLabel?: string;
  createLabel?: string;
  createTitle?: string;
  createHint?: string;
  className?: string;
  disabled?: boolean;
  /** Normalize typed value before create (e.g. uppercase) */
  normalize?: (raw: string) => string;
};

/**
 * Dropdown that always ends with “Add new…” so operators can extend lists
 * without leaving the form (customers, materials, machines, etc.).
 */
export function CreatableSelect({
  value,
  options,
  onChange,
  onCreate,
  placeholder = "— Select —",
  allowEmpty = true,
  emptyLabel = "— Select —",
  createLabel = "＋ Add new…",
  createTitle = "Add new item",
  createHint,
  className,
  disabled,
  normalize = (s) => s.trim(),
}: CreatableSelectProps) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const [error, setError] = useState("");
  const titleId = useId();

  const list = uniqueOptions(options, value);

  useEffect(() => {
    if (!open) {
      setDraft("");
      setError("");
    }
  }, [open]);

  function handleSelect(next: string) {
    if (next === CREATE_VALUE) {
      setDraft(value && !list.includes(value) ? value : "");
      setOpen(true);
      return;
    }
    onChange(next);
  }

  function confirmCreate() {
    const v = normalize(draft);
    if (!v) {
      setError("Enter a value");
      return;
    }
    const ok = onCreate(v);
    if (ok === false) {
      setError("Could not add that item");
      return;
    }
    onChange(v);
    setOpen(false);
  }

  return (
    <>
      <select
        className={cn(
          "flex h-10 w-full min-h-11 rounded-[var(--radius-md)] border border-[var(--color-border-strong)] bg-[var(--color-surface-2)] px-3 py-2 text-sm text-[var(--color-fg)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary)] disabled:cursor-not-allowed disabled:opacity-50",
          className,
        )}
        value={value}
        disabled={disabled}
        onChange={(e) => handleSelect(e.target.value)}
      >
        {allowEmpty && <option value="">{emptyLabel || placeholder}</option>}
        {list.map((opt) => (
          <option key={opt} value={opt}>
            {opt}
          </option>
        ))}
        <option value={CREATE_VALUE}>{createLabel}</option>
      </select>

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-4"
          onClick={() => setOpen(false)}
        >
          <div
            role="dialog"
            aria-labelledby={titleId}
            className="w-full max-w-md rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h2 id={titleId} className="text-lg font-semibold mb-1">
              {createTitle}
            </h2>
            {createHint && (
              <p className="text-sm text-[var(--color-muted)] mb-3">{createHint}</p>
            )}
            <Input
              autoFocus
              value={draft}
              onChange={(e) => {
                setDraft(e.target.value);
                setError("");
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  confirmCreate();
                }
                if (e.key === "Escape") setOpen(false);
              }}
              placeholder="Type the new name…"
            />
            {error && (
              <p className="text-xs text-[var(--color-danger)] mt-2">{error}</p>
            )}
            <div className="flex gap-2 mt-4 justify-end">
              <Button variant="ghost" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button onClick={confirmCreate}>
                <Plus className="h-4 w-4" /> Add & select
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function uniqueOptions(options: string[], current?: string): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const raw of options) {
    const o = String(raw ?? "").trim();
    if (!o) continue;
    const key = o.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(o);
  }
  const cur = (current || "").trim();
  if (cur && !seen.has(cur.toLowerCase())) {
    out.unshift(cur);
  }
  return out;
}
