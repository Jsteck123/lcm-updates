import { cn } from "@/lib/utils";
import type { BadgeTone } from "@/lib/lcm/status-colors";

const tones: Record<BadgeTone, string> = {
  neutral: "bg-[var(--color-surface-3)] text-[var(--color-muted)]",
  success:
    "bg-[color-mix(in_oklab,var(--color-success)_14%,transparent)] text-[var(--color-success)]",
  warn: "bg-[color-mix(in_oklab,var(--color-warn)_14%,transparent)] text-[var(--color-warn)]",
  danger:
    "bg-[color-mix(in_oklab,var(--color-status-danger)_14%,transparent)] text-[var(--color-status-danger)]",
  info: "bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)] text-[var(--color-primary)]",
  running:
    "bg-[color-mix(in_oklab,var(--color-status-active)_14%,transparent)] text-[var(--color-status-active)]",
  paused:
    "bg-[color-mix(in_oklab,var(--color-status-hold)_14%,transparent)] text-[var(--color-status-hold)]",
  hold: "bg-[color-mix(in_oklab,var(--color-status-hold)_14%,transparent)] text-[var(--color-status-hold)]",
  open: "bg-[color-mix(in_oklab,var(--color-status-open)_14%,transparent)] text-[var(--color-status-open)]",
  active:
    "bg-[color-mix(in_oklab,var(--color-status-active)_14%,transparent)] text-[var(--color-status-active)]",
  ready:
    "bg-[color-mix(in_oklab,var(--color-status-ready)_14%,transparent)] text-[var(--color-status-ready)]",
  done: "bg-[color-mix(in_oklab,var(--color-status-done)_14%,transparent)] text-[var(--color-status-done)]",
  office:
    "bg-[color-mix(in_oklab,var(--color-status-office)_14%,transparent)] text-[var(--color-status-office)]",
  soon: "bg-[color-mix(in_oklab,var(--color-status-soon)_14%,transparent)] text-[var(--color-status-soon)]",
  overdue:
    "bg-[color-mix(in_oklab,var(--color-status-overdue)_14%,transparent)] text-[var(--color-status-overdue)]",
};

export function Badge({
  className,
  tone = "neutral",
  ...props
}: React.HTMLAttributes<HTMLSpanElement> & {
  tone?: BadgeTone;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
        tones[tone] || tones.neutral,
        className,
      )}
      {...props}
    />
  );
}
