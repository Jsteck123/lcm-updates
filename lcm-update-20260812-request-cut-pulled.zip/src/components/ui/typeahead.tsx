import { useEffect, useId, useMemo, useRef, useState } from "react";
import { ChevronDown, Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { normalizeSizeKey, sizesEquivalent } from "@/lib/lcm/po-material";

type TypeaheadProps = {
  value: string;
  options: string[];
  onChange: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
  /** Max suggestions shown */
  maxSuggestions?: number;
  emptyMessage?: string;
  /** Allow value not in list (default true) */
  allowCustom?: boolean;
  /** Called when user commits a value not already in options */
  onCreate?: (value: string) => void;
  autoFocus?: boolean;
  /** After Enter commits the current value */
  onEnterAfterCommit?: () => void;
};

/** Normalize shop size typing: 0.5, .5, 1/2, 3/4, .75 → same key */
function normalizeShopQuery(q: string): string {
  return normalizeSizeKey(q);
}

function optionMatchesQuery(option: string, query: string): boolean {
  const o = option.toLowerCase();
  const q = query.trim().toLowerCase();
  if (!q) return true;
  if (o.includes(q) || fuzzyMatch(o, q)) return true;
  // 3/4" ↔ .75" ↔ 0.75
  if (sizesEquivalent(option, query)) return true;
  const nq = normalizeShopQuery(q);
  const no = normalizeShopQuery(o);
  if (!nq) return true;
  if (no === nq || no.includes(nq) || nq.includes(no)) return true;
  // token-wise numeric: user .75 matches option 3/4" DIA
  const qTok = nq.split("x").filter(Boolean).map(Number);
  const oTok = no.split("x").filter(Boolean).map(Number);
  if (qTok.length && oTok.length) {
    const n = Math.min(qTok.length, oTok.length);
    let ok = true;
    for (let i = 0; i < n; i++) {
      if (Math.abs(qTok[i]! - oTok[i]!) > 0.06) {
        ok = false;
        break;
      }
    }
    if (ok) return true;
  }
  const qDigits = nq.replace(/[^0-9.x]/g, "");
  const oDigits = no.replace(/[^0-9.x]/g, "");
  if (qDigits.length >= 1 && (oDigits.includes(qDigits) || qDigits.includes(oDigits)))
    return true;
  return false;
}

function optionMatchRank(option: string, query: string): number {
  const q = query.trim().toLowerCase();
  if (!q) return 0;
  if (sizesEquivalent(option, query)) return 0; // best
  const nq = normalizeShopQuery(q);
  const no = normalizeShopQuery(option);
  if (no === nq) return 0;
  if (option.toLowerCase().startsWith(q)) return 1;
  if (no.startsWith(nq)) return 2;
  if (no.includes(nq)) return 3;
  return 4;
}

/**
 * Text field that filters options as you type (shop size notes, vendors, etc.).
 * Arrow keys + Enter to pick; free text stays if allowCustom.
 */
export function Typeahead({
  value,
  options,
  onChange,
  placeholder = "Start typing…",
  disabled,
  className,
  maxSuggestions = 40,
  emptyMessage = "No matches — keep typing to use a custom value",
  allowCustom = true,
  onCreate,
  autoFocus,
  onEnterAfterCommit,
}: TypeaheadProps) {
  const listId = useId();
  const wrapRef = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const [highlight, setHighlight] = useState(0);
  const [draft, setDraft] = useState(value);

  useEffect(() => {
    setDraft(value);
  }, [value]);

  const filtered = useMemo(() => {
    const q = draft.trim().toLowerCase();
    const seen = new Set<string>();
    const out: string[] = [];
    // Scan full list first so 3/4" is not dropped before rank-sort when user typed .75
    for (const raw of options) {
      const o = String(raw ?? "").trim();
      if (!o) continue;
      const key = o.toLowerCase();
      if (seen.has(key)) continue;
      if (q && !optionMatchesQuery(o, draft)) continue;
      seen.add(key);
      out.push(o);
    }
    if (q) {
      out.sort((a, b) => {
        const ra = optionMatchRank(a, draft);
        const rb = optionMatchRank(b, draft);
        if (ra !== rb) return ra - rb;
        return a.localeCompare(b);
      });
    }
    return out.slice(0, maxSuggestions);
  }, [options, draft, maxSuggestions]);

  const showCreate =
    allowCustom &&
    draft.trim().length > 0 &&
    !filtered.some((o) => o.toLowerCase() === draft.trim().toLowerCase());

  useEffect(() => {
    setHighlight(0);
  }, [draft, open]);

  useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (!wrapRef.current?.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  function commit(next: string) {
    const v = next.trim();
    const inList = options.some((o) => o.toLowerCase() === v.toLowerCase());
    if (v && !inList && onCreate) onCreate(v);
    onChange(v);
    setDraft(v);
    setOpen(false);
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (!open && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
      setOpen(true);
      return;
    }
    const total = filtered.length + (showCreate ? 1 : 0);
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setOpen(true);
      setHighlight((h) => Math.min(h + 1, Math.max(0, total - 1)));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setHighlight((h) => Math.max(h - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (open && total > 0) {
        if (showCreate && highlight === filtered.length) {
          commit(draft);
        } else if (filtered[highlight]) {
          commit(filtered[highlight]);
        } else {
          commit(draft);
        }
      } else {
        commit(draft);
      }
      onEnterAfterCommit?.();
    } else if (e.key === "Escape") {
      setOpen(false);
      setDraft(value);
    } else if (e.key === "Tab") {
      // keep typed value
      if (draft !== value) onChange(draft.trim());
      setOpen(false);
    }
  }

  return (
    <div ref={wrapRef} className={cn("relative", className)}>
      <div className="relative">
        <Input
          disabled={disabled}
          value={draft}
          placeholder={placeholder}
          autoComplete="off"
          spellCheck={false}
          autoFocus={autoFocus}
          role="combobox"
          aria-expanded={open}
          aria-controls={listId}
          aria-autocomplete="list"
          onFocus={() => setOpen(true)}
          onChange={(e) => {
            setDraft(e.target.value);
            setOpen(true);
            // Live update parent so form state tracks typing
            onChange(e.target.value);
          }}
          onKeyDown={onKeyDown}
          onBlur={() => {
            // slight delay so click on option registers
            window.setTimeout(() => {
              if (!wrapRef.current?.contains(document.activeElement)) {
                setOpen(false);
                if (draft.trim() !== value) onChange(draft.trim());
              }
            }, 120);
          }}
          className="pr-9"
        />
        <button
          type="button"
          tabIndex={-1}
          disabled={disabled}
          className="absolute right-2 top-1/2 -translate-y-1/2 text-[var(--color-muted)] p-1"
          onMouseDown={(e) => {
            e.preventDefault();
            setOpen((o) => !o);
          }}
          aria-label="Show size list"
        >
          <ChevronDown className="h-4 w-4" />
        </button>
      </div>

      {open && !disabled && (
        <ul
          id={listId}
          role="listbox"
          className="absolute z-40 mt-1 max-h-60 w-full overflow-auto rounded-[var(--radius-md)] border border-[var(--color-border-strong)] bg-[var(--color-surface)] shadow-lg py-1 text-sm"
        >
          {filtered.map((opt, i) => (
            <li key={opt} role="option" aria-selected={i === highlight}>
              <button
                type="button"
                className={cn(
                  "w-full text-left px-3 py-2 min-h-10 hover:bg-[var(--color-surface-2)]",
                  i === highlight && "bg-[var(--color-surface-2)]",
                )}
                onMouseDown={(e) => {
                  e.preventDefault();
                  commit(opt);
                }}
                onMouseEnter={() => setHighlight(i)}
              >
                {highlightMatch(opt, draft)}
              </button>
            </li>
          ))}
          {showCreate && (
            <li role="option" aria-selected={highlight === filtered.length}>
              <button
                type="button"
                className={cn(
                  "w-full text-left px-3 py-2 min-h-10 flex items-center gap-2 text-[var(--color-primary)] hover:bg-[var(--color-surface-2)]",
                  highlight === filtered.length && "bg-[var(--color-surface-2)]",
                )}
                onMouseDown={(e) => {
                  e.preventDefault();
                  commit(draft);
                }}
                onMouseEnter={() => setHighlight(filtered.length)}
              >
                <Plus className="h-3.5 w-3.5 shrink-0" />
                Use “{draft.trim()}”
              </button>
            </li>
          )}
          {filtered.length === 0 && !showCreate && (
            <li className="px-3 py-2 text-[var(--color-muted)] text-xs">
              {emptyMessage}
            </li>
          )}
        </ul>
      )}
    </div>
  );
}

function fuzzyMatch(hay: string, q: string): boolean {
  // all query tokens must appear (split on space/x/×)
  const tokens = q.split(/[\s×x*]+/).filter(Boolean);
  return tokens.every((t) => hay.includes(t));
}

function highlightMatch(text: string, query: string): React.ReactNode {
  const q = query.trim();
  if (!q) return text;
  const i = text.toLowerCase().indexOf(q.toLowerCase());
  if (i < 0) return text;
  return (
    <>
      {text.slice(0, i)}
      <mark className="bg-[color-mix(in_oklab,var(--color-primary)_35%,transparent)] text-inherit rounded-sm px-0.5">
        {text.slice(i, i + q.length)}
      </mark>
      {text.slice(i + q.length)}
    </>
  );
}
