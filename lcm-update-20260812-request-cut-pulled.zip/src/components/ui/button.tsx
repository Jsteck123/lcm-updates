import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-[var(--radius-md)] text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary)] focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--color-bg)] disabled:pointer-events-none disabled:opacity-45 active:scale-[0.98]",
  {
    variants: {
      variant: {
        default:
          "bg-[var(--color-primary)] text-[var(--color-primary-fg)] hover:brightness-110",
        secondary:
          "bg-[var(--color-surface-2)] text-[var(--color-fg)] border border-[var(--color-border-strong)] hover:bg-[var(--color-surface-3)]",
        outline:
          "border border-[var(--color-border-strong)] bg-transparent hover:bg-[var(--color-surface-2)]",
        ghost: "hover:bg-[var(--color-surface-2)] text-[var(--color-fg)]",
        danger:
          "bg-[var(--color-danger)] text-white hover:brightness-110",
        success:
          "bg-[var(--color-success)] text-[#04150c] hover:brightness-110",
        warn: "bg-[var(--color-warn)] text-[#1a1205] hover:brightness-110",
      },
      size: {
        default: "h-10 px-4 py-2 min-h-11",
        sm: "h-8 rounded-[var(--radius-sm)] px-3 text-xs min-h-9",
        lg: "h-12 rounded-[var(--radius-lg)] px-6 text-base min-h-12",
        icon: "h-10 w-10 min-h-11 min-w-11",
      },
    },
    defaultVariants: { variant: "default", size: "default" },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, ...props }, ref) => (
    <button
      ref={ref}
      className={cn(buttonVariants({ variant, size, className }))}
      {...props}
    />
  ),
);
Button.displayName = "Button";
