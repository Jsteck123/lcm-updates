import { useState, type ReactNode } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

/** Card that can start collapsed to calm busy pages. */
export function CollapsibleSection({
  title,
  description,
  defaultOpen = false,
  badge,
  children,
  className,
  forceOpen,
}: {
  title: ReactNode;
  description?: ReactNode;
  defaultOpen?: boolean;
  badge?: string | number | null;
  children: ReactNode;
  className?: string;
  /** When true, stays open (e.g. floor reports waiting). */
  forceOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  const shown = forceOpen || open;

  return (
    <Card className={className}>
      <CardHeader className="pb-2">
        <button
          type="button"
          className="flex w-full items-start justify-between gap-3 text-left"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={shown}
        >
          <div className="min-w-0 space-y-1">
            <CardTitle className="flex flex-wrap items-center gap-2 text-base">
              {title}
              {badge != null && badge !== "" && Number(badge) !== 0 ? (
                <Badge tone="warn">{badge}</Badge>
              ) : null}
            </CardTitle>
            {description ? (
              <CardDescription className="text-xs">{description}</CardDescription>
            ) : null}
          </div>
          <ChevronDown
            className={cn(
              "h-5 w-5 shrink-0 text-[var(--color-muted)] transition-transform mt-0.5",
              shown && "rotate-180",
            )}
          />
        </button>
      </CardHeader>
      {shown ? <CardContent className="pt-0">{children}</CardContent> : null}
    </Card>
  );
}
