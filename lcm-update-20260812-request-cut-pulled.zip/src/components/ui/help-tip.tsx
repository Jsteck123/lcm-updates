import { useEffect, useId, useMemo, useRef, useState, type ReactNode } from "react";
import { CircleHelp, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useHelpTips } from "@/hooks/use-help-tips";
import { HELP_TIPS, type HelpTipId } from "@/lib/lcm/help-tips";
import { Button } from "@/components/ui/button";
import { useLcmStore } from "@/store/lcm-store";
import { getOperatorByEmail } from "@/lib/lcm/permissions";

type Props = {
  id: HelpTipId | string;
  /** Override catalog title */
  title?: string;
  /** Override catalog body */
  body?: string;
  className?: string;
  /** side of the popover */
  side?: "top" | "bottom" | "left" | "right";
  /** Optional label next to icon */
  label?: string;
};

/**
 * Small blue ? — hover or tap for instructions.
 * "Hide this tip" removes it for this user on this PC.
 * Catalog tips marked audience: "admin" never show for operators.
 */
export function HelpTip({
  id,
  title,
  body,
  className,
  side = "bottom",
  label,
}: Props) {
  const { showTip, hideTip, tipsEnabled } = useHelpTips();
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  const isAdmin = useMemo(() => {
    const me = getOperatorByEmail(operators, email);
    return me?.role === "admin";
  }, [operators, email]);

  const [open, setOpen] = useState(false);
  const wrapRef = useRef<HTMLSpanElement>(null);
  const panelId = useId();

  const catalog =
    id in HELP_TIPS
      ? HELP_TIPS[id as HelpTipId]
      : null;
  const tipTitle = title || catalog?.title || "Help";
  const tipBody = body || catalog?.body || "";
  const tipAudience =
    catalog && "audience" in catalog
      ? (catalog as { audience?: string }).audience
      : undefined;

  useEffect(() => {
    if (!open) return;
    function onDoc(e: MouseEvent) {
      if (!wrapRef.current?.contains(e.target as Node)) setOpen(false);
    }
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  // Floor never sees admin-only catalog tips (rates, pricing import, etc.)
  if (tipAudience === "admin" && !isAdmin) return null;
  if (!tipsEnabled || !showTip(id) || !tipBody) return null;

  const sideClass =
    side === "top"
      ? "bottom-full left-1/2 -translate-x-1/2 mb-2"
      : side === "left"
        ? "right-full top-1/2 -translate-y-1/2 mr-2"
        : side === "right"
          ? "left-full top-1/2 -translate-y-1/2 ml-2"
          : "top-full left-1/2 -translate-x-1/2 mt-2";

  return (
    <span
      ref={wrapRef}
      className={cn("relative inline-flex items-center gap-1 print:hidden", className)}
    >
      <button
        type="button"
        className={cn(
          "inline-flex items-center justify-center rounded-full",
          "h-6 w-6 min-h-6 min-w-6 text-[var(--color-primary)]",
          "hover:bg-[color-mix(in_oklab,var(--color-primary)_18%,transparent)]",
          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary)]",
        )}
        aria-label={`Help: ${tipTitle}`}
        aria-expanded={open}
        aria-controls={panelId}
        onMouseEnter={() => setOpen(true)}
        onFocus={() => setOpen(true)}
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setOpen((v) => !v);
        }}
      >
        <CircleHelp className="h-4 w-4" />
      </button>
      {label && (
        <span className="text-[10px] text-[var(--color-muted)]">{label}</span>
      )}

      {open && (
        <span
          id={panelId}
          role="tooltip"
          className={cn(
            "absolute z-[80] w-64 sm:w-72 rounded-[var(--radius-md)] border border-[var(--color-border-strong)]",
            "bg-[var(--color-surface)] text-[var(--color-fg)] shadow-xl p-3",
            sideClass,
          )}
          onMouseEnter={() => setOpen(true)}
          onMouseLeave={() => setOpen(false)}
        >
          <span className="flex items-start justify-between gap-2">
            <span className="text-xs font-semibold leading-snug">{tipTitle}</span>
            <button
              type="button"
              className="text-[var(--color-muted)] hover:text-[var(--color-fg)] p-0.5"
              aria-label="Close"
              onClick={() => setOpen(false)}
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </span>
          <span className="mt-1.5 block text-[11px] leading-relaxed text-[var(--color-muted)]">
            {tipBody}
          </span>
          <span className="mt-2.5 flex justify-end">
            <Button
              type="button"
              size="sm"
              variant="ghost"
              className="h-7 text-[11px] text-[var(--color-muted)]"
              onClick={() => {
                hideTip(id);
                setOpen(false);
              }}
            >
              Hide this tip
            </Button>
          </span>
        </span>
      )}
    </span>
  );
}

/** Inline row: children + help tip */
export function WithHelp({
  id,
  title,
  body,
  children,
  className,
  side,
}: Props & { children: ReactNode }) {
  return (
    <span className={cn("inline-flex items-center gap-1.5", className)}>
      {children}
      <HelpTip id={id} title={title} body={body} side={side} />
    </span>
  );
}
