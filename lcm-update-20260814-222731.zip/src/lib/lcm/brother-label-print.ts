/** Brother QL-810W tape sizes (die-cut / continuous). */

export const QL_TAPES = [
  {
    id: "dk2210",
    label: "DK-2210 1.1 in continuous × 100 ft",
    w: "1.1in",
    h: "1.0in",
    kind: "continuous" as const,
    windowsPaper: "29mm Continuous",
  },
  {
    id: "dk2210-short",
    label: "DK-2210 same roll · shorter 0.75 in cut",
    w: "1.1in",
    h: "0.75in",
    kind: "continuous" as const,
    windowsPaper: "29mm Continuous",
  },
  {
    id: "dk1201",
    label: "DK-1201 die-cut 1.1 × 3.5 in",
    w: "1.1in",
    h: "3.5in",
    kind: "diecut" as const,
    windowsPaper: "29mm x 90mm",
  },
  {
    id: "dk1209",
    label: "DK-1209 die-cut 1.1 × 2.4 in",
    w: "1.1in",
    h: "2.4in",
    kind: "diecut" as const,
    windowsPaper: "29mm x 62mm",
  },
  {
    id: "custom116",
    label: "1.1 × 1.6 in (Windows list)",
    w: "1.1in",
    h: "1.6in",
    kind: "diecut" as const,
    windowsPaper: "29mm x 42mm",
  },
  {
    id: "dk1202",
    label: "DK-1202 Shipping 2.4 × 3.9 in",
    w: "2.4in",
    h: "3.9in",
    kind: "diecut" as const,
    windowsPaper: "62mm x 100mm",
  },
  {
    id: "dk2205",
    label: "DK-2205 2.4 in continuous",
    w: "2.4in",
    h: "2.0in",
    kind: "continuous" as const,
    windowsPaper: "62mm Continuous",
  },
] as const;

export type QlTapeId = (typeof QL_TAPES)[number]["id"];
export type QlTape = (typeof QL_TAPES)[number];

const TAPE_STORE_KEY = "lcm-ql-tape";

export function tapeById(id: string): QlTape {
  return QL_TAPES.find((t) => t.id === id) || QL_TAPES[0]!;
}

export function loadSavedTapeId(): QlTapeId {
  if (typeof window === "undefined") return "dk2210";
  try {
    const v = localStorage.getItem(TAPE_STORE_KEY) || "";
    if (QL_TAPES.some((t) => t.id === v)) return v as QlTapeId;
  } catch {
    /* ignore */
  }
  return "dk2210";
}

export function saveTapeId(id: string) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(TAPE_STORE_KEY, id);
  } catch {
    /* ignore */
  }
}

function esc(s: string) {
  return String(s || "")
    .replace(/&/g, "\u0026amp;")
    .replace(/</g, "\u0026lt;")
    .replace(/>/g, "\u0026gt;")
    .replace(/"/g, "\u0026quot;");
}

export type StockLabelItem = {
  barcode: string;
  qrDataUrl: string;
  line1: string;
  line2: string;
  line3?: string;
};

export function isCompactTape(tape: Pick<QlTape, "h" | "kind">) {
  return tape.kind === "continuous" || parseFloat(tape.h) <= 1.15;
}

function labelCss(tape: QlTape) {
  const compact = isCompactTape(tape);
  const page =
    "@page { size: " +
    tape.w +
    " " +
    tape.h +
    "; margin: 0; }" +
    "html, body { margin: 0; padding: 0; background: #fff; color: #000; }" +
    "* { -webkit-print-color-adjust: exact; print-color-adjust: exact; }";
  const last =
    ".label:last-child { page-break-after: auto; break-after: auto; }";
  if (compact) {
    return (
      page +
      ".label { width: " +
      tape.w +
      "; height: " +
      tape.h +
      "; box-sizing: border-box; padding: 0.05in 0.06in 0.05in 0.04in; display: flex; flex-direction: row; align-items: center; gap: 0.05in; overflow: hidden; font-family: Arial, Helvetica, sans-serif; page-break-after: always; break-after: page; }" +
      last +
      ".qr { width: 0.55in; height: 0.55in; object-fit: contain; flex-shrink: 0; }" +
      ".text { flex: 1; min-width: 0; display: flex; flex-direction: column; justify-content: center; text-align: left; line-height: 1.08; overflow: hidden; }" +
      ".code { font-family: Consolas, monospace; font-size: 10px; font-weight: 800; letter-spacing: 0; white-space: nowrap; }" +
      ".mat { font-size: 9px; font-weight: 800; }" +
      ".size { font-size: 8px; font-weight: 700; }" +
      ".loc { font-size: 7px; font-weight: 600; }"
    );
  }
  return (
    page +
    ".label { width: " +
    tape.w +
    "; height: " +
    tape.h +
    "; box-sizing: border-box; padding: 0.08in 0.06in; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; overflow: hidden; font-family: Arial, Helvetica, sans-serif; page-break-after: always; break-after: page; }" +
    last +
    ".name { font-size: 7px; font-weight: 700; letter-spacing: 0.03em; }" +
    ".code { font-family: Consolas, monospace; font-size: 9px; font-weight: 700; margin-top: 0.03in; }" +
    ".qr { width: 0.9in; height: 0.9in; object-fit: contain; margin: 0.05in 0; }" +
    ".mat { font-size: 8px; font-weight: 700; }" +
    ".size { font-size: 7px; }" +
    ".loc { font-size: 6px; margin-top: 0.02in; }"
  );
}

function labelHtml(item: StockLabelItem, compact: boolean) {
  const qr = item.qrDataUrl
    ? '<img class="qr" src="' + item.qrDataUrl + '" alt=""/>'
    : "";
  const loc = item.line3 ? '<div class="loc">' + esc(item.line3) + "</div>" : "";
  if (compact) {
    return (
      '<div class="label">' +
      qr +
      '<div class="text">' +
      '<div class="code">' +
      esc(item.barcode) +
      "</div>" +
      '<div class="mat">' +
      esc(item.line1) +
      "</div>" +
      '<div class="size">' +
      esc(item.line2) +
      "</div>" +
      loc +
      "</div></div>"
    );
  }
  return (
    '<div class="label">' +
    '<div class="name">LAKE COUNTRY MACHINE</div>' +
    '<div class="code">' +
    esc(item.barcode) +
    "</div>" +
    qr +
    '<div class="mat">' +
    esc(item.line1) +
    "</div>" +
    '<div class="size">' +
    esc(item.line2) +
    "</div>" +
    loc +
    "</div>"
  );
}

function openPrintHtml(html: string): { ok: boolean; error?: string } {
  if (typeof document === "undefined") {
    return { ok: false, error: "Print is only available in the app window" };
  }
  document.querySelectorAll("iframe[data-lcm-label-print]").forEach((el) => el.remove());
  const iframe = document.createElement("iframe");
  iframe.setAttribute("data-lcm-label-print", "1");
  iframe.setAttribute("aria-hidden", "true");
  iframe.style.position = "fixed";
  iframe.style.right = "0";
  iframe.style.bottom = "0";
  iframe.style.width = "0";
  iframe.style.height = "0";
  iframe.style.border = "0";
  document.body.appendChild(iframe);
  const doc = iframe.contentDocument;
  const win = iframe.contentWindow;
  if (!doc || !win) {
    iframe.remove();
    return { ok: false, error: "Could not open print frame" };
  }
  const htmlNoAuto = html.replace(/<script>[\s\S]*?<\/script>/g, "");
  doc.open();
  doc.write(htmlNoAuto);
  doc.close();

  const cleanup = () => {
    window.setTimeout(() => iframe.remove(), 1500);
  };
  win.addEventListener("afterprint", cleanup);
  const start = () => {
    try {
      win.focus();
      win.print();
    } catch {
      cleanup();
    }
  };
  const imgs = Array.from(doc.images);
  if (imgs.length === 0) {
    window.setTimeout(start, 200);
  } else {
    let left = imgs.length;
    const tick = () => {
      left -= 1;
      if (left <= 0) window.setTimeout(start, 150);
    };
    imgs.forEach((img) => {
      if (img.complete) tick();
      else {
        img.addEventListener("load", tick);
        img.addEventListener("error", tick);
      }
    });
  }
  return { ok: true };
}

export function printBrotherSampleLabel(opts: {
  tapeId: string;
  barcode: string;
  qrDataUrl: string;
  line1: string;
  line2: string;
}): { ok: boolean; error?: string } {
  return printBrotherStockLabels(opts.tapeId, [
    {
      barcode: opts.barcode,
      qrDataUrl: opts.qrDataUrl,
      line1: opts.line1,
      line2: opts.line2,
    },
  ]);
}

export function printBrotherStockLabels(
  tapeId: string,
  items: StockLabelItem[],
): { ok: boolean; error?: string } {
  if (!items.length) return { ok: false, error: "No labels to print" };
  const tape = tapeById(tapeId);
  const title = items.length === 1 ? items[0]!.barcode : String(items.length) + " stock labels";
  const body = items.map((item) => labelHtml(item, isCompactTape(tape))).join("");
  const html =
    "<!doctype html><html><head><meta charset=\"utf-8\"/><title>" +
    esc(title) +
    "</title><style>" +
    labelCss(tape) +
    "</style></head><body>" +
    body +
    "<script>window.onload=function(){setTimeout(function(){window.print();},300);};</script></body></html>";
  return openPrintHtml(html);
}
