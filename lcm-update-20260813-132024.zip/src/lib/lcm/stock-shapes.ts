/**
 * Shape-aware stock dimensions for quoting / inventory.
 *
 * Stored fields (stable for DB + PO match):
 *   dimX, dimY, dimZ          — cross-section / blank geometry
 *   rawMaterialLength         — purchasable stock unit size (bar length, sheet side, etc.)
 *   partLengthEach            — length (or size) consumed per finished part
 *
 * Cost formula still uses: material $ × (partLengthEach / rawMaterialLength) × material %
 * so rawMaterialLength and partLengthEach must share the same unit (usually inches along bar,
 * or any consistent "stock units" for sheet if you treat both as area).
 */

export type DimKey = "dimX" | "dimY" | "dimZ" | "rawMaterialLength" | "partLengthEach";

export type ShapeField = {
  key: DimKey;
  label: string;
  hint?: string;
};

export type ShapeProfile = {
  id: string;
  match: (shape: string) => boolean;
  title: string;
  summary: string;
  /** Cross-section / blank size */
  section: ShapeField[];
  /** How stock is bought and cut */
  cut: ShapeField[];
};

const lower = (s: string) => (s || "").toLowerCase();

export const SHAPE_PROFILES: ShapeProfile[] = [
  {
    id: "round",
    match: (s) => {
      const t = lower(s);
      if (
        t.includes("tube") ||
        t.includes("flat") ||
        t.includes("rect") ||
        t.includes("square") ||
        t.includes("hex") ||
        /\bangle\b/.test(t) ||
        t.includes("channel")
      )
        return false;
      return (
        (t.includes("round") && !t.includes("tube")) ||
        t === "round stock" ||
        t === "bar" ||
        t === "bar stock"
      );
    },
    title: "Round / bar",
    summary: "Stock diameter + full bar length you pull from the rack",
    section: [
      { key: "dimX", label: "Stock diameter", hint: "Bar OD on the rack" },
    ],
    cut: [
      {
        key: "partLengthEach",
        label: "Stock used per part",
        hint: "How much of the bar each part eats (for buy qty)",
      },
      {
        key: "rawMaterialLength",
        label: "Stock bar length",
        hint: "Length of the bar you buy / pull from the rack",
      },
    ],
  },
  {
    id: "hex",
    match: (s) => lower(s).includes("hex"),
    title: "Hex stock",
    summary: "Across-flats + cut length + bar length",
    section: [
      { key: "dimX", label: "Across flats", hint: "Hex AF size" },
    ],
    cut: [
      {
        key: "partLengthEach",
        label: "Cut length / part",
        hint: "Bar used per part",
      },
      {
        key: "rawMaterialLength",
        label: "Bar length (stock)",
        hint: "Purchased bar length",
      },
    ],
  },
  {
    id: "square",
    match: (s) => {
      const t = lower(s);
      return t.includes("square") && !t.includes("tube");
    },
    title: "Square stock",
    summary: "Width × height + cut length + bar length",
    section: [
      { key: "dimX", label: "Width", hint: "Cross-section width" },
      { key: "dimY", label: "Height", hint: "Cross-section height (same as width if square)" },
    ],
    cut: [
      {
        key: "partLengthEach",
        label: "Cut length / part",
        hint: "Bar used per part",
      },
      {
        key: "rawMaterialLength",
        label: "Bar length (stock)",
        hint: "Purchased bar length",
      },
    ],
  },
  {
    id: "round-tube",
    match: (s) => {
      const t = lower(s);
      return t.includes("tube") && (t.includes("round") || !t.includes("square"));
    },
    title: "Round tube",
    summary: "OD + wall (or ID) + cut length + stick length",
    section: [
      { key: "dimX", label: "Outside diameter (OD)", hint: "Tube OD" },
      { key: "dimY", label: "Wall thickness", hint: "Or leave blank if not needed for quote" },
      { key: "dimZ", label: "Inside diameter (ID)", hint: "Optional" },
    ],
    cut: [
      {
        key: "partLengthEach",
        label: "Cut length / part",
        hint: "Tube used per part",
      },
      {
        key: "rawMaterialLength",
        label: "Stick length (stock)",
        hint: "Length of tube stick you buy",
      },
    ],
  },
  {
    id: "square-tube",
    match: (s) => lower(s).includes("square") && lower(s).includes("tube"),
    title: "Square tube",
    summary: "Outside width × height + wall + cut + stick",
    section: [
      { key: "dimX", label: "Outside width", hint: "Tube OD width" },
      { key: "dimY", label: "Outside height", hint: "Tube OD height" },
      { key: "dimZ", label: "Wall thickness", hint: "Optional" },
    ],
    cut: [
      {
        key: "partLengthEach",
        label: "Cut length / part",
        hint: "Tube used per part",
      },
      {
        key: "rawMaterialLength",
        label: "Stick length (stock)",
        hint: "Purchased stick length",
      },
    ],
  },
  {
    id: "angle",
    match: (s) => {
      const t = lower(s);
      if (t.includes("rect")) return false; // "rectangle" contains "angle"
      return /\bangle\b/.test(t) || t === "angle stock" || t.startsWith("angle ");
    },
    title: "Angle stock",
    summary: "Leg A × leg B × thickness + cut + bar",
    section: [
      { key: "dimX", label: "Leg A", hint: "First leg" },
      { key: "dimY", label: "Leg B", hint: "Second leg" },
      { key: "dimZ", label: "Thickness", hint: "Angle thickness" },
    ],
    cut: [
      {
        key: "partLengthEach",
        label: "Cut length / part",
        hint: "Angle used per part",
      },
      {
        key: "rawMaterialLength",
        label: "Bar length (stock)",
        hint: "Purchased angle length",
      },
    ],
  },
  {
    id: "rectangular",
    match: (s) => {
      const t = lower(s);
      if (t.includes("tube")) return false;
      return t.includes("rect");
    },
    title: "Rectangular stock",
    summary: "Thickness × width + cut length + bar length (e.g. 0.5\" × 1\" × 144\")",
    section: [
      { key: "dimX", label: "Thickness", hint: 'e.g. 0.5"' },
      { key: "dimY", label: "Width", hint: 'e.g. 1"' },
    ],
    cut: [
      {
        key: "partLengthEach",
        label: "Cut length / part",
        hint: "How much bar each blank uses",
      },
      {
        key: "rawMaterialLength",
        label: "Bar length (stock)",
        hint: "Full stick you buy (often 144\")",
      },
    ],
  },
  {
    id: "flat-bar",
    match: (s) => {
      const t = lower(s);
      return t.includes("flat") && !t.includes("sheet") && !t.includes("plate");
    },
    title: "Flat bar",
    summary: "Thickness × width + cut length + bar length",
    section: [
      { key: "dimX", label: "Thickness", hint: "Flat bar thickness (up to 5\"+)" },
      { key: "dimY", label: "Width", hint: "Flat bar width" },
    ],
    cut: [
      {
        key: "partLengthEach",
        label: "Cut length / part",
        hint: "Bar used per part",
      },
      {
        key: "rawMaterialLength",
        label: "Bar length (stock)",
        hint: "Purchased bar length",
      },
    ],
  },
  {
    id: "channel",
    match: (s) => lower(s).includes("channel") || lower(s).includes("beam"),
    title: "Channel / beam",
    summary: "Depth / designation + cut + stick",
    section: [
      { key: "dimX", label: "Depth / size", hint: "Channel depth or designation" },
      { key: "dimY", label: "Weight / flange", hint: "Optional weight class" },
    ],
    cut: [
      {
        key: "partLengthEach",
        label: "Cut length / part",
        hint: "Used per part",
      },
      {
        key: "rawMaterialLength",
        label: "Stick length (stock)",
        hint: "Purchased length",
      },
    ],
  },
  {
    id: "pipe",
    match: (s) => lower(s).includes("pipe") && !lower(s).includes("tube"),
    title: "Pipe",
    summary: "NPS + schedule + cut + stick",
    section: [
      { key: "dimX", label: "NPS / OD", hint: "Nominal pipe size or OD" },
      { key: "dimY", label: "Schedule / wall", hint: "Sch 40, wall, etc." },
    ],
    cut: [
      {
        key: "partLengthEach",
        label: "Cut length / part",
        hint: "Pipe used per part",
      },
      {
        key: "rawMaterialLength",
        label: "Stick length (stock)",
        hint: "Purchased stick",
      },
    ],
  },
  {
    id: "sheet",
    match: (s) => {
      const t = lower(s);
      return t.includes("sheet") || t.includes("plate");
    },
    title: "Sheet / plate",
    summary: "Thickness + blank size + full sheet size (same unit for cost)",
    section: [
      { key: "dimZ", label: "Thickness", hint: "Plate / sheet thickness" },
      { key: "dimX", label: "Blank width", hint: "Part blank width" },
      { key: "dimY", label: "Blank length", hint: "Part blank length" },
    ],
    cut: [
      {
        key: "partLengthEach",
        label: "Blank size (cost unit)",
        hint: "Usually blank area or one edge — must match stock unit below",
      },
      {
        key: "rawMaterialLength",
        label: "Sheet size (cost unit)",
        hint: "Full sheet in same unit as blank (area or length)",
      },
    ],
  },
];

const FALLBACK: ShapeProfile = {
  id: "generic",
  match: () => true,
  title: "Custom shape",
  summary: "X / Y / Z section + cut length + stock length",
  section: [
    { key: "dimX", label: "Size X", hint: "Primary cross-section" },
    { key: "dimY", label: "Size Y", hint: "Secondary" },
    { key: "dimZ", label: "Size Z", hint: "Third dimension" },
  ],
  cut: [
    {
      key: "partLengthEach",
      label: "Size used / part",
      hint: "Amount of stock each part uses",
    },
    {
      key: "rawMaterialLength",
      label: "Stock size (purchased)",
      hint: "Full stock unit in the same unit as above",
    },
  ],
};

export function profileForShape(shape: string): ShapeProfile {
  for (const p of SHAPE_PROFILES) {
    if (p.match(shape)) return p;
  }
  return FALLBACK;
}

/** Flat sheet or plate — blanks, not bar sticks. */
export function isSheetOrPlate(shape: string): boolean {
  const t = (shape || "").toLowerCase();
  return t.includes("sheet") || t.includes("plate");
}

/** Which dim keys this shape uses (for UI + validation) */
export function activeDimKeys(shape: string): DimKey[] {
  const p = profileForShape(shape);
  const keys = new Set<DimKey>();
  for (const f of [...p.section, ...p.cut]) keys.add(f.key);
  return [...keys];
}
