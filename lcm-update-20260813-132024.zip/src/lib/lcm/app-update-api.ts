import { createServerFn } from "@tanstack/react-start";

export const getAppUpdateInfo = createServerFn({ method: "GET" }).handler(
  async () => {
    const { getInstalledUpdateInfo } = await import("./app-update.server");
    return { ok: true as const, ...getInstalledUpdateInfo() };
  },
);

export const applyAppUpdate = createServerFn({ method: "POST" })
  .validator((data: { base64: string; fileName?: string; token?: string }) => data)
  .handler(async ({ data }) => {
    const { verifyShopToken } = await import("./shop-session.server");
    const session = verifyShopToken(data.token);
    if (!session) {
      return {
        ok: false as const,
        error: "Unlock with your admin PIN first (Switch user / PIN on this PC).",
      };
    }
    if (session.role !== "admin") {
      return { ok: false as const, error: "Admin only" };
    }
    const { applyUpdateFromBase64 } = await import("./app-update.server");
    return applyUpdateFromBase64(data.base64 || "", data.fileName || "update.zip");
  });
