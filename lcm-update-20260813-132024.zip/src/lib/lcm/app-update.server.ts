/**
 * Safe in-app updates: apply an LCM update zip without touching shop data/.
 */
import fs from "node:fs";
import path from "node:path";
import { extractZipFile } from "./zip-extract.server";
import { createBackup } from "./backup.server";

const APP_ID = "lcm-data-management";
const ROOT = process.cwd();

/** Paths that may be replaced from an update package */
const ALLOWED_PREFIXES = [
  "src/",
  "public/",
  "scripts/",
  "package.json",
  "package-lock.json",
  "vite.config.ts",
  "tsconfig.json",
  "startup.sh",
  "eslint.config.mjs",
  ".prettierrc",
  "AGENTS.project.md",
];

/** Never write under these (even if present in zip) */
const BLOCKED_PREFIXES = [
  "data/",
  "node_modules/",
  ".git/",
  ".env",
  "attachments/",
  "screenshots/",
];

export type UpdateManifest = {
  appId: string;
  format?: number;
  version: string;
  createdAt?: string;
  note?: string;
  include?: string[];
};

export type ApplyUpdateResult =
  | {
      ok: true;
      version: string;
      note: string;
      filesUpdated: number;
      paths: string[];
      needsNpmInstall: boolean;
      restartRequired: boolean;
    }
  | { ok: false; error: string };

function ensureDir(p: string) {
  fs.mkdirSync(p, { recursive: true });
}

function isBlocked(rel: string): boolean {
  const n = rel.replace(/\\/g, "/").replace(/^\.\//, "");
  if (n.includes("..")) return true;
  if (n.startsWith("/") || /^[a-zA-Z]:/.test(n)) return true;
  for (const b of BLOCKED_PREFIXES) {
    if (n === b.replace(/\/$/, "") || n.startsWith(b)) return true;
  }
  return false;
}

function isAllowed(rel: string): boolean {
  const n = rel.replace(/\\/g, "/").replace(/^\.\//, "");
  if (isBlocked(n)) return false;
  // Never write nested update zips / archives into the app (would grow forever)
  if (/\.(zip|7z|rar|tar|gz)$/i.test(n)) return false;
  for (const a of ALLOWED_PREFIXES) {
    if (a.endsWith("/")) {
      if (n === a.slice(0, -1) || n.startsWith(a)) return true;
    } else if (n === a) return true;
  }
  return false;
}

function copyFileSafe(from: string, to: string) {
  ensureDir(path.dirname(to));
  fs.copyFileSync(from, to);
}

function walkFiles(dir: string, base = dir): string[] {
  const out: string[] = [];
  if (!fs.existsSync(dir)) return out;
  for (const name of fs.readdirSync(dir)) {
    const abs = path.join(dir, name);
    const st = fs.statSync(abs);
    if (st.isDirectory()) out.push(...walkFiles(abs, base));
    else out.push(path.relative(base, abs));
  }
  return out;
}

function readManifest(extractDir: string): UpdateManifest | null {
  const p = path.join(extractDir, "lcm-update.json");
  if (!fs.existsSync(p)) return null;
  try {
    return JSON.parse(fs.readFileSync(p, "utf8")) as UpdateManifest;
  } catch {
    return null;
  }
}

function unzipTo(zipPath: string, dest: string): { ok: true } | { ok: false; error: string } {
  ensureDir(dest);
  // Pure JS extract — works on Windows host PCs (no system `unzip` required)
  const r = extractZipFile(zipPath, dest);
  if (!r.ok) {
    return { ok: false, error: (r.error || "unzip failed").slice(0, 400) };
  }
  return { ok: true };
}

export function getInstalledUpdateInfo(): {
  version: string | null;
  appliedAt: string | null;
  note: string | null;
} {
  const p = path.join(ROOT, "data", "updates", "installed.json");
  try {
    if (!fs.existsSync(p)) return { version: null, appliedAt: null, note: null };
    const j = JSON.parse(fs.readFileSync(p, "utf8")) as {
      version?: string;
      appliedAt?: string;
      note?: string;
    };
    return {
      version: j.version || null,
      appliedAt: j.appliedAt || null,
      note: j.note || null,
    };
  } catch {
    return { version: null, appliedAt: null, note: null };
  }
}

/**
 * Apply update from base64 zip bytes (from browser file picker).
 */
export function applyUpdateFromBase64(
  base64: string,
  fileName: string,
): ApplyUpdateResult {
  if (!base64 || base64.length < 100) {
    return { ok: false, error: "Empty or invalid update file — choose the full lcm-update-*.zip (not a folder or partial download)" };
  }

  const updatesRoot = path.join(ROOT, "data", "updates");
  ensureDir(updatesRoot);
  const stamp = Date.now().toString(36);
  const zipPath = path.join(updatesRoot, `incoming-${stamp}.zip`);
  const extractDir = path.join(updatesRoot, `extract-${stamp}`);

  try {
    const buf = Buffer.from(base64, "base64");
    // ZIP magic
    if (buf.length < 4 || buf[0] !== 0x50 || buf[1] !== 0x4b) {
      return { ok: false, error: "Not a zip file — use the lcm-update-*.zip package" };
    }
    fs.writeFileSync(zipPath, buf);

    // Host-side safety copy of shop DB before any program files are replaced.
    // Never writes into data/ from the package; this only snapshots lcm-shop.json.
    try {
      createBackup("pre-update");
    } catch {
      /* Settings also requires a successful client backup before calling this */
    }

    const uz = unzipTo(zipPath, extractDir);
    if (!uz.ok) return uz;

    // Support zip with single top folder
    let rootDir = extractDir;
    const top = fs.readdirSync(extractDir);
    if (
      top.length === 1 &&
      fs.statSync(path.join(extractDir, top[0]!)).isDirectory() &&
      !fs.existsSync(path.join(extractDir, "lcm-update.json"))
    ) {
      rootDir = path.join(extractDir, top[0]!);
    }

    const manifest = readManifest(rootDir);
    if (!manifest) {
      return {
        ok: false,
        error: "Missing lcm-update.json — this is not an LCM update package",
      };
    }
    if (manifest.appId !== APP_ID) {
      return {
        ok: false,
        error: `Wrong package (appId ${manifest.appId || "?"}). Expected ${APP_ID}`,
      };
    }
    if (!manifest.version) {
      return { ok: false, error: "Update package has no version" };
    }

    const allFiles = walkFiles(rootDir).filter(
      (f) => f.replace(/\\/g, "/") !== "lcm-update.json",
    );

    const applied: string[] = [];
    let needsNpmInstall = false;

    for (const rel of allFiles) {
      const norm = rel.replace(/\\/g, "/");
      if (!isAllowed(norm)) continue;
      const from = path.join(rootDir, rel);
      const to = path.join(ROOT, rel);
      copyFileSafe(from, to);
      applied.push(norm);
      if (norm === "package.json" || norm === "package-lock.json") {
        needsNpmInstall = true;
      }
    }

    if (!applied.length) {
      return {
        ok: false,
        error: "No allowed files found in package (nothing to update)",
      };
    }

    const installed = {
      version: manifest.version,
      appliedAt: new Date().toISOString(),
      note: manifest.note || "",
      fileName: fileName || "update.zip",
      filesUpdated: applied.length,
      paths: applied.slice(0, 200),
    };
    fs.writeFileSync(
      path.join(updatesRoot, "installed.json"),
      JSON.stringify(installed, null, 2),
    );

    // Keep last zip for audit; clean extract
    try {
      fs.rmSync(extractDir, { recursive: true, force: true });
    } catch {
      /* ignore */
    }

    return {
      ok: true,
      version: manifest.version,
      note: manifest.note || "",
      filesUpdated: applied.length,
      paths: applied.slice(0, 40),
      needsNpmInstall,
      restartRequired: true,
    };
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : "Update failed",
    };
  }
}
