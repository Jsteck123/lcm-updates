import { useState } from "react";
import { Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { AppSettings, PurchaseOrder } from "@/lib/lcm/types";
import { formatCurrency, formatDate, uid } from "@/lib/utils";
import { emptyPoLine, emptyPurchaseOrder, computeOrderNeeds } from "@/lib/lcm/po";
import { INVENTORY_UNITS } from "@/lib/lcm/inventory";
import { Link } from "@tanstack/react-router";

export function MaterialBuysPanel({
  purchaseOrders,
  materials,
  shapes,
  settings,
  needs,
  createPurchaseOrder,
  upsertPurchaseOrder,
  receivePoLine,
  addCustomListItem,
}: {
  purchaseOrders: import("@/lib/lcm/types").PurchaseOrder[];
  materials: string[];
  shapes: string[];
  settings: import("@/lib/lcm/types").AppSettings;
  needs: ReturnType<typeof computeOrderNeeds>;
  createPurchaseOrder: (p?: Partial<import("@/lib/lcm/types").PurchaseOrder>) => import("@/lib/lcm/types").PurchaseOrder;
  upsertPurchaseOrder: (p: import("@/lib/lcm/types").PurchaseOrder) => void;
  receivePoLine: (opts: {
    poId: string;
    lineId: string;
    qty: number;
    location?: string;
  }) => { ok: boolean; error?: string; pieceIds?: string[] };
  addCustomListItem: (
    kind: "materials" | "machines" | "stockShapes" | "pauseReasons" | "materialTypes",
    value: string,
    materialForType?: string,
  ) => { ok: boolean; error?: string };
}) {
  const [selectedId, setSelectedId] = useState(purchaseOrders[0]?.id || null);
  const selected =
    purchaseOrders.find((p) => p.id === selectedId) || purchaseOrders[0] || null;
  const [recv, setRecv] = useState<{
    poId: string;
    lineId: string;
    max: number;
    label: string;
  } | null>(null);
  const [recvQty, setRecvQty] = useState("1");
  const [lastIds, setLastIds] = useState<string[]>([]);

  function newBuy() {
    const po = createPurchaseOrder({
      vendor: "",
      status: "ordered",
      lines: [],
    });
    setSelectedId(po.id);
    toast.success(`Material buy ${po.poNumber}`);
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Material buys (vendor POs)</CardTitle>
          <CardDescription>
            Buy bar/sheet from vendors. Receive creates barcode stickers. Shop
            customer POs live under Shop Orders.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button onClick={newBuy}>
            <Plus className="h-4 w-4" /> New material buy
          </Button>
          {lastIds.length > 0 && (
            <Link
              to="/labels"
              search={{ ids: lastIds.join(",") }}
              className="inline-flex items-center rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2 text-sm min-h-10"
            >
              Print last labels ({lastIds.length})
            </Link>
          )}
          <Link
            to="/po"
            className="inline-flex items-center rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2 text-sm min-h-10"
          >
            Shop orders
          </Link>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Buy list</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 max-h-80 overflow-y-auto">
            {purchaseOrders.map((po) => (
              <button
                key={po.id}
                type="button"
                onClick={() => setSelectedId(po.id)}
                className={
                  "w-full text-left rounded-[var(--radius-md)] border px-3 py-2 text-sm " +
                  (selected?.id === po.id
                    ? "border-[var(--color-primary)]"
                    : "border-[var(--color-border)]")
                }
              >
                <div className="font-medium">{po.poNumber}</div>
                <div className="text-xs text-[var(--color-muted)]">
                  {po.vendor || "—"} · {po.status}
                </div>
              </button>
            ))}
            {purchaseOrders.length === 0 && (
              <p className="text-sm text-[var(--color-muted)]">No material buys yet.</p>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">
              {selected ? selected.poNumber : "Select a buy"}
            </CardTitle>
          </CardHeader>
          {selected && (
            <CardContent className="space-y-3">
              <div className="grid sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Vendor</Label>
                  <Input
                    value={selected.vendor}
                    onChange={(e) =>
                      upsertPurchaseOrder({ ...selected, vendor: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Status</Label>
                  <Select
                    value={selected.status}
                    onChange={(e) =>
                      upsertPurchaseOrder({
                        ...selected,
                        status: e.target.value as typeof selected.status,
                      })
                    }
                  >
                    <option value="draft">draft</option>
                    <option value="ordered">ordered</option>
                    <option value="partial">partial</option>
                    <option value="received">received</option>
                    <option value="cancelled">cancelled</option>
                  </Select>
                </div>
              </div>
              <Button
                size="sm"
                variant="secondary"
                onClick={() => {
                  const line = {
                    id: uid(),
                    material: "Aluminum",
                    materialType: "T6 6061",
                    stockShape: "Round Stock",
                    sizeNote: "",
                    unit: "in" as const,
                    qtyOrdered: 1,
                    qtyReceived: 0,
                    lengthEach: 144,
                    unitCost: 0,
                    partNumber: "",
                    jobRef: "",
                    notes: "",
                  };
                  upsertPurchaseOrder({
                    ...selected,
                    lines: [...selected.lines, line],
                  });
                }}
              >
                <Plus className="h-4 w-4" /> Add line
              </Button>
              <div className="space-y-2">
                {selected.lines.map((line) => {
                  const open = Math.max(0, line.qtyOrdered - line.qtyReceived);
                  return (
                    <div
                      key={line.id}
                      className="rounded-[var(--radius-md)] border border-[var(--color-border)] p-3 space-y-2"
                    >
                      <div className="grid sm:grid-cols-3 gap-2">
                        <Input
                          value={line.material}
                          onChange={(e) =>
                            upsertPurchaseOrder({
                              ...selected,
                              lines: selected.lines.map((l) =>
                                l.id === line.id
                                  ? { ...l, material: e.target.value }
                                  : l,
                              ),
                            })
                          }
                          placeholder="Material"
                        />
                        <Input
                          value={line.materialType}
                          onChange={(e) =>
                            upsertPurchaseOrder({
                              ...selected,
                              lines: selected.lines.map((l) =>
                                l.id === line.id
                                  ? { ...l, materialType: e.target.value }
                                  : l,
                              ),
                            })
                          }
                          placeholder="Type"
                        />
                        <Input
                          value={line.sizeNote}
                          onChange={(e) =>
                            upsertPurchaseOrder({
                              ...selected,
                              lines: selected.lines.map((l) =>
                                l.id === line.id
                                  ? { ...l, sizeNote: e.target.value }
                                  : l,
                              ),
                            })
                          }
                          placeholder="Size note"
                        />
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        <Label className="text-xs">Qty</Label>
                        <Input
                          type="number"
                          className="w-20 h-9"
                          value={line.qtyOrdered}
                          onChange={(e) =>
                            upsertPurchaseOrder({
                              ...selected,
                              lines: selected.lines.map((l) =>
                                l.id === line.id
                                  ? {
                                      ...l,
                                      qtyOrdered: Number(e.target.value) || 0,
                                    }
                                  : l,
                              ),
                            })
                          }
                        />
                        <span className="text-xs text-[var(--color-muted)]">
                          recv {line.qtyReceived}/{line.qtyOrdered}
                        </span>
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={open <= 0}
                          onClick={() => {
                            setRecv({
                              poId: selected.id,
                              lineId: line.id,
                              max: open,
                              label: `${line.material} ${line.materialType}`,
                            });
                            setRecvQty(String(open));
                          }}
                        >
                          Receive
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
              {needs.filter((n) => n.toOrder > 0).length > 0 && (
                <div className="text-xs text-[var(--color-muted)]">
                  Tip: short materials show under Order needs — add lines here,
                  then receive for barcodes.
                </div>
              )}
            </CardContent>
          )}
        </Card>
      </div>

      {recv && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-4"
          onClick={() => setRecv(null)}
        >
          <div
            className="w-full max-w-md rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 space-y-3"
            onClick={(e) => e.stopPropagation()}
          >
            <h2 className="text-lg font-semibold">Receive material</h2>
            <p className="text-sm text-[var(--color-muted)]">
              {recv.label} · open {recv.max}
            </p>
            <Input
              type="number"
              value={recvQty}
              onChange={(e) => setRecvQty(e.target.value)}
            />
            <div className="flex justify-end gap-2">
              <Button variant="ghost" onClick={() => setRecv(null)}>
                Cancel
              </Button>
              <Button
                onClick={() => {
                  const res = receivePoLine({
                    poId: recv.poId,
                    lineId: recv.lineId,
                    qty: Number(recvQty),
                    location: "Receiving",
                  });
                  if (!res.ok) {
                    toast.error(res.error || "Failed");
                    return;
                  }
                  toast.success(
                    `Received · ${res.pieceIds?.length || 0} barcodes`,
                  );
                  setLastIds(res.pieceIds || []);
                  setRecv(null);
                }}
              >
                Receive & barcodes
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/** Currency field: empty when 0, shows $ on blur */
export function MoneyInput({
  value,
  onValueChange,
}: {
  value: number;
  onValueChange: (n: number) => void;
}) {
  const [focused, setFocused] = useState(false);
  const [draft, setDraft] = useState("");

  const shown = focused
    ? draft
    : value > 0
      ? formatCurrency(value)
      : "";

  return (
    <Input
      type="text"
      inputMode="decimal"
      autoComplete="off"
      placeholder="$0.00"
      value={shown}
      onFocus={() => {
        setDraft(value > 0 ? String(value) : "");
        setFocused(true);
      }}
      onChange={(e) => {
        const raw = e.target.value;
        setDraft(raw);
        const cleaned = raw.replace(/[$,]/g, "").replace(/,/g, "").trim();
        if (cleaned === "" || cleaned === "." || cleaned === "-") {
          onValueChange(0);
          return;
        }
        const n = Number(cleaned);
        if (Number.isFinite(n)) onValueChange(n);
      }}
      onBlur={() => {
        const cleaned = draft.replace(/[$,]/g, "").replace(/,/g, "").trim();
        const n = cleaned === "" ? 0 : Number(cleaned);
        onValueChange(Number.isFinite(n) ? Math.round(n * 100) / 100 : 0);
        setFocused(false);
      }}
    />
  );
}
