import { useEffect, useRef } from "react";
import { CheckCircle2, FileText } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import { CreatableSelect } from "@/components/ui/creatable-select";
import { Typeahead } from "@/components/ui/typeahead";
import { SmartNumberInput } from "@/components/ui/smart-number-input";
import {
  allMaterialTypes,
  allMaterials,
  allStockShapes,
} from "@/lib/lcm/lists";
import {
  listMaterialStockCandidates,
  estimateMaterialUnits,
  formatSizeNote,
  stockCrossSection,
  findMaterialStockMatch,
  stockMatchesRecipe,
  onHandInNeedUnits,
  DEFAULT_BAR_LENGTH_IN,
  roundShopInches,
  isCustomerSuppliedMaterial,
} from "@/lib/lcm/po-material";
import {
  stockSizeNoteOptions,
  stockSizeNoteHint,
} from "@/lib/lcm/stock-size-catalog";
import { isSheetOrPlate, profileForShape } from "@/lib/lcm/stock-shapes";
import { lineDrawings } from "@/lib/lcm/line-files";
import { openPoAttachment } from "@/lib/lcm/open-attachment";
import type {
  AppSettings,
  CustomLists,
  MaterialStock,
  ShopOrder,
  ShopOrderLine,
} from "@/lib/lcm/types";

export function MaterialLineDialog({
  selected,
  lineId,
  materialStock,
  customLists,
  settings,
  updateLine,
  setShopLineMaterialReviewed,
  onClose,
}: {
  selected: ShopOrder;
  lineId: string;
  materialStock: MaterialStock[];
  customLists: CustomLists;
  settings: AppSettings;
  updateLine: (lineId: string, patch: Partial<ShopOrderLine>) => void;
  setShopLineMaterialReviewed: (
    orderId: string,
    lineId: string,
    reviewed: boolean,
  ) => void;
  onClose: () => void;
}) {
  const line = selected.lines.find((l) => l.id === lineId);
  const want = {
    stockShape: line?.stockShape,
    sizeNote: line?.sizeNote,
    dimX: line?.dimX,
    dimY: line?.dimY,
    dimZ: line?.dimZ,
  };
  const liveMatch = findMaterialStockMatch(materialStock, {
    material: line?.material || "",
    materialType: line?.materialType || "",
    stockShape: line?.stockShape || "",
    sizeNote: line?.sizeNote,
    dimX: line?.dimX,
    dimY: line?.dimY,
    dimZ: line?.dimZ,
    preferredId: "",
  });
  const savedRow = materialStock.find((s) => s.id === line?.materialStockId);
  const savedOk = Boolean(
    line && savedRow && stockMatchesRecipe(savedRow, want),
  );
  const shownStock = savedOk ? savedRow : liveMatch;
  const clearedRef = useRef(false);
  useEffect(() => {
    if (!line || clearedRef.current) return;
    if (line.materialStockId && !savedOk) {
      clearedRef.current = true;
      updateLine(line.id, {
        materialStockId: liveMatch?.id || "",
        materialOnHand: liveMatch?.onHand ?? 0,
        materialLocation: liveMatch?.location || "",
        materialReviewed: false,
      });
    }
  }, [line, savedOk, liveMatch, updateLine]);

  if (!line) return null;
  const current = line;
  const supplied = isCustomerSuppliedMaterial(current);

  function setMaterial(v: string) {
    if (isCustomerSuppliedMaterial({ material: v })) {
      updateLine(current.id, {
        material: v,
        materialType: "",
        stockShape: "",
        sizeNote: "",
        dimX: 0,
        dimY: 0,
        dimZ: 0,
        partLengthEach: 0,
        rawMaterialLength: 0,
        materialNeeded: 0,
        materialStockId: "",
        materialOnHand: 0,
        materialLocation: "",
        materialReviewed: true,
      });
      return;
    }
    updateLine(current.id, {
      material: v,
      materialStockId: "",
      materialReviewed: false,
    });
  }

  const typeOpts = allMaterialTypes(
    current.material || "Aluminum",
    customLists,
  );
  const candidates = listMaterialStockCandidates(
    materialStock,
    line.material || "",
    line.materialType || "",
    {
      stockShape: line.stockShape,
      sizeNote: line.sizeNote,
      dimX: line.dimX,
      dimY: line.dimY,
      dimZ: line.dimZ,
    },
  );
  const est = estimateMaterialUnits({
    orderQty: line.qty,
    partLengthEach: line.partLengthEach || 0,
    rawMaterialLength: line.rawMaterialLength || 0,
    stockShape: line.stockShape,
  });
  const profile = profileForShape(line.stockShape);
  const sheetPlate = isSheetOrPlate(line.stockShape);
  const onHandIn = shownStock
    ? onHandInNeedUnits(shownStock, {
        barLengthIn: line.rawMaterialLength || DEFAULT_BAR_LENGTH_IN,
        sheet: sheetPlate,
      })
    : 0;
  const inchesNeeded =
    !sheetPlate && line.materialNeeded >= 10
      ? line.materialNeeded
      : est.needed;
  const materialOptions = allMaterials(customLists);
  const stockShapeOptions = allStockShapes(customLists);
  const sizeOpts = stockSizeNoteOptions({
    material: line.material,
    materialType: line.materialType,
    stockShape: line.stockShape,
    customNotes: settings.customLists?.sizeNotes || [],
  });

  function applySize(patch: Partial<ShopOrderLine>) {
    const dimX = patch.dimX ?? current.dimX;
    const dimY =
      sheetPlate || (profile.id !== "round" && profile.id !== "hex")
        ? (patch.dimY ?? current.dimY)
        : 0;
    const dimZ = patch.dimZ ?? current.dimZ;
    const raw = sheetPlate
      ? 0
      : (patch.rawMaterialLength ??
        (dimZ > 0 ? dimZ : current.rawMaterialLength));
    updateLine(current.id, {
      ...patch,
      dimY,
      rawMaterialLength: raw,
      sizeNote:
        patch.sizeNote !== undefined
          ? patch.sizeNote
          : formatSizeNote({
              sizeNote: "",
              dimX,
              dimY,
              dimZ: sheetPlate ? dimZ : raw,
              stockShape: current.stockShape,
            }),
      materialStockId: "",
      materialReviewed: false,
    });
  }

  const sectionFields = profile.section.filter((f) => {
    if (profile.id === "round" || profile.id === "hex") return f.key === "dimX";
    return true;
  });

  return (
    <div
      className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-black/60 p-4 print:hidden"
      onClick={() => onClose()}
    >
      <div
        className="relative z-[71] w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 space-y-3 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h2 className="text-lg font-semibold">
              Stock for {line.partNumber || "line"}{" "}
              <span className="text-sm font-normal text-[var(--color-muted)]">
                rev {line.revision || "—"} · {line.qty} pcs
              </span>
            </h2>
            <p className="text-sm text-[var(--color-muted)] mt-1">
              This is the <strong>bar / sheet on the rack</strong>, not the
              finished part. Last-used stock for this P/N — change it only if
              the last run was wrong.
            </p>
          </div>
          <Button
            type="button"
            variant="secondary"
            className="shrink-0"
            onClick={async () => {
              const draws = lineDrawings(line);
              if (!draws.length) {
                toast.error("No drawing on this line — attach it on the PO");
                return;
              }
              const r = await openPoAttachment({
                id: draws[0].id,
                name: draws[0].name,
              });
              if (!r.ok) toast.error(r.error || "Missing file");
            }}
          >
            <FileText className="h-4 w-4" />
            Drawing
            {lineDrawings(line).length > 1
              ? ` (${lineDrawings(line).length})`
              : ""}
          </Button>
        </div>

        <div className="grid sm:grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label>Material</Label>
            <CreatableSelect
              value={line.material || ""}
              options={materialOptions}
              onChange={setMaterial}
              onCreate={setMaterial}
              createTitle="Add material"
            />
          </div>
          {!supplied && (
          <>
          <div className="space-y-1.5">
            <Label>Material type</Label>
            <CreatableSelect
              value={line.materialType || ""}
              options={typeOpts}
              onChange={(v) =>
                updateLine(line.id, {
                  materialType: v,
                  materialStockId: "",
                  materialReviewed: false,
                })
              }
              onCreate={(v) =>
                updateLine(line.id, {
                  materialType: v,
                  materialStockId: "",
                  materialReviewed: false,
                })
              }
              createTitle="Add type"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Stock shape</Label>
            <CreatableSelect
              value={line.stockShape || ""}
              options={stockShapeOptions}
              onChange={(v) =>
                updateLine(line.id, {
                  stockShape: v,
                  dimX: 0,
                  dimY: 0,
                  dimZ: 0,
                  sizeNote: "",
                  rawMaterialLength: 0,
                  materialStockId: "",
                  materialReviewed: false,
                })
              }
              onCreate={(v) =>
                updateLine(line.id, {
                  stockShape: v,
                  dimX: 0,
                  dimY: 0,
                  dimZ: 0,
                  sizeNote: "",
                  rawMaterialLength: 0,
                  materialStockId: "",
                  materialReviewed: false,
                })
              }
              createTitle="Add shape"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Stock size</Label>
            <Typeahead
              value={line.sizeNote || ""}
              options={sizeOpts}
              placeholder={
                sheetPlate
                  ? 'e.g. 0.5" plate × 48 × 96'
                  : profile.id === "round"
                    ? 'e.g. 3" dia × 144" long'
                    : 'e.g. 0.5 × 1 × 144'
              }
              maxSuggestions={40}
              onChange={(v) => {
                const parsed = stockCrossSection({
                  stockShape: line.stockShape,
                  sizeNote: v,
                });
                applySize({
                  sizeNote: v,
                  dimX: parsed.dia || parsed.thk || 0,
                  dimY: parsed.width || 0,
                  dimZ: parsed.length || 0,
                  rawMaterialLength: sheetPlate ? 0 : parsed.length || 0,
                });
              }}
            />
            <p className="text-[10px] text-[var(--color-subtle)]">
              {profile.title}: {stockSizeNoteHint(line.stockShape)}
            </p>
          </div>
          </>
          )}
        </div>
        {supplied && (
          <p className="text-sm text-[var(--color-muted)] rounded-md border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2">
            Customer supplies this stock. No type, size, buy qty, or rack
            match is needed.
          </p>
        )}

        {!supplied && (
<>
        <div className="rounded-md border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">
            Stock size — {profile.title}
          </div>
          <div
            className={
              sectionFields.length + (sheetPlate ? 0 : 1) >= 3
                ? "grid grid-cols-3 gap-2"
                : "grid sm:grid-cols-2 gap-2"
            }
          >
            {sectionFields.map((f) => (
              <div key={f.key} className="space-y-1">
                <Label className="text-[10px]">{f.label} (")</Label>
                <SmartNumberInput
                  format="inches"
                  value={Number(line[f.key]) || 0}
                  placeholder="—"
                  onValueChange={(n) => applySize({ [f.key]: n })}
                />
              </div>
            ))}
            {!sheetPlate && (
              <div className="space-y-1">
                <Label className="text-[10px]">Stock bar length (")</Label>
                <SmartNumberInput
                  format="inches"
                  value={line.rawMaterialLength || line.dimZ || 144}
                  placeholder="e.g. 144"
                  onValueChange={(rawMaterialLength) =>
                    applySize({
                      rawMaterialLength,
                      dimZ: rawMaterialLength,
                    })
                  }
                />
              </div>
            )}
          </div>
          <p className="text-[10px] text-[var(--color-subtle)]">
            {profile.summary}. These numbers are the stock you pull, not the
            finished part.
          </p>
        </div>

        <div className="rounded-md border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">
            How much stock to pull / buy
          </div>
          {sheetPlate ? (
            <>
              <div className="grid sm:grid-cols-2 gap-2">
                <div className="space-y-1">
                  <Label className="text-[10px]">Order qty</Label>
                  <div className="h-10 flex items-center text-sm px-2 rounded-md border border-[var(--color-border)]">
                    {line.qty} pcs
                  </div>
                </div>
                <div className="space-y-1">
                  <Label className="text-[10px]">
                    Sheet / plate pieces (auto)
                  </Label>
                  <SmartNumberInput
                    value={
                      !line.materialReviewed
                        ? est.needed
                        : line.materialNeeded > 0
                          ? line.materialNeeded
                          : est.needed
                    }
                    placeholder="auto"
                    onValueChange={(materialNeeded) =>
                      updateLine(line.id, {
                        materialNeeded,
                        materialReviewed: false,
                      })
                    }
                  />
                </div>
              </div>
              <p className="text-[11px] text-[var(--color-muted)] leading-snug">
                <strong className="text-[var(--color-fg)]">Math:</strong>{" "}
                <span className="font-mono text-[var(--color-fg)]">
                  {est.formula}
                </span>
              </p>
              <p className="text-[10px] text-[var(--color-subtle)]">
                One piece per part. Override if you nest more than one on a
                sheet.
              </p>
            </>
          ) : (
            <>
              <div className="grid sm:grid-cols-2 gap-2">
                <div className="space-y-1">
                  <Label className="text-[10px]">
                    Stock used per part (")
                  </Label>
                  <SmartNumberInput
                    format="inches"
                    value={line.partLengthEach || 0}
                    placeholder="e.g. 1.25"
                    onValueChange={(partLengthEach) =>
                      updateLine(line.id, {
                        partLengthEach,
                        materialNeeded: 0,
                        materialReviewed: false,
                      })
                    }
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-[10px]">
                  Inches needed (auto)
                </Label>
                <SmartNumberInput
                  format="inches"
                  value={
                    line.materialNeeded >= 10
                      ? line.materialNeeded
                      : est.needed
                  }
                  placeholder="auto"
                  onValueChange={(materialNeeded) =>
                    updateLine(line.id, {
                      materialNeeded,
                      materialReviewed: false,
                    })
                  }
                />
                </div>
              </div>
              <p className="text-[11px] text-[var(--color-muted)] leading-snug">
                <strong className="text-[var(--color-fg)]">Math:</strong>{" "}
                <span className="font-mono text-[var(--color-fg)]">
                  {est.formula}
                </span>
              </p>
              <p className="text-[10px] text-[var(--color-subtle)]">
                Everything is inches. {est.needed}" needed vs rack inches —
                no bar/foot conversion.
              </p>
            </>
          )}
        </div>

        <div className="space-y-1.5">
          <Label>On the rack (matched stock)</Label>
          <Select
            value={shownStock?.id || ""}
            onChange={(e) => {
              const id = e.target.value;
              const row = materialStock.find((s) => s.id === id);
              if (!row) {
                updateLine(line.id, {
                  materialStockId: "",
                  materialReviewed: false,
                });
                return;
              }
              updateLine(line.id, {
                materialStockId: row.id,
                material: row.material,
                materialType: row.materialType,
                stockShape: row.stockShape,
                sizeNote: row.sizeNote,
                dimX: row.dimX,
                dimY: row.dimY,
                dimZ: row.dimZ,
                materialOnHand: row.onHand,
                materialLocation: row.location,
                rawMaterialLength: sheetPlate
                  ? 0
                  : row.dimZ || line.rawMaterialLength || 0,
                materialNeeded: 0,
                materialReviewed: false,
              });
            }}
          >
            <option value="">
              {candidates.length
                ? "— Matching stock first — pick if last run was wrong —"
                : "— No inventory for this stock size —"}
            </option>
            {candidates.map((s, idx) => (
              <option key={s.id} value={s.id}>
                {(shownStock?.id === s.id && stockMatchesRecipe(s, want)
                  ? "★ "
                  : idx === 0 && stockMatchesRecipe(s, want)
                    ? "Best: "
                    : "") +
                  (s.sizeNote ||
                    `${s.dimX || "?"}${s.dimY ? " × " + s.dimY : ""}" ${s.stockShape}`) +
                  ` · ${s.materialType}` +
                  ` · on hand ${s.onHand} ${s.unit}` +
                  (s.location ? ` @ ${s.location}` : "")}
              </option>
            ))}
          </Select>
          <p className="text-[11px] text-[var(--color-muted)]">
            Last-used <strong>stock</strong> vs rack, in inches. On
            hand:{" "}
            <strong>
              {roundShopInches(onHandIn)}
              {sheetPlate ? " pc" : '"'}
            </strong>
            {shownStock?.location ? ` @ ${shownStock.location}` : ""}
            {!shownStock && line.material ? (
              <>
                {" "}
                ·{" "}
                <strong className="text-[var(--color-warn)]">
                  No {line.sizeNote || `${line.dimX || ""}"`} in inventory
                  — buy {roundShopInches(inchesNeeded)}
                  {sheetPlate ? " pc" : '"'}
                </strong>
              </>
            ) : inchesNeeded > onHandIn + 1e-9 ? (
              <>
                {" "}
                ·{" "}
                <strong className="text-[var(--color-warn)]">
                  Buy {roundShopInches(inchesNeeded - onHandIn)}
                  {sheetPlate ? " pc" : '"'}
                </strong>
              </>
            ) : null}
          </p>
        </div>

        </>
        )}

        {(!supplied && (!shownStock && line.material)) || (!supplied && line.attentionReason) ? (
          <div className="rounded-md border border-[color-mix(in_oklab,var(--color-warn)_40%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-warn)_12%,transparent)] px-3 py-2 text-xs text-[var(--color-fg)]">
            {!shownStock && line.material
              ? `Last-used stock ${line.sizeNote || `${line.dimX || "?"}"`} is not on the rack. Other sizes of the same alloy do not count — buy this stock size.`
              : line.attentionReason}
          </div>
        ) : null}

        <div className="flex flex-wrap justify-end gap-2 pt-1">
          <Button variant="ghost" type="button" onClick={() => onClose()}>
            Close
          </Button>
          <Button
            type="button"
            onClick={() => {
              updateLine(line.id, {
                materialNeeded: line.materialNeeded || 0,
              });
              setShopLineMaterialReviewed(selected.id, line.id, true);
              onClose();
              toast.success("Marked stock OK for this line");
            }}
          >
            <CheckCircle2 className="h-4 w-4" /> Mark OK
          </Button>
        </div>
      </div>
    </div>
  );
}
