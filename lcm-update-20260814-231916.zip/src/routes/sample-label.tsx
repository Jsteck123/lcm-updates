import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Printer, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { barcodeToDataUrl, scanUrlForBarcode } from "@/lib/lcm/barcode";
import { Button } from "@/components/ui/button";
import { Label, Select } from "@/components/ui/input";
import { useLcmStore } from "@/store/lcm-store";
import {
  downloadLabelPng,
  renderLabelPng,
  tapeById,
} from "@/lib/lcm/brother-label-print";
import {
  listShopLabelPrinters,
  printLabelOnShopHost,
} from "@/lib/lcm/print-label-api";
import { loadQlPrinterName, saveQlPrinterName } from "@/lib/lcm/ql-printer";
import { getShopToken, requestShopUnlock } from "@/lib/lcm/shop-sync";

export const SAMPLE_BARCODE = "LCM-SAMPLE-01";

const LOCAL_SAMPLE = {
  barcode: SAMPLE_BARCODE,
  material: "Aluminum",
  materialType: "T6 6061",
  stockShape: "Round Stock",
  sizeNote: '1.5" dia x 12 ft',
  remainingLength: 144,
  originalLength: 144,
  location: "Rack A-1",
  unit: "in" as const,
};

type ListedPrinter = { name: string; port: string; kind: "wifi" | "usb" | "other" };

export const Route = createFileRoute("/sample-label")({
  component: SampleLabelPage,
});

function SampleLabelPage() {
  const stockPiecesRaw = useLcmStore((s) => s.stockPieces);
  const stockPieces = stockPiecesRaw || [];
  const shopPublicUrl = useLcmStore((s) => s.settings.shopPublicUrl);
  const [qr, setQr] = useState("");
  const [busy, setBusy] = useState(false);
  const [printers, setPrinters] = useState<ListedPrinter[]>([]);
  const [printerName, setPrinterName] = useState(() => loadQlPrinterName());
  const tape = tapeById("dk2210");

  const piece =
    stockPieces.find((p) => p.barcode === SAMPLE_BARCODE) || LOCAL_SAMPLE;

  useEffect(() => {
    const url = scanUrlForBarcode(SAMPLE_BARCODE, shopPublicUrl);
    void barcodeToDataUrl(url, 220).then(setQr);
  }, [shopPublicUrl]);

  useEffect(() => {
    const token = getShopToken();
    if (!token) return;
    void listShopLabelPrinters({ data: { token } }).then((r) => {
      if (!r.ok) return;
      setPrinters(r.printers);
      if (!printerName && r.ql) {
        setPrinterName(r.ql);
        saveQlPrinterName(r.ql);
      }
    });
  }, [printerName]);

  async function printOnPrinter() {
    if (!qr) {
      toast.error("Wait for the barcode to finish drawing");
      return;
    }
    if (!getShopToken()) {
      requestShopUnlock();
      toast.error("Unlock this PC first, then print again.");
      return;
    }
    setBusy(true);
    try {
      const png = await renderLabelPng(
        {
          barcode: piece.barcode,
          qrDataUrl: qr,
          line1: `${piece.material} ${piece.materialType}`,
          line2: piece.sizeNote,
        },
        tape,
      );
      const r = await printLabelOnShopHost({
        data: {
          token: getShopToken() || undefined,
          pngBase64: png,
          printerName: printerName || undefined,
        },
      });
      if (!r.ok) toast.error(r.error || "Print failed");
      else {
        if (r.kind === "usb") {
          toast.error(
            "That job went to USB (" +
              r.printer +
              "). Pick the Wi-Fi QL-810W in the list and print again.",
          );
        } else {
          toast.success("Sent over Wi-Fi to " + r.printer + " · " + r.port);
        }
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Print failed");
    }
    setBusy(false);
  }

  async function savePng() {
    if (!qr) {
      toast.error("Wait for the barcode to finish drawing");
      return;
    }
    const r = await downloadLabelPng({
      tapeId: "dk2210",
      barcode: piece.barcode,
      qrDataUrl: qr,
      line1: `${piece.material} ${piece.materialType}`,
      line2: piece.sizeNote,
    });
    if (!r.ok) toast.error(r.error || "Could not save PNG");
  }

  const selected = printers.find((p) => p.name === printerName);

  return (
    <div className="mx-auto max-w-lg space-y-5 pb-10">
      <div className="flex items-center gap-2">
        <Link
          to="/inventory"
          className="inline-flex items-center justify-center gap-1.5 text-sm text-[var(--color-muted)] hover:text-[var(--color-fg)] min-h-11"
        >
          <ArrowLeft className="h-4 w-4" /> Inventory
        </Link>
      </div>

      <div className="space-y-2">
        <h1 className="text-2xl font-semibold tracking-tight">
          Sample barcode label
        </h1>
        <p className="text-sm text-[var(--color-muted)]">
          Prints 1.1 × 0.6 over Wi-Fi to the QL-810W. Pick the Wi-Fi printer —
          not the USB one.
        </p>
      </div>

      <div className="space-y-1.5">
        <Label>QL-810W on Wi-Fi</Label>
        <Select
          className="h-11"
          value={printerName}
          onChange={(e) => {
            setPrinterName(e.target.value);
            saveQlPrinterName(e.target.value);
          }}
        >
          <option value="">Auto — prefer Wi-Fi</option>
          {printers.map((p) => (
            <option key={p.name} value={p.name}>
              {p.name} — {p.kind === "wifi" ? "Wi-Fi" : p.kind === "usb" ? "USB" : p.port}{" "}
              {p.port}
            </option>
          ))}
        </Select>
        {selected ? (
          <p className="text-xs text-[var(--color-muted)]">
            {selected.kind === "wifi"
              ? "Wi-Fi / network port " + selected.port
              : selected.kind === "usb"
                ? "This is USB. Pick the other QL-810W if you see one."
                : selected.port}
          </p>
        ) : null}
      </div>

      <div
        className="sample-ql-label compact"
        style={{ width: tape.w, height: tape.h }}
      >
        {qr ? (
          <img src={qr} alt="" className="sample-ql-qr" />
        ) : (
          <div className="sample-ql-qr sample-ql-qr-empty" />
        )}
        <div className="sample-ql-text">
          <div className="sample-ql-code">{piece.barcode}</div>
          <div className="sample-ql-mat">
            {piece.material} {piece.materialType}
          </div>
          <div className="sample-ql-size">{piece.sizeNote}</div>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <Button
          type="button"
          className="min-h-11"
          disabled={busy}
          onClick={() => void printOnPrinter()}
        >
          <Printer className="h-4 w-4" /> {busy ? "Sending…" : "Print on Wi-Fi QL"}
        </Button>
        <Button
          type="button"
          variant="secondary"
          className="min-h-11"
          onClick={() => void savePng()}
        >
          Save PNG
        </Button>
      </div>

      <style>{`
        .sample-ql-label {
          box-sizing: border-box;
          padding: 0.04in 0.05in 0.04in 0.03in;
          border: 1px solid var(--color-border);
          background: #fff;
          color: #000;
          display: flex;
          flex-direction: row;
          align-items: center;
          gap: 0.04in;
          text-align: left;
          overflow: hidden;
        }
        .sample-ql-text {
          min-width: 0;
          flex: 1;
          display: flex;
          flex-direction: column;
          justify-content: center;
        }
        .sample-ql-code {
          font-family: ui-monospace, monospace;
          font-size: 9px;
          font-weight: 800;
          line-height: 1.08;
          white-space: nowrap;
        }
        .sample-ql-qr {
          width: 0.48in;
          height: 0.48in;
          object-fit: contain;
          flex-shrink: 0;
        }
        .sample-ql-qr-empty { background: #eee; }
        .sample-ql-mat {
          font-size: 8px;
          font-weight: 800;
          line-height: 1.08;
        }
        .sample-ql-size {
          font-size: 8px;
          font-weight: 700;
          line-height: 1.08;
        }
      `}</style>
    </div>
  );
}
