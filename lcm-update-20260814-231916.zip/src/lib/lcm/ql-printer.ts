const KEY = "lcm-ql-printer";

export function loadQlPrinterName(): string {
  if (typeof window === "undefined") return "";
  try {
    return localStorage.getItem(KEY) || "";
  } catch {
    return "";
  }
}

export function saveQlPrinterName(name: string) {
  if (typeof window === "undefined") return;
  try {
    if (name) localStorage.setItem(KEY, name);
    else localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}
