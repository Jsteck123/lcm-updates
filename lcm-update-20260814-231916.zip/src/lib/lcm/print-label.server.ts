/**
 * Print a stock-label PNG on the Windows shop PC's Brother QL-810W (Wi-Fi).
 * Picks the network queue, not a USB copy of the same printer.
 */
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

export type ShopPrinter = {
  name: string;
  port: string;
  kind: "wifi" | "usb" | "other";
};

function runPs(command: string, timeoutMs = 25000): {
  ok: boolean;
  stdout: string;
  stderr: string;
} {
  const r = spawnSync(
    "powershell.exe",
    ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", command],
    { encoding: "utf8", timeout: timeoutMs, windowsHide: true },
  );
  return {
    ok: r.status === 0,
    stdout: String(r.stdout || "").trim(),
    stderr: String(r.stderr || r.error?.message || "").trim(),
  };
}

export function classifyPort(port: string): ShopPrinter["kind"] {
  const p = String(port || "");
  if (/USB|DOT4|LPT|COM\d/i.test(p)) return "usb";
  if (/IP_|WSD|TCP|WLAN|Wi-?Fi|Network|BRN|9100|http/i.test(p)) return "wifi";
  return "other";
}

export function listWindowsPrinters(): ShopPrinter[] {
  if (process.platform !== "win32") return [];
  const r = runPs(
    "Get-Printer | ForEach-Object { $_.Name + '`t' + $_.PortName }",
    12000,
  );
  if (!r.ok) return [];
  return r.stdout
    .split(/\r?\n/)
    .map((line) => {
      const [name, port = ""] = line.split("\t");
      const n = (name || "").trim();
      if (!n) return null;
      const p = port.trim();
      return { name: n, port: p, kind: classifyPort(p) };
    })
    .filter((x): x is ShopPrinter => Boolean(x));
}

export function pickQlPrinter(
  printers: ShopPrinter[],
  preferred?: string,
): ShopPrinter | null {
  if (preferred) {
    const hit = printers.find((p) => p.name === preferred);
    if (hit) return hit;
  }
  const ql = printers.filter((p) => /QL-?810/i.test(p.name) || (/Brother/i.test(p.name) && /QL/i.test(p.name)));
  const pool = ql.length ? ql : printers.filter((p) => /Brother/i.test(p.name));
  return (
    pool.find((p) => p.kind === "wifi") ||
    pool.find((p) => p.kind === "other") ||
    pool[0] ||
    null
  );
}

function psScript(): string {
  return `
param([string]$PngPath, [string]$PrinterName)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$img = [System.Drawing.Image]::FromFile((Resolve-Path $PngPath))
try {
  $doc = New-Object System.Drawing.Printing.PrintDocument
  $doc.PrinterSettings.PrinterName = $PrinterName
  if (-not $doc.PrinterSettings.IsValid) { throw "Printer not valid: $PrinterName" }
  $doc.DocumentName = 'LCM label'
  $doc.DefaultPageSettings.Margins = New-Object System.Drawing.Printing.Margins 0,0,0,0
  $doc.OriginAtMargins = $true
  $paper = New-Object System.Drawing.Printing.PaperSize 'LCM-110x60', 110, 60
  $doc.DefaultPageSettings.PaperSize = $paper
  $doc.DefaultPageSettings.Landscape = $true
  $doc.add_PrintPage({
    param($s, $e)
    $e.Graphics.PageUnit = [System.Drawing.GraphicsUnit]::Pixel
    $dest = $e.PageBounds
    if ($dest.Width -lt 2 -or $dest.Height -lt 2) { $dest = $e.MarginBounds }
    $e.Graphics.DrawImage($img, $dest)
    $e.HasMorePages = $false
  })
  $doc.Print()
  $doc.Dispose()
} finally {
  $img.Dispose()
}
Write-Output 'printed'
`.trim();
}

export function printPngOnQl(
  pngBase64: string,
  printerName?: string,
):
  | { ok: true; printer: string; port: string; kind: ShopPrinter["kind"] }
  | { ok: false; error: string; printers?: ShopPrinter[] } {
  if (process.platform !== "win32") {
    return {
      ok: false,
      error:
        "Open LCM on the shop PC that is on Wi-Fi with the QL-810W.",
    };
  }
  const printers = listWindowsPrinters();
  const chosen = pickQlPrinter(printers, printerName);
  if (!chosen) {
    return {
      ok: false,
      error:
        printers.length === 0
          ? "Windows did not list any printers. Add the QL-810W as a network / Wi-Fi printer on this PC."
          : "No Brother QL printer found. Printers on this PC: " +
            printers.map((p) => p.name + " (" + p.kind + " " + p.port + ")").join(", "),
      printers,
    };
  }
  if (chosen.kind === "usb" && !printerName) {
    const wifi = printers.find(
      (p) => p.kind === "wifi" && (/QL/i.test(p.name) || /Brother/i.test(p.name)),
    );
    if (wifi) {
      return printPngOnQl(pngBase64, wifi.name);
    }
  }
  const raw = String(pngBase64 || "").replace(/^data:image\/png;base64,/, "");
  if (!raw || raw.length < 80) {
    return { ok: false, error: "Label image was empty." };
  }
  let buf: Buffer;
  try {
    buf = Buffer.from(raw, "base64");
  } catch {
    return { ok: false, error: "Label image was not valid." };
  }
  if (buf.length < 80 || buf[0] !== 0x89 || buf[1] !== 0x50) {
    return { ok: false, error: "Label image was not a PNG." };
  }
  const dir = path.join(os.tmpdir(), "lcm-labels");
  fs.mkdirSync(dir, { recursive: true });
  const stamp = Date.now();
  const pngPath = path.join(dir, `label-${stamp}.png`);
  const psPath = path.join(dir, `print-${stamp}.ps1`);
  fs.writeFileSync(pngPath, buf);
  fs.writeFileSync(psPath, psScript(), "utf8");
  const r = spawnSync(
    "powershell.exe",
    [
      "-NoProfile",
      "-NonInteractive",
      "-ExecutionPolicy",
      "Bypass",
      "-File",
      psPath,
      "-PngPath",
      pngPath,
      "-PrinterName",
      chosen.name,
    ],
    { encoding: "utf8", timeout: 40000, windowsHide: true },
  );
  const stderr = String(r.stderr || r.error?.message || "").trim();
  const stdout = String(r.stdout || "").trim();
  if (r.status !== 0 || !/printed/i.test(stdout)) {
    const paint = spawnSync("mspaint.exe", ["/pt", pngPath, chosen.name], {
      encoding: "utf8",
      timeout: 40000,
      windowsHide: true,
    });
    if (paint.status === 0) {
      return { ok: true, printer: chosen.name, port: chosen.port, kind: chosen.kind };
    }
    return {
      ok: false,
      error:
        stderr ||
        stdout ||
        String(paint.stderr || "") ||
        "Windows refused the print job. Check the QL-810W is on Wi-Fi.",
      printers,
    };
  }
  return { ok: true, printer: chosen.name, port: chosen.port, kind: chosen.kind };
}
