import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { Calculator, Save, Search, Trash2, Eraser, Plus, Layers, Mail } from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { GuidedQuoteWizard } from "@/components/lcm/guided-quote-wizard";
import {
  completedJobsForPart,
  computePartRunStats,
  jobVsQuote,
} from "@/lib/lcm/job-averages";
import {
  formatCurrency,
  formatDateTime,
  formatPercent,
  formatSeconds,
} from "@/lib/utils";
import { calculateAssemblyAwareCosts, quoteFromForm } from "@/lib/lcm/calculations";
import {
  emptyToolingCharge,
  normalizeToolingCharges,
  toolingShopCostTotal,
  TOOLING_KIND_LABEL,
  withDefaultBillPrice,
} from "@/lib/lcm/quote-tooling";
import { flushShopSync } from "@/lib/lcm/shop-sync";
import type { BomLine, Quote, QuoteKind, QuoteToolingCharge, QuoteToolingKind } from "@/lib/lcm/types";
import {
  liveToolingMinutes,
  openToolingLogsForPart,
  shopCostFromToolingMinutes,
} from "@/lib/lcm/shop-tooling-log";
import {
  bomRollup,
  emptyBomLine,
  looksLikeAssemblyPn,
  suggestChildPartNumbers,
} from "@/lib/lcm/assembly";
import { Button } from "@/components/ui/button";
import { HelpTip, WithHelp } from "@/components/ui/help-tip";
import { Input, Label, Select } from "@/components/ui/input";
import { CreatableSelect } from "@/components/ui/creatable-select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CollapsibleSection } from "@/components/ui/collapsible-section";
import { clampOpCount, makeOpLabels, padSlots, zeros } from "@/lib/lcm/ops";
import {
  allMaterials,
  allMaterialTypes,
  allMachines,
  allStockShapes,
} from "@/lib/lcm/lists";
import { profileForShape, type DimKey } from "@/lib/lcm/stock-shapes";
import {
  estimateMaterialFromBook,
  LCM_CALC_LABEL,
  normalizeMaterialPriceBook,
} from "@/lib/lcm/material-rates";

export const Route = createFileRoute("/quoting")({
  component: QuotingPage,
});

const emptyForm = (maxOps: number): Partial<Quote> & {
  partNumber: string;
  setupTimes: number[];
  runTimes: number[];
  quantities: number[];
} => {
  const n = clampOpCount(maxOps);
  return {
    partNumber: "",
    customer: "",
    revision: "",
    machines: [],
    machineRate: 0,
    material: "",
    materialType: "",
    materialPct: 0,
    materialVendor: "",
    dimX: 0,
    dimY: 0,
    dimZ: 0,
    rawMaterialLength: 0,
    stockShape: "",
    rawMaterialCost: 0,
    calculateMaterialDrop: false,
    dropMultiplier: 1,
    partLengthEach: 0,
    setupTimes: zeros(n),
    runTimes: zeros(n),
    quantities: zeros(6),
    kind: "part",
    bom: [],
    benchAssembleMinutes: 0,
    toolingCharges: [],
  };
};


function QuotingPage() {
  const customers = useLcmStore((s) => s.customers);
  const quotes = useLcmStore((s) => s.quotes);
  const maxOps = useLcmStore((s) => clampOpCount(s.settings.maxOperations));
  const opLabels = useMemo(() => makeOpLabels(maxOps), [maxOps]);
  const saveQuote = useLcmStore((s) => s.saveQuote);
  const jobs = useLcmStore((s) => s.jobs);
  const quoteHistory = useLcmStore((s) => s.quoteHistory);
  const freezeQuotePrices = useLcmStore((s) => s.freezeQuotePrices);
  const shopToolingLogs = useLcmStore((s) => s.shopToolingLogs);
  const applyShopToolingLogToQuote = useLcmStore((s) => s.applyShopToolingLogToQuote);
  const resolveShopToolingLog = useLcmStore((s) => s.resolveShopToolingLog);
  const deleteQuote = useLcmStore((s) => s.deleteQuote);
  const getQuote = useLcmStore((s) => s.getQuoteByPart);
  const customLists = useLcmStore((s) => s.settings.customLists);
  const rawPriceBook = useLcmStore((s) => s.settings.materialPriceBook);
  const materialPriceBook = useMemo(
    () => normalizeMaterialPriceBook(rawPriceBook),
    [rawPriceBook],
  );
  const addCustomListItem = useLcmStore((s) => s.addCustomListItem);
  const addCustomerQuick = useLcmStore((s) => s.addCustomerQuick);
  const [form, setForm] = useState(() => emptyForm(10));
  const [guidedOpen, setGuidedOpen] = useState(false);
  const [partQuery, setPartQuery] = useState("");
  const [suggestOpen, setSuggestOpen] = useState(false);
  const [highlight, setHighlight] = useState(0);
  const [loadedId, setLoadedId] = useState<string | null>(null);
  /** Office edits minutes / $ before applying floor logs to the quote */
  const [floorDrafts, setFloorDrafts] = useState<
    Record<
      string,
      {
        minutes: string;
        billUnitPrice: string;
        shopCost: string;
        billCustomer: boolean;
        description: string;
      }
    >
  >({});
  const partWrapRef = useRef<HTMLDivElement>(null);

  const isAssembly = form.kind === "assembly";

  const costs = useMemo(
    () =>
      calculateAssemblyAwareCosts(
        {
          ...form,
          setupTimes: form.setupTimes || zeros(maxOps),
          runTimes: form.runTimes || zeros(maxOps),
          quantities: form.quantities || [0, 0, 0, 0, 0, 0],
        },
        quotes,
      ),
    [form, maxOps, quotes],
  );

  const emj = useMemo(
    () =>
      estimateMaterialFromBook({
        book: materialPriceBook,
        material: form.material || "",
        materialType: form.materialType || "",
        stockShape: form.stockShape || "",
        dimX: Number(form.dimX) || 0,
        dimY: Number(form.dimY) || 0,
        dimZ: Number(form.dimZ) || 0,
        rawMaterialLength: Number(form.rawMaterialLength) || 0,
        partLengthEach: Number(form.partLengthEach) || 0,
      }),
    [
      materialPriceBook,
      form.material,
      form.materialType,
      form.stockShape,
      form.dimX,
      form.dimY,
      form.dimZ,
      form.rawMaterialLength,
      form.partLengthEach,
    ],
  );

  useEffect(() => {
    if (!(emj.ok && emj.stockCost > 0)) return;
    setForm((f) => {
      if ((f.rawMaterialCost || 0) > 0) return f;
      return { ...f, rawMaterialCost: emj.stockCost };
    });
  }, [emj.ok, emj.stockCost]);

  const bomSummary = useMemo(
    () => bomRollup(form.bom, quotes),
    [form.bom, quotes],
  );

  const partEvidence = useMemo(() => {
    const pn = (form.partNumber || partQuery || "").trim();
    if (!pn) return null;
    const rev = form.revision || "";
    const stats = computePartRunStats(jobs, pn, rev, maxOps, {
      averageMaxRuns: 10,
      averageOutlierRatio: 1.5,
    });
    const runs = completedJobsForPart(jobs, pn, rev).slice(0, 5);
    const snaps = (quoteHistory || [])
      .filter(
        (h) =>
          h.partNumber.toUpperCase() === pn.toUpperCase() &&
          (!rev || h.revision.toUpperCase() === rev.toUpperCase()),
      )
      .slice(0, 5);
    return { stats, runs, snaps };
  }, [form.partNumber, form.revision, partQuery, jobs, quoteHistory, maxOps]);

  const floorToolingLogs = useMemo(
    () =>
      openToolingLogsForPart(
        shopToolingLogs,
        form.partNumber || partQuery || "",
        form.revision,
      ),
    [shopToolingLogs, form.partNumber, form.revision, partQuery],
  );

    const materialOptions = useMemo(
    () => allMaterials(customLists),
    [customLists],
  );
  const typeOptions = useMemo(
    () => allMaterialTypes(form.material || "Aluminum", customLists),
    [form.material, customLists],
  );
  const machineOptions = useMemo(
    () => allMachines(customLists),
    [customLists],
  );
  const stockShapeOptions = useMemo(
    () => allStockShapes(customLists),
    [customLists],
  );
  const customerOptions = useMemo(
    () => customers.map((c) => c.name),
    [customers],
  );

  const matches = useMemo(() => {
    const q = partQuery.trim().toLowerCase();
    if (!q) return quotes.slice(0, 12);
    return quotes
      .filter((row) => {
        const hay = [
          row.partNumber,
          row.customer,
          row.material,
          row.materialType,
          row.revision,
          ...(row.machines || []),
        ]
          .join(" ")
          .toLowerCase();
        return row.partNumber.toLowerCase().includes(q) || hay.includes(q);
      })
      .sort((a, b) => {
        const ap = a.partNumber.toLowerCase();
        const bp = b.partNumber.toLowerCase();
        const aStart = ap.startsWith(q) ? 0 : 1;
        const bStart = bp.startsWith(q) ? 0 : 1;
        if (aStart !== bStart) return aStart - bStart;
        return ap.localeCompare(bp);
      })
      .slice(0, 12);
  }, [quotes, partQuery]);

  useEffect(() => {
    setHighlight(0);
  }, [partQuery]);

  useEffect(() => {
    setForm((f) => ({
      ...f,
      setupTimes: padSlots(f.setupTimes, maxOps, 0),
      runTimes: padSlots(f.runTimes, maxOps, 0),
    }));
  }, [maxOps]);

  useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (!partWrapRef.current?.contains(e.target as Node)) {
        setSuggestOpen(false);
      }
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  function loadQuote(q: Quote, silent = false) {
    setForm({
      ...q,
      kind: q.kind === "assembly" ? "assembly" : "part",
      bom: q.kind === "assembly" ? [...(q.bom || [])] : [],
      benchAssembleMinutes: q.benchAssembleMinutes || 0,
      setupTimes: padSlots(q.setupTimes, maxOps, 0),
      runTimes: padSlots(q.runTimes, maxOps, 0),
      quantities: padSlots(q.quantities, 6, 0),
      machines: [...(q.machines || [])],
      prices: padSlots(q.prices, 6, 0),
      toolingCharges: normalizeToolingCharges(q.toolingCharges),
    });
    setPartQuery(q.partNumber);
    setLoadedId(q.id);
    setSuggestOpen(false);
    if (!silent) toast.success(`Loaded ${q.partNumber} from database`);
  }

  function onPartChange(value: string) {
    const upper = value.toUpperCase();
    setPartQuery(upper);
    setSuggestOpen(true);

    // Always: empty part # → entire form blank (no leftover defaults)
    if (!upper.trim()) {
      setForm(emptyForm(maxOps));
      setLoadedId(null);
      return;
    }

    const exact = quotes.find(
      (row) => row.partNumber.toLowerCase() === upper.trim().toLowerCase(),
    );
    if (exact) {
      loadQuote(exact, true);
      toast.success(`Loaded ${exact.partNumber}`);
      return;
    }

    // Unknown part — no auto-fill defaults. If we just left a loaded quote
    // (or blank), keep fields empty and only set part #.
    setForm((f) => {
      const leftLoaded = loadedId != null;
      const base =
        leftLoaded || !(f.partNumber || "").trim()
          ? emptyForm(maxOps)
          : f;
      return { ...base, partNumber: upper };
    });
    setLoadedId(null);
  }


  function onMaterialChange(material: string) {
    const options = allMaterialTypes(material, customLists);
    setForm((f) => {
      const stillValid = options.some(
        (t) => t.toLowerCase() === (f.materialType || "").toLowerCase(),
      );
      return {
        ...f,
        material,
        materialType: stillValid ? f.materialType : options[0] || "",
      };
    });
  }

  function setKind(kind: QuoteKind) {
    setForm((f) => {
      if (kind === "assembly") {
        const pn = (f.partNumber || partQuery || "").toUpperCase();
        let bom = f.bom && f.bom.length ? [...f.bom] : [];
        if (!bom.length && pn) {
          bom = suggestChildPartNumbers(pn, 2).map((child) =>
            emptyBomLine({ partNumber: child, qty: 1 }),
          );
        }
        return {
          ...f,
          kind,
          bom,
          benchAssembleMinutes: f.benchAssembleMinutes || 0,
          calculateMaterialDrop: false,
        };
      }
      return { ...f, kind: "part", bom: [], benchAssembleMinutes: 0 };
    });
  }

  function updateBom(index: number, patch: Partial<BomLine>) {
    setForm((f) => {
      const bom = [...(f.bom || [])];
      bom[index] = { ...emptyBomLine(bom[index]), ...patch };
      return { ...f, bom };
    });
  }

  function addBomLine() {
    setForm((f) => {
      const existing = f.bom || [];
      const suggested = suggestChildPartNumbers(
        f.partNumber || partQuery || "PART-01",
        existing.length + 1,
      );
      const nextPn = suggested[existing.length] || "";
      return { ...f, bom: [...existing, emptyBomLine({ partNumber: nextPn })] };
    });
  }

  function removeBomLine(index: number) {
    setForm((f) => ({
      ...f,
      bom: (f.bom || []).filter((_, i) => i !== index),
    }));
  }

  function suggestBomFromPn() {
    const pn = (form.partNumber || partQuery || "").toUpperCase();
    if (!pn) {
      toast.error("Enter the assembly part number first (e.g. NS-2200-01)");
      return;
    }
    const children = suggestChildPartNumbers(pn, 2);
    setForm((f) => ({
      ...f,
      kind: "assembly",
      partNumber: looksLikeAssemblyPn(pn) ? pn : pn,
      bom: children.map((c) => {
        const existing = quotes.find(
          (q) => q.partNumber.toLowerCase() === c.toLowerCase(),
        );
        return emptyBomLine({
          partNumber: c,
          revision: existing?.revision || "A",
          qty: 1,
          note: existing ? existing.materialType || "" : "",
        });
      }),
    }));
    setPartQuery(looksLikeAssemblyPn(pn) ? pn : pn);
    toast.success(`BOM set to ${children.join(" + ")}`);
  }

  function setNum(key: keyof Quote, value: string) {
    setForm((f) => ({ ...f, [key]: value === "" ? 0 : Number(value) }));
  }

  function setArr(
    key: "setupTimes" | "runTimes" | "quantities",
    index: number,
    value: string,
  ) {
    setForm((f) => {
      const arr = [...(f[key] || zeros(maxOps))];
      arr[index] = value === "" ? 0 : Number(value);
      return { ...f, [key]: arr };
    });
  }

  function handleSearch() {
    const q = getQuote(partQuery || form.partNumber);
    if (!q) {
      toast.error("No quote found for that part #");
      return;
    }
    loadQuote(q);
  }

  function handlePartKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (!suggestOpen || matches.length === 0) {
      if (e.key === "Enter") {
        e.preventDefault();
        handleSearch();
      }
      return;
    }
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setHighlight((h) => Math.min(h + 1, matches.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setHighlight((h) => Math.max(h - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      loadQuote(matches[highlight] || matches[0]);
    } else if (e.key === "Escape") {
      setSuggestOpen(false);
    }
  }

  async function handleSubmit(mode: "submit" | "update") {
    if (!form.partNumber.trim()) {
      toast.error("Part number required");
      return;
    }
    const quote = quoteFromForm(
      {
        ...form,
        partNumber: form.partNumber.trim().toUpperCase(),
        revision: (form.revision || "A").toString().trim().toUpperCase(),
        prices: costs.prices,
      },
      maxOps,
    );
    if (!quote.material?.trim()) {
      toast.message(
        "Saved without material — add material/size so PO import can auto-fill stock",
      );
    }
    const r = saveQuote(quote, mode);
    if (!r.ok) {
      toast.error(r.error);
      return;
    }
    // Force host DB write so Customer Orders import sees this part immediately
    try {
      await flushShopSync();
    } catch {
      /* local still has the quote */
    }
    const matBits = [
      quote.material,
      quote.materialType,
      quote.stockShape,
      quote.dimX
        ? `${quote.dimX}"${quote.dimY ? " × " + quote.dimY + '"' : ""}`
        : "",
    ]
      .filter(Boolean)
      .join(" · ");
    toast.success(
      `${mode === "submit" ? "Saved" : "Updated"} ${quote.partNumber} rev ${quote.revision}` +
        (matBits ? ` · ${matBits}` : " · (no material)"),
    );
    if (mode === "submit") {
      // Keep form loaded so user can confirm what was saved; don't wipe
      const saved = getQuote(quote.partNumber);
      if (saved) setLoadedId(saved.id);
      setPartQuery(quote.partNumber);
    } else {
      const saved = getQuote(form.partNumber);
      if (saved) setLoadedId(saved.id);
    }
  }

  function handleDelete() {
    if (!form.partNumber.trim()) return;
    if (!confirm(`Delete quote for ${form.partNumber}?`)) return;
    deleteQuote(form.partNumber);
    setForm(emptyForm(maxOps));
    setPartQuery("");
    setLoadedId(null);
    toast.success("Deleted");
  }

  function handleClear() {
    setForm(emptyForm(maxOps));
    setPartQuery("");
    setLoadedId(null);
    setSuggestOpen(false);
  }

  const machinePrimary = form.machines?.[0] || "";
  const stockShapeMissing = !(form.stockShape || "").trim();
  const shapeProfile = profileForShape(form.stockShape || "");

  return (
    <div className="mx-auto max-w-6xl space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight">
            Master Quoter
          </h1>
          <p className="text-sm text-[var(--color-muted)] mt-1">
            Type a part # to search the database — selecting a match fills the whole form
          </p>
        </div>
        <div className="flex flex-wrap gap-2 items-center">
          <Button
            type="button"
            variant="secondary"
            onClick={() => setGuidedOpen(true)}
          >
            Guided quote
          </Button>
          <Button onClick={() => handleSubmit("submit")}>
            <Save className="h-4 w-4" /> Save
          </Button>
          {(loadedId || form.partNumber?.trim()) && (
            <Button
              type="button"
              variant="secondary"
              onClick={() => {
                const go = (part: string, id?: string) => {
                  const q = new URLSearchParams();
                  if (id) q.set("quoteId", id);
                  if (part) q.set("part", part);
                  window.location.href = `/email?${q.toString()}`;
                };
                if (loadedId) {
                  go(form.partNumber || "", loadedId);
                  return;
                }
                if (!form.partNumber.trim()) {
                  toast.error("Enter a part number first");
                  return;
                }
                const quote = quoteFromForm(
                  { ...form, prices: costs.prices },
                  maxOps,
                );
                const r = saveQuote(quote, "update");
                if (!r.ok) {
                  toast.error(r.error || "Save quote before emailing");
                  return;
                }
                const saved = getQuote(form.partNumber);
                if (saved) setLoadedId(saved.id);
                go(form.partNumber, saved?.id);
              }}
            >
              <Mail className="h-4 w-4" /> Email
            </Button>
          )}
          <details className="relative">
            <summary className="list-none cursor-pointer inline-flex items-center justify-center rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2.5 text-sm font-medium min-h-11 hover:bg-[var(--color-surface-2)]">
              More…
            </summary>
            <div className="absolute right-0 z-20 mt-1 min-w-[11rem] rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface)] p-1 shadow-lg space-y-0.5">
              <button
                type="button"
                className="w-full text-left rounded px-3 py-2 text-sm hover:bg-[var(--color-surface-2)]"
                onClick={handleSearch}
              >
                Search database
              </button>
              <button
                type="button"
                className="w-full text-left rounded px-3 py-2 text-sm hover:bg-[var(--color-surface-2)]"
                onClick={() => handleSubmit("update")}
              >
                Update existing
              </button>
              <button
                type="button"
                className="w-full text-left rounded px-3 py-2 text-sm hover:bg-[var(--color-surface-2)]"
                onClick={handleClear}
              >
                Clear form
              </button>
              <button
                type="button"
                className="w-full text-left rounded px-3 py-2 text-sm text-[var(--color-danger)] hover:bg-[var(--color-surface-2)]"
                onClick={handleDelete}
              >
                Delete part
              </button>
            </div>
          </details>
        </div>
      </div>

      {loadedId && (
        <div className="rounded-[var(--radius-md)] border border-[color-mix(in_oklab,var(--color-accent)_35%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-accent)_8%,var(--color-surface))] px-3 py-2 text-sm">
          Loaded from database:{" "}
          <span className="font-semibold">{form.partNumber}</span>
          {form.customer ? (
            <span className="text-[var(--color-muted)]"> · {form.customer}</span>
          ) : null}
          {form.revision ? (
            <span className="text-[var(--color-muted)]"> · Rev {form.revision}</span>
          ) : null}
          {isAssembly ? (
            <span className="ml-2 text-[10px] uppercase tracking-wide px-1.5 py-0.5 rounded bg-[color-mix(in_oklab,var(--color-accent)_18%,transparent)] text-[var(--color-accent)]">
              Assembly
            </span>
          ) : null}
        </div>
      )}

      {partEvidence && partEvidence.stats.completedRuns > 0 && (
        <details className="rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-surface)] group">
          <summary className="cursor-pointer list-none px-4 py-3 flex items-center justify-between gap-2">
            <div>
              <div className="text-base font-semibold">
                Shop evidence
                <span className="ml-2 text-xs font-normal text-[var(--color-muted)]">
                  {partEvidence.stats.completedRuns} floor run
                  {partEvidence.stats.completedRuns === 1 ? "" : "s"}
                </span>
              </div>
              <div className="text-xs text-[var(--color-muted)] mt-0.5">
                Floor proof for reprice — expand when needed
              </div>
            </div>
            <span className="text-xs text-[var(--color-subtle)] group-open:hidden">Show</span>
            <span className="text-xs text-[var(--color-subtle)] hidden group-open:inline">Hide</span>
          </summary>
          <div className="px-4 pb-4 space-y-4 text-sm border-t border-[var(--color-border)] pt-3">
            <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)]/60 px-3 py-2.5 text-xs text-[var(--color-muted)] leading-relaxed space-y-1.5">
              <p>
                <strong className="text-[var(--color-fg)]">Price each is always calculated.</strong>{" "}
                Setup, runtime, material, machine %, qty breaks → the green{" "}
                <em>Price each</em> row. You do not type a unit price; change the
                recipe and the price moves with it.
              </p>
              <p>
                <strong className="text-[var(--color-fg)]">How to read floor runs:</strong>{" "}
                <span className="text-[var(--color-fg)]/90">Time sold → actual</span>{" "}
                compares the time built into that quote vs what the job really
                took.{" "}
                <span className="text-[var(--color-danger)]">+%</span> = slower
                than sold (price may need to go up).{" "}
                <span className="text-[var(--color-success)]">−%</span> = faster
                (margin room).
              </p>
              <p>
                <strong className="text-[var(--color-fg)]">What averages change:</strong>{" "}
                Completed jobs can update <em>setup & run times</em> on the
                saved part. Next time you open it, Price each recalculates from
                those times — so the number can move because the recipe moved,
                not because we invent a price.
              </p>
              <p>
                <strong className="text-[var(--color-fg)]">What “lock / history” is:</strong>{" "}
                A photo of the <em>calculated</em> qty & $ each at that
                moment (save, email, or lock). History does not change later;
                the live quoter still always recalculates from current data.
              </p>
            </div>

            <div className="flex flex-wrap gap-2 text-xs">
              <span className="rounded-full border border-[var(--color-border)] px-2.5 py-1">
                <strong>{partEvidence.stats.completedRuns}</strong> completed
                run{partEvidence.stats.completedRuns === 1 ? "" : "s"} on record
              </span>
              <span className="rounded-full border border-[var(--color-border)] px-2.5 py-1">
                Average built from{" "}
                <strong>{partEvidence.stats.averagedRuns}</strong> good run
                {partEvidence.stats.averagedRuns === 1 ? "" : "s"}
                {partEvidence.stats.excludedRuns
                  ? ` · ${partEvidence.stats.excludedRuns} left out (outliers / unmarked)`
                  : ""}
              </span>
              <span className="rounded-full border border-[var(--color-border)] px-2.5 py-1">
                Shop avg efficiency{" "}
                <strong>
                  {formatPercent(partEvidence.stats.avgEfficiency)}
                </strong>
              </span>
            </div>

            <div>
              <div className="text-xs font-semibold text-[var(--color-fg)] mb-1">
                Last floor runs (newest first)
              </div>
              <p className="text-[11px] text-[var(--color-subtle)] mb-2">
                Each row is one completed job. Compare time sold vs time used
                before you submit a new price.
              </p>
              <div className="overflow-x-auto">
                <table className="w-full text-xs min-w-[520px]">
                  <thead>
                    <tr className="text-[var(--color-muted)] border-b border-[var(--color-border)]">
                      <th className="py-1.5 text-left font-medium">When</th>
                      <th className="py-1.5 text-left font-medium">Machine</th>
                      <th className="py-1.5 text-right font-medium">
                        Time sold → actual
                      </th>
                      <th className="py-1.5 text-right font-medium">
                        vs sold time
                      </th>
                      <th className="py-1.5 text-right font-medium">
                        Efficiency
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {partEvidence.runs.map((j) => {
                      const vs = jobVsQuote(j);
                      const pct =
                        vs.quotedSeconds > 0
                          ? ((vs.actualSeconds - vs.quotedSeconds) /
                              vs.quotedSeconds) *
                            100
                          : 0;
                      const eff =
                        j.efficiency > 1 ? j.efficiency / 100 : j.efficiency;
                      return (
                        <tr
                          key={j.id}
                          className="border-b border-[var(--color-border)] last:border-0"
                        >
                          <td className="py-1.5 whitespace-nowrap">
                            {formatDateTime(j.endTime || j.startTime)}
                          </td>
                          <td className="py-1.5">{j.machine}</td>
                          <td className="py-1.5 text-right tabular">
                            {formatSeconds(vs.quotedSeconds)} →{" "}
                            {formatSeconds(vs.actualSeconds)}
                          </td>
                          <td
                            className={`py-1.5 text-right tabular font-medium ${
                              pct > 5
                                ? "text-[var(--color-danger)]"
                                : pct < -5
                                  ? "text-[var(--color-success)]"
                                  : ""
                            }`}
                          >
                            {pct > 0 ? "+" : ""}
                            {pct.toFixed(0)}%
                            <span className="block text-[10px] font-normal text-[var(--color-subtle)]">
                              {pct > 5
                                ? "slower — consider raise"
                                : pct < -5
                                  ? "faster — margin headroom"
                                  : "about as quoted"}
                            </span>
                          </td>
                          <td className="py-1.5 text-right tabular">
                            {formatPercent(eff)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            <div>
              <div className="text-xs font-semibold text-[var(--color-fg)] mb-1">
                Past calculated prices (history)
              </div>
              <p className="text-[11px] text-[var(--color-subtle)] mb-2">
                What Price each was when you saved, emailed, or locked — from
                the quoter math at that moment. Compare to today's live
                Price each if setup/run/material changed.
              </p>
              {partEvidence.snaps.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {partEvidence.snaps.map((s) => (
                    <div
                      key={s.id}
                      className="rounded-md border border-[var(--color-border)] px-2.5 py-1.5 text-[11px]"
                    >
                      <div className="text-[var(--color-muted)]">
                        {s.reason === "email"
                          ? "Emailed"
                          : s.reason === "manual_lock"
                            ? "Locked"
                            : "Saved"}{" "}
                        · {new Date(s.frozenAt).toLocaleDateString()}
                        {s.emailedTo ? ` · ${s.emailedTo}` : ""}
                      </div>
                      <div className="flex flex-wrap gap-1.5 mt-0.5">
                        {s.quantities.map((q, i) =>
                          q > 0 ? (
                            <span key={i} className="tabular font-medium">
                              qty {q} @ {formatCurrency(s.prices[i] || 0)} ea
                            </span>
                          ) : null,
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-[var(--color-muted)]">
                  No frozen price yet — email a quote or use lock below after you
                  set qty breaks.
                </p>
              )}
            </div>

            {loadedId && (
              <div className="flex flex-col sm:flex-row sm:items-center gap-2 pt-1">
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    if (!form.partNumber.trim()) {
                      toast.error("Part number required");
                      return;
                    }
                    // Persist current form + live prices, then lock snapshot
                    const quote = quoteFromForm(
                      { ...form, prices: costs.prices },
                      maxOps,
                    );
                    const saveR = saveQuote(quote, "update");
                    if (!saveR.ok) {
                      toast.error(saveR.error);
                      return;
                    }
                    const saved = getQuote(form.partNumber);
                    if (!saved) {
                      toast.error("Quote not found after save");
                      return;
                    }
                    setLoadedId(saved.id);
                    const r = freezeQuotePrices(saved.id, "manual_lock");
                    if (!r.ok) toast.error(r.error);
                    else
                      toast.success(
                        "History now has this Price each (from setup/run/material/qty)",
                      );
                  }}
                >
                  Lock today's calculated prices
                </Button>
                <span className="text-[11px] text-[var(--color-subtle)]">
                  Writes a history photo of the Price each row (from setup /
                  run / material / qty) — not a typed price.
                </span>
              </div>
            )}
          </div>
        </details>
      )}

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Part & material</CardTitle>
          </CardHeader>
          <CardContent className="grid sm:grid-cols-2 gap-3">
            <div className="space-y-1.5 sm:col-span-2" ref={partWrapRef}>
              <Label>Part # <HelpTip id="quote-part-search" /></Label>
              <div className="relative">
                <Input
                  value={partQuery}
                  onChange={(e) => onPartChange(e.target.value)}
                  onFocus={() => setSuggestOpen(true)}
                  onKeyDown={handlePartKeyDown}
                  placeholder="Start typing part number…"
                  autoComplete="off"
                  spellCheck={false}
                  className="font-medium tracking-wide"
                />
                {suggestOpen && (
                  <div className="absolute z-30 mt-1 w-full max-h-72 overflow-y-auto rounded-[var(--radius-md)] border border-[var(--color-border-strong)] bg-[var(--color-surface)] shadow-xl">
                    {matches.length === 0 ? (
                      <div className="px-3 py-3 text-sm text-[var(--color-muted)]">
                        {partQuery.trim()
                          ? "No matching parts — keep typing for a new quote"
                          : "No parts in database yet"}
                      </div>
                    ) : (
                      <ul role="listbox">
                        {matches.map((row, i) => (
                          <li key={row.id}>
                            <button
                              type="button"
                              role="option"
                              aria-selected={i === highlight}
                              className={`w-full text-left px-3 py-2.5 min-h-11 border-b border-[var(--color-border)] last:border-0 ${
                                i === highlight
                                  ? "bg-[var(--color-surface-3)]"
                                  : "hover:bg-[var(--color-surface-2)]"
                              }`}
                              onMouseEnter={() => setHighlight(i)}
                              onClick={() => loadQuote(row)}
                            >
                              <div className="flex items-baseline justify-between gap-2">
                                <span className="font-semibold tracking-wide">
                                  {row.partNumber}
                                  {row.kind === "assembly" ? (
                                    <span className="ml-1.5 text-[10px] font-medium text-[var(--color-accent)]">
                                      ASM
                                    </span>
                                  ) : null}
                                </span>
                                <span className="text-[11px] text-[var(--color-muted)] shrink-0">
                                  Rev {row.revision || "—"}
                                </span>
                              </div>
                              <div className="text-xs text-[var(--color-muted)] truncate mt-0.5">
                                {row.customer || "No customer"}
                                {row.material
                                  ? ` · ${row.material}${row.materialType ? ` ${row.materialType}` : ""}`
                                  : ""}
                                {row.machines?.[0] ? ` · ${row.machines[0]}` : ""}
                              </div>
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                )}
              </div>
              <p className="text-[11px] text-[var(--color-subtle)]">
                Filters as you type. Click a result (or press Enter) to fill the entire quoter.
              </p>
            </div>

            <Field label="Quote type">
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setKind("part")}
                  className={`min-h-11 rounded-[var(--radius-md)] border text-sm font-medium ${
                    !isAssembly
                      ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)]"
                      : "border-[var(--color-border)] hover:bg-[var(--color-surface-2)]"
                  }`}
                >
                  Single part
                </button>
                <button
                  type="button"
                  onClick={() => setKind("assembly")}
                  className={`min-h-11 rounded-[var(--radius-md)] border text-sm font-medium inline-flex items-center justify-center gap-1.5 ${
                    isAssembly
                      ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)]"
                      : "border-[var(--color-border)] hover:bg-[var(--color-surface-2)]"
                  }`}
                >
                  <Layers className="h-3.5 w-3.5" /> Assembly (-01)
                </button>
              </div>
              <p className="text-[11px] text-[var(--color-subtle)] mt-1">
                Assembly = -01 parent · children -02/-03 · one sell price
              </p>
            </Field>
            <Field label="Customer">
              <CreatableSelect
                value={form.customer || ""}
                options={customerOptions}
                onChange={(v) => setForm((f) => ({ ...f, customer: v }))}
                onCreate={(v) => {
                  const r = addCustomerQuick(v);
                  if (!r.ok) {
                    toast.error(r.error);
                    return false;
                  }
                  toast.success(`Added customer ${v}`);
                }}
                createTitle="Add customer"
                createHint="Saved to the customer list for future quotes."
              />
            </Field>
            <Field label="Revision">
              <Input
                value={form.revision || ""}
                onChange={(e) =>
                  setForm((f) => ({ ...f, revision: e.target.value.toUpperCase() }))
                }
              />
            </Field>
            <Field label="Machines (select all that apply)">
              <div className="flex flex-wrap gap-2">
                {machineOptions.map((m) => {
                  const on = (form.machines || []).includes(m);
                  return (
                    <button
                      key={m}
                      type="button"
                      onClick={() =>
                        setForm((f) => {
                          const cur = f.machines || [];
                          const next = on
                            ? cur.filter((x) => x !== m)
                            : [...cur, m];
                          return { ...f, machines: next };
                        })
                      }
                      className={
                        "rounded-full border px-3 py-1.5 text-xs font-medium min-h-9 transition-colors " +
                        (on
                          ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_16%,transparent)] text-[var(--color-primary)]"
                          : "border-[var(--color-border)] text-[var(--color-muted)] hover:bg-[var(--color-surface-2)]")
                      }
                    >
                      {m}
                    </button>
                  );
                })}
              </div>
              <p className="text-[11px] text-[var(--color-subtle)] mt-1">
                Job averages and shop history use these machines when matching past runs.
                {(form.machines || []).length
                  ? ` Selected: ${(form.machines || []).join(", ")}`
                  : " None selected yet."}
              </p>
            </Field>
            <Field label="Machine %">
              <SmartNumberInput
                value={form.machineRate ?? 0}
                onValueChange={(n) =>
                  setForm((f) => ({ ...f, machineRate: n || 0 }))
                }
                format="plain"
                emptyMeans={0}
              />
              <p className="text-[11px] text-[var(--color-subtle)] mt-1">
                1 = actual · 1.25 = 25% markup on run time
              </p>
            </Field>
            <Field label="Material">
              <CreatableSelect
                allowEmpty={true}
                value={form.material || ""}
                options={materialOptions}
                onChange={onMaterialChange}
                onCreate={(v) => {
                  const r = addCustomListItem("materials", v);
                  if (!r.ok) {
                    toast.error(r.error);
                    return false;
                  }
                  toast.success(`Added material ${v}`);
                }}
                createTitle="Add material"
                createHint="e.g. Inconel, Magnesium"
              />
              <p className="text-[11px] text-[var(--color-subtle)] mt-1">
                Base material — filters the type list below
              </p>
            </Field>
            <Field label="Material type">
              <CreatableSelect
                allowEmpty={true}
                value={form.materialType || ""}
                options={typeOptions}
                onChange={(v) => setForm((f) => ({ ...f, materialType: v }))}
                onCreate={(v) => {
                  const mat = form.material || "Other";
                  const r = addCustomListItem("materialTypes", v, mat);
                  if (!r.ok) {
                    toast.error(r.error);
                    return false;
                  }
                  toast.success(`Added ${v} under ${mat}`);
                }}
                createTitle={`Add type for ${form.material || "material"}`}
                createHint="e.g. T6 6061, 4140 HT — saved under the selected material"
              />
              <p className="text-[11px] text-[var(--color-subtle)] mt-1">
                Alloy / temper for {form.material || "material"} only
              </p>
            </Field>
            <Field label="Material %">
              <SmartNumberInput
                value={form.materialPct ?? 0}
                onValueChange={(n) =>
                  setForm((f) => ({ ...f, materialPct: n || 0 }))
                }
                format="plain"
                emptyMeans={0}
              />
              <p className="text-[11px] text-[var(--color-subtle)] mt-1">
                1 = actual · 1.15 = 15% markup on material
              </p>
            </Field>
            <Field label="Stock shape">
              <div
                className={
                  stockShapeMissing
                    ? "rounded-[var(--radius-md)] ring-2 ring-amber-400/70 ring-offset-2 ring-offset-[var(--color-surface)]"
                    : undefined
                }
              >
                <CreatableSelect
                  allowEmpty={true}
                  value={form.stockShape || ""}
                  options={stockShapeOptions}
                  onChange={(v) =>
                    setForm((f) => ({
                      ...f,
                      stockShape: v,
                      // New shape → wipe size & material fields tied to the old stock
                      dimX: 0,
                      dimY: 0,
                      dimZ: 0,
                      partLengthEach: 0,
                      rawMaterialLength: 0,
                      rawMaterialCost: 0,
                    }))
                  }
                  onCreate={(v) => {
                    const r = addCustomListItem("stockShapes", v);
                    if (!r.ok) {
                      toast.error(r.error);
                      return false;
                    }
                    toast.success(`Added stock shape ${v}`);
                  }}
                  createTitle="Add stock shape"
                />
              </div>
              <p
                className={
                  stockShapeMissing
                    ? "text-[11px] text-amber-300 mt-1 font-medium"
                    : "text-[11px] text-[var(--color-subtle)] mt-1"
                }
              >
                {stockShapeMissing
                  ? "Not set — pick Round, Hex, Flat, Sheet, etc. (yellow = needs attention)"
                  : `${shapeProfile.title}: ${shapeProfile.summary}`}
              </p>
            </Field>

            <div className="sm:col-span-2 rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)]/50 p-3 space-y-3">
              <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">
                Cross-section / blank
              </div>
              <div className="grid sm:grid-cols-2 gap-3">
                {shapeProfile.section.map((field) => (
                  <Field key={field.key} label={field.label}>
                    <SmartNumberInput
                      value={Number(form[field.key as DimKey]) || 0}
                      onValueChange={(n) =>
                        setForm((f) => ({ ...f, [field.key]: n }))
                      }
                      format="inches"
                    />
                    {field.hint ? (
                      <p className="text-[11px] text-[var(--color-subtle)] mt-1">
                        {field.hint}
                      </p>
                    ) : null}
                  </Field>
                ))}
              </div>
              <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)] pt-1">
                Cut & stock (material $)
              </div>
              <div className="grid sm:grid-cols-2 gap-3">
                {shapeProfile.cut.map((field) => (
                  <Field key={field.key} label={field.label}>
                    <SmartNumberInput
                      value={Number(form[field.key as DimKey]) || 0}
                      onValueChange={(n) =>
                        setForm((f) => ({ ...f, [field.key]: n }))
                      }
                      format="inches"
                    />
                    {field.hint ? (
                      <p className="text-[11px] text-[var(--color-subtle)] mt-1">
                        {field.hint}
                      </p>
                    ) : null}
                  </Field>
                ))}
              </div>
              <p className="text-[11px] text-[var(--color-subtle)] leading-relaxed">
                Cost uses (cut / stock) × raw material cost × material %. Section
                sizes stay on the part for inventory match and drawings — they do
                not double as a second length.
              </p>
            </div>

            <Field label="Raw material cost">
              <SmartNumberInput
                value={form.rawMaterialCost ?? 0}
                onValueChange={(n) =>
                  setForm((f) => ({ ...f, rawMaterialCost: n }))
                }
                format="currency"
              />
            </Field>
            <div className="rounded-md border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-2">
              <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">
                {LCM_CALC_LABEL}
              </div>
              {emj.ok ? (
                <>
                  <p className="text-sm leading-snug">
                    <strong>{emj.grade}</strong>
                    {" · "}
                    {formatCurrency(emj.pricePerLb)}/lb
                    {emj.lbPerFoot > 0 ? (
                      <>
                        {" · "}
                        {emj.lbPerFoot.toFixed(3)} lb/ft
                        {" · "}
                        {formatCurrency((emj.lbPerFoot * emj.pricePerLb) / 12)}
                        /in
                      </>
                    ) : null}
                    {emj.stockCost > 0 ? (
                      <>
                        {" · "}
                        {emj.totalLb} lb ={" "}
                        <strong>{formatCurrency(emj.stockCost)}</strong> stock
                      </>
                    ) : null}
                    {emj.cutCost > 0 ? (
                      <>
                        {" · cut "}
                        {formatCurrency(emj.cutCost)}
                      </>
                    ) : null}
                  </p>
                  <p className="text-[11px] text-[var(--color-subtle)]">
                    {emj.formula}
                    {emj.stockCost <= 0
                      ? " · set stock length for full stick $"
                      : ""}
                  </p>
                  {emj.stockCost > 0 ? (
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      onClick={() =>
                        setForm((f) => ({
                          ...f,
                          rawMaterialCost: emj.stockCost,
                        }))
                      }
                    >
                      Use as raw material cost
                    </Button>
                  ) : null}
                </>
              ) : (
                <p className="text-sm text-[var(--color-muted)]">
                  {emj.error ||
                    "Set material, type, shape, section, and stock length to estimate."}
                </p>
              )}
            </div>
            <Field label="Calculate material drop">
              <Select
                value={form.calculateMaterialDrop ? "yes" : "no"}
                onChange={(e) =>
                  setForm((f) => ({
                    ...f,
                    calculateMaterialDrop: e.target.value === "yes",
                  }))
                }
              >
                <option value="no">No</option>
                <option value="yes">Yes</option>
              </Select>
            </Field>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-4 w-4" /> Live costs
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            {isAssembly && (
              <CostRow label="BOM (children)" value={formatCurrency(costs.bomCost || 0)} />
            )}
            {isAssembly && (
              <CostRow label="Bench bolt-up" value={formatCurrency(costs.benchCost || 0)} />
            )}
            <CostRow label="Material w/ %" value={formatCurrency(costs.materialCostWithPct)} />
            <CostRow label="Setup cost" value={formatCurrency(costs.setupCost)} />
            <CostRow
              label={isAssembly ? "Final machine run" : "Run cost"}
              value={formatCurrency(costs.runCost)}
            />
            <CostRow
              label={isAssembly ? "Assembly unit total" : "Base total"}
              value={formatCurrency(costs.baseTotal)}
              strong
            />
            <CostRow
              label="Special tools shop cost (not in price each)"
              value={formatCurrency(
                toolingShopCostTotal(form.toolingCharges as QuoteToolingCharge[] | undefined),
              )}
            />
          </CardContent>
        </Card>
      </div>


      {isAssembly && (
        <Card>
          <CardHeader className="flex-row items-start justify-between gap-3">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Layers className="h-4 w-4" /> Assembly BOM
              </CardTitle>
              <p className="text-xs text-[var(--color-muted)] mt-1">
                Shop flow: machine -02 & -03 → bench bolt → final ops on -01 (grid below).
                Child costs pull from the parts database when those quotes exist.
              </p>
            </div>
            <div className="flex flex-wrap gap-2 shrink-0">
              <Button type="button" size="sm" variant="outline" onClick={suggestBomFromPn}>
                Suggest -02 / -03
              </Button>
              <Button type="button" size="sm" variant="secondary" onClick={addBomLine}>
                <Plus className="h-4 w-4" /> Line
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full text-sm min-w-[640px]">
                <thead>
                  <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
                    <th className="pb-2 font-medium">Child part #</th>
                    <th className="pb-2 font-medium">Rev</th>
                    <th className="pb-2 font-medium">Qty</th>
                    <th className="pb-2 font-medium">Note</th>
                    <th className="pb-2 font-medium text-right">Unit $</th>
                    <th className="pb-2 font-medium text-right">Ext $</th>
                    <th className="pb-2 font-medium"></th>
                  </tr>
                </thead>
                <tbody>
                  {(form.bom || []).map((row, i) => {
                    const sum = bomSummary.lines[i];
                    return (
                      <tr key={i} className="border-b border-[var(--color-border)] last:border-0">
                        <td className="py-2 pr-2">
                          <Input
                            value={row.partNumber}
                            onChange={(e) =>
                              updateBom(i, { partNumber: e.target.value.toUpperCase() })
                            }
                            list={`bom-parts-${i}`}
                            className="font-medium"
                          />
                          <datalist id={`bom-parts-${i}`}>
                            {quotes
                              .filter((q) => q.kind !== "assembly")
                              .map((q) => (
                                <option key={q.id} value={q.partNumber} />
                              ))}
                          </datalist>
                          {sum && !sum.found && row.partNumber ? (
                            <span className="text-[10px] text-[var(--color-warn)]">
                              Not in DB yet
                            </span>
                          ) : null}
                        </td>
                        <td className="py-2 pr-2 w-20">
                          <Input
                            value={row.revision}
                            onChange={(e) =>
                              updateBom(i, { revision: e.target.value.toUpperCase() })
                            }
                          />
                        </td>
                        <td className="py-2 pr-2 w-20">
                          <Input
                            type="number"
                            min={1}
                            value={row.qty}
                            onChange={(e) =>
                              updateBom(i, { qty: Number(e.target.value) || 1 })
                            }
                          />
                        </td>
                        <td className="py-2 pr-2">
                          <Input
                            value={row.note}
                            onChange={(e) => updateBom(i, { note: e.target.value })}
                            placeholder="Housing, shaft…"
                          />
                        </td>
                        <td className="py-2 text-right tabular text-[var(--color-muted)]">
                          {sum?.found ? formatCurrency(sum.unitCost) : "—"}
                        </td>
                        <td className="py-2 text-right tabular font-medium">
                          {sum?.found ? formatCurrency(sum.extCost) : "—"}
                        </td>
                        <td className="py-2">
                          <Button
                            type="button"
                            size="icon"
                            variant="ghost"
                            onClick={() => removeBomLine(i)}
                            aria-label="Remove"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                  {(form.bom || []).length === 0 && (
                    <tr>
                      <td colSpan={7} className="py-6 text-center text-[var(--color-muted)]">
                        No BOM lines — use Suggest -02 / -03 or add a line
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            <div className="grid sm:grid-cols-2 gap-3 max-w-xl">
              <div className="space-y-1.5">
                <Label>Bench assemble (minutes)</Label>
                <Input
                  type="number"
                  min={0}
                  step="0.1"
                  value={form.benchAssembleMinutes ?? 0}
                  onChange={(e) =>
                    setForm((f) => ({
                      ...f,
                      benchAssembleMinutes: Number(e.target.value) || 0,
                    }))
                  }
                />
                <p className="text-[11px] text-[var(--color-subtle)]">
                  Bolt / fit on the bench before final machine ops
                </p>
              </div>
              <div className="panel-inset p-3 flex flex-col justify-center">
                <div className="text-xs text-[var(--color-muted)]">BOM roll-up / assembly</div>
                <div className="text-xl font-semibold tabular mt-1">
                  {formatCurrency(bomSummary.total)}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>
            {isAssembly
              ? `Final -01 machine ops (minutes) · OP1–OP${maxOps}`
              : `Setup & run times (minutes) · OP1–OP${maxOps}`}
          </CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full text-sm" style={{ minWidth: Math.max(640, maxOps * 88) }}>
            <thead>
              <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
                <th className="pb-2 font-medium sticky left-0 bg-[var(--color-surface)]"> </th>
                {opLabels.map((label) => (
                  <th key={label} className="pb-2 font-medium">
                    {label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-[var(--color-border)]">
                <td className="py-2 text-[var(--color-muted)]">Setup min</td>
                {(form.setupTimes || []).map((v, i) => (
                  <td key={i} className="py-2 pr-2">
                    <SmartNumberInput
                      className="h-9 tabular-nums"
                      value={Number(v) || 0}
                      onValueChange={(n) =>
                        setArr("setupTimes", i, n === 0 ? "" : String(n))
                      }
                    />
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-2 text-[var(--color-muted)]">Run min/pc</td>
                {(form.runTimes || []).map((v, i) => (
                  <td key={i} className="py-2 pr-2">
                    <SmartNumberInput
                      className="h-9 tabular-nums"
                      value={Number(v) || 0}
                      onValueChange={(n) =>
                        setArr("runTimes", i, n === 0 ? "" : String(n))
                      }
                    />
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </CardContent>
      </Card>



      {floorToolingLogs.length > 0 && (
        <Card className="border-[color-mix(in_oklab,var(--color-warn)_40%,var(--color-border))]">
          <CardHeader>
            <CardTitle className="text-base">Shop floor time</CardTitle>
            <p className="text-xs text-[var(--color-muted)] mt-1">
              Operators timed soft jaws / other on the machine. Adjust minutes
              and customer amount here before you put it on the quote or send
              email.
            </p>
          </CardHeader>
          <CardContent className="space-y-3">
            {floorToolingLogs.map((log) => {
              const liveMin = liveToolingMinutes(log);
              const draft = floorDrafts[log.id] || {
                minutes: String(liveMin || ""),
                billUnitPrice: String(
                  log.suggestedBillAmount > 0
                    ? log.suggestedBillAmount
                    : shopCostFromToolingMinutes(liveMin) || "",
                ),
                shopCost: String(
                  shopCostFromToolingMinutes(liveMin) ||
                    log.suggestedBillAmount ||
                    "",
                ),
                billCustomer: true,
                description:
                  log.description ||
                  TOOLING_KIND_LABEL[log.kind] ||
                  "Special tool",
              };
              const setDraft = (
                patch: Partial<typeof draft>,
              ) =>
                setFloorDrafts((prev) => ({
                  ...prev,
                  [log.id]: { ...draft, ...patch },
                }));
              return (
                <div
                  key={log.id}
                  className="rounded-[var(--radius-md)] border border-[var(--color-border)] p-3 space-y-3"
                >
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <div className="font-semibold">
                        {TOOLING_KIND_LABEL[log.kind] || "Tooling"}
                        {log.timerStartedAt ? " · timer still running" : ""}
                      </div>
                      <div className="text-xs text-[var(--color-muted)]">
                        {log.operator || "—"} · {log.machine || "—"}
                        {log.partNumber ? ` · ${log.partNumber}` : ""}
                      </div>
                      {log.notes ? (
                        <p className="text-sm mt-1 text-[var(--color-muted)]">
                          {log.notes}
                        </p>
                      ) : null}
                    </div>
                  </div>
                  <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    <div className="space-y-1.5 sm:col-span-2">
                      <Label>Description (customer line)</Label>
                      <Input
                        value={draft.description}
                        onChange={(e) =>
                          setDraft({ description: e.target.value })
                        }
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Minutes (adjust)</Label>
                      <SmartNumberInput
                        className="h-10 tabular-nums"
                        value={Number(draft.minutes) || 0}
                        onValueChange={(n) => {
                          const mins = n;
                          const cost = shopCostFromToolingMinutes(mins);
                          setDraft({
                            minutes: n === 0 ? "" : String(n),
                            shopCost: cost > 0 ? String(cost) : draft.shopCost,
                            billUnitPrice:
                              !draft.billUnitPrice ||
                              Number(draft.billUnitPrice) ===
                                shopCostFromToolingMinutes(
                                  Number(draft.minutes) || 0,
                                )
                                ? cost > 0
                                  ? String(cost)
                                  : draft.billUnitPrice
                                : draft.billUnitPrice,
                          });
                        }}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Shop cost (internal)</Label>
                      <SmartNumberInput
                        className="h-10 tabular-nums"
                        value={Number(draft.shopCost) || 0}
                        onValueChange={(n) =>
                          setDraft({
                            shopCost: n === 0 ? "" : String(n),
                          })
                        }
                      />
                    </div>
                  </div>
                  <label className="inline-flex items-center gap-2 text-sm min-h-10">
                    <input
                      type="checkbox"
                      checked={draft.billCustomer}
                      onChange={(e) =>
                        setDraft({ billCustomer: e.target.checked })
                      }
                    />
                    Bill customer as separate line
                  </label>
                  {draft.billCustomer && (
                    <div className="space-y-1.5 max-w-xs">
                      <Label>Customer price each</Label>
                      <SmartNumberInput
                        className="h-10 tabular-nums"
                        value={Number(draft.billUnitPrice) || 0}
                        onValueChange={(n) =>
                          setDraft({
                            billUnitPrice: n === 0 ? "" : String(n),
                          })
                        }
                      />
                      <p className="text-[11px] text-[var(--color-subtle)]">
                        This is what appears on the quote email — change freely
                        before sending.
                      </p>
                    </div>
                  )}
                  <div className="flex flex-wrap gap-2">
                    <Button
                      type="button"
                      size="sm"
                      onClick={() => {
                        if (!form.partNumber?.trim()) {
                          toast.error("Load or enter the part first");
                          return;
                        }
                        const quote = quoteFromForm(
                          { ...form, prices: costs.prices },
                          maxOps,
                        );
                        const r0 = saveQuote(quote, "update");
                        if (!r0.ok) {
                          toast.error(r0.error || "Save quote first");
                          return;
                        }
                        const saved = getQuote(form.partNumber);
                        const r = applyShopToolingLogToQuote(
                          log.id,
                          saved?.id || loadedId || undefined,
                          {
                            minutes: Number(draft.minutes) || 0,
                            billUnitPrice: Number(draft.billUnitPrice) || 0,
                            shopCost: Number(draft.shopCost) || 0,
                            billCustomer: draft.billCustomer,
                            description: draft.description,
                          },
                        );
                        if (!r.ok) {
                          toast.error(r.error || "Could not apply");
                          return;
                        }
                        setFloorDrafts((prev) => {
                          const next = { ...prev };
                          delete next[log.id];
                          return next;
                        });
                        const refreshed = getQuote(form.partNumber);
                        if (refreshed) loadQuote(refreshed, true);
                        toast.success(
                          draft.billCustomer
                            ? "Added to quote — adjust line below if needed"
                            : "Stored on quote (not billed)",
                        );
                      }}
                    >
                      Add to quote
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        resolveShopToolingLog(log.id, "no_charge");
                        toast.message("Marked no charge");
                      }}
                    >
                      No charge
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        resolveShopToolingLog(log.id, "dismissed");
                        toast.message("Dismissed");
                      }}
                    >
                      Dismiss
                    </Button>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      <details
        className="rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-surface)] group"
        open={(form.toolingCharges || []).length > 0 || undefined}
      >
        <summary className="cursor-pointer list-none px-4 py-3">
          <div className="text-base font-semibold flex items-center gap-2">
            Special tools
            {(form.toolingCharges || []).length > 0 ? (
              <span className="text-xs font-normal text-[var(--color-muted)]">
                {(form.toolingCharges || []).length} on quote
              </span>
            ) : (
              <span className="text-xs font-normal text-[var(--color-subtle)]">
                optional · expand to add
              </span>
            )}
          </div>
          <div className="text-xs text-[var(--color-muted)] mt-0.5">
            Soft jaws & extras — separate from part price each
          </div>
        </summary>
        <div className="px-4 pb-4 space-y-3 border-t border-[var(--color-border)] pt-3">
          {(form.toolingCharges || []).length === 0 && (
            <p className="text-sm text-[var(--color-muted)]">
              No special tools on this quote yet.
            </p>
          )}
          {(form.toolingCharges || []).map((row, idx) => {
            const charge = row as QuoteToolingCharge;
            return (
              <div
                key={charge.id || idx}
                className="rounded-[var(--radius-md)] border border-[var(--color-border)] p-3 space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <Select
                      value={
                        charge.kind === "soft_jaws" || charge.kind === "other"
                          ? charge.kind
                          : "special_tool"
                      }
                      onChange={(e) => {
                        const kind = e.target.value as QuoteToolingKind;
                        setForm((f) => {
                          const list = [
                            ...(f.toolingCharges || []),
                          ] as QuoteToolingCharge[];
                          const prev = list[idx];
                          const next = {
                            ...prev,
                            kind,
                            description:
                              !prev.description ||
                              prev.description ===
                                TOOLING_KIND_LABEL[prev.kind]
                                ? TOOLING_KIND_LABEL[kind]
                                : prev.description,
                          };
                          list[idx] = next;
                          return { ...f, toolingCharges: list };
                        });
                      }}
                      className="w-44"
                    >
                      <option value="soft_jaws">Soft jaws</option>
                      <option value="special_tool">Special tool</option>
                      <option value="other">Other</option>
                    </Select>
                    <label className="inline-flex items-center gap-2 text-sm min-h-10 px-2">
                      <input
                        type="checkbox"
                        checked={!!charge.billCustomer}
                        onChange={(e) => {
                          const billCustomer = e.target.checked;
                          setForm((f) => {
                            const list = [
                              ...(f.toolingCharges || []),
                            ] as QuoteToolingCharge[];
                            list[idx] = withDefaultBillPrice({
                              ...list[idx],
                              billCustomer,
                            });
                            return { ...f, toolingCharges: list };
                          });
                        }}
                      />
                      Bill customer (separate line)
                    </label>
                  </div>
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() =>
                      setForm((f) => ({
                        ...f,
                        toolingCharges: (f.toolingCharges || []).filter(
                          (_, i) => i !== idx,
                        ),
                      }))
                    }
                  >
                    <Trash2 className="h-4 w-4" /> Remove
                  </Button>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div className="space-y-1.5 sm:col-span-2">
                    <Label>Description</Label>
                    <Input
                      value={charge.description || ""}
                      placeholder={TOOLING_KIND_LABEL[charge.kind]}
                      onChange={(e) =>
                        setForm((f) => {
                          const list = [
                            ...(f.toolingCharges || []),
                          ] as QuoteToolingCharge[];
                          list[idx] = {
                            ...list[idx],
                            description: e.target.value,
                          };
                          return { ...f, toolingCharges: list };
                        })
                      }
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Shop cost (internal)</Label>
                    <SmartNumberInput
                      className="h-10 tabular-nums"
                      value={Number(charge.shopCost) || 0}
                      onValueChange={(n) =>
                        setForm((f) => {
                          const list = [
                            ...(f.toolingCharges || []),
                          ] as QuoteToolingCharge[];
                          const next = { ...list[idx], shopCost: n };
                          if (
                            next.billCustomer &&
                            !(Number(next.billUnitPrice) > 0)
                          ) {
                            next.billUnitPrice = n;
                          }
                          list[idx] = next;
                          return { ...f, toolingCharges: list };
                        })
                      }
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Notes (shop only)</Label>
                    <Input
                      value={charge.notes || ""}
                      placeholder="Vendor, re-use on next job…"
                      onChange={(e) =>
                        setForm((f) => {
                          const list = [
                            ...(f.toolingCharges || []),
                          ] as QuoteToolingCharge[];
                          list[idx] = {
                            ...list[idx],
                            notes: e.target.value,
                          };
                          return { ...f, toolingCharges: list };
                        })
                      }
                    />
                  </div>
                </div>
                {charge.billCustomer && (
                  <div className="grid sm:grid-cols-2 gap-3 rounded-[var(--radius-md)] bg-[color-mix(in_oklab,var(--color-primary)_8%,transparent)] border border-[color-mix(in_oklab,var(--color-primary)_25%,var(--color-border))] p-3">
                    <div className="space-y-1.5">
                      <Label>Bill qty</Label>
                      <SmartNumberInput
                        className="h-10 tabular-nums"
                        value={Number(charge.billQty) || 1}
                        onValueChange={(n) =>
                          setForm((f) => {
                            const list = [
                              ...(f.toolingCharges || []),
                            ] as QuoteToolingCharge[];
                            list[idx] = {
                              ...list[idx],
                              billQty: Math.max(1, n || 1),
                            };
                            return { ...f, toolingCharges: list };
                          })
                        }
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Customer price each</Label>
                      <SmartNumberInput
                        className="h-10 tabular-nums"
                        value={Number(charge.billUnitPrice) || 0}
                        onValueChange={(n) =>
                          setForm((f) => {
                            const list = [
                              ...(f.toolingCharges || []),
                            ] as QuoteToolingCharge[];
                            list[idx] = {
                              ...list[idx],
                              billUnitPrice: n,
                            };
                            return { ...f, toolingCharges: list };
                          })
                        }
                      />
                      <p className="text-[11px] text-[var(--color-subtle)]">
                        Edit anytime before emailing the customer — separate
                        from part price each.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
          <Button
            type="button"
            size="sm"
            variant="secondary"
            onClick={() =>
              setForm((f) => ({
                ...f,
                toolingCharges: [
                  ...(f.toolingCharges || []),
                  emptyToolingCharge({ kind: "special_tool" }),
                ],
              }))
            }
          >
            <Plus className="h-4 w-4" /> Add special tool
          </Button>
        </div>
      </details>

      <Card>
        <CardHeader>
          <CardTitle>Quantity breaks & price each</CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full text-sm min-w-[640px]">
            <thead>
              <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
                <th className="pb-2 font-medium">Level</th>
                {[1, 2, 3, 4, 5, 6].map((n) => (
                  <th key={n} className="pb-2 font-medium">
                    L{n}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-[var(--color-border)]">
                <td className="py-2 text-[var(--color-muted)]">Qty</td>
                {(form.quantities || []).map((v, i) => (
                  <td key={i} className="py-2 pr-2">
                    <SmartNumberInput
                      className="h-9 tabular-nums"
                      value={Number(v) || 0}
                      onValueChange={(n) =>
                        setArr("quantities", i, n === 0 ? "" : String(n))
                      }
                    />
                  </td>
                ))}
              </tr>
              <tr className="border-b border-[var(--color-border)]">
                <td className="py-2 text-[var(--color-muted)]">Drop $/pc</td>
                {costs.dropMarkups.map((v, i) => (
                  <td key={i} className="py-2 tabular text-[var(--color-muted)]">
                    {formatCurrency(v)}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-2 font-medium">Price each</td>
                {costs.prices.map((v, i) => (
                  <td
                    key={i}
                    className="py-2 tabular font-semibold text-[var(--color-accent)]"
                  >
                    {v > 0 ? formatCurrency(v) : "—"}
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </CardContent>
      </Card>

      <GuidedQuoteWizard
        open={guidedOpen}
        onClose={() => setGuidedOpen(false)}
        maxOps={maxOps}
        machineOptions={machineOptions}
        materialOptions={materialOptions}
        typeOptions={typeOptions}
        shapeOptions={stockShapeOptions}
        customerOptions={customerOptions}
        initial={{
          customer: form.customer,
          partNumber: form.partNumber || partQuery,
          revision: form.revision,
          kind: form.kind,
          material: form.material,
          materialType: form.materialType,
          stockShape: form.stockShape,
          machines: form.machines,
          setupTimes: form.setupTimes,
          runTimes: form.runTimes,
          quantities: form.quantities,
          prices: form.prices,
        }}
        onCreateCustomer={(v) => {
          const r = addCustomerQuick(v);
          if (!r.ok) {
            toast.error(r.error);
            return false;
          }
          toast.success(`Added customer ${v}`);
          return true;
        }}
        onCreateMaterial={(v) => {
          const r = addCustomListItem("materials", v);
          if (!r.ok) {
            toast.error(r.error);
            return false;
          }
          toast.success(`Added material ${v}`);
          return true;
        }}
        onCreateType={(v) => {
          const r = addCustomListItem("materialTypes", v, form.material || "Other");
          if (!r.ok) {
            toast.error(r.error);
            return false;
          }
          toast.success(`Added type ${v}`);
          return true;
        }}
        onCreateShape={(v) => {
          const r = addCustomListItem("stockShapes", v);
          if (!r.ok) {
            toast.error(r.error);
            return false;
          }
          toast.success(`Added shape ${v}`);
          return true;
        }}
        onApply={(draft) => {
          setForm((f) => ({
            ...f,
            customer: draft.customer || f.customer,
            partNumber: draft.partNumber || f.partNumber,
            revision: draft.revision || f.revision,
            kind: draft.kind,
            material: draft.material || f.material,
            materialType: draft.materialType || f.materialType,
            stockShape: draft.stockShape || f.stockShape,
            machines: draft.machines.length ? draft.machines : f.machines,
            setupTimes: draft.setupTimes,
            runTimes: draft.runTimes,
            quantities: draft.quantities,
            prices: draft.prices,
          }));
          if (draft.partNumber) setPartQuery(draft.partNumber);
          toast.success("Guided quote applied — review and Save");
        }}
      />
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function CostRow({
  label,
  value,
  strong,
}: {
  label: string;
  value: string;
  strong?: boolean;
}) {
  return (
    <div className="flex justify-between gap-3 border-b border-[var(--color-border)] pb-2 last:border-0">
      <span className="text-[var(--color-muted)]">{label}</span>
      <span className={strong ? "font-semibold tabular" : "tabular"}>{value}</span>
    </div>
  );
}


/** Safe arithmetic for in-box calc: 12*12, 12x12, (10+2)/2 */
function evaluateNumericExpression(raw: string): number | null {
  let s = String(raw ?? "")
    .replace(/[$,]/g, "")
    .replace(/\s*in\s*$/i, "")
    .replace(/,/g, "")
    .trim();
  if (!s || s === "-" || s === ".") return null;

  // × or x between numbers → multiply (12x12, 12 x 12)
  s = s.replace(/×/g, "*");
  s = s.replace(/(\d(?:\.\d+)?)\s*[xX]\s*(\d)/g, "$1*$2");
  s = s.replace(/\s+/g, "");

  // Only digits and + - * / ( ) .
  if (!/^[\d+\-*/().]+$/.test(s)) return null;
  // Disallow empty parens / trailing ops
  try {
    // eslint-disable-next-line no-new-func
    const n = Function(`"use strict"; return (${s});`)() as unknown;
    if (typeof n !== "number" || !Number.isFinite(n)) return null;
    // keep reasonable precision for shop math
    return Math.round(n * 10000) / 10000;
  } catch {
    return null;
  }
}

/** Number field: no spinner, empty when 0 until you type, format on blur.
 *  Supports in-box math: type 12*12 or 12x12 → becomes 144 on blur/Enter.
 */
function SmartNumberInput({
  value,
  onValueChange,
  format = "plain",
  emptyMeans = 0,
  className,
}: {
  value: number;
  onValueChange: (n: number) => void;
  format?: "plain" | "currency" | "inches";
  /** Value used when field left blank after blur */
  emptyMeans?: number;
  className?: string;
}) {
  const [focused, setFocused] = useState(false);
  const [draft, setDraft] = useState("");

  function formatBlurred(n: number): string {
    if (n === 0 || n == null || Number.isNaN(n)) return "";
    if (format === "currency") return formatCurrency(n);
    if (format === "inches") {
      const s = Number.isInteger(n)
        ? String(n)
        : String(Math.round(n * 1000) / 1000);
      return `${s} in`;
    }
    return String(n);
  }

  function parseDraft(raw: string): number {
    const cleaned = raw
      .replace(/[$,]/g, "")
      .replace(/\s*in\s*$/i, "")
      .replace(/,/g, "")
      .trim();
    if (cleaned === "" || cleaned === "-" || cleaned === ".") return emptyMeans;
    const expr = evaluateNumericExpression(cleaned);
    if (expr != null) return expr;
    const n = Number(cleaned);
    return Number.isFinite(n) ? n : emptyMeans;
  }

  function commit(raw: string) {
    const n = parseDraft(raw);
    onValueChange(n);
    // Show resolved number while still focused after Enter
    if (n === emptyMeans && (!raw || !raw.trim())) {
      setDraft("");
    } else {
      setDraft(String(n));
    }
    return n;
  }

  const shown = focused
    ? draft
    : formatBlurred(typeof value === "number" ? value : 0);

  return (
    <Input
      type="text"
      inputMode="text"
      autoComplete="off"
      spellCheck={false}
      title="Tip: 12*12 or 12x12 calculates on Enter or when you leave the field"
      className={className}
      value={shown}
      onFocus={() => {
        const n = typeof value === "number" ? value : 0;
        // Clear zero so typing does not become "01"
        setDraft(n === 0 ? "" : String(n));
        setFocused(true);
      }}
      onChange={(e) => {
        const raw = e.target.value;
        setDraft(raw);
        const cleaned = raw
          .replace(/[$,]/g, "")
          .replace(/\s*in\s*$/i, "")
          .replace(/"/g, "")
          .replace(/,/g, "")
          .trim();
        // Keep empty / incomplete drafts local (no 0 flash, no spinners)
        if (
          cleaned === "" ||
          cleaned === "-" ||
          cleaned === "." ||
          cleaned === "0" ||
          cleaned === "-0" ||
          /^\d*\.$/.test(cleaned) ||
          /^\.\d*$/.test(cleaned) ||
          /[+\-*/.]$/.test(cleaned)
        ) {
          return;
        }
        const expr = evaluateNumericExpression(cleaned);
        if (expr != null) {
          onValueChange(expr);
          return;
        }
        const n = Number(cleaned);
        if (Number.isFinite(n)) onValueChange(n);
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          commit(draft);
          (e.target as HTMLInputElement).blur();
        }
      }}
      onBlur={() => {
        commit(draft);
        setFocused(false);
      }}
    />
  );
}
