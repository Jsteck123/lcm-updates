/**
 * One-shot live-book cleanup: leftover TEST clocks, junk customers,
 * and machine-name aliases. Never deletes history — closes or merges.
 */
import type { Customer, JobRun } from "./types";
import type { ShopSharedState } from "./shop-types";
import { looksLikeTestPart } from "./beta-cleanup";
import { canonicalMachine } from "./lists";

export type HygieneReport = {
  completedTestJobs: number;
  completedQtyDoneJobs: number;
  mergedCustomers: string[];
  droppedCustomers: string[];
  queueMachinesFixed: number;
  notes: string[];
};

const DROP_CUSTOMERS = new Set(["2", "test"]);

const CUSTOMER_CANON: Record<string, string> = {
  "sat-lite": "Sat-Lite Technologies",
  "sat-lite technologies": "Sat-Lite Technologies",
  "kemp meek": "Kemp Meek",
  "kemp-meek": "Kemp Meek",
};

export function canonCustomerName(name: string): string {
  const raw = String(name || "").trim();
  if (!raw) return "";
  return CUSTOMER_CANON[raw.toLowerCase()] || raw;
}

function shouldDropCustomer(name: string): boolean {
  return DROP_CUSTOMERS.has(String(name || "").trim().toLowerCase());
}

function completeJob(j: JobRun, nowIso: string, reason: string): JobRun {
  return {
    ...j,
    status: "Completed",
    endTime: j.endTime || nowIso,
    saveTime: j.saveTime || nowIso,
    pauseReason: j.pauseReason || reason,
    countInAverage: looksLikeTestPart(j.partNumber) ? false : j.countInAverage,
  };
}

export function applyBookHygiene(
  state: ShopSharedState,
  now = new Date(),
): { state: ShopSharedState; report: HygieneReport } {
  const nowIso = now.toISOString();
  const report: HygieneReport = {
    completedTestJobs: 0,
    completedQtyDoneJobs: 0,
    mergedCustomers: [],
    droppedCustomers: [],
    queueMachinesFixed: 0,
    notes: [],
  };

  const jobs = (state.jobs || []).map((j) => {
    if (j.status !== "In Progress") return j;
    if (looksLikeTestPart(j.partNumber)) {
      report.completedTestJobs += 1;
      return completeJob(j, nowIso, "Beta leftover — TEST job closed");
    }
    const qty = Number(j.quantity) || 0;
    const done = Number(j.quantityCompleted) || 0;
    if (qty > 0 && done >= qty) {
      report.completedQtyDoneJobs += 1;
      return completeJob(j, nowIso, j.pauseReason || "Qty complete — closed leftover clock");
    }
    return j;
  });

  const keptCustomers: Customer[] = [];
  const seen = new Map<string, Customer>();
  for (const c of state.customers || []) {
    if (shouldDropCustomer(c.name)) {
      report.droppedCustomers.push(c.name);
      continue;
    }
    const name = canonCustomerName(c.name);
    const key = name.toLowerCase();
    const prev = seen.get(key);
    if (prev) {
      report.mergedCustomers.push(`${c.name} → ${name}`);
      const emails = [
        ...new Set(
          [prev.email, c.email, ...(prev.emails || []), ...(c.emails || [])]
            .map((e) => String(e || "").trim())
            .filter(Boolean),
        ),
      ];
      const primary = emails[0] || "";
      seen.set(key, {
        ...prev,
        name,
        email: primary,
        emails: emails.filter((e) => e.toLowerCase() !== primary.toLowerCase()),
        lastEmailedAt: prev.lastEmailedAt || c.lastEmailedAt || null,
      });
      continue;
    }
    const next = { ...c, name };
    seen.set(key, next);
    keptCustomers.push(next);
  }
  const customers = Array.from(seen.values());

  const rewriteName = (raw: string) => {
    if (shouldDropCustomer(raw)) return "";
    return canonCustomerName(raw);
  };

  const quotes = (state.quotes || []).map((q) => {
    const next = rewriteName(q.customer);
    return next === q.customer ? q : { ...q, customer: next };
  });

  const shopOrders = (state.shopOrders || []).map((o) => {
    const next = rewriteName(o.customer);
    return next === o.customer ? o : { ...o, customer: next };
  });

  const jobsNamed = jobs.map((j) => {
    const next = rewriteName(j.customer);
    return next === j.customer ? j : { ...j, customer: next };
  });

  const workQueue = (state.workQueue || []).map((row) => {
    const machine = canonicalMachine(row.machine, state.settings?.customLists);
    const customer = rewriteName(row.customer);
    if (machine === row.machine && customer === row.customer) return row;
    if (machine !== row.machine) report.queueMachinesFixed += 1;
    return { ...row, machine, customer, updatedAt: nowIso };
  });

  if (report.completedTestJobs) {
    report.notes.push(`Closed ${report.completedTestJobs} TEST job(s)`);
  }
  if (report.completedQtyDoneJobs) {
    report.notes.push(
      `Closed ${report.completedQtyDoneJobs} job(s) that already met qty`,
    );
  }
  if (report.droppedCustomers.length) {
    report.notes.push(`Dropped junk customers: ${report.droppedCustomers.join(", ")}`);
  }
  if (report.mergedCustomers.length) {
    report.notes.push(`Merged ${report.mergedCustomers.length} duplicate customer name(s)`);
  }
  if (report.queueMachinesFixed) {
    report.notes.push(`Normalized ${report.queueMachinesFixed} work-queue machine name(s)`);
  }

  return {
    report,
    state: {
      ...state,
      jobs: jobsNamed,
      customers,
      quotes,
      shopOrders,
      workQueue,
    },
  };
}
