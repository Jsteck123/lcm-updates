import { createServerFn } from "@tanstack/react-start";
import type { ShopSharedState } from "./shop-types";
import type { ChatAttachment, ChatMessage, Operator } from "./types";
import type { ShopDirectory } from "./shop-push-policy";

export type ShopPullResult = {
  rev: number;
  updatedAt: string;
  dataPath: string;
  /** True when client already has this rev — no state payload. */
  unchanged?: boolean;
  /** Full shop slice. Omitted when unchanged or when only the directory was sent. */
  state?: ShopSharedState;
  /**
   * PIN not yet entered — names for the switcher only.
   * Quotes, costs, and orders are not included.
   */
  limited?: boolean;
  directory?: ShopDirectory;
};

export type ShopPushResult =
  | { ok: true; rev: number; updatedAt: string }
  | {
      ok: false;
      conflict: true;
      rev: number;
      updatedAt: string;
      state: ShopSharedState;
    }
  | { ok: false; error: string };

export type ClaimSessionResult =
  | {
      ok: true;
      token: string;
      operator: Pick<
        Operator,
        "id" | "name" | "email" | "role" | "tabs" | "active"
      >;
    }
  | { ok: false; error: string };

function tokenFromInput(data: { token?: string } | undefined): string | null {
  return data?.token?.trim() || null;
}

/** Exchange operator email + PIN for a signed shop session token. */
export const claimShopSession = createServerFn({ method: "POST" })
  .validator((data: { email: string; pin: string }) => data)
  .handler(async ({ data }): Promise<ClaimSessionResult> => {
    const { ensureShopReady } = await import("./shop-store.server");
    const { issueShopToken } = await import("./shop-session.server");
    const { verifySecret } = await import("./crypto");
    const { getOperatorByEmail, requiresPinToSwitch } = await import(
      "./permissions"
    );

    const snap = await ensureShopReady();
    const email = (data.email || "").trim().toLowerCase();
    const op = getOperatorByEmail(snap.state.operators, email);
    if (!op || !op.active) {
      return { ok: false, error: "Unknown or inactive operator" };
    }
    if (requiresPinToSwitch(op)) {
      const ok = await verifySecret(data.pin || "", op.pin);
      if (!ok) return { ok: false, error: "Incorrect PIN" };
    }
    const token = issueShopToken({
      email: op.email,
      role: op.role,
      name: op.name,
    });
    return {
      ok: true,
      token,
      operator: {
        id: op.id,
        name: op.name,
        email: op.email,
        role: op.role,
        tabs: op.tabs,
        active: op.active,
      },
    };
  });

/** Verify edit password without exposing the hash to the client. */
export const verifyEditPassword = createServerFn({ method: "POST" })
  .validator((data: { password: string }) => data)
  .handler(async ({ data }): Promise<{ ok: boolean }> => {
    const { ensureShopReady } = await import("./shop-store.server");
    const { verifySecret } = await import("./crypto");
    const snap = await ensureShopReady();
    const ok = await verifySecret(
      data.password || "",
      snap.state.settings?.editPassword,
    );
    return { ok };
  });

/**
 * Pull shared shop DB (secrets stripped).
 * Without a PIN session we only send the operator switcher (no quotes / $).
 * Writes always require a session token.
 */
export const pullShopState = createServerFn({ method: "POST" })
  .validator((data: { token?: string; sinceRev?: number } = {}) => data ?? {})
  .handler(async ({ data }): Promise<ShopPullResult> => {
    const {
      ensureShopReady,
      getShopDataPath,
      stripSecretsForClient,
    } = await import("./shop-store.server");
    const { verifyShopToken, isBootstrapOpen } = await import(
      "./shop-session.server"
    );
    const { toShopDirectory } = await import("./shop-push-policy");

    const snap = await ensureShopReady();
    const session = verifyShopToken(tokenFromInput(data));
    const sinceRev =
      typeof data?.sinceRev === "number" && Number.isFinite(data.sinceRev)
        ? data.sinceRev
        : undefined;

    if (!session && !isBootstrapOpen(snap.state.operators?.length || 0)) {
      return {
        rev: snap.rev,
        updatedAt: snap.updatedAt,
        dataPath: getShopDataPath(),
        limited: true,
        directory: toShopDirectory(snap.state),
      };
    }

    // Same revision the client already has — skip the 1–2 MB payload.
    if (sinceRev !== undefined && sinceRev === snap.rev) {
      return {
        rev: snap.rev,
        updatedAt: snap.updatedAt,
        dataPath: getShopDataPath(),
        unchanged: true,
      };
    }
    return {
      rev: snap.rev,
      updatedAt: snap.updatedAt,
      state: stripSecretsForClient(snap.state),
      dataPath: getShopDataPath(),
      unchanged: false,
    };
  });

/** Push local edits. Requires valid shop session token. */
export const pushShopState = createServerFn({ method: "POST" })
  .validator(
    (data: { baseRev: number; state: ShopSharedState; token?: string }) => data,
  )
  .handler(async ({ data }): Promise<ShopPushResult> => {
    try {
      const {
        ensureShopReady,
        putShopSnapshotAsync,
        stripSecretsForClient,
      } = await import("./shop-store.server");
      const { verifyShopToken } = await import("./shop-session.server");
      const { hashSecret, isHashedSecret } = await import("./crypto");

      const current = await ensureShopReady();
      const session = verifyShopToken(tokenFromInput(data));
      if (!session) {
        return {
          ok: false,
          error: "Shop session required — switch user / enter PIN",
        };
      }

      const incoming = data.state;
      const operators = await Promise.all(
        (incoming.operators || []).map(async (op) => {
          const prev = current.state.operators.find((o) => o.id === op.id);
          let pin = op.pin || "";
          if (!pin || pin === "••••") {
            pin = prev?.pin || "";
          } else if (!isHashedSecret(pin)) {
            pin = await hashSecret(pin);
          }
          return { ...op, pin };
        }),
      );
      let editPassword = incoming.settings?.editPassword || "";
      if (!editPassword || editPassword === "••••") {
        editPassword = current.state.settings?.editPassword || "";
      } else if (!isHashedSecret(editPassword)) {
        editPassword = await hashSecret(editPassword);
      }

      const secured: ShopSharedState = {
        ...incoming,
        operators,
        settings: { ...incoming.settings, editPassword },
      };

      const result = await putShopSnapshotAsync(data.baseRev, secured, {
        role: session.role === "admin" ? "admin" : "operator",
      });
      if (!result.ok) {
        return {
          ok: false,
          conflict: true,
          rev: result.rev,
          updatedAt: result.updatedAt,
          state: stripSecretsForClient(result.state),
        };
      }
      return { ok: true, rev: result.rev, updatedAt: result.updatedAt };
    } catch (e) {
      return {
        ok: false,
        error: e instanceof Error ? e.message : "Save failed",
      };
    }
  });


/**
 * Lightweight chat send — appends one message on the host without a full DB push.
 * Requires shop session (PIN unlock on this device).
 */
export const postChatMessage = createServerFn({ method: "POST" })
  .validator(
    (data: {
      token?: string;
      message: {
        id: string;
        channel: "shop" | "dm";
        fromEmail: string;
        fromName: string;
        toEmail: string;
        body: string;
        createdAt: string;
        context: string;
        readBy: string[];
        attachments?: ChatAttachment[];
      };
    }) => data,
  )
  .handler(async ({ data }) => {
    try {
      const { ensureShopReady, putShopSnapshotAsync } = await import(
        "./shop-store.server"
      );
      const { verifyShopToken } = await import("./shop-session.server");
      const { mergeChatMessages } = await import("./chat");

      const session = verifyShopToken(tokenFromInput(data));
      if (!session) {
        return {
          ok: false as const,
          needsPin: true as const,
          error: "Enter your PIN on this PC so chat can send",
        };
      }

      const raw = data.message;
      const attachments = (Array.isArray(raw?.attachments) ? raw.attachments : [])
        .filter((a) => a && a.id && a.name)
        .slice(0, 5)
        .map((a) => ({
          id: String(a.id).slice(0, 64),
          name: String(a.name).slice(0, 120),
          mime: String(a.mime || "application/octet-stream").slice(0, 80),
          size: Math.max(0, Number(a.size) || 0),
        }));
      const bodyRaw = String(raw?.body || "").trim();
      if (!raw?.id || (!bodyRaw && !attachments.length)) {
        return { ok: false as const, error: "Empty message" };
      }
      const body = (bodyRaw || (attachments.length ? "(attachment)" : "")).slice(
        0,
        2000,
      );
      const fromEmail = (raw.fromEmail || session.email).trim().toLowerCase();
      // Session user must match sender (prevent spoofing)
      if (fromEmail !== session.email.toLowerCase()) {
        return { ok: false as const, error: "Signed-in user mismatch — unlock again" };
      }

      const msg: ChatMessage = {
        id: String(raw.id).slice(0, 80),
        channel: raw.channel === "dm" ? "dm" : "shop",
        fromEmail,
        fromName: String(raw.fromName || session.name || fromEmail).slice(0, 80),
        toEmail: raw.channel === "dm" ? String(raw.toEmail || "").trim() : "",
        body,
        createdAt: raw.createdAt || new Date().toISOString(),
        context: String(raw.context || "").trim().slice(0, 120),
        readBy: Array.isArray(raw.readBy) ? raw.readBy.slice(0, 50) : [fromEmail],
        attachments,
      };

      // Retry a few times on concurrent edits from host/other PCs
      for (let attempt = 0; attempt < 6; attempt++) {
        const current = await ensureShopReady();
        const nextState = {
          ...current.state,
          chatMessages: mergeChatMessages(current.state.chatMessages || [], [msg]),
        };
        const result = await putShopSnapshotAsync(current.rev, nextState);
        if (result.ok) {
          return {
            ok: true as const,
            rev: result.rev,
            updatedAt: result.updatedAt,
            id: msg.id,
          };
        }
        // conflict — loop and merge again
      }
      return {
        ok: false as const,
        error: "Shop is busy saving — try send again in a second",
      };
    } catch (e) {
      return {
        ok: false as const,
        error: e instanceof Error ? e.message : "Chat send failed",
      };
    }
  });
