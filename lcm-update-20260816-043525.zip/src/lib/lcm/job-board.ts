/**
 * Digital job board — component pieces first, then assembly, or simple lines.
 * Multi-machine quotes emit one card per open OP.
 * Sorted soonest due → furthest (wall board: top-left next).
 */
import type { Quote, ShopOrder, ShopOrderLine, ShopOpAssignment } from "./types";
import {
  allComponentsComplete,
  lineCadFiles,
  lineDrawings,
  lineHasCad,
  normalizeComponents,
  promoteRelatedFilesToComponents,
} from "./line-files";
import { lineShipDate } from "./shipping-calendar";
import { opLabel } from "./ops";
import {
  getOpAssignment,
  isMultiMachinePart,
  quoteForPn,
  quoteOpMachine,
  remainingTimedOps,
  timedOpIndexes,
  waitOnOpLabel,
} from "./op-slots";

export type BoardCard = {
  orderId: string;
  lineId: string;
  /** Empty = the main PO line / assembly step */
  componentId: string;
  poNumber: string;
  customer: string;
  partNumber: string;
  revision: string;
  description: string;
  qty: number;
  dueDate: string;
  material: string;
  materialType: string;
  sizeNote: string;
  drawingId: string;
  cadFileId: string;
  drawings: { id: string; name: string; relatedPartNumber?: string }[];
  cadFiles: { id: string; name: string; relatedPartNumber?: string }[];
  revPdfOk: boolean;
  revCadOk: boolean;
  stockNoted: boolean;
  checkedOutBy: string;
  checkedOutAt: string;
  checkedOutMachine: string;
  readyForPack: boolean;
  linePacked: boolean;
  released: boolean;
  /** component | assembly | part */
  kind: "component" | "assembly" | "part";
  /** Parent assembly P/N when kind is component */
  parentPartNumber: string;
  /** For assembly cards: which components still open */
  waitingOn: string[];
  /** 0-based OP when this card is one operation of a multi-machine job */
  opIndex: number | null;
  opLabel: string;
  quotedMachine: string;
  /** Previous timed OP still open, e.g. "OP1" */
  waitOnOp: string;
  /** Next open OP after this card (multi-machine only) */
  nextOpIndex: number | null;
  nextOpLabel: string;
  nextOpAssignedTo: string;
};

export function lineReleasedToShop(line: ShopOrderLine): boolean {
  if (!line.revPdfOk || !line.stockNoted) return false;
  if (lineHasCad(line) && !line.revCadOk) return false;
  const comps = normalizeComponents(line);
  const anyCad = comps.some((c) => (c.cadFiles || []).length > 0);
  if (anyCad && !line.revCadOk) return false;
  return true;
}

function mapFiles(
  list: { id: string; name: string; relatedPartNumber?: string }[],
) {
  return (list || []).map((f) => ({
    id: f.id,
    name: f.name,
    relatedPartNumber: f.relatedPartNumber,
  }));
}

type Host = {
  checkedOutBy?: string;
  checkedOutAt?: string;
  checkedOutMachine?: string;
  opAssignments?: ShopOpAssignment[];
};

function emitCards(
  cards: BoardCard[],
  base: Omit<
    BoardCard,
    | "checkedOutBy"
    | "checkedOutAt"
    | "checkedOutMachine"
    | "opIndex"
    | "opLabel"
    | "quotedMachine"
    | "waitOnOp"
    | "nextOpIndex"
    | "nextOpLabel"
    | "nextOpAssignedTo"
    | "released"
  > & { released: boolean },
  host: Host,
  quote: Quote | undefined,
) {
  if (isMultiMachinePart(quote)) {
    const open = remainingTimedOps(quote, host.opAssignments);
    const timed = timedOpIndexes(quote);
    for (const opIndex of open) {
      const slot = getOpAssignment(host.opAssignments, opIndex);
      const wait = waitOnOpLabel(quote, host.opAssignments, opIndex);
      const next = timed.find(
        (i) =>
          i > opIndex && !getOpAssignment(host.opAssignments, i)?.complete,
      );
      const nextSlot =
        next != null ? getOpAssignment(host.opAssignments, next) : undefined;
      cards.push({
        ...base,
        checkedOutBy: slot?.checkedOutBy || "",
        checkedOutAt: slot?.checkedOutAt || "",
        checkedOutMachine: slot?.checkedOutMachine || "",
        opIndex,
        opLabel: opLabel(opIndex),
        quotedMachine:
          slot?.officeAssignedMachine ||
          slot?.checkedOutMachine ||
          quoteOpMachine(quote, opIndex),
        waitOnOp: wait,
        nextOpIndex: next ?? null,
        nextOpLabel: next != null ? opLabel(next) : "",
        nextOpAssignedTo:
          nextSlot?.officeAssignedTo || nextSlot?.checkedOutBy || "",
        released: base.released,
      });
    }
    return;
  }
  cards.push({
    ...base,
    checkedOutBy: host.checkedOutBy || "",
    checkedOutAt: host.checkedOutAt || "",
    checkedOutMachine: host.checkedOutMachine || "",
    opIndex: null,
    opLabel: "",
    quotedMachine: "",
    waitOnOp: "",
    nextOpIndex: null,
    nextOpLabel: "",
    nextOpAssignedTo: "",
    released: base.released,
  });
}

export function buildJobBoard(
  orders: ShopOrder[],
  quotes: Quote[] = [],
): BoardCard[] {
  const cards: BoardCard[] = [];
  for (const order of orders) {
    if (order.status === "cancelled") continue;
    if (order.deliveredAt) continue;
    for (const raw of order.lines || []) {
      if (raw.lineStatus === "cancelled") continue;
      if (raw.readyForPack || raw.linePacked) continue;
      if (!(raw.partNumber || raw.description)) continue;

      const promoted = promoteRelatedFilesToComponents(raw);
      const line: ShopOrderLine = {
        ...raw,
        ...promoted,
        components: normalizeComponents({ ...raw, ...promoted }),
      } as ShopOrderLine;

      const due =
        lineShipDate(order, line) || order.dateRequired || "9999-12-31";
      const released = lineReleasedToShop(line);
      const comps = normalizeComponents(line);
      const shared = {
        orderId: order.id,
        lineId: line.id,
        poNumber: order.poNumber || "(no PO)",
        customer: order.customer || "",
        dueDate: due,
        material: line.material || "",
        materialType: line.materialType || "",
        sizeNote: line.sizeNote || "",
        revPdfOk: Boolean(line.revPdfOk),
        revCadOk: Boolean(line.revCadOk),
        stockNoted: Boolean(line.stockNoted),
        readyForPack: Boolean(line.readyForPack),
        linePacked: Boolean(line.linePacked),
      };

      if (comps.length > 0) {
        for (const c of comps) {
          if (c.complete) continue;
          if (c.boardHidden) continue;
          const draws = mapFiles(c.drawings || []);
          const cads = mapFiles(c.cadFiles || []);
          emitCards(
            cards,
            {
              ...shared,
              componentId: c.id,
              partNumber: c.partNumber,
              revision: c.revision || line.revision || "",
              description:
                c.description ||
                `Make component for assembly ${line.partNumber}`,
              qty: Number(c.qty) || Number(line.qty) || 0,
              drawingId: draws[0]?.id || "",
              cadFileId: cads[0]?.id || "",
              drawings: draws,
              cadFiles: cads,
              released,
              kind: "component",
              parentPartNumber: line.partNumber || "",
              waitingOn: [],
            },
            c,
            quoteForPn(quotes, c.partNumber),
          );
        }

        const waiting = comps.filter((c) => !c.complete).map((c) => c.partNumber);
        const draws = mapFiles(lineDrawings(line));
        const cads = mapFiles(lineCadFiles(line));
        if (!line.boardHidden) {
          emitCards(
            cards,
            {
              ...shared,
              componentId: "",
              partNumber: line.partNumber || "",
              revision: line.revision || "",
              description:
                (line.description || "Assembly") +
                (waiting.length
                  ? ` · wait for ${waiting.join(", ")}`
                  : " · bolt / assemble"),
              qty: Number(line.qty) || 0,
              drawingId: draws[0]?.id || "",
              cadFileId: cads[0]?.id || "",
              drawings: draws,
              cadFiles: cads,
              released: released && waiting.length === 0,
              kind: "assembly",
              parentPartNumber: "",
              waitingOn: waiting,
            },
            line,
            quoteForPn(quotes, line.partNumber),
          );
        }
      } else if (!line.boardHidden) {
        const draws = mapFiles(lineDrawings(line));
        const cads = mapFiles(lineCadFiles(line));
        emitCards(
          cards,
          {
            ...shared,
            componentId: "",
            partNumber: line.partNumber || "",
            revision: line.revision || "",
            description: line.description || "",
            qty: Number(line.qty) || 0,
            drawingId: draws[0]?.id || line.drawingId || "",
            cadFileId: cads[0]?.id || line.cadFileId || "",
            drawings: draws,
            cadFiles: cads,
            released,
            kind: "part",
            parentPartNumber: "",
            waitingOn: [],
          },
          line,
          quoteForPn(quotes, line.partNumber),
        );
      }
    }
  }
  return cards.sort((a, b) => {
    const d = a.dueDate.localeCompare(b.dueDate);
    if (d) return d;
    if (a.orderId === b.orderId && a.lineId === b.lineId) {
      if (a.kind === "component" && b.kind === "assembly") return -1;
      if (a.kind === "assembly" && b.kind === "component") return 1;
      const ao = a.opIndex == null ? -1 : a.opIndex;
      const bo = b.opIndex == null ? -1 : b.opIndex;
      if (ao !== bo) return ao - bo;
    }
    return (
      a.poNumber.localeCompare(b.poNumber) ||
      a.partNumber.localeCompare(b.partNumber)
    );
  });
}

export function fridayOfWeek(from = new Date()): string {
  const d = new Date(from);
  d.setHours(12, 0, 0, 0);
  const day = d.getDay();
  const add = day <= 5 ? 5 - day : 6;
  d.setDate(d.getDate() + add);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}

/** Sunday–Saturday week containing `from` (local dates as YYYY-MM-DD). */
export function weekRangeContaining(from = new Date()): {
  start: string;
  end: string;
} {
  const d = new Date(from);
  d.setHours(12, 0, 0, 0);
  const day = d.getDay();
  const start = new Date(d);
  start.setDate(d.getDate() - day);
  const end = new Date(start);
  end.setDate(start.getDate() + 6);
  const ymd = (x: Date) => {
    const y = x.getFullYear();
    const m = String(x.getMonth() + 1).padStart(2, "0");
    const dd = String(x.getDate()).padStart(2, "0");
    return `${y}-${m}-${dd}`;
  };
  return { start: ymd(start), end: ymd(end) };
}
