/**
 * Full USB backup: app + shop DB + prints/photos + branding.
 * Unzip on a new PC and run INSTALL-FROM-USB.cmd.
 */
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const ROOT = process.cwd();
const USB_DIR = path.join(ROOT, "data", "usb-backups");
const MAX_KEEP = 3;

export type UsbBackupInfo = {
  id: string;
  fileName: string;
  createdAt: string;
  sizeBytes: number;
};

function ensureDir(p: string) {
  fs.mkdirSync(p, { recursive: true });
}

const SKIP_DIRS = new Set([
  "node_modules",
  ".git",
  ".grok",
  "artifacts",
  "attachments",
  "screenshots",
  ".output",
  "dist",
  ".nitro",
  ".vinxi",
  ".cache",
  ".vercel",
]);

/** Extra folder-name prefixes that are install junk, not shop data. */
function shouldSkipDir(name: string) {
  if (SKIP_DIRS.has(name)) return true;
  if (name.startsWith("_office-pack")) return true;
  if (name.startsWith(".node_modules")) return true;
  if (name.startsWith("node_modules")) return true;
  return false;
}

function shouldSkipFile(rel: string, name: string) {
  const norm = rel.replace(/\\/g, "/");
  const lower = name.toLowerCase();

  // Never nest zips inside a USB backup (old USBs + update packages snowball)
  if (lower.endsWith(".zip") || lower.endsWith(".7z") || lower.endsWith(".rar")) {
    return true;
  }

  // data/updates: keep version history only — not the incoming update binary
  if (norm === "data/updates" || norm.startsWith("data/updates/")) {
    return name !== "installed.json" && name !== "changelog.json";
  }

  // Never put the HMAC session secret on a USB stick
  if (name === ".shop-secret" || name.endsWith(".shop-secret")) {
    return true;
  }

  return false;
}

function copyTree(src: string, dest: string, rel = "") {
  const st = fs.statSync(src);
  if (st.isDirectory()) {
    const base = path.basename(src);
    if (shouldSkipDir(base)) return;
    const normRel = rel.replace(/\\/g, "/");
    if (normRel === "data/usb-backups" || normRel.startsWith("data/usb-backups/"))
      return;
    if (normRel === "data/logs" || normRel.startsWith("data/logs/")) return;
    // data/updates (installed.json + changelog) stays — version history after a USB restore
    ensureDir(dest);
    for (const name of fs.readdirSync(src)) {
      if (shouldSkipDir(name)) continue;
      copyTree(path.join(src, name), path.join(dest, name), path.join(rel, name));
    }
    return;
  }
  if (shouldSkipFile(rel, path.basename(src))) return;
  ensureDir(path.dirname(dest));
  fs.copyFileSync(src, dest);
}

function zipStage(stage: string, outZip: string): { ok: boolean; error?: string } {
  const py = `
import zipfile, os, sys
stage, out = sys.argv[1], sys.argv[2]
skip_dirs = {"node_modules", ".git", ".grok", "attachments", "artifacts", "screenshots"}
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(stage):
        dirs[:] = [d for d in dirs if d not in skip_dirs and not d.startswith(".node_modules")]
        for f in files:
            if f.lower().endswith((".zip", ".7z", ".rar")):
                continue
            p = os.path.join(root, f)
            z.write(p, os.path.relpath(p, stage))
`;
  const pyCmds: string[][] = [
    ["python3", "-c", py, stage, outZip],
    ["py", "-3", "-c", py, stage, outZip],
    ["python", "-c", py, stage, outZip],
  ];
  for (const cmd of pyCmds) {
    const r = spawnSync(cmd[0], cmd.slice(1), { encoding: "utf8" });
    if (r.status === 0 && fs.existsSync(outZip)) return { ok: true };
  }
  if (process.platform === "win32") {
    const r = spawnSync(
      "powershell",
      [
        "-NoProfile",
        "-Command",
        `Compress-Archive -Path '${stage}\\*' -DestinationPath '${outZip}' -Force`,
      ],
      { encoding: "utf8" },
    );
    if (r.status === 0 && fs.existsSync(outZip)) return { ok: true };
    return { ok: false, error: r.stderr || r.stdout || "Zip failed" };
  }
  return { ok: false, error: "Need Python to build the USB zip on this host" };
}

function pruneOld() {
  if (!fs.existsSync(USB_DIR)) return;
  const files = fs
    .readdirSync(USB_DIR)
    .filter((f) => f.endsWith(".zip"))
    .map((f) => ({
      f,
      t: fs.statSync(path.join(USB_DIR, f)).mtimeMs,
    }))
    .sort((a, b) => b.t - a.t);
  for (const x of files.slice(MAX_KEEP)) {
    try {
      fs.unlinkSync(path.join(USB_DIR, x.f));
    } catch {
      /* ignore */
    }
  }
}

export function listUsbBackups(): UsbBackupInfo[] {
  ensureDir(USB_DIR);
  return fs
    .readdirSync(USB_DIR)
    .filter((f) => f.endsWith(".zip"))
    .map((fileName) => {
      const st = fs.statSync(path.join(USB_DIR, fileName));
      return {
        id: fileName.replace(/\.zip$/i, ""),
        fileName,
        createdAt: st.mtime.toISOString(),
        sizeBytes: st.size,
      };
    })
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function readUsbBackup(fileName: string): { buffer: Buffer; fileName: string } | null {
  const safe = path.basename(fileName);
  if (!safe.toLowerCase().endsWith(".zip") || safe.includes("..")) return null;
  const full = path.join(USB_DIR, safe);
  if (!fs.existsSync(full)) return null;
  return { buffer: fs.readFileSync(full), fileName: safe };
}

export function createFullUsbBackup():
  | { ok: true; backup: UsbBackupInfo }
  | { ok: false; error: string } {
  ensureDir(USB_DIR);
  const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const fileName = `LCM-FULL-USB-${stamp}.zip`;
  const outZip = path.join(USB_DIR, fileName);
  const stage = path.join(os.tmpdir(), `lcm-usb-${process.pid}-${Date.now()}`);
  try {
    fs.rmSync(stage, { recursive: true, force: true });
    ensureDir(stage);
    for (const name of fs.readdirSync(ROOT)) {
      if (shouldSkipDir(name)) continue;
      copyTree(path.join(ROOT, name), path.join(stage, name), name);
    }
    const readme = [
      "LAKE COUNTRY MACHINE — FULL USB BACKUP",
      `Created: ${new Date().toISOString()}`,
      "",
      "This zip is the whole shop: the LCM app, the database,",
      "drawings/prints/photos, and the company logo.",
      "",
      "NEW COMPUTER",
      "  1. Install Node.js LTS from https://nodejs.org (add to PATH).",
      "  2. Unzip this file (or copy the unzipped folder).",
      "  3. Double-click INSTALL-FROM-USB.cmd",
      "     It copies to C:\\LCM, installs packages, and starts LCM.",
      "  4. Open http://127.0.0.1:8080",
      "",
      "THIS COMPUTER AFTER A BAD UPDATE",
      "  1. Close LCM (stop the Node window).",
      "  2. Unzip over C:\\LCM  — or run INSTALL-FROM-USB.cmd from the unzip.",
      "  3. Open http://127.0.0.1:8080",
      "",
      "You still need Node.js on a brand-new PC. Everything else is in this zip.",
      "",
      "The shop session key is NOT on this stick. First start after a",
      "recover mints a new one — everyone signs in with their PIN again.",
      "",
    ].join("\r\n");
    fs.writeFileSync(path.join(stage, "README-USB.txt"), readme, "utf8");
    const installer = path.join(ROOT, "scripts", "host", "INSTALL-FROM-USB.cmd");
    if (fs.existsSync(installer)) {
      fs.copyFileSync(installer, path.join(stage, "INSTALL-FROM-USB.cmd"));
    }
    const zipped = zipStage(stage, outZip);
    if (!zipped.ok) return { ok: false, error: zipped.error || "Zip failed" };
    pruneOld();
    const st = fs.statSync(outZip);
    return {
      ok: true,
      backup: {
        id: fileName.replace(/\.zip$/i, ""),
        fileName,
        createdAt: new Date().toISOString(),
        sizeBytes: st.size,
      },
    };
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : "USB backup failed",
    };
  } finally {
    try {
      fs.rmSync(stage, { recursive: true, force: true });
    } catch {
      /* ignore */
    }
  }
}
