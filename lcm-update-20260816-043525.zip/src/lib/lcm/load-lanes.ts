/**
 * Load lanes — quoted hours stacked on work days in due-date order.
 * Not a promised start clock. Squeeze = first leftover hole that fits.
 */
import type {
  CustomLists,
  MachineSession,
  Quote,
  ShopOrder,
  WorkQueueItem,
} from "./types";
import { normalizeComponents } from "./line-files";
import { quotedHoursForPart } from "./assign-workload";
import { opLabel } from "./ops";
import {
  getOpAssignment,
  isMultiMachinePart,
  previousTimedOpComplete,
  quoteForPn,
  quotedHoursForOp,
  remainingTimedOps,
} from "./op-slots";
import { lineShipDate } from "./shipping-calendar";
import { dueUrgency } from "./status-colors";
import { shiftHoursRequired } from "./day-bonus";
import { allMachines } from "./lists";

export type LoadJob = {
  key: string;
  partNumber: string;
  revision: string;
  qty: number;
  hours: number;
  dueDate: string;
  operator: string;
  machine: string;
  poNumber: string;
  customer: string;
  live: boolean;
  pulled: boolean;
  opIndex: number | null;
  opLabel: string;
};

export type LoadDay = {
  ymd: string;
  label: string;
  weekday: string;
  capacity: number;
};

export type LoadSegment = {
  ymd: string;
  startFrac: number;
  widthFrac: number;
};

export type LoadBlock = {
  job: LoadJob;
  tone: "active" | "open" | "soon" | "overdue";
  missesDue: boolean;
  startHour: number;
  hours: number;
  segments: LoadSegment[];
};

export type LoadLane = {
  name: string;
  kind: "person" | "machine";
  bookedHours: number;
  jobs: LoadJob[];
  blocks: LoadBlock[];
  chips: LoadJob[];
  openByDay: { ymd: string; open: number }[];
  tailOpen: number;
  tailDay: string;
};

export type SqueezeHit = {
  lane: string;
  kind: "person" | "machine";
  day: string;
  dayLabel: string;
  open: number;
  hours: number;
};

function norm(s: string) {
  return String(s || "").trim();
}

function normPn(s: string) {
  return norm(s).toUpperCase();
}

export function ymdLocal(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function parseYmd(ymd: string): Date {
  const [y, m, d] = ymd.split("-").map(Number);
  return new Date(y || 1970, (m || 1) - 1, d || 1);
}

function addDays(d: Date, n: number): Date {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}

function isWeekend(d: Date): boolean {
  const w = d.getDay();
  return w === 0 || w === 6;
}

/** Next n weekdays, starting today if it is a weekday, else next Monday. */
export function nextWorkdays(from: Date, n = 5): string[] {
  const out: string[] = [];
  let d = new Date(from.getFullYear(), from.getMonth(), from.getDate());
  if (isWeekend(d)) {
    const skip = d.getDay() === 6 ? 2 : 1;
    d = addDays(d, skip);
  }
  while (out.length < n) {
    if (!isWeekend(d)) out.push(ymdLocal(d));
    d = addDays(d, 1);
  }
  return out;
}

export function shiftDayHours(opts?: {
  workDayStart?: string;
  workDayEnd?: string;
  lunchHours?: number;
}): number {
  const start = opts?.workDayStart || "07:00";
  const end = opts?.workDayEnd || "16:00";
  const lunch = opts?.lunchHours ?? 1;
  return Math.round(shiftHoursRequired(start, end, lunch) * 10) / 10;
}

export function formatDayLabel(ymd: string): { weekday: string; label: string } {
  const d = parseYmd(ymd);
  const weekday = d.toLocaleDateString("en-US", { weekday: "short" });
  const label = d.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
  });
  return { weekday, label };
}

export function buildLoadDays(
  from: Date,
  opts?: {
    workDayStart?: string;
    workDayEnd?: string;
    lunchHours?: number;
    count?: number;
  },
): LoadDay[] {
  const cap = shiftDayHours(opts);
  return nextWorkdays(from, opts?.count ?? 5).map((ymd) => {
    const { weekday, label } = formatDayLabel(ymd);
    return { ymd, weekday, label, capacity: cap };
  });
}

function leftoverQty(line: { qty?: number; qtyCompleted?: number }) {
  return Math.max(0, (Number(line.qty) || 0) - (Number(line.qtyCompleted) || 0));
}

/** Who holds this card now — line checkout, or a single person on the OP slots. */
function hostOperator(host: {
  checkedOutBy?: string;
  opAssignments?: { checkedOutBy?: string }[];
}): string {
  const lineOp = norm(host.checkedOutBy || "");
  if (lineOp) return lineOp;
  const names = (host.opAssignments || [])
    .map((s) => norm(s.checkedOutBy || ""))
    .filter(Boolean);
  const uniq: string[] = [];
  for (const n of names) {
    if (!uniq.some((x) => x.toLowerCase() === n.toLowerCase())) uniq.push(n);
  }
  return uniq.length === 1 ? uniq[0]! : "";
}

function hostMachine(host: {
  checkedOutMachine?: string;
  officeAssignedMachine?: string;
  opAssignments?: {
    checkedOutMachine?: string;
    officeAssignedMachine?: string;
    checkedOutBy?: string;
  }[];
}): string {
  const m = norm(host.checkedOutMachine || host.officeAssignedMachine || "");
  if (m) return m;
  const hit = (host.opAssignments || []).find((s) => norm(s.checkedOutBy || ""));
  return norm(hit?.checkedOutMachine || hit?.officeAssignedMachine || "");
}

function collectFromOrders(
  orders: ShopOrder[],
  quotes: Quote[],
): LoadJob[] {
  const out: LoadJob[] = [];
  for (const order of orders || []) {
    if (order.status === "cancelled" || order.deliveredAt) continue;
    for (const line of order.lines || []) {
      if (line.lineStatus === "cancelled") continue;
      if (line.readyForPack || line.linePacked) continue;
      const due = lineShipDate(order, line) || "";
      const comps = normalizeComponents(line);
      if (comps.length) {
        for (const c of comps) {
          if (c.complete || c.boardHidden) continue;
          const qty = c.qty || leftoverQty(line) || line.qty || 1;
          const quote = quoteForPn(quotes, c.partNumber);
          if (isMultiMachinePart(quote)) {
            for (const opIndex of remainingTimedOps(quote, c.opAssignments)) {
              if (!previousTimedOpComplete(quote, c.opAssignments, opIndex))
                continue;
              const slot = getOpAssignment(c.opAssignments, opIndex);
              const slotOp = norm(slot?.checkedOutBy || "");
              if (!slotOp) continue;
              out.push({
                key: `c:${order.id}:${line.id}:${c.id}:op${opIndex}`,
                partNumber: c.partNumber,
                revision: c.revision || line.revision || "",
                qty,
                hours: quotedHoursForOp(quote, opIndex, qty),
                dueDate: due,
                operator: slotOp,
                machine: norm(
                  slot?.checkedOutMachine || slot?.officeAssignedMachine || "",
                ),
                poNumber: order.poNumber || "",
                customer: order.customer || "",
                live: false,
                pulled: true,
                opIndex,
                opLabel: opLabel(opIndex),
              });
            }
            continue;
          }
          const op = hostOperator(c);
          if (!op) continue;
          out.push({
            key: `c:${order.id}:${line.id}:${c.id}`,
            partNumber: c.partNumber,
            revision: c.revision || line.revision || "",
            qty,
            hours: quotedHoursForPart(quotes, c.partNumber, qty),
            dueDate: due,
            operator: op,
            machine: hostMachine(c),
            poNumber: order.poNumber || "",
            customer: order.customer || "",
            live: false,
            pulled: true,
            opIndex: null,
            opLabel: "",
          });
        }
      }
      if (line.boardHidden) continue;
      const leftover = leftoverQty(line);
      if (leftover <= 0) continue;
      const lineQuote = quoteForPn(quotes, line.partNumber);
      if (isMultiMachinePart(lineQuote)) {
        for (const opIndex of remainingTimedOps(lineQuote, line.opAssignments)) {
          if (!previousTimedOpComplete(lineQuote, line.opAssignments, opIndex))
            continue;
          const slot = getOpAssignment(line.opAssignments, opIndex);
          const slotOp = norm(slot?.checkedOutBy || "");
          if (!slotOp) continue;
          out.push({
            key: `l:${order.id}:${line.id}:op${opIndex}`,
            partNumber: line.partNumber,
            revision: line.revision || "",
            qty: leftover,
            hours: quotedHoursForOp(lineQuote, opIndex, leftover),
            dueDate: due,
            operator: slotOp,
            machine: norm(
              slot?.checkedOutMachine || slot?.officeAssignedMachine || "",
            ),
            poNumber: order.poNumber || "",
            customer: order.customer || "",
            live: false,
            pulled: true,
            opIndex,
            opLabel: opLabel(opIndex),
          });
        }
        continue;
      }
      const op = hostOperator(line);
      if (!op) continue;
      out.push({
        key: `l:${order.id}:${line.id}`,
        partNumber: line.partNumber,
        revision: line.revision || "",
        qty: leftover,
        hours: quotedHoursForPart(quotes, line.partNumber, leftover),
        dueDate: due,
        operator: op,
        machine: hostMachine(line),
        poNumber: order.poNumber || "",
        customer: order.customer || "",
        live: false,
        pulled: true,
        opIndex: null,
        opLabel: "",
      });
    }
  }
  return out;
}

function markLive(jobs: LoadJob[], sessions?: Record<string, MachineSession>) {
  if (!sessions) return jobs;
  return jobs.map((j) => {
    if (j.live) return j;
    const sess = j.machine ? sessions[j.machine] : undefined;
    if (!sess || normPn(sess.partNumber) !== normPn(j.partNumber)) return j;
    if (
      j.opIndex != null &&
      typeof sess.focusOpIndex === "number" &&
      sess.focusOpIndex !== j.opIndex
    ) {
      return j;
    }
    return { ...j, live: true };
  });
}

function dedupeJobs(jobs: LoadJob[]): LoadJob[] {
  const seen = new Set<string>();
  const out: LoadJob[] = [];
  for (const j of jobs) {
    const k = `${normPn(j.partNumber)}|${j.operator.toLowerCase()}|${j.machine.toLowerCase()}|${j.qty}|${j.opIndex ?? "all"}`;
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(j);
  }
  return out;
}

function mergeSameHolder(jobs: LoadJob[]): LoadJob[] {
  const map = new Map<string, LoadJob>();
  for (const j of jobs) {
    const k = `${j.operator.toLowerCase()}|${normPn(j.partNumber)}|${j.poNumber}|${j.revision}|${j.qty}`;
    const prev = map.get(k);
    if (!prev) {
      map.set(k, { ...j });
      continue;
    }
    prev.hours = Math.round((prev.hours + j.hours) * 10) / 10;
    if (prev.opLabel && j.opLabel && prev.opLabel !== j.opLabel) {
      prev.opLabel = "";
      prev.opIndex = null;
    }
  }
  return [...map.values()];
}

export function collectLoadJobs(opts: {
  shopOrders: ShopOrder[];
  workQueue: WorkQueueItem[];
  quotes: Quote[];
  sessions?: Record<string, MachineSession>;
}): LoadJob[] {
  const raw = collectFromOrders(opts.shopOrders || [], opts.quotes || []);
  return markLive(mergeSameHolder(dedupeJobs(raw)), opts.sessions);
}

function sortJobs(jobs: LoadJob[]): LoadJob[] {
  return [...jobs].sort((a, b) => {
    if (a.live !== b.live) return a.live ? -1 : 1;
    const da = a.dueDate || "9999-12-31";
    const db = b.dueDate || "9999-12-31";
    if (da !== db) return da.localeCompare(db);
    return a.partNumber.localeCompare(b.partNumber);
  });
}

function blockTone(job: LoadJob, missesDue: boolean): LoadBlock["tone"] {
  if (job.live) return "active";
  if (missesDue) return "overdue";
  const u = dueUrgency(job.dueDate);
  if (u === "overdue") return "overdue";
  if (u === "soon") return "soon";
  return "open";
}

function placeBlocks(jobs: LoadJob[], days: LoadDay[]): LoadBlock[] {
  const cap = days[0]?.capacity || 8;
  const total = days.length * cap;
  let cursor = 0;
  const blocks: LoadBlock[] = [];
  for (const job of sortJobs(jobs)) {
    if (!(job.hours > 0)) continue;
    const startHour = cursor;
    const hours = job.hours;
    cursor += hours;
    const segments: LoadSegment[] = [];
    let left = hours;
    let t = startHour;
    while (left > 0.001 && t < total + hours) {
      const dayIndex = Math.min(days.length - 1, Math.max(0, Math.floor(t / cap)));
      const into = t - dayIndex * cap;
      const room = Math.max(0.01, cap - into);
      const take = Math.min(left, room);
      if (dayIndex < days.length && take > 0) {
        segments.push({
          ymd: days[dayIndex]!.ymd,
          startFrac: into / cap,
          widthFrac: take / cap,
        });
      }
      left -= take;
      t += take;
      if (dayIndex >= days.length - 1 && left > 0) break;
    }
    const finishHour = startHour + hours;
    const finishDayIndex = Math.min(
      days.length - 1,
      Math.max(0, Math.floor((finishHour - 0.01) / cap)),
    );
    const finishYmd = days[finishDayIndex]?.ymd || days[days.length - 1]?.ymd || "";
    const missesDue = Boolean(job.dueDate && finishYmd && finishYmd > job.dueDate);
    blocks.push({
      job,
      tone: blockTone(job, missesDue),
      missesDue,
      startHour,
      hours,
      segments,
    });
  }
  return blocks;
}

function openByDay(blocks: LoadBlock[], days: LoadDay[]) {
  return days.map((d) => {
    const used = blocks.reduce((n, b) => {
      const seg = b.segments.find((s) => s.ymd === d.ymd);
      return n + (seg ? seg.widthFrac * d.capacity : 0);
    }, 0);
    return { ymd: d.ymd, open: Math.max(0, Math.round((d.capacity - used) * 10) / 10) };
  });
}

function buildLane(
  name: string,
  kind: "person" | "machine",
  jobs: LoadJob[],
  days: LoadDay[],
): LoadLane {
  const blocks = placeBlocks(jobs, days);
  const chips = sortJobs(jobs).filter((j) => !(j.hours > 0));
  const open = openByDay(blocks, days);
  const booked = Math.round(jobs.reduce((n, j) => n + (j.hours || 0), 0) * 10) / 10;
  const hole = open.find((d) => d.open > 0.05) || open[open.length - 1];
  return {
    name,
    kind,
    bookedHours: booked,
    jobs: sortJobs(jobs),
    blocks,
    chips,
    openByDay: open,
    tailOpen: hole?.open ?? 0,
    tailDay: hole?.ymd || "",
  };
}

export function buildPersonLanes(opts: {
  jobs: LoadJob[];
  days: LoadDay[];
  operatorNames: string[];
}): LoadLane[] {
  const by = new Map<string, LoadJob[]>();
  for (const n of opts.operatorNames) {
    if (n.trim()) by.set(n.trim(), []);
  }
  for (const j of opts.jobs) {
    if (!j.operator) continue;
    const list = by.get(j.operator) || [];
    list.push(j);
    by.set(j.operator, list);
  }
  return [...by.entries()]
    .map(([name, jobs]) => buildLane(name, "person", jobs, opts.days))
    .sort((a, b) => b.bookedHours - a.bookedHours || a.name.localeCompare(b.name));
}

export function buildMachineLanes(opts: {
  jobs: LoadJob[];
  days: LoadDay[];
  officialMachines: string[];
}): LoadLane[] {
  const listed = new Set(
    (opts.officialMachines || []).map((m) => m.trim().toLowerCase()),
  );
  const by = new Map<string, LoadJob[]>();
  for (const m of opts.officialMachines || []) {
    if (m.trim()) by.set(m.trim(), []);
  }
  const loose: LoadJob[] = [];
  for (const j of opts.jobs) {
    if (!j.machine) {
      loose.push(j);
      continue;
    }
    if (listed.size && !listed.has(j.machine.toLowerCase())) continue;
    const canon =
      (opts.officialMachines || []).find(
        (m) => m.toLowerCase() === j.machine.toLowerCase(),
      ) || j.machine;
    const list = by.get(canon) || [];
    list.push(j);
    by.set(canon, list);
  }
  const lanes = [...by.entries()].map(([name, jobs]) =>
    buildLane(name, "machine", jobs, opts.days),
  );
  if (loose.length) lanes.push(buildLane("No machine", "machine", loose, opts.days));
  return lanes.sort(
    (a, b) => b.bookedHours - a.bookedHours || a.name.localeCompare(b.name),
  );
}

export function findSqueeze(
  lanes: LoadLane[],
  hours: number,
  days: LoadDay[],
): SqueezeHit | null {
  const need = Math.round(Number(hours) * 10) / 10;
  if (!(need > 0) || !lanes.length) return null;
  let best: SqueezeHit | null = null;
  for (const lane of lanes) {
    for (const slot of lane.openByDay) {
      if (slot.open + 0.05 < need) continue;
      const day = days.find((d) => d.ymd === slot.ymd);
      const hit: SqueezeHit = {
        lane: lane.name,
        kind: lane.kind,
        day: slot.ymd,
        dayLabel: day ? `${day.weekday} ${day.label}` : slot.ymd,
        open: slot.open,
        hours: need,
      };
      if (
        !best ||
        hit.day < best.day ||
        (hit.day === best.day && hit.open > best.open)
      ) {
        best = hit;
      }
      break;
    }
  }
  return best;
}

export function resolveSqueezeHours(
  quotes: Quote[],
  rawHours: string,
  partNumber: string,
  qty: number,
): number {
  const typed = Number(rawHours);
  if (Number.isFinite(typed) && typed > 0) return Math.round(typed * 10) / 10;
  const pn = normPn(partNumber);
  if (!pn) return 0;
  return quotedHoursForPart(quotes, pn, Math.max(1, qty || 1));
}

export function listedMachines(custom?: CustomLists): string[] {
  return allMachines(custom);
}
