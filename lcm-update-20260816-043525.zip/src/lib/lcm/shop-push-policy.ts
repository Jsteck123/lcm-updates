/**
 * What a floor operator is allowed to write back to the host.
 * Quotes, prices, operators, and settings stay office-only even if
 * a machine PC still has an old copy of those collections in memory.
 */
import type { ShopOrder, ShopOrderLine, ShopLineComponent } from "./types";
import type { ShopSharedState } from "./shop-types";

const FLOOR_LINE_KEYS = [
  "qtyCompleted",
  "checkedOutBy",
  "checkedOutAt",
  "checkedOutMachine",
  "readyForPack",
  "readyForPackAt",
  "readyForPackBy",
  "linePacked",
  "linePackedAt",
  "linePackedBy",
  "opAssignments",
] as const;

function mergeComponentFloor(
  host: ShopLineComponent,
  incoming: ShopLineComponent | undefined,
): ShopLineComponent {
  if (!incoming) return host;
  return {
    ...host,
    checkedOutBy: incoming.checkedOutBy,
    checkedOutAt: incoming.checkedOutAt,
    checkedOutMachine: incoming.checkedOutMachine,
    complete: incoming.complete,
    completedAt: incoming.completedAt,
    completedBy: incoming.completedBy,
    opAssignments: incoming.opAssignments ?? host.opAssignments,
    boardHidden: incoming.boardHidden,
  };
}

function mergeLineFloor(
  host: ShopOrderLine,
  incoming: ShopOrderLine | undefined,
): ShopOrderLine {
  if (!incoming) return host;
  const incComp = new Map(
    (incoming.components || []).map((c) => [c.id, c]),
  );
  const next: ShopOrderLine = { ...host };
  for (const k of FLOOR_LINE_KEYS) {
    if (k in incoming) {
      (next as unknown as Record<string, unknown>)[k] = incoming[k];
    }
  }
  next.components = (host.components || []).map((c) =>
    mergeComponentFloor(c, incComp.get(c.id)),
  );
  return next;
}

/** Keep office header / prices; take floor checkout / pack / qty from incoming. */
export function mergeShopOrdersFloor(
  host: ShopOrder[] | undefined,
  incoming: ShopOrder[] | undefined,
): ShopOrder[] {
  const h = Array.isArray(host) ? host : [];
  const incMap = new Map(
    (Array.isArray(incoming) ? incoming : []).map((o) => [o.id, o]),
  );
  return h.map((order) => {
    const next = incMap.get(order.id);
    if (!next) return order;
    const lineMap = new Map((next.lines || []).map((l) => [l.id, l]));
    return {
      ...order,
      status: next.status || order.status,
      packStatus: next.packStatus || order.packStatus,
      packedBy: next.packedBy ?? order.packedBy,
      packedAt: next.packedAt ?? order.packedAt,
      verifiedBy: next.verifiedBy ?? order.verifiedBy,
      verifiedAt: next.verifiedAt ?? order.verifiedAt,
      deliveredAt: next.deliveredAt ?? order.deliveredAt,
      deliveredBy: next.deliveredBy ?? order.deliveredBy,
      signedSlipFileId: next.signedSlipFileId || order.signedSlipFileId,
      signedSlipName: next.signedSlipName || order.signedSlipName,
      signedSlipMime: next.signedSlipMime || order.signedSlipMime,
      lines: (order.lines || []).map((l) => mergeLineFloor(l, lineMap.get(l.id))),
      updatedAt: next.updatedAt || order.updatedAt,
    };
  });
}

/** Collections a non-admin may replace. Everything else stays on the host. */
export function floorWritableState(
  host: ShopSharedState,
  incoming: ShopSharedState,
): ShopSharedState {
  return {
    ...host,
    jobs: incoming.jobs,
    downtimes: incoming.downtimes,
    operatorTimeLog: incoming.operatorTimeLog,
    sessions: incoming.sessions,
    activeTimers: incoming.activeTimers,
    dayBonuses: incoming.dayBonuses,
    workQueue: incoming.workQueue,
    cutTickets: incoming.cutTickets,
    shopOrders: mergeShopOrdersFloor(host.shopOrders, incoming.shopOrders),
    chatMessages: incoming.chatMessages,
    shopToolingLogs: incoming.shopToolingLogs,
    feedbackTickets: incoming.feedbackTickets,
    auditLog: incoming.auditLog,
    stockPieces: incoming.stockPieces,
    materialStock: incoming.materialStock,
    partStock: incoming.partStock,
    partUnits: incoming.partUnits,
    inventoryTxns: incoming.inventoryTxns,
    poFollowups: incoming.poFollowups,
  };
}

export type ShopDirectory = {
  companyName: string;
  machines: string[];
  operators: Array<{
    id: string;
    name: string;
    email: string;
    role: "admin" | "operator";
    tabs: ShopSharedState["operators"][number]["tabs"];
    active: boolean;
    hasPin: boolean;
  }>;
};

export function toShopDirectory(state: ShopSharedState): ShopDirectory {
  return {
    companyName: state.settings?.companyName || "Lake Country Machine",
    machines: state.settings?.customLists?.machines || [],
    operators: (state.operators || []).map((op) => ({
      id: op.id,
      name: op.name,
      email: op.email,
      role: op.role === "admin" ? "admin" : "operator",
      tabs: op.tabs,
      active: op.active !== false,
      hasPin: Boolean(op.pin && String(op.pin).length > 0),
    })),
  };
}
