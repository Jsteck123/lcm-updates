import { useMemo, useState } from "react";
import { Plus, Send, Trophy, Trash2, Mail } from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { Input, Label, Select, Textarea } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Typeahead } from "@/components/ui/typeahead";
import { MultiSelect } from "@/components/ui/multi-select";
import {
  bidLineTotal,
  defaultBidLinesForRfq,
  emptyVendorRfqLine,
  rfqEmailBody,
} from "@/lib/lcm/vendor-rfq";
import type { VendorBid, VendorRfq, VendorRfqLine } from "@/lib/lcm/types";
import { formatCurrency } from "@/lib/utils";
import { INVENTORY_UNITS } from "@/lib/lcm/inventory";
import { MaterialGuideField } from "@/components/lcm/guided-material-form";

/**
 * Vendor RFQ → enter bids → award winner → material buy PO
 */
export function VendorRfqPanel() {
  const vendorRfqs = useLcmStore((s) => s.vendorRfqs || []);
  const createVendorRfq = useLcmStore((s) => s.createVendorRfq);
  const upsertVendorRfq = useLcmStore((s) => s.upsertVendorRfq);
  const removeVendorRfq = useLcmStore((s) => s.removeVendorRfq);
  const addVendorBid = useLcmStore((s) => s.addVendorBid);
  const acceptVendorBid = useLcmStore((s) => s.acceptVendorBid);
  const settings = useLcmStore((s) => s.settings);
  const company = settings.companyName || "Shop";

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const selected = useMemo(
    () => vendorRfqs.find((r) => r.id === selectedId) || vendorRfqs[0] || null,
    [vendorRfqs, selectedId],
  );

  const [bidVendor, setBidVendor] = useState("");
  const [bidQuoteNo, setBidQuoteNo] = useState("");
  const [bidFreight, setBidFreight] = useState("0");
  const [bidNotes, setBidNotes] = useState("");
  const [bidCosts, setBidCosts] = useState<Record<string, string>>({});

  const vendorOptions = useMemo(() => {
    const set = new Set<string>();
    for (const r of vendorRfqs) {
      for (const v of r.vendorsRequested || []) if (v.trim()) set.add(v.trim());
      for (const b of r.bids || []) if (b.vendor.trim()) set.add(b.vendor.trim());
    }
    for (const d of [
      "Metal Supermarkets",
      "Ryerson",
      "Online Metals",
      "McMaster-Carr",
      "Local Steel",
    ])
      set.add(d);
    return [...set].sort((a, b) => a.localeCompare(b));
  }, [vendorRfqs]);

  function newRfq() {
    const rfq = createVendorRfq({
      lines: [emptyVendorRfqLine({ material: "Aluminum", materialType: "T6 6061" })],
    });
    setSelectedId(rfq.id);
    toast.success(`Created ${rfq.rfqNumber}`);
  }

  function patchRfq(patch: Partial<VendorRfq>) {
    if (!selected) return;
    upsertVendorRfq({ ...selected, ...patch });
  }

  function patchLine(lineId: string, patch: Partial<VendorRfqLine>) {
    if (!selected) return;
    upsertVendorRfq({
      ...selected,
      lines: selected.lines.map((l) =>
        l.id === lineId ? { ...l, ...patch } : l,
      ),
    });
  }

  function addLine() {
    if (!selected) return;
    upsertVendorRfq({
      ...selected,
      lines: [...selected.lines, emptyVendorRfqLine()],
    });
  }

  function removeLine(lineId: string) {
    if (!selected || selected.lines.length <= 1) {
      toast.error("Keep at least one line");
      return;
    }
    upsertVendorRfq({
      ...selected,
      lines: selected.lines.filter((l) => l.id !== lineId),
    });
  }

  function markSent() {
    if (!selected) return;
    if (!selected.lines.some((l) => l.material.trim())) {
      toast.error("Add material lines first");
      return;
    }
    upsertVendorRfq({
      ...selected,
      status: selected.status === "draft" ? "sent" : selected.status,
    });
    toast.success("RFQ marked sent — enter vendor bids when they reply");
  }

  function openRfqEmail() {
    if (!selected) return;
    const subject = `${company} Material RFQ ${selected.rfqNumber}`;
    const body = rfqEmailBody({ companyName: company, rfq: selected });
    const to = ""; // user picks vendor
    const url = `mailto:${encodeURIComponent(to)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    if (url.length > 1800) {
      void navigator.clipboard.writeText(`${subject}\n\n${body}`);
      toast.message("RFQ body copied — paste into email (too long for mailto)");
    }
    window.location.href = url;
    if (selected.status === "draft") {
      upsertVendorRfq({ ...selected, status: "sent" });
    }
  }

  function submitBid() {
    if (!selected) return;
    const lines = defaultBidLinesForRfq(selected).map((bl) => ({
      ...bl,
      unitCost: Number(bidCosts[bl.rfqLineId] || 0) || 0,
    }));
    const r = addVendorBid(selected.id, {
      vendor: bidVendor,
      vendorQuoteNumber: bidQuoteNo,
      freight: Number(bidFreight) || 0,
      notes: bidNotes,
      lines,
    });
    if (!r.ok) {
      toast.error(r.error);
      return;
    }
    toast.success(`Bid from ${bidVendor} saved`);
    setBidVendor("");
    setBidQuoteNo("");
    setBidFreight("0");
    setBidNotes("");
    setBidCosts({});
  }

  function award(bid: VendorBid) {
    if (!selected) {
      toast.error("No RFQ selected");
      return;
    }
    try {
      const r = acceptVendorBid(selected.id, bid.id);
      if (!r.ok) {
        toast.error(r.error || "Could not award bid");
        return;
      }
      // Keep this RFQ selected so status updates are visible
      setSelectedId(selected.id);
      toast.success(
        `Awarded to ${bid.vendor} · material PO ${r.po?.poNumber || "?"} created. Open Material buys to receive.`,
      );
    } catch (e) {
      console.error(e);
      toast.error(
        e instanceof Error ? e.message : "Award failed — see console",
      );
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Vendor RFQs (material quotes)</CardTitle>
          <CardDescription>
            Ask vendors for pricing with your RFQ # → enter their quotes → pick
            a winner → turn it into a material buy PO. Customer part quotes stay
            on Master Quoter.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button onClick={newRfq}>
            <Plus className="h-4 w-4" /> New RFQ
          </Button>
          <p className="text-xs text-[var(--color-muted)] self-center">
            After award → open <strong>Material buys</strong> tab to receive & print labels
          </p>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">RFQ list</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 max-h-96 overflow-y-auto">
            {vendorRfqs.map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => setSelectedId(r.id)}
                className={
                  "w-full text-left rounded-[var(--radius-md)] border px-3 py-2 text-sm " +
                  (selected?.id === r.id
                    ? "border-[var(--color-primary)]"
                    : "border-[var(--color-border)]")
                }
              >
                <div className="font-medium font-mono">{r.rfqNumber}</div>
                <div className="text-xs text-[var(--color-muted)] flex flex-wrap gap-1 items-center">
                  <Badge
                    tone={
                      r.status === "awarded"
                        ? "success"
                        : r.status === "quoted"
                          ? "info"
                          : r.status === "sent"
                            ? "warn"
                            : "neutral"
                    }
                  >
                    {r.status}
                  </Badge>
                  <span>{r.bids?.length || 0} bid(s)</span>
                </div>
              </button>
            ))}
            {vendorRfqs.length === 0 && (
              <p className="text-sm text-[var(--color-muted)]">
                No RFQs yet. Create one when you need material pricing.
              </p>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0">
            <div>
              <CardTitle className="text-base font-mono">
                {selected ? selected.rfqNumber : "Select or create an RFQ"}
              </CardTitle>
              {selected && (
                <p className="text-xs text-[var(--color-muted)] mt-1">
                  Status: {selected.status}
                  {selected.purchaseOrderId
                    ? " · linked material PO created"
                    : ""}
                </p>
              )}
            </div>
            {selected && selected.status !== "awarded" && (
              <Button
                type="button"
                size="sm"
                variant="ghost"
                onClick={() => {
                  if (confirm(`Delete ${selected.rfqNumber}?`)) {
                    removeVendorRfq(selected.id);
                    setSelectedId(null);
                  }
                }}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
          </CardHeader>

          {selected && (
            <CardContent className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Date</Label>
                  <Input
                    type="date"
                    value={selected.date?.slice(0, 10) || ""}
                    onChange={(e) => patchRfq({ date: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Needed by</Label>
                  <Input
                    type="date"
                    value={selected.neededBy?.slice(0, 10) || ""}
                    onChange={(e) => patchRfq({ neededBy: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Customer quote ref (optional)</Label>
                  <Input
                    placeholder="Part # / quote batch"
                    value={selected.customerQuoteRef}
                    onChange={(e) =>
                      patchRfq({ customerQuoteRef: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Shop order / job ref (optional)</Label>
                  <Input
                    placeholder="PO-26-… or job"
                    value={selected.shopOrderRef}
                    onChange={(e) =>
                      patchRfq({ shopOrderRef: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-1.5 sm:col-span-2">
                  <Label>Vendors to request</Label>
                  <MultiSelect
                    value={selected.vendorsRequested || []}
                    options={vendorOptions}
                    onChange={(vendorsRequested) =>
                      patchRfq({ vendorsRequested })
                    }
                    placeholder="Select one or more vendors…"
                    allowCreate
                  />
                  <p className="text-[11px] text-[var(--color-subtle)] mt-1">
                    Multi-select · type to filter · add a new vendor name anytime
                  </p>
                </div>
                <div className="space-y-1.5 sm:col-span-2">
                  <Label>Notes to vendors</Label>
                  <Textarea
                    rows={2}
                    value={selected.notes}
                    onChange={(e) => patchRfq({ notes: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-semibold">Lines to quote</Label>
                  <Button type="button" size="sm" variant="outline" onClick={addLine}>
                    <Plus className="h-3.5 w-3.5" /> Line
                  </Button>
                </div>
                {selected.lines.map((line, idx) => (
                  <div
                    key={line.id}
                    className="rounded-[var(--radius-md)] border border-[var(--color-border)] p-3 space-y-2"
                  >
                    <div className="text-xs text-[var(--color-muted)]">
                      Line {idx + 1}
                    </div>
                    <div className="grid sm:grid-cols-3 gap-2">
                      <div className="sm:col-span-3">
                        <MaterialGuideField
                          title="Stock for RFQ line"
                          stock={line}
                          onApply={(next) =>
                            patchLine(line.id, {
                              material: next.material,
                              materialType: next.materialType,
                              stockShape: next.stockShape,
                              sizeNote: next.sizeNote,
                              lengthEach: next.lengthEach,
                            })
                          }
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Qty</Label>
                        <Input
                          type="number"
                          value={line.qty}
                          onChange={(e) =>
                            patchLine(line.id, {
                              qty: Number(e.target.value) || 0,
                            })
                          }
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Unit</Label>
                        <Select
                          value={line.unit}
                          onChange={(e) =>
                            patchLine(line.id, {
                              unit: e.target.value as VendorRfqLine["unit"],
                            })
                          }
                        >
                          {INVENTORY_UNITS.map((u) => (
                            <option key={u} value={u}>
                              {u}
                            </option>
                          ))}
                        </Select>
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Length each (in)</Label>
                        <Input
                          type="number"
                          value={line.lengthEach}
                          onChange={(e) =>
                            patchLine(line.id, {
                              lengthEach: Number(e.target.value) || 0,
                            })
                          }
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Part # (optional)</Label>
                        <Input
                          value={line.partNumber}
                          onChange={(e) =>
                            patchLine(line.id, {
                              partNumber: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                    <Button
                      type="button"
                      size="sm"
                      variant="ghost"
                      onClick={() => removeLine(line.id)}
                    >
                      Remove line
                    </Button>
                  </div>
                ))}
              </div>

              <div className="flex flex-wrap gap-2">
                <Button type="button" variant="secondary" onClick={openRfqEmail}>
                  <Mail className="h-4 w-4" /> Email RFQ to vendor
                </Button>
                <Button type="button" variant="outline" onClick={markSent}>
                  <Send className="h-4 w-4" /> Mark sent
                </Button>
              </div>
              <p className="text-[11px] text-[var(--color-subtle)]">
                Email includes RFQ # <strong>{selected.rfqNumber}</strong> so
                vendors put it on their reply. Enter each reply below.
              </p>

              {/* Enter bid */}
              {selected.status !== "awarded" && (
                <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)]/40 p-3 space-y-3">
                  <div className="text-sm font-semibold">Enter vendor quote (bid)</div>
                  <div className="grid sm:grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <Label className="text-xs">Vendor</Label>
                      <Typeahead
                        value={bidVendor}
                        options={vendorOptions}
                        onChange={setBidVendor}
                        placeholder="Who quoted?"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Their quote #</Label>
                      <Input
                        value={bidQuoteNo}
                        onChange={(e) => setBidQuoteNo(e.target.value)}
                        placeholder="Vendor Q-… "
                      />
                    </div>
                    {selected.lines.map((line) => (
                      <div key={line.id} className="space-y-1">
                        <Label className="text-xs">
                          $/unit · {line.material} {line.sizeNote || line.materialType}
                        </Label>
                        <Input
                          type="number"
                          step="0.01"
                          value={bidCosts[line.id] || ""}
                          onChange={(e) =>
                            setBidCosts((c) => ({
                              ...c,
                              [line.id]: e.target.value,
                            }))
                          }
                          placeholder="0.00"
                        />
                      </div>
                    ))}
                    <div className="space-y-1">
                      <Label className="text-xs">Freight $</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={bidFreight}
                        onChange={(e) => setBidFreight(e.target.value)}
                      />
                    </div>
                    <div className="space-y-1 sm:col-span-2">
                      <Label className="text-xs">Bid notes</Label>
                      <Input
                        value={bidNotes}
                        onChange={(e) => setBidNotes(e.target.value)}
                        placeholder="Lead time, mill cert, etc."
                      />
                    </div>
                  </div>
                  <Button type="button" onClick={submitBid}>
                    Save vendor bid
                  </Button>
                </div>
              )}

              {/* Compare bids */}
              <div className="space-y-2">
                <div className="text-sm font-semibold">Bids received</div>
                {(selected.bids || []).length === 0 && (
                  <p className="text-sm text-[var(--color-muted)]">
                    No bids yet — wait for vendor replies, then enter them above.
                  </p>
                )}
                {(selected.bids || []).map((bid) => {
                  const tot = bidLineTotal(selected, bid);
                  const isWin = selected.awardedBidId === bid.id;
                  return (
                    <div
                      key={bid.id}
                      className={
                        "rounded-[var(--radius-md)] border px-3 py-3 text-sm space-y-1 " +
                        (isWin
                          ? "border-[var(--color-success)] bg-[color-mix(in_oklab,var(--color-success)_10%,transparent)]"
                          : "border-[var(--color-border)]")
                      }
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <span className="font-semibold">{bid.vendor}</span>
                          {bid.vendorQuoteNumber ? (
                            <span className="text-[var(--color-muted)]">
                              {" "}
                              · their # {bid.vendorQuoteNumber}
                            </span>
                          ) : null}
                          <Badge
                            className="ml-2"
                            tone={
                              bid.status === "accepted"
                                ? "success"
                                : bid.status === "rejected"
                                  ? "neutral"
                                  : "info"
                            }
                          >
                            {bid.status}
                          </Badge>
                        </div>
                        <div className="font-semibold tabular">
                          {formatCurrency(tot.total)}
                          <span className="text-xs font-normal text-[var(--color-muted)]">
                            {" "}
                            (mat {formatCurrency(tot.material)}
                            {tot.freight
                              ? ` + frt ${formatCurrency(tot.freight)}`
                              : ""}
                            )
                          </span>
                        </div>
                      </div>
                      {bid.notes && (
                        <p className="text-xs text-[var(--color-muted)]">
                          {bid.notes}
                        </p>
                      )}
                      {selected.status !== "awarded" && bid.status === "open" && (
                        <Button
                          type="button"
                          size="sm"
                          className="mt-1"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            award(bid);
                          }}
                        >
                          <Trophy className="h-3.5 w-3.5" /> Accept → create PO
                        </Button>
                      )}
                      {isWin && (
                        <p className="text-xs text-[var(--color-success)]">
                          Winner — open <strong>Material buys</strong> tab to
                          receive stock & print labels.
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          )}
        </Card>
      </div>
    </div>
  );
}
