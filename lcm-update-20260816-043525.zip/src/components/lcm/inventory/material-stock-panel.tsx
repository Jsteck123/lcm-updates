import { MoneyInput } from "./material-buys-panel";
import {
  Eraser,
  Trash2,
  ArrowDownToLine,
  ArrowUpFromLine,
  SlidersHorizontal,
  Plus,
  Search,
  X,
  AlertTriangle,
} from "lucide-react";
// Plus used in save buttons

import { useEffect, useMemo } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CreatableSelect } from "@/components/ui/creatable-select";
import { Typeahead } from "@/components/ui/typeahead";
import {
  INVENTORY_UNITS,
  emptyMaterial,
  isLowStock,
  materialLabel,
  type MaterialOnHandFilters,
} from "@/lib/lcm/inventory";
import type { AppSettings, InventoryTxnType, MaterialStock } from "@/lib/lcm/types";
import { formatCurrency } from "@/lib/utils";
import { MaterialGuideField } from "@/components/lcm/guided-material-form";
import { formatSizeNote } from "@/lib/lcm/po-material";
import { useCanSeeMoney } from "@/hooks/use-can-see-money";
import { inventoryQtyStatus } from "@/lib/lcm/status-colors";
import { stockSizeNoteHint } from "@/lib/lcm/stock-size-catalog";
import {
  bookVsStockHint,
  emjCostPerUnitFromEstimate,
  estimateMaterialFromBook,
  LCM_CALC_LABEL,
  matchPriceEntry,
  normalizeMaterialPriceBook,
  parseSizeNoteForEmj,
} from "@/lib/lcm/material-rates";

export type MaterialStockPanelProps = {
  matForm: MaterialStock;
  setMatForm: React.Dispatch<React.SetStateAction<MaterialStock>>;
  editingMatId: string | null;
  setEditingMatId: (id: string | null) => void;
  materials: string[];
  shapes: string[];
  matTypes: string[];
  sizeNoteOptions: string[];
  vendorOptions: string[];
  settings: AppSettings;
  filteredMat: MaterialStock[];
  /** Total lines before filters (for “showing X of Y”) */
  totalMatCount: number;
  matFilters: MaterialOnHandFilters;
  setMatFilters: React.Dispatch<React.SetStateAction<MaterialOnHandFilters>>;
  matFilterOptions: {
    materials: string[];
    materialTypes: string[];
    stockShapes: string[];
    sizeNotes: string[];
    locations: string[];
    vendors: string[];
    searchHints: string[];
  };
  matFilterActiveCount: number;
  clearMatFilters: () => void;
  saveMaterial: () => void;
  addCustomListItem: (
    kind: "materials" | "machines" | "stockShapes" | "pauseReasons" | "materialTypes" | "sizeNotes",
    value: string,
    materialForType?: string,
  ) => { ok: boolean; error?: string };
  openMove: (
    itemKind: "material" | "part",
    itemId: string,
    label: string,
    kind: InventoryTxnType,
  ) => void;
  editMaterial: (m: MaterialStock) => void;
  setDeleteTarget: (t: { kind: "material" | "part"; id: string; label: string } | null) => void;
};

function patchFilter(
  setMatFilters: React.Dispatch<React.SetStateAction<MaterialOnHandFilters>>,
  key: keyof MaterialOnHandFilters,
  value: string | boolean,
) {
  setMatFilters((f) => ({ ...f, [key]: value }));
}

export function MaterialStockPanel({
  matForm,
  setMatForm,
  editingMatId,
  setEditingMatId,
  materials,
  shapes,
  matTypes,
  sizeNoteOptions,
  vendorOptions,
  filteredMat,
  totalMatCount,
  matFilters,
  setMatFilters,
  matFilterOptions,
  matFilterActiveCount,
  clearMatFilters,
  settings,
  saveMaterial,
  addCustomListItem,
  openMove,
  editMaterial,
  setDeleteTarget,
}: MaterialStockPanelProps) {
  const canSeeMoney = useCanSeeMoney();
  const priceBook = useMemo(
    () => normalizeMaterialPriceBook(settings.materialPriceBook),
    [settings.materialPriceBook],
  );
  const parsedSize = useMemo(
    () => parseSizeNoteForEmj(matForm.sizeNote || ""),
    [matForm.sizeNote],
  );
  const unitKey = (matForm.unit || "").toLowerCase();
  const lengthFromOnHand =
    unitKey === "in" || unitKey === "inch" || unitKey === "inches"
      ? Number(matForm.onHand) || 0
      : unitKey === "ft" || unitKey === "feet" || unitKey === "foot"
        ? (Number(matForm.onHand) || 0) * 12
        : 0;
  const emj = useMemo(
    () =>
      estimateMaterialFromBook({
        book: priceBook,
        material: matForm.material || "",
        materialType: matForm.materialType || "",
        stockShape: matForm.stockShape || "",
        dimX: Number(matForm.dimX) || parsedSize.dimX,
        dimY: Number(matForm.dimY) || parsedSize.dimY,
        dimZ: Number(matForm.dimZ) || parsedSize.dimZ,
        rawMaterialLength: parsedSize.lengthIn || lengthFromOnHand || 0,
        partLengthEach: 0,
      }),
    [
      priceBook,
      matForm.material,
      matForm.materialType,
      matForm.stockShape,
      matForm.dimX,
      matForm.dimY,
      matForm.dimZ,
      parsedSize,
      lengthFromOnHand,
    ],
  );
  const bookRow = useMemo(
    () => matchPriceEntry(priceBook, matForm.material, matForm.materialType),
    [priceBook, matForm.material, matForm.materialType],
  );
  const unitFromBook = emj.ok
    ? emjCostPerUnitFromEstimate(emj, matForm.unit)
    : bookRow
      ? emjCostPerUnitFromEstimate(
          {
            ok: true,
            lbPerFoot: 0,
            lengthIn: 0,
            lengthFt: 0,
            totalLb: 0,
            pricePerLb: bookRow.pricePerLb,
            stockCost: 0,
            cutCost: 0,
            grade: bookRow.grade,
            family: bookRow.family,
            formula: "",
            densityLbIn3: bookRow.densityLbIn3,
            shapeId: "",
          },
          matForm.unit,
        )
      : null;
  const vsBook = bookVsStockHint(
    bookRow,
    matForm.costPerUnit || 0,
    matForm.unit,
  );

  useEffect(() => {
    if (!canSeeMoney) return;
    if (!unitFromBook || !(unitFromBook.costPerUnit > 0)) return;
    if (editingMatId) return;
    setMatForm((f) => {
      if (Math.abs((f.costPerUnit || 0) - unitFromBook.costPerUnit) < 1e-9) {
        return f;
      }
      return { ...f, costPerUnit: unitFromBook.costPerUnit };
    });
  }, [
    canSeeMoney,
    editingMatId,
    setMatForm,
    unitFromBook?.costPerUnit,
    unitFromBook?.label,
  ]);
  return (
  <>
    <Card>
      <CardHeader className="flex flex-row items-start justify-between gap-3 space-y-0">
        <div className="min-w-0 space-y-1.5">
          <CardTitle>
            {editingMatId ? "Edit material" : "Add material stock"}
          </CardTitle>
          <CardDescription>
            Track bar, plate, sheet by material + type + size. Set a min qty
            for reorder warnings.
          </CardDescription>
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="shrink-0"
          onClick={() => {
            setMatForm(
              emptyMaterial({
                id: "",
                material: "",
                materialType: "",
                stockShape: "",
                sizeNote: "",
                unit: "pcs",
                onHand: 0,
                minQty: 0,
                location: "",
                vendor: "",
                costPerUnit: 0,
                notes: "",
                dimX: 0,
                dimY: 0,
                dimZ: 0,
              }),
            );
            setEditingMatId(null);
            toast.message("Material form cleared");
          }}
        >
          <Eraser className="h-4 w-4" />
          Clear all
        </Button>
      </CardHeader>
      <CardContent className="space-y-3">
        <MaterialGuideField
          title={editingMatId ? "Edit material stock" : "Add material stock"}
          mode="inventory"
          stock={matForm}
          onApply={(next) =>
            setMatForm((f) => ({
              ...f,
              material: next.material,
              materialType: next.materialType,
              stockShape: next.stockShape,
              dimX: next.dimX,
              dimY: next.dimY,
              dimZ: next.dimZ,
              sizeNote: formatSizeNote({
                sizeNote: "",
                dimX: next.dimX,
                dimY: next.dimY,
                dimZ: next.dimZ,
                stockShape: next.stockShape,
              }),
            }))
          }
        />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          <div className="space-y-1.5">
            <Label>Unit (bar stock = inches)</Label>
            <Select
              value={matForm.unit}
              onChange={(e) =>
                setMatForm((f) => ({
                  ...f,
                  unit: e.target.value as MaterialStock["unit"],
                }))
              }
            >
              {INVENTORY_UNITS.map((u) => (
                <option key={u} value={u}>
                  {u}
                </option>
              ))}
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>On hand</Label>
            <Input
              type="number"
              value={matForm.onHand}
              onChange={(e) =>
                setMatForm((f) => ({
                  ...f,
                  onHand: Number(e.target.value),
                }))
              }
            />
            <p className="text-[11px] text-[var(--color-subtle)] mt-1">
              Count bar / rect / round in <strong>inches</strong> of stick.
            </p>
          </div>
          <div className="space-y-1.5">
            <Label>Min qty (reorder)</Label>
            <Input
              type="number"
              value={matForm.minQty}
              onChange={(e) =>
                setMatForm((f) => ({
                  ...f,
                  minQty: Number(e.target.value),
                }))
              }
            />
          </div>
          <div className="space-y-1.5">
            <Label>Location</Label>
            <Input
              placeholder="Rack A-1"
              value={matForm.location}
              onChange={(e) =>
                setMatForm((f) => ({ ...f, location: e.target.value }))
              }
            />
          </div>
          <div className="space-y-1.5">
            <Label>Vendor</Label>
            <CreatableSelect
              allowEmpty
              emptyLabel="— Select vendor —"
              value={matForm.vendor || ""}
              options={vendorOptions}
              onChange={(v) =>
                setMatForm((f) => ({ ...f, vendor: v }))
              }
              onCreate={(v) => {
                setMatForm((f) => ({ ...f, vendor: v.trim() }));
                toast.success(`Vendor ${v.trim()} ready to save`);
                return true;
              }}
              createTitle="Add vendor"
              createHint="Supplier you buy this stock from"
            />
          </div>
          {canSeeMoney && (
          <div className="space-y-1.5">
            <Label>Cost / unit</Label>
            <MoneyInput
              value={matForm.costPerUnit || 0}
              onValueChange={(n) =>
                setMatForm((f) => ({ ...f, costPerUnit: n }))
              }
            />
            <p className="text-[11px] text-[var(--color-subtle)] mt-1">
              What you pay for <strong>one</strong> of the Unit above
              (ea, ft, lb…). Stock value = on hand × this.
            </p>
            {vsBook ? (
              <p className="text-[11px] text-[var(--color-muted)]">{vsBook}</p>
            ) : null}
            <div className="rounded-md border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-2">
              <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">
                {LCM_CALC_LABEL}
              </div>
              {emj.ok ? (
                <>
                  <p className="text-sm leading-snug">
                    <strong>{emj.grade}</strong>
                    {" · "}
                    {formatCurrency(emj.pricePerLb)}/lb
                    {emj.lbPerFoot > 0 ? (
                      <>
                        {" · "}
                        {emj.lbPerFoot.toFixed(3)} lb/ft
                      </>
                    ) : null}
                    {unitFromBook ? (
                      <>
                        {" · "}
                        <strong>{unitFromBook.label}</strong>
                      </>
                    ) : null}
                  </p>
                  {emj.stockCost > 0 ? (
                    <p className="text-sm leading-snug">
                      {emj.totalLb} lb
                      {emj.lengthFt > 0
                        ? ` × ${emj.lengthFt.toFixed(2)} ft`
                        : ""}
                      {" = "}
                      <strong>{formatCurrency(emj.stockCost)}</strong> stock
                    </p>
                  ) : null}
                  <p className="text-[11px] text-[var(--color-subtle)]">
                    {emj.formula}
                  </p>
                  {unitFromBook && unitFromBook.costPerUnit > 0 ? (
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      onClick={() => {
                        setMatForm((f) => ({
                          ...f,
                          costPerUnit: unitFromBook.costPerUnit,
                        }));
                        toast.success(`Cost / unit set to ${unitFromBook.label}`);
                      }}
                    >
                      Use as cost / unit
                    </Button>
                  ) : null}
                </>
              ) : bookRow ? (
                <>
                  <p className="text-sm leading-snug">
                    <strong>{bookRow.grade}</strong>
                    {" · book "}
                    {formatCurrency(bookRow.pricePerLb)}/lb
                  </p>
                  <p className="text-[11px] text-[var(--color-subtle)]">
                    {emj.error ||
                      "Add a size (e.g. 3\" dia) so we can compute $/inch."}
                  </p>
                  {unitFromBook && unitFromBook.costPerUnit > 0 ? (
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      onClick={() => {
                        setMatForm((f) => ({
                          ...f,
                          costPerUnit: unitFromBook.costPerUnit,
                        }));
                        toast.success(`Cost / unit set to ${unitFromBook.label}`);
                      }}
                    >
                      Use as cost / unit
                    </Button>
                  ) : null}
                </>
              ) : (
                <p className="text-sm text-[var(--color-muted)]">
                  {emj.error ||
                    "Set material, type, shape, and size to estimate from the price book."}
                </p>
              )}
            </div>
          </div>
          )}
          <div className="space-y-1.5 sm:col-span-2 lg:col-span-3">
            <Label>Notes</Label>
            <Input
              value={matForm.notes}
              onChange={(e) =>
                setMatForm((f) => ({ ...f, notes: e.target.value }))
              }
            />
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button onClick={saveMaterial}>
            <Plus className="h-4 w-4" />
            {editingMatId ? "Save material" : "Add material"}
          </Button>
          {editingMatId && (
            <Button
              variant="ghost"
              onClick={() => {
                setEditingMatId(null);
                setMatForm(emptyMaterial({ id: "" }));
              }}
            >
              Cancel edit
            </Button>
          )}
        </div>
      </CardContent>
    </Card>

    <Card>
      <CardHeader className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <CardTitle>
              Material on hand ({filteredMat.length}
              {matFilterActiveCount > 0 && totalMatCount !== filteredMat.length
                ? ` of ${totalMatCount}`
                : ""}
              )
            </CardTitle>
            <CardDescription className="mt-1">
              Filter by column or search — 4×2 finds 2×4. Odd leftover like 1.6" is the cut (LOC), not the bar.
            </CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {matFilterActiveCount > 0 && (
              <Badge tone="info">{matFilterActiveCount} filter{matFilterActiveCount === 1 ? "" : "s"}</Badge>
            )}
            <Button
              type="button"
              variant={matFilters.lowOnly ? "secondary" : "outline"}
              size="sm"
              onClick={() =>
                patchFilter(setMatFilters, "lowOnly", !matFilters.lowOnly)
              }
            >
              <AlertTriangle className="h-4 w-4" />
              Low only
            </Button>
            {matFilterActiveCount > 0 && (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={clearMatFilters}
              >
                <X className="h-4 w-4" />
                Clear filters
              </Button>
            )}
          </div>
        </div>

        {/* Search + column filters */}
        <div className="space-y-2 rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)]/40 p-3">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 z-10 h-4 w-4 -translate-y-1/2 text-[var(--color-muted)]" />
            <div className="pl-9">
              <Typeahead
                value={matFilters.search}
                options={matFilterOptions.searchHints}
                allowCustom
                maxSuggestions={50}
                placeholder="Search material, size, location, vendor…"
                emptyMessage="No matches in stock — keep typing"
                onChange={(v) => patchFilter(setMatFilters, "search", v)}
              />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-2">
            <div className="space-y-1">
              <Label>Material</Label>
              <Typeahead
                value={matFilters.material}
                options={matFilterOptions.materials}
                allowCustom
                maxSuggestions={40}
                placeholder="All materials"
                emptyMessage="No material matches"
                onChange={(v) => {
                  setMatFilters((f) => ({
                    ...f,
                    material: v,
                    // reset type when material filter changes
                    ...(v !== f.material ? { materialType: "" } : {}),
                  }));
                }}
              />
            </div>
            <div className="space-y-1">
              <Label>Type / grade</Label>
              <Typeahead
                value={matFilters.materialType}
                options={matFilterOptions.materialTypes}
                allowCustom
                maxSuggestions={40}
                placeholder="All types"
                emptyMessage="No type matches"
                onChange={(v) => patchFilter(setMatFilters, "materialType", v)}
              />
            </div>
            <div className="space-y-1">
              <Label>Shape</Label>
              <Typeahead
                value={matFilters.stockShape}
                options={matFilterOptions.stockShapes}
                allowCustom
                maxSuggestions={40}
                placeholder="All shapes"
                emptyMessage="No shape matches"
                onChange={(v) => patchFilter(setMatFilters, "stockShape", v)}
              />
            </div>
            <div className="space-y-1">
              <Label>Size</Label>
              <Typeahead
                value={matFilters.sizeNote}
                options={matFilterOptions.sizeNotes}
                allowCustom
                maxSuggestions={60}
                placeholder='All sizes — try .75 or 3/4"'
                emptyMessage="No size matches"
                onChange={(v) => patchFilter(setMatFilters, "sizeNote", v)}
              />
            </div>
            <div className="space-y-1">
              <Label>Location</Label>
              <Typeahead
                value={matFilters.location}
                options={matFilterOptions.locations}
                allowCustom
                maxSuggestions={40}
                placeholder="All locations"
                emptyMessage="No location matches"
                onChange={(v) => patchFilter(setMatFilters, "location", v)}
              />
            </div>
            <div className="space-y-1">
              <Label>Vendor</Label>
              <Typeahead
                value={matFilters.vendor}
                options={matFilterOptions.vendors}
                allowCustom
                maxSuggestions={40}
                placeholder="All vendors"
                emptyMessage="No vendor matches"
                onChange={(v) => patchFilter(setMatFilters, "vendor", v)}
              />
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="overflow-x-auto">
        <table className="w-full text-sm min-w-[900px]">
          <thead>
            <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
              <th className="pb-2 font-medium">Material</th>
              <th className="pb-2 font-medium">Size</th>
              <th className="pb-2 font-medium">On hand</th>
              <th className="pb-2 font-medium">Min</th>
              <th className="pb-2 font-medium">Location</th>
              {canSeeMoney && <th className="pb-2 font-medium">Value</th>}
              <th className="pb-2 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredMat.map((m) => {
              const low = isLowStock(m.onHand, m.minQty);
              const qStatus = inventoryQtyStatus(m.onHand, m.minQty);
              return (
                <tr
                  key={m.id}
                  className={
                    "border-b border-[var(--color-border)]/60 " +
                    (qStatus === "danger"
                      ? "bg-[color-mix(in_oklab,var(--color-status-danger)_7%,transparent)]"
                      : qStatus === "hold"
                        ? "bg-[color-mix(in_oklab,var(--color-status-hold)_7%,transparent)]"
                        : "")
                  }
                >
                  <td className="py-2.5 pr-2">
                    <div className="font-medium">
                      {m.material}{" "}
                      {m.materialType && (
                        <span className="text-[var(--color-muted)] font-normal">
                          {m.materialType}
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-[var(--color-muted)]">
                      {m.stockShape}
                      {m.vendor ? ` · ${m.vendor}` : ""}
                    </div>
                  </td>
                  <td className="py-2.5 pr-2 text-[var(--color-muted)]">
                    {m.sizeNote || "—"}
                  </td>
                  <td className="py-2.5 pr-2 tabular">
                    <span
                      className={
                        low ? "text-[var(--color-warn)] font-semibold" : ""
                      }
                    >
                      {m.onHand} {m.unit}
                    </span>
                    {qStatus === "danger" && (
                      <Badge tone="danger" className="ml-2">
                        Out
                      </Badge>
                    )}
                    {qStatus === "hold" && (
                      <Badge tone="hold" className="ml-2">
                        Low
                      </Badge>
                    )}
                  </td>
                  <td className="py-2.5 pr-2 tabular text-[var(--color-muted)]">
                    {m.minQty}
                  </td>
                  <td className="py-2.5 pr-2">{m.location || "—"}</td>
                  {canSeeMoney && (
                  <td className="py-2.5 pr-2 tabular">
                    <div>{formatCurrency(m.onHand * (m.costPerUnit || 0))}</div>
                    <div className="text-[10px] text-[var(--color-subtle)]">
                      {m.costPerUnit
                        ? `${formatCurrency(m.costPerUnit)}/${m.unit}`
                        : "no unit cost"}
                    </div>
                  </td>
                  )}
                  <td className="py-2.5">
                    <div className="flex flex-wrap gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          openMove(
                            "material",
                            m.id,
                            materialLabel(m),
                            "receive",
                          )
                        }
                      >
                        <ArrowDownToLine className="h-3.5 w-3.5" />
                        In
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          openMove(
                            "material",
                            m.id,
                            materialLabel(m),
                            "issue",
                          )
                        }
                      >
                        <ArrowUpFromLine className="h-3.5 w-3.5" />
                        Out
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() =>
                          openMove(
                            "material",
                            m.id,
                            materialLabel(m),
                            "adjust",
                          )
                        }
                      >
                        <SlidersHorizontal className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => editMaterial(m)}
                      >
                        Edit
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        aria-label="Delete material line"
                        title="Delete this stock line"
                        onClick={() =>
                          setDeleteTarget({
                            kind: "material",
                            id: m.id,
                            label: materialLabel(m),
                          })
                        }
                      >
                        <Trash2 className="h-4 w-4 text-[var(--color-danger)]" />
                      </Button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {filteredMat.length === 0 && (
              <tr>
                <td
                  colSpan={7}
                  className="py-8 text-center text-[var(--color-muted)]"
                >
                  {totalMatCount === 0
                    ? "No material stock yet — add a line above."
                    : "No lines match these filters — clear filters or adjust search."}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </CardContent>
    </Card>
  </>
  );
}
