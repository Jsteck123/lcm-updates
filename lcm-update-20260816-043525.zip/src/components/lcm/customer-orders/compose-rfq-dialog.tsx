import { useMemo, useState } from "react";
import { FileText, Plus, Send, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import { SmartNumberInput } from "@/components/ui/smart-number-input";
import type { LineFileRef, VendorRfq, VendorRfqLine } from "@/lib/lcm/types";
import {
  downloadRfqDrawings,
  emptyVendorRfqLine,
  rfqEmailBody,
} from "@/lib/lcm/vendor-rfq";
import { openPoAttachment } from "@/lib/lcm/open-attachment";
import { MaterialGuideField } from "@/components/lcm/guided-material-form";
import { INVENTORY_UNITS } from "@/lib/lcm/inventory";

export function ComposeRfqDialog({
  company,
  rfqNumber,
  vendorOptions,
  initialVendors,
  initialLines,
  onCancel,
  onSend,
}: {
  company: string;
  rfqNumber: string;
  vendorOptions: string[];
  initialVendors: string[];
  initialLines: VendorRfqLine[];
  onCancel: () => void;
  onSend: (opts: { vendors: string[]; lines: VendorRfqLine[] }) => void;
}) {
  const [picked, setPicked] = useState<string[]>(
    initialVendors.length ? initialVendors : vendorOptions,
  );
  const [extraVendors, setExtraVendors] = useState<string[]>([]);
  const [newVendor, setNewVendor] = useState("");
  const [lines, setLines] = useState<VendorRfqLine[]>(
    initialLines.length ? initialLines : [emptyVendorRfqLine()],
  );
  const [sending, setSending] = useState(false);

  const allVendors = useMemo(() => {
    const set = new Set(
      [...vendorOptions, ...extraVendors].map((v) => v.trim()).filter(Boolean),
    );
    return [...set].sort((a, b) => a.localeCompare(b));
  }, [vendorOptions, extraVendors]);

  const draft: VendorRfq = {
    id: "",
    rfqNumber,
    date: new Date().toISOString().slice(0, 10),
    neededBy: "",
    status: "draft",
    customerQuoteRef: "",
    shopOrderRef: "",
    notes: "",
    lines,
    vendorsRequested: picked,
    bids: [],
    awardedBidId: "",
    purchaseOrderId: "",
    createdAt: "",
    updatedAt: "",
    createdBy: "",
  };
  const preview = rfqEmailBody({ companyName: company, rfq: draft });
  const drawingCount = lines.reduce(
    (n, l) => n + (l.drawings?.length || 0),
    0,
  );

  function patchLine(id: string, patch: Partial<VendorRfqLine>) {
    setLines((prev) => prev.map((l) => (l.id === id ? { ...l, ...patch } : l)));
  }

  function toggleVendor(name: string) {
    setPicked((prev) =>
      prev.includes(name) ? prev.filter((v) => v !== name) : [...prev, name],
    );
  }

  function addVendor() {
    const name = newVendor.trim();
    if (!name) return;
    setExtraVendors((prev) => (prev.includes(name) ? prev : [...prev, name]));
    setPicked((prev) => (prev.includes(name) ? prev : [...prev, name]));
    setNewVendor("");
  }

  function dropDrawing(lineId: string, fileId: string) {
    setLines((prev) =>
      prev.map((l) =>
        l.id === lineId
          ? { ...l, drawings: (l.drawings || []).filter((d) => d.id !== fileId) }
          : l,
      ),
    );
  }

  async function addDrawingFiles(lineId: string, files: File[]) {
    const { fileToBase64 } = await import("@/lib/lcm/po-import");
    const { savePoAttachment } = await import("@/lib/lcm/po-files-api");
    const { getShopToken } = await import("@/lib/lcm/shop-sync");
    const added: LineFileRef[] = [];
    for (const f of files) {
      const b64 = await fileToBase64(f);
      const saved = await savePoAttachment({
        data: {
          name: f.name,
          mime: f.type || "application/octet-stream",
          base64: b64,
          token: getShopToken() || undefined,
        },
      });
      if (!saved.ok) {
        toast.error(saved.error || `Could not add ${f.name}`);
        continue;
      }
      added.push({
        id: saved.meta.id,
        name: saved.meta.name,
        mime: saved.meta.mime,
      });
    }
    if (!added.length) return;
    setLines((prev) =>
      prev.map((l) =>
        l.id === lineId
          ? { ...l, drawings: [...(l.drawings || []), ...added] }
          : l,
      ),
    );
  }

  return (
    <div
      className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-black/60 p-4 print:hidden"
      onClick={onCancel}
    >
      <div
        className="relative z-[71] w-full max-w-2xl max-h-[92vh] overflow-y-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 space-y-4 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div>
          <h2 className="text-lg font-semibold">Send RFQ · {rfqNumber}</h2>
          <p className="text-sm text-[var(--color-muted)]">
            Pick vendors, fix the lines, attach prints. Email stays plain —
            drawings download so you can drop them on the mail.
          </p>
        </div>

        <div className="space-y-2">
          <Label>Vendors</Label>
          {allVendors.length === 0 && (
            <p className="text-sm text-[var(--color-muted)]">
              No vendors on file yet — type one below.
            </p>
          )}
          <div className="flex flex-wrap gap-2">
            {allVendors.map((name) => {
              const on = picked.includes(name);
              return (
                <button
                  key={name}
                  type="button"
                  onClick={() => toggleVendor(name)}
                  className={
                    "min-h-10 rounded-md border px-3 text-sm " +
                    (on
                      ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_18%,transparent)] text-[var(--color-fg)]"
                      : "border-[var(--color-border)] text-[var(--color-muted)]")
                  }
                >
                  {on ? "✓ " : ""}
                  {name}
                </button>
              );
            })}
          </div>
          <div className="flex gap-2">
            <Input
              value={newVendor}
              placeholder="Add a vendor"
              onChange={(e) => setNewVendor(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  addVendor();
                }
              }}
            />
            <Button type="button" variant="secondary" onClick={addVendor}>
              <Plus className="h-4 w-4" />
              Add
            </Button>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between gap-2">
            <Label>Lines</Label>
            <Button
              type="button"
              variant="ghost"
              onClick={() =>
                setLines((prev) => [...prev, emptyVendorRfqLine()])
              }
            >
              <Plus className="h-4 w-4" />
              Line
            </Button>
          </div>
          <div className="space-y-3">
            {lines.map((l, i) => (
              <div
                key={l.id}
                className="rounded-md border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-2"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-[var(--color-muted)]">
                    {i + 1}.
                  </span>
                  {lines.length > 1 && (
                    <button
                      type="button"
                      className="text-[var(--color-muted)] hover:text-[var(--color-danger)]"
                      title="Remove line"
                      onClick={() =>
                        setLines((prev) => prev.filter((x) => x.id !== l.id))
                      }
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
                <div className="grid sm:grid-cols-2 gap-2">
                  <div className="sm:col-span-2">
                    <MaterialGuideField
                      title={`Stock for line ${i + 1}`}
                      stock={l}
                      autoOpen={!l.material && !l.sizeNote}
                      onApply={(next) =>
                        patchLine(l.id, {
                          material: next.material,
                          materialType: next.materialType,
                          stockShape: next.stockShape,
                          sizeNote: next.sizeNote,
                          lengthEach: next.lengthEach,
                        })
                      }
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-[10px]">Qty</Label>
                    <SmartNumberInput
                      value={l.qty}
                      onValueChange={(qty) => patchLine(l.id, { qty })}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-[10px]">Unit</Label>
                    <Select
                      value={l.unit}
                      onChange={(e) =>
                        patchLine(l.id, {
                          unit: e.target.value as VendorRfqLine["unit"],
                        })
                      }
                    >
                      {INVENTORY_UNITS.map((u) => (
                        <option key={u} value={u}>
                          {u}
                        </option>
                      ))}
                    </Select>
                  </div>
                  <div className="space-y-1 sm:col-span-2">
                    <Label className="text-[10px]">Part</Label>
                    <Input
                      value={l.partNumber}
                      onChange={(e) =>
                        patchLine(l.id, { partNumber: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-1 sm:col-span-2">
                    <Label className="text-[10px]">Note</Label>
                    <Input
                      value={l.notes}
                      onChange={(e) =>
                        patchLine(l.id, { notes: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-1 sm:col-span-2">
                    <Label className="text-[10px]">Drawings</Label>
                    <div className="flex flex-wrap items-center gap-2">
                      {(l.drawings || []).length === 0 && (
                        <span className="text-xs text-[var(--color-subtle)]">
                          None — add the print if the vendor needs it
                        </span>
                      )}
                      {(l.drawings || []).map((d) => (
                        <span
                          key={d.id}
                          className="inline-flex items-center gap-1 rounded border border-[var(--color-border)] px-1.5 py-0.5 text-xs"
                        >
                          <button
                            type="button"
                            className="text-[var(--color-primary)] underline inline-flex items-center gap-1 max-w-[12rem] truncate"
                            title={d.name}
                            onClick={async () => {
                              const r = await openPoAttachment({
                                id: d.id,
                                name: d.name,
                              });
                              if (!r.ok) toast.error(r.error || "Missing file");
                            }}
                          >
                            <FileText className="h-3.5 w-3.5 shrink-0" />
                            {d.name}
                          </button>
                          <button
                            type="button"
                            className="text-[var(--color-muted)] hover:text-[var(--color-danger)]"
                            title="Remove from RFQ"
                            onClick={() => dropDrawing(l.id, d.id)}
                          >
                            ×
                          </button>
                        </span>
                      ))}
                      <label className="text-xs underline text-[var(--color-muted)] cursor-pointer min-h-8 inline-flex items-center">
                        Add drawing
                        <input
                          type="file"
                          className="hidden"
                          multiple
                          accept=".pdf,image/*,.dxf,.dwg,.tif,.tiff"
                          onChange={async (e) => {
                            const files = Array.from(e.target.files || []);
                            e.target.value = "";
                            if (files.length) await addDrawingFiles(l.id, files);
                          }}
                        />
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-1">
          <Label>Email they will see</Label>
          <pre className="whitespace-pre-wrap rounded-md border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 text-sm font-sans text-[var(--color-fg)]">
            {preview}
          </pre>
        </div>

        <div className="flex flex-wrap justify-end gap-2">
          <Button variant="ghost" type="button" onClick={onCancel}>
            Cancel
          </Button>
          <Button
            type="button"
            disabled={sending}
            onClick={async () => {
              if (!picked.length) {
                toast.error("Pick at least one vendor");
                return;
              }
              const ready = lines.filter((l) => l.material.trim());
              if (!ready.length) {
                toast.error("Need at least one material line");
                return;
              }
              setSending(true);
              const files = ready.flatMap((l) => l.drawings || []);
              if (files.length) {
                const n = await downloadRfqDrawings(files);
                if (n)
                  toast.message(
                    `${n} drawing(s) downloading — drop them on the email`,
                  );
              }
              onSend({ vendors: picked, lines: ready });
              setSending(false);
            }}
          >
            <Send className="h-4 w-4" />
            {sending
              ? "Sending…"
              : drawingCount
                ? `Send RFQ + ${drawingCount} drawing${drawingCount === 1 ? "" : "s"}`
                : "Send RFQ"}
          </Button>
        </div>
      </div>
    </div>
  );
}
