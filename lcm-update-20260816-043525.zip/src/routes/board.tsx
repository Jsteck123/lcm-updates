import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  Hand,
  Printer,
  Undo2,
  PackageCheck,
  FileText,
  Tag,
  Factory,
} from "lucide-react";
import { toast } from "sonner";
import { useLcmStore, getInProgressJobsForPart } from "@/store/lcm-store";
import { CutRequestDialog } from "@/components/lcm/cut-request-dialog";
import { ticketsForLine, statusLabel, qtyAvailable } from "@/lib/lcm/cut-tickets";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select } from "@/components/ui/input";
import { buildJobBoard } from "@/lib/lcm/job-board";
import { getOperatorByEmail } from "@/lib/lcm/permissions";
import { allMachines, normalizeCustomLists } from "@/lib/lcm/lists";
import { machineToSlug } from "@/lib/lcm/machines";
import {
  ShopWorkOrderSheet,
  ShippingWorkOrderSheet,
  ShipLabelSheet,
} from "@/components/lcm/work-order-print";
import { openPoAttachment } from "@/lib/lcm/open-attachment";
import { BoardCardArt } from "@/components/lcm/board-card-art";
import { findPairHint } from "@/lib/lcm/job-pair";
import { useEditorMode } from "@/hooks/use-editor-mode";
import { EditorHideButton, EditorReleaseButton } from "@/components/lcm/editor-remove";
import { PageHowTo } from "@/components/lcm/page-howto";
import { FloorPulseStrip, JobProgressStrip } from "@/components/lcm/floor-pulse";
import {
  findSessionForPart,
  jobProgressForPart,
} from "@/lib/lcm/floor-pulse";
import { cn } from "@/lib/utils";
import {
  boardCardStatus,
  dueUrgency,
  statusSurfaceClass,
  statusToBadgeTone,
} from "@/lib/lcm/status-colors";

function poDueLabel(raw: string) {
  if (!raw) return "no due";
  const iso = String(raw).trim().slice(0, 10);
  if (/^\d{4}-\d{2}-\d{2}$/.test(iso)) {
    const [y, m, d] = iso.split("-").map(Number);
    return new Date(y, (m || 1) - 1, d || 1).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    });
  }
  const dt = new Date(raw);
  if (Number.isNaN(dt.getTime())) return raw;
  return dt.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export const Route = createFileRoute("/board")({
  component: JobBoardPage,
});

function JobBoardPage() {
  // Stable selectors only — never `|| []` or getCustomLists() in the selector
  // (those return new refs every call → infinite re-render).
  const shopOrders = useLcmStore((s) => s.shopOrders);
  const quotes = useLcmStore((s) => s.quotes);
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  const customLists = useLcmStore((s) => s.settings.customLists);
  const pull = useLcmStore((s) => s.pullJobBoardLine);
  const officeAssignPart = useLcmStore((s) => s.officeAssignPart);
  const loadJob = useLcmStore((s) => s.loadJobOnMachine);
  const setOperatorOnMachine = useLcmStore((s) => s.setOperatorOnMachine);
  const sessions = useLcmStore((s) => s.sessions);
  const activeTimers = useLcmStore((s) => s.activeTimers);
  const getLive = useLcmStore((s) => s.getLiveElapsedSeconds);
  const navigate = useNavigate();
  const cutTicketsRaw = useLcmStore((s) => s.cutTickets);
  const cutTickets = cutTicketsRaw || [];
  const [cutReq, setCutReq] = useState<null | {
    orderId: string;
    lineId: string;
    componentId?: string;
    machine?: string;
  }>(null);
  const ret = useLcmStore((s) => s.returnJobBoardLine);
  const ready = useLcmStore((s) => s.markLineReadyForPack);
  const adminCleanFloor = useLcmStore((s) => s.adminCleanFloor);

  const me = useMemo(
    () => getOperatorByEmail(operators, email),
    [operators, email],
  );
  const { editorMode } = useEditorMode(me?.role === "admin");
  const myName = me?.name || email.split("@")[0] || "User";
  const machines = useMemo(
    () => allMachines(normalizeCustomLists(customLists)),
    [customLists],
  );

  const [filter, setFilter] = useState<"all" | "available" | "mine">("all");
  const [machine, setMachine] = useState("");
  const [poOrderId, setPoOrderId] = useState("");
  const [print, setPrint] = useState<
    | null
    | { kind: "shop"; orderId: string; lineId: string }
    | { kind: "ship"; orderId: string }
    | { kind: "label"; orderId: string; lineId: string }
  >(null);
  const [, tick] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => tick((n) => n + 1), 2000);
    return () => window.clearInterval(id);
  }, []);

  const cards = useMemo(
    () => buildJobBoard(shopOrders || [], quotes || []),
    [shopOrders, quotes],
  );
  const poOptions = useMemo(() => {
    const openCount = new Map<string, number>();
    for (const c of cards) {
      openCount.set(c.orderId, (openCount.get(c.orderId) || 0) + 1);
    }
    return (shopOrders || [])
      .filter((o) => openCount.has(o.id))
      .map((o) => ({
        orderId: o.id,
        poNumber: o.poNumber || "(no PO)",
        dueDate: o.dueDate || o.dateRequired || "",
        customer: o.customer || "",
        openLines: openCount.get(o.id) || 0,
      }))
      .sort((a, b) =>
        (a.dueDate || "9999-12-31").localeCompare(b.dueDate || "9999-12-31"),
      );
  }, [shopOrders, cards]);
  const shown = useMemo(() => {
    return cards.filter((c) => {
      if (poOrderId && c.orderId !== poOrderId) return false;
      if (filter === "available")
        return !c.checkedOutBy && c.released && !c.waitOnOp;
      if (filter === "mine")
        return c.checkedOutBy.toLowerCase() === myName.toLowerCase();
      return true;
    });
  }, [cards, filter, myName, poOrderId]);

  const printOrder = useMemo(() => {
    if (!print) return null;
    return (shopOrders || []).find((o) => o.id === print.orderId) || null;
  }, [print, shopOrders]);

  const printLine = useMemo(() => {
    if (!print || print.kind === "ship" || !printOrder) return null;
    return printOrder.lines.find((l) => l.id === print.lineId) || null;
  }, [print, printOrder]);

  function doPrint() {
    window.setTimeout(() => window.print(), 50);
  }

  return (
    <div className="p-3 sm:p-5 space-y-4 max-w-[1400px] mx-auto">
      <div className="print:hidden flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
        <div>
        <h1 className="text-xl font-semibold">Job Board</h1>
        <p className="text-sm text-[var(--color-muted)] mt-0.5">
          Soonest due first. Assemblies: take <strong>component jobs</strong>{" "}
          (-02, -03…) first, finish each qty, then take the{" "}
          <strong>assembly job</strong> (-01) to bolt together → pack.
          Multi-machine parts (lathe then mill) show one card per OP — only
          the current OP is on Available. A mill job with several ops stays
          one card. The person on this OP can name who runs the next one.
        </p>
        <div className="flex flex-wrap gap-1.5 mt-2">
          <Badge tone="hold">Hold</Badge>
          <Badge tone="open">Open</Badge>
          <Badge tone="soon">Due soon</Badge>
          <Badge tone="overdue">Overdue</Badge>
          <Badge tone="active">My Job</Badge>
          <span className="text-[10px] text-[var(--color-muted)] self-center">
            Soft tints · same colors system-wide
          </span>
        </div>
        </div>
        <PageHowTo id="job-board" />
      </div>

      <FloorPulseStrip className="print:hidden" />

      <div className="flex flex-wrap gap-2 items-center print:hidden">
        <Select
          className="h-9 w-auto"
          value={filter}
          onChange={(e) => setFilter(e.target.value as typeof filter)}
        >
          <option value="all">All Jobs</option>
          <option value="available">Available Jobs</option>
          <option value="mine">My Jobs</option>
        </Select>
        <Select
          className="h-9 w-auto min-w-[8rem]"
          value={machine}
          onChange={(e) => setMachine(e.target.value)}
        >
          <option value="">Machine (optional)</option>
          {machines.map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </Select>
        <Select
          className="h-9 w-auto min-w-[12rem] max-w-[min(100%,22rem)]"
          value={poOrderId}
          onChange={(e) => setPoOrderId(e.target.value)}
        >
          <option value="">All POs</option>
          {poOptions.map((p) => (
            <option key={p.orderId} value={p.orderId}>
              {p.poNumber} · due {poDueLabel(p.dueDate)}
              {p.customer ? ` · ${p.customer}` : ""} · {p.openLines} left
            </option>
          ))}
        </Select>
        <span className="text-xs text-[var(--color-muted)]">
          {shown.length} line(s)
          {poOrderId
            ? ` on this PO · soonest due first`
            : " · not released until office checks PDF rev + stock"}
        </span>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 print:hidden">
        {shown.map((c) => {
          const mine =
            Boolean(c.checkedOutBy) &&
            c.checkedOutBy.toLowerCase() === myName.toLowerCase();
          return (
            <Card
              key={`${c.orderId}-${c.lineId}-${c.componentId || "line"}-op${c.opIndex ?? "all"}`}
              className={cn(
                "relative overflow-hidden border",
                statusSurfaceClass(
                  boardCardStatus({
                    released: c.released,
                    checkedOutBy: c.checkedOutBy,
                    myName,
                    dueDate: c.dueDate,
                  }),
                ),
                c.checkedOutBy && !mine && "status-dim",
                mine &&
                  "ring-1 ring-[color-mix(in_oklab,var(--color-status-active)_45%,transparent)]",
              )}
            >
              <BoardCardArt
                fileId={c.drawings?.[0]?.id || c.drawingId || ""}
                name={c.drawings?.[0]?.name || ""}
              />
              <CardHeader className="relative z-10 pb-2 space-y-1">
                <div className="flex justify-between gap-2">
                  <CardTitle className="text-sm font-mono board-card-ink">
                    {c.poNumber}
                  </CardTitle>
                  <Badge
                    tone={statusToBadgeTone(
                      boardCardStatus({
                        released: c.released,
                        checkedOutBy: c.checkedOutBy,
                        myName,
                        dueDate: c.dueDate,
                      }),
                    )}
                  >
                    {!c.released
                      ? c.kind === "assembly" && c.waitingOn?.length
                        ? "Wait components"
                        : "Hold"
                      : c.checkedOutBy
                        ? c.checkedOutBy
                        : dueUrgency(c.dueDate) === "overdue"
                          ? "Open · overdue"
                          : dueUrgency(c.dueDate) === "soon"
                            ? "Open · due soon"
                            : "Open"}
                  </Badge>
                </div>
                <CardDescription className="text-xs board-card-ink">
                  Due {c.dueDate} · {c.customer}
                </CardDescription>
              </CardHeader>
              <CardContent className="relative z-10 space-y-2 text-sm">
                <div>
                  <div className="flex flex-wrap items-center gap-1.5 mb-0.5">
                    {c.kind === "component" && (
                      <Badge tone="open" className="text-[9px] px-1.5 py-0">
                        Component
                      </Badge>
                    )}
                    {c.kind === "assembly" && (
                      <Badge tone="office" className="text-[9px] px-1.5 py-0">
                        Assembly
                      </Badge>
                    )}
                    {c.opLabel ? (
                      <Badge tone="info" className="text-[9px] px-1.5 py-0">
                        {c.opLabel}
                      </Badge>
                    ) : null}
                    {c.quotedMachine ? (
                      <Badge tone="neutral" className="text-[9px] px-1.5 py-0">
                        {c.quotedMachine}
                      </Badge>
                    ) : null}
                    {c.waitOnOp ? (
                      <Badge tone="warn" className="text-[9px] px-1.5 py-0">
                        Wait {c.waitOnOp}
                      </Badge>
                    ) : null}
                    {c.parentPartNumber ? (
                      <span className="text-[10px] text-[var(--color-muted)]">
                        of {c.parentPartNumber}
                      </span>
                    ) : null}
                  </div>
                  <div className="font-mono font-semibold text-base board-card-ink">
                    {c.partNumber}{" "}
                    <span className="text-xs font-normal">
                      Rev {c.revision || "—"}
                    </span>
                  </div>
                  <div className="text-xs text-[var(--color-muted)] line-clamp-2 board-card-ink">
                    {c.description}
                  </div>
                  {c.kind === "assembly" && c.waitingOn?.length ? (
                    <div className="text-[10px] text-amber-300/95 mt-1">
                      Waiting on: {c.waitingOn.join(", ")}
                    </div>
                  ) : null}
                </div>
                <div className="text-xs">
                  Qty <strong>{c.qty}</strong>
                  {(c.material || c.sizeNote) && (
                    <span className="text-[var(--color-muted)]">
                      {" "}
                      · {c.material} {c.materialType} {c.sizeNote}
                    </span>
                  )}
                </div>
                {(() => {
                  const sess = findSessionForPart(sessions, c.partNumber);
                  if (!sess) return null;
                  const live = getLive(sess.machine);
                  const pulse = jobProgressForPart(sess, live, c.partNumber);
                  return pulse ? (
                    <JobProgressStrip job={pulse} className="pt-0.5" />
                  ) : null;
                })()}
                <div className="flex flex-wrap gap-1 text-[10px]">
                  <span>{c.revPdfOk ? "✓ PDF rev" : "○ PDF rev"}</span>
                  <span>{c.stockNoted ? "✓ Stock" : "○ Stock"}</span>
                  {(() => {
                    const tk = ticketsForLine(
                      cutTickets,
                      c.orderId,
                      c.lineId,
                      c.componentId || undefined,
                    ).filter((x) => x.status !== "cancelled");
                    if (!tk.length) return null;
                    const top = tk[0]!;
                    return (
                      <span>
                        ✂ {statusLabel(top.status)}
                        {top.qtyCut > 0
                          ? ` ${top.qtyCut}/${top.qtyRequested}`
                          : ""}
                        {qtyAvailable(top) > 0
                          ? ` · ${qtyAvailable(top)} ready`
                          : ""}
                      </span>
                    );
                  })()}
                  {(c.cadFiles?.length || c.cadFileId) ? (
                    <span>
                      {c.revCadOk ? "✓ CAD" : "○ CAD"}
                      {c.cadFiles && c.cadFiles.length > 1
                        ? ` ×${c.cadFiles.length}`
                        : ""}
                    </span>
                  ) : null}
                </div>
                {mine && c.nextOpIndex != null && (
                  <div className="space-y-1">
                    <div className="text-[10px] font-semibold uppercase tracking-wide text-[var(--color-muted)]">
                      Who does {c.nextOpLabel}?
                    </div>
                    {c.nextOpAssignedTo ? (
                      <p className="text-xs">
                        {c.nextOpAssignedTo}
                        <span className="text-[var(--color-muted)]">
                          {" "}
                          · already named
                        </span>
                      </p>
                    ) : (
                      <Select
                        className="h-9"
                        value=""
                        onChange={(e) => {
                          const who = e.target.value;
                          if (!who) return;
                          const r = officeAssignPart({
                            orderId: c.orderId,
                            lineId: c.lineId,
                            componentId: c.componentId || undefined,
                            operatorName: who,
                            machine: machine || c.quotedMachine,
                            notes: `Named by ${myName} from ${c.opLabel || "board"}`,
                            opIndex: c.nextOpIndex ?? undefined,
                          });
                          if (r.ok)
                            toast.success(
                              `${who} has ${c.partNumber} ${c.nextOpLabel}`,
                            );
                          else toast.error(r.error || "Could not assign");
                        }}
                      >
                        <option value="">Pick operator…</option>
                        {operators
                          .filter((o) => o.active)
                          .map((o) => (
                            <option key={o.id} value={o.name}>
                              {o.name}
                            </option>
                          ))}
                      </Select>
                    )}
                  </div>
                )}
                {c.waitOnOp && !c.checkedOutBy && (
                  <p className="text-[11px] text-[var(--color-muted)]">
                    Waits on {c.waitOnOp} — not on Available until that OP is
                    done.
                  </p>
                )}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {editorMode && (
                    <>
                      <EditorReleaseButton
                        onRelease={() => {
                          const r = adminCleanFloor({
                            orderId: c.orderId,
                            lineId: c.lineId,
                            componentId: c.componentId || undefined,
                            partNumber: c.partNumber,
                            mode: "release",
                            opIndex: c.opIndex ?? undefined,
                          });
                          if (r.ok) toast.success("Released — back on the board as open");
                          else toast.error(r.error || "Could not release");
                        }}
                      />
                      <EditorHideButton
                        onHide={() => {
                          const r = adminCleanFloor({
                            orderId: c.orderId,
                            lineId: c.lineId,
                            componentId: c.componentId || undefined,
                            partNumber: c.partNumber,
                            mode: "hide",
                          });
                          if (r.ok) toast.success("Removed from board and queues");
                          else toast.error(r.error || "Could not remove");
                        }}
                      />
                    </>
                  )}
                  {!c.checkedOutBy && c.released && !c.waitOnOp && (
                    <>
                    <Button
                      size="sm"
                      type="button"
                      onClick={() => {
                        const r = pull(
                          c.orderId,
                          c.lineId,
                          myName,
                          machine || c.quotedMachine,
                          c.componentId || undefined,
                          c.opIndex ?? undefined,
                        );
                        if (r.ok)
                          toast.success(
                            c.opLabel
                              ? `This is your job · ${c.partNumber} ${c.opLabel}`
                              : c.kind === "component"
                              ? `This is your job · ${c.partNumber}`
                              : c.kind === "assembly"
                                ? "This is your job — bolt together"
                                : "This is your job — this line only",
                          );
                        else toast.error(r.error || "Cannot take job");
                      }}
                    >
                      <Hand className="h-3.5 w-3.5" /> Take job
                    </Button>
                    {c.opIndex == null && (() => {
                      const hint = findPairHint(c.partNumber, {
                        quotes,
                        shopOrders: shopOrders || [],
                        preferQty: c.qty,
                        preferRev: c.revision,
                        preferCustomer: c.customer,
                      });
                      const sib = hint
                        ? shown.find(
                            (x) =>
                              x.partNumber.toUpperCase() ===
                                hint.partNumber.toUpperCase() &&
                              !x.checkedOutBy &&
                              x.released &&
                              x.opIndex == null,
                          )
                        : undefined;
                      if (!hint || !sib) return null;
                      return (
                        <Button
                          size="sm"
                          variant="secondary"
                          type="button"
                          onClick={() => {
                            const a = pull(
                              c.orderId,
                              c.lineId,
                              myName,
                              machine,
                              c.componentId || undefined,
                            );
                            const b = pull(
                              sib.orderId,
                              sib.lineId,
                              myName,
                              machine,
                              sib.componentId || undefined,
                            );
                            if (a.ok && b.ok)
                              toast.success(
                                `Pair is your jobs · ${c.partNumber} + ${sib.partNumber}`,
                              );
                            else
                              toast.error(
                                a.error || b.error || "Could not take pair",
                              );
                          }}
                        >
                          Take pair · {sib.partNumber}
                        </Button>
                      );
                    })()}
                    </>
                  )}
                  {mine && (
                    <>
                      <Button
                        size="sm"
                        type="button"
                        onClick={() => {
                          const target = (
                            c.checkedOutMachine ||
                            c.quotedMachine ||
                            machine
                          ).trim();
                          if (!target) {
                            toast.error(
                              "Pick a machine at the top, then Load",
                            );
                            return;
                          }
                          if (c.waitOnOp) {
                            toast.message(
                              `${c.opLabel || "This OP"} usually waits on ${c.waitOnOp} — you can still set up`,
                            );
                          }
                          const sess = sessions[target];
                          const timer = activeTimers[target];
                          if (
                            sess?.jobId &&
                            (sess.partNumber || "").toUpperCase() !==
                              (c.partNumber || "").toUpperCase()
                          ) {
                            toast.error(
                              `${target} already has ${sess.partNumber} loaded`,
                            );
                            return;
                          }
                          if (timer && sess?.partNumber !== c.partNumber) {
                            toast.error(
                              `Stop the timer on ${target} first`,
                            );
                            return;
                          }
                          if (myName) setOperatorOnMachine(target, myName);
                          if (
                            sess?.jobId &&
                            (sess.partNumber || "").toUpperCase() ===
                              (c.partNumber || "").toUpperCase() &&
                            c.opIndex == null
                          ) {
                            toast.message(
                              `${c.partNumber} is already on ${target}`,
                            );
                            void navigate({
                              to: "/machines/$machineId",
                              params: { machineId: machineToSlug(target) },
                            });
                            return;
                          }
                          const open = getInProgressJobsForPart(c.partNumber);
                          const r = loadJob(target, {
                            partNumber: c.partNumber,
                            revision: c.revision || "A",
                            quantity: c.qty || 1,
                            customer: c.customer,
                            existingJobId: sess?.jobId || open[0]?.id,
                            focusOpIndex: c.opIndex ?? undefined,
                          });
                          if (!r.ok) {
                            toast.error(r.error || "Could not load");
                            return;
                          }
                          toast.success(
                            `Loaded ${c.partNumber}${c.opLabel ? ` ${c.opLabel}` : ""} on ${target}`,
                          );
                          void navigate({
                            to: "/machines/$machineId",
                            params: { machineId: machineToSlug(target) },
                          });
                        }}
                      >
                        <Factory className="h-3.5 w-3.5" /> Load
                      </Button>
                      {c.opIndex == null && (() => {
                        const hint = findPairHint(c.partNumber, {
                          quotes,
                          shopOrders: shopOrders || [],
                          preferQty: c.qty,
                          preferRev: c.revision,
                          preferCustomer: c.customer,
                        });
                        if (!hint) return null;
                        return (
                          <Button
                            size="sm"
                            variant="secondary"
                            type="button"
                            onClick={() => {
                              const target = (
                                c.checkedOutMachine || machine
                              ).trim();
                              if (!target) {
                                toast.error(
                                  "Pick a machine at the top, then Load",
                                );
                                return;
                              }
                              if (myName) setOperatorOnMachine(target, myName);
                              const open = getInProgressJobsForPart(c.partNumber);
                              const pairOpen = getInProgressJobsForPart(
                                hint.partNumber,
                              );
                              const r = loadJob(target, {
                                partNumber: c.partNumber,
                                revision: c.revision || "A",
                                quantity: c.qty || 1,
                                customer: c.customer,
                                existingJobId: open[0]?.id,
                                pair: {
                                  partNumber: hint.partNumber,
                                  revision: hint.revision,
                                  quantity: hint.quantity || c.qty || 1,
                                  customer: hint.customer || c.customer,
                                  existingJobId: pairOpen[0]?.id,
                                },
                              });
                              if (!r.ok) {
                                toast.error(r.error || "Could not load pair");
                                return;
                              }
                              toast.success(
                                `Loaded pair ${c.partNumber} + ${hint.partNumber} on ${target}`,
                              );
                              void navigate({
                                to: "/machines/$machineId",
                                params: { machineId: machineToSlug(target) },
                              });
                            }}
                          >
                            Load pair
                          </Button>
                        );
                      })()}
                      <Button
                        size="sm"
                        variant="secondary"
                        type="button"
                        onClick={() =>
                          setCutReq({
                            orderId: c.orderId,
                            lineId: c.lineId,
                            componentId: c.componentId || undefined,
                            machine: c.checkedOutMachine || machine,
                          })
                        }
                      >
                        Request cut
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        type="button"
                        onClick={() => {
                          ret(
                            c.orderId,
                            c.lineId,
                            c.componentId || undefined,
                            c.opIndex ?? undefined,
                          );
                          toast.message(
                            c.opLabel
                              ? `${c.opLabel} returned to Available Jobs`
                              : "Returned to Available Jobs",
                          );
                        }}
                      >
                        <Undo2 className="h-3.5 w-3.5" /> Return job
                      </Button>
                      <Button
                        size="sm"
                        type="button"
                        onClick={() => {
                          const r = ready(
                            c.orderId,
                            c.lineId,
                            myName,
                            c.componentId || undefined,
                            c.opIndex ?? undefined,
                          );
                          if (r.ok)
                            toast.success(
                              c.opLabel && c.kind !== "component"
                                ? `${c.partNumber} ${c.opLabel} complete`
                                : c.kind === "component" && !c.opLabel
                                  ? `${c.partNumber} complete — next component or assembly`
                                  : c.kind === "component"
                                    ? `${c.partNumber} ${c.opLabel} complete`
                                    : "Ready for pack — packing can take it",
                            );
                          else toast.error(r.error || "Failed");
                        }}
                      >
                        <PackageCheck className="h-3.5 w-3.5" />{" "}
                        {c.opLabel
                          ? `Done ${c.opLabel}`
                          : c.kind === "component"
                            ? "Done component"
                            : "Done → pack"}
                      </Button>
                    </>
                  )}
                  <Button
                    size="sm"
                    variant="secondary"
                    type="button"
                    onClick={() => {
                      setPrint({
                        kind: "shop",
                        orderId: c.orderId,
                        lineId: c.lineId,
                      });
                      doPrint();
                    }}
                  >
                    <Printer className="h-3.5 w-3.5" /> Shop WO
                  </Button>
                  <Button
                    size="sm"
                    variant="secondary"
                    type="button"
                    onClick={() => {
                      setPrint({
                        kind: "label",
                        orderId: c.orderId,
                        lineId: c.lineId,
                      });
                      doPrint();
                    }}
                  >
                    <Tag className="h-3.5 w-3.5" /> Label
                  </Button>
                  {(c.drawings?.length
                    ? c.drawings
                    : c.drawingId
                      ? [{ id: c.drawingId, name: "drawing" }]
                      : []
                  ).map((d, i) => (
                    <Button
                      key={d.id}
                      size="sm"
                      variant="outline"
                      type="button"
                      onClick={async () => {
                        const r = await openPoAttachment({
                          id: d.id,
                          name: d.name || "drawing",
                        });
                        if (!r.ok) toast.error(r.error || "No drawing");
                      }}
                    >
                      <FileText className="h-3.5 w-3.5" />{" "}
                      {c.drawings && c.drawings.length > 1
                        ? `Draw ${i + 1}`
                        : "Drawing"}
                    </Button>
                  ))}
                  {(c.cadFiles || []).map((f, i) => (
                    <Button
                      key={f.id}
                      size="sm"
                      variant="outline"
                      type="button"
                      onClick={async () => {
                        const r = await openPoAttachment({
                          id: f.id,
                          name: f.name || "cad",
                        });
                        if (!r.ok) toast.error(r.error || "No CAD");
                      }}
                    >
                      <FileText className="h-3.5 w-3.5" />{" "}
                      {c.cadFiles.length > 1 ? `CAD ${i + 1}` : "CAD"}
                    </Button>
                  ))}
                </div>
                <Link
                  to="/po"
                  className="text-[10px] text-[var(--color-primary)]"
                >
                  Open full PO
                </Link>
              </CardContent>
            </Card>
          );
        })}
      </div>
      {shown.length === 0 && (
        <p className="text-sm text-[var(--color-muted)] text-center py-10 print:hidden">
          No lines on the board. Import POs, confirm rev/stock on Customer
          Orders, then lines appear here.
        </p>
      )}

      {/* Print surface */}
      <div id="lcm-board-print" className="hidden print:block">
        {print?.kind === "shop" && printOrder && printLine && (
          <ShopWorkOrderSheet order={printOrder} line={printLine} />
        )}
        {print?.kind === "ship" && printOrder && (
          <ShippingWorkOrderSheet order={printOrder} />
        )}
        {print?.kind === "label" && printOrder && printLine && (
          <div className="p-4">
            <ShipLabelSheet order={printOrder} line={printLine} />
          </div>
        )}
      </div>
      <style>{`
        @media print {
          body * { visibility: hidden !important; }
          #lcm-board-print, #lcm-board-print * { visibility: visible !important; }
          #lcm-board-print { position: absolute; left: 0; top: 0; width: 100%; display: block !important; }
        }
      `}</style>
      {cutReq && (
        <CutRequestDialog
          open={!!cutReq}
          onClose={() => setCutReq(null)}
          orderId={cutReq.orderId}
          lineId={cutReq.lineId}
          componentId={cutReq.componentId}
          byName={myName}
          machine={cutReq.machine}
        />
      )}
    </div>
  );
}
