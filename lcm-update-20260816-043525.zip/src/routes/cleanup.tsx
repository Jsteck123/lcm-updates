import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Check,
  ChevronDown,
  ClipboardList,
  Eraser,
  Info,
  Shield,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useLcmStore } from "@/store/lcm-store";
import { getOperatorByEmail } from "@/lib/lcm/permissions";
import { PageHowTo } from "@/components/lcm/page-howto";
import {
  cleanupKindLabel,
  scanBetaCleanup,
  type CleanupItem,
  type CleanupKind,
} from "@/lib/lcm/beta-cleanup";

export const Route = createFileRoute("/cleanup")({
  component: CleanupPage,
});

const KIND_ORDER: CleanupKind[] = [
  "open_clock",
  "open_downtime",
  "loaded_session",
  "settings",
  "packed_open",
  "over_complete",
  "dup_cut",
  "started_cell",
  "test_job",
  "stale_job",
  "stale_bonus",
  "odd_quote",
];

function CleanupPage() {
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  const me = getOperatorByEmail(operators, email);
  const isAdmin = me?.role === "admin";

  const operatorTimeLog = useLcmStore((s) => s.operatorTimeLog);
  const downtimes = useLcmStore((s) => s.downtimes);
  const activeTimers = useLcmStore((s) => s.activeTimers);
  const sessions = useLcmStore((s) => s.sessions);
  const jobs = useLcmStore((s) => s.jobs);
  const quotes = useLcmStore((s) => s.quotes);
  const shopOrders = useLcmStore((s) => s.shopOrders);
  const cutTickets = useLcmStore((s) => s.cutTickets);
  const dayBonuses = useLcmStore((s) => s.dayBonuses);
  const settings = useLcmStore((s) => s.settings);
  const applyBetaCleanup = useLcmStore((s) => s.applyBetaCleanup);
  const applyBookHygiene = useLcmStore((s) => s.applyBookHygiene);

  const items = useMemo(
    () =>
      scanBetaCleanup({
        operatorTimeLog,
        downtimes,
        activeTimers,
        sessions,
        jobs,
        quotes,
        shopOrders,
        cutTickets,
        dayBonuses,
        settings,
      }),
    [
      operatorTimeLog,
      downtimes,
      activeTimers,
      sessions,
      jobs,
      quotes,
      shopOrders,
      cutTickets,
      dayBonuses,
      settings,
    ],
  );
  const [picked, setPicked] = useState<Record<string, boolean>>({});
  const [openWhy, setOpenWhy] = useState<Record<string, boolean>>({});
  const [busy, setBusy] = useState(false);

  const grouped = useMemo(() => {
    const map = new Map<CleanupKind, CleanupItem[]>();
    for (const it of items) {
      const list = map.get(it.kind) || [];
      list.push(it);
      map.set(it.kind, list);
    }
    return KIND_ORDER.filter((k) => map.has(k)).map((k) => ({
      kind: k,
      items: map.get(k)!,
    }));
  }, [items]);

  const selected = items.filter((i) => picked[i.id]);

  function toggleKind(kind: CleanupKind, on: boolean) {
    const next = { ...picked };
    for (const it of items) {
      if (it.kind === kind) next[it.id] = on;
    }
    setPicked(next);
  }

  function run(list: CleanupItem[]) {
    if (!list.length) {
      toast.message("Pick one or more rows first");
      return;
    }
    setBusy(true);
    try {
      const r = applyBetaCleanup(list.map((i) => i.action));
      if (!r.ok) toast.error(r.error || "Could not apply");
      else toast.success(`Applied ${r.applied} cleanup action(s). Nothing was deleted.`);
      setPicked({});
    } finally {
      setBusy(false);
    }
  }

  if (!isAdmin) {
    return (
      <div className="mx-auto max-w-xl p-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Shield className="h-4 w-4" />
              Admin only
            </CardTitle>
            <CardDescription>
              Switch to James or Pam to review leftover beta data. Nothing here
              deletes records.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
      <div>
        <p className="text-xs uppercase tracking-wide text-[var(--color-muted)]">
          Settings · go-live
        </p>
        <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight mt-1">
          Beta cleanup desk
        </h1>
        <p className="text-sm text-[var(--color-muted)] mt-2 max-w-2xl leading-relaxed">
          Practice clocks, TEST jobs, and half-packed POs are normal while the
          shop is in beta. This desk lists them so you can close or correct
          each one. <strong>Nothing is deleted</strong> — jobs, quotes, and POs
          stay in history.
        </p>
      </div>
      <PageHowTo id="cleanup" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <ClipboardList className="h-4 w-4" />
            {items.length} item{items.length === 1 ? "" : "s"} to review
          </CardTitle>
          <CardDescription>
            Tick what you want to clean, then apply. Or apply one row at a time.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button
            type="button"
            disabled={busy || !selected.length}
            onClick={() => run(selected)}
          >
            <Eraser className="h-4 w-4" />
            Apply selected ({selected.length})
          </Button>
          <Button
            type="button"
            variant="outline"
            disabled={busy || !items.length}
            onClick={() => run(items)}
          >
            Apply all {items.length}
          </Button>
          <Button
            type="button"
            variant="outline"
            disabled={busy}
            onClick={() => {
              setBusy(true);
              try {
                const r = applyBookHygiene();
                if (!r.ok) toast.error("Could not clean the book");
                else if (!r.applied)
                  toast.message("Book already clean — no TEST leftovers or junk names");
                else toast.success(r.notes.join(" · ") || `Cleaned ${r.applied} item(s)`);
              } finally {
                setBusy(false);
              }
            }}
          >
            <Eraser className="h-4 w-4" />
            Clean TEST + junk names
          </Button>
          <Link
            to="/settings"
            className="inline-flex items-center justify-center gap-2 h-10 px-4 rounded-[var(--radius-md)] text-sm font-medium hover:bg-[var(--color-surface-2)] min-h-11"
          >
            Back to Settings
          </Link>
        </CardContent>
      </Card>

      {items.length === 0 && (
        <Card>
          <CardContent className="py-8 text-sm text-[var(--color-muted)]">
            Nothing leftover. Clocks are closed, TEST jobs are out of averages,
            and packed orders match completed qty.
          </CardContent>
        </Card>
      )}

      {grouped.map((g) => (
        <section key={g.kind} className="space-y-2">
          <div className="flex items-end justify-between gap-3">
            <h2 className="text-sm font-semibold">
              {cleanupKindLabel(g.kind)}
              <span className="ml-2 text-[var(--color-muted)] font-normal">
                {g.items.length}
              </span>
            </h2>
            <button
              type="button"
              className="text-xs text-[var(--color-primary)]"
              onClick={() =>
                toggleKind(
                  g.kind,
                  !g.items.every((i) => picked[i.id]),
                )
              }
            >
              {g.items.every((i) => picked[i.id]) ? "Unselect group" : "Select group"}
            </button>
          </div>
          <ul className="space-y-2">
            {g.items.map((it) => {
              const whyOpen = openWhy[it.id];
              return (
                <li
                  key={it.id}
                  className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface)] px-3 py-2.5"
                >
                  <div className="flex flex-col sm:flex-row sm:items-start gap-3">
                    <div className="flex items-start gap-3 min-w-0 flex-1">
                    <input
                      type="checkbox"
                      className="mt-1 h-4 w-4 shrink-0"
                      checked={!!picked[it.id]}
                      onChange={(e) =>
                        setPicked((p) => ({ ...p, [it.id]: e.target.checked }))
                      }
                      aria-label={it.title}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium leading-snug">
                        {it.title}
                      </div>
                      <div className="text-xs text-[var(--color-muted)] mt-0.5">
                        {it.detail}
                      </div>
                      <button
                        type="button"
                        className="mt-1 inline-flex items-center gap-1 text-xs text-[var(--color-primary)]"
                        onClick={() =>
                          setOpenWhy((w) => ({ ...w, [it.id]: !w[it.id] }))
                        }
                      >
                        <Info className="h-3 w-3" />
                        Why this matters
                        <ChevronDown
                          className={`h-3 w-3 transition-transform ${whyOpen ? "rotate-180" : ""}`}
                        />
                      </button>
                      {whyOpen && (
                        <p className="mt-1 text-sm text-[var(--color-fg)] leading-relaxed">
                          {it.why}
                        </p>
                      )}
                    </div>
                    </div>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      disabled={busy}
                      className="shrink-0 self-stretch sm:self-start"
                      onClick={() => run([it])}
                    >
                      <Check className="h-3.5 w-3.5" />
                      Apply
                    </Button>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
      ))}
    </div>
  );
}
