@echo off
REM Restart LCM on the shop host without a visible console.
REM Called from Settings → Restart LCM. Safe if the boot task also starts it.
setlocal EnableExtensions
cd /d "%~dp0..\.."

timeout /t 2 /nobreak >NUL

for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":8080.*LISTENING"') do (
  taskkill /F /PID %%P >NUL 2>&1
)
timeout /t 3 /nobreak >NUL

curl.exe -sf -o NUL --max-time 3 http://127.0.0.1:8080/ >NUL 2>&1
if %ERRORLEVEL%==0 (
  echo [lcm] already back up after stop
  exit /b 0
)

start "" /MIN "%~dp0start-host.cmd"
exit /b 0
