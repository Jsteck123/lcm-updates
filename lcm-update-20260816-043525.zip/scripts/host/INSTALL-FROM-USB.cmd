@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Lake Country Machine - Install from USB
echo.
echo ============================================
echo  LCM - Install / recover from this backup
echo ============================================
echo.
echo This copies LCM + shop data + prints onto this PC,
echo installs Node packages if needed, and starts the shop.
echo.

set "SRC=%~dp0"
if "%SRC:~-1%"=="\" set "SRC=%SRC:~0,-1%"

if not exist "%SRC%\package.json" (
  echo ERROR: package.json not found next to this script.
  echo Unzip the USB backup first, then run INSTALL-FROM-USB.cmd
  echo from inside that unzipped folder.
  pause
  exit /b 1
)

set "DEST=C:\LCM"
echo Source: %SRC%
echo Install to: %DEST%
echo.
echo Close LCM on this PC if it is running.
echo Press Ctrl+C to cancel, or
pause

echo.
echo [1/4] Stopping LCM on port 8080 (leaves other Node apps alone)...
for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":8080.*LISTENING"') do (
  taskkill /F /PID %%P >NUL 2>&1
)
timeout /t 2 /nobreak >NUL

echo [2/4] Copying app + shop data to %DEST% ...
if /I not "%SRC%"=="%DEST%" (
  if not exist "%DEST%" mkdir "%DEST%"
  robocopy "%SRC%" "%DEST%" /E /XD node_modules .git artifacts screenshots data\usb-backups data\logs data\updates /NFL /NDL /NJH /NJS /nc /ns
  if errorlevel 8 (
    echo COPY FAILED.
    pause
    exit /b 1
  )
) else (
  echo   Already running from %DEST% — skip copy.
)

cd /d "%DEST%"
if not exist "data\logs" mkdir "data\logs"
if not exist "data\backups" mkdir "data\backups"
if not exist "data\po-files" mkdir "data\po-files"
if not exist "data\branding" mkdir "data\branding"

echo [3/4] Checking Node.js...
where node >NUL 2>&1
if errorlevel 1 (
  echo.
  echo Node.js is not installed.
  echo 1^) Install Node.js LTS from https://nodejs.org
  echo 2^) Check "Add to PATH"
  echo 3^) Close this window, open a NEW one, run this script again.
  start https://nodejs.org
  pause
  exit /b 1
)

if not exist "node_modules\" (
  echo Installing packages — first time can take several minutes...
  call npm install
  if errorlevel 1 (
    echo npm install FAILED. See the error above.
    pause
    exit /b 1
  )
) else (
  echo   Packages already installed.
)

echo [4/4] Starting the shop...
echo.
echo When it is up, open:  http://127.0.0.1:8080
echo Leave the start window OPEN.
echo.

if exist "scripts\host\start-host.cmd" (
  call "scripts\host\start-host.cmd"
) else (
  set LCM_HMR=0
  call npm run dev -- --host 0.0.0.0 --port 8080
)

echo.
echo Done. If the window closed, double-click scripts\host\start-host.cmd
pause
