#!/usr/bin/env node
/**
 * One-shot live-book cleanup. Safe to re-run (idempotent).
 * Closes leftover TEST / qty-done clocks, merges junk customers,
 * normalizes a few machine names. Does not delete history.
 */
import fs from "node:fs";
import path from "node:path";

const ROOT = process.cwd();
const DATA = path.join(ROOT, "data", "lcm-shop.json");
const BACKUP_DIR = path.join(ROOT, "data", "backups");

const DROP = new Set(["2", "test"]);
const CUSTOMER_CANON = {
  "sat-lite": "Sat-Lite Technologies",
  "sat-lite technologies": "Sat-Lite Technologies",
  "kemp meek": "Kemp Meek",
  "kemp-meek": "Kemp Meek",
};
const MACHINE_ALIASES = {
  "haas lathe": "HAAS DS30Y LATHE",
  vf2: "HAAS VF2 MILL",
  vf4: "HAAS VF4 MILL",
  st35y: "HAAS ST-35Y LATHE",
  "st-35y": "HAAS ST-35Y LATHE",
  ds30y: "HAAS DS30Y LATHE",
  "ds-30y": "HAAS DS30Y LATHE",
};

function looksLikeTest(pn) {
  const u = String(pn || "").trim().toUpperCase();
  return (
    u === "TEST" ||
    u.startsWith("TEST ") ||
    u.startsWith("TEST-0293") ||
    u.startsWith("TET-0293")
  );
}

function canonCustomer(name) {
  const raw = String(name || "").trim();
  if (!raw) return "";
  return CUSTOMER_CANON[raw.toLowerCase()] || raw;
}

function canonMachine(name) {
  const raw = String(name || "").trim();
  if (!raw) return "";
  const alias = MACHINE_ALIASES[raw.toLowerCase()];
  return alias || raw;
}

function rewriteName(raw) {
  if (DROP.has(String(raw || "").trim().toLowerCase())) return "";
  return canonCustomer(raw);
}

function main() {
  if (!fs.existsSync(DATA)) {
    console.error("No data/lcm-shop.json");
    process.exit(1);
  }
  const snap = JSON.parse(fs.readFileSync(DATA, "utf8"));
  const state = snap.state;
  if (!state) {
    console.error("Invalid snapshot");
    process.exit(1);
  }

  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const pre = path.join(BACKUP_DIR, `backup-${stamp}.json`);
  fs.writeFileSync(
    pre,
    JSON.stringify({
      ...snap,
      backupMeta: {
        id: `backup-${stamp}`,
        createdAt: new Date().toISOString(),
        label: "pre-hygiene",
      },
    }),
  );

  const nowIso = new Date().toISOString();
  const report = {
    completedTestJobs: 0,
    completedQtyDoneJobs: 0,
    droppedCustomers: [],
    mergedCustomers: [],
    queueMachinesFixed: 0,
  };

  state.jobs = (state.jobs || []).map((j) => {
    let next = j;
    if (j.status === "In Progress") {
      if (looksLikeTest(j.partNumber)) {
        report.completedTestJobs += 1;
        next = {
          ...j,
          status: "Completed",
          endTime: j.endTime || nowIso,
          saveTime: j.saveTime || nowIso,
          pauseReason: j.pauseReason || "Beta leftover — TEST job closed",
          countInAverage: false,
        };
      } else {
        const qty = Number(j.quantity) || 0;
        const done = Number(j.quantityCompleted) || 0;
        if (qty > 0 && done >= qty) {
          report.completedQtyDoneJobs += 1;
          next = {
            ...j,
            status: "Completed",
            endTime: j.endTime || nowIso,
            saveTime: j.saveTime || nowIso,
            pauseReason:
              j.pauseReason || "Qty complete — closed leftover clock",
          };
        }
      }
    }
    const customer = rewriteName(next.customer);
    return customer === next.customer ? next : { ...next, customer };
  });

  const seen = new Map();
  for (const c of state.customers || []) {
    if (DROP.has(String(c.name || "").trim().toLowerCase())) {
      report.droppedCustomers.push(c.name);
      continue;
    }
    const name = canonCustomer(c.name);
    const key = name.toLowerCase();
    const prev = seen.get(key);
    if (prev) {
      report.mergedCustomers.push(`${c.name} → ${name}`);
      const emails = [
        ...new Set(
          [prev.email, c.email, ...(prev.emails || []), ...(c.emails || [])]
            .map((e) => String(e || "").trim())
            .filter(Boolean),
        ),
      ];
      const primary = emails[0] || "";
      seen.set(key, {
        ...prev,
        name,
        email: primary,
        emails: emails.filter((e) => e.toLowerCase() !== primary.toLowerCase()),
        lastEmailedAt: prev.lastEmailedAt || c.lastEmailedAt || null,
      });
      continue;
    }
    seen.set(key, { ...c, name });
  }
  state.customers = Array.from(seen.values());

  state.quotes = (state.quotes || []).map((q) => {
    const customer = rewriteName(q.customer);
    return customer === q.customer ? q : { ...q, customer };
  });
  state.shopOrders = (state.shopOrders || []).map((o) => {
    const customer = rewriteName(o.customer);
    return customer === o.customer ? o : { ...o, customer };
  });
  state.workQueue = (state.workQueue || []).map((row) => {
    const machine = canonMachine(row.machine);
    const customer = rewriteName(row.customer);
    if (machine === row.machine && customer === row.customer) return row;
    if (machine !== row.machine) report.queueMachinesFixed += 1;
    return { ...row, machine, customer, updatedAt: nowIso };
  });

  const notes = [];
  if (report.completedTestJobs)
    notes.push(`Closed ${report.completedTestJobs} TEST job(s)`);
  if (report.completedQtyDoneJobs)
    notes.push(`Closed ${report.completedQtyDoneJobs} qty-done leftover(s)`);
  if (report.droppedCustomers.length)
    notes.push(`Dropped ${report.droppedCustomers.join(", ")}`);
  if (report.mergedCustomers.length)
    notes.push(`Merged ${report.mergedCustomers.length} customer name(s)`);
  if (report.queueMachinesFixed)
    notes.push(`Fixed ${report.queueMachinesFixed} queue machine name(s)`);

  state.auditLog = [
    {
      id: `hygiene-${Date.now()}`,
      timestamp: nowIso,
      user: "system",
      action: "Book hygiene",
      details: notes.join(" · ") || "No changes",
    },
    ...(state.auditLog || []),
  ].slice(0, 500);

  snap.rev = Number(snap.rev || 0) + 1;
  snap.updatedAt = nowIso;
  snap.state = state;

  const tmp = `${DATA}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(snap));
  fs.renameSync(tmp, DATA);

  console.log("Hygiene applied. rev", snap.rev);
  console.log(JSON.stringify(report, null, 2));
  console.log("Pre-hygiene backup:", pre);
}

main();
