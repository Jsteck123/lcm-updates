import type { MaterialPriceEntry } from "./material-rates";

export const MACHINES = [
  "HAAS VF2 MILL",
  "HAAS VF4 MILL",
  "MAZAK 530C MILL",
  "HAAS ST-35Y LATHE",
  "MAZAK 250MY LATHE",
  "HAAS DS30Y LATHE",
  "LASER",
] as const;

export type MachineName = (typeof MACHINES)[number] | string;

export type Operation = `OP${number}`;

export type TimerType = "Setup" | "Runtime";

export type JobStatus = "In Progress" | "Completed" | "Downtime";

export type PauseReason =
  | "Shift Change"
  | "End of Shift"
  | "Machine Transfer"
  | "Lunch"
  | "Shop Help"
  | string;

export type AppTab =
  | "dashboard"
  | "machines"
  | "jobs"
  | "quoting"
  | "database"
  | "inventory"
  | "po"
  | "calendar"
  | "board"
  | "saw"
  | "email"
  | "reports"
  | "feedback"
  | "settings"
  | "active";

export type InventoryUnit = "pcs" | "in" | "ft" | "lbs" | "sheet" | "bar";

export type InventoryTxnType = "receive" | "issue" | "adjust" | "scrap" | "return";

/** Raw / stock material on the shelf */
export interface MaterialStock {
  id: string;
  material: string;
  materialType: string;
  stockShape: string;
  /** Free-form size note e.g. 1.5" dia x 12 ft */
  sizeNote: string;
  dimX: number;
  dimY: number;
  dimZ: number;
  unit: InventoryUnit;
  onHand: number;
  minQty: number;
  location: string;
  vendor: string;
  costPerUnit: number;
  notes: string;
  updatedAt: string;
}

/** Finished parts, hardware, inserts, bought-outs */
export interface PartStock {
  id: string;
  partNumber: string;
  revision: string;
  description: string;
  category: string;
  unit: InventoryUnit;
  onHand: number;
  minQty: number;
  location: string;
  vendor: string;
  costPerUnit: number;
  notes: string;
  updatedAt: string;
}

export interface InventoryTxn {
  id: string;
  at: string;
  by: string;
  kind: InventoryTxnType;
  itemKind: "material" | "part" | "piece";
  itemId: string;
  label: string;
  qty: number;
  balanceAfter: number;
  reason: string;
  ref: string;
}


/** Vendor material RFQ (request quotes before placing a material buy PO) */
export type VendorRfqStatus =
  | "draft"
  | "sent"
  | "quoted"
  | "awarded"
  | "cancelled";

export interface VendorRfqLine {
  id: string;
  material: string;
  materialType: string;
  stockShape: string;
  sizeNote: string;
  unit: InventoryUnit;
  qty: number;
  lengthEach: number;
  partNumber: string;
  jobRef: string;
  notes: string;
  /** Prints to send with this RFQ line */
  drawings?: LineFileRef[];
}

/** One vendor's bid against an RFQ (or a single line) */
export interface VendorBidLine {
  rfqLineId: string;
  unitCost: number;
  /** Optional lead time days for this line */
  leadDays: number;
  notes: string;
}

export interface VendorBid {
  id: string;
  vendor: string;
  /** Vendor's quote / estimate # if they gave one */
  vendorQuoteNumber: string;
  date: string;
  status: "open" | "accepted" | "rejected";
  lines: VendorBidLine[];
  notes: string;
  /** Freight / extras rolled into decision */
  freight: number;
  validUntil: string;
  createdAt: string;
}

export interface VendorRfq {
  id: string;
  /** Our RFQ # e.g. RFQ-26-0001 — attached on outgoing requests */
  rfqNumber: string;
  date: string;
  neededBy: string;
  status: VendorRfqStatus;
  /** Optional link to customer quote part #s or shop PO */
  customerQuoteRef: string;
  shopOrderRef: string;
  notes: string;
  lines: VendorRfqLine[];
  /** Vendors we sent the RFQ to (emails optional) */
  vendorsRequested: string[];
  bids: VendorBid[];
  /** Winning bid id after award */
  awardedBidId: string;
  /** Material buy PO created from award */
  purchaseOrderId: string;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
}

/** Vendor material buy (Inventory → Material buys) */
export type MaterialPoStatus =
  | "draft"
  | "ordered"
  | "partial"
  | "received"
  | "cancelled";

export type PoStatus = MaterialPoStatus;

export interface PoLine {
  id: string;
  material: string;
  materialType: string;
  stockShape: string;
  sizeNote: string;
  unit: InventoryUnit;
  qtyOrdered: number;
  qtyReceived: number;
  lengthEach: number;
  unitCost: number;
  partNumber: string;
  jobRef: string;
  notes: string;
}

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  vendor: string;
  date: string;
  status: MaterialPoStatus;
  notes: string;
  lines: PoLine[];
  createdAt: string;
  updatedAt: string;
  createdBy: string;
}

/** Customer shop order (PO tab) — work coming into the shop */
export type ShopOrderStatus =
  | "draft"
  | "open"
  | "in_progress"
  | "complete"
  | "cancelled";

export type ShopLineMaterialStatus = "ok" | "needs_attention" | "unchecked";
export type ShopLineMaterialMatch = "exact" | "part_only" | "none";

/**
 * File attached to a PO line (drawing or CAD).
 * relatedPartNumber set when file is for a child of an assembly (e.g. -02 under -01).
 */
export type LineFileRef = {
  id: string;
  name: string;
  mime: string;
  /** Child P/N when file belongs to assembly component */
  relatedPartNumber?: string;
};

/**
 * Piece of an assembly on a customer PO line.
 * Shop runs each component (e.g. -02, -03), then bolts the assembly (-01).
 */
export interface ShopLineComponent {
  id: string;
  partNumber: string;
  revision: string;
  description: string;
  /** Usually same as parent line qty (or BOM qty) */
  qty: number;
  drawings: LineFileRef[];
  cadFiles: LineFileRef[];
  checkedOutBy: string;
  checkedOutAt: string;
  checkedOutMachine: string;
  /** Office desk assignment (who should run this, before floor pull) */
  officeAssignedTo: string;
  officeAssignedMachine: string;
  officeAssignedAt: string;
  officeAssignNotes: string;
  /** Machining done for this component */
  complete: boolean;
  completedAt: string;
  completedBy: string;
  notes: string;
}

/** Active = on order; cancelled = dropped by a customer PO rev (kept for history). */
export type ShopLineStatus = "active" | "cancelled";

export interface ShopOrderLine {
  id: string;
  /** Line item # on the customer PO (1, 2, 3…) */
  itemNo: number;
  partNumber: string;
  description: string;
  revision: string;
  /** Unit price — office only; hidden from shop operators */
  unitCost: number;
  qty: number;
  qtyCompleted: number;
  units: string;
  taxable: boolean;
  notes: string;
  dueDate: string;
  /**
   * Drawing / print attachment (legacy primary — first of drawings[]).
   * Prefer drawings[] for assemblies with multiple prints.
   */
  drawingId: string;
  drawingName: string;
  drawingMime: string;
  /** All shop drawings/prints for this line (assembly may have several). */
  drawings: LineFileRef[];
  /** Material planning (from quote DB + inventory) */
  material: string;
  materialType: string;
  stockShape: string;
  materialVendor: string;
  materialNeeded: number;
  materialOnHand: number;
  materialStockId: string;
  materialLocation: string;
  finishedOnHand: number;
  finishedStockId: string;
  materialMatch: ShopLineMaterialMatch;
  materialStatus: ShopLineMaterialStatus;
  attentionReason: string;
  /** Office checked this line as planned / OK */
  materialReviewed: boolean;
  quoteId: string;
  /** Free-form size e.g. 1.5" dia x 12 ft */
  sizeNote: string;
  dimX: number;
  dimY: number;
  dimZ: number;
  partLengthEach: number;
  rawMaterialLength: number;
  /** Office: PDF rev matches PO */
  revPdfOk: boolean;
  /** Office: CAD / .x_t rev matches PO */
  revCadOk: boolean;
  /** Office: stock size noted for this line */
  stockNoted: boolean;
  /** Optional CAD solid (legacy primary — first of cadFiles[]). */
  cadFileId: string;
  cadFileName: string;
  cadFileMime: string;
  /** All CAD solids for this line (assembly-level only). */
  cadFiles: LineFileRef[];
  /**
   * Assembly children to machine separately (e.g. -02, -03 under -01).
   * Empty = simple part (one job on the board).
   */
  components: ShopLineComponent[];
  /**
   * Job board: who pulled THIS line only (rest of PO still available).
   * Empty = on the board for anyone.
   */
  checkedOutBy: string;
  checkedOutAt: string;
  checkedOutMachine: string;
  /** Office desk assignment (who should run this, before floor pull) */
  officeAssignedTo: string;
  officeAssignedMachine: string;
  officeAssignedAt: string;
  officeAssignNotes: string;
  /** Shop finished machining — packing can take it */
  readyForPack: boolean;
  readyForPackAt: string;
  readyForPackBy: string;
  /** Line fully packed (for multi-line POs) */
  linePacked: boolean;
  linePackedAt: string;
  linePackedBy: string;
  /**
   * active (default) or cancelled when customer PO rev drops the line.
   * Cancelled lines stay for history; job board / ship calendar ignore them.
   */
  lineStatus: ShopLineStatus;
  cancelledAt: string;
  cancelledReason: string;
}

export type WorkQueueStatus =
  | "queued"
  | "active"
  | "done"
  | "cancelled"
  | "held";

/** Planned work for a machine and/or operator, usually from a customer PO line */
export interface WorkQueueItem {
  id: string;
  shopOrderId: string;
  shopOrderLineId: string;
  poNumber: string;
  customer: string;
  partNumber: string;
  revision: string;
  description: string;
  qty: number;
  qtyCompleted: number;
  machine: string;
  operatorName: string;
  /** Lower = sooner in that machine's queue */
  sortOrder: number;
  status: WorkQueueStatus;
  notes: string;
  jobId: string | null;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
}


/** Mill / lathe process for a saw cut ticket */
export type CutProcess = "mill" | "lathe" | "other";

/** Which dimension is Length of Cut (mill: x/y/z · lathe: dia) */
export type LocAxis = "x" | "y" | "z" | "dia";

export type CutTicketStatus =
  | "requested"
  | "cutting"
  | "partial"
  | "done"
  | "skipped"
  | "cancelled";

/**
 * Floor cut order: quote size is estimate; CAD actuals + progressive qty.
 * Saw marks qtyCut in batches; machines claim available blanks without waiting for full qty.
 */
export interface CutTicket {
  id: string;
  shopOrderId: string;
  shopOrderLineId: string;
  /** Empty unless assembly component */
  componentId: string;
  poNumber: string;
  customer: string;
  partNumber: string;
  revision: string;
  material: string;
  materialType: string;
  stockShape: string;
  process: CutProcess;
  dimX: number;
  dimY: number;
  dimZ: number;
  /** Lathe OD (inches) */
  diameter: number;
  /** Which axis is LOC */
  locAxis: LocAxis;
  locValue: number;
  qtyRequested: number;
  /** Blanks the saw has finished (progressive) */
  qtyCut: number;
  /** Blanks claimed by mills/lathes */
  qtyClaimed: number;
  status: CutTicketStatus;
  requestedBy: string;
  requestedAt: string;
  requestedMachine: string;
  notes: string;
  sawOperator: string;
  completedAt: string;
  /** When true, completing cut may write dims back to quote recipe */
  writeBackToQuote: boolean;
  writtenBackAt: string;
  dueDate: string;
}

/** Prior customer PO PDF kept when order is revised A→B */
export type PriorPoFile = {
  id: string;
  name: string;
  mime: string;
  /** Document rev at the time this PDF was current (e.g. A) */
  poRevision: string;
  replacedAt: string;
};

export interface ShopOrder {
  id: string;
  /** Customer's PO number e.g. PO-26-X679 */
  poNumber: string;
  /**
   * Customer PO document revision. Blank on the original PO.
   * First customer revise is A, then B, C… (or 1, 2… if they number them).
   * Not the same as part drawing rev on each line.
   */
  poRevision: string;
  /** Our sales order # (for QuickBooks / paper SO) */
  soNumber: string;
  customer: string;
  /** Customer sold-from / header block */
  customerAddress: string;
  customerPhone: string;
  shipToName: string;
  shipToAddress: string;
  attn: string;
  buyer: string;
  techContact: string;
  account: string;
  dateRequired: string;
  fob: string;
  shippingMethod: string;
  terms: string;
  date: string;
  dueDate: string;
  rating: string;
  shippingAcct: string;
  status: ShopOrderStatus;
  notes: string;
  /** Footer reminder printed on paper POs */
  footerNote: string;
  lines: ShopOrderLine[];
  /** Original emailed PO file (PDF/image) stored on shop host */
  sourceFileId: string;
  sourceFileName: string;
  sourceFileMime: string;
  /** Previous PO PDFs after a customer rev (newest first) */
  priorPoFiles: PriorPoFile[];
  /**
   * Shipping / packing workflow (office calendar):
   * pending → shop packed on cart → office verified ready to load
   */
  packStatus: "pending" | "packed" | "verified";
  packedBy: string;
  packedAt: string;
  verifiedBy: string;
  verifiedAt: string;
  /** Delivery / office closeout */
  deliveredAt: string;
  deliveredBy: string;
  signedSlipFileId: string;
  signedSlipName: string;
  signedSlipMime: string;
  invoicedInQb: boolean;
  invoicedAt: string;
  paymentReceived: boolean;
  paymentReceivedAt: string;
  closedAt: string;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
}

/**
 * One physical finished part with a short sharpied UIN (unique ID).
 * Used for extras / second-quality so shelf pull can match defect notes.
 */
export interface PartUnit {
  id: string;
  /** Short code written on the part (e.g. K7M2) */
  uin: string;
  partNumber: string;
  revision: string;
  quality: "good" | "second";
  /** Required when quality is second */
  defectNote: string;
  location: string;
  status: "available" | "issued" | "scrapped";
  jobRef: string;
  stockedBy: string;
  stockedAt: string;
  notes: string;
}

/** One physical bar / sheet / piece with a printable barcode sticker */
export interface StockPiece {
  id: string;
  barcode: string;
  stockId: string;
  material: string;
  materialType: string;
  stockShape: string;
  sizeNote: string;
  originalLength: number;
  remainingLength: number;
  unit: InventoryUnit;
  location: string;
  status: "available" | "consumed";
  poId: string | null;
  poLineId: string | null;
  receivedAt: string;
  notes: string;
}

export type OperatorRole = "admin" | "operator";

export type QuoteKind = "part" | "assembly";

export interface Operator {
  id: string;
  name: string;
  email: string;
  active: boolean;
  role: OperatorRole;
  tabs: AppTab[];
  /**
   * On server: PBKDF2 hash (`v1$salt$hash`) or legacy plaintext until migrated.
   * On client after sync: masked (`••••`) — never a usable PIN.
   */
  pin: string;
  /** Client-only: whether a PIN is configured. */
  hasPin?: boolean;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  emails: string[];
  lastEmailedAt: string | null;
}

export interface PartNote {
  partNumber: string;
  notes: string;
}

export interface BomLine {
  partNumber: string;
  revision: string;
  qty: number;
  note: string;
}

/** Soft jaws, special tools, etc. — never folded into part price each. */
export type QuoteToolingKind = "soft_jaws" | "special_tool" | "other";

/**
 * Soft jaws / special tools: shop cost is always stored.
 * Optionally billed as a separate customer line (QTY + price each).
 * Never amortized into quote.prices.
 */
export interface QuoteToolingCharge {
  id: string;
  kind: QuoteToolingKind;
  /** Label on customer quote when billed (and in-shop). */
  description: string;
  /** What it costs the shop to make or buy. */
  shopCost: number;
  /** When true, appear as a separate line on the customer quote. */
  billCustomer: boolean;
  /** Line qty when billed (usually 1). */
  billQty: number;
  /** Customer unit price when billed (may differ from shopCost). */
  billUnitPrice: number;
  notes: string;
}

export interface Quote {
  id: string;
  date: string;
  customer: string;
  partNumber: string;
  revision: string;
  kind: QuoteKind;
  bom: BomLine[];
  benchAssembleMinutes: number;
  machines: string[];
  machineRate: number;
  material: string;
  materialType: string;
  materialPct: number;
  materialVendor: string;
  dimX: number;
  dimY: number;
  dimZ: number;
  rawMaterialLength: number;
  stockShape: string;
  rawMaterialCost: number;
  calculateMaterialDrop: boolean;
  dropMultiplier: number;
  partLengthEach: number;
  /** Live process recipe (updated from shop averages when jobs complete) */
  setupTimes: number[];
  runTimes: number[];
  /** Last computed shop averages (minutes) — informational */
  shopAvgSetupTimes?: number[];
  shopAvgRunTimes?: number[];
  shopAvgUpdatedAt?: string;
  shopAvgRunCount?: number;
  quantities: number[];
  prices: number[];
  /**
   * Soft jaws / special tools — stored for the shop.
   * Optional separate bill lines; never rolled into price each.
   */
  toolingCharges: QuoteToolingCharge[];
  /** Last locked/sent price snapshot id */
  lastSnapshotId?: string;
  qtyRun?: number;
  partEff?: number;
  operator?: string;
  partBonus?: number;
}

export interface JobRun {
  id: string;
  partNumber: string;
  startTime: string;
  endTime: string | null;
  setups: (number | "STARTED" | null)[];
  runtimes: (number | "STARTED" | null)[];
  quotedSetups: number[];
  quotedRuntimes: number[];
  status: JobStatus;
  saveTime: string | null;
  operator: string;
  efficiency: number;
  bonus: number;
  totalElapsed: number;
  actualTime: number;
  totalPaused: number;
  machine: string;
  revision: string;
  quantity: number;
  customer: string;
  pauseReason: string;
  machinesUsed: string[];
  quantityCompleted: number;
  /** When false, completed run is history-only and does not affect shop averages */
  countInAverage: boolean;
}

/** Frozen quote prices/times as sent or locked (requote evidence) */
export interface QuoteSnapshot {
  id: string;
  quoteId: string;
  partNumber: string;
  revision: string;
  customer: string;
  date: string;
  frozenAt: string;
  reason: "email" | "manual_lock" | "submit";
  quantities: number[];
  prices: number[];
  setupTimes: number[];
  runTimes: number[];
  /** Tooling charges frozen with this send/lock */
  toolingCharges: QuoteToolingCharge[];
  notes: string;
  emailedTo?: string;
}


/** Floor → office: time + notes for soft jaws / special tools (not part cycle time). */
export type ShopToolingLogStatus =
  | "open"
  | "applied_to_quote"
  | "no_charge"
  | "dismissed";

export interface ShopToolingLog {
  id: string;
  createdAt: string;
  updatedAt: string;
  machine: string;
  operator: string;
  jobId: string | null;
  partNumber: string;
  revision: string;
  customer: string;
  kind: QuoteToolingKind;
  description: string;
  /** Minutes spent making jaws/tools (separate from OP setup/run). */
  minutes: number;
  /** Live floor timer; null when stopped/logged. */
  timerStartedAt: string | null;
  /** Free-text for office / billing (what & why). */
  notes: string;
  /** Operator asks office to bill customer as a separate line. */
  billRequest: boolean;
  /** Optional $ suggestion from floor or office. */
  suggestedBillAmount: number;
  status: ShopToolingLogStatus;
  quoteId?: string;
  toolingChargeId?: string;
}

export interface EmailSendLog {
  id: string;
  sentAt: string;
  by: string;
  customer: string;
  toEmail: string;
  subject: string;
  quoteIds: string[];
  partNumbers: string[];
  method: "mailto" | "copy" | "print";
}

export interface DowntimeEntry {
  id: string;
  jobId: string;
  machine: string;
  operator: string;
  reason: string;
  startTime: string;
  endTime: string | null;
}

export interface OperatorTimeEntry {
  id: string;
  jobId: string;
  machine: string;
  operation: Operation;
  type: TimerType;
  operator: string;
  startTime: string;
  endTime: string | null;
  durationHours: number;
  unitsCompleted: number | null;
}

export interface AuditEntry {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  details: string;
}

export interface ActiveTimer {
  jobId: string;
  machine: string;
  operation: Operation;
  type: TimerType;
  startIso: string;
  accumulatedSeconds: number;
}

export interface MachineSession {
  machine: string;
  operatorId: string | null;
  operatorName: string;
  jobId: string | null;
  partNumber: string;
  revision: string;
  quantity: number;
  customer: string;
  loginTime: string | null;
  shiftStart: string | null;
  notes: string;
  setups: (number | "STARTED" | null)[];
  runtimes: (number | "STARTED" | null)[];
  quotedSetups: number[];
  quotedRuntimes: number[];
  efficiency: number;
  bonus: number;
  quantityCompleted: number;
  paused: boolean;
  pauseStart: string | null;
  /** Mid-setup / mid-runtime freeze so Resume continues the same clock. */
  pausedTimer?: {
    operation: Operation;
    type: TimerType;
    accumulatedSeconds: number;
  } | null;
}

export interface BonusTier {
  minEff: number;
  percentage: number;
}

/** Configurable day or night (or other) work window for bonuses */
export interface WorkShift {
  id: string;
  name: string;
  /** HH:MM local */
  start: string;
  /** HH:MM local — may be next calendar day if before start (overnight) */
  end: string;
  lunchHours: number;
  enabled: boolean;
}

export interface DayBonusRecord {
  id: string;
  operatorName: string;
  dateKey: string;
  /** day | night | custom shift id */
  shiftId: string;
  shiftName: string;
  weekKey: string;
  earnedHours: number;
  workedHours: number;
  pauseHours: number;
  onShiftHours: number;
  requiredShiftHours: number;
  efficiency: number;
  tierPct: number;
  pool: number;
  bonus: number;
  eligible: boolean;
  eligibilityReason: string;
  jobIds: string[];
  status: "open" | "finalized";
  finalizedAt: string | null;
}

export interface WeeklyPayout {
  id: string;
  operatorName: string;
  weekKey: string;
  dayIds: string[];
  totalBonus: number;
  status: "open" | "paid";
  paidAt: string | null;
}

export type CustomLists = {
  materials: string[];
  materialTypes: Record<string, string[]>;
  machines: string[];
  stockShapes: string[];
  pauseReasons: string[];
  /** Shop-added size notes (inventory typeahead) */
  sizeNotes: string[];
};


/** In-app shop chat (LAN shared) */
export type ChatChannel = "shop" | "dm";

/** File attached to a chat message (stored on host under data/po-files). */
export interface ChatAttachment {
  id: string;
  name: string;
  mime: string;
  size: number;
}

export interface ChatMessage {
  id: string;
  /** "shop" = everyone; "dm" = private to toEmail */
  channel: ChatChannel;
  fromEmail: string;
  fromName: string;
  /** DM recipient email; empty for shop channel */
  toEmail: string;
  body: string;
  createdAt: string;
  /** Optional job / part / machine note */
  context: string;
  /** Emails that have opened/read this (for unread badge) */
  readBy: string[];
  /** Optional files (PDF, photos, etc.) — ids point at host file store */
  attachments?: ChatAttachment[];
}

/** Shop-floor bug report or feature request (shared on host). */
export type FeedbackKind = "bug" | "feature";
export type FeedbackStatus = "new" | "looking" | "planned" | "done" | "wont";

export interface FeedbackAttachment {
  id: string;
  name: string;
  mime: string;
  size: number;
}

export interface FeedbackComment {
  id: string;
  at: string;
  byName: string;
  byEmail: string;
  body: string;
}

export interface FeedbackTicket {
  id: string;
  kind: FeedbackKind;
  status: FeedbackStatus;
  title: string;
  body: string;
  /** Page they were on, if they know */
  page: string;
  machine: string;
  createdAt: string;
  updatedAt: string;
  createdByName: string;
  createdByEmail: string;
  attachments: FeedbackAttachment[];
  comments: FeedbackComment[];
}

export interface AppSettings {
  editPassword: string;
  /** Client-only after sync: whether an edit password is set. */
  hasEditPassword?: boolean;
  /** @deprecated prefer shifts[day] — kept in sync for older code */
  workDayStart: string;
  workDayEnd: string;
  /** Unpaid lunch for primary day shift */
  lunchHours: number;
  /**
   * Day + night (and optional extra) shift windows for incentives.
   * Overnight shifts: end time earlier than start (e.g. 16:00–02:00).
   */
  shifts: WorkShift[];
  bonusTiers: BonusTier[];
  hourlyRate: number;
  companyName: string;
  /**
   * Beta / test mode for first shop rollout.
   * When true: bonuses calculate and show, but Mark paid is blocked (practice only).
   * Turn off for full production when you're ready to run for real.
   */
  betaMode: boolean;
  maxOperations: number;
  customLists: CustomLists;
  quoteFromEmail: string;
  /**
   * LAN address printed into barcode QR codes (phones must reach the host).
   * Example: http://10.200.1.139:8080 — not 127.0.0.1.
   */
  shopPublicUrl?: string;
  /** How many completed runs feed the shop average (default 10) */
  averageMaxRuns: number;
  /** 0–1 blend of shop avg into recipe (1 = full replace with average) */
  averageShopWeight: number;
  /** Exclude runs slower than this × quoted time from averages (default 1.5) */
  averageOutlierRatio: number;
  /** Shop going rates for EMJ weight × $/lb estimates on Quotes */
  materialPriceBook?: MaterialPriceEntry[];
}

export interface LcmState {
  operators: Operator[];
  customers: Customer[];
  quotes: Quote[];
  jobs: JobRun[];
  downtimes: DowntimeEntry[];
  operatorTimeLog: OperatorTimeEntry[];
  auditLog: AuditEntry[];
  sessions: Record<string, MachineSession>;
  activeTimers: Record<string, ActiveTimer | null>;
  dayBonuses: DayBonusRecord[];
  weeklyPayouts: WeeklyPayout[];
  materialStock: MaterialStock[];
  partStock: PartStock[];
  /** Individual finished parts with sharpied UIN + notes */
  partUnits: PartUnit[];
  inventoryTxns: InventoryTxn[];
  purchaseOrders: PurchaseOrder[];
  vendorRfqs: VendorRfq[];
  shopOrders: ShopOrder[];
  workQueue: WorkQueueItem[];
  /** Saw cut queue — progressive qty, CAD actuals */
  cutTickets: CutTicket[];
  stockPieces: StockPiece[];
  /** Frozen price/time snapshots for requote history */
  quoteHistory: QuoteSnapshot[];
  /** Outbound quote email log */
  emailLog: EmailSendLog[];
  /** Shop floor / office chat messages (shared on host) */
  chatMessages: ChatMessage[];
  /** Soft jaws / special tools logs from the floor */
  shopToolingLogs: ShopToolingLog[];
  /** Shop-floor bug reports and feature requests */
  feedbackTickets: FeedbackTicket[];
  settings: AppSettings;
  currentUserEmail: string;
}
