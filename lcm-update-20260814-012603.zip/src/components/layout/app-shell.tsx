import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Factory,
  FileSpreadsheet,
  Database,
  ClipboardList,
  BarChart3,
  Settings,
  Menu,
  X,
  Shield,
  UserRound,
  Lock,
  Mail,
  Package,
  Truck,
  CircleHelp,
  RefreshCw,
  AlertTriangle,
  CalendarDays,
  LayoutGrid,
  Timer,
  Scissors,
  MessageSquarePlus,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useLcmStore } from "@/store/lcm-store";
import { useHydrated } from "@/hooks/use-hydrated";
import {
  APP_TABS,
  firstAllowedPath,
  getOperatorByEmail,
  operatorCanAccessTab,
  pathToTab,
  requiresPinToSwitch,
  type AppTabId,
} from "@/lib/lcm/permissions";
import { RequireAccess } from "./require-access";
import { Input, Select, Label } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { Operator } from "@/lib/lcm/types";
import {
  getShopToken,
  registerShopUnlockHandler,
  setShopToken,
  startShopSync,
  useShopSyncStatus,
} from "@/lib/lcm/shop-sync";
import { claimShopSession } from "@/lib/lcm/shop-api";
import { HelpTip } from "@/components/ui/help-tip";
import { CompanyLogo } from "@/components/lcm/company-logo";
import { GlobalAttachmentPreview } from "@/components/lcm/attachment-preview";
import { ShopChat } from "@/components/lcm/shop-chat";
import { getAppUpdateInfo } from "@/lib/lcm/app-update-api";

const ICONS: Record<
  AppTabId,
  React.ComponentType<{ className?: string }>
> = {
  dashboard: LayoutDashboard,
  machines: Factory,
  jobs: ClipboardList,
  quoting: FileSpreadsheet,
  database: Database,
  inventory: Package,
  po: Truck,
  calendar: CalendarDays,
  board: LayoutGrid,
  active: Timer,
  saw: Scissors,
  feedback: MessageSquarePlus,
  email: Mail,
  reports: BarChart3,
  settings: Settings,
};

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const company = useLcmStore((s) => s.settings.companyName);
  const betaMode = useLcmStore((s) => s.settings.betaMode !== false);
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  const setCurrentUserEmail = useLcmStore((s) => s.setCurrentUserEmail);
  const addAudit = useLcmStore((s) => s.addAudit);
  const openFeedbackCount = useLcmStore((s) => {
    const list = s.feedbackTickets;
    if (!list || list.length === 0) return 0;
    let n = 0;
    for (const t of list) {
      if (t.status === "new" || t.status === "looking") n += 1;
    }
    return n;
  });
  const [open, setOpen] = useState(false);
  const [pendingUser, setPendingUser] = useState<Operator | null>(null);
  /** True when unlock is required before this device can write (chat, saves). */
  const [unlockRequired, setUnlockRequired] = useState(false);
  const [unlockReason, setUnlockReason] = useState<string>("");
  const [pinInput, setPinInput] = useState("");
  const [pinError, setPinError] = useState("");
  const [pinBusy, setPinBusy] = useState(false);
  const hydrated = useHydrated();
  const shopSync = useShopSyncStatus();
  /** Yellow refresh badge when host has a newer app package than this tab loaded */
  const [refreshNeeded, setRefreshNeeded] = useState(false);
  const [serverAppVersion, setServerAppVersion] = useState<string | null>(null);

  useEffect(() => {
    if (hydrated) startShopSync();
  }, [hydrated]);

  // Let chat / sync request the PIN dialog
  useEffect(() => {
    registerShopUnlockHandler((reason) => {
      const op = getOperatorByEmail(operators, email);
      if (!op) return;
      setUnlockReason(reason || "Enter your PIN to use chat and save on this device");
      setUnlockRequired(true);
      setPendingUser(op);
      setPinInput("");
      setPinError("");
    });
    return () => registerShopUnlockHandler(null);
  }, [operators, email]);

  // Re-establish shop session for the current operator (needed for saves + chat)
  useEffect(() => {
    if (!hydrated || !email) return;
    const op = getOperatorByEmail(operators, email);
    if (!op) return;

    if (requiresPinToSwitch(op)) {
      // Prompt PIN once if we don't already have a shop session token
      if (!getShopToken()) {
        setUnlockRequired(true);
        setUnlockReason(
          "Enter your PIN so this phone/PC can send chat and save to the shop database",
        );
        setPendingUser((cur) => cur ?? op);
      }
      return;
    }

    // Operators without a PIN: claim session automatically
    void claimShopSession({ data: { email: op.email, pin: "" } }).then((r) => {
      if (r.ok) {
        setShopToken(r.token);
        setUnlockRequired(false);
      }
    });
  }, [hydrated, email, operators]);

  useEffect(() => {
    if (!hydrated) return;
    let cancelled = false;
    const SESSION_KEY = "lcm-client-app-version";

    async function check() {
      try {
        const r = await getAppUpdateInfo();
        if (cancelled || !r.ok) return;
        const serverVer = r.version || "base";
        setServerAppVersion(r.version);
        const clientVer = sessionStorage.getItem(SESSION_KEY);
        if (!clientVer) {
          sessionStorage.setItem(SESSION_KEY, serverVer);
          setRefreshNeeded(false);
          return;
        }
        if (clientVer !== serverVer) {
          setRefreshNeeded(true);
        } else {
          setRefreshNeeded(false);
        }
      } catch {
        /* offline / ignore */
      }
    }

    void check();
    const id = window.setInterval(() => void check(), 12000);
    const onFocus = () => void check();
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") void check();
    });
    return () => {
      cancelled = true;
      window.clearInterval(id);
      window.removeEventListener("focus", onFocus);
    };
  }, [hydrated]);

  const activeOps = useMemo(
    () => operators.filter((o) => o.active),
    [operators],
  );

  const currentOp = useMemo(
    () => getOperatorByEmail(operators, email),
    [operators, email],
  );

  const navGroups = useMemo(() => {
    const allowed = APP_TABS.filter((t) =>
      operatorCanAccessTab(currentOp, t.id),
    ).map((t) => ({
      to: t.path,
      label: t.label,
      id: t.id,
      icon: ICONS[t.id],
    }));
    const groups: {
      label: string;
      ids: AppTabId[];
    }[] = [
      { label: "Floor", ids: ["dashboard", "machines", "board", "active", "saw", "jobs", "feedback"] },
      { label: "Orders", ids: ["po", "calendar"] },
      {
        label: "Quote / Buy",
        ids: ["quoting", "email", "database", "inventory"],
      },
      { label: "Manage", ids: ["reports", "settings"] },
    ];
    return groups
      .map((g) => ({
        label: g.label,
        items: g.ids
          .map((id) => allowed.find((a) => a.id === id))
          .filter(Boolean) as typeof allowed,
      }))
      .filter((g) => g.items.length > 0);
  }, [currentOp]);

  function completeSwitch(op: Operator) {
    setCurrentUserEmail(op.email);
    const tab = pathToTab(pathname);
    if (tab && !operatorCanAccessTab(op, tab)) {
      navigate({ to: firstAllowedPath(op) as "/" });
    }
    setOpen(false);
    setPendingUser(null);
    setPinInput("");
    setPinError("");
    setUnlockRequired(false);
    setUnlockReason("");
    addAudit(op.email, "Switch User", `Signed in as ${op.name}`);
  }

  function requestSwitch(nextEmail: string) {
    if (nextEmail.toLowerCase() === email.toLowerCase()) return;
    const op = getOperatorByEmail(operators, nextEmail);
    if (!op) return;

    if (!requiresPinToSwitch(op)) {
      void claimShopSession({ data: { email: op.email, pin: "" } }).then((r) => {
        if (r.ok) setShopToken(r.token);
        else toast.error(r.error || "Could not open shop session");
      });
      completeSwitch(op);
      toast.message(`Signed in as ${op.name}`);
      return;
    }

    // Switching to a PIN account: clear old token until they unlock as the new person
    setShopToken(null);
    setUnlockRequired(false); // optional switch — can cancel
    setUnlockReason("");
    setPendingUser(op);
    setPinInput("");
    setPinError("");
  }

  function cancelPinDialog() {
    // Required unlock (this device has no session): cannot dismiss
    if (unlockRequired) return;
    setPendingUser(null);
    setPinInput("");
    setPinError("");
  }

  async function confirmPin() {
    if (!pendingUser || pinBusy) return;
    const pin = pinInput.trim();
    if (!pin) {
      setPinError("Enter your PIN");
      return;
    }
    setPinBusy(true);
    setPinError("");
    try {
      const r = await claimShopSession({
        data: { email: pendingUser.email, pin },
      });
      if (!r.ok) {
        // Only show incorrect when the server actually rejected the PIN
        setPinError(r.error || "Incorrect PIN");
        toast.error(r.error || "Incorrect PIN");
        return;
      }
      setShopToken(r.token);
      toast.success(`Unlocked · signed in as ${pendingUser.name}`);
      completeSwitch(pendingUser);
    } catch (e) {
      // Network / host unreachable — do NOT pretend offline sign-in worked
      const msg =
        e instanceof Error && e.message
          ? e.message
          : "Cannot reach the shop host. Check Wi‑Fi and try again.";
      setPinError(msg);
      toast.error(msg);
    } finally {
      setPinBusy(false);
    }
  }

  const needsPinBanner =
    hydrated &&
    currentOp &&
    requiresPinToSwitch(currentOp) &&
    !shopSync.hasSession;

  return (
    <div className="min-h-dvh flex bg-[var(--color-bg)] text-[var(--color-fg)]">
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-64 border-r border-[var(--color-border)] bg-[var(--color-surface)] flex flex-col transition-transform lg:translate-x-0 lg:static print:hidden",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex items-center gap-2.5 px-3 h-14 border-b border-[var(--color-border)] shrink-0">
          <CompanyLogo
            variant="mark"
            invertFallback
            alt=""
            className="h-10 w-10 shrink-0 opacity-95"
          />
          <div className="min-w-0">
            <div className="font-semibold text-sm truncate leading-tight">
              {company}
            </div>
            <div className="text-[10px] text-[var(--color-muted)] uppercase tracking-wider">
              Data Management
            </div>
          </div>
          <button
            type="button"
            className="ml-auto lg:hidden p-2 rounded-[var(--radius-md)] hover:bg-[var(--color-surface-2)]"
            onClick={() => setOpen(false)}
            aria-label="Close menu"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto p-2 space-y-3">
          {navGroups.map((group) => (
            <div key={group.label} className="space-y-0.5">
              <div className="px-3 pt-1 pb-0.5 text-[10px] font-semibold uppercase tracking-wider text-[var(--color-subtle)]">
                {group.label}
              </div>
              {group.items.map((item) => {
                const active =
                  item.to === "/"
                    ? pathname === "/"
                    : pathname === item.to ||
                      pathname.startsWith(item.to + "/");
                const Icon = item.icon;
                return (
                  <Link
                    key={item.to}
                    to={item.to as "/"}
                    onClick={() => setOpen(false)}
                    className={cn(
                      "flex items-center gap-2.5 rounded-[var(--radius-md)] px-3 py-2.5 text-sm font-medium min-h-11 transition-colors",
                      active
                        ? "bg-[color-mix(in_oklab,var(--color-primary)_16%,transparent)] text-[var(--color-primary)]"
                        : "text-[var(--color-muted)] hover:bg-[var(--color-surface-2)] hover:text-[var(--color-fg)]",
                    )}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span className="flex-1 truncate">{item.label}</span>
                    {item.id === "feedback" && openFeedbackCount > 0 && (
                      <span className="rounded-full bg-[var(--color-primary)] text-[var(--color-primary-fg)] text-[10px] font-semibold min-w-5 h-5 px-1.5 inline-flex items-center justify-center">
                        {openFeedbackCount > 99 ? "99+" : openFeedbackCount}
                      </span>
                    )}
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>

        <div className="mt-auto p-3 border-t border-[var(--color-border)] space-y-2 shrink-0 print:hidden">
          <div className="text-[10px] uppercase tracking-wide text-[var(--color-muted)] font-medium px-0.5">
            Status colors
          </div>
          <div className="flex flex-wrap gap-1">
            <Badge tone="hold" className="text-[9px] px-1.5 py-0">
              Hold
            </Badge>
            <Badge tone="open" className="text-[9px] px-1.5 py-0">
              Open
            </Badge>
            <Badge tone="soon" className="text-[9px] px-1.5 py-0">
              Due soon
            </Badge>
            <Badge tone="overdue" className="text-[9px] px-1.5 py-0">
              Overdue
            </Badge>
            <Badge tone="active" className="text-[9px] px-1.5 py-0">
              Active
            </Badge>
            <Badge tone="ready" className="text-[9px] px-1.5 py-0">
              Ready
            </Badge>
            <Badge tone="done" className="text-[9px] px-1.5 py-0">
              Done
            </Badge>
            <Badge tone="danger" className="text-[9px] px-1.5 py-0">
              Problem
            </Badge>
            <Badge tone="office" className="text-[9px] px-1.5 py-0">
              Office
            </Badge>
          </div>
          <p className="text-[9px] text-[var(--color-subtle)] leading-snug px-0.5">
            Soft tints mean the same on every page
          </p>
        </div>

        <div className="p-3 border-t border-[var(--color-border)] space-y-2 shrink-0">
          <div className="flex items-center gap-2 px-1">
            <UserRound className="h-3.5 w-3.5 text-[var(--color-muted)]" />
            <span className="text-[10px] uppercase tracking-wide text-[var(--color-muted)] font-medium">
              Switch user
            </span>
            <HelpTip id="nav-switch-user" side="right" />
            {currentOp?.role === "admin" && (
              <Shield className="h-3 w-3 text-[var(--color-accent)] ml-auto" />
            )}
          </div>
          <Select
            value={email}
            onChange={(e) => requestSwitch(e.target.value)}
            aria-label="Switch signed-in user"
          >
            {activeOps.map((o) => (
              <option key={o.id} value={o.email}>
                {o.name}
                {o.role === "admin" ? " (Admin)" : ""}
              </option>
            ))}
          </Select>
          <p className="text-[10px] text-[var(--color-subtle)] px-0.5 leading-snug">
            {hydrated && currentOp
              ? requiresPinToSwitch(currentOp)
                ? shopSync.hasSession
                  ? "Unlocked on this device"
                  : "PIN required on this device for chat & saves"
                : "Open switch — set a PIN in Settings to lock"
              : "…"}
          </p>
        </div>
      </aside>

      {open && (
        <button
          type="button"
          className="fixed inset-0 z-30 bg-black/50 lg:hidden print:hidden"
          aria-label="Close overlay"
          onClick={() => setOpen(false)}
        />
      )}

      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-20 flex h-14 items-center gap-2 sm:gap-3 border-b border-[var(--color-border)] bg-[color-mix(in_oklab,var(--color-bg)_88%,transparent)] px-3 sm:px-5 backdrop-blur-md print:hidden min-w-0">
          <button
            type="button"
            className="lg:hidden inline-flex h-11 w-11 items-center justify-center rounded-[var(--radius-md)] border border-[var(--color-border)] shrink-0"
            onClick={() => setOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="h-4 w-4" />
          </button>
          <div className="text-sm text-[var(--color-muted)] truncate min-w-0 flex-1">
            {hydrated ? currentOp?.name || email : "…"}
          </div>
          <div className="ml-auto flex items-center gap-1.5 sm:gap-2 shrink-0 max-w-[70%] sm:max-w-none overflow-x-auto">
            {refreshNeeded && (
              <button
                type="button"
                onClick={() => {
                  try {
                    const v = serverAppVersion || "base";
                    sessionStorage.setItem("lcm-client-app-version", v);
                  } catch {
                    /* ignore */
                  }
                  window.location.reload();
                }}
                className="inline-flex items-center gap-1.5 rounded-full border border-amber-500/60 bg-amber-500/15 px-2.5 py-1 text-[11px] font-semibold text-amber-300 hover:bg-amber-500/25 min-h-9 animate-pulse"
                title="Host installed a new app version. Data stays on the host. Save forms, then refresh this page."
              >
                <AlertTriangle className="h-3.5 w-3.5 text-amber-400" />
                <span className="hidden sm:inline">Refresh required</span>
                <RefreshCw className="h-3.5 w-3.5" />
              </button>
            )}
            {betaMode && (
              <span
                className="inline-flex items-center gap-1 rounded-full border border-amber-500/50 bg-amber-500/10 px-2.5 py-1 text-[11px] font-semibold text-amber-300 min-h-9"
                title="Beta mode: full shop tools work; bonus Mark paid is practice-only until Production"
              >
                BETA
              </span>
            )}
            <Link
              to="/help"
              className="inline-flex items-center gap-1.5 rounded-full border border-[var(--color-border)] px-2 py-1 sm:px-2.5 text-[11px] font-medium text-[var(--color-primary)] hover:bg-[var(--color-surface-2)] min-h-9"
              title="How to use this system"
            >
              <CircleHelp className="h-3.5 w-3.5" />
              <span className="hidden xs:inline sm:inline">How to use</span>
            </Link>

            <span
              className={`inline-flex items-center gap-1.5 rounded-full px-2 sm:px-2.5 py-1 text-[11px] font-medium border shrink-0 ${
                shopSync.connected && shopSync.hasSession
                  ? "border-[color-mix(in_oklab,var(--color-success)_40%,transparent)] text-[var(--color-success)] bg-[color-mix(in_oklab,var(--color-success)_10%,transparent)]"
                  : shopSync.connected && !shopSync.hasSession
                    ? "border-amber-500/50 text-amber-300 bg-amber-500/10"
                    : "border-[var(--color-border)] text-[var(--color-muted)]"
              }`}
              title={
                shopSync.error ||
                (shopSync.rev
                  ? `Shared shop database · save #${shopSync.rev}`
                  : "Shared shop database")
              }
            >
              <span
                className={`h-1.5 w-1.5 rounded-full ${
                  shopSync.connected && shopSync.hasSession
                    ? "bg-[var(--color-success)] live-dot"
                    : shopSync.connected
                      ? "bg-amber-400"
                      : "bg-[var(--color-muted)]"
                }`}
              />
              <span className="sm:hidden">
                {shopSync.connected
                  ? shopSync.hasSession
                    ? "Live"
                    : "PIN"
                  : shopSync.error
                    ? "Off"
                    : "…"}
              </span>
              <span className="hidden sm:inline">
                {shopSync.connected
                  ? shopSync.hasSession
                    ? "Shop live"
                    : "Unlock PIN to save"
                  : shopSync.error
                    ? "Shop offline"
                    : "Connecting…"}
              </span>
            </span>
          </div>
        </header>
        {needsPinBanner && (
          <div className="print:hidden sticky top-14 z-20 flex items-center justify-between gap-3 border-b border-amber-500/50 bg-amber-500/15 px-3 sm:px-5 py-2 text-sm text-amber-100">
            <div className="flex items-center gap-2 min-w-0">
              <Lock className="h-4 w-4 shrink-0 text-amber-400" />
              <span className="min-w-0 text-xs sm:text-sm">
                This device is not unlocked — chat and saves will only work on
                the host until you enter your PIN.
              </span>
            </div>
            <button
              type="button"
              className="shrink-0 inline-flex items-center gap-1.5 rounded-md bg-amber-400 text-black font-semibold text-xs px-3 py-1.5 min-h-9"
              onClick={() => {
                if (currentOp) {
                  setUnlockRequired(true);
                  setUnlockReason(
                    "Enter your PIN so this device can send chat and save",
                  );
                  setPendingUser(currentOp);
                  setPinInput("");
                  setPinError("");
                }
              }}
            >
              <Lock className="h-3.5 w-3.5" />
              Enter PIN
            </button>
          </div>
        )}
        {refreshNeeded && (
          <div className="print:hidden sticky top-14 z-20 flex items-center justify-between gap-3 border-b border-amber-500/50 bg-amber-500/15 px-3 sm:px-5 py-2 text-sm text-amber-100">
            <div className="flex items-center gap-2 min-w-0">
              <AlertTriangle className="h-4 w-4 shrink-0 text-amber-400" />
              <span className="min-w-0">
                <span className="font-medium block sm:inline">
                  New app version on the host.
                </span>{" "}
                <span className="text-amber-100/90 text-xs sm:text-sm">
                  Your shop data is on the host PC — nothing was deleted. Save open
                  forms, then refresh this browser to load the new version.
                </span>
              </span>
            </div>
            <button
              type="button"
              className="shrink-0 inline-flex items-center gap-1.5 rounded-md bg-amber-400 text-black font-semibold text-xs px-3 py-1.5 min-h-9"
              onClick={() => {
                try {
                  sessionStorage.setItem(
                    "lcm-client-app-version",
                    serverAppVersion || "base",
                  );
                } catch {
                  /* ignore */
                }
                window.location.reload();
              }}
            >
              <RefreshCw className="h-3.5 w-3.5" />
              Refresh now
            </button>
          </div>
        )}
        <main className="flex-1 p-3 sm:p-5 lg:p-6 print:p-0">
          <RequireAccess pathname={pathname}>{children}</RequireAccess>
          <ShopChat />
        </main>
      </div>

      {pendingUser && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-4 print:hidden"
          onClick={() => {
            if (!unlockRequired) cancelPinDialog();
          }}
        >
          <div
            className="w-full max-w-sm rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 mb-1">
              <Lock className="h-4 w-4 text-[var(--color-primary)]" />
              <h2 className="text-lg font-semibold">
                {unlockRequired ? "Unlock this device" : "Enter PIN"}
              </h2>
            </div>
            <p className="text-sm text-[var(--color-muted)] mb-1">
              {unlockRequired ? (
                <>
                  Unlock{" "}
                  <strong className="text-[var(--color-fg)]">
                    {pendingUser.name}
                  </strong>
                  {pendingUser.role === "admin" ? " (admin)" : ""} so this
                  phone/PC can chat and save to the shop.
                </>
              ) : (
                <>
                  Switch to{" "}
                  <strong className="text-[var(--color-fg)]">
                    {pendingUser.name}
                  </strong>
                  {pendingUser.role === "admin" ? " (admin)" : ""}
                </>
              )}
            </p>
            {unlockReason ? (
              <p className="text-xs text-amber-200/90 mb-3 leading-relaxed">
                {unlockReason}
              </p>
            ) : (
              <div className="mb-3" />
            )}
            <div className="space-y-1.5">
              <Label htmlFor="switch-pin">PIN (set in Settings — not your Wi‑Fi password)</Label>
              <Input
                id="switch-pin"
                type="password"
                inputMode="numeric"
                autoComplete="one-time-code"
                autoFocus
                value={pinInput}
                disabled={pinBusy}
                onChange={(e) => {
                  setPinInput(e.target.value);
                  setPinError("");
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") void confirmPin();
                }}
                placeholder="••••"
              />
              {pinError && (
                <p className="text-xs text-[var(--color-danger)]">{pinError}</p>
              )}
            </div>
            <div className="flex gap-2 mt-4 justify-end">
              {!unlockRequired && (
                <Button variant="ghost" onClick={cancelPinDialog} disabled={pinBusy}>
                  Cancel
                </Button>
              )}
              <Button onClick={() => void confirmPin()} disabled={pinBusy}>
                {pinBusy ? "Checking…" : unlockRequired ? "Unlock" : "Unlock"}
              </Button>
            </div>
          </div>
        </div>
      )}
      <GlobalAttachmentPreview />
    </div>
  );
}
