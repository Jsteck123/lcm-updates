import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  Download,
  Upload,
  RotateCcw,
  Plus,
  Trash2,
  Shield,
  KeyRound,
  FileSpreadsheet,
  PackageCheck,
  RefreshCw,
} from "lucide-react";
import { toast } from "sonner";
import { resolveWorkShifts, DEFAULT_WORK_SHIFTS } from "@/lib/lcm/day-bonus";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { uid } from "@/lib/utils";
import type { AppTab, Operator, Customer, OperatorRole } from "@/lib/lcm/types";
import {
  ALL_TABS,
  APP_TABS,
  DEFAULT_ADMIN_PIN,
  DEFAULT_OPERATOR_TABS,
  getOperatorByEmail,
  isMoneyTab,
  normalizeOperator,
  requiresPinToSwitch,
} from "@/lib/lcm/permissions";
import {
  DEFAULT_OPERATIONS,
  MAX_OPERATIONS,
  MIN_OPERATIONS,
  clampOpCount,
} from "@/lib/lcm/ops";
import { flushShopSync, getShopToken, requestShopUnlock, useShopSyncStatus } from "@/lib/lcm/shop-sync";
import {
  createShopBackup,
  downloadShopBackup,
  listShopBackups,
  restoreShopBackup,
  type BackupInfo,
} from "@/lib/lcm/backup-api";
import { HelpTip, WithHelp } from "@/components/ui/help-tip";
import { useHelpTips } from "@/hooks/use-help-tips";
import {
  downloadSampleCsv,
  parseQuoteCsv,
  type QuoteImportMode,
} from "@/lib/lcm/quote-import";
import {
  applyAppUpdate,
  getAppUpdateInfo,
} from "@/lib/lcm/app-update-api";
import {
  clearCompanyLogo,
  getCompanyLogoInfo,
  saveCompanyLogo,
} from "@/lib/lcm/branding-api";
import { CompanyLogo, notifyLogoChanged } from "@/components/lcm/company-logo";

export const Route = createFileRoute("/settings")({
  component: SettingsPage,
});

function SettingsPage() {
  const shopSync = useShopSyncStatus();
  const helpTips = useHelpTips();
  const operators = useLcmStore((s) => s.operators);
  const customers = useLcmStore((s) => s.customers);
  const settings = useLcmStore((s) => s.settings);
  const currentUserEmail = useLcmStore((s) => s.currentUserEmail);
  const setCurrentUserEmail = useLcmStore((s) => s.setCurrentUserEmail);
  const updateSettings = useLcmStore((s) => s.updateSettings);
  const upsertOperator = useLcmStore((s) => s.upsertOperator);
  const removeOperator = useLcmStore((s) => s.removeOperator);
  const upsertCustomer = useLcmStore((s) => s.upsertCustomer);
  const removeCustomer = useLcmStore((s) => s.removeCustomer);
  const exportJson = useLcmStore((s) => s.exportJson);
  const importJson = useLcmStore((s) => s.importJson);
  const importHistoricalQuotes = useLcmStore((s) => s.importHistoricalQuotes);
  const quotes = useLcmStore((s) => s.quotes);
  const resetToSeed = useLcmStore((s) => s.resetToSeed);
  const auditLog = useLcmStore((s) => s.auditLog);
  const addAudit = useLcmStore((s) => s.addAudit);

  const me = getOperatorByEmail(operators, currentUserEmail);
  const isAdmin = me?.role === "admin";

  const fileRef = useRef<HTMLInputElement>(null);
  const [opName, setOpName] = useState("");
  const [opEmail, setOpEmail] = useState("");
  const [opRole, setOpRole] = useState<OperatorRole>("operator");
  const [opPin, setOpPin] = useState("");
  const [custName, setCustName] = useState("");
  const [pw, setPw] = useState(settings.editPassword);
  const [tiers, setTiers] = useState(settings.bonusTiers);
  const [pinDrafts, setPinDrafts] = useState<Record<string, string>>({});
  const [maxOpsDraft, setMaxOpsDraft] = useState(
    String(settings.maxOperations || DEFAULT_OPERATIONS),
  );
  const [quoteImportMode, setQuoteImportMode] =
    useState<QuoteImportMode>("update");
  const [quoteImportBusy, setQuoteImportBusy] = useState(false);
  const [quotePreview, setQuotePreview] = useState<{
    count: number;
    sample: string[];
    errors: string[];
  } | null>(null);
  const [quoteImportResult, setQuoteImportResult] = useState<string | null>(
    null,
  );
  const [quoteCsvText, setQuoteCsvText] = useState("");
  const [backups, setBackups] = useState<BackupInfo[]>([]);
  const [backupFolder, setBackupFolder] = useState("");
  const [backupAuthError, setBackupAuthError] = useState("");
  const [backupBusy, setBackupBusy] = useState(false);
  const [updateBusy, setUpdateBusy] = useState(false);
  const [updateInfo, setUpdateInfo] = useState<{
    version: string | null;
    appliedAt: string | null;
    note: string | null;
  }>({ version: null, appliedAt: null, note: null });
  const [updateDialogOpen, setUpdateDialogOpen] = useState(false);
  const [pendingUpdateFile, setPendingUpdateFile] = useState<File | null>(null);
  const updateFileRef = useRef<HTMLInputElement>(null);
  const logoFileRef = useRef<HTMLInputElement>(null);
  const [logoBusy, setLogoBusy] = useState(false);
  const [logoInfo, setLogoInfo] = useState<{
    hasLogo: boolean;
    url?: string;
    name?: string;
  }>({ hasLogo: false });
  const [resetTyped, setResetTyped] = useState("");
  const [avgMax, setAvgMax] = useState(String(settings.averageMaxRuns ?? 10));
  const [avgWeight, setAvgWeight] = useState(
    String(settings.averageShopWeight ?? 0.7),
  );
  const [avgOutlier, setAvgOutlier] = useState(
    String(settings.averageOutlierRatio ?? 1.5),
  );

  function needBackupSession(): boolean {
    if (getShopToken()) return true;
    requestShopUnlock(
      "Unlock with your admin PIN so this PC can talk to host backups",
    );
    toast.message("Enter your PIN, then try Backup now again");
    return false;
  }

  async function refreshBackups() {
    try {
      const token = getShopToken() || undefined;
      if (!token) {
        setBackupAuthError("Unlock with your PIN to see and make backups.");
        return;
      }
      const r = await listShopBackups({ data: { token } });
      if (r.ok) {
        setBackups(r.backups || []);
        setBackupFolder(r.folder || "");
        setBackupAuthError("");
      } else {
        setBackupAuthError(r.error || "Could not list backups");
      }
    } catch {
      /* ignore */
    }
  }

  async function downloadBackupFile(fileName: string) {
    if (!needBackupSession()) return;
    const token = getShopToken() || undefined;
    setBackupBusy(true);
    try {
      const r = await downloadShopBackup({ data: { fileName, token } });
      if (!r.ok) {
        toast.error(r.error || "Download failed");
        return;
      }
      const blob = new Blob([r.json], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = r.fileName || fileName;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      toast.success("Backup saved on this computer");
    } finally {
      setBackupBusy(false);
    }
  }

  async function refreshUpdateInfo() {
    try {
      const r = await getAppUpdateInfo();
      if (r.ok) {
        setUpdateInfo({
          version: r.version,
          appliedAt: r.appliedAt,
          note: r.note,
        });
      }
    } catch {
      /* ignore */
    }
  }

  useEffect(() => {
    void refreshBackups();
    void refreshUpdateInfo();
    void refreshLogoInfo();
  }, []);

  async function refreshLogoInfo() {
    try {
      const r = await getCompanyLogoInfo();
      if (r.ok && r.hasLogo) {
        setLogoInfo({
          hasLogo: true,
          url: r.url,
          name: r.meta?.originalName,
        });
      } else {
        setLogoInfo({ hasLogo: false });
      }
    } catch {
      setLogoInfo({ hasLogo: false });
    }
  }

  async function handleLogoFile(file: File | null) {
    if (!file || !isAdmin) return;
    if (file.size > 6_000_000) {
      toast.error("Logo max size is 6 MB");
      return;
    }
    setLogoBusy(true);
    try {
      const buf = await file.arrayBuffer();
      const bytes = new Uint8Array(buf);
      let binary = "";
      const chunk = 0x8000;
      for (let i = 0; i < bytes.length; i += chunk) {
        binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
      }
      const r = await saveCompanyLogo({
        data: {
          name: file.name,
          mime: file.type || "image/png",
          base64: btoa(binary),
        },
      });
      if (!r.ok) {
        toast.error(r.error || "Upload failed");
        return;
      }
      await refreshLogoInfo();
      notifyLogoChanged();
      addAudit(currentUserEmail, "Branding", `Logo uploaded: ${file.name}`);
      toast.success("Company logo saved — header, printouts, and desktop/home-screen icons");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setLogoBusy(false);
      if (logoFileRef.current) logoFileRef.current.value = "";
    }
  }

  async function runAppUpdate() {
    if (!pendingUpdateFile) {
      toast.error("Choose an update package first");
      return;
    }
    if (!isAdmin) {
      toast.error("Only admins can update the app");
      return;
    }
    setUpdateBusy(true);
    try {
      // Backup shop DB first
      try {
        await createShopBackup({
          data: { label: "pre-update", token: getShopToken() || undefined },
        });
      } catch {
        /* best effort */
      }
      const buf = await pendingUpdateFile.arrayBuffer();
      const bytes = new Uint8Array(buf);
      let binary = "";
      const chunk = 0x8000;
      for (let i = 0; i < bytes.length; i += chunk) {
        binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
      }
      const base64 = btoa(binary);
      const r = await applyAppUpdate({
        data: {
          base64,
          fileName: pendingUpdateFile.name,
        },
      });
      if (!r.ok) {
        toast.error(r.error || "Update failed");
        return;
      }
      addAudit(
        currentUserEmail,
        "App update",
        `v${r.version} · ${r.filesUpdated} files · ${pendingUpdateFile.name}`,
      );
      await refreshUpdateInfo();
      setUpdateDialogOpen(false);
      setPendingUpdateFile(null);
      toast.success(
        `Updated to ${r.version} (${r.filesUpdated} files). Restart the app on the host PC, then refresh all browsers.`,
        { duration: 12000 },
      );
      if (r.needsNpmInstall) {
        toast.message(
          "This package changed dependencies — on the host run: npm install  then restart",
          { duration: 15000 },
        );
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Update failed");
    } finally {
      setUpdateBusy(false);
    }
  }

  function saveSettings() {
    const maxOperations = clampOpCount(Number(maxOpsDraft) || DEFAULT_OPERATIONS);
    updateSettings({
      editPassword: pw,
      bonusTiers: tiers,
      maxOperations,
    });
    setMaxOpsDraft(String(maxOperations));
    toast.success("Settings saved · max ops = " + maxOperations);
  }

  function saveAverageRules() {
    // Number("1") is fine; Number("") is 0 → treat empty as default 10
    const rawMax = String(avgMax).trim();
    const parsedMax = rawMax === "" ? 10 : Number(rawMax);
    const averageMaxRuns = Math.min(
      50,
      Math.max(1, Number.isFinite(parsedMax) ? parsedMax : 10),
    );
    const rawW = String(avgWeight).trim();
    const parsedW = rawW === "" ? 0.7 : Number(rawW);
    const averageShopWeight = Math.min(
      1,
      Math.max(0, Number.isFinite(parsedW) ? parsedW : 0.7),
    );
    const rawO = String(avgOutlier).trim();
    const parsedO = rawO === "" ? 1.5 : Number(rawO);
    const averageOutlierRatio = Math.max(
      1,
      Number.isFinite(parsedO) ? parsedO : 1.5,
    );
    updateSettings({
      averageMaxRuns,
      averageShopWeight,
      averageOutlierRatio,
    });
    setAvgMax(String(averageMaxRuns));
    setAvgWeight(String(averageShopWeight));
    setAvgOutlier(String(averageOutlierRatio));
    toast.success(
      `Average rules saved · runs max = ${averageMaxRuns} · weight = ${averageShopWeight} · outlier = ${averageOutlierRatio}`,
    );
  }

  function addOperator() {
    if (!opName.trim() || !opEmail.trim()) {
      toast.error("Name and email required");
      return;
    }
    const op = normalizeOperator({
      id: uid(),
      name: opName.trim(),
      email: opEmail.trim(),
      active: true,
      role: opRole,
      tabs: opRole === "admin" ? [...ALL_TABS] : [...DEFAULT_OPERATOR_TABS],
      pin: opPin.trim() || (opRole === "admin" ? DEFAULT_ADMIN_PIN : ""),
    });
    upsertOperator(op);
    setOpName("");
    setOpEmail("");
    setOpPin("");
    setOpRole("operator");
    toast.success("Operator added");
  }

  function toggleTab(op: Operator, tab: AppTab) {
    if (!isAdmin) return;
    // Settings stays on for admins so access can always be managed
    if (op.role === "admin" && tab === "settings" && op.tabs.includes("settings")) {
      toast.message("Admins always keep Settings so access can be managed.");
      return;
    }
    if (op.role !== "admin" && isMoneyTab(tab)) {
      toast.message("Quoting, prices, email, and reports stay office-only.");
      return;
    }
    const has = op.tabs.includes(tab);
    let tabs = has ? op.tabs.filter((t) => t !== tab) : [...op.tabs, tab];
    if (op.role === "admin" && !tabs.includes("settings")) {
      tabs = [...tabs, "settings"];
    }
    // Empty nav would leave them stranded
    if (tabs.length === 0) {
      tabs = ["dashboard"];
      toast.message("At least Dashboard stays on so they can still open the app.");
    }
    upsertOperator(normalizeOperator({ ...op, tabs }));
  }

  function savePin(op: Operator) {
    const pin = (pinDrafts[op.id] ?? op.pin ?? "").trim();
    upsertOperator(normalizeOperator({ ...op, pin }));
    toast.success(pin ? "PIN saved for " + op.name : "PIN cleared for " + op.name);
  }

  function addCustomer() {
    if (!custName.trim()) return;
    upsertCustomer({
      id: uid(),
      name: custName.trim(),
      email: "",
      emails: [],
      lastEmailedAt: null,
    });
    setCustName("");
    toast.success("Customer added");
  }

  async function handleQuoteCsvPreview(file: File) {
    setQuoteImportBusy(true);
    setQuoteImportResult(null);
    try {
      const text = await file.text();
      const parsed = parseQuoteCsv(
        text,
        settings.maxOperations || DEFAULT_OPERATIONS,
      );
      setQuotePreview({
        count: parsed.quotes.length,
        sample: parsed.quotes.slice(0, 8).map(
          (q) =>
            `${q.partNumber}${q.revision ? " rev " + q.revision : ""} · ${q.customer || "—"} · ${q.material || "no mat"}`,
        ),
        errors: parsed.errors,
      });
      if (!parsed.quotes.length) {
        toast.error(parsed.errors[0] || "No parts found in CSV");
      } else {
        toast.message(
          `Ready: ${parsed.quotes.length} part row(s) from ${file.name}`,
        );
      }
      // stash text on input dataset via ref attribute
      setQuoteCsvText(text);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not read CSV");
    } finally {
      setQuoteImportBusy(false);
    }
  }

  async function runQuoteImport() {
    if (!isAdmin) {
      toast.error("Admin only");
      return;
    }
    const text = quoteCsvText;
    if (!text) {
      toast.error("Choose a CSV file first");
      return;
    }
    if (
      !confirm(
        `Import historical quotes?\nMode: ${quoteImportMode}\nThis writes into the shared shop database on the host.`,
      )
    ) {
      return;
    }
    setQuoteImportBusy(true);
    try {
      const res = importHistoricalQuotes(text, quoteImportMode);
      if (!res.ok) {
        toast.error(res.error || "Import failed");
        setQuoteImportResult(res.error || "failed");
        return;
      }
      // Force push to host so other PCs + restarts keep Machine % / stock shape
      const flush = await flushShopSync();
      if (!flush.ok) {
        toast.error(
          flush.error ||
            "Imported on this screen but not saved to host yet — unlock PIN and import again",
        );
        setQuoteImportResult(
          `${res.created} new · ${res.updated} updated (NOT on host yet — ${flush.error || "save failed"})`,
        );
        return;
      }
      setQuoteImportResult(
        `${res.created} new · ${res.updated} updated · ${res.skipped} skipped (${res.total} CSV rows) · saved to host rev ${flush.rev}`,
      );
      toast.success(
        `${res.created} new, ${res.updated} updated — saved to shop host (other PCs refresh in a few seconds)`,
      );
      if (res.errors.length) toast.message(res.errors[0]);
    } finally {
      setQuoteImportBusy(false);
    }
  }

  function handleExport() {
    const blob = new Blob([exportJson()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "lcm-backup-" + new Date().toISOString().slice(0, 10) + ".json";
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Backup downloaded");
  }

  function handleImport(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      const res = importJson(String(reader.result || ""));
      if (res.ok) toast.success("Backup restored");
      else toast.error(res.error || "Import failed");
    };
    reader.readAsText(file);
  }

  return (
    <div className="mx-auto max-w-5xl space-y-5">
      <div>
        <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight">Settings</h1>
        <p className="text-sm text-[var(--color-muted)] mt-1">
          Users, PINs, tab access, shop network, bonus day, and backup
        </p>
      </div>

<Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PackageCheck className="h-5 w-5" />
            Update app
            <HelpTip id="app-update" />
          </CardTitle>
          <CardDescription>
            Install a new version from an <strong>lcm-update-*.zip</strong> package
            (the file we give you from chat). Replaces program files only — your
            shop database under <code className="text-xs">data/</code> is never
            touched. A safety backup is taken first.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!isAdmin ? (
            <p className="text-sm text-[var(--color-muted)]">
              Admin only — switch to an admin account to update the app.
            </p>
          ) : (
            <>
              <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 text-sm">
                <div className="font-medium">
                  Installed package:{" "}
                  {updateInfo.version ? (
                    <span className="tabular-nums">{updateInfo.version}</span>
                  ) : (
                    <span className="text-[var(--color-muted)]">base install</span>
                  )}
                </div>
                {updateInfo.appliedAt && (
                  <div className="text-xs text-[var(--color-muted)] mt-0.5">
                    Applied {new Date(updateInfo.appliedAt).toLocaleString()}
                    {updateInfo.note ? ` · ${updateInfo.note}` : ""}
                  </div>
                )}
              </div>

              <ol className="text-sm text-[var(--color-muted)] list-decimal pl-5 space-y-1">
                <li>Download the <strong>lcm-update-*.zip</strong> we send you.</li>
                <li>Click Update app and choose that zip (about 0.5&nbsp;MB).</li>
                <li>Confirm — only program files are replaced (never the database).</li>
                <li>Restart the app on the host PC, then refresh every browser/phone.</li>
              </ol>
              <p className="text-xs text-[var(--color-muted)] leading-relaxed rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2">
                If Update says <strong>unzip failed</strong> (older installs on Windows):
                copy the zip into the app folder and run{" "}
                <code className="text-[10px]">node scripts/apply-lcm-update.mjs lcm-update-….zip</code>
                {" "}from that folder, then restart the app once. Newer packages fix
                in-app update so next time Settings works.
              </p>

              <div className="flex flex-wrap gap-2">
                <Button
                  type="button"
                  onClick={() => {
                    setPendingUpdateFile(null);
                    setUpdateDialogOpen(true);
                  }}
                >
                  <Upload className="h-4 w-4" />
                  Update app…
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => void refreshUpdateInfo()}
                >
                  <RefreshCw className="h-4 w-4" />
                  Refresh status
                </Button>
              </div>
              <p className="text-[11px] text-[var(--color-subtle)] leading-relaxed">
                Safe: updates <code className="text-[10px]">src/</code>, UI, scripts,
                config. Never overwrites quotes, inventory, orders, or drawings.
              </p>
            </>
          )}
        </CardContent>
      </Card>


      <Card>
        <CardHeader>
          <CardTitle>Shop network (LAN)</CardTitle>
          <CardDescription>
            One PC hosts the app. Every other computer on your network opens that
            PC address in a browser. All data lives in one file on the host —
            jobs, quotes, timers update live for everyone (about once a second).
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-[var(--color-muted)]">
          <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-1">
            <p className="text-[var(--color-fg)] font-medium">
              Status:{" "}
              {shopSync.connected
                ? "Connected · revision " + shopSync.rev
                : shopSync.error || "Connecting…"}
            </p>
            <p>
              Mode:{" "}
              {shopSync.mode === "shared"
                ? "Shared shop database"
                : "Local fallback"}
            </p>
          </div>
          <ol className="list-decimal pl-5 space-y-1.5">
            <li>
              Pick one always-on shop PC as the{" "}
              <strong className="text-[var(--color-fg)]">host</strong> (office
              desktop or small server).
            </li>
            <li>
              Run this app on the host so it listens on the network (port 8080).
            </li>
            <li>
              On the host, open a command prompt and run{" "}
              <code className="text-[var(--color-fg)]">ipconfig</code> — note
              the IPv4 address (e.g. 192.168.1.50).
            </li>
            <li>
              On every other PC / tablet, open Edge or Chrome to{" "}
              <code className="text-[var(--color-fg)]">http://192.168.x.x:8080</code>{" "}
              (use your host IP).
            </li>
            <li>
              Windows Firewall: allow the app / port 8080 on the host (Private
              network).
            </li>
          </ol>
          <p className="text-xs">
            Database file on the host:{" "}
            <code className="text-[var(--color-fg)]">data/lcm-shop.json</code> —
            back that file up. Only run one host; everyone else connects to it.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Who am I? (this station)</CardTitle>
          <CardDescription>
            Signed-in user stays on this PC only. Shop data is shared; identity is
            not.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-1.5 max-w-md">
            <Label>Signed in as</Label>
            <Select
              value={currentUserEmail}
              onChange={(e) => setCurrentUserEmail(e.target.value)}
            >
              {operators
                .filter((o) => o.active)
                .map((o) => (
                  <option key={o.id} value={o.email}>
                    {o.name}
                    {o.role === "admin" ? " (Admin)" : ""}
                  </option>
                ))}
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-4 w-4" /> Operators & access
            <HelpTip id="settings-pins" />
          </CardTitle>
          <CardDescription>
            Choose who can open Quoting, Email, Settings, etc. Admins need a PIN. 
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {isAdmin && (
            <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-2">
              <Input
                placeholder="Name"
                value={opName}
                onChange={(e) => setOpName(e.target.value)}
              />
              <Input
                placeholder="email@shop.com"
                value={opEmail}
                onChange={(e) => setOpEmail(e.target.value)}
              />
              <Select
                value={opRole}
                onChange={(e) => setOpRole(e.target.value as OperatorRole)}
              >
                <option value="operator">Operator</option>
                <option value="admin">Admin</option>
              </Select>
              <Input
                placeholder="PIN (optional)"
                value={opPin}
                onChange={(e) => setOpPin(e.target.value)}
              />
              <Button onClick={addOperator}>
                <Plus className="h-4 w-4" /> Add
              </Button>
            </div>
          )}

          <div className="space-y-3">
            {operators.map((op) => (
              <div
                key={op.id}
                className="rounded-[var(--radius-lg)] border border-[var(--color-border)] p-3 space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="font-medium">
                      {op.name}{" "}
                      {op.role === "admin" && (
                        <span className="text-xs text-[var(--color-accent)]">
                          admin
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-[var(--color-muted)]">{op.email}</div>
                  </div>
                  {isAdmin && op.email !== currentUserEmail && (
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => removeOperator(op.id)}
                      aria-label="Remove"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>

                {isAdmin && (
                  <>
                    <div className="flex flex-wrap gap-1.5">
                      {APP_TABS.filter(
                        (t) => op.role === "admin" || !isMoneyTab(t.id),
                      ).map((t) => {
                        const on = op.tabs.includes(t.id);
                        return (
                          <button
                            key={t.id}
                            type="button"
                            disabled={op.role === "admin" && t.id === "settings"}
                            onClick={() => toggleTab(op, t.id)}
                            className={
                              "text-xs px-2 py-1 rounded-md border min-h-8 " +
                              (on
                                ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)]"
                                : "border-[var(--color-border)] text-[var(--color-muted)]")
                            }
                          >
                            {t.label}
                          </button>
                        );
                      })}
                    </div>
                    <div className="flex flex-wrap items-end gap-2">
                      <div className="space-y-1 flex-1 min-w-[120px]">
                        <Label className="text-xs flex items-center gap-1">
                          <KeyRound className="h-3 w-3" /> PIN
                          {requiresPinToSwitch(op) ? " (required)" : ""}
                        </Label>
                        <Input
                          type="password"
                          inputMode="numeric"
                          placeholder={op.pin ? "••••" : "none"}
                          value={pinDrafts[op.id] ?? ""}
                          onChange={(e) =>
                            setPinDrafts((d) => ({
                              ...d,
                              [op.id]: e.target.value,
                            }))
                          }
                        />
                      </div>
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => savePin(op)}
                      >
                        Save PIN
                      </Button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Customers & emails</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {isAdmin && (
              <div className="flex gap-2">
                <Input
                  placeholder="Customer name"
                  value={custName}
                  onChange={(e) => setCustName(e.target.value)}
                />
                <Button onClick={addCustomer}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            )}
            <ul className="divide-y divide-[var(--color-border)] max-h-80 overflow-y-auto">
              {customers.map((c) => (
                <li key={c.id} className="py-2.5 space-y-1.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-medium truncate">{c.name}</span>
                    {isAdmin && (
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => removeCustomer(c.id)}
                        aria-label="Remove"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  {isAdmin && (
                    <Input
                      type="email"
                      placeholder="Primary email for quotes"
                      value={c.email || ""}
                      onChange={(e) =>
                        upsertCustomer({ ...c, email: e.target.value.trim() })
                      }
                      className="h-9 text-xs"
                    />
                  )}
                </li>
              ))}
            </ul>
            {isAdmin && (
              <div className="space-y-1.5 pt-2 border-t border-[var(--color-border)]">
                <Label>Quote From email (display)</Label>
                <Input
                  type="email"
                  value={settings.quoteFromEmail || ""}
                  onChange={(e) =>
                    updateSettings({ quoteFromEmail: e.target.value.trim() })
                  }
                  placeholder="you@lakecountrymachine.com"
                />
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Shifts & bonus</CardTitle>
            <CardDescription>
              Day and night each have their own window. Bonus only counts work
              inside that shift (overnight night shift OK). Full shift required.
              Lunch excluded. Paid weekly — not per job.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {(() => {
              const shifts = resolveWorkShifts(settings);
              const patchShift = (
                id: string,
                patch: Partial<(typeof shifts)[0]>,
              ) => {
                const next = shifts.map((s) =>
                  s.id === id ? { ...s, ...patch } : s,
                );
                // ensure day + night always present
                for (const d of DEFAULT_WORK_SHIFTS) {
                  if (!next.some((s) => s.id === d.id)) next.push({ ...d });
                }
                updateSettings({ shifts: next });
              };
              return (
                <div className="space-y-4">
                  {shifts.map((sh) => (
                    <div
                      key={sh.id}
                      className="rounded-[var(--radius-md)] border border-[var(--color-border)] p-3 space-y-3"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="font-medium text-sm">
                          {sh.name} shift
                          <span className="text-[var(--color-muted)] font-normal">
                            {" "}
                            · {sh.start}–{sh.end}
                            {sh.end < sh.start ||
                            (sh.id === "night" && sh.end <= "12:00")
                              ? " (overnight)"
                              : ""}
                          </span>
                        </div>
                        <label className="flex items-center gap-2 text-xs text-[var(--color-muted)] min-h-9 cursor-pointer">
                          <input
                            type="checkbox"
                            className="h-4 w-4 accent-[var(--color-primary)]"
                            checked={sh.enabled}
                            disabled={!isAdmin}
                            onChange={(e) =>
                              patchShift(sh.id, { enabled: e.target.checked })
                            }
                          />
                          Enabled
                        </label>
                      </div>
                      <div className="grid sm:grid-cols-3 gap-3">
                        <div className="space-y-1.5">
                          <Label>Start</Label>
                          <Input
                            type="time"
                            value={sh.start}
                            disabled={!isAdmin || !sh.enabled}
                            onChange={(e) =>
                              patchShift(sh.id, { start: e.target.value })
                            }
                          />
                        </div>
                        <div className="space-y-1.5">
                          <Label>End</Label>
                          <Input
                            type="time"
                            value={sh.end}
                            disabled={!isAdmin || !sh.enabled}
                            onChange={(e) =>
                              patchShift(sh.id, { end: e.target.value })
                            }
                          />
                        </div>
                        <div className="space-y-1.5">
                          <Label>Lunch (hours, unpaid)</Label>
                          <Input
                            type="number"
                            min={0}
                            max={3}
                            step={0.25}
                            value={sh.lunchHours}
                            disabled={!isAdmin || !sh.enabled}
                            onChange={(e) =>
                              patchShift(sh.id, {
                                lunchHours: Number(e.target.value) || 0,
                              })
                            }
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              );
            })()}
            <div className="grid sm:grid-cols-2 gap-3">
              {isAdmin && (
              <div className="space-y-1.5">
                <Label>Hourly rate ($)</Label>
                <Input
                  type="number"
                  value={settings.hourlyRate}
                  disabled={!isAdmin}
                  onChange={(e) =>
                    updateSettings({ hourlyRate: Number(e.target.value) || 0 })
                  }
                />
              </div>
              )}
              <div className="space-y-1.5">
                <Label>Max operations (OP slots)</Label>
                <Input
                  type="number"
                  min={MIN_OPERATIONS}
                  max={MAX_OPERATIONS}
                  value={maxOpsDraft}
                  disabled={!isAdmin}
                  onChange={(e) => setMaxOpsDraft(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Edit password</Label>
                <Input
                  type="password"
                  value={pw}
                  disabled={!isAdmin}
                  onChange={(e) => setPw(e.target.value)}
                />
              </div>
            </div>

            {isAdmin && (
              <div className="space-y-2">
                <Label>Bonus tiers (min efficiency → percentage)</Label>
                {tiers.map((tier, i) => (
                  <div key={i} className="flex gap-2">
                    <Input
                      type="number"
                      step="0.01"
                      value={tier.minEff}
                      onChange={(e) => {
                        const next = [...tiers];
                        next[i] = {
                          ...next[i],
                          minEff: Number(e.target.value),
                        };
                        setTiers(next);
                      }}
                      placeholder="Min eff (1 = 100%)"
                    />
                    <Input
                      type="number"
                      step="0.01"
                      value={tier.percentage}
                      onChange={(e) => {
                        const next = [...tiers];
                        next[i] = {
                          ...next[i],
                          percentage: Number(e.target.value),
                        };
                        setTiers(next);
                      }}
                      placeholder="% of pool"
                    />
                  </div>
                ))}
                <Button onClick={saveSettings}>Save settings</Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>


      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Help tips
            <HelpTip id="help-master" />
          </CardTitle>
          <CardDescription>
            Blue <strong>?</strong> icons explain buttons and areas. Hover or tap
            for details. Hide a tip when you know it — it stays hidden for you on
            this PC. Full how-to guide:{" "}
            <a href="/help" className="text-[var(--color-primary)] underline">
              How to use
            </a>
            .
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col sm:flex-row sm:items-center gap-3">
          <label className="inline-flex items-center gap-2 text-sm min-h-11">
            <input
              type="checkbox"
              className="h-4 w-4 accent-[var(--color-primary)]"
              checked={helpTips.tipsEnabled}
              onChange={(e) => helpTips.setShowTips(e.target.checked)}
            />
            Show help tip icons
          </label>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => {
              helpTips.showAllTips();
              toast.success("All help tips restored");
            }}
          >
            Show all tips again
          </Button>
          <span className="text-xs text-[var(--color-muted)]">
            {helpTips.hiddenCount
              ? `${helpTips.hiddenCount} tip(s) hidden for you`
              : "No tips hidden"}
          </span>
        </CardContent>
      </Card>

<Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5 text-[var(--color-primary)]" />
            Import historical quotes (Google Sheets)
            <HelpTip id="settings-import-quotes" />
          </CardTitle>
          <CardDescription>
            Export your Google Sheet <strong>DATABASE</strong> or{" "}
            <strong>Historical Quotes</strong> tab as CSV, then import here.
            Use <strong>Update existing</strong> to re-import and fix Machine % /
            Material % (keeps values like 1.1) and blank stock shapes (not forced
            to Round Stock — missing shape shows yellow).
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!isAdmin ? (
            <p className="text-sm text-[var(--color-muted)]">
              Admin only — switch to an admin account to import.
            </p>
          ) : (
            <>
              <ol className="text-sm text-[var(--color-muted)] list-decimal pl-5 space-y-1.5">
                <li>Open your Google Sheet with the old LCM data.</li>
                <li>
                  Open the <strong>DATABASE</strong> tab (or Historical Quotes).
                </li>
                <li>File → Download → Comma Separated Values (.csv).</li>
                <li>Upload that file below, preview, then Import.</li>
              </ol>

              <div className="grid sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>If part # + rev already exists</Label>
                  <Select
                    value={quoteImportMode}
                    onChange={(e) =>
                      setQuoteImportMode(e.target.value as QuoteImportMode)
                    }
                  >
                    <option value="update">Update existing (recommended)</option>
                    <option value="skip">Skip duplicates</option>
                    <option value="keep_both">Keep both rows</option>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>CSV file from Google Sheets</Label>
                  <Input
                    type="file"
                    accept=".csv,text/csv"
                    disabled={quoteImportBusy}
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) void handleQuoteCsvPreview(f);
                      e.target.value = "";
                    }}
                  />
                </div>
              </div>

              {quotePreview && (
                <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 text-sm space-y-2">
                  <div className="font-medium">
                    Preview: {quotePreview.count} part row(s)
                    <span className="text-[var(--color-muted)] font-normal">
                      {" "}
                      · app currently has {quotes.length} quotes
                    </span>
                  </div>
                  <ul className="text-xs text-[var(--color-muted)] space-y-0.5 font-mono max-h-40 overflow-y-auto">
                    {quotePreview.sample.map((s) => (
                      <li key={s}>{s}</li>
                    ))}
                    {quotePreview.count > 8 && (
                      <li>…and {quotePreview.count - 8} more</li>
                    )}
                  </ul>
                  {quotePreview.errors.map((err) => (
                    <p key={err} className="text-xs text-[var(--color-warn)]">
                      {err}
                    </p>
                  ))}
                </div>
              )}

              {quoteImportResult && (
                <p className="text-sm text-[var(--color-success)]">
                  {quoteImportResult}
                </p>
              )}

              <div className="flex flex-wrap gap-2">
                <Button
                  onClick={runQuoteImport}
                  disabled={quoteImportBusy || !quotePreview?.count}
                >
                  <Upload className="h-4 w-4" />
                  {quoteImportBusy ? "Working…" : "Import into database"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    const blob = new Blob([downloadSampleCsv()], {
                      type: "text/csv",
                    });
                    const a = document.createElement("a");
                    a.href = URL.createObjectURL(blob);
                    a.download = "lcm-historical-quotes-sample.csv";
                    a.click();
                    URL.revokeObjectURL(a.href);
                  }}
                >
                  <Download className="h-4 w-4" /> Sample CSV format
                </Button>
              </div>
              <p className="text-[11px] text-[var(--color-subtle)] leading-relaxed">
                Tip: use Export JSON under Backup first. Times can be HH:MM:SS or
                decimal minutes. Machine % / Material % use 1 = cost, 1.25 = 25%
                markup (same as the old sheet).
              </p>
            </>
          )}
        </CardContent>
      </Card>


      
      <Card>
        <CardHeader>
          <CardTitle>Company logo</CardTitle>
          <CardDescription>
            Upload your real logo (PNG or JPG). Used on Sales Orders, the sidebar,
            and printouts. Stored on the shop host under{" "}
            <code className="text-xs">data/branding/</code> so app updates do not
            wipe it.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!isAdmin ? (
            <p className="text-sm text-[var(--color-muted)]">
              Admin only — switch to an admin account to change the logo.
            </p>
          ) : (
            <>
              <div className="flex flex-wrap items-center gap-6">
                <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-white p-4 min-w-[10rem]">
                  <div className="text-[10px] uppercase tracking-wide text-neutral-500 mb-2">
                    Print / light
                  </div>
                  <CompanyLogo variant="wide" className="h-14 w-auto max-w-[220px]" />
                </div>
                <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-4 min-w-[8rem]">
                  <div className="text-[10px] uppercase tracking-wide text-[var(--color-muted)] mb-2">
                    App header
                  </div>
                  <CompanyLogo
                    variant="mark"
                    invertFallback
                    className="h-12 w-12"
                  />
                </div>
                <div className="text-sm text-[var(--color-muted)] space-y-1">
                  {logoInfo.hasLogo ? (
                    <>
                      <div className="text-[var(--color-fg)] font-medium">
                        Custom logo active
                      </div>
                      <div className="text-xs">{logoInfo.name || "logo file"}</div>
                    </>
                  ) : (
                    <div>Using built-in art until you upload.</div>
                  )}
                </div>
              </div>
              <div className="flex flex-wrap gap-2 items-center">
                <input
                  ref={logoFileRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/svg+xml,.png,.jpg,.jpeg,.webp,.svg"
                  className="hidden"
                  onChange={(e) => {
                    void handleLogoFile(e.target.files?.[0] || null);
                  }}
                />
                <Button
                  type="button"
                  disabled={logoBusy}
                  onClick={() => logoFileRef.current?.click()}
                >
                  <Upload className="h-4 w-4" />
                  {logoBusy ? "Uploading…" : "Upload logo"}
                </Button>
                {logoInfo.hasLogo && (
                  <Button
                    type="button"
                    variant="outline"
                    disabled={logoBusy}
                    onClick={async () => {
                      setLogoBusy(true);
                      try {
                        await clearCompanyLogo();
                        await refreshLogoInfo();
                        notifyLogoChanged();
                        toast.message("Custom logo removed — using built-in art");
                      } finally {
                        setLogoBusy(false);
                      }
                    }}
                  >
                    Remove custom logo
                  </Button>
                )}
              </div>
              <p className="text-[11px] text-[var(--color-subtle)] leading-relaxed">
                Best: transparent PNG, wide letterhead style. Max 6 MB. Every shop
                PC uses this file from the host.
              </p>
            </>
          )}
        </CardContent>
      </Card>


      <Card>
        <CardHeader>
          <CardTitle>App mode · Beta / Production</CardTitle>
          <CardDescription>
            First shop rollout should stay in <strong>Beta</strong>. Timers,
            quotes, inventory, and orders work for real. Bonuses still{" "}
            <em>calculate and show</em>, but you cannot mark them paid until you
            switch to Production.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!isAdmin ? (
            <p className="text-sm text-[var(--color-muted)]">
              Admin only — ask an admin to change app mode.
            </p>
          ) : (
            <>
              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  className={
                    "rounded-full px-4 py-2 text-sm font-semibold border min-h-11 " +
                    (settings.betaMode !== false
                      ? "border-amber-500/60 bg-amber-500/15 text-amber-200"
                      : "border-[var(--color-border)] text-[var(--color-muted)]")
                  }
                  onClick={() => {
                    updateSettings({ betaMode: true });
                    addAudit(currentUserEmail, "App mode", "Beta enabled");
                    toast.message("Beta mode on — bonuses are practice only");
                  }}
                >
                  Beta (test)
                </button>
                <button
                  type="button"
                  className={
                    "rounded-full px-4 py-2 text-sm font-semibold border min-h-11 " +
                    (settings.betaMode === false
                      ? "border-[color-mix(in_oklab,var(--color-success)_50%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-success)_12%,transparent)] text-[var(--color-success)]"
                      : "border-[var(--color-border)] text-[var(--color-muted)]")
                  }
                  onClick={() => {
                    if (
                      !confirm(
                        "Switch to Production? Weekly bonus Mark paid will count as real payouts.",
                      )
                    ) {
                      return;
                    }
                    updateSettings({ betaMode: false });
                    addAudit(currentUserEmail, "App mode", "Production enabled");
                    toast.success("Production mode — bonuses can be marked paid");
                  }}
                >
                  Production (live)
                </button>
              </div>
              <p className="text-sm text-[var(--color-fg)]">
                Current:{" "}
                <strong>
                  {settings.betaMode !== false ? "Beta (test)" : "Production (live)"}
                </strong>
              </p>
              <ul className="text-xs text-[var(--color-muted)] list-disc pl-5 space-y-1">
                <li>
                  <strong>Beta</strong> — train the crew, import POs, run timers.
                  Bonus $ amounts show for practice but Mark paid is locked.
                </li>
                <li>
                  <strong>Production</strong> — same app, real weekly bonus
                  payouts allowed.
                </li>
              </ul>
            </>
          )}
        </CardContent>
      </Card>


      <Card>
        <CardHeader>
          <CardTitle>Backup & reset</CardTitle>
          <CardDescription>
            Export is a full JSON backup. On the host, also back up data/lcm-shop.json.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button variant="secondary" onClick={handleExport}>
            <Download className="h-4 w-4" /> Export JSON
          </Button>
          <Button variant="outline" onClick={() => fileRef.current?.click()}>
            <Upload className="h-4 w-4" /> Import JSON
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json,.json"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleImport(f);
              e.target.value = "";
            }}
          />
          {isAdmin && (
            <div className="w-full space-y-2 border-t border-[var(--color-border)] pt-3 mt-1">
              <p className="text-xs text-[var(--color-danger)] font-medium">
                Danger: reset wipes live shop data on every PC. Type RESET to enable.
              </p>
              <div className="flex flex-wrap gap-2 items-center">
                <Input
                  className="max-w-[10rem] font-mono"
                  placeholder="Type RESET"
                  value={resetTyped}
                  onChange={(e) => setResetTyped(e.target.value)}
                />
                <Button
                  variant="danger"
                  disabled={resetTyped !== "RESET"}
                  onClick={() => {
                    void createShopBackup({
                      data: {
                        label: "pre-reset",
                        token: getShopToken() || undefined,
                      },
                    });
                    resetToSeed();
                    addAudit(currentUserEmail, "Reset", "Seed data restored");
                    toast.message("Reset to seed — will sync to all PCs");
                    setResetTyped("");
                  }}
                >
                  <RotateCcw className="h-4 w-4" /> Reset demo data
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Host backups</CardTitle>
          <CardDescription>
            Copies of the live shop database on the office/host PC (last 30,
            plus one every hour when the shop is saving). Unlock with your PIN
            on this PC first. Restore only when you mean it — a safety copy is
            taken first.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-xs text-[var(--color-muted)] leading-relaxed">
            If LCM will not open at all, on the host PC open{" "}
            <Link to="/recover" className="underline text-[var(--color-primary)]">
              Recover shop
            </Link>{" "}
            or copy the files in{" "}
            <span className="font-mono">
              {backupFolder || "data/backups"}
            </span>
            . Download a copy to a USB stick whenever you want one off the
            machine.
          </p>
          {backupAuthError && (
            <p className="text-xs text-[var(--color-danger)]">{backupAuthError}</p>
          )}
          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              variant="secondary"
              disabled={backupBusy || !isAdmin}
              onClick={async () => {
                if (!needBackupSession()) return;
                setBackupBusy(true);
                try {
                  const r = await createShopBackup({
                    data: {
                      label: "manual",
                      token: getShopToken() || undefined,
                    },
                  });
                  if (!r.ok) toast.error(r.error || "Backup failed");
                  else {
                    toast.success("Backup created on host");
                    await refreshBackups();
                  }
                } finally {
                  setBackupBusy(false);
                }
              }}
            >
              Backup now
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                if (!getShopToken()) {
                  needBackupSession();
                  return;
                }
                void refreshBackups();
              }}
            >
              Refresh list
            </Button>
          </div>
          <div className="max-h-48 overflow-y-auto space-y-1.5 text-sm">
            {backups.length === 0 && !backupAuthError && (
              <p className="text-[var(--color-muted)] text-xs">
                No backups yet — unlock, then hit Backup now.
              </p>
            )}
            {backups.slice(0, 12).map((b) => (
              <div
                key={b.id}
                className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-[var(--color-border)] px-2 py-1.5"
              >
                <div className="min-w-0 text-xs">
                  <div className="font-medium truncate">
                    {new Date(b.createdAt).toLocaleString()} · {b.label}
                  </div>
                  <div className="text-[var(--color-muted)]">
                    rev {b.rev ?? "?"} · {(b.sizeBytes / 1024).toFixed(0)} KB
                  </div>
                </div>
                {isAdmin && (
                  <div className="flex flex-wrap gap-1">
                    <Button
                      size="sm"
                      variant="outline"
                      type="button"
                      disabled={backupBusy}
                      onClick={() => void downloadBackupFile(b.fileName)}
                    >
                      <Download className="h-3.5 w-3.5" />
                      Download
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      type="button"
                      disabled={backupBusy}
                      onClick={async () => {
                        if (!needBackupSession()) return;
                        if (
                          !confirm(
                            `Restore backup from ${new Date(b.createdAt).toLocaleString()}? Current data will be snapshotted first.`,
                          )
                        )
                          return;
                        setBackupBusy(true);
                        try {
                          const r = await restoreShopBackup({
                            data: {
                              fileName: b.fileName,
                              token: getShopToken() || undefined,
                            },
                          });
                          if (!r.ok) toast.error(r.error || "Restore failed");
                          else {
                            toast.success("Restored — reload the page");
                            window.location.reload();
                          }
                        } finally {
                          setBackupBusy(false);
                        }
                      }}
                    >
                      Restore
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Shop average rules</CardTitle>
          <CardDescription>
            How completed jobs update process times on the part (prices never
            auto-change).
          </CardDescription>
        </CardHeader>
        <CardContent className="grid sm:grid-cols-3 gap-3">
          <div className="space-y-1.5">
            <Label>Runs in average (max)</Label>
            <Input
              type="number"
              min={1}
              max={50}
              value={avgMax}
              disabled={!isAdmin}
              onChange={(e) => setAvgMax(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Shop weight (0–1)</Label>
            <Input
              type="number"
              step="0.1"
              min={0}
              max={1}
              value={avgWeight}
              disabled={!isAdmin}
              onChange={(e) => setAvgWeight(e.target.value)}
            />
            <p className="text-[10px] text-[var(--color-muted)]">
              0.7 = 70% shop avg + 30% prior recipe
            </p>
          </div>
          <div className="space-y-1.5">
            <Label>Outlier limit (× quote)</Label>
            <Input
              type="number"
              step="0.1"
              min={1}
              value={avgOutlier}
              disabled={!isAdmin}
              onChange={(e) => setAvgOutlier(e.target.value)}
            />
            <p className="text-[10px] text-[var(--color-muted)]">
              Runs slower than this × quoted time are skipped
            </p>
          </div>
          {isAdmin && (
            <Button type="button" onClick={saveAverageRules} className="sm:col-span-3 w-fit">
              Save average rules
            </Button>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent audit log</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 max-h-64 overflow-y-auto text-sm">
          {auditLog.slice(0, 40).map((a) => (
            <div
              key={a.id}
              className="flex justify-between gap-3 border-b border-[var(--color-border)] pb-1.5 last:border-0"
            >
              <div className="min-w-0">
                <div className="font-medium truncate">{a.action}</div>
                <div className="text-xs text-[var(--color-muted)] truncate">
                  {a.user} · {a.details}
                </div>
              </div>
              <div className="text-[10px] text-[var(--color-subtle)] shrink-0">
                {new Date(a.timestamp).toLocaleString()}
              </div>
            </div>
          ))}
          {auditLog.length === 0 && (
            <p className="text-[var(--color-muted)] py-4 text-center">No events</p>
          )}
        </CardContent>
      </Card>

      {updateDialogOpen && isAdmin && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
          onClick={() => !updateBusy && setUpdateDialogOpen(false)}
        >
          <div
            className="w-full max-w-md rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 shadow-xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div>
              <h3 className="text-lg font-semibold">Install app update</h3>
              <p className="text-sm text-[var(--color-muted)] mt-1">
                Select the <strong>lcm-update-…zip</strong> file you downloaded.
                Your shop database will not be replaced. A host backup is created
                first when possible.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label>Update package</Label>
              <Input
                ref={updateFileRef}
                type="file"
                accept=".zip,application/zip"
                disabled={updateBusy}
                onChange={(e) => {
                  const f = e.target.files?.[0] || null;
                  setPendingUpdateFile(f);
                }}
              />
              {pendingUpdateFile && (
                <p className="text-xs text-[var(--color-muted)]">
                  Selected: {pendingUpdateFile.name} (
                  {(pendingUpdateFile.size / 1024).toFixed(0)} KB)
                </p>
              )}
            </div>
            <div className="flex justify-end gap-2">
              <Button
                type="button"
                variant="outline"
                disabled={updateBusy}
                onClick={() => {
                  setUpdateDialogOpen(false);
                  setPendingUpdateFile(null);
                }}
              >
                Cancel
              </Button>
              <Button
                type="button"
                disabled={updateBusy || !pendingUpdateFile}
                onClick={() => void runAppUpdate()}
              >
                <PackageCheck className="h-4 w-4" />
                {updateBusy ? "Installing…" : "Install update"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
