/** Brother QL-810W — paper names match the Windows print dropdown. */

export const QL_TAPES = [
  {
    id: "dk2210",
    label: "DK-2210 1.1 x 1.4 in",
    w: "1.1in",
    h: "1.4in",
    kind: "continuous" as const,
    windowsPaper: "1.1 x 0.6",
  },
] as const;

export type QlTapeId = (typeof QL_TAPES)[number]["id"];
export type QlTape = (typeof QL_TAPES)[number];

const TAPE_STORE_KEY = "lcm-ql-tape";
const DPI = 300;

export function tapeById(id: string): QlTape {
  return QL_TAPES.find((t) => t.id === id) || QL_TAPES[0]!;
}

export function loadSavedTapeId(): QlTapeId {
  if (typeof window === "undefined") return "dk2210";
  try {
    const v = localStorage.getItem(TAPE_STORE_KEY) || "";
    if (QL_TAPES.some((t) => t.id === v)) return v as QlTapeId;
  } catch {
    /* ignore */
  }
  return "dk2210";
}

export function saveTapeId(id: string) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(TAPE_STORE_KEY, id);
  } catch {
    /* ignore */
  }
}

function esc(s: string) {
  return String(s || "")
    .replace(/&/g, "\u0026amp;")
    .replace(/</g, "\u0026lt;")
    .replace(/>/g, "\u0026gt;")
    .replace(/"/g, "\u0026quot;");
}

export type StockLabelItem = {
  barcode: string;
  qrDataUrl: string;
  line1: string;
  line2: string;
  line3?: string;
};

export function isCompactTape(tape: Pick<QlTape, "w" | "h" | "kind">) {
  return parseFloat(tape.w) <= 1.15;
}

function loadImg(src: string): Promise<HTMLImageElement | null> {
  if (!src) return Promise.resolve(null);
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

function breakLong(ctx: CanvasRenderingContext2D, word: string, maxW: number): string[] {
  if (ctx.measureText(word).width <= maxW) return [word];
  const out: string[] = [];
  let cur = "";
  for (const ch of word) {
    const trial = cur + ch;
    if (ctx.measureText(trial).width <= maxW) cur = trial;
    else {
      if (cur) out.push(cur);
      cur = ch;
    }
  }
  if (cur) out.push(cur);
  return out.length ? out : [word];
}

function wrapText(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxW: number,
): string[] {
  const words = String(text || "").split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let cur = "";
  for (const w of words) {
    const parts = breakLong(ctx, w, maxW);
    for (const part of parts) {
      const trial = cur ? cur + " " + part : part;
      if (ctx.measureText(trial).width <= maxW) {
        cur = trial;
      } else {
        if (cur) lines.push(cur);
        cur = part;
      }
    }
  }
  if (cur) lines.push(cur);
  return lines.length ? lines : [""];
}

export async function renderLabelPng(
  item: StockLabelItem,
  tape: QlTape,
): Promise<string> {
  const wIn = parseFloat(tape.w);
  const hIn = parseFloat(tape.h);
  const w = Math.max(1, Math.round(wIn * DPI));
  const h = Math.max(1, Math.round(hIn * DPI));
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not draw label");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = "#000000";
  ctx.textBaseline = "top";

  const pad = Math.round(0.05 * DPI);
  const qrImg = await loadImg(item.qrDataUrl);
  const stacked = true;

  if (stacked) {
    const qrSize = Math.round(Math.min(w - pad * 2, h * 0.48));
    const qx = Math.round((w - qrSize) / 2);
    const qy = pad;
    if (qrImg) ctx.drawImage(qrImg, qx, qy, qrSize, qrSize);
    else {
      ctx.strokeStyle = "#000";
      ctx.strokeRect(qx, qy, qrSize, qrSize);
    }
    let y = qy + qrSize + Math.round(0.04 * DPI);
    const maxW = w - pad * 2;
    ctx.font = "700 " + Math.round(0.09 * DPI) + "px Consolas, monospace";
    for (const line of wrapText(ctx, item.barcode, maxW)) {
      ctx.fillText(line, pad, y);
      y += Math.round(0.11 * DPI);
    }
    ctx.font = "800 " + Math.round(0.08 * DPI) + "px Arial, Helvetica, sans-serif";
    for (const line of wrapText(ctx, item.line1, maxW)) {
      ctx.fillText(line, pad, y);
      y += Math.round(0.1 * DPI);
    }
    ctx.font = "700 " + Math.round(0.075 * DPI) + "px Arial, Helvetica, sans-serif";
    for (const line of wrapText(ctx, item.line2, maxW)) {
      ctx.fillText(line, pad, y);
      y += Math.round(0.095 * DPI);
    }
    if (item.line3) {
      ctx.font = "600 " + Math.round(0.065 * DPI) + "px Arial, Helvetica, sans-serif";
      for (const line of wrapText(ctx, item.line3, maxW)) {
        ctx.fillText(line, pad, y);
        y += Math.round(0.085 * DPI);
      }
    }
  } else {
    const qrSize = Math.round(Math.min(h - pad * 2, w * 0.48));
    if (qrImg) ctx.drawImage(qrImg, pad, Math.round((h - qrSize) / 2), qrSize, qrSize);
    const tx = pad + qrSize + Math.round(0.03 * DPI);
    const maxW = w - tx - pad;
    const lineH = Math.max(14, Math.round(h / 4.2));
    let y = Math.round((h - lineH * 3.1) / 2);
    ctx.font = "800 " + Math.round(lineH * 0.72) + "px Consolas, monospace";
    for (const line of wrapText(ctx, item.barcode, maxW).slice(0, 1)) {
      ctx.fillText(line, tx, y);
      y += lineH;
    }
    ctx.font = "800 " + Math.round(lineH * 0.68) + "px Arial, Helvetica, sans-serif";
    for (const line of wrapText(ctx, item.line1, maxW).slice(0, 2)) {
      ctx.fillText(line, tx, y);
      y += lineH;
    }
    ctx.font = "700 " + Math.round(lineH * 0.64) + "px Arial, Helvetica, sans-serif";
    for (const line of wrapText(ctx, item.line2, maxW).slice(0, 2)) {
      ctx.fillText(line, tx, y);
      y += lineH;
    }
  }
  return canvas.toDataURL("image/png");
}

function openPrintHtml(html: string): { ok: boolean; error?: string } {
  if (typeof document === "undefined") {
    return { ok: false, error: "Print is only available in the app window" };
  }
  const blob = new Blob([html], { type: "text/html" });
  const url = URL.createObjectURL(blob);
  const win = window.open(url, "lcm-ql-label", "width=480,height=320,menubar=no,toolbar=no");
  if (!win) {
    URL.revokeObjectURL(url);
    return {
      ok: false,
      error: "Allow pop-ups for this site — the app must open a small sticker window, not print the whole page.",
    };
  }
  const start = () => {
    try {
      win.focus();
      win.print();
    } catch {
      /* ignore */
    }
    window.setTimeout(() => URL.revokeObjectURL(url), 8000);
  };
  win.addEventListener("load", () => window.setTimeout(start, 250));
  window.setTimeout(start, 800);
  return { ok: true };
}

function printSheetHtml(tape: QlTape, pngs: string[], title: string) {
  const w = tape.w;
  const h = tape.h;
  const imgs = pngs
    .map((src) => '<img class="sticker" src="' + src + '" alt=""/>')
    .join("");
  return (
    "<!doctype html><html><head><meta charset=\"utf-8\"/><title>" +
    esc(title) +
    "</title><style>" +
    "@page { size: " +
    w +
    " " +
    h +
    "; margin: 0; }" +
    "html, body { margin: 0; padding: 0; background: #fff; width: " +
    w +
    "; height: " +
    h +
    "; }" +
    "img.sticker { width: " +
    w +
    "; height: " +
    h +
    "; display: block; page-break-after: always; break-after: page; }" +
    "img.sticker:last-child { page-break-after: auto; }" +
    "</style></head><body>" +
    imgs +
    "</body></html>"
  );
}

export async function printBrotherSampleLabel(opts: {
  tapeId: string;
  barcode: string;
  qrDataUrl: string;
  line1: string;
  line2: string;
}): Promise<{ ok: boolean; error?: string }> {
  return printBrotherStockLabels(opts.tapeId, [
    {
      barcode: opts.barcode,
      qrDataUrl: opts.qrDataUrl,
      line1: opts.line1,
      line2: opts.line2,
    },
  ]);
}

export async function printBrotherStockLabels(
  tapeId: string,
  items: StockLabelItem[],
): Promise<{ ok: boolean; error?: string }> {
  if (!items.length) return { ok: false, error: "No labels to print" };
  if (typeof document === "undefined") {
    return { ok: false, error: "Print is only available in the app window" };
  }
  const tape = tapeById(tapeId);
  try {
    const pngs: string[] = [];
    for (const item of items) pngs.push(await renderLabelPng(item, tape));
    const title = items.length === 1 ? items[0]!.barcode : String(items.length) + " stock labels";
    return openPrintHtml(printSheetHtml(tape, pngs, title));
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not draw label" };
  }
}

export async function downloadLabelPng(opts: {
  tapeId: string;
  barcode: string;
  qrDataUrl: string;
  line1: string;
  line2: string;
  line3?: string;
}): Promise<{ ok: boolean; error?: string }> {
  if (typeof document === "undefined") {
    return { ok: false, error: "Save is only available in the app window" };
  }
  try {
    const tape = tapeById(opts.tapeId);
    const png = await renderLabelPng(
      {
        barcode: opts.barcode,
        qrDataUrl: opts.qrDataUrl,
        line1: opts.line1,
        line2: opts.line2,
        line3: opts.line3,
      },
      tape,
    );
    const a = document.createElement("a");
    a.href = png;
    a.download = (opts.barcode || "label") + ".png";
    a.click();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not save PNG" };
  }
}

const QL_PRINTABLE_W = 306;

export async function renderLabelMono(opts: {
  tapeId: string;
  barcode: string;
  qrDataUrl: string;
  line1: string;
  line2: string;
  line3?: string;
}): Promise<{ width: number; height: number; pixelsB64: string }> {
  if (typeof document === "undefined") {
    throw new Error("Label draw is only available in the app window");
  }
  const tape = tapeById(opts.tapeId);
  const png = await renderLabelPng(
    {
      barcode: opts.barcode,
      qrDataUrl: opts.qrDataUrl,
      line1: opts.line1,
      line2: opts.line2,
      line3: opts.line3,
    },
    tape,
  );
  const img = await loadImg(png);
  const h = Math.max(150, Math.round(parseFloat(tape.h) * 300));
  const canvas = document.createElement("canvas");
  canvas.width = QL_PRINTABLE_W;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not draw label");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, QL_PRINTABLE_W, h);
  if (img) ctx.drawImage(img, 0, 0, QL_PRINTABLE_W, h);
  const data = ctx.getImageData(0, 0, QL_PRINTABLE_W, h).data;
  const pixels = new Uint8Array(QL_PRINTABLE_W * h);
  for (let i = 0; i < pixels.length; i++) {
    const o = i * 4;
    const lum = (data[o] || 0) + (data[o + 1] || 0) + (data[o + 2] || 0);
    pixels[i] = lum < 384 ? 1 : 0;
  }
  let bin = "";
  for (let i = 0; i < pixels.length; i++) bin += String.fromCharCode(pixels[i]!);
  return { width: QL_PRINTABLE_W, height: h, pixelsB64: btoa(bin) };
}
