import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { BookOpen, ExternalLink, ListTree, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { useLcmStore } from "@/store/lcm-store";
import { getOperatorByEmail, operatorCanAccessTab } from "@/lib/lcm/permissions";
import {
  SHOP_GUIDE,
  type GuideChapter,
  type GuideSection,
} from "@/lib/lcm/shop-guide";

export const Route = createFileRoute("/help")({
  component: HelpTutorialPage,
});

function chapterVisible(
  ch: GuideChapter,
  isAdmin: boolean,
  canTab: (tab: NonNullable<GuideChapter["tab"]>) => boolean,
) {
  const aud = ch.audience || "all";
  if (aud === "admin" && !isAdmin) return false;
  if (aud === "floor" && isAdmin) return false;
  if (!isAdmin && ch.tab && !canTab(ch.tab)) return false;
  return true;
}

function filterGuide(
  isAdmin: boolean,
  canTab: (tab: NonNullable<GuideChapter["tab"]>) => boolean,
  q: string,
): GuideSection[] {
  const needle = q.trim().toLowerCase();
  return SHOP_GUIDE.map((sec) => {
    if (sec.audience === "admin" && !isAdmin) return null;
    const chapters = sec.chapters.filter((ch) => {
      if (!chapterVisible(ch, isAdmin, canTab)) return false;
      if (!needle) return true;
      const blob = [
        sec.title,
        ch.title,
        ch.intro,
        ...ch.steps.flatMap((s) => [s.title, ...s.body]),
        ...(ch.notes || []),
      ]
        .join(" ")
        .toLowerCase();
      return blob.includes(needle);
    });
    if (!chapters.length) return null;
    return { ...sec, chapters };
  }).filter((s): s is GuideSection => !!s);
}

function HelpTutorialPage() {
  const operators = useLcmStore((s) => s.operators);
  const email = useLcmStore((s) => s.currentUserEmail);
  const me = useMemo(
    () => getOperatorByEmail(operators, email),
    [operators, email],
  );
  const isAdmin = me?.role === "admin";
  const canTab = (tab: NonNullable<GuideChapter["tab"]>) =>
    !me || operatorCanAccessTab(me, tab);

  const [query, setQuery] = useState("");
  const [openId, setOpenId] = useState<string>("what-lcm-is");

  const sections = useMemo(
    () => filterGuide(isAdmin, canTab, query),
    [isAdmin, me, query],
  );

  useEffect(() => {
    const hash = typeof window !== "undefined" ? window.location.hash.slice(1) : "";
    if (hash) setOpenId(hash);
  }, []);

  useEffect(() => {
    const still = sections.some((s) => s.chapters.some((c) => c.id === openId));
    if (!still) {
      const first = sections[0]?.chapters[0]?.id;
      if (first) setOpenId(first);
    }
  }, [sections, openId]);

  function jump(id: string) {
    setOpenId(id);
    if (typeof window !== "undefined") {
      window.history.replaceState(null, "", `#${id}`);
      document.getElementById(`guide-${id}`)?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  }

  return (
    <div className="mx-auto max-w-6xl pb-16">
      <div className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight flex items-center gap-2">
          <BookOpen className="h-7 w-7 text-[var(--color-primary)]" />
          How to use this system
        </h1>
        <p className="text-sm text-[var(--color-muted)] mt-2 max-w-3xl leading-relaxed">
          Step-by-step for every screen. Work top to bottom the first time, or
          jump a section when you already know the shop.{" "}
          {isAdmin
            ? "This login includes office chapters (quotes, reports, settings, backups)."
            : "This login is the floor guide — prices, markups, and bonus setup stay with office."}
        </p>
        <div className="flex flex-wrap gap-1.5 mt-3">
          <Badge tone="hold">Hold</Badge>
          <Badge tone="open">Open</Badge>
          <Badge tone="soon">Due soon</Badge>
          <Badge tone="overdue">Overdue</Badge>
          <Badge tone="active">Active</Badge>
          <Badge tone="ready">Ready</Badge>
          <Badge tone="done">Done</Badge>
          <Badge tone="danger">Problem</Badge>
          {isAdmin && <Badge tone="office">Office</Badge>}
        </div>
        <div className="relative mt-4 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--color-muted)]" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search the manual — label, saw, receive…"
            className="pl-9 h-11"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[240px_minmax(0,1fr)] gap-6 items-start">
        <nav className="lg:sticky lg:top-4 space-y-4 print:hidden">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <ListTree className="h-4 w-4 text-[var(--color-primary)]" />
                Sections
              </CardTitle>
              <CardDescription>Tap a chapter to jump.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 max-h-[70vh] overflow-y-auto pr-1">
              {sections.map((sec) => (
                <div key={sec.id}>
                  <div className="text-[11px] font-semibold uppercase tracking-wide text-[var(--color-muted)] mb-1">
                    {sec.title}
                  </div>
                  <ul className="space-y-0.5">
                    {sec.chapters.map((ch) => (
                      <li key={ch.id}>
                        <button
                          type="button"
                          onClick={() => jump(ch.id)}
                          className={cn(
                            "w-full text-left text-sm rounded-[var(--radius-sm)] px-2 py-1.5 min-h-9",
                            openId === ch.id
                              ? "bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)] text-[var(--color-fg)] font-medium"
                              : "text-[var(--color-muted)] hover:bg-[var(--color-surface-2)] hover:text-[var(--color-fg)]",
                          )}
                        >
                          {ch.title}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
              {sections.length === 0 && (
                <p className="text-sm text-[var(--color-muted)]">
                  Nothing matches that search.
                </p>
              )}
            </CardContent>
          </Card>
        </nav>

        <div className="space-y-8 min-w-0">
          {sections.map((sec) => (
            <section key={sec.id} className="space-y-4">
              <div>
                <h2 className="text-xl font-semibold tracking-tight">
                  {sec.title}
                </h2>
                <p className="text-sm text-[var(--color-muted)] mt-1">
                  {sec.blurb}
                </p>
              </div>
              {sec.chapters.map((ch) => (
                <Card
                  key={ch.id}
                  id={`guide-${ch.id}`}
                  className={cn(
                    "scroll-mt-4",
                    openId === ch.id &&
                      "ring-1 ring-[color-mix(in_oklab,var(--color-primary)_45%,transparent)]",
                  )}
                >
                  <CardHeader className="pb-3 border-b border-[var(--color-border)]">
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                      <div>
                        <CardTitle className="text-lg">{ch.title}</CardTitle>
                        <CardDescription className="mt-1.5 leading-relaxed">
                          {ch.intro}
                        </CardDescription>
                      </div>
                      {ch.path ? (
                        <Link
                          to={ch.path as "/"}
                          className="inline-flex items-center gap-1.5 text-sm text-[var(--color-primary)] font-medium hover:underline shrink-0 min-h-11"
                        >
                          Open this screen
                          <ExternalLink className="h-3.5 w-3.5" />
                        </Link>
                      ) : null}
                    </div>
                  </CardHeader>
                  <CardContent className="p-4 sm:p-5 space-y-5">
                    <ol className="space-y-5">
                      {ch.steps.map((step, i) => (
                        <li key={step.title} className="flex gap-3">
                          <span className="shrink-0 mt-0.5 h-7 w-7 rounded-full bg-[var(--color-surface-2)] border border-[var(--color-border)] text-xs font-semibold tabular flex items-center justify-center">
                            {i + 1}
                          </span>
                          <div className="min-w-0">
                            <h3 className="font-semibold text-sm sm:text-base">
                              {step.title}
                            </h3>
                            <ul className="mt-1.5 space-y-1.5 text-sm text-[var(--color-fg)]/90 leading-relaxed">
                              {step.body.map((line) => (
                                <li key={line} className="pl-0">
                                  {line}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </li>
                      ))}
                    </ol>
                    {ch.notes && ch.notes.length > 0 ? (
                      <div className="rounded-[var(--radius-md)] border border-[color-mix(in_oklab,var(--color-status-hold)_35%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-status-hold)_10%,transparent)] px-3 py-2.5 text-sm">
                        <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-status-hold)] mb-1">
                          Keep in mind
                        </div>
                        {ch.notes.map((n) => (
                          <p
                            key={n}
                            className="text-[var(--color-fg)]/90 leading-relaxed"
                          >
                            {n}
                          </p>
                        ))}
                      </div>
                    ) : null}
                  </CardContent>
                </Card>
              ))}
            </section>
          ))}

          {sections.length > 0 ? (
            <div className="flex justify-end print:hidden">
              <Button
                type="button"
                variant="outline"
                onClick={() =>
                  typeof window !== "undefined" && window.scrollTo({ top: 0 })
                }
              >
                Back to top
              </Button>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
