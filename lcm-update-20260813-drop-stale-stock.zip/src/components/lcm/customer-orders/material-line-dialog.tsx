import { useEffect, useRef } from "react";
import { CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import { CreatableSelect } from "@/components/ui/creatable-select";
import { Typeahead } from "@/components/ui/typeahead";
import { SmartNumberInput } from "@/components/ui/smart-number-input";
import {
  allMaterialTypes,
  allMaterials,
  allStockShapes,
} from "@/lib/lcm/lists";
import {
  listMaterialStockCandidates,
  estimateMaterialUnits,
  formatSizeNote,
  stockCrossSection,
  findMaterialStockMatch,
  stockMatchesRecipe,
} from "@/lib/lcm/po-material";
import {
  stockSizeNoteOptions,
  stockSizeNoteHint,
} from "@/lib/lcm/stock-size-catalog";
import { isSheetOrPlate } from "@/lib/lcm/stock-shapes";
import type {
  AppSettings,
  CustomLists,
  MaterialStock,
  ShopOrder,
  ShopOrderLine,
} from "@/lib/lcm/types";

export function MaterialLineDialog({
  selected,
  lineId,
  materialStock,
  customLists,
  settings,
  updateLine,
  setShopLineMaterialReviewed,
  onClose,
}: {
  selected: ShopOrder;
  lineId: string;
  materialStock: MaterialStock[];
  customLists: CustomLists;
  settings: AppSettings;
  updateLine: (lineId: string, patch: Partial<ShopOrderLine>) => void;
  setShopLineMaterialReviewed: (
    orderId: string,
    lineId: string,
    reviewed: boolean,
  ) => void;
  onClose: () => void;
}) {
  const line = selected.lines.find((l) => l.id === lineId);
  const want = {
    stockShape: line?.stockShape,
    sizeNote: line?.sizeNote,
    dimX: line?.dimX,
    dimY: line?.dimY,
    dimZ: line?.dimZ,
  };
  const liveMatch = findMaterialStockMatch(materialStock, {
    material: line?.material || "",
    materialType: line?.materialType || "",
    stockShape: line?.stockShape || "",
    sizeNote: line?.sizeNote,
    dimX: line?.dimX,
    dimY: line?.dimY,
    dimZ: line?.dimZ,
    preferredId: "",
  });
  const savedRow = materialStock.find((s) => s.id === line?.materialStockId);
  const savedOk = Boolean(
    line && savedRow && stockMatchesRecipe(savedRow, want),
  );
  const shownStock = savedOk ? savedRow : liveMatch;
  const clearedRef = useRef(false);
  useEffect(() => {
    if (!line || clearedRef.current) return;
    if (line.materialStockId && !savedOk) {
      clearedRef.current = true;
      updateLine(line.id, {
        materialStockId: liveMatch?.id || "",
        materialOnHand: liveMatch?.onHand ?? 0,
        materialLocation: liveMatch?.location || "",
        materialReviewed: false,
      });
    }
  }, [line, savedOk, liveMatch, updateLine]);

  if (!line) return null;

  const typeOpts = allMaterialTypes(
    line.material || "Aluminum",
    customLists,
  );
  const candidates = listMaterialStockCandidates(
  materialStock,
  line.material || "",
  line.materialType || "",
  {
    stockShape: line.stockShape,
    sizeNote: line.sizeNote,
    dimX: line.dimX,
    dimY: line.dimY,
    dimZ: line.dimZ,
  },
);
const est = estimateMaterialUnits({
  orderQty: line.qty,
  partLengthEach: line.partLengthEach || 0,
  rawMaterialLength: line.rawMaterialLength || 0,
  stockShape: line.stockShape,
});
const shape = (line.stockShape || "").toLowerCase();
const sheetPlate = isSheetOrPlate(line.stockShape);
const isRect =
  !sheetPlate &&
  (shape.includes("rect") ||
    (shape.includes("flat") && !shape.includes("sheet") && !shape.includes("plate")) ||
    (shape.includes("square") && !shape.includes("tube")));
const isRound =
  !sheetPlate &&
  !isRect &&
  ((shape.includes("round") && !shape.includes("tube")) ||
    shape.includes("hex") ||
    !shape);
const materialOptions = allMaterials(customLists);
const stockShapeOptions = allStockShapes(customLists);
const sizeOpts = stockSizeNoteOptions({
  material: line.material,
  materialType: line.materialType,
  stockShape: line.stockShape,
  customNotes: settings.customLists?.sizeNotes || [],
});
return (
  <div
    className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-black/60 p-4 print:hidden"
    onClick={() => onClose()}
  >
    <div
      className="relative z-[71] w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 space-y-3 shadow-xl"
      onClick={(e) => e.stopPropagation()}
    >
      <h2 className="text-lg font-semibold">
        Material for {line.partNumber || "line"}{" "}
        <span className="text-sm font-normal text-[var(--color-muted)]">
          rev {line.revision || "—"} · order qty {line.qty}
        </span>
      </h2>
      <p className="text-sm text-[var(--color-muted)]">
        Looks up this P/N in the part database for{" "}
        <strong>last-used stock</strong>, then matches that recipe to
        inventory and tells you if you need to buy more. Edit only if
        the last run was wrong.
      </p>

      <div className="grid sm:grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label>Material</Label>
          <CreatableSelect
            value={line.material || ""}
            options={materialOptions}
            onChange={(v) =>
              updateLine(line.id, {
                material: v,
                materialStockId: "",
                materialReviewed: false,
              })
            }
            onCreate={(v) =>
              updateLine(line.id, {
                material: v,
                materialStockId: "",
                materialReviewed: false,
              })
            }
            createTitle="Add material"
          />
        </div>
        <div className="space-y-1.5">
          <Label>Material type</Label>
          <CreatableSelect
            value={line.materialType || ""}
            options={typeOpts}
            onChange={(v) =>
              updateLine(line.id, {
                materialType: v,
                materialStockId: "",
                materialReviewed: false,
              })
            }
            onCreate={(v) =>
              updateLine(line.id, {
                materialType: v,
                materialStockId: "",
                materialReviewed: false,
              })
            }
            createTitle="Add type"
          />
        </div>
        <div className="space-y-1.5">
          <Label>Stock shape</Label>
          <CreatableSelect
            value={line.stockShape || ""}
            options={stockShapeOptions}
            onChange={(v) =>
              updateLine(line.id, {
                stockShape: v,
                dimX: 0,
                dimY: 0,
                dimZ: 0,
                sizeNote: "",
                materialStockId: "",
                materialReviewed: false,
              })
            }
            onCreate={(v) =>
              updateLine(line.id, {
                stockShape: v,
                dimX: 0,
                dimY: 0,
                dimZ: 0,
                sizeNote: "",
                materialStockId: "",
                materialReviewed: false,
              })
            }
            createTitle="Add shape"
          />
        </div>
        <div className="space-y-1.5">
          <Label>Size note</Label>
          <Typeahead
            value={line.sizeNote || ""}
            options={sizeOpts}
            placeholder={'Type to filter — e.g. 0.5 × 1'}
            maxSuggestions={40}
            onChange={(v) => {
              const parsed = stockCrossSection({
                stockShape: line.stockShape,
                sizeNote: v,
              });
              updateLine(line.id, {
                sizeNote: v,
                dimX: parsed.dia || parsed.thk || 0,
                dimY: isSheetOrPlate(line.stockShape) || parsed.width
                  ? parsed.width
                  : 0,
                dimZ: parsed.length || 0,
                materialStockId: "",
                materialReviewed: false,
              });
            }}
          />
          <p className="text-[10px] text-[var(--color-subtle)]">
            {stockSizeNoteHint(line.stockShape)}
          </p>
        </div>
      </div>

      <div className="rounded-md border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-2">
        <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">
          {sheetPlate
            ? "Sheet / plate size — thickness first, then blank if you know it"
            : "Cross-section size (match inventory) — leave blank until known"}
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div className="space-y-1">
            <Label className="text-[10px]">
              {sheetPlate
                ? 'Thickness (")'
                : isRound
                  ? 'Dia (")'
                  : 'Thickness / X (")'}
            </Label>
            <SmartNumberInput
              format="inches"
              value={line.dimX || 0}
              placeholder="e.g. 0.5"
              onValueChange={(dimX) => {
                updateLine(line.id, {
                  dimX,
                  sizeNote: formatSizeNote({
                    sizeNote: "",
                    dimX,
                    dimY: line.dimY,
                    dimZ: line.dimZ,
                    stockShape: line.stockShape,
                  }),
                  materialStockId: "",
                  materialReviewed: false,
                });
              }}
            />
          </div>
          <div className="space-y-1">
            <Label className="text-[10px]">
              {sheetPlate
                ? 'Blank width (")'
                : isRound
                  ? "Y (n/a)"
                  : 'Width / Y (")'}
            </Label>
            <SmartNumberInput
              format="inches"
              disabled={isRound}
              value={isRound ? 0 : line.dimY || 0}
              placeholder={isRound ? "—" : sheetPlate ? "e.g. 10" : "e.g. 1"}
              onValueChange={(dimY) => {
                updateLine(line.id, {
                  dimY,
                  sizeNote: formatSizeNote({
                    sizeNote: "",
                    dimX: line.dimX,
                    dimY,
                    dimZ: line.dimZ,
                    stockShape: line.stockShape,
                  }),
                  materialStockId: "",
                  materialReviewed: false,
                });
              }}
            />
          </div>
          <div className="space-y-1">
            <Label className="text-[10px]">
              {sheetPlate
                ? 'Blank length (")'
                : isRound || isRect
                  ? 'Bar length Z (")'
                  : 'Z / length (")'}
            </Label>
            <SmartNumberInput
              format="inches"
              value={line.dimZ || 0}
              placeholder="e.g. 144"
              onValueChange={(dimZ) => {
                updateLine(line.id, {
                  dimZ,
                  rawMaterialLength: sheetPlate
                    ? line.rawMaterialLength
                    : dimZ > 0
                      ? dimZ
                      : line.rawMaterialLength,
                  sizeNote: formatSizeNote({
                    sizeNote: "",
                    dimX: line.dimX,
                    dimY: line.dimY,
                    dimZ,
                    stockShape: line.stockShape,
                  }),
                  materialStockId: "",
                  materialNeeded: 0,
                  materialReviewed: false,
                });
              }}
            />
          </div>
        </div>
        <p className="text-[10px] text-[var(--color-subtle)]">
          {sheetPlate
            ? "Example: 0.5\" thick plate, 10\" × 12\" blank. Buy qty is 1 blank per part — not bar math."
            : isRound
              ? "Round: diameter + bar length (e.g. 3\" dia × 144\"). Y is not used."
              : 'Example rectangular: 0.5" thick × 1" wide × 144" bar. Fields stay empty until you type (no default 1s).'}
        </p>
      </div>

      <div className="rounded-md border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-2">
        <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">
          How much stock is needed
        </div>
        {sheetPlate ? (
          <>
            <div className="grid sm:grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label className="text-[10px]">Order qty</Label>
                <div className="h-10 flex items-center text-sm px-2 rounded-md border border-[var(--color-border)]">
                  {line.qty} pcs
                </div>
              </div>
              <div className="space-y-1">
                <Label className="text-[10px]">
                  Blanks / pieces needed (auto)
                </Label>
                <SmartNumberInput
                  value={
                    sheetPlate && !line.materialReviewed
                      ? est.needed
                      : line.materialNeeded > 0
                        ? line.materialNeeded
                        : est.needed
                  }
                  placeholder="auto"
                  onValueChange={(materialNeeded) =>
                    updateLine(line.id, {
                      materialNeeded,
                      materialReviewed: false,
                    })
                  }
                />
              </div>
            </div>
            <p className="text-[11px] text-[var(--color-muted)] leading-snug">
              <strong className="text-[var(--color-fg)]">Math:</strong>{" "}
              <span className="font-mono text-[var(--color-fg)]">
                {est.formula}
              </span>
            </p>
            <p className="text-[10px] text-[var(--color-subtle)]">
              One blank per part. If you nest more than one on a sheet,
              type the real piece count. Leave at auto (or 0) to follow
              order qty.
            </p>
          </>
        ) : (
          <>
            <div className="grid sm:grid-cols-3 gap-2">
              <div className="space-y-1">
                <Label className="text-[10px]">
                  Part cut length each (")
                </Label>
                <SmartNumberInput
                  format="inches"
                  value={line.partLengthEach || 0}
                  placeholder="e.g. 1"
                  onValueChange={(partLengthEach) =>
                    updateLine(line.id, {
                      partLengthEach,
                      materialNeeded: 0,
                      materialReviewed: false,
                    })
                  }
                />
              </div>
              <div className="space-y-1">
                <Label className="text-[10px]">
                  Stock bar length (")
                </Label>
                <SmartNumberInput
                  format="inches"
                  value={line.rawMaterialLength || 0}
                  placeholder="e.g. 144"
                  onValueChange={(rawMaterialLength) =>
                    updateLine(line.id, {
                      rawMaterialLength,
                      materialNeeded: 0,
                      materialReviewed: false,
                    })
                  }
                />
              </div>
              <div className="space-y-1">
                <Label className="text-[10px]">
                  Whole bars needed (auto)
                </Label>
                <SmartNumberInput
                  value={
                    line.materialNeeded > 0
                      ? line.materialNeeded
                      : est.needed
                  }
                  placeholder="auto"
                  onValueChange={(materialNeeded) =>
                    updateLine(line.id, {
                      materialNeeded,
                      materialReviewed: false,
                    })
                  }
                />
              </div>
            </div>
            <p className="text-[11px] text-[var(--color-muted)] leading-snug">
              <strong className="text-[var(--color-fg)]">Math:</strong>{" "}
              <span className="font-mono text-[var(--color-fg)]">
                {est.formula}
              </span>
              {est.totalInches > 0 ? (
                <>
                  {" "}
                  · total cut{" "}
                  <strong>{est.totalInches}"</strong>
                  {est.needed > 0
                    ? ` · pull ${est.needed} full bar(s) from rack`
                    : ""}
                </>
              ) : null}
            </p>
            <p className="text-[10px] text-[var(--color-subtle)]">
              Example: 20 parts × 1" cut ÷ 144" bar = 0.14 →{" "}
              <strong>1 bar</strong> (not 20). Leave “bars needed” at 0 to
              keep auto-calc.
            </p>
          </>
        )}
      </div>

      <div className="space-y-1.5">
        <Label>Inventory row (matched stock)</Label>
        <Select
          value={shownStock?.id || ""}
          onChange={(e) => {
            const id = e.target.value;
            const row = materialStock.find((s) => s.id === id);
            if (!row) {
              updateLine(line.id, {
                materialStockId: "",
                materialReviewed: false,
              });
              return;
            }
            updateLine(line.id, {
              materialStockId: row.id,
              material: row.material,
              materialType: row.materialType,
              stockShape: row.stockShape,
              sizeNote: row.sizeNote,
              dimX: row.dimX,
              dimY: row.dimY,
              dimZ: row.dimZ,
              materialOnHand: row.onHand,
              materialLocation: row.location,
              rawMaterialLength: sheetPlate
                ? 0
                : row.dimZ || line.rawMaterialLength || 0,
              materialNeeded: 0,
              materialReviewed: false,
            });
          }}
        >
          <option value="">
            {candidates.length
              ? "— Best match first — pick if wrong —"
              : "— No inventory for this material / size —"}
          </option>
          {candidates.map((s, idx) => (
            <option key={s.id} value={s.id}>
              {(shownStock?.id === s.id && stockMatchesRecipe(s, want)
                ? "★ "
                : idx === 0 && stockMatchesRecipe(s, want)
                  ? "Best: "
                  : "") +
                (s.sizeNote ||
                  `${s.dimX || "?"}${s.dimY ? " × " + s.dimY : ""}" ${s.stockShape}`) +
                ` · ${s.materialType}` +
                ` · on hand ${s.onHand} ${s.unit}` +
                (s.location ? ` @ ${s.location}` : "")}
            </option>
          ))}
        </Select>
        <p className="text-[11px] text-[var(--color-muted)]">
          Matched from <strong>last-used part recipe</strong> in the
          database, then checked against inventory. On hand:{" "}
          <strong>{shownStock?.onHand ?? 0}</strong>
          {shownStock?.location ? ` @ ${shownStock.location}` : ""}
          {!shownStock && line.material ? (
            <>
              {" "}
              ·{" "}
              <strong className="text-[var(--color-warn)]">
                No {line.sizeNote || `${line.dimX || ""}"`} in inventory —
                buy {line.materialNeeded || est.needed || line.qty}
              </strong>
            </>
          ) : (line.materialNeeded || 0) > (shownStock?.onHand || 0) ? (
            <>
              {" "}
              ·{" "}
              <strong className="text-[var(--color-warn)]">
                Buy{" "}
                {(line.materialNeeded || 0) - (shownStock?.onHand || 0)}{" "}
                more
              </strong>
            </>
          ) : null}
          {" · "}
          Finished parts: <strong>{line.finishedOnHand ?? 0}</strong>
        </p>
        {!candidates.length && line.material && (
          <p className="text-[11px] text-amber-800">
            No inventory item for this material yet — add it under
            Inventory, or Mark OK after you plan a buy.
          </p>
        )}
      </div>

      {(!shownStock && line.material) || line.attentionReason ? (
        <div className="rounded-md border border-[color-mix(in_oklab,var(--color-warn)_40%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-warn)_12%,transparent)] px-3 py-2 text-xs text-[var(--color-fg)]">
          {!shownStock && line.material
            ? `Last-used ${line.sizeNote || `${line.dimX || "?"}"`} is not in inventory. Other sizes of the same alloy on the rack do not count — buy this size.`
            : line.attentionReason}
        </div>
      ) : null}

      <div className="flex flex-wrap justify-end gap-2 pt-1">
        <Button
          variant="ghost"
          type="button"
          onClick={() => onClose()}
        >
          Close
        </Button>
        <Button
          type="button"
          onClick={() => {
            // force re-resolve with current fields
            updateLine(line.id, {
              materialNeeded: line.materialNeeded || 0,
            });
            setShopLineMaterialReviewed(selected.id, line.id, true);
            onClose();
            toast.success("Marked material OK for this line");
          }}
        >
          <CheckCircle2 className="h-4 w-4" /> Mark OK
        </Button>
      </div>
    </div>
  </div>
  );
}
