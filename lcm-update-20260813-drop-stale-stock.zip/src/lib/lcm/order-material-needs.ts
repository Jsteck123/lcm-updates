import type {
  MaterialStock,
  ShopOrder,
  ShopOrderLine,
  VendorRfq,
} from "./types";
import { estimateMaterialUnits } from "./po-material";
import { isSheetOrPlate } from "./stock-shapes";
import { shopLineOpenQty } from "./po";
import { materialLabel } from "./inventory";

export function isCustomerSuppliedMaterial(line: {
  material?: string;
  materialType?: string;
  stockShape?: string;
  notes?: string;
}): boolean {
  const blob = [
    line.material,
    line.materialType,
    line.stockShape,
    line.notes,
  ]
    .join(" ")
    .toLowerCase();
  return (
    blob.includes("customer supplied") ||
    blob.includes("customer-supplied") ||
    blob.includes("cust supplied") ||
    blob.includes("c/s material") ||
    blob.includes("supplied by customer")
  );
}

function norm(s: string): string {
  return (s || "").trim().toLowerCase().replace(/\s+/g, " ");
}

export function stockNeedKey(opts: {
  material: string;
  materialType: string;
  stockShape: string;
  sizeNote: string;
}): string {
  return [
    norm(opts.material),
    norm(opts.materialType),
    norm(opts.stockShape),
    norm(opts.sizeNote),
  ].join("|");
}

export type OrderBuyRow = {
  key: string;
  material: string;
  materialType: string;
  stockShape: string;
  sizeNote: string;
  qtyNeeded: number;
  onHand: number;
  toBuy: number;
  unit: "sheet" | "bar" | "pcs";
  partNumbers: string[];
  customerSupplied: boolean;
  missingSize: boolean;
};

export function computeShopOrderBuyList(
  order: ShopOrder | null | undefined,
  materialStock: MaterialStock[],
): OrderBuyRow[] {
  if (!order) return [];
  const map = new Map<string, OrderBuyRow>();

  for (const line of order.lines || []) {
    if (line.lineStatus === "cancelled") continue;
    const open = shopLineOpenQty(line);
    if (open <= 0) continue;
    if (!line.material?.trim()) continue;

    const supplied = isCustomerSuppliedMaterial(line);
    const shape = line.stockShape || "";
    const sheet = isSheetOrPlate(shape);
    const needed =
      line.materialNeeded > 0
        ? line.materialNeeded
        : estimateMaterialUnits({
            orderQty: open,
            partLengthEach: line.partLengthEach || 0,
            rawMaterialLength: line.rawMaterialLength || 0,
            stockShape: shape,
          }).needed || open;

    const sizeNote = (line.sizeNote || "").trim();
    const key = stockNeedKey({
      material: line.material,
      materialType: line.materialType || "",
      stockShape: shape,
      sizeNote,
    });

    const onHand = (materialStock || [])
      .filter(
        (s) =>
          stockNeedKey({
            material: s.material,
            materialType: s.materialType,
            stockShape: s.stockShape,
            sizeNote: s.sizeNote,
          }) === key ||
          (norm(s.material) === norm(line.material) &&
            norm(s.materialType) === norm(line.materialType || "") &&
            norm(s.stockShape) === norm(shape) &&
            !sizeNote),
      )
      .reduce((n, s) => n + (s.onHand || 0), 0);

    const prev = map.get(key);
    const pn = line.partNumber || "";
    if (prev) {
      prev.qtyNeeded += needed;
      prev.onHand = Math.max(prev.onHand, onHand);
      prev.toBuy = Math.max(0, prev.qtyNeeded - prev.onHand);
      if (pn && !prev.partNumbers.includes(pn)) prev.partNumbers.push(pn);
      prev.missingSize = prev.missingSize && !sizeNote;
      continue;
    }
    map.set(key, {
      key,
      material: line.material,
      materialType: line.materialType || "",
      stockShape: shape,
      sizeNote,
      qtyNeeded: needed,
      onHand,
      toBuy: supplied ? 0 : Math.max(0, needed - onHand),
      unit: sheet ? "sheet" : "bar",
      partNumbers: pn ? [pn] : [],
      customerSupplied: supplied,
      missingSize: !sizeNote && !(line.dimX > 0),
    });
  }

  return [...map.values()].sort((a, b) => {
    if (a.customerSupplied !== b.customerSupplied)
      return a.customerSupplied ? 1 : -1;
    return b.toBuy - a.toBuy || a.material.localeCompare(b.material);
  });
}

export function rfqsForShopOrder(
  order: ShopOrder | null | undefined,
  rfqs: VendorRfq[],
): VendorRfq[] {
  if (!order) return [];
  const refs = new Set(
    [order.poNumber, order.id]
      .map((x) => (x || "").trim().toLowerCase())
      .filter(Boolean),
  );
  return (rfqs || []).filter((r) => {
    if (r.status === "cancelled") return false;
    const ref = (r.shopOrderRef || "").trim().toLowerCase();
    return ref && refs.has(ref);
  });
}

export { materialLabel };
