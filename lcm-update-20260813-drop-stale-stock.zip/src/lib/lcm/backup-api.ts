import { createServerFn } from "@tanstack/react-start";

export type BackupInfo = {
  id: string;
  fileName: string;
  createdAt: string;
  sizeBytes: number;
  rev: number | null;
  label: string;
};

async function requireAdmin(token?: string) {
  const { verifyShopToken } = await import("./shop-session.server");
  const session = verifyShopToken(token);
  if (!session) {
    return {
      ok: false as const,
      error: "Unlock with your admin PIN first (Switch user / PIN on this PC).",
    };
  }
  if (session.role !== "admin") {
    return { ok: false as const, error: "Admin only" };
  }
  return { ok: true as const, session };
}

export const listShopBackups = createServerFn({ method: "POST" })
  .validator((data: { token?: string } = {}) => data ?? {})
  .handler(async ({ data }) => {
    const gate = await requireAdmin(data?.token);
    if (!gate.ok) return gate;
    const { listBackups, backupFolderHint } = await import("./backup.server");
    return {
      ok: true as const,
      backups: listBackups() as BackupInfo[],
      folder: backupFolderHint(),
    };
  });

export const createShopBackup = createServerFn({ method: "POST" })
  .validator((data: { label?: string; token?: string }) => data || {})
  .handler(async ({ data }) => {
    const gate = await requireAdmin(data?.token);
    if (!gate.ok) return gate;
    const { createBackup } = await import("./backup.server");
    const b = createBackup(data?.label || "manual");
    if (!b) return { ok: false as const, error: "No shop database file yet" };
    return { ok: true as const, backup: b as BackupInfo };
  });

export const restoreShopBackup = createServerFn({ method: "POST" })
  .validator((data: { fileName: string; token?: string }) => data)
  .handler(async ({ data }) => {
    const gate = await requireAdmin(data?.token);
    if (!gate.ok) return gate;
    const { restoreBackup } = await import("./backup.server");
    return restoreBackup(data.fileName);
  });

export const downloadShopBackup = createServerFn({ method: "POST" })
  .validator((data: { fileName: string; token?: string }) => data)
  .handler(async ({ data }) => {
    const gate = await requireAdmin(data?.token);
    if (!gate.ok) return gate;
    const { readBackupFile } = await import("./backup.server");
    const file = readBackupFile(data.fileName);
    if (!file) return { ok: false as const, error: "Backup not found" };
    return {
      ok: true as const,
      fileName: file.fileName,
      json: file.json,
    };
  });
