import type { LcmState } from "./types";

/** Everything shared across all shop PCs (not per-station user). */
export type ShopSharedState = Pick<
  LcmState,
  | "operators"
  | "customers"
  | "quotes"
  | "jobs"
  | "downtimes"
  | "operatorTimeLog"
  | "auditLog"
  | "sessions"
  | "activeTimers"
  | "dayBonuses"
  | "weeklyPayouts"
  | "materialStock"
  | "partStock"
  | "partUnits"
  | "inventoryTxns"
  | "purchaseOrders"
  | "vendorRfqs"
  | "shopOrders"
  | "workQueue"
  | "cutTickets"
  | "stockPieces"
  | "quoteHistory"
  | "emailLog"
  | "poFollowups"
  | "chatMessages"
  | "shopToolingLogs"
  | "feedbackTickets"
  | "settings"
>;
