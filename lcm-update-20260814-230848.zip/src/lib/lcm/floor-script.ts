/**
 * Shop floor guided script for machine stations.
 * Happy path: You → Load → Jaws (opt) → Work → Done
 * Soft jaws is always optional (skip allowed).
 */
import type { ActiveTimer, MachineSession } from "./types";
import { opLabel } from "./ops";

export type FloorStepId =
  | "operator"
  | "load"
  | "stock"
  | "tooling"
  | "start"
  | "running"
  | "paused"
  | "finish";

/** Compact bar steps shown to operators (running/start share "Work"). */
export type FloorBarId =
  | "operator"
  | "load"
  | "stock"
  | "tooling"
  | "work"
  | "finish";

export type FloorStep = {
  id: FloorStepId;
  index: number;
  label: string;
  instruction: string;
  primaryLabel?: string;
  blockReason?: string;
  optional?: boolean;
};

const STEP_ORDER: FloorStepId[] = [
  "operator",
  "load",
  "stock",
  "tooling",
  "start",
  "running",
  "finish",
];

export function floorStepIndex(id: FloorStepId): number {
  if (id === "paused") return 4;
  return Math.max(0, STEP_ORDER.indexOf(id));
}

/** Map detailed step → bar chip */
export function toBarStep(id: FloorStepId): FloorBarId {
  if (id === "start" || id === "running" || id === "paused") return "work";
  if (id === "finish") return "finish";
  if (id === "tooling") return "tooling";
  if (id === "stock") return "stock";
  if (id === "load") return "load";
  return "operator";
}

export function barStepIndex(id: FloorBarId): number {
  const order: FloorBarId[] = [
    "operator",
    "load",
    "stock",
    "tooling",
    "work",
    "finish",
  ];
  return Math.max(0, order.indexOf(id));
}

export function nextOpHint(
  session: MachineSession | undefined,
  maxOps: number,
): { text: string; opIndex: number | null; kind: "Setup" | "Runtime" | null } {
  if (!session?.jobId) {
    return { text: "Load a job first", opIndex: null, kind: null };
  }
  const n = Math.max(session.setups?.length || 0, maxOps);
  const anyQuoted =
    session.quotedSetups?.some((v) => (v || 0) > 0) ||
    session.quotedRuntimes?.some((v) => (v || 0) > 0);
  for (let i = 0; i < n; i++) {
    const planned =
      !anyQuoted ||
      (session.quotedSetups[i] || 0) > 0 ||
      (session.quotedRuntimes[i] || 0) > 0 ||
      session.setups[i] != null ||
      session.runtimes[i] != null;
    if (!planned) continue;
    if (session.setups[i] == null) {
      return {
        text: `Start ${opLabel(i)} Setup (one-time)`,
        opIndex: i,
        kind: "Setup",
      };
    }
    if (session.runtimes[i] == null) {
      return {
        text: `Start ${opLabel(i)} Runtime (per piece)`,
        opIndex: i,
        kind: "Runtime",
      };
    }
  }
  return {
    text: "All operations timed — finish the job",
    opIndex: null,
    kind: null,
  };
}

export function hasStartedAnyOp(session: MachineSession | undefined): boolean {
  if (!session) return false;
  return (
    (session.setups || []).some((v) => v != null) ||
    (session.runtimes || []).some((v) => v != null)
  );
}

export function deriveFloorStep(opts: {
  session: MachineSession | undefined;
  timer: ActiveTimer | null | undefined;
  maxOps: number;
  toolingSkipped?: boolean;
  toolingRunning?: boolean;
  toolingLogged?: boolean;
  stockPicked?: boolean;
  stockSkipped?: boolean;
}): FloorStep {
  const {
    session,
    timer,
    maxOps,
    toolingSkipped = false,
    toolingRunning = false,
    toolingLogged = false,
    stockPicked = false,
    stockSkipped = false,
  } = opts;
  const hasOp = Boolean((session?.operatorName || "").trim());
  const hasJob = Boolean(session?.jobId);
  const opHint = nextOpHint(session, maxOps);
  const opsStarted = hasStartedAnyOp(session);

  if (!hasOp) {
    return {
      id: "operator",
      index: 0,
      label: "You",
      instruction: "Who is on this machine? Select yourself first.",
    };
  }
  if (!hasJob) {
    return {
      id: "load",
      index: 1,
      label: "Load job",
      instruction:
        "Load the next job from this machine’s queue (or search a part).",
      primaryLabel: machineQueuePrimaryLabel(),
    };
  }

  if (!stockPicked && !stockSkipped && !opsStarted && !timer) {
    return {
      id: "stock",
      index: 2,
      label: "Stock",
      instruction:
        "Pick or confirm stock. LOC is length of cut — the saw axis and how long that cut is (model 3\" → cut 3.1\"). Skip if office already set it.",
      primaryLabel: "Confirm stock",
      optional: true,
    };
  }

  // Timer always wins — keep eyes on the clock
  if (timer) {
    return {
      id: "running",
      index: 5,
      label: "Running",
      instruction: `${timer.type === "Setup" ? "Setup" : "Runtime"} · ${timer.operation} — stop when done.`,
      primaryLabel: "Stop timer",
    };
  }

  if (toolingRunning) {
    return {
      id: "tooling",
      index: 2,
      label: "Soft jaws",
      instruction:
        "Jaws timer is running. Stop it when done, then start part setup.",
      primaryLabel: "Stop jaws timer",
      optional: true,
    };
  }

  // Optional jaws only as a first prompt before any part timing.
  // After skip / first op, jaws stay available on the machine page anytime (OP2 etc.).
  if (!opsStarted && !toolingSkipped && !toolingLogged) {
    return {
      id: "tooling",
      index: 2,
      label: "Soft jaws",
      instruction:
        "Soft jaws now if you need them first — or skip and do jaws later (e.g. before OP2).",
      primaryLabel: "Skip for now — jaws later OK",
      optional: true,
    };
  }

  if (session?.paused) {
    return {
      id: "paused",
      index: 5,
      label: "Paused",
      instruction: opHint.kind
        ? `Paused. Resume with: ${opHint.text}`
        : "Paused. Resume, save for tomorrow, or finish if done.",
      primaryLabel: opHint.kind ? opHint.text : "Finish job",
    };
  }

  if (opHint.kind) {
    return {
      id: "start",
      index: 4,
      label: "Time work",
      instruction: opHint.text,
      primaryLabel: opHint.text,
    };
  }

  return {
    id: "finish",
    index: 5,
    label: "Finish",
    instruction:
      "All ops timed. Enter good qty and finish (or save in progress).",
    primaryLabel: "Finish job",
  };
}

function machineQueuePrimaryLabel() {
  return "Load next from queue";
}

export const FLOOR_SCRIPT_STEPS: {
  id: FloorBarId;
  short: string;
  optional?: boolean;
}[] = [
  { id: "operator", short: "You" },
  { id: "load", short: "Load" },
  { id: "stock", short: "Stock", optional: true },
  { id: "tooling", short: "Jaws", optional: true },
  { id: "work", short: "Work" },
  { id: "finish", short: "Done" },
];

export function effFeedback(eff: number): {
  tone: "good" | "ok" | "over";
  line: string;
} {
  const e = eff > 1.5 ? eff / 100 : eff;
  if (e >= 1.02) {
    return {
      tone: "good",
      line: `Under quoted time · ${Math.round(e * 100)}% job efficiency`,
    };
  }
  if (e >= 0.9) {
    return {
      tone: "ok",
      line: `Near quote · ${Math.round(e * 100)}% job efficiency`,
    };
  }
  return {
    tone: "over",
    line: `Over quoted time · ${Math.round(e * 100)}% job efficiency`,
  };
}
