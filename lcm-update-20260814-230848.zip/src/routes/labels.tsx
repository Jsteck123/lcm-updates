import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Printer } from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { Label, Select } from "@/components/ui/input";
import { barcodeToDataUrl, scanUrlForBarcode } from "@/lib/lcm/barcode";
import {
  QL_TAPES,
  loadSavedTapeId,
  printBrotherStockLabels,
  saveTapeId,
  tapeById,
} from "@/lib/lcm/brother-label-print";

export const Route = createFileRoute("/labels")({
  validateSearch: (search: Record<string, unknown>) => ({
    ids: typeof search.ids === "string" ? search.ids : "",
  }),
  component: LabelsPage,
});

function LabelsPage() {
  const { ids } = Route.useSearch();
  const stockPiecesRaw = useLcmStore((s) => s.stockPieces);
  const stockPieces = stockPiecesRaw || [];
  const shopPublicUrl = useLcmStore((s) => s.settings.shopPublicUrl);
  const [qrMap, setQrMap] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [tapeId, setTapeId] = useState(() => loadSavedTapeId());
  const tape = tapeById(tapeId);

  const selected = useMemo(() => {
    const idSet = new Set(
      ids
        .split(",")
        .map((x) => x.trim())
        .filter(Boolean),
    );
    if (idSet.size === 0) {
      const avail = stockPieces.filter((p) => p.status === "available");
      return avail.length ? avail : stockPieces;
    }
    return stockPieces.filter((p) => idSet.has(p.id) || idSet.has(p.barcode));
  }, [ids, stockPieces]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const next: Record<string, string> = {};
      await Promise.all(
        selected.map(async (p) => {
          const payload = scanUrlForBarcode(p.barcode, shopPublicUrl);
          next[p.id] = await barcodeToDataUrl(payload, 220);
        }),
      );
      if (!cancelled) setQrMap(next);
    })();
    return () => {
      cancelled = true;
    };
  }, [selected, shopPublicUrl]);

  function pickTape(id: string) {
    setTapeId(id as ReturnType<typeof loadSavedTapeId>);
    saveTapeId(id);
  }

  async function printAll() {
    const missing = selected.filter((p) => !qrMap[p.id]);
    if (missing.length) {
      toast.error("Wait for barcodes to finish drawing");
      return;
    }
    setBusy(true);
    const r = await printBrotherStockLabels(
      tapeId,
      selected.map((p) => ({
        barcode: p.barcode,
        qrDataUrl: qrMap[p.id] || "",
        line1: `${p.material} ${p.materialType}`.trim(),
        line2: p.sizeNote || `${p.originalLength}"`,
        line3: p.location ? `Loc ${p.location}` : "",
      })),
    );
    setBusy(false);
    if (!r.ok) toast.error(r.error || "Could not open print");
    else
      toast.message(
        `${selected.length} label${selected.length === 1 ? "" : "s"} — paper ${tape.windowsPaper}, Margins None, Scale 100%`,
      );
  }

  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            Stock barcode labels
          </h1>
          <p className="text-xs text-[var(--color-muted)]">
            Labels to print: {selected.length} · pieces in shop:{" "}
            {stockPieces.length}
          </p>
          <p className="text-sm text-[var(--color-muted)] mt-1">
            DK-2210 is the 1.1" × 100 ft continuous roll. In the print window
            In the print list pick <strong>1.1" x 1.6"</strong>. Set Brother Length to 1.60 to match.
          </p>
        </div>
        <div className="flex flex-wrap gap-2 items-end">
          <div className="space-y-1 min-w-56">
            <Label>Tape in the printer</Label>
            <Select
              className="h-11"
              value={tapeId}
              onChange={(e) => pickTape(e.target.value)}
            >
              {QL_TAPES.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.label}
                </option>
              ))}
            </Select>
          </div>
          <Button
            className="min-h-11"
            disabled={busy || selected.length === 0}
            onClick={() => void printAll()}
          >
            <Printer className="h-4 w-4" /> Print {selected.length} label
            {selected.length === 1 ? "" : "s"}
          </Button>
          <Link
            to="/sample-label"
            className="inline-flex items-center rounded-[var(--radius-md)] border border-[var(--color-border)] px-4 py-2.5 text-sm min-h-11"
          >
            Test print
          </Link>
          <Link
            to="/scan"
            search={{ c: "" }}
            className="inline-flex items-center rounded-[var(--radius-md)] border border-[var(--color-border)] px-4 py-2.5 text-sm min-h-11"
          >
            Scan page
          </Link>
        </div>
      </div>

      {selected.length === 0 ? (
        <p className="text-[var(--color-muted)]">
          No pieces to print. Receive material on a PO first, or add barcoded
          pieces under Inventory.
        </p>
      ) : (
        <div className="label-sheet">
          {selected.map((p) => (
            <div
              key={p.id}
              className="stock-label"
              style={{ width: tape.w, height: tape.h }}
            >
              {qrMap[p.id] ? (
                <img src={qrMap[p.id]} alt={p.barcode} className="label-qr" />
              ) : (
                <div className="label-qr placeholder" />
              )}
              <div className="label-text">
                <div className="label-code">{p.barcode}</div>
                <div className="label-mat">
                  {p.material} {p.materialType}
                </div>
                <div className="label-size">
                  {p.sizeNote || `${p.originalLength}"`}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <style>{`
        .label-sheet {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }
        .stock-label {
          border: 1px solid var(--color-border);
          display: flex;
          flex-direction: row;
          align-items: center;
          gap: 0.05in;
          padding: 0.05in 0.06in 0.05in 0.04in;
          box-sizing: border-box;
          background: #fff;
          color: #000;
          overflow: hidden;
        }
        .label-qr {
          width: 0.55in;
          height: 0.55in;
          object-fit: contain;
          flex-shrink: 0;
        }
        .label-qr.placeholder {
          background: #eee;
        }
        .label-text {
          min-width: 0;
          flex: 1;
          text-align: left;
          line-height: 1.08;
        }
        .label-code {
          font-family: ui-monospace, monospace;
          font-size: 10px;
          font-weight: 800;
          white-space: nowrap;
        }
        .label-mat {
          font-size: 9px;
          font-weight: 800;
        }
        .label-size {
          font-size: 8px;
          font-weight: 700;
        }
      `}</style>
    </div>
  );
}
