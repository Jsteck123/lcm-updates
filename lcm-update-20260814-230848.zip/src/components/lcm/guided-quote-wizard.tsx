/**
 * Guided Master Quoter — step-through for new quotes.
 * Order: Customer → P/N → Rev → Quote type → Material → Type → Stock shape
 * → Soft jaws → Machines → Setup/Runtime per OP → Qty breaks → Review
 */
import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import { SmartNumberInput } from "@/components/ui/smart-number-input";
import { CreatableSelect } from "@/components/ui/creatable-select";
import { MultiSelect } from "@/components/ui/multi-select";
import type { QuoteKind } from "@/lib/lcm/types";
import { opLabel } from "@/lib/lcm/ops";
import { GuidedMaterialForm } from "@/components/lcm/guided-material-form";
import type { LocAxis } from "@/lib/lcm/types";
import { cn } from "@/lib/utils";

export type GuidedQuoteDraft = {
  customer: string;
  partNumber: string;
  revision: string;
  kind: QuoteKind;
  material: string;
  materialType: string;
  stockShape: string;
  stockProcess: "" | "mill" | "lathe";
  dimX: number;
  dimY: number;
  dimZ: number;
  locAxis: LocAxis | "";
  partLengthEach: number;
  rawMaterialLength: number;
  softJaws: boolean;
  machines: string[];
  setupTimes: number[];
  runTimes: number[];
  quantities: number[];
  prices: number[];
};

type Props = {
  open: boolean;
  onClose: () => void;
  onApply: (draft: GuidedQuoteDraft) => void;
  maxOps: number;
  machineOptions: string[];
  materialOptions: string[];
  typeOptions: string[];
  shapeOptions: string[];
  customerOptions: string[];
  initial?: Partial<GuidedQuoteDraft>;
  onCreateCustomer?: (name: string) => boolean;
  onCreateMaterial?: (name: string) => boolean;
  onCreateType?: (name: string) => boolean;
  onCreateShape?: (name: string) => boolean;
  onCreateMachine?: (name: string) => boolean;
};

type StepId =
  | "customer"
  | "part"
  | "rev"
  | "kind"
  | "stock"
  | "softJaws"
  | "machines"
  | "ops"
  | "qty"
  | "review";

const STEPS: { id: StepId; title: string }[] = [
  { id: "customer", title: "Customer" },
  { id: "part", title: "Part number" },
  { id: "rev", title: "Revision" },
  { id: "kind", title: "Quote type" },
  { id: "stock", title: "Material & stock" },
  { id: "softJaws", title: "Soft jaws / tooling" },
  { id: "machines", title: "Machines" },
  { id: "ops", title: "Setup & runtime" },
  { id: "qty", title: "Quantity breaks" },
  { id: "review", title: "Review" },
];

function emptyDraft(maxOps: number, initial?: Partial<GuidedQuoteDraft>): GuidedQuoteDraft {
  return {
    customer: initial?.customer || "",
    partNumber: initial?.partNumber || "",
    revision: initial?.revision || "",
    kind: initial?.kind === "assembly" ? "assembly" : "part",
    material: initial?.material || "",
    materialType: initial?.materialType || "",
    stockShape: initial?.stockShape || "",
    stockProcess: initial?.stockProcess || "",
    dimX: initial?.dimX || 0,
    dimY: initial?.dimY || 0,
    dimZ: initial?.dimZ || 0,
    locAxis: initial?.locAxis || "",
    partLengthEach: initial?.partLengthEach || 0,
    rawMaterialLength: initial?.rawMaterialLength || 0,
    softJaws: Boolean(initial?.softJaws),
    machines: initial?.machines ? [...initial.machines] : [],
    setupTimes: initial?.setupTimes
      ? [...initial.setupTimes]
      : Array(maxOps).fill(0),
    runTimes: initial?.runTimes ? [...initial.runTimes] : Array(maxOps).fill(0),
    quantities: initial?.quantities?.length
      ? [...initial.quantities]
      : [1, 5, 10],
    prices: initial?.prices?.length ? [...initial.prices] : [0, 0, 0],
  };
}

export function GuidedQuoteWizard({
  open,
  onClose,
  onApply,
  maxOps,
  machineOptions,
  materialOptions,
  typeOptions,
  shapeOptions,
  customerOptions,
  initial,
  onCreateCustomer,
  onCreateMaterial,
  onCreateType,
  onCreateShape,
  onCreateMachine,
}: Props) {
  const [step, setStep] = useState(0);
  const [draft, setDraft] = useState(() => emptyDraft(maxOps, initial));
  const [opIndex, setOpIndex] = useState(0);
  const [opPhase, setOpPhase] = useState<"setup" | "runtime">("setup");

  useEffect(() => {
    if (!open) return;
    setStep(0);
    setOpIndex(0);
    setOpPhase("setup");
    setDraft(emptyDraft(maxOps, initial));
  }, [open, maxOps]); // eslint-disable-line react-hooks/exhaustive-deps

  const stepDef = STEPS[step]!;

  function next() {
    if (stepDef.id === "ops") {
      // advance setup → runtime → next op
      if (opPhase === "setup") {
        setOpPhase("runtime");
        return;
      }
      if (opIndex + 1 < maxOps) {
        setOpIndex((i) => i + 1);
        setOpPhase("setup");
        return;
      }
    }
    if (step < STEPS.length - 1) setStep((s) => s + 1);
  }

  function back() {
    if (stepDef.id === "ops") {
      if (opPhase === "runtime") {
        setOpPhase("setup");
        return;
      }
      if (opIndex > 0) {
        setOpIndex((i) => i - 1);
        setOpPhase("runtime");
        return;
      }
    }
    if (step > 0) setStep((s) => s - 1);
  }

  function finish() {
    onApply(draft);
    onClose();
  }

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-3 print:hidden"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-lg max-h-[92vh] overflow-y-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] shadow-xl p-4 space-y-4">
        <div className="flex items-start justify-between gap-2">
          <div>
            <h2 className="text-lg font-semibold">Guided quote</h2>
            <p className="text-xs text-[var(--color-muted)] mt-0.5">
              Step {step + 1} of {STEPS.length}: {stepDef.title}
              {stepDef.id === "ops"
                ? ` · ${opLabel(opIndex)} ${opPhase === "setup" ? "Setup" : "Runtime"}`
                : ""}
            </p>
          </div>
          <Button type="button" variant="ghost" size="sm" onClick={onClose}>
            Close
          </Button>
        </div>

        {/* progress dots */}
        <div className="flex flex-wrap gap-1">
          {STEPS.map((s, i) => (
            <div
              key={s.id}
              className={cn(
                "h-1.5 flex-1 min-w-[12px] rounded-full",
                i <= step
                  ? "bg-[var(--color-primary)]"
                  : "bg-[var(--color-surface-3)]",
              )}
            />
          ))}
        </div>

        <div className="min-h-[140px] space-y-3">
          {stepDef.id === "customer" && (
            <div className="space-y-1.5">
              <Label>Customer</Label>
              <CreatableSelect
                value={draft.customer}
                options={customerOptions}
                onChange={(v) => setDraft((d) => ({ ...d, customer: v }))}
                onCreate={(v) => {
                  if (onCreateCustomer && !onCreateCustomer(v)) return false;
                  setDraft((d) => ({ ...d, customer: v }));
                  return true;
                }}
                createTitle="Add customer"
                createHint="Saved for future quotes"
              />
            </div>
          )}
          {stepDef.id === "part" && (
            <div className="space-y-1.5">
              <Label>Part number</Label>
              <Input
                autoFocus
                value={draft.partNumber}
                onChange={(e) =>
                  setDraft((d) => ({
                    ...d,
                    partNumber: e.target.value.toUpperCase(),
                  }))
                }
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    next();
                  }
                }}
                placeholder="e.g. AF-4421"
              />
            </div>
          )}
          {stepDef.id === "rev" && (
            <div className="space-y-1.5">
              <Label>Revision</Label>
              <Input
                autoFocus
                value={draft.revision}
                onChange={(e) =>
                  setDraft((d) => ({
                    ...d,
                    revision: e.target.value.toUpperCase(),
                  }))
                }
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    next();
                  }
                }}
                placeholder="A"
              />
            </div>
          )}
          {stepDef.id === "kind" && (
            <div className="flex gap-2">
              {(["part", "assembly"] as const).map((k) => (
                <button
                  key={k}
                  type="button"
                  className={cn(
                    "flex-1 rounded-[var(--radius-md)] border px-3 py-3 text-sm font-semibold min-h-12",
                    draft.kind === k
                      ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)]"
                      : "border-[var(--color-border)]",
                  )}
                  onClick={() => setDraft((d) => ({ ...d, kind: k }))}
                >
                  {k === "part" ? "Part" : "Assembly"}
                </button>
              ))}
            </div>
          )}
          {stepDef.id === "stock" && (
            <GuidedMaterialForm
              mode="quote"
              machines={draft.machines}
              value={{
                material: draft.material,
                materialType: draft.materialType,
                stockShape: draft.stockShape,
                stockProcess: draft.stockProcess,
                dimX: draft.dimX,
                dimY: draft.dimY,
                dimZ: draft.dimZ,
                locAxis: draft.locAxis,
                rawMaterialLength: draft.rawMaterialLength,
                partLengthEach: draft.partLengthEach,
              }}
              onChange={(next) =>
                setDraft((d) => ({
                  ...d,
                  material: next.material,
                  materialType: next.materialType,
                  stockShape: next.stockShape,
                  stockProcess: next.stockProcess,
                  dimX: next.dimX,
                  dimY: next.dimY,
                  dimZ: next.dimZ,
                  locAxis: next.locAxis,
                  rawMaterialLength: next.rawMaterialLength,
                  partLengthEach: next.partLengthEach,
                }))
              }
              materialOptions={materialOptions}
              typeOptions={typeOptions}
              shapeOptions={shapeOptions}
              onCreateMaterial={onCreateMaterial}
              onCreateType={onCreateType}
              onCreateShape={onCreateShape}
            />
          )}
          {stepDef.id === "softJaws" && (
            <div className="space-y-2">
              <p className="text-sm text-[var(--color-muted)]">
                Soft jaws or special tools for this part? (You can add charges
                on the full form later.)
              </p>
              <div className="flex gap-2">
                {[true, false].map((v) => (
                  <button
                    key={String(v)}
                    type="button"
                    className={cn(
                      "flex-1 rounded-[var(--radius-md)] border px-3 py-3 text-sm font-semibold min-h-12",
                      draft.softJaws === v
                        ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)]"
                        : "border-[var(--color-border)]",
                    )}
                    onClick={() => setDraft((d) => ({ ...d, softJaws: v }))}
                  >
                    {v ? "Yes — need tooling" : "No"}
                  </button>
                ))}
              </div>
            </div>
          )}
          {stepDef.id === "machines" && (
            <div className="space-y-2">
              <Label>Machines that run this part</Label>
              <MultiSelect
                value={draft.machines}
                options={machineOptions}
                placeholder="Select one or more machines…"
                allowCreate
                allowReorder
                onChange={(next) => {
                  for (const name of next) {
                    if (
                      !machineOptions.some(
                        (o) => o.toLowerCase() === name.toLowerCase(),
                      )
                    ) {
                      onCreateMachine?.(name);
                    }
                  }
                  setDraft((d) => ({
                    ...d,
                    machines: next.map((s) => s.trim()).filter(Boolean),
                  }));
                }}
              />
              <p className="text-[11px] text-[var(--color-subtle)]">
                Check every machine this job may run on. First selected is preferred.
              </p>
            </div>
          )}
          {stepDef.id === "ops" && (
            <div className="space-y-2">
              <Label>
                {opLabel(opIndex)} {opPhase === "setup" ? "Setup" : "Runtime"}{" "}
                (minutes)
              </Label>
              <SmartNumberInput
                key={`${opIndex}-${opPhase}`}
                value={
                  opPhase === "setup"
                    ? draft.setupTimes[opIndex] || 0
                    : draft.runTimes[opIndex] || 0
                }
                onValueChange={(n) => {
                  setDraft((d) => {
                    if (opPhase === "setup") {
                      const setupTimes = [...d.setupTimes];
                      setupTimes[opIndex] = n || 0;
                      return { ...d, setupTimes };
                    }
                    const runTimes = [...d.runTimes];
                    runTimes[opIndex] = n || 0;
                    return { ...d, runTimes };
                  });
                }}
                format="plain"
                emptyMeans={0}
              />
              <p className="text-[11px] text-[var(--color-muted)]">
                Enter minutes, then Next. Field clears for the next op.
                Leave 0 if this op is not used.
              </p>
            </div>
          )}
          {stepDef.id === "qty" && (
            <div className="space-y-2">
              <Label>Quantity breaks</Label>
              {draft.quantities.map((q, i) => (
                <div key={i} className="flex gap-2 items-center">
                  <span className="text-xs text-[var(--color-muted)] w-10">
                    Qty
                  </span>
                  <SmartNumberInput
                    value={q}
                    onValueChange={(n) =>
                      setDraft((d) => {
                        const quantities = [...d.quantities];
                        quantities[i] = Math.max(1, n || 1);
                        return { ...d, quantities };
                      })
                    }
                    format="plain"
                  />
                  <span className="text-xs text-[var(--color-muted)]">@ $</span>
                  <SmartNumberInput
                    value={draft.prices[i] || 0}
                    onValueChange={(n) =>
                      setDraft((d) => {
                        const prices = [...d.prices];
                        prices[i] = n || 0;
                        return { ...d, prices };
                      })
                    }
                    format="currency"
                  />
                </div>
              ))}
            </div>
          )}
          {stepDef.id === "review" && (
            <div className="text-sm space-y-1 rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3">
              <div>
                <strong>{draft.partNumber || "—"}</strong> Rev{" "}
                {draft.revision || "—"} · {draft.kind}
              </div>
              <div>
                {draft.customer || "—"} · {draft.material} {draft.materialType}{" "}
                {draft.stockShape}
              </div>
              <div className="text-xs text-[var(--color-muted)]">
                Machines: {draft.machines.join(", ") || "—"}
                {draft.softJaws ? " · Soft jaws noted" : ""}
              </div>
              <div className="text-xs text-[var(--color-muted)]">
                Ops:{" "}
                {draft.setupTimes
                  .map((s, i) =>
                    s || draft.runTimes[i]
                      ? `${opLabel(i)} ${s}/${draft.runTimes[i] || 0}`
                      : null,
                  )
                  .filter(Boolean)
                  .join(" · ") || "none"}
              </div>
              <p className="text-[11px] text-[var(--color-muted)] pt-1">
                Apply fills the main form — review prices and save there.
              </p>
            </div>
          )}
        </div>

        <div className="flex gap-2 pt-1">
          <Button
            type="button"
            variant="outline"
            disabled={step === 0 && opIndex === 0 && opPhase === "setup"}
            onClick={back}
          >
            Back
          </Button>
          {stepDef.id === "review" ? (
            <Button type="button" className="flex-1" onClick={finish}>
              Apply to form
            </Button>
          ) : (
            <Button type="button" className="flex-1" onClick={next}>
              Next
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
