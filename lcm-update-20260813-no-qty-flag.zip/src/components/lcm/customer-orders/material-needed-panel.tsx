import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Mail, Send } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type {
  MaterialStock,
  ShopOrder,
  VendorRfq,
  VendorRfqLine,
} from "@/lib/lcm/types";
import {
  computeShopOrderBuyList,
  rfqsForShopOrder,
} from "@/lib/lcm/order-material-needs";
import { emptyVendorRfqLine, rfqEmailBody } from "@/lib/lcm/vendor-rfq";
import { isSheetOrPlate } from "@/lib/lcm/stock-shapes";

export function MaterialNeededPanel({
  order,
  materialStock,
  vendorRfqs,
  vendorNames,
  company,
  canSend,
  createVendorRfq,
  upsertVendorRfq,
}: {
  order: ShopOrder | null;
  materialStock: MaterialStock[];
  vendorRfqs: VendorRfq[];
  vendorNames: string[];
  company: string;
  canSend: boolean;
  createVendorRfq: (partial?: Partial<VendorRfq>) => VendorRfq;
  upsertVendorRfq: (rfq: VendorRfq) => void;
}) {
  const rows = computeShopOrderBuyList(order, materialStock);
  const linked = rfqsForShopOrder(order, vendorRfqs);
  const activeRfq = linked.find((r) => r.status !== "cancelled") || null;
  const buyRows = rows.filter((r) => !r.customerSupplied && r.toBuy > 0);
  const supplied = rows.filter((r) => r.customerSupplied);

  function sendBulkRfq() {
    if (!order) return;
    if (!buyRows.length) {
      toast.error("Nothing to buy on this PO");
      return;
    }
    const lines: VendorRfqLine[] = buyRows.map((r) =>
      emptyVendorRfqLine({
        material: r.material,
        materialType: r.materialType,
        stockShape: r.stockShape || "Round Stock",
        sizeNote: r.sizeNote,
        unit: isSheetOrPlate(r.stockShape) ? "sheet" : "bar",
        qty: r.toBuy,
        lengthEach: isSheetOrPlate(r.stockShape) ? 0 : 144,
        partNumber: r.partNumbers.join(", "),
        jobRef: order.poNumber,
        notes: r.missingSize ? "Size TBD — confirm before buying" : "",
      }),
    );
    const rfq =
      activeRfq && (activeRfq.status === "draft" || activeRfq.status === "sent")
        ? { ...activeRfq, lines, vendorsRequested: vendorNames, shopOrderRef: order.poNumber }
        : createVendorRfq({
            shopOrderRef: order.poNumber,
            customerQuoteRef: order.poNumber,
            notes: `Bulk RFQ for customer PO ${order.poNumber} · ${order.customer}`,
            vendorsRequested: vendorNames,
            lines,
            status: "draft",
          });
    upsertVendorRfq({ ...rfq, status: "sent" });
    const body = rfqEmailBody({
      companyName: company,
      rfq: { ...rfq, status: "sent" },
    });
    const vendorLine = vendorNames.length
      ? `Please quote. Sending to: ${vendorNames.join(", ")}\n\n`
      : "";
    const full = vendorLine + body;
    const subject = `${company} Material RFQ ${rfq.rfqNumber} — ${order.poNumber}`;
    const url = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(full)}`;
    if (url.length > 1800) {
      void navigator.clipboard.writeText(`${subject}\n\n${full}`);
      toast.message("RFQ copied — paste into one email and BCC your vendors");
    } else {
      window.location.href = url;
    }
    toast.success(`${rfq.rfqNumber} ready — send to vendors, then enter bids under Inventory → Vendor RFQs`);
  }

  if (!order) return null;

  return (
    <Card className="print:hidden">
      <CardHeader className="pb-2">
        <CardTitle className="text-base">
          Material for this PO · {order.poNumber}
        </CardTitle>
        <CardDescription>
          What this order still needs to buy. Customer-supplied is listed
          separately. Shop-wide buys stay under Inventory.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {rows.length === 0 && (
          <p className="text-sm text-[var(--color-muted)]">
            No material set on open lines yet — open a line and fill material.
          </p>
        )}

        {rows.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-[11px] uppercase tracking-wide text-[var(--color-muted)]">
                  <th className="py-1 pr-2 font-medium">Stock</th>
                  <th className="py-1 pr-2 font-medium">Parts</th>
                  <th className="py-1 pr-2 font-medium text-right">Need</th>
                  <th className="py-1 pr-2 font-medium text-right">On hand</th>
                  <th className="py-1 font-medium text-right">Buy</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr
                    key={r.key}
                    className="border-t border-[var(--color-border)]"
                  >
                    <td className="py-2 pr-2">
                      <div className="font-medium">
                        {r.material}
                        {r.materialType ? ` ${r.materialType}` : ""}
                      </div>
                      <div className="text-[11px] text-[var(--color-muted)]">
                        {r.stockShape || "—"}
                        {r.sizeNote ? ` · ${r.sizeNote}` : r.missingSize ? " · size missing" : ""}
                      </div>
                    </td>
                    <td className="py-2 pr-2 text-[11px] text-[var(--color-muted)]">
                      {r.partNumbers.join(", ") || "—"}
                    </td>
                    <td className="py-2 pr-2 text-right tabular-nums">
                      {Number.isInteger(r.qtyNeeded)
                        ? r.qtyNeeded
                        : r.qtyNeeded.toFixed(2)}{" "}
                      {r.unit}
                    </td>
                    <td className="py-2 pr-2 text-right tabular-nums">
                      {Number.isInteger(r.onHand)
                        ? r.onHand
                        : r.onHand.toFixed(2)}
                    </td>
                    <td className="py-2 text-right">
                      {r.customerSupplied ? (
                        <Badge tone="office">Customer supplied</Badge>
                      ) : r.toBuy > 0 ? (
                        <span className="font-semibold text-[var(--color-warn)]">
                          {r.toBuy} {r.unit}
                        </span>
                      ) : (
                        <Badge tone="done">Covered</Badge>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {supplied.length > 0 && buyRows.length === 0 && rows.length > 0 && (
          <p className="text-xs text-[var(--color-muted)]">
            Remaining open lines are customer-supplied — nothing to RFQ.
          </p>
        )}

        <div className="flex flex-wrap items-center gap-2">
          {activeRfq && (
            <Badge
              tone={
                activeRfq.status === "awarded"
                  ? "done"
                  : activeRfq.status === "sent" || activeRfq.status === "quoted"
                    ? "soon"
                    : "open"
              }
            >
              {activeRfq.rfqNumber} · {activeRfq.status}
            </Badge>
          )}
          {canSend && buyRows.length > 0 && (!activeRfq || activeRfq.status === "draft") && (
            <Button type="button" onClick={sendBulkRfq}>
              <Send className="h-4 w-4" />
              RFQ all vendors
            </Button>
          )}
          {canSend && activeRfq && activeRfq.status === "sent" && (
            <Button type="button" variant="outline" onClick={sendBulkRfq}>
              <Mail className="h-4 w-4" />
              Resend RFQ
            </Button>
          )}
          <Link
            to="/inventory"
            className="text-xs underline text-[var(--color-primary)]"
          >
            Inventory → Vendor RFQs
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
