import type {
  MaterialStock,
  PartStock,
  Quote,
  ShopOrder,
  ShopOrderLine,
} from "./types";
import { isSheetOrPlate } from "./stock-shapes";

export type MaterialLineStatus = "ok" | "needs_attention" | "unchecked";

export type LineMaterialPlan = {
  match: "exact" | "part_only" | "none";
  quoteId: string;
  material: string;
  materialType: string;
  stockShape: string;
  materialVendor: string;
  sizeNote: string;
  dimX: number;
  dimY: number;
  dimZ: number;
  partLengthEach: number;
  rawMaterialLength: number;
  materialNeeded: number;
  materialOnHand: number;
  materialStockId: string;
  materialLocation: string;
  finishedOnHand: number;
  finishedStockId: string;
  status: MaterialLineStatus;
  attentionReason: string;
  materialReviewed: boolean;
  /** Human-readable how need was computed */
  needFormula: string;
};

export function emptyLineMaterialPlan(
  partial?: Partial<LineMaterialPlan>,
): LineMaterialPlan {
  return {
    match: partial?.match || "none",
    quoteId: partial?.quoteId || "",
    material: partial?.material || "",
    materialType: partial?.materialType || "",
    stockShape: partial?.stockShape || "",
    materialVendor: partial?.materialVendor || "",
    sizeNote: partial?.sizeNote || "",
    dimX: partial?.dimX ?? 0,
    dimY: partial?.dimY ?? 0,
    dimZ: partial?.dimZ ?? 0,
    partLengthEach: partial?.partLengthEach ?? 0,
    rawMaterialLength: partial?.rawMaterialLength ?? 0,
    materialNeeded: partial?.materialNeeded ?? 0,
    materialOnHand: partial?.materialOnHand ?? 0,
    materialStockId: partial?.materialStockId || "",
    materialLocation: partial?.materialLocation || "",
    finishedOnHand: partial?.finishedOnHand ?? 0,
    finishedStockId: partial?.finishedStockId || "",
    status: partial?.status || "unchecked",
    attentionReason: partial?.attentionReason || "",
    materialReviewed: partial?.materialReviewed ?? false,
    needFormula: partial?.needFormula || "",
  };
}

function norm(s: string): string {
  return (s || "").trim().toUpperCase();
}

/** Part numbers: strip spaces, unify dashes for matching */
export function normalizePartNumber(pn: string): string {
  return norm(pn).replace(/\s+/g, "").replace(/[–—]/g, "-");
}

/** Generic shapes often auto-filled by old imports — do not treat as rich recipe. */
function isGenericStockShape(shape: string): boolean {
  const s = (shape || "").trim().toLowerCase();
  return (
    !s ||
    s === "round stock" ||
    s === "round" ||
    s === "bar" ||
    s === "bar stock"
  );
}

/** Prefer richer / newer quote when merging shared DB with local saves */
export function quoteRecipeScore(q: Quote): number {
  let s = 0;
  if ((q.material || "").trim()) s += 20;
  if ((q.materialType || "").trim()) s += 8;
  const shape = (q.stockShape || "").trim();
  if (shape && !isGenericStockShape(shape)) s += 6;
  else if (shape) s += 1; // generic round — weak signal only
  if (Number(q.dimX) > 0) s += 12;
  if (Number(q.dimY) > 0) s += 8;
  if (Number(q.dimZ) > 0) s += 4;
  if (Number(q.partLengthEach) > 0) s += 6;
  if (Number(q.rawMaterialLength) > 0) s += 4;
  // Intentional markups (1.1, 1.25…) beat default 1 from blank import defaults
  const mr = Number(q.machineRate) || 0;
  const mp = Number(q.materialPct) || 0;
  if (mr > 0 && Math.abs(mr - 1) > 0.001) s += 5;
  if (mp > 0 && Math.abs(mp - 1) > 0.001) s += 5;
  const t = new Date(q.date || 0).getTime();
  if (Number.isFinite(t)) s += Math.min(5, t / 1e12);
  return s;
}

function pickStockShape(primary: string | undefined, secondary: string | undefined): string {
  const p = (primary || "").trim();
  const s = (secondary || "").trim();
  if (p) return primary || "";
  // Primary intentionally blank: do NOT resurrect generic Round Stock from the other side
  if (s && !isGenericStockShape(s)) return secondary || "";
  return "";
}

function pickRate(primary: number | undefined, secondary: number | undefined): number {
  const p = Number(primary);
  const s = Number(secondary);
  const pOk = Number.isFinite(p) && p > 0;
  const sOk = Number.isFinite(s) && s > 0;
  if (pOk && sOk) {
    // Prefer real markup over bare default 1
    if (Math.abs(p - 1) < 0.001 && Math.abs(s - 1) > 0.001) return s;
    if (Math.abs(s - 1) < 0.001 && Math.abs(p - 1) > 0.001) return p;
    return p;
  }
  if (pOk) return p;
  if (sOk) return s;
  return 1;
}

export function quoteKey(q: Pick<Quote, "partNumber" | "revision" | "id">): string {
  const pn = normalizePartNumber(q.partNumber);
  const rev = norm(q.revision || "");
  if (pn) return `${pn}::${rev || "_"}`;
  return `id::${q.id}`;
}

/** Union of quote lists — never drop a part recipe that only exists on one side */
export function mergeQuoteLists(...lists: (Quote[] | undefined)[]): Quote[] {
  const map = new Map<string, Quote>();
  for (const list of lists) {
    for (const q of list || []) {
      if (!q?.partNumber && !q?.id) continue;
      const k = quoteKey(q);
      const prev = map.get(k);
      if (!prev) {
        map.set(k, q);
        continue;
      }
      // Later list wins ties (callers pass host/incoming last when it should win)
      const qWins = quoteRecipeScore(q) >= quoteRecipeScore(prev);
      const primary = qWins ? q : prev;
      const secondary = qWins ? prev : q;
      map.set(k, {
        ...secondary,
        ...primary,
        material: (primary.material || "").trim()
          ? primary.material
          : secondary.material || "",
        materialType: (primary.materialType || "").trim()
          ? primary.materialType
          : secondary.materialType || "",
        // Blank stock shape is intentional (yellow in UI) — never fill with Round Stock
        stockShape: pickStockShape(primary.stockShape, secondary.stockShape),
        machineRate: pickRate(primary.machineRate, secondary.machineRate),
        materialPct: pickRate(primary.materialPct, secondary.materialPct),
        dimX: Number(primary.dimX) || Number(secondary.dimX) || 0,
        dimY: Number(primary.dimY) || Number(secondary.dimY) || 0,
        dimZ: Number(primary.dimZ) || Number(secondary.dimZ) || 0,
        partLengthEach:
          Number(primary.partLengthEach) || Number(secondary.partLengthEach) || 0,
        rawMaterialLength:
          Number(primary.rawMaterialLength) ||
          Number(secondary.rawMaterialLength) ||
          0,
        materialVendor: primary.materialVendor || secondary.materialVendor || "",
        id: prev.id || q.id,
      });
    }
  }
  return [...map.values()];
}

function nearly(a: number, b: number, tol = 0.051): boolean {
  if (!Number.isFinite(a) || !Number.isFinite(b)) return false;
  if (a === 0 && b === 0) return true;
  if (!a || !b) return false;
  return Math.abs(a - b) <= tol;
}

/** Canonical number string so 0.75, .75, 0.750, 3/4 all become "0.75" */
function canonNum(n: number): string {
  if (!Number.isFinite(n)) return "";
  // 3 decimal places is enough for shop stock (thousandths)
  const r = Math.round(n * 1000) / 1000;
  // strip trailing zeros but keep leading zero before decimal
  return String(r);
}

/**
 * Normalize size text so 1/2" ≈ 0.5" ≈ .5 ≈ 0.50 ≈ 3/4" ≈ .75"
 * Multi-dim: 3/4 x 1  ≈  0.75 × 1"
 */
export function normalizeSizeKey(raw: string): string {
  let s = (raw || "").toLowerCase().replace(/["″''′]/g, " ");
  s = s.replace(/×/g, "x").replace(/\s+/g, " ").trim();
  // mixed numbers: 1-1/2, 1 1/2
  s = s.replace(/(\d+)\s*[-\s]\s*(\d+)\/(\d+)/g, (_, w, n, d) => {
    const v = Number(w) + Number(n) / Number(d);
    return Number.isFinite(v) ? canonNum(v) : _;
  });
  // simple fractions 3/4, 1/2
  s = s.replace(/\b(\d+)\/(\d+)\b/g, (_, n, d) => {
    const v = Number(n) / Number(d);
    return Number.isFinite(v) ? canonNum(v) : `${n}/${d}`;
  });
  // leading decimals: .75 → 0.75 (all digits after decimal)
  s = s.replace(/(^|[^0-9])\.(\d+)/g, (_, pre, digs) => `${pre}${canonNum(Number(`0.${digs}`))}`);
  // full decimals: 0.750 → 0.75
  s = s.replace(/\b(\d+\.\d+)\b/g, (_, num) => canonNum(Number(num)));
  s = s.replace(/\b(\d+)\b/g, (_, num) => canonNum(Number(num)));
  // keep digits, dots, x
  s = s.replace(/[^0-9.x]+/g, " ").replace(/\s+/g, " ").trim();
  s = s.replace(/\s*x\s*/g, "x");
  return s;
}

/** True if two size callouts mean the same stock (fraction ↔ decimal). */
export function sizesEquivalent(a: string, b: string, tol = 0.051): boolean {
  const na = normalizeSizeKey(a);
  const nb = normalizeSizeKey(b);
  if (!na || !nb) return false;
  if (na === nb) return true;
  if (na.includes(nb) || nb.includes(na)) return true;
  const ta = na.split("x").filter(Boolean).map(Number);
  const tb = nb.split("x").filter(Boolean).map(Number);
  if (!ta.length || !tb.length) return false;
  const n = Math.min(ta.length, tb.length);
  for (let i = 0; i < n; i++) {
    if (!nearly(ta[i]!, tb[i]!, tol)) return false;
  }
  return true;
}

/** First numeric token of a size note (dia / thickness). */
export function firstSizeNumber(raw: string): number {
  const key = normalizeSizeKey(raw);
  const m = key.match(/([0-9]+(?:\.[0-9]+)?)/);
  return m ? Number(m[1]) : 0;
}

function shapeFamily(shape: string): string {
  const t = (shape || "").toLowerCase();
  if (t.includes("tube")) {
    if (t.includes("square") || t.includes("rect")) return "rect-tube";
    return "round-tube";
  }
  if (t.includes("pipe")) return "pipe";
  if (t.includes("rect") || (t.includes("flat") && !t.includes("sheet"))) return "rect-bar";
  if (t.includes("square") && !t.includes("tube")) return "square";
  if (t.includes("hex")) return "hex";
  if (/\bangle\b/.test(t) && !t.includes("rect")) return "angle";
  if (t.includes("plate") || t.includes("sheet")) return "plate";
  if (t.includes("round") || t === "bar" || t === "bar stock" || t === "round stock")
    return "round";
  return t || "unknown";
}

function shapesCompatible(a: string, b: string): boolean {
  if (!a || !b) return true;
  const fa = shapeFamily(a);
  const fb = shapeFamily(b);
  if (fa === fb) return true;
  // rect bar ↔ flat bar
  if (
    (fa === "rect-bar" && fb === "square") ||
    (fb === "rect-bar" && fa === "square")
  )
    return true;
  return false;
}


export function findQuoteForPart(
  quotes: Quote[],
  partNumber: string,
  revision: string,
): { quote: Quote | null; match: "exact" | "part_only" | "none" } {
  const pn = normalizePartNumber(partNumber);
  if (!pn) return { quote: null, match: "none" };
  const rev = norm(revision);

  const samePn = (quotes || []).filter(
    (q) => normalizePartNumber(q.partNumber) === pn,
  );
  if (!samePn.length) return { quote: null, match: "none" };

  // Prefer quotes that actually have material on file
  const withMat = (list: Quote[]) =>
    [...list].sort((a, b) => {
      const am = a.material?.trim() ? 1 : 0;
      const bm = b.material?.trim() ? 1 : 0;
      if (bm !== am) return bm - am;
      return new Date(b.date).getTime() - new Date(a.date).getTime();
    });

  if (rev) {
    const exact = withMat(samePn.filter((q) => norm(q.revision) === rev));
    if (exact[0]) return { quote: exact[0], match: "exact" };
  } else {
    // No rev on PO line — take newest with material
    const newest = withMat(samePn);
    if (newest[0]) return { quote: newest[0], match: "exact" };
  }

  const newest = withMat(samePn);
  return { quote: newest[0] || null, match: "part_only" };
}

export type MaterialRecipe = {
  source: "quote" | "prior_order" | "line";
  quoteId: string;
  material: string;
  materialType: string;
  stockShape: string;
  sizeNote: string;
  dimX: number;
  dimY: number;
  dimZ: number;
  partLengthEach: number;
  rawMaterialLength: number;
  materialVendor: string;
  match: "exact" | "part_only" | "none";
};

function recipeFromQuote(
  quote: Quote,
  match: "exact" | "part_only",
): MaterialRecipe {
  const stockShape = (quote.stockShape || "").trim();
  const dimX = Number(quote.dimX) || 0;
  const dimY = Number(quote.dimY) || 0;
  const dimZ = Number(quote.dimZ) || 0;
  return {
    source: "quote",
    quoteId: quote.id,
    material: (quote.material || "").trim(),
    materialType: (quote.materialType || "").trim(),
    stockShape,
    sizeNote: formatSizeNote({
      sizeNote: "",
      dimX,
      dimY,
      dimZ,
      stockShape,
    }),
    dimX,
    dimY,
    dimZ,
    partLengthEach: Number(quote.partLengthEach) || 0,
    rawMaterialLength: Number(quote.rawMaterialLength) || 0,
    materialVendor: (quote.materialVendor || "").trim(),
    match,
  };
}

function recipeFromShopLine(
  line: ShopOrderLine,
  match: "exact" | "part_only",
): MaterialRecipe | null {
  if (!(line.material || "").trim() && !line.dimX && !line.sizeNote) return null;
  return {
    source: "prior_order",
    quoteId: line.quoteId || "",
    material: (line.material || "").trim(),
    materialType: (line.materialType || "").trim(),
    stockShape: (line.stockShape || "").trim(),
    sizeNote: (line.sizeNote || "").trim(),
    dimX: Number(line.dimX) || 0,
    dimY: Number(line.dimY) || 0,
    dimZ: Number(line.dimZ) || 0,
    partLengthEach: Number(line.partLengthEach) || 0,
    rawMaterialLength: Number(line.rawMaterialLength) || 0,
    materialVendor: (line.materialVendor || "").trim(),
    match,
  };
}

/**
 * Last-used material recipe for a P/N: part DB quote first, then prior shop orders.
 */

export type PoQuotePriceCheck = {
  hasQuote: boolean;
  partNumber: string;
  revision: string;
  /** Quoted unit price for this order qty (0 if unknown) */
  quotedUnitPrice: number;
  /** Qty break used from the quote */
  quoteQtyBreak: number;
  /** True when PO unit cost is $0 */
  zeroCost: boolean;
  /** True when we have a positive quoted price and PO cost differs */
  costMismatch: boolean;
  /** True when order qty is not one of the quote's qty breaks (and quote has breaks) */
  qtyNotOnBreak: boolean;
  /** Human summary for tooltips */
  summary: string;
};

/**
 * Pick which quote qty-break price applies to an order qty.
 * - Exact match → that break
 * - Otherwise → highest quoted qty that is still ≤ order qty (step down)
 * - If order qty is below every break → smallest quoted break (reference only)
 *
 * Works for any quote breaks the office entered (not fixed 1/3/5/10/20).
 * Example breaks 1,3,5,10,20:  2→1,  4→3,  9→5,  15→10,  18→10,  25→20
 */
export function pickQuoteQtyBreak(
  breaks: { qty: number; price: number }[],
  orderQty: number,
): { qty: number; price: number } | null {
  const list = (breaks || []).filter((b) => b.qty > 0 && b.price > 0);
  if (!list.length) return null;
  const qty = Number(orderQty) || 0;
  const sorted = [...list].sort((a, b) => a.qty - b.qty);
  if (qty <= 0) {
    // no order qty yet — show smallest break as reference
    return sorted[0] || null;
  }
  const exact = sorted.find((b) => b.qty === qty);
  if (exact) return exact;
  // Fall back to next lower quoted amount (largest break ≤ order qty)
  const lower = sorted.filter((b) => b.qty < qty);
  if (lower.length) return lower[lower.length - 1]!;
  // Order qty below every break — use lowest quote as reference
  return sorted[0] || null;
}

/**
 * Compare a customer PO line cost/qty against historical quote price breaks.
 * Flags $0 cost and prices that do not match the exact or next-lower quoted break.
 */
export function checkPoLineAgainstQuote(
  quotes: Quote[],
  partNumber: string,
  revision: string,
  orderQty: number,
  unitCost: number,
): PoQuotePriceCheck {
  const pn = (partNumber || "").trim();
  const base: PoQuotePriceCheck = {
    hasQuote: false,
    partNumber: pn,
    revision: (revision || "").trim(),
    quotedUnitPrice: 0,
    quoteQtyBreak: 0,
    zeroCost: (Number(unitCost) || 0) <= 0.0001,
    costMismatch: false,
    qtyNotOnBreak: false,
    summary: "",
  };
  if (!pn) {
    base.summary = base.zeroCost ? "Cost is $0.00 — enter price or confirm TBD" : "";
    return base;
  }

  const { quote, match } = findQuoteForPart(quotes, pn, revision);
  if (!quote || match === "none") {
    base.summary = base.zeroCost
      ? "Cost is $0.00 — no historical quote for this P/N"
      : "No historical quote for this P/N + rev";
    return base;
  }

  base.hasQuote = true;
  const qs = (quote.quantities || []).map((n) => Number(n) || 0);
  const ps = (quote.prices || []).map((n) => Number(n) || 0);
  const breaks: { qty: number; price: number }[] = [];
  for (let i = 0; i < Math.max(qs.length, ps.length); i++) {
    const q = qs[i] || 0;
    const price = ps[i] || 0;
    if (q > 0 && price > 0) breaks.push({ qty: q, price });
  }

  const qty = Number(orderQty) || 0;
  const cost = Number(unitCost) || 0;

  const chosen = pickQuoteQtyBreak(breaks, qty);
  if (chosen) {
    base.quotedUnitPrice = chosen.price;
    base.quoteQtyBreak = chosen.qty;
  }

  if (breaks.length && qty > 0) {
    base.qtyNotOnBreak = !breaks.some((b) => b.qty === qty);
  }

  if (base.quotedUnitPrice > 0 && cost > 0) {
    const tol = Math.max(0.02, base.quotedUnitPrice * 0.005); // 2¢ or 0.5%
    base.costMismatch = Math.abs(cost - base.quotedUnitPrice) > tol;
  }

  const at = (price: number, breakQty: number) =>
    `$${price.toFixed(2)} (@ qty ${breakQty})`;

  const bits: string[] = [];
  if (base.zeroCost) {
    bits.push(
      base.quotedUnitPrice > 0
        ? `Cost is $0.00 — need cost; quote ${at(base.quotedUnitPrice, base.quoteQtyBreak)} for order qty ${qty || "—"}`
        : "Cost is $0.00 — need price from customer / quote",
    );
  } else if (base.costMismatch) {
    bits.push(
      `PO $${cost.toFixed(2)} ≠ quote ${at(base.quotedUnitPrice, base.quoteQtyBreak)} for order qty ${qty}`,
    );
  }
  if (base.qtyNotOnBreak && breaks.length && base.quoteQtyBreak > 0) {
    const list = [...breaks].map((b) => b.qty).sort((a, b) => a - b).join(", ");
    bits.push(
      `Order qty ${qty} not a quote break (${list}) — using lower break qty ${base.quoteQtyBreak} for price check`,
    );
  }
  if (!bits.length && base.quotedUnitPrice > 0) {
    bits.push(
      qty === base.quoteQtyBreak
        ? `Matches quote ${at(base.quotedUnitPrice, base.quoteQtyBreak)}`
        : `Matches quote ${at(base.quotedUnitPrice, base.quoteQtyBreak)} (lower break for order qty ${qty})`,
    );
  }
  base.summary = bits.join(" · ");
  return base;
}


export function findLastMaterialRecipe(opts: {
  partNumber: string;
  revision: string;
  quotes: Quote[];
  shopOrders?: ShopOrder[];
}): MaterialRecipe | null {
  const { quote, match } = findQuoteForPart(
    opts.quotes,
    opts.partNumber,
    opts.revision,
  );
  if (quote && (quote.material?.trim() || quote.dimX || quote.stockShape)) {
    return recipeFromQuote(quote, match === "none" ? "part_only" : match);
  }

  const pn = normalizePartNumber(opts.partNumber);
  const rev = norm(opts.revision);
  const prior: { line: ShopOrderLine; when: string; exact: boolean }[] = [];
  for (const order of opts.shopOrders || []) {
    for (const line of order.lines || []) {
      if (normalizePartNumber(line.partNumber) !== pn) continue;
      if (!(line.material || line.sizeNote || line.dimX)) continue;
      const exact = !rev || norm(line.revision) === rev;
      prior.push({
        line,
        when: order.updatedAt || order.date || order.createdAt || "",
        exact,
      });
    }
  }
  prior.sort((a, b) => {
    if (a.exact !== b.exact) return a.exact ? -1 : 1;
    return new Date(b.when).getTime() - new Date(a.when).getTime();
  });
  if (prior[0]) {
    return recipeFromShopLine(
      prior[0].line,
      prior[0].exact ? "exact" : "part_only",
    );
  }

  // Quote exists but empty material — still return shell for match status
  if (quote) return recipeFromQuote(quote, match === "none" ? "part_only" : match);
  return null;
}

/** Build size note from dims if blank */
export function formatSizeNote(opts: {
  sizeNote?: string;
  dimX?: number;
  dimY?: number;
  dimZ?: number;
  stockShape?: string;
}): string {
  if (opts.sizeNote?.trim()) return opts.sizeNote.trim();
  const x = Number(opts.dimX) || 0;
  const y = Number(opts.dimY) || 0;
  const z = Number(opts.dimZ) || 0;
  const shape = (opts.stockShape || "").toLowerCase();
  if (
    (shape.includes("round") && !shape.includes("tube")) ||
    shape.includes("hex")
  ) {
    if (x && z) return `${x}" dia × ${z}" long`;
    if (x) return `${x}" dia`;
  }
  if (
    shape.includes("rect") ||
    shape.includes("flat") ||
    shape.includes("square") ||
    shape.includes("sheet") ||
    shape.includes("plate")
  ) {
    if (x && y && z) return `${x}" × ${y}" × ${z}"`;
    if (x && y) return `${x}" × ${y}"`;
    if (x) return `${x}"`;
  }
  const bits = [x, y, z].filter((n) => n > 0);
  if (bits.length) return bits.map((n) => `${n}"`).join(" × ");
  return "";
}

/**
 * Stock units needed for the PO line qty.
 * Round/bar: ceil(orderQty * partLengthEach / rawMaterialLength)
 * Sheet / plate: 1 blank per part (override in the dialog if you nest).
 */
export function estimateMaterialUnits(opts: {
  orderQty: number;
  partLengthEach: number;
  rawMaterialLength: number;
  stockShape?: string;
}): {
  needed: number;
  formula: string;
  totalInches: number;
  barsExact: number;
} {
  const qty = Math.max(0, Number(opts.orderQty) || 0);
  const each = Math.max(0, Number(opts.partLengthEach) || 0);
  const bar = Math.max(0, Number(opts.rawMaterialLength) || 0);
  if (!qty)
    return { needed: 0, formula: "Order qty is 0", totalInches: 0, barsExact: 0 };

  if (isSheetOrPlate(opts.stockShape || "")) {
    return {
      needed: qty,
      barsExact: qty,
      totalInches: 0,
      formula: `${qty} pcs × 1 blank each = ${qty} sheet/plate piece(s)`,
    };
  }

  const totalInches = qty * each;

  // Bar / stick math: need ceil(total cut length / bar length) whole bars
  if (each > 0 && bar > 0) {
    const barsExact = totalInches / bar;
    const needed = Math.max(1, Math.ceil(barsExact - 1e-9));
    return {
      needed,
      barsExact,
      totalInches,
      formula: `${qty} pcs × ${each}\" = ${totalInches}\" total → ÷ ${bar}\" stick = ${barsExact.toFixed(2)} → ${needed} bar(s)`,
    };
  }
  if (each > 0 && !bar) {
    return {
      needed: 0,
      barsExact: 0,
      totalInches,
      formula: `${qty} pcs × ${each}\" = ${totalInches}\" needed — enter stock bar length (e.g. 144\") to get bar count`,
    };
  }
  return {
    needed: 0,
    barsExact: 0,
    totalInches: 0,
    formula:
      'Set part cut length and stock bar length (e.g. 1" each, 144" bar → ceil(20/144)=1 bar)',
  };
}

export function scoreMaterialStock(
  row: MaterialStock,
  want: {
    material: string;
    materialType: string;
    stockShape: string;
    sizeNote: string;
    dimX: number;
    dimY: number;
    dimZ: number;
  },
): number {
  const m = norm(want.material);
  if (!m || norm(row.material) !== m) return -1;

  // Hard reject incompatible shapes (round vs rectangular, etc.)
  if (
    want.stockShape &&
    row.stockShape &&
    !shapesCompatible(want.stockShape, row.stockShape)
  ) {
    return -1;
  }

  let score = 10;
  if (want.materialType && norm(row.materialType) === norm(want.materialType)) {
    score += 25;
  } else if (want.materialType && row.materialType) {
    score += 2;
  }

  if (want.stockShape && row.stockShape) {
    if (norm(want.stockShape) === norm(row.stockShape)) score += 20;
    else if (shapeFamily(want.stockShape) === shapeFamily(row.stockShape))
      score += 12;
  }

  // Cross-section dims (thickness / dia / width) — ignore stock length on dimZ
  // when comparing unless both look like cross-section (small numbers)
  if (want.dimX > 0 && nearly(row.dimX, want.dimX)) score += 30;
  if (want.dimY > 0 && nearly(row.dimY, want.dimY)) score += 25;
  // dimZ as length is loose; only boost if close
  if (want.dimZ > 0 && row.dimZ > 0 && nearly(row.dimZ, want.dimZ, 2)) {
    score += 8;
  }

  // sizeNote 3/4" ↔ .75" ↔ dimX 0.75
  if (want.sizeNote && row.sizeNote && sizesEquivalent(want.sizeNote, row.sizeNote)) {
    score += 35;
  } else if (want.sizeNote && row.sizeNote) {
    const a = normalizeSizeKey(want.sizeNote);
    const b = normalizeSizeKey(row.sizeNote);
    const ta = a.split("x").filter(Boolean).map(Number);
    const tb = b.split("x").filter(Boolean).map(Number);
    if (ta[0] && tb[0] && nearly(ta[0], tb[0], 0.06)) {
      score += 18;
      if (ta[1] && tb[1] && nearly(ta[1], tb[1], 0.06)) score += 12;
    }
  }
  // dimX vs size note first number (callout .75 matches stock 3/4")
  const wantDia =
    want.dimX > 0 ? want.dimX : firstSizeNumber(want.sizeNote || "");
  const rowDia = row.dimX > 0 ? row.dimX : firstSizeNumber(row.sizeNote || "");
  if (wantDia > 0 && rowDia > 0 && nearly(wantDia, rowDia, 0.06)) {
    // only add if we didn't already get full sizeNote match
    if (!(want.sizeNote && row.sizeNote && sizesEquivalent(want.sizeNote, row.sizeNote))) {
      score += 28;
    }
  }
  if (want.dimY > 0) {
    const rowY = row.dimY > 0 ? row.dimY : 0;
    // second token of size note as width
    if (rowY > 0 && nearly(want.dimY, rowY, 0.06)) {
      /* already counted above via dimY */
    } else if (row.sizeNote) {
      const parts = normalizeSizeKey(row.sizeNote).split("x").map(Number);
      if (parts[1] && nearly(want.dimY, parts[1], 0.06)) score += 20;
    }
  }

  // Prefer stock that actually has qty
  if ((row.onHand || 0) > 0) score += 3;
  score += Math.min(5, row.onHand || 0) * 0.01;
  return score;
}

export type StockMatchResult = {
  row: MaterialStock | null;
  score: number;
  ranked: { row: MaterialStock; score: number }[];
};

export function rankMaterialStock(
  stock: MaterialStock[],
  want: {
    material: string;
    materialType: string;
    stockShape: string;
    sizeNote?: string;
    dimX?: number;
    dimY?: number;
    dimZ?: number;
  },
): StockMatchResult {
  if (!want.material?.trim()) return { row: null, score: -1, ranked: [] };
  const wantFull = {
    material: want.material,
    materialType: want.materialType || "",
    stockShape: want.stockShape || "",
    sizeNote: want.sizeNote || "",
    dimX: want.dimX || 0,
    dimY: want.dimY || 0,
    dimZ: want.dimZ || 0,
  };
  const ranked = (stock || [])
    .map((row) => ({ row, score: scoreMaterialStock(row, wantFull) }))
    .filter((x) => x.score >= 0)
    .sort((a, b) => b.score - a.score);

  // Need material+type+shape or solid size hit — not "any aluminum"
  const minScore =
    wantFull.dimX > 0 || wantFull.sizeNote.trim()
      ? 45
      : wantFull.materialType
        ? 40
        : 55;
  const best = ranked[0];
  if (!best || best.score < minScore) {
    return { row: null, score: best?.score ?? -1, ranked };
  }
  return { row: best.row, score: best.score, ranked };
}

export function findMaterialStockMatch(
  stock: MaterialStock[],
  want: {
    material: string;
    materialType: string;
    stockShape: string;
    sizeNote?: string;
    dimX?: number;
    dimY?: number;
    dimZ?: number;
    preferredId?: string;
  },
): MaterialStock | null {
  const ranked = rankMaterialStock(stock, want);
  // Only keep preferred id if it still scores as a real match to the recipe
  if (want.preferredId) {
    const pref = ranked.ranked.find((x) => x.row.id === want.preferredId);
    if (pref && pref.score >= 45) return pref.row;
  }
  return ranked.row;
}

/** Candidate inventory rows ranked by how well they match last-used recipe */
export function listMaterialStockCandidates(
  stock: MaterialStock[],
  material: string,
  materialType?: string,
  want?: {
    stockShape?: string;
    sizeNote?: string;
    dimX?: number;
    dimY?: number;
    dimZ?: number;
  },
): MaterialStock[] {
  const m = norm(material);
  if (!m) return [];
  if (want) {
    const { ranked } = rankMaterialStock(stock, {
      material,
      materialType: materialType || "",
      stockShape: want.stockShape || "",
      sizeNote: want.sizeNote,
      dimX: want.dimX,
      dimY: want.dimY,
      dimZ: want.dimZ,
    });
    if (ranked.length) return ranked.map((x) => x.row);
  }
  const t = norm(materialType || "");
  return (stock || [])
    .filter((s) => norm(s.material) === m)
    .sort((a, b) => {
      const ta = t && norm(a.materialType) === t ? 0 : 1;
      const tb = t && norm(b.materialType) === t ? 0 : 1;
      if (ta !== tb) return ta - tb;
      return (b.onHand || 0) - (a.onHand || 0);
    });
}

export function findFinishedPartStock(
  stock: PartStock[],
  partNumber: string,
  revision: string,
): PartStock | null {
  const pn = norm(partNumber);
  if (!pn) return null;
  const rev = norm(revision);
  const list = stock || [];
  const exact = list.find(
    (p) => norm(p.partNumber) === pn && (!rev || norm(p.revision) === rev),
  );
  if (exact) return exact;
  return list.find((p) => norm(p.partNumber) === pn) || null;
}

export function resolveLineMaterial(opts: {
  line: Pick<ShopOrderLine, "partNumber" | "revision" | "qty" | "description"> &
    Partial<ShopOrderLine>;
  quotes: Quote[];
  materialStock: MaterialStock[];
  partStock: PartStock[];
  shopOrders?: ShopOrder[];
  preserveReviewed?: boolean;
  /** If true, recompute materialNeeded from lengths even if previously set */
  recomputeNeed?: boolean;
}): LineMaterialPlan {
  const { line, quotes, materialStock, partStock, shopOrders } = opts;

  const finished = findFinishedPartStock(
    partStock,
    line.partNumber,
    line.revision,
  );

  const recipe = findLastMaterialRecipe({
    partNumber: line.partNumber,
    revision: line.revision,
    quotes,
    shopOrders,
  });
  const match: "exact" | "part_only" | "none" = recipe?.match || "none";
  const quoteId = recipe?.quoteId || "";

  // Line values win when set; otherwise auto-fill from last-used recipe (DB / prior PO)
  const material = (line.material || recipe?.material || "").trim();
  const materialType = (line.materialType || recipe?.materialType || "").trim();
  const stockShape = (line.stockShape || recipe?.stockShape || "").trim();

  const dimX0 = Number(line.dimX) || Number(recipe?.dimX) || 0;
  const dimY0 = Number(line.dimY) || Number(recipe?.dimY) || 0;
  const dimZ0 = Number(line.dimZ) || Number(recipe?.dimZ) || 0;

  let partLengthEach =
    Number(line.partLengthEach) || Number(recipe?.partLengthEach) || 0;
  let rawMaterialLength =
    Number(line.rawMaterialLength) ||
    Number(recipe?.rawMaterialLength) ||
    0;

  let dimX = dimX0;
  let dimY = dimY0;
  let dimZ = dimZ0;

  // Incomplete quotes often stuffed thickness into "bar length" and blank
  // size into "cut length". For sheet/plate, put those back where they belong
  // and never treat them as stick math.
  if (isSheetOrPlate(stockShape)) {
    if (!dimX && rawMaterialLength > 0 && rawMaterialLength <= 6) {
      dimX = rawMaterialLength;
    }
    if (!dimZ && partLengthEach > 0) {
      dimZ = partLengthEach;
    }
    rawMaterialLength = 0;
    partLengthEach = 0;
  }

  const sizeNote = formatSizeNote({
    sizeNote: line.sizeNote || recipe?.sizeNote || "",
    dimX,
    dimY,
    dimZ,
    stockShape,
  });
  const lastUsedLabel = [
    material,
    materialType,
    stockShape,
    sizeNote ||
      ([dimX, dimY].filter((n) => n > 0).map((n) => `${n}"`).join(" × ") || ""),
  ]
    .filter(Boolean)
    .join(" · ");

  // Keep a chosen inventory row only if it still scores against the recipe
  const matStock = findMaterialStockMatch(materialStock, {
    material,
    materialType,
    stockShape,
    sizeNote,
    dimX,
    dimY,
    dimZ,
    preferredId: line.materialStockId || "",
  });

  // If stock row picked, prefer its size for display when line size blank
  const resolvedSizeNote =
    sizeNote ||
    matStock?.sizeNote ||
    formatSizeNote({
      dimX: matStock?.dimX,
      dimY: matStock?.dimY,
      dimZ: matStock?.dimZ,
      stockShape: matStock?.stockShape || stockShape,
    });

  const est = estimateMaterialUnits({
    orderQty: line.qty,
    partLengthEach,
    rawMaterialLength: isSheetOrPlate(stockShape)
      ? 0
      : rawMaterialLength || matStock?.dimZ || 0,
    stockShape,
  });

  // Keep manual needed only if set and not forcing recompute.
  // Sheet/plate: ignore leftover bar-math buy qty unless they already marked OK.
  const keepManual =
    !opts.recomputeNeed &&
    line.materialNeeded &&
    line.materialNeeded > 0 &&
    (!isSheetOrPlate(stockShape) || Boolean(line.materialReviewed));
  const materialNeeded = keepManual
    ? Number(line.materialNeeded)
    : est.needed;

  const needFormula = keepManual
    ? `Manual override: ${line.materialNeeded} stock unit(s)`
    : est.formula;

  const materialOnHand = matStock?.onHand ?? 0;
  const finishedOnHand = finished?.onHand ?? 0;

  let status: MaterialLineStatus = "unchecked";
  let attentionReason = "";

  const buyMore = Math.max(0, (materialNeeded || 0) - (materialOnHand || 0));

  if (!line.partNumber.trim()) {
    status = "needs_attention";
    attentionReason = "Missing part number";
  } else if (match === "none") {
    status = "needs_attention";
    attentionReason =
      "Part not in database — enter material (last-used stock unknown)";
  } else if (match === "part_only" && lastUsedLabel) {
    // Recipe found under different rev — still auto-filled; soft attention
    status = material && (dimX || resolvedSizeNote) ? "ok" : "needs_attention";
    attentionReason =
      status === "ok"
        ? `Auto-filled last-used (${recipe?.source || "DB"}): ${lastUsedLabel} — rev differed, confirm if needed`
        : `Prior rev had incomplete material — set size`;
  } else if (match === "part_only") {
    status = "needs_attention";
    attentionReason = "P/N found but no material recipe on file — set material & size";
  } else if (!material) {
    status = "needs_attention";
    attentionReason = "Part in DB but no material on file — set material & size";
  } else if (!dimX && !resolvedSizeNote) {
    status = "needs_attention";
    attentionReason = `Last-used: ${lastUsedLabel} — missing size (enter thk×width or dia)`;
  } else if (
    !isSheetOrPlate(stockShape) &&
    partLengthEach > 0 &&
    !(rawMaterialLength || matStock?.dimZ)
  ) {
    status = "needs_attention";
    attentionReason = `Last-used: ${lastUsedLabel}. Cut ${partLengthEach}" × ${line.qty} = ${partLengthEach * line.qty}" — set stock bar length to compute buy qty`;
  } else if (!matStock) {
    status = "needs_attention";
    attentionReason = `Last-used: ${lastUsedLabel}. Not in inventory — BUY material (${materialNeeded > 0 ? `~${materialNeeded} unit(s)` : "qty TBD"})`;
  } else if (materialNeeded > 0 && materialOnHand < materialNeeded) {
    status = "needs_attention";
    attentionReason = `Last-used matched inventory @ ${matStock.location || "stock"}: need ${materialNeeded}, on hand ${materialOnHand} → BUY ${buyMore} more (${needFormula})`;
  } else {
    status = "ok";
    attentionReason = matStock
      ? `Last-used stock on hand: ${materialOnHand} @ ${matStock.location || "stock"} (${needFormula || "ok"})`
      : "";
  }

  if (
    status === "needs_attention" &&
    finishedOnHand >= (line.qty || 0) &&
    (line.qty || 0) > 0
  ) {
    attentionReason =
      (attentionReason ? attentionReason + " · " : "") +
      `Finished parts on hand: ${finishedOnHand}`;
  }

  if (line.materialReviewed && opts.preserveReviewed) {
    status = "ok";
    attentionReason = "";
  }

  // Recipe on file with size = part DB is good. Inventory short still flags attention
  // but user does not re-enter material — fields stay filled from last-used.
  const hasRecipe =
    !!material && (!!dimX || !!resolvedSizeNote || !!stockShape);
  const autoReviewed =
    hasRecipe &&
    (match === "exact" || match === "part_only") &&
    status === "ok" &&
    !!matStock;

  return emptyLineMaterialPlan({
    match,
    quoteId,
    material,
    materialType,
    stockShape: stockShape || matStock?.stockShape || "",
    materialVendor:
      recipe?.materialVendor || matStock?.vendor || line.materialVendor || "",
    sizeNote: resolvedSizeNote,
    dimX: dimX || matStock?.dimX || 0,
    dimY: dimY || matStock?.dimY || 0,
    dimZ: dimZ || matStock?.dimZ || 0,
    partLengthEach,
    rawMaterialLength: isSheetOrPlate(stockShape)
      ? 0
      : rawMaterialLength || matStock?.dimZ || 0,
    materialNeeded,
    materialOnHand,
    materialStockId: matStock?.id || "",
    materialLocation: matStock?.location || "",
    finishedOnHand,
    finishedStockId: finished?.id || "",
    status,
    attentionReason,
    materialReviewed:
      Boolean(line.materialReviewed && opts.preserveReviewed) || autoReviewed,
    needFormula,
  });
}

export function applyMaterialPlanToLine(
  line: ShopOrderLine,
  plan: LineMaterialPlan,
): ShopOrderLine {
  return {
    ...line,
    material: plan.material,
    materialType: plan.materialType,
    stockShape: plan.stockShape,
    materialVendor: plan.materialVendor,
    materialNeeded: plan.materialNeeded,
    materialOnHand: plan.materialOnHand,
    materialStockId: plan.materialStockId,
    materialLocation: plan.materialLocation,
    finishedOnHand: plan.finishedOnHand,
    finishedStockId: plan.finishedStockId,
    materialMatch: plan.match,
    materialStatus: plan.status,
    attentionReason: plan.attentionReason,
    materialReviewed: plan.materialReviewed,
    quoteId: plan.quoteId,
    sizeNote: plan.sizeNote,
    dimX: plan.dimX,
    dimY: plan.dimY,
    dimZ: plan.dimZ,
    partLengthEach: plan.partLengthEach,
    rawMaterialLength: plan.rawMaterialLength,
  };
}

export function enrichShopOrderLines(
  lines: ShopOrderLine[],
  quotes: Quote[],
  materialStock: MaterialStock[],
  partStock: PartStock[],
  opts?: {
    preserveReviewed?: boolean;
    recomputeNeed?: boolean;
    shopOrders?: ShopOrder[];
  },
): ShopOrderLine[] {
  return (lines || []).map((line) => {
    const plan = resolveLineMaterial({
      line,
      quotes,
      materialStock,
      partStock,
      shopOrders: opts?.shopOrders,
      preserveReviewed: opts?.preserveReviewed,
      recomputeNeed: opts?.recomputeNeed ?? true,
    });
    return applyMaterialPlanToLine(line, plan);
  });
}
