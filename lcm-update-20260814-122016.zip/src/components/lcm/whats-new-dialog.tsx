import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { ChangelogEntry } from "@/lib/lcm/whats-new";

export function WhatsNewDialog({
  current,
  changelog,
  onClose,
}: {
  current: { version: string; note: string; appliedAt: string | null };
  changelog: ChangelogEntry[];
  onClose: () => void;
}) {
  const extras = changelog.filter((c) => c.version !== current.version).slice(0, 8);
  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-4 print:hidden"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 shadow-xl max-h-[85vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2 mb-1">
          <Sparkles className="h-4 w-4 text-[var(--color-primary)]" />
          <h2 className="text-lg font-semibold">What’s new</h2>
        </div>
        <p className="text-xs text-[var(--color-muted)] mb-3">
          Version {current.version}
          {current.appliedAt
            ? ` · ${new Date(current.appliedAt).toLocaleString()}`
            : ""}
        </p>
        <p className="text-sm leading-relaxed">
          {current.note || "App update installed."}
        </p>
        {extras.length > 0 && (
          <div className="mt-4 space-y-2">
            <div className="text-[11px] font-semibold uppercase tracking-wide text-[var(--color-muted)]">
              Earlier
            </div>
            <ul className="space-y-2">
              {extras.map((c) => (
                <li
                  key={c.version}
                  className="rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2"
                >
                  <div className="text-[11px] text-[var(--color-muted)] tabular">
                    {c.version}
                    {c.appliedAt
                      ? ` · ${new Date(c.appliedAt).toLocaleString()}`
                      : ""}
                  </div>
                  <div className="text-sm mt-0.5">{c.note || "Update"}</div>
                </li>
              ))}
            </ul>
          </div>
        )}
        <Button className="w-full mt-4 min-h-11" onClick={onClose}>
          Got it
        </Button>
      </div>
    </div>
  );
}
