import type {
  AppSettings,
  BonusTier,
  DayBonusRecord,
  DowntimeEntry,
  JobRun,
  OperatorTimeEntry,
  WeeklyPayout,
  WorkShift,
} from "./types";
import { pickBonusPercentage } from "./calculations";
import { opIndex } from "./ops";

/** Local calendar YYYY-MM-DD */
export function localDateKey(iso: string | Date = new Date()): string {
  const d = typeof iso === "string" ? new Date(iso) : iso;
  if (Number.isNaN(d.getTime())) return "";
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/** Monday-start week key: 2026-W32 */
export function weekKeyFromDate(iso: string | Date = new Date()): string {
  const d = typeof iso === "string" ? new Date(iso) : new Date(iso.getTime());
  if (Number.isNaN(d.getTime())) return "";
  const day = d.getDay();
  const diffToMon = day === 0 ? -6 : 1 - day;
  const mon = new Date(d);
  mon.setHours(0, 0, 0, 0);
  mon.setDate(mon.getDate() + diffToMon);
  const thu = new Date(mon);
  thu.setDate(mon.getDate() + 3);
  const yearStart = new Date(thu.getFullYear(), 0, 1);
  const weekNo = Math.ceil(
    ((thu.getTime() - yearStart.getTime()) / 86400000 + 1) / 7,
  );
  return `${thu.getFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

export function hhmmToHours(hhmm: string): number {
  const [h, m] = (hhmm || "0:0").split(":").map((x) => Number(x) || 0);
  return h + m / 60;
}

/** Wall-clock span of the scheduled day (e.g. 07:00–16:00 → 9h) */
export function shiftWindowHours(workDayStart: string, workDayEnd: string): number {
  let start = hhmmToHours(workDayStart);
  let end = hhmmToHours(workDayEnd);
  if (end <= start) end += 24;
  return Math.max(0.5, end - start);
}

/**
 * Paid / bonus work day length = window − lunch.
 * Default: 07:00–16:00 with 1h lunch → 8h required.
 */
export function shiftHoursRequired(
  workDayStart: string,
  workDayEnd: string,
  lunchHours = 1,
): number {
  const window = shiftWindowHours(workDayStart, workDayEnd);
  const lunch = Math.max(0, Number(lunchHours) || 0);
  return Math.max(0.5, window - lunch);
}

export function shiftEnded(
  dateKey: string,
  workDayEnd: string,
  now = new Date(),
  workDayStart?: string,
): boolean {
  const start = dateAtHhmm(dateKey, workDayStart || "00:00");
  let end = dateAtHhmm(dateKey, workDayEnd);
  if (end.getTime() <= start.getTime()) {
    end = new Date(end.getTime() + 24 * 3600000);
  }
  return now.getTime() >= end.getTime();
}

/** Local Date for dateKey + "HH:MM" */
export function dateAtHhmm(dateKey: string, hhmm: string): Date {
  const [y, mo, d] = dateKey.split("-").map((x) => Number(x));
  const [h, m] = (hhmm || "0:0").split(":").map((x) => Number(x) || 0);
  return new Date(y, (mo || 1) - 1, d || 1, h, m, 0, 0);
}

/** Overlap of [aStart,aEnd] with [wStart,wEnd] in hours */
export function overlapHours(
  aStartMs: number,
  aEndMs: number,
  wStartMs: number,
  wEndMs: number,
): number {
  const s = Math.max(aStartMs, wStartMs);
  const e = Math.min(aEndMs, wEndMs);
  return Math.max(0, (e - s) / 3600000);
}

function slotN(...arrays: (unknown[] | undefined)[]): number {
  let n = 0;
  for (const a of arrays) if (a && a.length > n) n = a.length;
  return n || 6;
}

/** Earned + actual from job cells — used only when no time log (no window clip) */
export function jobEarnedAndWorked(job: JobRun): {
  earnedHours: number;
  workedHours: number;
} {
  let earned = 0;
  let worked = 0;
  const n = slotN(job.setups, job.runtimes, job.quotedSetups, job.quotedRuntimes);
  const unitsForRun =
    job.quantityCompleted > 0
      ? job.quantityCompleted
      : job.status === "Completed" && job.quantity > 0
        ? job.quantity
        : job.quantityCompleted;

  for (let i = 0; i < n; i++) {
    const setup = job.setups[i];
    const runtime = job.runtimes[i];
    if (typeof setup === "number" && setup > 0) {
      earned += (job.quotedSetups[i] || 0) / 3600;
      worked += setup / 3600;
    }
    if (typeof runtime === "number" && runtime > 0) {
      earned +=
        ((job.quotedRuntimes[i] || 0) / 3600) * Math.max(0, unitsForRun || 0);
      worked += runtime / 3600;
    }
  }
  if (job.pairTwoVise) {
    const setup1 = job.setups[0];
    const op1 = job.runtimes[0];
    if (typeof setup1 === "number" && setup1 > 0) {
      earned += (job.quotedSetups[1] || 0) / 3600;
    }
    if (typeof op1 === "number" && op1 > 0) {
      earned +=
        ((job.quotedRuntimes[1] || 0) / 3600) * Math.max(0, unitsForRun || 0);
    }
  }
  if (worked <= 0 && (job.actualTime || 0) > 0) {
    worked = job.actualTime / 3600;
  }
  return { earnedHours: earned, workedHours: worked };
}

export function accumulateOperatorDay(opts: {
  operatorName: string;
  dateKey: string;
  jobs: JobRun[];
  operatorTimeLog: OperatorTimeEntry[];
  downtimes: DowntimeEntry[];
  workDayStart: string;
  workDayEnd: string;
}): {
  earnedHours: number;
  workedHours: number;
  pauseHours: number;
  jobIds: string[];
  outsideShiftHours: number;
} {
  const {
    operatorName,
    dateKey,
    jobs,
    operatorTimeLog,
    downtimes,
    workDayStart,
    workDayEnd,
  } = opts;
  const name = operatorName.trim().toLowerCase();

  const winStart = dateAtHhmm(dateKey, workDayStart).getTime();
  let winEnd = dateAtHhmm(dateKey, workDayEnd).getTime();
  if (winEnd <= winStart) winEnd += 24 * 3600000; // overnight shift

  // Jobs that overlap this shift window (supports after-midnight night shift)
  const dayJobs = jobs.filter((j) => {
    if (j.operator?.trim().toLowerCase() !== name) return false;
    if (!j.startTime) return false;
    const a = new Date(j.startTime).getTime();
    const b = j.endTime
      ? new Date(j.endTime).getTime()
      : a + Math.max(0, (j.actualTime || 0) * 1000) + 60_000;
    return b > winStart && a < winEnd;
  });
  const jobIds = dayJobs.map((j) => j.id);

  // Time-log rows that overlap the shift window
  const logRows = operatorTimeLog.filter((r) => {
    if (r.operator?.trim().toLowerCase() !== name) return false;
    if (!r.endTime) return false;
    const a = new Date(r.startTime).getTime();
    const b = new Date(r.endTime).getTime();
    return b > winStart && a < winEnd;
  });

  let earned = 0;
  let worked = 0;
  let outside = 0;

  if (logRows.length > 0) {
    for (const row of logRows) {
      const a = new Date(row.startTime).getTime();
      const b = new Date(row.endTime!).getTime();
      const rawHours = Math.max(0, (b - a) / 3600000);
      const inHours = overlapHours(a, b, winStart, winEnd);
      const outHours = Math.max(0, rawHours - inHours);
      outside += outHours;

      if (inHours <= 0) continue;

      worked += inHours;
      const job = jobs.find((j) => j.id === row.jobId);
      if (!job) continue;
      const idx = opIndex(row.operation);
      // Scale earned by fraction of this segment that fell inside the shift window
      const scale = rawHours > 0 ? inHours / rawHours : 0;
      if (row.type === "Setup") {
        earned += ((job.quotedSetups[idx] || 0) / 3600) * scale;
        if (job.pairTwoVise && idx === 0) {
          earned += ((job.quotedSetups[1] || 0) / 3600) * scale;
        }
      } else {
        const units = row.unitsCompleted || 0;
        earned += ((job.quotedRuntimes[idx] || 0) / 3600) * units * scale;
        if (job.pairTwoVise && idx === 0) {
          earned += ((job.quotedRuntimes[1] || 0) / 3600) * units * scale;
        }
      }
    }
  } else {
    // Fallback: no time log — use job aggregates (cannot clip to clock; still dated)
    for (const j of dayJobs) {
      const x = jobEarnedAndWorked(j);
      earned += x.earnedHours;
      worked += x.workedHours;
    }
  }

  let pauseHours = 0;
  for (const d of downtimes) {
    if (d.operator?.trim().toLowerCase() !== name) continue;
    if (!d.endTime) continue;
    const a = new Date(d.startTime).getTime();
    const b = new Date(d.endTime).getTime();
    // Only pause time inside the official shift window counts toward "on shift"
    const inHours = overlapHours(a, b, winStart, winEnd);
    pauseHours += inHours;
    const raw = Math.max(0, (b - a) / 3600000);
    outside += Math.max(0, raw - inHours);
  }

  return {
    earnedHours: earned,
    workedHours: worked,
    pauseHours,
    jobIds: [...new Set(jobIds)],
    outsideShiftHours: outside,
  };
}

export type DayBonusCalc = {
  dateKey: string;
  weekKey: string;
  operatorName: string;
  shiftId: string;
  shiftName: string;
  workDayStart: string;
  workDayEnd: string;
  earnedHours: number;
  workedHours: number;
  pauseHours: number;
  onShiftHours: number;
  requiredShiftHours: number;
  windowHours: number;
  lunchHours: number;
  outsideShiftHours: number;
  efficiency: number;
  tierPct: number;
  pool: number;
  projectedBonus: number;
  eligible: boolean;
  eligibilityReason: string;
  shiftEnded: boolean;
  jobIds: string[];
};

export function calculateDayBonus(opts: {
  operatorName: string;
  dateKey: string;
  jobs: JobRun[];
  operatorTimeLog: OperatorTimeEntry[];
  downtimes: DowntimeEntry[];
  workDayStart: string;
  workDayEnd: string;
  lunchHours?: number;
  bonusTiers: BonusTier[];
  hourlyRate: number;
  now?: Date;
  shiftId?: string;
  shiftName?: string;
}): DayBonusCalc {
  const now = opts.now || new Date();
  const shiftId = opts.shiftId || "day";
  const shiftName = opts.shiftName || (shiftId === "night" ? "Night" : "Day");
  const lunchHours = Math.max(0, Number(opts.lunchHours ?? 1) || 0);
  const windowHours = shiftWindowHours(opts.workDayStart, opts.workDayEnd);
  const required = shiftHoursRequired(
    opts.workDayStart,
    opts.workDayEnd,
    lunchHours,
  );
  const acc = accumulateOperatorDay({
    operatorName: opts.operatorName,
    dateKey: opts.dateKey,
    jobs: opts.jobs,
    operatorTimeLog: opts.operatorTimeLog,
    downtimes: opts.downtimes,
    workDayStart: opts.workDayStart,
    workDayEnd: opts.workDayEnd,
  });

  // Presence toward full shift: worked + pause inside this shift window only
  const onShiftHours = acc.workedHours + acc.pauseHours;
  const efficiency =
    acc.workedHours > 0 ? acc.earnedHours / acc.workedHours : 0;
  const tierPct = pickBonusPercentage(efficiency, opts.bonusTiers);
  const pool = acc.earnedHours * (opts.hourlyRate || 0);
  const ended = shiftEnded(
    opts.dateKey,
    opts.workDayEnd,
    now,
    opts.workDayStart,
  );

  const grace = 15 / 60;
  const fullShift = onShiftHours + 1e-9 >= required - grace;

  let eligible = false;
  let eligibilityReason = "";
  if (acc.workedHours <= 0) {
    eligibilityReason = `No timed work inside ${shiftName.toLowerCase()} shift hours`;
  } else if (!fullShift) {
    eligibilityReason = `Full ${shiftName.toLowerCase()} shift required (${onShiftHours.toFixed(1)}h of ${required.toFixed(1)}h inside ${opts.workDayStart}–${opts.workDayEnd}; lunch ${lunchHours}h excluded)`;
  } else if (efficiency < 0.7 || tierPct <= 0) {
    eligibilityReason = "Shift efficiency below bonus tiers";
  } else {
    eligible = true;
    eligibilityReason = `Eligible (${shiftName}) — paid in weekly payout`;
  }

  if (acc.outsideShiftHours > 0.05 && eligible) {
    eligibilityReason += ` · ${acc.outsideShiftHours.toFixed(1)}h outside shift not counted`;
  } else if (acc.outsideShiftHours > 0.05 && !eligible && acc.workedHours > 0) {
    eligibilityReason += ` · ${acc.outsideShiftHours.toFixed(1)}h outside this shift ignored`;
  }

  const projectedBonus = eligible ? pool * tierPct : 0;

  return {
    dateKey: opts.dateKey,
    weekKey: weekKeyFromDate(`${opts.dateKey}T12:00:00`),
    operatorName: opts.operatorName,
    shiftId,
    shiftName,
    workDayStart: opts.workDayStart,
    workDayEnd: opts.workDayEnd,
    earnedHours: acc.earnedHours,
    workedHours: acc.workedHours,
    pauseHours: acc.pauseHours,
    onShiftHours,
    requiredShiftHours: required,
    windowHours,
    lunchHours,
    outsideShiftHours: acc.outsideShiftHours,
    efficiency,
    tierPct,
    pool,
    projectedBonus,
    eligible,
    eligibilityReason,
    shiftEnded: ended,
    jobIds: acc.jobIds,
  };
}

export function toDayBonusRecord(
  calc: DayBonusCalc,
  status: DayBonusRecord["status"],
  existing?: DayBonusRecord | null,
): DayBonusRecord {
  const bonus =
    status === "finalized"
      ? calc.eligible
        ? calc.projectedBonus
        : 0
      : calc.projectedBonus;

  const shiftId = calc.shiftId || existing?.shiftId || "day";
  return {
    id:
      existing?.id ||
      `day-${calc.dateKey}-${shiftId}-${calc.operatorName.replace(/\s+/g, "-")}`,
    operatorName: calc.operatorName,
    dateKey: calc.dateKey,
    shiftId,
    shiftName: calc.shiftName || existing?.shiftName || "Day",
    weekKey: calc.weekKey,
    earnedHours: calc.earnedHours,
    workedHours: calc.workedHours,
    pauseHours: calc.pauseHours,
    onShiftHours: calc.onShiftHours,
    requiredShiftHours: calc.requiredShiftHours,
    efficiency: calc.efficiency,
    tierPct: calc.tierPct,
    pool: calc.pool,
    bonus,
    eligible: calc.eligible,
    eligibilityReason: calc.eligibilityReason,
    jobIds: calc.jobIds,
    status,
    finalizedAt: status === "finalized" ? new Date().toISOString() : null,
  };
}

export function rollupWeek(
  records: DayBonusRecord[],
  operatorName: string,
  weekKey: string,
  existing?: WeeklyPayout | null,
): WeeklyPayout {
  const days = records.filter(
    (r) =>
      r.operatorName === operatorName &&
      r.weekKey === weekKey &&
      r.status === "finalized",
  );
  const totalBonus = days.reduce((s, d) => s + (d.eligible ? d.bonus : 0), 0);
  return {
    id:
      existing?.id ||
      `week-${weekKey}-${operatorName.replace(/\s+/g, "-")}`,
    operatorName,
    weekKey,
    dayIds: days.map((d) => d.id),
    totalBonus,
    status: existing?.status === "paid" ? "paid" : "open",
    paidAt: existing?.status === "paid" ? existing.paidAt : null,
  };
}

export function formatWeekLabel(weekKey: string): string {
  const m = weekKey.match(/^(\d{4})-W(\d{2})$/);
  if (!m) return weekKey;
  return `Week ${Number(m[2])}, ${m[1]}`;
}


export const DEFAULT_WORK_SHIFTS: WorkShift[] = [
  {
    id: "day",
    name: "Day",
    start: "07:00",
    end: "16:00",
    lunchHours: 1,
    enabled: true,
  },
  {
    id: "night",
    name: "Night",
    start: "16:00",
    end: "01:00",
    lunchHours: 1,
    enabled: true,
  },
];

/** Normalize settings → enabled shifts (migrates legacy workDay* fields) */
export function resolveWorkShifts(
  settings: Pick<
    AppSettings,
    "workDayStart" | "workDayEnd" | "lunchHours" | "shifts"
  >,
): WorkShift[] {
  const raw = Array.isArray(settings.shifts) ? settings.shifts : [];
  if (raw.length > 0) {
    return raw.map((s) => ({
      id: s.id || "day",
      name: s.name || s.id || "Shift",
      start: s.start || "07:00",
      end: s.end || "16:00",
      lunchHours: Math.max(0, Number(s.lunchHours) || 0),
      enabled: s.enabled !== false,
    }));
  }
  // Legacy single day window
  return [
    {
      id: "day",
      name: "Day",
      start: settings.workDayStart || "07:00",
      end: settings.workDayEnd || "16:00",
      lunchHours: Math.max(0, Number(settings.lunchHours ?? 1) || 0),
      enabled: true,
    },
    {
      ...DEFAULT_WORK_SHIFTS[1],
      enabled: true,
    },
  ];
}

export function getShiftById(
  settings: Pick<
    AppSettings,
    "workDayStart" | "workDayEnd" | "lunchHours" | "shifts"
  >,
  shiftId?: string,
): WorkShift {
  const all = resolveWorkShifts(settings);
  const id = shiftId || "day";
  return (
    all.find((s) => s.id === id) ||
    all.find((s) => s.enabled) ||
    all[0] ||
    DEFAULT_WORK_SHIFTS[0]
  );
}

/**
 * Which shift is "current" right now.
 * dateKey for overnight night shift is the calendar date the shift *started*
 * (e.g. Thu night 4pm–2am still uses Thursday as dateKey after midnight).
 */
export function currentShiftContext(
  settings: Pick<
    AppSettings,
    "workDayStart" | "workDayEnd" | "lunchHours" | "shifts"
  >,
  now = new Date(),
): { shift: WorkShift; dateKey: string } {
  const shifts = resolveWorkShifts(settings).filter((s) => s.enabled);
  const list = shifts.length ? shifts : DEFAULT_WORK_SHIFTS;
  const today = localDateKey(now);
  const yesterdayDate = new Date(now);
  yesterdayDate.setDate(yesterdayDate.getDate() - 1);
  const yesterday = localDateKey(yesterdayDate);

  for (const shift of list) {
    // Window starting today
    const startToday = dateAtHhmm(today, shift.start).getTime();
    let endToday = dateAtHhmm(today, shift.end).getTime();
    if (endToday <= startToday) endToday += 24 * 3600000;
    if (now.getTime() >= startToday && now.getTime() < endToday) {
      return { shift, dateKey: today };
    }
    // Overnight still running from yesterday
    const startY = dateAtHhmm(yesterday, shift.start).getTime();
    let endY = dateAtHhmm(yesterday, shift.end).getTime();
    if (endY <= startY) endY += 24 * 3600000;
    if (now.getTime() >= startY && now.getTime() < endY) {
      return { shift, dateKey: yesterday };
    }
  }
  // Default: day shift for today
  const day =
    list.find((s) => s.id === "day") || list[0] || DEFAULT_WORK_SHIFTS[0];
  return { shift: day, dateKey: today };
}

export function calculateShiftBonus(opts: {
  operatorName: string;
  dateKey: string;
  shift: WorkShift;
  jobs: JobRun[];
  operatorTimeLog: OperatorTimeEntry[];
  downtimes: DowntimeEntry[];
  bonusTiers: BonusTier[];
  hourlyRate: number;
  now?: Date;
}): DayBonusCalc {
  return calculateDayBonus({
    operatorName: opts.operatorName,
    dateKey: opts.dateKey,
    jobs: opts.jobs,
    operatorTimeLog: opts.operatorTimeLog,
    downtimes: opts.downtimes,
    workDayStart: opts.shift.start,
    workDayEnd: opts.shift.end,
    lunchHours: opts.shift.lunchHours,
    bonusTiers: opts.bonusTiers,
    hourlyRate: opts.hourlyRate,
    now: opts.now,
    shiftId: opts.shift.id,
    shiftName: opts.shift.name,
  });
}
