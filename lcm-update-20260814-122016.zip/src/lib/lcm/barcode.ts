import QRCode from "qrcode";

/** Build QR data URL for a barcode string (used on 0.5"×1" stickers). */
export async function barcodeToDataUrl(
  text: string,
  size = 96,
): Promise<string> {
  return QRCode.toDataURL(text, {
    errorCorrectionLevel: "M",
    margin: 0,
    width: size,
    color: { dark: "#000000", light: "#ffffff" },
  });
}

/** Normalize Settings → shopPublicUrl into http://host:port with no trailing slash. */
export function normalizeShopPublicUrl(raw: string | undefined | null): string {
  let s = String(raw || "").trim();
  if (!s) return "";
  if (!/^https?:\/\//i.test(s)) s = "http://" + s;
  s = s.replace(/\/+$/, "");
  try {
    const u = new URL(s);
    if (!u.port && u.protocol === "http:") u.port = "8080";
    return u.origin;
  } catch {
    return s;
  }
}

/** Origin encoded into label QR codes. Prefer shopPublicUrl so phones hit the host. */
export function resolveLabelOrigin(configured?: string | null): string {
  const c = normalizeShopPublicUrl(configured);
  if (c) return c;
  if (typeof window !== "undefined") return window.location.origin;
  return "";
}

/** Absolute scan URL when we know the host (for stickers that open the app). */
export function scanUrlForBarcode(barcode: string, origin?: string): string {
  const base = resolveLabelOrigin(origin);
  const path = `/scan?c=${encodeURIComponent(barcode)}`;
  return base ? `${base}${path}` : path;
}
