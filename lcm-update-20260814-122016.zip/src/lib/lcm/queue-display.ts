import type {
  LineFileRef,
  Quote,
  ShopOrder,
  ShopOrderLine,
  WorkQueueItem,
} from "./types";
import { normalizeLineFiles } from "./line-files";

export type QueueItemDisplay = {
  dueDate: string;
  estMinutes: number | null;
  drawings: LineFileRef[];
};

function samePart(a: string, b: string) {
  return (a || "").trim().toUpperCase() === (b || "").trim().toUpperCase();
}

function sameRev(a: string, b: string) {
  const x = (a || "").trim().toUpperCase();
  const y = (b || "").trim().toUpperCase();
  if (!x || !y) return true;
  return x === y;
}

export function findQueueOrderLine(
  item: WorkQueueItem,
  orders: ShopOrder[],
): { order: ShopOrder | null; line: ShopOrderLine | null } {
  const list = orders || [];
  const order =
    list.find((o) => o.id === item.shopOrderId) ||
    list.find((o) => (o.poNumber || "") === (item.poNumber || "") && item.poNumber) ||
    null;
  if (!order) return { order: null, line: null };
  const lines = order.lines || [];
  const line =
    lines.find((l) => l.id === item.shopOrderLineId) ||
    lines.find(
      (l) =>
        samePart(l.partNumber, item.partNumber) &&
        sameRev(l.revision, item.revision),
    ) ||
    lines.find((l) => samePart(l.partNumber, item.partNumber)) ||
    null;
  return { order, line };
}

export function drawingsForQueueItem(
  item: WorkQueueItem,
  line: ShopOrderLine | null,
): LineFileRef[] {
  if (!line) return [];
  const files = normalizeLineFiles(line);
  const pn = (item.partNumber || "").trim().toUpperCase();
  const fromLine = files.drawings.filter((d) => {
    const related = (d.relatedPartNumber || "").trim().toUpperCase();
    return !related || related === pn;
  });
  const fromComp = (line.components || [])
    .filter((c) => samePart(c.partNumber, item.partNumber))
    .flatMap((c) => c.drawings || []);
  const seen = new Set<string>();
  const out: LineFileRef[] = [];
  for (const d of [...fromLine, ...fromComp]) {
    if (!d?.id || seen.has(d.id)) continue;
    seen.add(d.id);
    out.push(d);
  }
  return out;
}

export function quoteForQueueItem(
  item: WorkQueueItem,
  quotes: Quote[],
): Quote | null {
  const list = quotes || [];
  const exact = list.find(
    (q) =>
      samePart(q.partNumber, item.partNumber) &&
      sameRev(q.revision, item.revision),
  );
  if (exact) return exact;
  return list.find((q) => samePart(q.partNumber, item.partNumber)) || null;
}

/** Setup + run×qty from the quote recipe. Minutes. Null when nothing is quoted. */
export function estimateQueueMinutes(
  item: WorkQueueItem,
  quote: Quote | null,
): number | null {
  if (!quote) return null;
  const setup = (quote.setupTimes || []).reduce((a, b) => a + (b || 0), 0);
  const runEach = (quote.runTimes || []).reduce((a, b) => a + (b || 0), 0);
  if (setup <= 0 && runEach <= 0) return null;
  const qty = Math.max(1, Number(item.qty) || 1);
  return setup + runEach * qty;
}

export function queueItemDisplay(
  item: WorkQueueItem,
  orders: ShopOrder[],
  quotes: Quote[],
): QueueItemDisplay {
  const { order, line } = findQueueOrderLine(item, orders);
  const dueDate = (line?.dueDate || order?.dueDate || order?.dateRequired || "").trim();
  return {
    dueDate,
    estMinutes: estimateQueueMinutes(item, quoteForQueueItem(item, quotes)),
    drawings: drawingsForQueueItem(item, line),
  };
}

export function formatQueueEst(mins: number | null): string {
  if (mins == null || !Number.isFinite(mins) || mins <= 0) return "";
  if (mins < 60) return `${Math.round(mins)} min`;
  const h = Math.floor(mins / 60);
  const m = Math.round(mins % 60);
  return m ? `${h}h ${m}m` : `${h}h`;
}
