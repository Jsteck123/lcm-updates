import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Factory,
  Activity,
  DollarSign,
  Clock,
  AlertTriangle,
  ChevronRight,
  ClipboardList,
  Package,
  Pause,
  Timer,
  TrendingUp,
  UserRound,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useLcmStore } from "@/store/lcm-store";
import { isLowStock, materialLabel, partLabel } from "@/lib/lcm/inventory";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  formatCurrency,
  formatPercent,
  formatDateTime,
  formatSeconds,
} from "@/lib/utils";
import { allMachines } from "@/lib/lcm/lists";
import { machineToSlug } from "@/lib/lcm/machines";
import { getOperatorByEmail, operatorCanAccessTab } from "@/lib/lcm/permissions";
import { localDateKey } from "@/lib/lcm/day-bonus";
import { jobVsQuote } from "@/lib/lcm/job-averages";
import { opLabel } from "@/lib/lcm/ops";
import { openQueue } from "@/lib/lcm/work-queue";
import { shopLineOpenQty } from "@/lib/lcm/po";
import type { MachineSession, ShopOrder } from "@/lib/lcm/types";

export const Route = createFileRoute("/")({
  component: DashboardPage,
});

type AttentionItem = {
  id: string;
  severity: "danger" | "warn" | "info";
  title: string;
  detail: string;
  href: string;
};

function nextOpHint(session: MachineSession | undefined, maxOps: number): string {
  if (!session?.jobId) return "No job loaded";
  const n = Math.max(session.setups?.length || 0, maxOps);
  const anyQuoted =
    session.quotedSetups?.some((v) => (v || 0) > 0) ||
    session.quotedRuntimes?.some((v) => (v || 0) > 0);
  for (let i = 0; i < n; i++) {
    const planned =
      !anyQuoted ||
      (session.quotedSetups[i] || 0) > 0 ||
      (session.quotedRuntimes[i] || 0) > 0 ||
      session.setups[i] != null ||
      session.runtimes[i] != null;
    if (!planned) continue;
    if (session.setups[i] == null) return `Next: ${opLabel(i)} Setup`;
    if (session.runtimes[i] == null) return `Next: ${opLabel(i)} Runtime`;
  }
  return "All ops complete — save job";
}

function daysUntil(dateStr: string): number | null {
  if (!dateStr) return null;
  const d = new Date(dateStr.slice(0, 10) + "T12:00:00");
  if (Number.isNaN(d.getTime())) return null;
  const today = new Date();
  today.setHours(12, 0, 0, 0);
  return Math.round((d.getTime() - today.getTime()) / 86400000);
}

function DashboardPage() {
  const jobs = useLcmStore((s) => s.jobs);
  const sessions = useLcmStore((s) => s.sessions);
  const activeTimers = useLcmStore((s) => s.activeTimers);
  const company = useLcmStore((s) => s.settings.companyName);
  const customLists = useLcmStore((s) => s.settings.customLists);
  const maxOps = useLcmStore((s) => s.settings.maxOperations || 10);
  const dayBonuses = useLcmStore((s) => s.dayBonuses);
  const weeklyPayouts = useLcmStore((s) => s.weeklyPayouts);
  const materialStock = useLcmStore((s) => s.materialStock || []);
  const partStock = useLcmStore((s) => s.partStock || []);
  const shopOrders = useLcmStore((s) => s.shopOrders || []);
  const workQueue = useLcmStore((s) => s.workQueue || []);
  const email = useLcmStore((s) => s.currentUserEmail);
  const operators = useLcmStore((s) => s.operators);
  const getLive = useLcmStore((s) => s.getLiveElapsedSeconds);
  const getDayBonusLive = useLcmStore((s) => s.getDayBonusLive);

  const me = getOperatorByEmail(operators, email);
  const isAdmin = me?.role === "admin";
  const myName = me?.name || "";
  const canPo = isAdmin || operatorCanAccessTab(me, "po");
  const canInv = isAdmin || operatorCanAccessTab(me, "inventory");
  const canJobs = isAdmin || operatorCanAccessTab(me, "jobs");

  const machines = useMemo(() => allMachines(customLists), [customLists]);
  const today = localDateKey();

  // Live timer tick
  const [, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick((n) => n + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const openJobs = useMemo(
    () => jobs.filter((j) => j.status === "In Progress"),
    [jobs],
  );

  const todayJobs = useMemo(() => {
    return jobs.filter((j) => {
      const key = localDateKey(j.endTime || j.saveTime || j.startTime);
      return key === today;
    });
  }, [jobs, today]);

  const todayCompleted = todayJobs.filter((j) => j.status === "Completed");
  const todayEff =
    todayCompleted.length > 0
      ? todayCompleted.reduce(
          (s, j) => s + (j.efficiency > 1 ? j.efficiency / 100 : j.efficiency),
          0,
        ) / todayCompleted.length
      : 0;

  const weekBonusOpen = weeklyPayouts
    .filter((w) => w.status === "open")
    .reduce((s, w) => s + (w.totalBonus || 0), 0);

  const myDayBonus = myName ? getDayBonusLive(myName) : null;

  const liveCount = machines.filter(
    (m) => activeTimers[m] || sessions[m]?.paused || sessions[m]?.jobId,
  ).length;

  const lowItems = useMemo(() => {
    if (!canInv && !isAdmin) return [];
    const mats = materialStock
      .filter((m) => isLowStock(m.onHand, m.minQty))
      .map((m) => ({
        id: m.id,
        label: materialLabel(m),
        onHand: m.onHand,
        minQty: m.minQty,
      }));
    const parts = partStock
      .filter((p) => isLowStock(p.onHand, p.minQty))
      .map((p) => ({
        id: p.id,
        label: partLabel(p),
        onHand: p.onHand,
        minQty: p.minQty,
      }));
    return [...mats, ...parts];
  }, [materialStock, partStock, canInv, isAdmin]);

  const openOrders = useMemo(() => {
    if (!canPo) return [];
    return (shopOrders || [])
      .filter(
        (o) =>
          o.status !== "cancelled" &&
          o.status !== "complete" &&
          o.status !== "draft",
      )
      .map((o) => {
        const due = o.dateRequired || o.dueDate || "";
        const days = daysUntil(due);
        const openLines = (o.lines || []).filter((l) => shopLineOpenQty(l) > 0);
        const needMat = (o.lines || []).filter(
          (l) =>
            l.materialStatus === "needs_attention" ||
            l.materialStatus === "unchecked",
        );
        return { order: o, due, days, openLines: openLines.length, needMat: needMat.length };
      })
      .sort((a, b) => {
        if (a.days == null && b.days == null) return 0;
        if (a.days == null) return 1;
        if (b.days == null) return -1;
        return a.days - b.days;
      });
  }, [shopOrders, canPo]);

  const queueOpen = useMemo(() => openQueue(workQueue), [workQueue]);

  const attention = useMemo(() => {
    const items: AttentionItem[] = [];

    for (const m of machines) {
      const sess = sessions[m];
      const timer = activeTimers[m];
      if (sess?.paused) {
        items.push({
          id: `pause-${m}`,
          severity: "warn",
          title: `${m} paused`,
          detail: sess.partNumber
            ? `${sess.partNumber} · ${sess.operatorName || "—"}`
            : sess.operatorName || "Paused with no part",
          href: `/machines/${machineToSlug(m)}`,
        });
      }
      if (timer) {
        const live = getLive(m) || 0;
        if (live > 4 * 3600) {
          items.push({
            id: `long-${m}`,
            severity: "info",
            title: `${m} timer over 4h`,
            detail: `${timer.type} ${timer.operation} · ${formatSeconds(live)} — verify still running`,
            href: `/machines/${machineToSlug(m)}`,
          });
        }
      }
    }

    // Order / material flags — only when this login can open those tabs
    if (canPo) {
      for (const row of openOrders) {
        if (row.days != null && row.days < 0) {
          items.push({
            id: `late-${row.order.id}`,
            severity: "danger",
            title: `Overdue PO ${row.order.poNumber || row.order.id.slice(0, 6)}`,
            detail: `${row.order.customer} · ${Math.abs(row.days)} day(s) past due · ${row.openLines} open line(s)`,
            href: "/po",
          });
        } else if (row.days != null && row.days <= 2) {
          items.push({
            id: `due-${row.order.id}`,
            severity: "warn",
            title: `Due soon · ${row.order.poNumber || "PO"}`,
            detail: `${row.order.customer} · ${row.days === 0 ? "today" : `${row.days} day(s)`} · ${row.openLines} open line(s)`,
            href: "/po",
          });
        }
        if (row.needMat > 0) {
          items.push({
            id: `mat-${row.order.id}`,
            severity: "warn",
            title: `Material needs attention · ${row.order.poNumber || "order"}`,
            detail: `${row.needMat} line(s) unchecked or short on ${row.order.customer}`,
            href: "/po",
          });
        }
      }
    }

    if (canInv || isAdmin) {
      for (const low of lowItems.slice(0, 6)) {
        items.push({
          id: `low-${low.id}`,
          severity: "warn",
          title: "Low stock",
          detail: `${low.label} · on hand ${low.onHand} (min ${low.minQty})`,
          href: "/inventory",
        });
      }
    }

    if (queueOpen.length > 8) {
      items.push({
        id: "queue-backlog",
        severity: "info",
        title: `${queueOpen.length} items in machine queues`,
        detail: "Assigned work waiting to start — check Shop Floor",
        href: "/machines",
      });
    }

    const rank = { danger: 0, warn: 1, info: 2 };
    return items.sort((a, b) => rank[a.severity] - rank[b.severity]).slice(0, 12);
  }, [
    machines,
    sessions,
    activeTimers,
    openOrders,
    lowItems,
    queueOpen,
    getLive,
    canPo,
    canInv,
    isAdmin,
  ]);

  const recentJobs = useMemo(() => {
    const list = isAdmin
      ? jobs
      : jobs.filter(
          (j) =>
            !myName ||
            j.operator?.toLowerCase() === myName.toLowerCase(),
        );
    return [...list]
      .sort(
        (a, b) =>
          new Date(b.startTime).getTime() - new Date(a.startTime).getTime(),
      )
      .slice(0, 8);
  }, [jobs, isAdmin, myName]);

  const showDemoHint =
    isAdmin &&
    shopOrders.length === 0 &&
    jobs.filter((j) => j.status === "Completed").length <= 3;

  return (
    <div className="mx-auto max-w-7xl space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight">
            Shop Dashboard
          </h1>
          <p className="text-[var(--color-muted)] mt-1 text-sm">
            {company}
            {myName ? ` · ${myName}` : ""}
            {isAdmin ? " · owner view" : " · floor view"}
            {" · "}
            {today}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link
            to="/machines"
            className="inline-flex items-center justify-center gap-1.5 rounded-[var(--radius-md)] bg-[var(--color-primary)] text-[var(--color-primary-fg)] px-4 py-2.5 text-sm font-medium min-h-11"
          >
            Shop floor <ChevronRight className="h-4 w-4" />
          </Link>
          {canPo && (
            <Link
              to="/po"
              className="inline-flex items-center justify-center gap-1.5 rounded-[var(--radius-md)] border border-[var(--color-border-strong)] px-4 py-2.5 text-sm font-medium min-h-11 hover:bg-[var(--color-surface-2)]"
            >
              Customer orders
            </Link>
          )}
          {(isAdmin || operatorCanAccessTab(me, "board")) && (
            <Link
              to="/board"
              className="inline-flex items-center justify-center gap-1.5 rounded-[var(--radius-md)] border border-[var(--color-border-strong)] px-4 py-2.5 text-sm font-medium min-h-11 hover:bg-[var(--color-surface-2)]"
            >
              Job board
            </Link>
          )}
          {(isAdmin || operatorCanAccessTab(me, "active")) && (
            <Link
              to="/active"
              className="inline-flex items-center justify-center gap-1.5 rounded-[var(--radius-md)] border border-[var(--color-border-strong)] px-4 py-2.5 text-sm font-medium min-h-11 hover:bg-[var(--color-surface-2)]"
            >
              Active jobs
            </Link>
          )}
        </div>
      </div>

      {/* KPI strip — role aware (no shop-wide $ for floor) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <StatCard
          icon={<Factory className="h-3.5 w-3.5" />}
          label="Live machines"
          value={String(liveCount)}
          hint={`${machines.length} total on floor`}
        />
        <StatCard
          icon={<AlertTriangle className="h-3.5 w-3.5" />}
          label="Needs attention"
          value={String(attention.length)}
          hint={attention[0]?.title || "Nothing flagged"}
          tone={attention.some((a) => a.severity === "danger") ? "danger" : attention.length ? "warn" : "ok"}
        />
        <StatCard
          icon={<Clock className="h-3.5 w-3.5" />}
          label={isAdmin ? "Today efficiency" : "My day efficiency"}
          value={
            isAdmin
              ? formatPercent(todayEff)
              : formatPercent(myDayBonus?.efficiency || 0)
          }
          hint={
            isAdmin
              ? `${todayCompleted.length} completed today`
              : myDayBonus?.eligible
                ? "On track for day bonus"
                : "Full shift required for bonus"
          }
        />
        {isAdmin ? (
          <StatCard
            icon={<DollarSign className="h-3.5 w-3.5" />}
            label="Week bonus open"
            value={formatCurrency(weekBonusOpen)}
            hint={`${dayBonuses.filter((d) => d.status === "finalized").length} days locked`}
          />
        ) : (
          <StatCard
            icon={<TrendingUp className="h-3.5 w-3.5" />}
            label="My day efficiency"
            value={formatPercent(myDayBonus?.efficiency || 0)}
            hint={
              myDayBonus?.eligible
                ? "Shift path looking good"
                : myDayBonus
                  ? "Keep logging full-shift time"
                  : "Load a job with your name"
            }
          />
        )}
      </div>

      {/* Needs attention */}
      <Card>
        <CardHeader className="pb-2 flex flex-row items-center justify-between gap-2 space-y-0">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-[var(--color-warn)]" />
              Needs attention
            </CardTitle>
            <CardDescription>
              {isAdmin
                ? "Overdue orders, material gaps, paused machines, low stock"
                : "Paused machines, long timers, and work that needs your eyes"}
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="space-y-1.5">
          {attention.length === 0 ? (
            <p className="text-sm text-[var(--color-success)] py-2">
              All clear — no urgent flags right now.
            </p>
          ) : (
            attention.map((a) => (
              <Link
                key={a.id}
                to={a.href}
                className="flex items-start gap-3 rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2.5 hover:bg-[var(--color-surface-2)] min-h-12"
              >
                <span
                  className={`mt-1.5 h-2 w-2 rounded-full shrink-0 ${
                    a.severity === "danger"
                      ? "bg-[var(--color-danger)]"
                      : a.severity === "warn"
                        ? "bg-[var(--color-warn)]"
                        : "bg-[var(--color-primary)]"
                  }`}
                />
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium truncate">{a.title}</div>
                  <div className="text-xs text-[var(--color-muted)] truncate">
                    {a.detail}
                  </div>
                </div>
                <ChevronRight className="h-4 w-4 text-[var(--color-subtle)] shrink-0 mt-1" />
              </Link>
            ))
          )}
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-2 gap-4">
        {/* Floor board */}
        <Card>
          <CardHeader className="pb-2 flex flex-row items-center justify-between gap-2 space-y-0">
            <CardTitle className="text-base">Floor board</CardTitle>
            <Link
              to="/machines"
              className="text-xs text-[var(--color-primary)] hover:underline"
            >
              All machines
            </Link>
          </CardHeader>
          <CardContent className="space-y-2">
            {machines.map((m) => {
              const sess = sessions[m];
              const timer = activeTimers[m];
              const live = timer ? getLive(m) : null;
              const busy = Boolean(timer || sess?.paused || sess?.jobId);
              const hint = nextOpHint(sess, maxOps);
              return (
                <Link
                  key={m}
                  to="/machines/$machineId"
                  params={{ machineId: machineToSlug(m) }}
                  className="block rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2.5 hover:bg-[var(--color-surface-2)] transition-colors"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="font-medium text-sm truncate">{m}</div>
                    <Badge
                      tone={
                        timer
                          ? "running"
                          : sess?.paused
                            ? "paused"
                            : busy
                              ? "info"
                              : "neutral"
                      }
                    >
                      {timer
                        ? "Running"
                        : sess?.paused
                          ? "Paused"
                          : busy
                            ? "Loaded"
                            : "Idle"}
                    </Badge>
                  </div>
                  <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-[var(--color-muted)]">
                    {sess?.partNumber ? (
                      <span className="font-mono text-[var(--color-fg)]">
                        {sess.partNumber}
                      </span>
                    ) : (
                      <span>No job</span>
                    )}
                    {sess?.operatorName && (
                      <span className="inline-flex items-center gap-0.5">
                        <UserRound className="h-3 w-3" />
                        {sess.operatorName}
                      </span>
                    )}
                    {timer && live != null && (
                      <span className="inline-flex items-center gap-0.5 text-[var(--color-running)] font-medium tabular">
                        <Timer className="h-3 w-3" />
                        {timer.type} {timer.operation} · {formatSeconds(live)}
                      </span>
                    )}
                    {sess?.paused && (
                      <span className="inline-flex items-center gap-0.5 text-[var(--color-warn)]">
                        <Pause className="h-3 w-3" />
                        Paused
                      </span>
                    )}
                  </div>
                  {busy && (
                    <div className="mt-1 text-[11px] text-[var(--color-subtle)]">
                      {hint}
                    </div>
                  )}
                </Link>
              );
            })}
          </CardContent>
        </Card>

        {/* Orders pipeline + queue */}
        <div className="space-y-4">
          {canPo && (
            <Card>
              <CardHeader className="pb-2 flex flex-row items-center justify-between gap-2 space-y-0">
                <CardTitle className="text-base flex items-center gap-2">
                  <ClipboardList className="h-4 w-4 text-[var(--color-primary)]" />
                  Customer orders
                </CardTitle>
                <Link
                  to="/po"
                  className="text-xs text-[var(--color-primary)] hover:underline"
                >
                  Open
                </Link>
              </CardHeader>
              <CardContent className="space-y-2">
                {openOrders.length === 0 ? (
                  <p className="text-sm text-[var(--color-muted)] py-2">
                    No open customer orders.
                  </p>
                ) : (
                  openOrders.slice(0, 6).map(({ order, due, days, openLines, needMat }) => (
                    <OrderRow
                      key={order.id}
                      order={order}
                      due={due}
                      days={days}
                      openLines={openLines}
                      needMat={needMat}
                    />
                  ))
                )}
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader className="pb-2 flex flex-row items-center justify-between gap-2 space-y-0">
              <CardTitle className="text-base">Assigned queue</CardTitle>
              <span className="text-xs text-[var(--color-muted)]">
                {queueOpen.length} open
              </span>
            </CardHeader>
            <CardContent className="space-y-1.5 text-sm">
              {queueOpen.length === 0 ? (
                <p className="text-[var(--color-muted)] text-xs py-1">
                  Nothing assigned to machines yet
                  {canPo ? " — assign from Customer Orders." : "."}
                </p>
              ) : (
                queueOpen.slice(0, 6).map((q, i) => (
                  <Link
                    key={q.id}
                    to="/machines/$machineId"
                    params={{ machineId: machineToSlug(q.machine) }}
                    className="flex justify-between gap-2 border-b border-[var(--color-border)] pb-1.5 last:border-0 hover:text-[var(--color-primary)]"
                  >
                    <span className="truncate">
                      <span className="text-[var(--color-subtle)] mr-1">
                        {i + 1}.
                      </span>
                      <span className="font-mono font-medium">{q.partNumber}</span>
                      <span className="text-xs text-[var(--color-muted)] ml-1">
                        → {q.machine}
                      </span>
                    </span>
                    <Badge tone={q.status === "active" ? "running" : "neutral"}>
                      {q.status}
                    </Badge>
                  </Link>
                ))
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        {canJobs && (
          <Card>
            <CardHeader className="pb-2 flex flex-row items-center justify-between gap-2 space-y-0">
              <CardTitle className="text-base">
                {isAdmin ? "Recent job runs" : "My recent runs"}
              </CardTitle>
              <Link
                to="/jobs"
                className="text-xs text-[var(--color-primary)] hover:underline"
              >
                Job history
              </Link>
            </CardHeader>
            <CardContent className="space-y-2">
              {recentJobs.map((j) => {
                const vs = jobVsQuote(j);
                const eff = j.efficiency > 1 ? j.efficiency / 100 : j.efficiency;
                const pct =
                  vs.quotedSeconds > 0
                    ? ((vs.actualSeconds - vs.quotedSeconds) / vs.quotedSeconds) *
                      100
                    : 0;
                return (
                  <Link
                    key={j.id}
                    to="/jobs"
                    className="flex items-start justify-between gap-3 border-b border-[var(--color-border)] pb-2 last:border-0 hover:bg-[var(--color-surface-2)] -mx-1 px-1 rounded"
                  >
                    <div className="min-w-0">
                      <div className="font-medium text-sm truncate">
                        {j.partNumber}
                        <span className="text-[var(--color-subtle)] font-normal ml-1">
                          rev {j.revision || "—"}
                        </span>
                      </div>
                      <div className="text-xs text-[var(--color-muted)] truncate">
                        {j.operator} · {j.machine}
                      </div>
                      <div className="text-[10px] text-[var(--color-subtle)]">
                        {formatDateTime(j.startTime)}
                      </div>
                    </div>
                    <div className="text-right shrink-0 space-y-0.5">
                      <Badge
                        tone={
                          j.status === "Completed"
                            ? "success"
                            : j.status === "In Progress"
                              ? "info"
                              : "warn"
                        }
                      >
                        {j.status}
                      </Badge>
                      {j.status === "Completed" && (
                        <>
                          <div className="text-[11px] tabular text-[var(--color-muted)]">
                            {formatSeconds(vs.quotedSeconds)} →{" "}
                            {formatSeconds(vs.actualSeconds)}
                          </div>
                          <div
                            className={`text-[11px] tabular font-medium ${
                              pct > 5
                                ? "text-[var(--color-danger)]"
                                : pct < -5
                                  ? "text-[var(--color-success)]"
                                  : "text-[var(--color-muted)]"
                            }`}
                          >
                            {pct > 0 ? "+" : ""}
                            {pct.toFixed(0)}% · {formatPercent(eff)}
                          </div>
                        </>
                      )}
                    </div>
                  </Link>
                );
              })}
              {recentJobs.length === 0 && (
                <p className="text-sm text-[var(--color-muted)]">No jobs yet.</p>
              )}
            </CardContent>
          </Card>
        )}

        {canInv && (
          <Card>
            <CardHeader className="pb-2 flex flex-row items-center justify-between gap-2 space-y-0">
              <CardTitle className="text-base flex items-center gap-2">
                <Package className="h-4 w-4" />
                Low stock
              </CardTitle>
              <Link
                to="/inventory"
                className="text-xs text-[var(--color-primary)] hover:underline"
              >
                Inventory
              </Link>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              {lowItems.length === 0 ? (
                <p className="text-[var(--color-muted)]">All stock above minimums.</p>
              ) : (
                lowItems.slice(0, 8).map((row) => (
                  <div
                    key={row.id}
                    className="flex justify-between gap-3 border-b border-[var(--color-border)] pb-1.5 last:border-0"
                  >
                    <span className="truncate">{row.label}</span>
                    <span className="text-[var(--color-warn)] tabular shrink-0">
                      {row.onHand} / min {row.minQty}
                    </span>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {isAdmin && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Today at a glance (owner)</CardTitle>
            <CardDescription>
              Open jobs {openJobs.length} · completed today {todayCompleted.length} ·
              queue {queueOpen.length} · open POs {openOrders.length}
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2 text-xs">
            <Link
              to="/reports"
              className="rounded-full border border-[var(--color-border)] px-3 py-1.5 min-h-9 inline-flex items-center hover:bg-[var(--color-surface-2)]"
            >
              <Activity className="h-3.5 w-3.5 mr-1.5" /> Reports
            </Link>
            <Link
              to="/email"
              search={{ quoteId: "", part: "" }}
              className="rounded-full border border-[var(--color-border)] px-3 py-1.5 min-h-9 inline-flex items-center hover:bg-[var(--color-surface-2)]"
            >
              Email quotes
            </Link>
            <Link
              to="/settings"
              className="rounded-full border border-[var(--color-border)] px-3 py-1.5 min-h-9 inline-flex items-center hover:bg-[var(--color-surface-2)]"
            >
              Settings / backups
            </Link>
            <Link
              to="/help"
              className="rounded-full border border-[var(--color-border)] px-3 py-1.5 min-h-9 inline-flex items-center hover:bg-[var(--color-surface-2)]"
            >
              How to use
            </Link>
          </CardContent>
        </Card>
      )}

      {!isAdmin && (
        <Card>
          <CardContent className="py-3 flex flex-wrap items-center justify-between gap-2 text-sm">
            <span className="text-[var(--color-muted)]">
              Need a refresher on the floor screens?
            </span>
            <Link
              to="/help"
              className="text-[var(--color-primary)] font-medium hover:underline min-h-9 inline-flex items-center"
            >
              How to use (floor guide)
            </Link>
          </CardContent>
        </Card>
      )}

      {showDemoHint && (
        <div className="flex items-start gap-3 rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-surface)] p-4 text-sm text-[var(--color-muted)]">
          <AlertTriangle className="h-4 w-4 mt-0.5 text-[var(--color-warn)] shrink-0" />
          <p>
            Still light on live customer orders. Import a PO under{" "}
            <strong className="text-[var(--color-fg)]">Customer Orders</strong>,
            set who is signed in with{" "}
            <strong className="text-[var(--color-fg)]">Switch user</strong>, then
            run timers from the floor. This tip hides once you have real orders
            and more completed jobs.
          </p>
        </div>
      )}
    </div>
  );
}

function OrderRow({
  order,
  due,
  days,
  openLines,
  needMat,
}: {
  order: ShopOrder;
  due: string;
  days: number | null;
  openLines: number;
  needMat: number;
}) {
  const dueLabel =
    days == null
      ? due || "No due date"
      : days < 0
        ? `${Math.abs(days)}d late`
        : days === 0
          ? "Due today"
          : `${days}d`;
  const tone =
    days != null && days < 0
      ? "danger"
      : days != null && days <= 2
        ? "warn"
        : "neutral";

  return (
    <Link
      to="/po"
      className="flex items-start justify-between gap-2 rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2 hover:bg-[var(--color-surface-2)]"
    >
      <div className="min-w-0">
        <div className="text-sm font-medium truncate">
          {order.poNumber || "PO"} · {order.customer}
        </div>
        <div className="text-xs text-[var(--color-muted)]">
          {openLines} open line{openLines === 1 ? "" : "s"}
          {needMat > 0 ? ` · ${needMat} material ?` : ""}
        </div>
      </div>
      <Badge tone={tone as "danger" | "warn" | "neutral"}>{dueLabel}</Badge>
    </Link>
  );
}

function StatCard({
  icon,
  label,
  value,
  hint,
  tone = "ok",
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint: string;
  tone?: "ok" | "warn" | "danger";
}) {
  return (
    <Card
      className={
        tone === "danger"
          ? "border-[color-mix(in_oklab,var(--color-danger)_40%,var(--color-border))]"
          : tone === "warn"
            ? "border-[color-mix(in_oklab,var(--color-warn)_35%,var(--color-border))]"
            : undefined
      }
    >
      <CardContent className="p-4 sm:p-5">
        <div className="flex items-center gap-2 text-[var(--color-muted)] text-xs font-medium uppercase tracking-wide">
          {icon}
          {label}
        </div>
        <div className="mt-2 text-2xl font-semibold tracking-tight tabular">
          {value}
        </div>
        <div className="text-xs text-[var(--color-subtle)] mt-1 truncate">
          {hint}
        </div>
      </CardContent>
    </Card>
  );
}
