import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  Play,
  Square,
  Pause,
  Save,
  Search,
  Eraser,
  Database,
  Pencil,
  FileText,
  Maximize2,
  X,
  ExternalLink,
} from "lucide-react";
import { toast } from "sonner";
import { queueForMachine } from "@/lib/lcm/work-queue";
import { queueItemDisplay } from "@/lib/lcm/queue-display";
import { QueueJobMeta } from "@/components/lcm/queue-job-meta";
import { DrawingThumb } from "@/components/lcm/drawing-thumb";
import { useLcmStore, getInProgressJobsForPart } from "@/store/lcm-store";
import { slugToMachine, machineToSlug } from "@/lib/lcm/machines";
import { clampOpCount, makeOpLabels, opIndex, opLabel, zeros } from "@/lib/lcm/ops";
import {
  allMaterials,
  allMaterialTypes,
  allPauseReasons,
  allStockShapes,
  allMachines,
} from "@/lib/lcm/lists";
import { quoteFromForm } from "@/lib/lcm/calculations";
import { Button } from "@/components/ui/button";
import { HelpTip, WithHelp } from "@/components/ui/help-tip";
import { Input, Label, Textarea } from "@/components/ui/input";
import { CreatableSelect } from "@/components/ui/creatable-select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DayBonusPanel } from "@/components/day-bonus-panel";
import { ShopToolingFloorPanel } from "@/components/lcm/shop-tooling-panel";
import { useCanSeeMoney } from "@/hooks/use-can-see-money";
import {
  deriveFloorStep,
  toBarStep,
  barStepIndex,
  FLOOR_SCRIPT_STEPS,
} from "@/lib/lcm/floor-script";
import {
  ticketsForPart,
  qtyAvailable,
  statusLabel,
  cutTicketLabel,
} from "@/lib/lcm/cut-tickets";
import {
  formatCurrency,
  formatPercent,
  formatSeconds,
  formatDateTime,
  cn,
} from "@/lib/utils";
import { resolveAttachment } from "@/lib/lcm/open-attachment";
import type { LineFileRef, ShopOrder } from "@/lib/lcm/types";
import { getOperatorByEmail } from "@/lib/lcm/permissions";
import { listMyActiveJobs } from "@/lib/lcm/active-jobs";
import { findPairHint } from "@/lib/lcm/job-pair";

export const Route = createFileRoute("/machines/$machineId")({
  component: MachineDetailPage,
});

type NewPartDraft = {
  partNumber: string;
  revision: string;
  quantity: string;
  customer: string;
  material: string;
  materialType: string;
  stockShape: string;
  /** OP1 setup minutes (optional but recommended) */
  setupMin: string;
  /** OP1 run minutes per piece (optional but recommended) */
  runMin: string;
  notes: string;
};

const emptyNewPart = (partial?: Partial<NewPartDraft>): NewPartDraft => ({
  partNumber: "",
  revision: "A",
  quantity: "10",
  customer: "",
  material: "Aluminum",
  materialType: "T6 6061",
  stockShape: "Round Stock",
  setupMin: "",
  runMin: "",
  notes: "",
  ...partial,
});

function MachineDetailPage() {
  const canSeeMoneyOnFloor = useCanSeeMoney();
  const { machineId } = Route.useParams();
  const operators = useLcmStore((s) => s.operators);
  const quotes = useLcmStore((s) => s.quotes);
  const shopOrders = useLcmStore((s) => s.shopOrders || []);
  const customers = useLcmStore((s) => s.customers);
  const cutTicketsRaw = useLcmStore((s) => s.cutTickets);
  const cutTickets = cutTicketsRaw || [];
  const claimCutStock = useLcmStore((s) => s.claimCutStock);
  const maxOps = useLcmStore((s) => clampOpCount(s.settings.maxOperations));
  const customLists = useLcmStore((s) => s.settings.customLists);
  const addCustomListItem = useLcmStore((s) => s.addCustomListItem);
  const addCustomerQuick = useLcmStore((s) => s.addCustomerQuick);
  const addOperatorQuick = useLcmStore((s) => s.addOperatorQuick);
  const saveQuote = useLcmStore((s) => s.saveQuote);

  const machine = useMemo(
    () => slugToMachine(machineId, customLists),
    [machineId, customLists],
  );

  const pauseReasonOptions = useMemo(
    () => allPauseReasons(customLists),
    [customLists],
  );
  const customerOptions = useMemo(
    () => customers.map((c) => c.name),
    [customers],
  );
  const operatorOptions = useMemo(
    () => operators.filter((o) => o.active).map((o) => o.name),
    [operators],
  );
  const materialOptions = useMemo(
    () => allMaterials(customLists),
    [customLists],
  );
  const stockShapeOptions = useMemo(
    () => allStockShapes(customLists),
    [customLists],
  );
  const opLabels = useMemo(() => makeOpLabels(maxOps), [maxOps]);
  const session = useLcmStore((s) => (machine ? s.sessions[machine] : undefined));
  const timer = useLcmStore((s) => (machine ? s.activeTimers[machine] : null));
  const setOperator = useLcmStore((s) => s.setOperatorOnMachine);
  const loadJob = useLcmStore((s) => s.loadJobOnMachine);
  const attachPair = useLcmStore((s) => s.attachPairOnMachine);
  const clearPair = useLcmStore((s) => s.clearPairOnMachine);
  const smartStart = useLcmStore((s) => s.smartStart);
  const smartStop = useLcmStore((s) => s.smartStop);
  const pauseJob = useLcmStore((s) => s.pauseJob);
  const resumeJob = useLcmStore((s) => s.resumeJob);
  const adjustOpTime = useLcmStore((s) => s.adjustOpTime);
  const reopenOpTimer = useLcmStore((s) => s.reopenOpTimer);
  const saveJob = useLcmStore((s) => s.saveJob);
  const stockPartUnits = useLcmStore((s) => s.stockPartUnits);
  const clearSession = useLcmStore((s) => s.clearMachineSession);
  const updateNotes = useLcmStore((s) => s.updateSessionNotes);
  const updateField = useLcmStore((s) => s.updateSessionField);
  const getLive = useLcmStore((s) => s.getLiveElapsedSeconds);
  const currentEmail = useLcmStore((s) => s.currentUserEmail);
  const sessions = useLcmStore((s) => s.sessions);
  const allTimers = useLcmStore((s) => s.activeTimers);
  const operatorTimeLog = useLcmStore((s) => s.operatorTimeLog || []);
  const workQueue = useLcmStore((s) => s.workQueue || []);
  const startWorkQueueItem = useLcmStore((s) => s.startWorkQueueItem);
  const moveWorkQueueItem = useLcmStore((s) => s.moveWorkQueueItem);
  const removeWorkQueueItem = useLcmStore((s) => s.removeWorkQueueItem);
  const completeWorkQueueItem = useLcmStore((s) => s.completeWorkQueueItem);
  const shopToolingLogs = useLcmStore((s) => s.shopToolingLogs || []);
  const stopShopToolingTimer = useLcmStore((s) => s.stopShopToolingTimer);
  const startShopToolingLog = useLcmStore((s) => s.startShopToolingLog);
  const machineQueue = useMemo(
    () => (machine ? queueForMachine(workQueue, machine) : []),
    [workQueue, machine],
  );

  const [partSearch, setPartSearch] = useState("");
  const [pairSearch, setPairSearch] = useState("");
  const [rev, setRev] = useState("A");
  const [qty, setQty] = useState("10");
  const [customer, setCustomer] = useState("");
  const [unitsPrompt, setUnitsPrompt] = useState(false);
  const [units, setUnits] = useState("0");
  const [pauseOpen, setPauseOpen] = useState(false);
  const [pauseReason, setPauseReason] = useState("Lunch");
  const [toolingSkipped, setToolingSkipped] = useState(false);
  const [saveOpen, setSaveOpen] = useState(false);
  const [saveQty, setSaveQty] = useState("0");
  const [countInAverage, setCountInAverage] = useState(true);
  const [extraStockOpen, setExtraStockOpen] = useState(false);
  const [extraQty, setExtraQty] = useState("");
  const [extraLocation, setExtraLocation] = useState("");
  const [extraQuality, setExtraQuality] = useState<"good" | "second">("good");
  const [extraDefectNote, setExtraDefectNote] = useState("");
  const [pendingCompleteQty, setPendingCompleteQty] = useState<number | null>(null);
  const [extraUins, setExtraUins] = useState<string[]>([]);
  const [uinWriteOpen, setUinWriteOpen] = useState(false);
  const [newPartOpen, setNewPartOpen] = useState(false);
  const [newPart, setNewPart] = useState<NewPartDraft>(emptyNewPart());
  const [pendingExistingJobId, setPendingExistingJobId] = useState<
    string | undefined
  >();
  const [tick, setTick] = useState(0);
  const [timeEdit, setTimeEdit] = useState<null | {
    idx: number;
    type: "Setup" | "Runtime";
    seconds: number;
  }>(null);
  const [editH, setEditH] = useState("0");
  const [editM, setEditM] = useState("0");
  const [editS, setEditS] = useState("0");

  const isAdmin = useMemo(() => {
    const me = operators.find(
      (o) => o.email.toLowerCase() === currentEmail.toLowerCase(),
    );
    return me?.role === "admin";
  }, [operators, currentEmail]);

  const lastStop = useMemo(() => {
    if (!session?.jobId || !machine) return null;
    const row = operatorTimeLog.find(
      (r) =>
        r.jobId === session.jobId &&
        r.machine === machine &&
        r.endTime,
    );
    if (row) {
      const idx = opIndex(row.operation);
      const cell =
        row.type === "Setup" ? session.setups?.[idx] : session.runtimes?.[idx];
      const seconds = typeof cell === "number" ? cell : 0;
      return { idx, type: row.type as "Setup" | "Runtime", seconds, operation: row.operation };
    }
    const n = session.setups?.length || 0;
    for (let i = n - 1; i >= 0; i--) {
      if (typeof session.runtimes?.[i] === "number") {
        return {
          idx: i,
          type: "Runtime" as const,
          seconds: Number(session.runtimes[i]),
          operation: opLabel(i),
        };
      }
      if (typeof session.setups?.[i] === "number") {
        return {
          idx: i,
          type: "Setup" as const,
          seconds: Number(session.setups[i]),
          operation: opLabel(i),
        };
      }
    }
    return null;
  }, [session, machine, operatorTimeLog]);

  const lastStopIsActive =
    Boolean(timer) &&
    Boolean(lastStop) &&
    timer?.operation === lastStop?.operation &&
    timer?.type === lastStop?.type;

  const jobPrints = useMemo(
    () =>
      collectJobPrints(
        shopOrders,
        session?.partNumber || "",
        session?.revision || "",
      ),
    [shopOrders, session?.partNumber, session?.revision],
  );
  const [printOpen, setPrintOpen] = useState(false);
  const [printBusy, setPrintBusy] = useState(false);
  const [printIdx, setPrintIdx] = useState(0);
  const [printView, setPrintView] = useState<{
    url: string;
    mime: string;
    name: string;
    revoke?: () => void;
  } | null>(null);

  useEffect(() => {
    return () => {
      printView?.revoke?.();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadPrintAt(index: number, opts?: { popOut?: boolean }) {
    const file = jobPrints[index];
    if (!file) {
      toast.error("No print on this job — attach the drawing on the order.");
      return;
    }
    setPrintBusy(true);
    const r = await resolveAttachment({ id: file.id, name: file.name });
    setPrintBusy(false);
    if (!r.ok) {
      toast.error(r.error || "Could not open print");
      return;
    }
    printView?.revoke?.();
    const next = {
      url: r.url,
      mime: r.mime,
      name: r.name || file.name || "Print",
      revoke: r.revoke,
    };
    setPrintView(next);
    setPrintIdx(index);
    setPrintOpen(true);
    if (opts?.popOut) {
      const ok = popOutPrintWindow(
        next.url,
        next.name,
        next.mime,
        session?.partNumber || "",
        session?.revision || "",
      );
      if (!ok) toast.message("Popup blocked — print is full screen on this page.");
    }
  }

  function openTimeEdit(
    idx: number,
    type: "Setup" | "Runtime",
    seconds: number,
  ) {
    const s = Math.max(0, Math.floor(seconds || 0));
    setTimeEdit({ idx, type, seconds: s });
    setEditH(String(Math.floor(s / 3600)));
    setEditM(String(Math.floor((s % 3600) / 60)));
    setEditS(String(s % 60));
  }

  const typeOptions = useMemo(
    () => allMaterialTypes(newPart.material || "Aluminum", customLists),
    [newPart.material, customLists],
  );

  useEffect(() => {
    const id = setInterval(() => setTick((n) => n + 1), 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (session?.partNumber) {
      setPartSearch(session.partNumber);
      setRev(session.revision || "A");
      setQty(String(session.quantity || 0));
      setCustomer(session.customer || "");
    }
  }, [session?.jobId]);

  useEffect(() => {
    setToolingSkipped(false);
  }, [session?.jobId]);

  const liveSeconds = machine ? getLive(machine) : null;

  const nextHint = useMemo(() => {
    if (!session) return "—";
    const n = Math.max(session.setups?.length || 0, maxOps);
    const anyQuoted =
      session.quotedSetups?.some((v) => (v || 0) > 0) ||
      session.quotedRuntimes?.some((v) => (v || 0) > 0);
    for (let i = 0; i < n; i++) {
      const planned =
        !anyQuoted ||
        (session.quotedSetups[i] || 0) > 0 ||
        (session.quotedRuntimes[i] || 0) > 0 ||
        session.setups[i] != null ||
        session.runtimes[i] != null;
      if (!planned) continue;
      if (session.setups[i] == null) return `Next: ${opLabel(i)} Setup`;
      if (session.runtimes[i] == null) return `Next: ${opLabel(i)} Runtime`;
    }
    return "All operations complete";
  }, [session, maxOps]);

  const toolingRunning = useMemo(
    () =>
      Boolean(
        machine &&
          shopToolingLogs.some(
            (l) =>
              l.machine === machine && l.status === "open" && l.timerStartedAt,
          ),
      ),
    [shopToolingLogs, machine, tick],
  );
  const toolingLogged = useMemo(
    () =>
      Boolean(
        machine &&
          session?.jobId &&
          shopToolingLogs.some(
            (l) =>
              l.machine === machine &&
              l.jobId === session.jobId &&
              (l.minutes > 0 || !l.timerStartedAt),
          ),
      ),
    [shopToolingLogs, machine, session?.jobId],
  );
  const floorStep = useMemo(
    () =>
      deriveFloorStep({
        session,
        timer,
        maxOps,
        toolingSkipped,
        toolingRunning,
        toolingLogged,
      }),
    [session, timer, maxOps, toolingSkipped, toolingRunning, toolingLogged],
  );
  const floorBar = toBarStep(floorStep.id);
  const floorBarIdx = barStepIndex(floorBar);

  if (!machine) {
    return (
      <div className="max-w-lg mx-auto text-center space-y-4 py-16">
        <p className="text-[var(--color-muted)]">Unknown machine.</p>
        <Link to="/machines" className="text-[var(--color-primary)]">
          Back to shop floor
        </Link>
      </div>
    );
  }

  function doLoadJob(opts: {
    partNumber: string;
    revision: string;
    quantity: number;
    customer: string;
    existingJobId?: string;
    fromDb: boolean;
    pair?: {
      partNumber: string;
      revision: string;
      quantity: number;
      customer?: string;
    };
  }) {
    if (!machine) return;
    const result = loadJob(machine, {
      partNumber: opts.partNumber,
      revision: opts.revision,
      quantity: opts.quantity,
      customer: opts.customer,
      existingJobId: opts.existingJobId,
      pair: opts.pair,
    });
    if (!result.ok) {
      toast.error(result.error);
      return;
    }
    setRev(opts.revision);
    setCustomer(opts.customer);
    setQty(String(opts.quantity));
    setPartSearch(opts.partNumber.toUpperCase());
    toast.success(
      opts.pair
        ? `Loaded pair ${opts.partNumber} + ${opts.pair.partNumber}`
        : opts.existingJobId
          ? `Resumed in-progress job for ${opts.partNumber}`
          : opts.fromDb
            ? `Loaded ${opts.partNumber} from database`
            : `Saved ${opts.partNumber} to database and loaded job`,
    );
  }

  function handleSearchLoad() {
    const pn = partSearch.trim().toUpperCase();
    if (!pn || !machine) {
      toast.error("Enter a part number");
      return;
    }
    const open = getInProgressJobsForPart(pn);
    const existingJobId = open[0]?.id;
    const quote = quotes.find(
      (q) => q.partNumber.toLowerCase() === pn.toLowerCase(),
    );

    // Known part → load immediately
    if (quote) {
      doLoadJob({
        partNumber: pn,
        revision: rev || quote.revision || "A",
        quantity: Number(qty) || quote.quantities.find((q) => q > 0) || 1,
        customer: customer || quote.customer || open[0]?.customer || "",
        existingJobId,
        fromDb: true,
      });
      return;
    }

    // Unknown part → capture database fields first
    setPendingExistingJobId(existingJobId);
    setNewPart(
      emptyNewPart({
        partNumber: pn,
        revision: rev || "A",
        quantity: qty || "10",
        customer: customer || open[0]?.customer || "",
        material: "Aluminum",
        materialType: "T6 6061",
        stockShape: "Round Stock",
      }),
    );
    setNewPartOpen(true);
  }

  function onNewPartMaterialChange(material: string) {
    const types = allMaterialTypes(material, customLists);
    setNewPart((f) => {
      const stillValid = types.some(
        (t) => t.toLowerCase() === (f.materialType || "").toLowerCase(),
      );
      return {
        ...f,
        material,
        materialType: stillValid ? f.materialType : types[0] || "",
      };
    });
  }

  function confirmNewPart() {
    if (!machine) return;
    const pn = newPart.partNumber.trim().toUpperCase();
    if (!pn) {
      toast.error("Part number required");
      return;
    }
    if (!newPart.material.trim()) {
      toast.error("Select a material");
      return;
    }
    if (!newPart.materialType.trim()) {
      toast.error("Select a material type");
      return;
    }
    if (!newPart.customer.trim()) {
      toast.error("Select or add a customer");
      return;
    }

    const setup = Number(newPart.setupMin) || 0;
    const run = Number(newPart.runMin) || 0;
    const setupTimes = zeros(maxOps);
    const runTimes = zeros(maxOps);
    setupTimes[0] = setup;
    runTimes[0] = run;
    const quantities = [Number(newPart.quantity) || 1, 0, 0, 0, 0, 0];

    const quote = quoteFromForm(
      {
        partNumber: pn,
        revision: (newPart.revision || "A").toUpperCase(),
        customer: newPart.customer.trim(),
        machines: [machine],
        material: newPart.material.trim(),
        materialType: newPart.materialType.trim(),
        stockShape: newPart.stockShape || "Round Stock",
        machineRate: 1,
        materialPct: 1.15,
        setupTimes,
        runTimes,
        quantities,
        prices: [0, 0, 0, 0, 0, 0],
      },
      maxOps,
    );

    const saved = saveQuote(quote, "submit");
    if (!saved.ok) {
      // If somehow created between open and confirm, try update
      const updated = saveQuote(quote, "update");
      if (!updated.ok) {
        toast.error(saved.error || updated.error || "Could not save part");
        return;
      }
    }

    // Stash shop note onto machine session after load
    const noteLine = newPart.notes.trim();
    doLoadJob({
      partNumber: pn,
      revision: quote.revision,
      quantity: Number(newPart.quantity) || 1,
      customer: quote.customer,
      existingJobId: pendingExistingJobId,
      fromDb: false,
    });
    if (noteLine) {
      updateNotes(machine, noteLine);
    }
    setNewPartOpen(false);
    setPendingExistingJobId(undefined);
  }

  function handleStart() {
    if (!machine) return;
    const r = smartStart(machine);
    if (!r.ok) toast.error(r.error);
    else toast.success(r.message || "Started");
  }

  function handleStop() {
    if (!machine) return;
    const r = smartStop(machine);
    if (r.needsUnits) {
      setUnitsPrompt(true);
      return;
    }
    if (!r.ok) toast.error(r.error);
    else toast.success("Timer stopped");
  }

  function confirmUnits() {
    if (!machine) return;
    const r = smartStop(machine, Number(units) || 0);
    if (!r.ok) toast.error(r.error);
    else {
      toast.success("Runtime stopped");
      setUnitsPrompt(false);
    }
  }

  function handlePause() {
    if (!machine) return;
    const r = pauseJob(machine, pauseReason);
    if (!r.ok) toast.error(r.error);
    else {
      toast.success(`Paused: ${pauseReason}`);
      setPauseOpen(false);
    }
  }

  function handleResume() {
    if (!machine) return;
    const r = resumeJob(machine);
    if (!r.ok) toast.error(r.error);
    else toast.success(r.message || "Job resumed");
  }

  function handleFloorPrimary() {
    if (!machine) return;
    switch (floorStep.id) {
      case "load": {
        const next = machineQueue[0];
        if (next) {
          const r = startWorkQueueItem(next.id);
          if (!r.ok) toast.error(r.error || "Could not load queue item");
          else toast.success(`Loaded ${next.partNumber} from queue`);
          return;
        }
        handleSearchLoad();
        return;
      }
      case "tooling": {
        const running = shopToolingLogs.find(
          (l) =>
            l.machine === machine && l.status === "open" && l.timerStartedAt,
        );
        if (running) {
          const r = stopShopToolingTimer(running.id);
          if (!r.ok) toast.error(r.error);
          else toast.success("Jaws time saved");
          return;
        }
        setToolingSkipped(true);
        toast.message("Jaws skipped — still available below");
        return;
      }
      case "start":
        handleStart();
        return;
      case "running":
        handleStop();
        return;
      case "paused": {
        const r = resumeJob(machine);
        if (!r.ok) toast.error(r.error);
        else if (floorStep.primaryLabel === "Finish job" && !session?.pausedTimer) {
          setSaveQty(String(session?.quantityCompleted || 0));
          setSaveOpen(true);
        } else {
          toast.success(r.message || "Job resumed");
        }
        return;
      }
      case "finish":
        setSaveQty(String(session?.quantityCompleted || 0));
        setSaveOpen(true);
        return;
      default:
        return;
    }
  }

  function finishJobComplete(qtyDone: number) {
    if (!machine) return;
    const r = saveJob(machine, "completed", qtyDone, { countInAverage });
    if (!r.ok) {
      toast.error(r.error);
      return;
    }
    toast.success(
      countInAverage
        ? "Job completed · shop average updated (recipe times)"
        : "Job completed · excluded from averages (history only)",
    );
    setSaveOpen(false);
    setExtraStockOpen(false);
    setPendingCompleteQty(null);
    setCountInAverage(true);
  }

  function handleSave(mode: "in-progress" | "completed") {
    if (!machine) return;
    const qtyDone = Number(saveQty);
    const planned = Number(session?.quantity) || 0;

    if (mode === "in-progress") {
      const r = saveJob(machine, mode, Number.isFinite(qtyDone) ? qtyDone : 0);
      if (!r.ok) toast.error(r.error);
      else {
        toast.success("Saved in progress");
        setSaveOpen(false);
        setCountInAverage(true);
      }
      return;
    }

    // Completed — if they made more than the job qty, ask about stock
    const done = Number.isFinite(qtyDone) ? qtyDone : planned;
    const extras = Math.max(0, Math.floor(done - planned));
    if (extras > 0 && (session?.partNumber || "").trim()) {
      setPendingCompleteQty(done);
      setExtraQty(String(extras));
      setExtraLocation("");
      setExtraQuality("good");
      setExtraDefectNote("");
      setExtraStockOpen(true);
      return;
    }
    finishJobComplete(done);
  }

  function handleExtraStockDecision(stockThem: boolean) {
    const done = pendingCompleteQty ?? (Number(saveQty) || 0);
    const pn = session?.partNumber || "";
    const rev = session?.revision || "";
    const jobRef = session?.jobId || "";

    if (stockThem) {
      const n = Math.max(0, Math.floor(Number(extraQty) || 0));
      if (n <= 0) {
        toast.error("Enter how many extras go to stock (or choose No)");
        return;
      }
      const r = stockPartUnits({
        partNumber: pn,
        revision: rev,
        qty: n,
        location: extraLocation,
        jobRef,
        quality: extraQuality,
        defectNote: extraDefectNote,
      });
      if (!r.ok) {
        toast.error(r.error || "Could not update stock");
        return;
      }
      const codes = (r.units || []).map((u) => u.uin);
      setExtraUins(codes);
      setExtraStockOpen(false);
      setUinWriteOpen(true);
      // complete job after they dismiss UIN card — keep pending qty
      return;
    }

    finishJobComplete(done);
  }

  function confirmUinsWritten() {
    const done = pendingCompleteQty ?? (Number(saveQty) || 0);
    setUinWriteOpen(false);
    setExtraUins([]);
    toast.success(
      extraQuality === "second"
        ? "Second-quality parts stocked — write UINs on each part"
        : "Extras stocked — write UINs on each part",
    );
    finishJobComplete(done);
  }

  const displayOps = useMemo(() => {
    if (!session?.jobId) return opLabels;
    const anyQuoted =
      session.quotedSetups?.some((v) => (v || 0) > 0) ||
      session.quotedRuntimes?.some((v) => (v || 0) > 0);
    if (!anyQuoted) return opLabels;
    let last = 0;
    for (let i = 0; i < maxOps; i++) {
      if (
        (session.quotedSetups[i] || 0) > 0 ||
        (session.quotedRuntimes[i] || 0) > 0 ||
        session.setups[i] != null ||
        session.runtimes[i] != null
      ) {
        last = i;
      }
    }
    return makeOpLabels(Math.min(maxOps, Math.max(last + 1, 1)));
  }, [session, opLabels, maxOps]);

  const myName = useMemo(() => {
    const op = getOperatorByEmail(operators, currentEmail);
    return op?.name || session?.operatorName || currentEmail.split("@")[0] || "";
  }, [operators, currentEmail, session?.operatorName]);

  const myActiveJobs = useMemo(() => {
    const list = allMachines(customLists);
    return listMyActiveJobs(list, sessions, allTimers, myName);
  }, [customLists, sessions, allTimers, myName]);

  return (
    <div className="mx-auto max-w-xl space-y-4">
      <div className="flex items-center gap-3">
        <Link
          to="/machines"
          className="inline-flex h-11 w-11 items-center justify-center rounded-[var(--radius-md)] border border-[var(--color-border)] shrink-0 hover:bg-[var(--color-surface-2)]"
          title="All machines"
        >
          <ArrowLeft className="h-4 w-4" />
        </Link>
        <div className="min-w-0 flex-1">
          <h1 className="text-xl font-semibold tracking-tight truncate">
            {machine}
          </h1>
          {session?.partNumber ? (
            <p className="text-xs text-[var(--color-muted)] truncate">
              {session.partNumber}
              {session.pairPartNumber ? ` + ${session.pairPartNumber}` : ""}
              {session.revision ? ` · Rev ${session.revision}` : ""}
              {session.operatorName ? ` · ${session.operatorName}` : ""}
            </p>
          ) : (
            <p className="text-xs text-[var(--color-muted)]">Guided station</p>
          )}
        </div>
        {session?.jobId && jobPrints.length > 0 && (
          <Button
            size="sm"
            type="button"
            className="min-h-10 shrink-0"
            disabled={printBusy}
            onClick={() => void loadPrintAt(printIdx || 0)}
          >
            <FileText className="h-4 w-4" />
            Print
          </Button>
        )}
        {timer && (
          <Badge tone="running" className="shrink-0">
            <span className="live-dot mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-current" />
            {formatSeconds(liveSeconds || 0)}
          </Badge>
        )}
        {session?.paused && !timer && <Badge tone="paused">PAUSED</Badge>}
      </div>

      <div className="flex flex-wrap gap-1.5">
        {myActiveJobs.map((row) => {
          const here = row.machine === machine;
          const live = getLive(row.machine);
          return (
            <Link
              key={row.machine}
              to="/machines/$machineId"
              params={{ machineId: machineToSlug(row.machine) }}
              className={cn(
                "inline-flex items-center min-h-11 px-3 rounded-[var(--radius-md)] border text-xs font-medium",
                here
                  ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_16%,transparent)]"
                  : "border-[var(--color-border)] hover:bg-[var(--color-surface-2)]",
              )}
            >
              <span className="truncate max-w-[10rem]">
                {row.machine}
                {row.session.partNumber ? ` · ${row.session.partNumber}` : ""}
              </span>
              {row.timer ? (
                <span className="ml-2 tabular text-[var(--color-status-active)]">
                  {formatSeconds(live || 0)}
                </span>
              ) : null}
            </Link>
          );
        })}
        <Link
          to="/active"
          className="inline-flex items-center min-h-11 px-3 rounded-[var(--radius-md)] border border-[var(--color-border)] text-xs font-medium hover:bg-[var(--color-surface-2)]"
        >
          My jobs
        </Link>
      </div>

      {session?.jobId ? (
        <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2.5 text-sm space-y-2">
          {session.pairPartNumber ? (
            <>
              <div className="font-medium">Nested on this machine</div>
              <p className="text-xs text-[var(--color-muted)]">
                Floor nest — one clock. Good pieces count on both{" "}
                {session.partNumber} and {session.pairPartNumber}.
              </p>
              <label className="flex items-start gap-2 text-xs">
                <input
                  type="checkbox"
                  className="mt-0.5"
                  checked={Boolean(session.pairTwoVise)}
                  onChange={(e) =>
                    updateField(machine, { pairTwoVise: e.target.checked })
                  }
                />
                <span>
                  <strong>Two vises, one cycle</strong> — vise 1 is OP1 of both
                  parts, vise 2 is OP2 of both. One Setup, then one Runtime.
                  Do not start a second op timer.
                </span>
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-[var(--color-muted)]">
                    {session.partNumber}
                  </span>
                  <div className="tabular font-semibold">
                    {session.quantityCompleted || 0} / {session.quantity || 0}
                  </div>
                </div>
                <div>
                  <span className="text-[var(--color-muted)]">
                    {session.pairPartNumber}
                  </span>
                  <div className="tabular font-semibold">
                    {session.pairQuantityCompleted || 0} /{" "}
                    {session.pairQuantity || 0}
                  </div>
                </div>
              </div>
              <Button
                size="sm"
                variant="outline"
                type="button"
                onClick={() => {
                  const r = clearPair(machine);
                  if (!r.ok) toast.error(r.error);
                  else {
                    setPairSearch("");
                    toast.message(
                      `${session.pairPartNumber} dropped · ${session.partNumber} still running`,
                    );
                  }
                }}
              >
                Drop nested part
              </Button>
            </>
          ) : (
            <>
              <div className="font-medium">Nest another part (optional)</div>
              <p className="text-xs text-[var(--color-muted)]">
                You decide the vise mix — type any P/N. Timer stays running.
              </p>
              <div className="flex flex-wrap gap-2">
                <Input
                  value={pairSearch}
                  onChange={(e) => setPairSearch(e.target.value.toUpperCase())}
                  placeholder="Nested part #"
                  list="pair-part-suggestions"
                  className="flex-1 min-w-[10rem]"
                />
                <datalist id="pair-part-suggestions">
                  {quotes
                    .filter(
                      (q) =>
                        q.partNumber.toUpperCase() !==
                        (session.partNumber || "").toUpperCase(),
                    )
                    .map((q) => (
                      <option key={q.id} value={q.partNumber} />
                    ))}
                </datalist>
                <Button
                  size="sm"
                  type="button"
                  onClick={() => {
                    const pn = pairSearch.trim().toUpperCase();
                    if (!pn) {
                      toast.error("Enter the nested part number");
                      return;
                    }
                    const open = getInProgressJobsForPart(pn);
                    const quote = quotes.find(
                      (q) => q.partNumber.toUpperCase() === pn,
                    );
                    const r = attachPair(machine, {
                      partNumber: pn,
                      revision: quote?.revision || session.revision || "A",
                      quantity:
                        quote?.quantities?.find((n) => n > 0) ||
                        session.quantity ||
                        1,
                      customer: quote?.customer || session.customer || "",
                      existingJobId: open[0]?.id,
                    });
                    if (!r.ok) toast.error(r.error);
                    else toast.success(`Nested ${pn} with ${session.partNumber}`);
                  }}
                >
                  Nest this part
                </Button>
              </div>
              {(() => {
                const hint = findPairHint(session.partNumber, {
                  quotes,
                  shopOrders,
                  preferQty: session.quantity,
                  preferRev: session.revision,
                  preferCustomer: session.customer,
                });
                if (!hint) return null;
                return (
                  <button
                    type="button"
                    className="text-xs text-[var(--color-primary)] underline-offset-2 hover:underline"
                    onClick={() => {
                      setPairSearch(hint.partNumber);
                      const open = getInProgressJobsForPart(hint.partNumber);
                      const r = attachPair(machine, {
                        partNumber: hint.partNumber,
                        revision: hint.revision,
                        quantity: hint.quantity,
                        customer: hint.customer,
                        existingJobId: open[0]?.id,
                      });
                      if (!r.ok) toast.error(r.error);
                      else
                        toast.success(
                          `Nested ${hint.partNumber} with ${session.partNumber}`,
                        );
                    }}
                  >
                    Suggestion: {hint.partNumber}
                  </button>
                );
              })()}
            </>
          )}
        </div>
      ) : null}

      <Card>
        <CardContent className="p-4 space-y-4">
          <div className="flex items-center gap-1 overflow-x-auto">
            {FLOOR_SCRIPT_STEPS.map((s, i) => {
              const active = s.id === floorBar;
              const done = i < floorBarIdx;
              return (
                <div key={s.id} className="flex items-center gap-1 shrink-0">
                  {i > 0 && (
                    <span className="text-[var(--color-subtle)] px-0.5">→</span>
                  )}
                  <span
                    className={
                      active
                        ? "rounded-full bg-[var(--color-primary)] text-[var(--color-primary-fg)] px-2.5 py-1 text-xs font-semibold"
                        : done
                          ? "rounded-full bg-[var(--color-surface-3)] text-[var(--color-fg)] px-2.5 py-1 text-xs font-medium"
                          : "rounded-full border border-[var(--color-border)] text-[var(--color-muted)] px-2.5 py-1 text-xs"
                    }
                  >
                    {s.short}
                  </span>
                </div>
              );
            })}
          </div>
          <p className="text-base font-medium text-[var(--color-fg)] leading-snug">
            {floorStep.instruction}
          </p>

          {floorStep.id === "operator" && (
            <div className="space-y-1.5">
              <Label>Who is on this machine?</Label>
              <CreatableSelect
                value={session?.operatorName || ""}
                options={operatorOptions}
                onChange={(v) => setOperator(machine, v)}
                onCreate={(v) => {
                  const r = addOperatorQuick(v);
                  if (!r.ok) {
                    toast.error(r.error);
                    return false;
                  }
                  toast.success(`Added operator ${v}`);
                }}
                createTitle="Add operator"
                createHint="Creates an operator account (shop-floor tabs, no PIN)."
              />
            </div>
          )}

          {floorStep.id === "load" && (
            <div className="space-y-3">
              {machineQueue[0] && (
                <div className="flex items-center gap-3">
                  <div className="min-w-0 flex-1 space-y-2">
                    <Button
                      size="lg"
                      className="w-full min-h-12"
                      onClick={handleFloorPrimary}
                    >
                      <Play className="h-4 w-4" />
                      Load next · {machineQueue[0].partNumber}
                    </Button>
                    {(() => {
                      const meta = queueItemDisplay(
                        machineQueue[0],
                        shopOrders,
                        quotes,
                      );
                      return (
                        <QueueJobMeta
                          drawingLink={false}
                          dueDate={meta.dueDate}
                          estMinutes={meta.estMinutes}
                          drawings={meta.drawings}
                        />
                      );
                    })()}
                  </div>
                  <DrawingThumb
                    size="lg"
                    file={
                      queueItemDisplay(machineQueue[0], shopOrders, quotes)
                        .drawings[0]
                    }
                  />
                </div>
              )}
              {machineQueue.length > 1 && (
                <details className="rounded-[var(--radius-md)] border border-[var(--color-border)]">
                  <summary className="cursor-pointer px-3 py-2.5 text-sm font-medium">
                    Pick a different job ({machineQueue.length} in queue)
                  </summary>
                  <div className="space-y-2 px-3 pb-3 max-h-80 overflow-y-auto">
                    {machineQueue.map((q, i) => {
                      const meta = queueItemDisplay(q, shopOrders, quotes);
                      return (
                      <div
                        key={q.id}
                        className="flex items-center gap-3 rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] px-2.5 py-2 text-sm"
                      >
                        <div className="flex-1 min-w-0 space-y-1">
                          <div className="font-medium truncate">
                            {i + 1}. {q.partNumber}{" "}
                            <span className="text-[var(--color-muted)] font-normal">
                              x{q.qty}
                            </span>
                          </div>
                          <QueueJobMeta
                            drawingLink={false}
                            dueDate={meta.dueDate}
                            estMinutes={meta.estMinutes}
                            drawings={meta.drawings}
                          />
                        </div>
                        <DrawingThumb size="lg" file={meta.drawings[0]} />
                        <Button
                          size="sm"
                          onClick={() => {
                            const r = startWorkQueueItem(q.id);
                            if (!r.ok) toast.error(r.error || "Failed");
                            else toast.success(`Loaded ${q.partNumber}`);
                          }}
                        >
                          Load
                        </Button>
                      </div>
                      );
                    })}
                  </div>
                </details>
              )}
              <details className="rounded-[var(--radius-md)] border border-[var(--color-border)]">
                <summary className="cursor-pointer px-3 py-2.5 text-sm font-medium">
                  Search a part instead
                </summary>
                <div className="space-y-2 px-3 pb-3">
                  <Input
                    value={partSearch}
                    onChange={(e) => setPartSearch(e.target.value)}
                    placeholder="e.g. AF-4421"
                    list="part-suggestions"
                  />
                  <datalist id="part-suggestions">
                    {quotes.map((q) => (
                      <option key={q.id} value={q.partNumber} />
                    ))}
                  </datalist>
                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      value={rev}
                      onChange={(e) => setRev(e.target.value.toUpperCase())}
                      placeholder="Rev"
                    />
                    <Input
                      type="number"
                      min={1}
                      value={qty}
                      onChange={(e) => setQty(e.target.value)}
                      placeholder="Qty"
                    />
                  </div>
                  <Button className="w-full" onClick={handleSearchLoad}>
                    <Search className="h-4 w-4" /> Search / Load job
                  </Button>
                </div>
              </details>
            </div>
          )}

          {floorStep.id === "tooling" && (
            <div className="space-y-3">
              {toolingRunning ? (
                <Button
                  size="lg"
                  className="w-full min-h-12"
                  variant="danger"
                  onClick={handleFloorPrimary}
                >
                  <Square className="h-4 w-4" /> Stop jaws timer
                </Button>
              ) : (
                <>
                  <Button
                    size="lg"
                    className="w-full min-h-12"
                    onClick={() => {
                      const r = startShopToolingLog({
                        machine,
                        kind: "soft_jaws",
                        description: "Soft jaws",
                      });
                      if (!r.ok) toast.error(r.error);
                      else toast.success("Soft jaws timer started");
                    }}
                  >
                    <Play className="h-4 w-4" /> Yes — making soft jaws
                  </Button>
                  <Button
                    size="lg"
                    variant="secondary"
                    className="w-full min-h-12"
                    onClick={handleFloorPrimary}
                  >
                    Skip for now
                  </Button>
                </>
              )}
            </div>
          )}

          {(floorStep.id === "start" ||
            floorStep.id === "running" ||
            floorStep.id === "paused" ||
            floorStep.id === "finish") &&
            floorStep.primaryLabel && (
              <div className="space-y-2">
                {timer && (
                  <div className="rounded-[var(--radius-lg)] border border-[color-mix(in_oklab,var(--color-running)_40%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-running)_8%,var(--color-surface-2))] p-4 flex items-center justify-between">
                    <div>
                      <div className="text-xs text-[var(--color-muted)] uppercase tracking-wide">
                        Running {timer.type}
                      </div>
                      <div className="text-lg font-semibold">{timer.operation}</div>
                    </div>
                    <div className="text-3xl font-semibold tabular tracking-tight">
                      {formatSeconds(liveSeconds || 0)}
                    </div>
                  </div>
                )}
                <Button
                  size="lg"
                  className="w-full min-h-12"
                  variant={floorStep.id === "running" ? "danger" : "default"}
                  onClick={handleFloorPrimary}
                >
                  {floorStep.id === "running" ? (
                    <Square className="h-4 w-4" />
                  ) : (
                    <Play className="h-4 w-4" />
                  )}
                  {floorStep.primaryLabel}
                </Button>
                {floorStep.id === "running" && (
                  <Button
                    size="lg"
                    variant="warn"
                    className="w-full min-h-12"
                    onClick={() => setPauseOpen(true)}
                  >
                    <Pause className="h-4 w-4" /> Pause this timer
                  </Button>
                )}
                {isAdmin && lastStop && !lastStopIsActive && (
                  <Button
                    size="lg"
                    variant="secondary"
                    className="w-full min-h-12"
                    onClick={() => {
                      const r = reopenOpTimer(
                        machine,
                        lastStop.idx,
                        lastStop.type,
                        lastStop.seconds,
                      );
                      if (!r.ok) toast.error(r.error);
                      else toast.success(r.message || "Back on that timer");
                    }}
                  >
                    Put them back on {lastStop.type} {lastStop.operation}
                  </Button>
                )}
                {session?.jobId && jobPrints.length > 0 && (
                  <Button
                    size="lg"
                    variant="outline"
                    className="w-full min-h-12"
                    disabled={printBusy}
                    onClick={() => void loadPrintAt(0)}
                  >
                    <FileText className="h-4 w-4" />
                    View print
                  </Button>
                )}

                {session?.jobId && (
                  <div className="overflow-x-auto -mx-1 pt-1">
                    <table className="w-full text-xs sm:text-sm table-fixed">
                      <colgroup>
                        <col className="w-[3.25rem]" />
                        <col />
                        <col />
                      </colgroup>
                      <thead>
                        <tr className="text-left text-[var(--color-muted)] border-b border-[var(--color-border)]">
                          <th className="py-1.5 pr-1 font-medium">Op</th>
                          <th className="py-1.5 px-1 font-medium">Setup</th>
                          <th className="py-1.5 pl-1 font-medium">Run</th>
                        </tr>
                      </thead>
                      <tbody>
                        {displayOps.map((op, i) => {
                          const setup = session?.setups[i];
                          const runtime = session?.runtimes[i];
                          const setupLive =
                            timer?.operation === op && timer.type === "Setup"
                              ? liveSeconds
                              : null;
                          const runLive =
                            timer?.operation === op && timer.type === "Runtime"
                              ? liveSeconds
                              : null;
                          const setupSecs =
                            setupLive != null
                              ? setupLive
                              : session?.paused &&
                                  session.pausedTimer?.type === "Setup" &&
                                  session.pausedTimer.operation === op
                                ? session.pausedTimer.accumulatedSeconds
                                : typeof setup === "number"
                                  ? setup
                                  : 0;
                          const runSecs =
                            runLive != null
                              ? runLive
                              : session?.paused &&
                                  session.pausedTimer?.type === "Runtime" &&
                                  session.pausedTimer.operation === op
                                ? session.pausedTimer.accumulatedSeconds
                                : typeof runtime === "number"
                                  ? runtime
                                  : 0;
                          const setupActual =
                            setup === "STARTED" || setupLive != null ? (
                              <span className="text-[var(--color-running)] font-semibold tabular">
                                {formatSeconds(setupLive ?? setupSecs)}
                              </span>
                            ) : setup != null ? (
                              <span className="tabular font-medium">
                                {formatSeconds(Number(setup))}
                              </span>
                            ) : (
                              <span className="text-[var(--color-subtle)]">—</span>
                            );
                          const runActual =
                            runtime === "STARTED" || runLive != null ? (
                              <span className="text-[var(--color-running)] font-semibold tabular">
                                {formatSeconds(runLive ?? runSecs)}
                              </span>
                            ) : runtime != null ? (
                              <span className="tabular font-medium">
                                {formatSeconds(Number(runtime))}
                              </span>
                            ) : (
                              <span className="text-[var(--color-subtle)]">—</span>
                            );
                          const wrapAdmin = (
                            node: React.ReactNode,
                            type: "Setup" | "Runtime",
                            secs: number,
                          ) =>
                            isAdmin ? (
                              <button
                                type="button"
                                className="inline-flex items-center gap-1 rounded px-0.5 min-h-8 text-left hover:bg-[var(--color-surface-3)]"
                                onClick={() => openTimeEdit(i, type, secs)}
                                title="Correct this time"
                              >
                                {node}
                                <Pencil className="h-3 w-3 text-[var(--color-muted)]" />
                              </button>
                            ) : (
                              node
                            );
                          return (
                            <tr
                              key={op}
                              className="border-b border-[var(--color-border)] last:border-0"
                            >
                              <td className="py-1.5 pr-1 font-semibold text-[11px] sm:text-xs">
                                {op}
                              </td>
                              <td className="py-1.5 px-1">
                                {wrapAdmin(setupActual, "Setup", setupSecs)}
                              </td>
                              <td className="py-1.5 pl-1">
                                {wrapAdmin(runActual, "Runtime", runSecs)}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}
        </CardContent>
      </Card>

      <details className="rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-surface)]">
        <summary className="cursor-pointer list-none px-4 py-3 text-sm font-medium select-none [&::-webkit-details-marker]:hidden">
          More on this machine
          <span className="ml-2 text-xs font-normal text-[var(--color-muted)]">
            queue · notes · jaws · bonus · clear
          </span>
        </summary>
        <div className="space-y-4 px-4 pb-4 border-t border-[var(--color-border)] pt-4">
          <div className="space-y-1.5">
            <Label>Operator</Label>
            <CreatableSelect
              value={session?.operatorName || ""}
              options={operatorOptions}
              onChange={(v) => setOperator(machine, v)}
              onCreate={(v) => {
                const r = addOperatorQuick(v);
                if (!r.ok) {
                  toast.error(r.error);
                  return false;
                }
                toast.success(`Added operator ${v}`);
              }}
              createTitle="Add operator"
            />
          </div>

          {session?.jobId && (
            <div className="grid grid-cols-2 gap-2 text-sm">
              <Detail label="Part #" value={session.partNumber || "—"} />
              <Detail label="Customer" value={session.customer || "—"} />
              <div className="space-y-1 col-span-2 sm:col-span-1">
                <Label>Revision</Label>
                <Input
                  value={session.revision || ""}
                  onChange={(e) =>
                    updateField(machine, {
                      revision: e.target.value.toUpperCase(),
                    })
                  }
                />
              </div>
              <div className="space-y-1">
                <Label>Qty / done</Label>
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    type="number"
                    value={session.quantity || 0}
                    onChange={(e) =>
                      updateField(machine, {
                        quantity: Number(e.target.value) || 0,
                      })
                    }
                  />
                  <Input
                    type="number"
                    value={session.quantityCompleted || 0}
                    onChange={(e) =>
                      updateField(machine, {
                        quantityCompleted: Number(e.target.value) || 0,
                      })
                    }
                  />
                </div>
              </div>
              {session.pairPartNumber ? (
                <div className="space-y-1 col-span-2">
                  <Label>Pair {session.pairPartNumber} qty / done</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      type="number"
                      value={session.pairQuantity || 0}
                      onChange={(e) =>
                        updateField(machine, {
                          pairQuantity: Number(e.target.value) || 0,
                        })
                      }
                    />
                    <Input
                      type="number"
                      value={session.pairQuantityCompleted || 0}
                      onChange={(e) =>
                        updateField(machine, {
                          pairQuantityCompleted: Number(e.target.value) || 0,
                        })
                      }
                    />
                  </div>
                </div>
              ) : null}
              <div className="col-span-2 panel-inset p-3">
                <div className="text-xs text-[var(--color-muted)]">Job efficiency</div>
                <div className="text-xl font-semibold tabular">
                  {formatPercent(session.efficiency || 0)}
                </div>
              </div>
            </div>
          )}

          {machineQueue.length > 0 && (
            <div className="space-y-2">
              <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">
                Queue
              </div>
              <div className="space-y-2 max-h-96 overflow-y-auto">
              {machineQueue.map((q, i) => {
                const meta = queueItemDisplay(q, shopOrders, quotes);
                return (
                <div
                  key={q.id}
                  className="flex flex-wrap items-center gap-3 rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] px-2.5 py-2 text-sm"
                >
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="font-medium truncate">
                      {i + 1}. {q.partNumber}{" "}
                      <span className="text-[var(--color-muted)] font-normal">
                        x{q.qty}
                      </span>
                    </div>
                    <QueueJobMeta
                      drawingLink={false}
                      dueDate={meta.dueDate}
                      estMinutes={meta.estMinutes}
                      drawings={meta.drawings}
                    />
                  </div>
                  <DrawingThumb size="lg" file={meta.drawings[0]} />
                  <div className="flex flex-wrap gap-1">
                  <Button size="sm" variant="ghost" onClick={() => moveWorkQueueItem(q.id, "up")}>
                    Up
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => moveWorkQueueItem(q.id, "down")}>
                    Down
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => {
                      const r = startWorkQueueItem(q.id);
                      if (!r.ok) toast.error(r.error || "Failed");
                      else toast.success(`Loaded ${q.partNumber}`);
                    }}
                  >
                    Load
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => removeWorkQueueItem(q.id)}>
                    Remove
                  </Button>
                  </div>
                </div>
                );
              })}
              </div>
            </div>
          )}

          <div className="space-y-2">
            <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">
              Load another part
            </div>
            <Input
              value={partSearch}
              onChange={(e) => setPartSearch(e.target.value)}
              placeholder="Part number"
              list="part-suggestions-more"
            />
            <datalist id="part-suggestions-more">
              {quotes.map((q) => (
                <option key={q.id} value={q.partNumber} />
              ))}
            </datalist>
            <div className="grid grid-cols-2 gap-2">
              <Input
                value={rev}
                onChange={(e) => setRev(e.target.value.toUpperCase())}
                placeholder="Rev"
              />
              <Input
                type="number"
                min={1}
                value={qty}
                onChange={(e) => setQty(e.target.value)}
                placeholder="Qty"
              />
            </div>
            <Button className="w-full" variant="secondary" onClick={handleSearchLoad}>
              <Search className="h-4 w-4" /> Search / Load
            </Button>
          </div>

          {session?.partNumber &&
            (() => {
              const tks = ticketsForPart(cutTickets, session.partNumber);
              if (!tks.length) return null;
              return (
                <div className="space-y-2">
                  <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">
                    Saw / stock cut
                  </div>
                  {tks.slice(0, 3).map((tk) => {
                    const avail = qtyAvailable(tk);
                    return (
                      <div
                        key={tk.id}
                        className="rounded-[var(--radius-md)] border border-[var(--color-border)] p-3 text-sm space-y-1"
                      >
                        <div className="font-medium">{statusLabel(tk.status)}</div>
                        <div className="text-[var(--color-muted)] text-xs">
                          {cutTicketLabel(tk)} · {avail} available
                        </div>
                        {avail > 0 && (
                          <Button
                            size="sm"
                            type="button"
                            onClick={() => {
                              const r = claimCutStock(
                                tk.id,
                                Math.min(avail, 1),
                                machine,
                              );
                              if (r.ok)
                                toast.success(`Claimed 1 blank · ${r.available} left`);
                              else toast.error(r.error || "Cannot claim");
                            }}
                          >
                            Claim 1 blank
                          </Button>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })()}

          {machine ? <ShopToolingFloorPanel machine={machine} tick={tick} /> : null}

          <div className="space-y-1.5">
            <Label>Job notes</Label>
            <Textarea
              value={session?.notes || ""}
              onChange={(e) => updateNotes(machine, e.target.value)}
              placeholder="Job notes"
              className="min-h-24"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="secondary"
              onClick={() => {
                setSaveQty(String(session?.quantityCompleted || 0));
                setSaveOpen(true);
              }}
              disabled={!session?.jobId}
            >
              <Save className="h-4 w-4" /> Save
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                clearSession(machine);
                toast.message("Session cleared");
              }}
            >
              <Eraser className="h-4 w-4" /> Clear station
            </Button>
          </div>

          <DayBonusPanel operatorName={session?.operatorName || ""} compact />
        </div>
      </details>

      {newPartOpen && (
        <Modal
          title="New part — add to database"
          onClose={() => {
            setNewPartOpen(false);
            setPendingExistingJobId(undefined);
          }}
          wide
        >
          <div className="flex items-start gap-2 rounded-[var(--radius-md)] border border-[color-mix(in_oklab,var(--color-accent)_35%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-accent)_8%,var(--color-surface))] px-3 py-2 text-sm mb-4">
            <Database className="h-4 w-4 mt-0.5 text-[var(--color-accent)] shrink-0" />
            <p>
              <strong className="text-[var(--color-fg)]">{newPart.partNumber}</strong> is not in
              the parts database. Enter material and basics so the shop has a record, then the job
              will load on this machine.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Part #</Label>
              <Input value={newPart.partNumber} disabled className="font-semibold" />
            </div>
            <div className="space-y-1.5">
              <Label>Revision *</Label>
              <Input
                value={newPart.revision}
                onChange={(e) =>
                  setNewPart((f) => ({ ...f, revision: e.target.value.toUpperCase() }))
                }
              />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Customer *</Label>
              <CreatableSelect
                value={newPart.customer}
                options={customerOptions}
                onChange={(v) => setNewPart((f) => ({ ...f, customer: v }))}
                onCreate={(v) => {
                  const r = addCustomerQuick(v);
                  if (!r.ok) {
                    toast.error(r.error);
                    return false;
                  }
                  toast.success(`Added customer ${v}`);
                }}
                createTitle="Add customer"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Quantity *</Label>
              <Input
                type="number"
                min={1}
                value={newPart.quantity}
                onChange={(e) => setNewPart((f) => ({ ...f, quantity: e.target.value }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Stock shape</Label>
              <CreatableSelect
                allowEmpty={false}
                value={newPart.stockShape}
                options={stockShapeOptions}
                onChange={(v) => setNewPart((f) => ({ ...f, stockShape: v }))}
                onCreate={(v) => {
                  const r = addCustomListItem("stockShapes", v);
                  if (!r.ok) {
                    toast.error(r.error);
                    return false;
                  }
                  toast.success(`Added stock shape ${v}`);
                }}
                createTitle="Add stock shape"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Material *</Label>
              <CreatableSelect
                allowEmpty={false}
                value={newPart.material}
                options={materialOptions}
                onChange={onNewPartMaterialChange}
                onCreate={(v) => {
                  const r = addCustomListItem("materials", v);
                  if (!r.ok) {
                    toast.error(r.error);
                    return false;
                  }
                  toast.success(`Added material ${v}`);
                }}
                createTitle="Add material"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Material type *</Label>
              <CreatableSelect
                allowEmpty={false}
                value={newPart.materialType}
                options={typeOptions}
                onChange={(v) => setNewPart((f) => ({ ...f, materialType: v }))}
                onCreate={(v) => {
                  const mat = newPart.material || "Other";
                  const r = addCustomListItem("materialTypes", v, mat);
                  if (!r.ok) {
                    toast.error(r.error);
                    return false;
                  }
                  toast.success(`Added ${v} under ${mat}`);
                }}
                createTitle={`Add type for ${newPart.material}`}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Est. OP1 setup (min)</Label>
              <Input
                type="number"
                step="0.1"
                min={0}
                value={newPart.setupMin}
                onChange={(e) => setNewPart((f) => ({ ...f, setupMin: e.target.value }))}
                placeholder="Optional"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Est. OP1 run (min/pc)</Label>
              <Input
                type="number"
                step="0.1"
                min={0}
                value={newPart.runMin}
                onChange={(e) => setNewPart((f) => ({ ...f, runMin: e.target.value }))}
                placeholder="Optional"
              />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Notes</Label>
              <Textarea
                value={newPart.notes}
                onChange={(e) => setNewPart((f) => ({ ...f, notes: e.target.value }))}
                placeholder="Anything the next person should know"
                className="min-h-20"
              />
            </div>
          </div>

          <p className="text-[11px] text-[var(--color-subtle)] mt-3">
            Machine is set to <strong className="text-[var(--color-fg)]">{machine}</strong>. You
            can refine pricing later in Master Quoter.
          </p>

          <div className="flex flex-col-reverse sm:flex-row gap-2 mt-4 justify-end">
            <Button
              variant="ghost"
              onClick={() => {
                setNewPartOpen(false);
                setPendingExistingJobId(undefined);
              }}
            >
              Cancel
            </Button>
            <Button onClick={confirmNewPart}>
              <Database className="h-4 w-4" /> Save to database & load job
            </Button>
          </div>
        </Modal>
      )}

      {unitsPrompt && (
        <Modal title="Units completed" onClose={() => setUnitsPrompt(false)}>
          <p className="text-sm text-[var(--color-muted)] mb-3">
            Enter number of units completed during this runtime session.
          </p>
          <Input
            type="number"
            min={0}
            value={units}
            onChange={(e) => setUnits(e.target.value)}
            autoFocus
          />
          <div className="flex gap-2 mt-4 justify-end">
            <Button variant="ghost" onClick={() => setUnitsPrompt(false)}>
              Cancel
            </Button>
            <Button onClick={confirmUnits}>Confirm stop</Button>
          </div>
        </Modal>
      )}

      {timeEdit && (
        <Modal
          title={`Correct ${timeEdit.type} ${opLabel(timeEdit.idx)}`}
          onClose={() => setTimeEdit(null)}
        >
          <p className="text-sm text-[var(--color-muted)] mb-3">
            Current {formatSeconds(timeEdit.seconds)}. Set the clock the
            operator should have. If this timer is running, it keeps going from
            the new time.
          </p>
          <div className="grid grid-cols-3 gap-2">
            <div className="space-y-1">
              <Label>Hours</Label>
              <Input
                inputMode="numeric"
                value={editH}
                onChange={(e) => setEditH(e.target.value.replace(/[^\d]/g, ""))}
              />
            </div>
            <div className="space-y-1">
              <Label>Min</Label>
              <Input
                inputMode="numeric"
                value={editM}
                onChange={(e) => setEditM(e.target.value.replace(/[^\d]/g, ""))}
              />
            </div>
            <div className="space-y-1">
              <Label>Sec</Label>
              <Input
                inputMode="numeric"
                value={editS}
                onChange={(e) => setEditS(e.target.value.replace(/[^\d]/g, ""))}
              />
            </div>
          </div>
          <div className="flex flex-wrap gap-2 mt-3">
            {[-5, -1, 1, 5].map((m) => (
              <Button
                key={m}
                size="sm"
                variant="outline"
                type="button"
                onClick={() => {
                  const next = Math.max(
                    0,
                    (Number(editH) || 0) * 3600 +
                      (Number(editM) || 0) * 60 +
                      (Number(editS) || 0) +
                      m * 60,
                  );
                  setEditH(String(Math.floor(next / 3600)));
                  setEditM(String(Math.floor((next % 3600) / 60)));
                  setEditS(String(next % 60));
                }}
              >
                {m > 0 ? `+${m} min` : `${m} min`}
              </Button>
            ))}
          </div>
          <div className="flex flex-wrap gap-2 mt-4 justify-end">
            <Button variant="ghost" onClick={() => setTimeEdit(null)}>
              Cancel
            </Button>
            <Button
              variant="secondary"
              onClick={() => {
                const sec =
                  (Number(editH) || 0) * 3600 +
                  (Number(editM) || 0) * 60 +
                  (Number(editS) || 0);
                const r = reopenOpTimer(
                  machine,
                  timeEdit.idx,
                  timeEdit.type,
                  sec,
                );
                if (!r.ok) toast.error(r.error);
                else {
                  toast.success(r.message || "Back on that timer");
                  setTimeEdit(null);
                }
              }}
            >
              Put them back on this timer
            </Button>
            <Button
              onClick={() => {
                const sec =
                  (Number(editH) || 0) * 3600 +
                  (Number(editM) || 0) * 60 +
                  (Number(editS) || 0);
                const r = adjustOpTime(machine, timeEdit.idx, timeEdit.type, sec);
                if (!r.ok) toast.error(r.error);
                else {
                  toast.success(
                    `Set ${timeEdit.type} ${opLabel(timeEdit.idx)} to ${formatSeconds(sec)}`,
                  );
                  setTimeEdit(null);
                }
              }}
            >
              Save time
            </Button>
          </div>
        </Modal>
      )}

      {pauseOpen && (
        <Modal title="Pause reason" onClose={() => setPauseOpen(false)}>
          <CreatableSelect
            allowEmpty={false}
            value={pauseReason}
            options={pauseReasonOptions}
            onChange={setPauseReason}
            onCreate={(v) => {
              const r = addCustomListItem("pauseReasons", v);
              if (!r.ok) {
                toast.error(r.error);
                return false;
              }
              toast.success(`Added pause reason ${v}`);
            }}
            createTitle="Add pause reason"
          />
          <div className="flex gap-2 mt-4 justify-end">
            <Button variant="ghost" onClick={() => setPauseOpen(false)}>
              Cancel
            </Button>
            <Button variant="warn" onClick={handlePause}>
              Pause job
            </Button>
          </div>
        </Modal>
      )}

      {saveOpen && (
        <Modal title="Save job" onClose={() => setSaveOpen(false)}>
          <p className="text-sm text-[var(--color-muted)] mb-3">
            Efficiency: {formatPercent(session?.efficiency || 0)}
            {canSeeMoneyOnFloor && (
              <>
                {" "}
                · Bonus: {formatCurrency(session?.bonus || 0)}
              </>
            )}
          </p>
          <div className="space-y-1.5 mb-2">
            <Label>Qty completed (good parts finished)</Label>
            <Input
              type="number"
              min={0}
              value={saveQty}
              onChange={(e) => setSaveQty(e.target.value)}
            />
            <p className="text-[11px] text-[var(--color-subtle)]">
              Job qty: {session?.quantity || 0}
              {Number(saveQty) > (session?.quantity || 0) ? (
                <span className="text-[var(--color-warn)] font-medium">
                  {" "}
                  · {Math.floor(Number(saveQty) - (session?.quantity || 0))} over
                  job qty — we'll ask about stocking extras on complete
                </span>
              ) : null}
            </p>
          </div>
          <label className="flex items-start gap-2 text-sm mb-4 min-h-11 cursor-pointer">
            <input
              type="checkbox"
              className="mt-1 h-4 w-4 accent-[var(--color-primary)]"
              checked={countInAverage}
              onChange={(e) => setCountInAverage(e.target.checked)}
            />
            <span>
              <span className="font-medium">Use this run in shop averages</span>
              <span className="block text-xs text-[var(--color-muted)] mt-0.5">
                Uncheck for training/scrap/one-offs. History is always kept. Extreme
                outliers are auto-excluded.
              </span>
            </span>
          </label>
          <div className="flex flex-col sm:flex-row gap-2">
            <Button
              variant="secondary"
              className="flex-1"
              onClick={() => handleSave("in-progress")}
            >
              Save in progress
            </Button>
            <Button className="flex-1" onClick={() => handleSave("completed")}>
              Mark completed
            </Button>
          </div>
          <p className="text-xs text-[var(--color-subtle)] mt-3">
            In Progress requires the job to be paused first. Completing updates recipe
            times only — not customer prices.
          </p>
        </Modal>
      )}

      {extraStockOpen && (
        <Modal
          title="Extra parts — stock them?"
          onClose={() => handleExtraStockDecision(false)}
        >
          <p className="text-sm text-[var(--color-muted)] mb-3 leading-relaxed">
            Job was for{" "}
            <strong className="text-[var(--color-fg)]">
              {session?.quantity || 0}
            </strong>{" "}
            and you finished{" "}
            <strong className="text-[var(--color-fg)]">
              {pendingCompleteQty ?? saveQty}
            </strong>
            . Should any of the extras go into{" "}
            <strong className="text-[var(--color-fg)]">Parts inventory</strong>{" "}
            (on-hand stock)?
          </p>
          <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)]/50 px-3 py-2 text-xs text-[var(--color-muted)] mb-4">
            Part{" "}
            <span className="font-mono text-[var(--color-fg)]">
              {session?.partNumber || "—"}
            </span>
            {session?.revision ? ` · Rev ${session.revision}` : ""}
          </div>
          <div className="space-y-1.5 mb-3">
            <Label>How many extras to stock?</Label>
            <Input
              type="number"
              min={0}
              value={extraQty}
              onChange={(e) => setExtraQty(e.target.value)}
            />
            <p className="text-[11px] text-[var(--color-subtle)]">
              Default is the over-run amount. Use less if some were scrap / hold.
            </p>
          </div>
          <div className="space-y-1.5 mb-3">
            <Label>Quality</Label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                className={`rounded-[var(--radius-md)] border px-3 py-2.5 text-sm min-h-11 text-left ${
                  extraQuality === "good"
                    ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)]"
                    : "border-[var(--color-border)] hover:bg-[var(--color-surface-2)]"
                }`}
                onClick={() => setExtraQuality("good")}
              >
                <span className="font-medium">Good</span>
                <span className="block text-[11px] text-[var(--color-muted)]">
                  Sellable as normal stock
                </span>
              </button>
              <button
                type="button"
                className={`rounded-[var(--radius-md)] border px-3 py-2.5 text-sm min-h-11 text-left ${
                  extraQuality === "second"
                    ? "border-[var(--color-warn)] bg-[color-mix(in_oklab,var(--color-warn)_14%,transparent)]"
                    : "border-[var(--color-border)] hover:bg-[var(--color-surface-2)]"
                }`}
                onClick={() => setExtraQuality("second")}
              >
                <span className="font-medium">Second quality</span>
                <span className="block text-[11px] text-[var(--color-muted)]">
                  Slight defect — keep, note it
                </span>
              </button>
            </div>
          </div>
          {extraQuality === "second" && (
            <div className="space-y-1.5 mb-3">
              <Label>Potential defect / note (required)</Label>
              <Textarea
                rows={3}
                placeholder="e.g. Light tool mark on non-critical face · OK for spare / rework / discount sale"
                value={extraDefectNote}
                onChange={(e) => setExtraDefectNote(e.target.value)}
              />
              <p className="text-[11px] text-[var(--color-subtle)]">
                Stays on the Parts inventory row so anyone pulling stock sees the
                issue. Second-quality is kept separate from good stock of the
                same part #.
              </p>
            </div>
          )}
          <div className="space-y-1.5 mb-4">
            <Label>Location (optional)</Label>
            <Input
              placeholder="Shelf / bin"
              value={extraLocation}
              onChange={(e) => setExtraLocation(e.target.value)}
            />
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            <Button
              variant="secondary"
              className="flex-1"
              onClick={() => handleExtraStockDecision(false)}
            >
              No — don't stock
            </Button>
            <Button
              className="flex-1"
              onClick={() => handleExtraStockDecision(true)}
            >
              Yes — add to stock
            </Button>
          </div>
          <p className="text-xs text-[var(--color-subtle)] mt-3">
            Stocked extras show under Inventory → Parts. Each part gets a short
            UIN to write on with a sharpie so notes can be matched later.
          </p>
        </Modal>
      )}

      {uinWriteOpen && (
        <Modal title="Write UIN on each part" onClose={confirmUinsWritten}>
          <p className="text-sm text-[var(--color-muted)] mb-3 leading-relaxed">
            Mark each physical part with a{" "}
            <strong className="text-[var(--color-fg)]">sharpie</strong> using
            the code below. When someone pulls it off the shelf, look up the UIN
            under Inventory → Parts to see quality and defect notes.
          </p>
          <div className="space-y-2 mb-4">
            {extraUins.map((code, i) => (
              <div
                key={code}
                className="rounded-[var(--radius-md)] border-2 border-[var(--color-border-strong)] bg-[var(--color-surface-2)] px-4 py-3 flex items-center justify-between gap-3"
              >
                <span className="text-xs text-[var(--color-muted)]">
                  Part {i + 1} of {extraUins.length}
                </span>
                <span className="font-mono text-3xl sm:text-4xl font-bold tracking-[0.2em] text-[var(--color-fg)]">
                  {code}
                </span>
              </div>
            ))}
          </div>
          {extraQuality === "second" && extraDefectNote.trim() ? (
            <div className="rounded-[var(--radius-md)] border border-[var(--color-warn)]/50 bg-[color-mix(in_oklab,var(--color-warn)_10%,transparent)] px-3 py-2 text-sm mb-4">
              <div className="text-xs font-semibold text-[var(--color-warn)] mb-0.5">
                Defect note saved with each UIN
              </div>
              {extraDefectNote.trim()}
            </div>
          ) : null}
          <Button className="w-full" onClick={confirmUinsWritten}>
            Done — UINs written on parts
          </Button>
        </Modal>
      )}

      {printOpen && printView && (
        <JobPrintOverlay
          partNumber={session?.partNumber || ""}
          revision={session?.revision || ""}
          files={jobPrints}
          activeIdx={printIdx}
          view={printView}
          onClose={() => {
            printView.revoke?.();
            setPrintView(null);
            setPrintOpen(false);
          }}
          onPick={(i) => void loadPrintAt(i)}
          onPopOut={() => {
            const ok = popOutPrintWindow(
              printView.url,
              printView.name,
              printView.mime,
              session?.partNumber || "",
              session?.revision || "",
            );
            if (!ok) toast.error("Popup blocked — allow popups for this site.");
          }}
        />
      )}

    </div>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-3 border-b border-[var(--color-border)] pb-2">
      <span className="text-[var(--color-muted)]">{label}</span>
      <span className="font-medium text-right truncate">{value}</span>
    </div>
  );
}

function Modal({
  title,
  children,
  onClose,
  wide,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-4"
      onClick={onClose}
    >
      <div
        className={`w-full ${wide ? "max-w-lg" : "max-w-md"} max-h-[90vh] overflow-y-auto rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5 shadow-xl`}
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-lg font-semibold mb-3">{title}</h2>
        {children}
      </div>
    </div>
  );
}

function collectJobPrints(
  orders: ShopOrder[],
  partNumber: string,
  revision: string,
): LineFileRef[] {
  const pn = (partNumber || "").trim().toUpperCase();
  const rev = (revision || "").trim().toUpperCase();
  if (!pn) return [];
  const seen = new Set<string>();
  const out: LineFileRef[] = [];
  const add = (f?: { id?: string; name?: string; mime?: string } | null) => {
    if (!f?.id || seen.has(f.id)) return;
    seen.add(f.id);
    out.push({
      id: f.id,
      name: f.name || "Print",
      mime: f.mime || "",
    });
  };
  for (const o of orders || []) {
    for (const line of o.lines || []) {
      const linePn = (line.partNumber || "").toUpperCase();
      const lineRev = (line.revision || "").toUpperCase();
      const lineHit = linePn === pn && (!rev || !lineRev || lineRev === rev);
      if (lineHit) {
        for (const d of line.drawings || []) add(d);
        if (line.drawingId)
          add({
            id: line.drawingId,
            name: line.drawingName,
            mime: line.drawingMime,
          });
      }
      for (const d of line.drawings || []) {
        if ((d.relatedPartNumber || "").toUpperCase() === pn) add(d);
      }
      for (const c of line.components || []) {
        if ((c.partNumber || "").toUpperCase() !== pn) continue;
        const cRev = (c.revision || "").toUpperCase();
        if (rev && cRev && cRev !== rev) continue;
        for (const d of c.drawings || []) add(d);
      }
    }
  }
  return out;
}

function popOutPrintWindow(
  url: string,
  name: string,
  mime: string,
  partNumber: string,
  revision: string,
): boolean {
  const w = window.screen.availWidth || 1200;
  const h = window.screen.availHeight || 800;
  const win = window.open(
    "",
    "lcm-job-print",
    `popup=yes,width=${w},height=${h},left=0,top=0,resizable=yes,scrollbars=yes`,
  );
  if (!win) return false;
  const title = `${partNumber || "Print"}${revision ? ` Rev ${revision}` : ""} — ${name || "drawing"}`;
  const isImage = /^image\//i.test(mime);
  const body = isImage
    ? `<img src="${url}" alt="${escHtml(name)}" />`
    : `<iframe src="${url}" title="${escHtml(name)}"></iframe>`;
  win.document.open();
  win.document.write(`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${escHtml(title)}</title>
  <style>
    html, body { margin: 0; height: 100%; background: #111; }
    iframe, img { width: 100%; height: 100%; border: 0; object-fit: contain; background: #111; }
  </style>
</head>
<body>${body}</body>
</html>`);
  win.document.close();
  return true;
}

function escHtml(s: string) {
  return String(s || "")
    .replace(/&/g, "\u0026amp;")
    .replace(/</g, "\u0026lt;")
    .replace(/>/g, "\u0026gt;")
    .replace(/"/g, "\u0026quot;");
}

function JobPrintOverlay({
  partNumber,
  revision,
  files,
  activeIdx,
  view,
  onClose,
  onPick,
  onPopOut,
}: {
  partNumber: string;
  revision: string;
  files: LineFileRef[];
  activeIdx: number;
  view: { url: string; mime: string; name: string };
  onClose: () => void;
  onPick: (i: number) => void;
  onPopOut: () => void;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const isImage = /^image\//i.test(view.mime);
  const isPdf =
    /pdf/i.test(view.mime) ||
    /\.pdf$/i.test(view.name) ||
    view.mime === "application/pdf";

  return (
    <div
      className="fixed inset-0 z-[90] flex flex-col bg-black print:hidden"
      role="dialog"
      aria-modal="true"
      aria-label="Job print"
    >
      <div className="flex items-center gap-2 px-3 py-2 border-b border-white/10 bg-[#161616] shrink-0">
        <FileText className="h-4 w-4 text-white/70 shrink-0" />
        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold text-white truncate">
            {partNumber || "Print"}
            {revision ? ` · Rev ${revision}` : ""}
          </div>
          <div className="text-[10px] text-white/55 truncate">{view.name}</div>
        </div>
        {files.length > 1 && (
          <div className="flex flex-wrap gap-1 max-w-[40%]">
            {files.map((f, i) => (
              <button
                key={f.id}
                type="button"
                className={`rounded px-2 py-1 text-[11px] min-h-8 ${
                  i === activeIdx
                    ? "bg-white text-black font-semibold"
                    : "bg-white/10 text-white"
                }`}
                onClick={() => onPick(i)}
              >
                {i + 1}
              </button>
            ))}
          </div>
        )}
        <Button
          type="button"
          size="sm"
          variant="outline"
          className="shrink-0 h-10 bg-transparent text-white border-white/25"
          onClick={onPopOut}
        >
          <ExternalLink className="h-4 w-4" />
          Window
        </Button>
        <Button type="button" size="sm" className="shrink-0 h-10" onClick={onClose}>
          <X className="h-4 w-4" />
          Close
        </Button>
      </div>
      <div className="flex-1 min-h-0 bg-[#0b0b0b]">
        {isImage ? (
          <img
            src={view.url}
            alt={view.name}
            className="w-full h-full object-contain"
          />
        ) : isPdf ? (
          <iframe
            title={view.name}
            src={view.url}
            className="w-full h-full bg-white"
          />
        ) : (
          <div className="h-full flex items-center justify-center text-white/70 text-sm p-6 text-center">
            This file type won’t preview. Use Window to open it.
          </div>
        )}
      </div>
    </div>
  );
}
