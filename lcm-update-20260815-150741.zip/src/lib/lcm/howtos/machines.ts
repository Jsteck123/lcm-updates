import type { PageHowToDoc } from "./types";

export const shopFloorHowTo: PageHowToDoc = {
  id: "shop-floor",
  path: "/machines",
  title: "Shop Floor",
  tab: "machines",
  whatThisPageIs:
    "The machine map. Every machine on the shop list is a card: who is on it, what part is loaded, whether the clock is Live / Paused / On job / Idle, live timer, efficiency, and what is Up next in that machine’s queue. Above the cards is Running order — the selected person’s due-sorted queue with Load. Tap a machine card (or Machine on a queue row) to open the guided station. This page does not run Setup/Runtime; the station does.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "Select a machine to log in, load a part, and run setup / runtime timers. Cards tick every second while a timer is live. Status colors match the rest of the shop.",
        },
        {
          type: "ul",
          items: [
            "Running order defaults to you (or the first active operator) and Next due.",
            "Load on a queue row starts that work-queue item on its machine (same as Load next on the station).",
            "Machine on a queue row opens the station without loading.",
            "Each machine card shows Part, Rev / Qty, pieces ran with a completion bar and time remaining, Timer, Efficiency, and Up next (that machine’s queue, soonest due). Piece count uses shop colors: overdue if they have not tapped Good so far in a sold cycle.",
            "The pulse strip under the title is the shop week + your day. Same strip as Job Board / Active / Saw. Quiet days stay quiet — no $0.",
            "Add machine appends a name to the floor list (same list Quoting uses).",
          ],
        },
        {
          type: "note",
          text: "Nothing queued means nobody assigned lines from Customer Orders (Shop Orders) to this person / filter. The Job Board is a different take pile — those jobs show here only after Load.",
        },
        {
          type: "warn",
          text: "Remove on a queue row is editor mode only (admin with editor mode on). It hides the line from the board/queues; the customer PO stays.",
        },
      ],
    },
    {
      title: "Header",
      blocks: [
        {
          type: "control",
          name: "Shop Floor",
          does: "Page title. Subtitle: select a machine to log in, load a part, and run setup / runtime timers.",
        },
        {
          type: "control",
          name: "Add machine",
          does: "Toggles the add-machine card. Tap again to hide it. Anyone who can open this page can add a name to the floor list.",
        },
        {
          type: "control",
          name: "Shop pulse strip",
          does: "Under the title. Shop week dollar when the shop is on pace, plus your day line and shift bar. Same strip on Job Board, Active Jobs, and Saw. Does not start a timer.",
        },
        {
          type: "control",
          name: "— Pick Add new… —",
          does: "Creatable machine picker inside the add card. Pick Add new… and type the name (normalized to UPPERCASE). Saved onto the machines list for floor and quoting. Toast “Added {name}” or an error if the name is bad / duplicate.",
        },
        {
          type: "control",
          name: "Add machine",
          does: "Create-dialog title when you type a new machine name in that picker. Hint: “Appears on shop floor and quoting machine lists.”",
        },
      ],
    },
    {
      title: "Running order",
      blocks: [
        {
          type: "control",
          name: "Running order",
          does: "Queue card for one person. Subtitle: soonest due first; filter by date or person.",
        },
        {
          type: "control",
          name: "Next due",
          does: "Due filter (default). Soonest due first, including future dates.",
        },
        {
          type: "control",
          name: "Overdue",
          does: "Due filter. Only queue items past due.",
        },
        {
          type: "control",
          name: "Due today",
          does: "Due filter. Only items due today.",
        },
        {
          type: "control",
          name: "Due this week",
          does: "Due filter. Items due in the current week window.",
        },
        {
          type: "control",
          name: "Operator",
          does: "Person picker (disabled placeholder until a name is chosen). Lists every active operator. The queue is that person’s assigned work. Defaults to you.",
        },
        {
          type: "control",
          name: "Nothing queued. Assign lines from Shop Orders.",
          does: "Empty state when that person + due filter has no open queue items.",
        },
        {
          type: "control",
          name: "Load",
          does: "On a queue row. Starts that work-queue item on its machine (loads the part, sets the session). Toast “Loaded on {machine}” or an error. Does not navigate — open the machine yourself if you want the station.",
        },
        {
          type: "control",
          name: "Machine",
          does: "On a queue row. Opens that machine’s station without changing what is loaded.",
        },
        {
          type: "control",
          name: "Remove",
          does: "Editor mode only. Confirms, then hides the line from board/queues (or drops the queue row if it has no PO). Toast “Removed {part}”. Hidden for everyone else.",
        },
      ],
    },
    {
      title: "Machine cards",
      blocks: [
        {
          type: "control",
          name: "Machine card",
          does: "Whole card is a link to /machines/{slug}. Hover darkens the border.",
        },
        {
          type: "control",
          name: "No operator",
          does: "Shown under the machine name when nobody is signed onto that station.",
        },
        {
          type: "control",
          name: "Live",
          does: "Badge when a Setup or Runtime timer is running. Timer row shows type, operation, and live time.",
        },
        {
          type: "control",
          name: "Paused",
          does: "Badge when the session is paused.",
        },
        {
          type: "control",
          name: "On job",
          does: "Badge when a job is loaded, timer off, not paused.",
        },
        {
          type: "control",
          name: "Idle",
          does: "Badge when nothing is loaded.",
        },
        {
          type: "control",
          name: "Part",
          does: "Loaded part number, or — if idle.",
        },
        {
          type: "control",
          name: "Rev / Qty",
          does: "Revision and quantity on the session.",
        },
        {
          type: "control",
          name: "Timer",
          does: "“{type} {operation} · {time}” when live, otherwise —.",
        },
        {
          type: "control",
          name: "Efficiency",
          does: "Live job efficiency on that session (0% if idle).",
        },
        {
          type: "control",
          name: "Up next",
          does: "That machine’s queue, soonest due, with drawing thumb, due, estimate, operator, and qty. Hidden when the machine queue is empty.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Walk up and open your machine",
        },
        {
          type: "ol",
          items: [
            "Find the machine card (Live / Paused / On job / Idle).",
            "Tap the card.",
            "On the station, pick yourself under Who is on this machine? if the bar is on You.",
          ],
        },
        {
          type: "h",
          text: "Load the next due job for you",
        },
        {
          type: "ol",
          items: [
            "In Running order leave Operator as you and Next due.",
            "On the top row tap Load.",
            "Tap Machine (or the machine card) and run the station script.",
          ],
        },
        {
          type: "h",
          text: "Add a machine that is not on the list",
        },
        {
          type: "ol",
          items: [
            "Tap Add machine.",
            "In — Pick Add new… — create the name (UPPERCASE).",
            "The new card appears on the floor.",
          ],
        },
      ],
    },
  ],
};

export const machineStationHowTo: PageHowToDoc = {
  id: "machine-station",
  path: "/machines/$machineId",
  title: "Machine station",
  tab: "machines",
  whatThisPageIs:
    "The guided station for one machine. The bar is You → Load → Stock → Jaws → Work → Done. You sign onto the machine, load a part (queue, search, or nest pair), confirm stock, optionally time soft jaws, then smart-start Setup and Runtime. A pulse card under the chips shows pieces on this job, shift progress, and Possible today when you are on pace. Stop asks for units on a runtime. Pause holds the clock with a reason. Save / Finish job can stay in progress or mark completed, stock extras with a UIN, and lock your shift bonus under More. Unknown machines show “Unknown machine” and Back to shop floor.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "One machine, one script. The colored chips (You → Load → Stock → Jaws → Work → Done) follow the job. The big instruction and the primary button change with the step. Optional steps (Stock, Jaws) can be skipped; they stay available later under More on this machine.",
        },
        {
          type: "ul",
          items: [
            "You — nobody is on this machine yet. Pick your name (or add an operator) before anything else.",
            "Load — no job. Load next from this machine’s queue, pick a different queued job, or Search a part instead.",
            "Stock — job is on, no op timed yet. Confirm or skip the PO stock / LOC. Skip if office already set it.",
            "Jaws — optional soft-jaws timer before the first part clock. Skip and do jaws later (e.g. before OP2).",
            "Work — Start the next Setup/Runtime, Stop timer, or Pause this timer. A live clock always wins the script.",
            "Done — every planned op is timed. Finish job (or Save) and enter good qty.",
          ],
        },
        {
          type: "p",
          text: "Smart start always picks the next untimed planned op (Setup first, then Runtime, then the next OP). Quoted-zero ops are skipped unless you already have time on them. After the last op the primary button becomes Finish job.",
        },
        {
          type: "note",
          text: "A nest pair is one clock on this machine. Good pieces count on both part numbers. Two vises, one cycle means vise 1 is OP1 of both and vise 2 is OP2 of both — do not start a second op timer.",
        },
        {
          type: "warn",
          text: "Stopping a Runtime opens Units completed — prefilled with Good so far if they tapped pieces on the fly. Enter good pieces for that session. Pause is for lunch / end of shift / transfer, not for “I finished the op”. Clear station wipes the session without saving the job.",
        },
        {
          type: "p",
          text: "Chips along the top jump you to your other loaded machines. My jobs opens My Active Jobs. Print / View print opens the drawing overlay when the PO line has files.",
        },
      ],
    },
    {
      title: "Header and jump chips",
      blocks: [
        {
          type: "control",
          name: "All machines",
          does: "Back arrow (title on the button). Returns to Shop Floor. Shown even on Unknown machine as “Back to shop floor”.",
        },
        {
          type: "control",
          name: "Unknown machine.",
          does: "Empty state when the URL slug is not on the machines list. Only action is Back to shop floor.",
        },
        {
          type: "control",
          name: "Guided station",
          does: "Subtitle when no part is loaded. With a job it shows part (+ nested part) · Rev · operator.",
        },
        {
          type: "control",
          name: "Print",
          does: "Header button. Shown only when a job is loaded and the PO line has drawings. Opens the job-print overlay. Disabled while the file is loading. Hidden with no prints.",
        },
        {
          type: "control",
          name: "Live time badge",
          does: "Running badge with the live clock. Only while a timer is on.",
        },
        {
          type: "control",
          name: "PAUSED",
          does: "Badge when the session is paused and no timer is running.",
        },
        {
          type: "control",
          name: "My other machine chips",
          does: "One chip per machine you have a job on. Current station is highlighted. Live chips show the other machine’s clock. Tap jumps to that station.",
        },
        {
          type: "control",
          name: "My jobs",
          does: "Chip that opens /active (My Active Jobs).",
        },
      ],
    },
    {
      title: "Job and day pulse",
      blocks: [
        {
          type: "p",
          text: "The pulse card sits under the machine chips, above the guided script. It is meant to keep you moving — pieces first, then the shift, then a possible bonus only when it is real. A bad time vs quote never draws a failing bar.",
        },
        {
          type: "control",
          name: "This job",
          does: "Piece slider: good qty / job qty, including live Good so far taps. A nest pair gets a second slider. Count badge uses shop colors — overdue red if they have not tapped in a sold cycle (the number is probably wrong), due soon when a cycle is almost up, active while the last tap is fresh, done when qty is in. Clock finish only after they have tapped at least one piece. Sold remaining (no clock) shows on a loaded job that is not counting yet. Sold-pace bar uses quoted run × pieces vs this clock (plus this op’s setup if already stopped). Ahead / on sold = green. A little behind = warn/red. Under 60% of sold the pace bar and live ETA hide — the piece bar stays. Setup by itself never draws a sold-time bar.",
        },
        {
          type: "control",
          name: "Load a job — pieces fill this bar as you run.",
          does: "Empty state on This job when the station has no part loaded.",
        },
        {
          type: "control",
          name: "Your day / {name} · day",
          does: "Shift slider (hours in the window / required). Line is Start a timer / Clock is on / Day is building / On pace / Day bonus is in play. Possible today only when you are on a bonus pace. Never $0.",
        },
        {
          type: "note",
          text: "Finalize still lives under More on this machine → Shift bonus. The pulse is the live picture; More is where you lock the day after the shift ends.",
        },
      ],
    },
    {
      title: "Nest another part (pair)",
      blocks: [
        {
          type: "p",
          text: "Shown only after a job is loaded. If no pair is attached you see Nest another part (optional). If a pair is on, you see Nested on this machine.",
        },
        {
          type: "control",
          name: "Nested on this machine",
          does: "Header when a pair is attached. Explains floor nest — one clock; good pieces count on both parts. Shows qty completed / qty for each P/N.",
        },
        {
          type: "control",
          name: "Two vises, one cycle",
          does: "Checkbox on a nested job. Vise 1 is OP1 of both parts, vise 2 is OP2 of both. One Setup, then one Runtime. Do not start a second op timer. Stored on the session.",
        },
        {
          type: "control",
          name: "Drop nested part",
          does: "Removes the pair. This part stays running. Toast “{pair} dropped · {part} still running”. Hidden when no pair is attached.",
        },
        {
          type: "control",
          name: "Nest another part (optional)",
          does: "Header when no pair is on. You type any P/N; the timer stays running.",
        },
        {
          type: "control",
          name: "Nested part #",
          does: "Type-ahead of other quotes. Uppercase. Required before Nest this part.",
        },
        {
          type: "control",
          name: "Nest this part",
          does: "Attaches that P/N as the pair (revision/qty/customer from quote or this job; resumes an in-progress job for that P/N if one exists). Errors if the number is blank or attach fails.",
        },
        {
          type: "control",
          name: "Suggestion: {part}",
          does: "Shown when the shop recognizes a nest mate. Taps fill Nested part # and attach immediately. Hidden if there is no hint.",
        },
      ],
    },
    {
      title: "Script bar — You / Load / Stock / Jaws / Work / Done",
      blocks: [
        {
          type: "control",
          name: "You",
          does: "Chip. Active until an operator is on the session. Instruction: “Who is on this machine? Select yourself first.”",
        },
        {
          type: "control",
          name: "Load",
          does: "Chip. Active when you are signed on but no job is loaded. Instruction: load the next job from this machine’s queue (or search a part).",
        },
        {
          type: "control",
          name: "Stock",
          does: "Optional chip. Active after load, before any op time, until you Confirm stock or Skip for now. Instruction explains LOC (model 3\" → cut 3.1\").",
        },
        {
          type: "control",
          name: "Jaws",
          does: "Optional chip. Soft jaws before the first part clock, or while a jaws timer is already running. After skip / first op, jaws stay under More on this machine.",
        },
        {
          type: "control",
          name: "Work",
          does: "Chip covering start, running, and paused. Primary button is the next Setup/Runtime, Stop timer, or the resume / Finish job label.",
        },
        {
          type: "control",
          name: "Done",
          does: "Chip when every planned op is timed. Instruction: enter good qty and finish (or save in progress). Primary is Finish job.",
        },
      ],
    },
    {
      title: "Step: You",
      blocks: [
        {
          type: "control",
          name: "Who is on this machine?",
          does: "Creatable operator list (active names). Choosing a name signs that person onto the session. Required before Load.",
        },
        {
          type: "control",
          name: "Add operator",
          does: "Create-dialog when you type a new name. Creates a floor operator account (shop-floor tabs, no PIN). Toast “Added operator {name}”.",
        },
      ],
    },
    {
      title: "Step: Load",
      blocks: [
        {
          type: "control",
          name: "Load next · {part}",
          does: "Big primary when this machine has a queue. Loads the first due item. Toast “Loaded {part} from queue” or an error. If the queue is empty the same primary runs Search / Load job instead.",
        },
        {
          type: "control",
          name: "Pick a different job ({n} in queue)",
          does: "Disclosure when more than one queue item exists. Lists every queued part with due / estimate / drawing.",
        },
        {
          type: "control",
          name: "Load",
          does: "On a row inside Pick a different job. Starts that queue item on this machine. Toast “Loaded {part}”.",
        },
        {
          type: "control",
          name: "Remove",
          does: "Editor mode only, on a queue row in that list. Hides the line from board/queues. Hidden otherwise.",
        },
        {
          type: "control",
          name: "Search a part instead",
          does: "Disclosure. Manual part search when the job is not in this machine’s queue (or you want a different P/N).",
        },
        {
          type: "control",
          name: "e.g. AF-4421",
          does: "Part-number field (suggestions from quotes) inside Search a part instead.",
        },
        {
          type: "control",
          name: "Rev",
          does: "Revision field next to Qty. Forced uppercase. Used when you Search / Load job.",
        },
        {
          type: "control",
          name: "Qty",
          does: "Quantity field next to Rev.",
        },
        {
          type: "control",
          name: "Search / Load job",
          does: "Looks up the part. Known quote → loads (or resumes an in-progress job). Unknown part → opens New part — add to database. Errors “Enter a part number” if empty.",
        },
      ],
    },
    {
      title: "Step: Stock",
      blocks: [
        {
          type: "p",
          text: "If the part matches a customer PO line, you get the same stock form the office uses. If there is no PO line, the copy says confirm stock in job notes or skip.",
        },
        {
          type: "control",
          name: "Material",
          does: "Creatable material list on the PO line. Changing material clears type until you pick again.",
        },
        {
          type: "control",
          name: "Material type",
          does: "Creatable type for that material (Add type).",
        },
        {
          type: "control",
          name: "Stock shape",
          does: "Creatable shape (Add shape). Drives mill vs lathe axis labels.",
        },
        {
          type: "control",
          name: "How it sits",
          does: "Two buttons: “Mill — X Y Z in the vise” and “Lathe — X diameter, Z length”. Sets stock process and default LOC axis.",
        },
        {
          type: "control",
          name: "Mill — X Y Z in the vise",
          does: "How it sits = mill. Three size boxes; you pick which axis is LOC.",
        },
        {
          type: "control",
          name: "Lathe — X diameter, Z length",
          does: "How it sits = lathe. X is diameter (stays stock). Z is length of cut.",
        },
        {
          type: "control",
          name: "Size in the machine",
          does: "Stock-blank sizes as the part sits. The highlighted axis is LOC — the one the saw cuts.",
        },
        {
          type: "control",
          name: "LOC — length of cut",
          does: "Saw axis + how long that cut is. Model 3\" → cut 3.1\" so you can machine .05\" off each end. Do not pick an axis that must stay stock.",
        },
        {
          type: "control",
          name: "Length of cut (axis) \"",
          does: "Inches for the saw. Syncs with the highlighted size box.",
        },
        {
          type: "control",
          name: "Full bar on the rack (\")",
          does: "Raw bar length (often 144). Used for yield, not the cut.",
        },
        {
          type: "control",
          name: "Confirm stock",
          does: "Marks the PO line materialReviewed + stockNoted and toasts “Stock confirmed”. Moves the script off Stock. Also the floor primary label on this step.",
        },
        {
          type: "control",
          name: "Skip for now",
          does: "Leaves stock unconfirmed and moves on. Toast “Stock skipped — you can still change it below”. Pick / change stock stays under More on this machine.",
        },
      ],
    },
    {
      title: "Step: Jaws",
      blocks: [
        {
          type: "control",
          name: "Yes — making soft jaws",
          does: "Starts a Soft jaws tooling timer on this machine / job. Toast “Soft jaws timer started”. Hidden while a jaws timer is already running.",
        },
        {
          type: "control",
          name: "Skip for now",
          does: "On the jaws step when no jaws timer is running. Marks jaws skipped for this visit (still available below). Toast “Jaws skipped — still available below”. Floor primary may read “Skip for now — jaws later OK”.",
        },
        {
          type: "control",
          name: "Stop jaws timer",
          does: "Shown as the big danger button (and floor primary) while a jaws timer is running. Saves the jaws minutes. Toast “Jaws time saved”. Then start part Setup.",
        },
      ],
    },
    {
      title: "Step: Work (start / running / paused)",
      blocks: [
        {
          type: "control",
          name: "Running {Setup|Runtime}",
          does: "Live panel while a timer is on. Shows type, operation (OP1…), and the big clock.",
        },
        {
          type: "control",
          name: "Good so far",
          does: "Shown while a Runtime is running or paused mid-runtime. + / − / +5 and a number field for good pieces on this runtime only (not the whole job). Each tap is a refresh — the count goes back to Active and the boards update. If they do not tap within one sold cycle the pad and every board that shows this qty go overdue red (same overdue as due dates) so floor and office know the number is probably wrong. Due soon is amber in the last stretch of that cycle. Pause freezes the clock so lunch does not paint them overdue. Gloves: 48px targets. Job N / qty is locked pieces plus this count. A nest pair counts the same number on both parts. Does not change official quantity completed until Confirm stop. Hidden on Setup.",
        },
        {
          type: "control",
          name: "+5",
          does: "Adds five good pieces to this runtime count. Minus one is disabled at 0. Cap 999.",
        },
        {
          type: "control",
          name: "Start {OPn} Setup (one-time)",
          does: "Primary when the next untimed work is a setup. Smart-starts that Setup. Toast is the start message or an error.",
        },
        {
          type: "control",
          name: "Start {OPn} Runtime (per piece)",
          does: "Primary when setup is already timed and runtime is not. Smart-starts that Runtime.",
        },
        {
          type: "control",
          name: "Stop timer",
          does: "Primary (danger) while running. Smart-stops. Runtime with no units opens Units completed. Toast “Timer stopped” / “Runtime stopped”.",
        },
        {
          type: "control",
          name: "Pause this timer",
          does: "Warn button only while running. Opens Pause reason. Does not stop the op as complete — it holds the clock.",
        },
        {
          type: "control",
          name: "Put them back on {type} {op}",
          does: "Admin only. Shown after a stop when that op is not the live timer. Re-opens the last stopped Setup/Runtime from its saved seconds. Hidden for floor and while that timer is already live.",
        },
        {
          type: "control",
          name: "View print",
          does: "Work-step button when the job has drawings. Same overlay as header Print. Hidden with no files.",
        },
        {
          type: "control",
          name: "Finish job",
          does: "Primary when every planned op is timed, or when paused with nothing left to time. Opens Save job with qty prefilled from quantity completed.",
        },
      ],
    },
    {
      title: "Op table (Setup / Run)",
      blocks: [
        {
          type: "p",
          text: "Under the primary work button once a job is loaded. One row per planned op (quoted ops, or all ops if nothing was quoted).",
        },
        {
          type: "control",
          name: "Op",
          does: "Column: OP1, OP2, …",
        },
        {
          type: "control",
          name: "Setup",
          does: "Timed setup seconds, live green clock, paused leftover, or —. Admin: tap the time (pencil) to open Correct {type} {op}. Floor sees the number only.",
        },
        {
          type: "control",
          name: "Run",
          does: "Same as Setup for Runtime. Admin tap-to-correct. Floor read-only.",
        },
      ],
    },
    {
      title: "More on this machine",
      blocks: [
        {
          type: "control",
          name: "More on this machine",
          does: "Disclosure (queue · notes · jaws · bonus · clear). Everything below lives here so the script stays short.",
        },
        {
          type: "control",
          name: "Operator",
          does: "Same creatable operator list as You, always available so you can hand the machine off without clearing the job.",
        },
        {
          type: "control",
          name: "Part #",
          does: "Read-only loaded part.",
        },
        {
          type: "control",
          name: "Customer",
          does: "Read-only customer on the session.",
        },
        {
          type: "control",
          name: "Revision",
          does: "Editable. Forced uppercase. Writes through to the session.",
        },
        {
          type: "control",
          name: "Qty / done",
          does: "Two number fields: planned quantity and quantity completed. Both write through. Done is what Save job prefills.",
        },
        {
          type: "control",
          name: "Pair {part} qty / done",
          does: "Shown only with a nest. Planned and completed qty for the nested part.",
        },
        {
          type: "control",
          name: "Job efficiency",
          does: "Live % for this run vs quote.",
        },
        {
          type: "control",
          name: "Queue",
          does: "This machine’s due-sorted queue with drawing thumbs.",
        },
        {
          type: "control",
          name: "Up",
          does: "Moves that queue row earlier.",
        },
        {
          type: "control",
          name: "Down",
          does: "Moves that queue row later.",
        },
        {
          type: "control",
          name: "Load",
          does: "Loads that queue item onto this machine (same as the Load step).",
        },
        {
          type: "control",
          name: "Remove",
          does: "Drops that item from this machine’s queue (does not hide the PO line unless you are in editor mode on the Load-step list).",
        },
        {
          type: "control",
          name: "Load another part",
          does: "Manual search block: Part number, Rev, Qty, then Search / Load. Same unknown-part path as the Load step.",
        },
        {
          type: "control",
          name: "Part number",
          does: "Search field under Load another part (quote suggestions).",
        },
        {
          type: "control",
          name: "Search / Load",
          does: "Same as Search / Load job — known quote loads; unknown opens New part — add to database.",
        },
        {
          type: "control",
          name: "Stock for this job",
          does: "Read-out of the PO line size, or a note that there is no customer PO line.",
        },
        {
          type: "control",
          name: "Pick / change stock",
          does: "Opens Pick stock (same guided form). Hidden when there is no PO line.",
        },
        {
          type: "control",
          name: "Saw / stock cut",
          does: "Up to three cut tickets for this part. Shows status and available blanks.",
        },
        {
          type: "control",
          name: "Claim 1 blank",
          does: "On a ticket with available > 0. Claims one blank for this machine. Toast “Claimed 1 blank · {n} left”. Hidden when nothing is available.",
        },
        {
          type: "control",
          name: "Job notes",
          does: "Free-text session notes. Autosave as you type. Use this when there is no PO stock line.",
        },
        {
          type: "control",
          name: "Save",
          does: "Opens Save job with qty completed prefilled. Disabled when no job is loaded.",
        },
        {
          type: "control",
          name: "Clear station",
          does: "Wipes the session on this machine without completing the job. Toast “Session cleared”. Does not mark the Job Board line done.",
        },
      ],
    },
    {
      title: "Soft jaws / other (tooling panel)",
      blocks: [
        {
          type: "p",
          text: "Always under More on this machine. Floor-only: no rates, billing, or notes. Need an operator and a loaded part to start.",
        },
        {
          type: "control",
          name: "Soft jaws / other",
          does: "Panel title. Separate from the part Setup/Runtime clock.",
        },
        {
          type: "control",
          name: "Soft jaws",
          does: "Kind toggle (default). Times making jaws.",
        },
        {
          type: "control",
          name: "Other",
          does: "Kind toggle. Times other tooling on this job.",
        },
        {
          type: "control",
          name: "Start timer",
          does: "Starts the selected kind on this machine / job. Disabled until you sign in and load a part. Helper text: “Sign in and load a part first”.",
        },
        {
          type: "control",
          name: "Stop",
          does: "Shown while a tooling timer is running (big clock). Saves minutes. Toast “Time saved”.",
        },
      ],
    },
    {
      title: "Shift bonus (Day bonus)",
      blocks: [
        {
          type: "p",
          text: "Compact panel at the bottom of More on this machine, keyed to the operator on this station. Full shift inside the window is required. Floor sees progress, not dollar formula. Admin sees projected / locked dollars.",
        },
        {
          type: "control",
          name: "Shift bonus · {name}",
          does: "Panel title. Badge Live or Finalized. Empty copy “Select an operator to see shift bonus progress.” when no name is on the machine.",
        },
        {
          type: "control",
          name: "Live",
          does: "Badge while the shift is not locked.",
        },
        {
          type: "control",
          name: "Finalized",
          does: "Badge after the shift is locked. Buttons hide.",
        },
        {
          type: "control",
          name: "Shift name chips",
          does: "One pill per enabled shift (e.g. Day, Night). The current window adds “ · now”. Tap to view that shift’s numbers.",
        },
        {
          type: "control",
          name: "Shift efficiency",
          does: "Metric. Live or finalized efficiency for that window.",
        },
        {
          type: "control",
          name: "On shift (in window)",
          does: "Hours inside start–end vs required hours (lunch excluded).",
        },
        {
          type: "control",
          name: "Earned hours",
          does: "Earned-hour pool for the bonus math.",
        },
        {
          type: "control",
          name: "Projected / Shift bonus",
          does: "Admin only money metric. Hidden on floor. Label is Projected until finalized, then Shift bonus.",
        },
        {
          type: "control",
          name: "Full {shift} progress",
          does: "Bar of on-shift hours vs required. Outside-window hours warn and do not count.",
        },
        {
          type: "control",
          name: "Finalize {shift}",
          does: "Locks the shift after the window end. Disabled until then (“Available after {end}”). Eligible bonus goes to the weekly payout (admin toast shows $). Floor toast is just “{shift} locked”. Hidden once Finalized.",
        },
        {
          type: "control",
          name: "Admin force finalize",
          does: "Admin only. Locks now even if the window has not ended. Hidden for floor.",
        },
      ],
    },
    {
      title: "Modal: New part — add to database",
      blocks: [
        {
          type: "p",
          text: "Opens when Search / Load job hits a P/N that is not in quotes. You must enter material and a customer so the shop has a record; then the job loads on this machine. Pricing is refined later in Master Quoter.",
        },
        {
          type: "control",
          name: "Part #",
          does: "Read-only. The number you searched.",
        },
        {
          type: "control",
          name: "Revision *",
          does: "Required. Uppercase.",
        },
        {
          type: "control",
          name: "Customer *",
          does: "Creatable customer list. Add customer creates the customer. Required.",
        },
        {
          type: "control",
          name: "Quantity *",
          does: "Job qty to load.",
        },
        {
          type: "control",
          name: "Material / Material type / Stock shape / How it sits / LOC",
          does: "Same guided stock form as the Stock step. Material and type are required to save.",
        },
        {
          type: "control",
          name: "Est. OP1 setup (min)",
          does: "Optional minutes written onto OP1 setup of the new quote.",
        },
        {
          type: "control",
          name: "Est. OP1 run (min/pc)",
          does: "Optional minutes per piece written onto OP1 runtime.",
        },
        {
          type: "control",
          name: "Notes",
          does: "Optional. Copied onto the machine session after load.",
        },
        {
          type: "control",
          name: "Cancel",
          does: "Closes without saving a quote or loading.",
        },
        {
          type: "control",
          name: "Save to database & load job",
          does: "Writes the quote (submit, or update if it appeared in the meantime) and loads the job on this machine. Errors: part / material / type / customer required, or save failed.",
        },
      ],
    },
    {
      title: "Modal: Units completed",
      blocks: [
        {
          type: "p",
          text: "Opens when you Stop a Runtime that needs a good-piece count (from this station or from My Active Jobs Stop).",
        },
        {
          type: "control",
          name: "Units completed",
          does: "Modal title. Copy: enter number of units completed during this runtime session.",
        },
        {
          type: "control",
          name: "Units number",
          does: "Number field (min 0), auto-focused. Prefills from Good so far when they counted on the fly. This is good pieces for this runtime stop, not the whole job qty.",
        },
        {
          type: "control",
          name: "Cancel",
          does: "Closes without stopping. The timer keeps running.",
        },
        {
          type: "control",
          name: "Confirm stop",
          does: "Stops the runtime with that qty. Toast “Runtime stopped”. Adds to quantity completed.",
        },
      ],
    },
    {
      title: "Modal: Pause reason",
      blocks: [
        {
          type: "control",
          name: "Pause reason",
          does: "Modal title. Creatable list (Lunch, End of Shift, Shift Change, Machine Transfer, Shop Help, plus shop custom). Default Lunch.",
        },
        {
          type: "control",
          name: "Add pause reason",
          does: "Create-dialog to add a reason to the shop list.",
        },
        {
          type: "control",
          name: "Cancel",
          does: "Closes without pausing. Timer keeps running.",
        },
        {
          type: "control",
          name: "Pause job",
          does: "Holds the clock with that reason. Toast “Paused: {reason}”. Resume later with the Work primary (or Start).",
        },
      ],
    },
    {
      title: "Modal: Save job",
      blocks: [
        {
          type: "p",
          text: "Opens from Finish job, Save, or a paused Finish job primary. Shows efficiency. Bonus $ only if this login can see money on the floor.",
        },
        {
          type: "control",
          name: "Qty completed (good parts finished)",
          does: "Number. Prefills from session quantity completed. If it is over job qty, a warn line says how many over — Complete will ask Extra parts — stock them?",
        },
        {
          type: "control",
          name: "Use this run in shop averages",
          does: "Checkbox, on by default. Uncheck for training / scrap / one-offs. History is always kept. Extreme outliers are auto-excluded.",
        },
        {
          type: "control",
          name: "Save in progress",
          does: "Writes the job as In Progress and closes. Requires the job to be paused first (note under the buttons). Does not open extras.",
        },
        {
          type: "control",
          name: "Mark completed",
          does: "Completes the job. If extras > 0, opens Extra parts — stock them? first. Otherwise finishes: recipe times update, customer prices do not. Toast says whether averages were updated.",
        },
      ],
    },
    {
      title: "Modal: Extra parts — stock them? + Write UIN",
      blocks: [
        {
          type: "p",
          text: "Opens when Mark completed qty is over the job qty. Closing the modal without Yes is treated as No — don't stock, then the job still completes.",
        },
        {
          type: "control",
          name: "How many extras to stock?",
          does: "Defaults to the over-run. Use less if some were scrap / hold.",
        },
        {
          type: "control",
          name: "Good",
          does: "Quality = sellable as normal stock (default).",
        },
        {
          type: "control",
          name: "Second quality",
          does: "Quality = slight defect. Reveals the required defect note. Kept separate from good stock of the same P/N.",
        },
        {
          type: "control",
          name: "Potential defect / note (required)",
          does: "Shown only for Second quality. Stays on the Parts inventory row.",
        },
        {
          type: "control",
          name: "Location (optional)",
          does: "Shelf / bin for the extras.",
        },
        {
          type: "control",
          name: "No — don't stock",
          does: "Completes the job without putting extras in inventory.",
        },
        {
          type: "control",
          name: "Yes — add to stock",
          does: "Creates part units (each gets a UIN) and opens Write UIN on each part. Errors if qty is 0 or stock fails.",
        },
        {
          type: "control",
          name: "Write UIN on each part",
          does: "Modal listing each sharpie code (Part N of M). Second-quality shows the defect note. Closing or Done completes the job.",
        },
        {
          type: "control",
          name: "Done — UINs written on parts",
          does: "Confirms you marked the parts. Completes the job. Toast reminds you extras (or second-quality) are stocked.",
        },
      ],
    },
    {
      title: "Modal: Correct time (admin)",
      blocks: [
        {
          type: "p",
          text: "Admin only, from tapping a Setup or Run cell. Title “Correct {Setup|Runtime} {OPn}”. If that timer is running it keeps going from the new time.",
        },
        {
          type: "control",
          name: "Hours / Min / Sec",
          does: "The clock the operator should have. Digits only.",
        },
        {
          type: "control",
          name: "-5 min / -1 min / +1 min / +5 min",
          does: "Nudges the three fields by that many minutes (floor at 0).",
        },
        {
          type: "control",
          name: "Cancel",
          does: "Closes without changing time.",
        },
        {
          type: "control",
          name: "Put them back on this timer",
          does: "Re-opens that Setup/Runtime from the edited seconds so the operator is live on it again.",
        },
        {
          type: "control",
          name: "Save time",
          does: "Writes the edited seconds onto that cell without necessarily restarting the timer. Toast “Set {type} {op} to {time}”.",
        },
      ],
    },
    {
      title: "Modal: Pick stock",
      blocks: [
        {
          type: "control",
          name: "Pick stock",
          does: "Same guided form as the Stock step. Copy: machinist pick wins. LOC is the saw axis (model 3\" → cut 3.1\"). Hidden if there is no PO line.",
        },
        {
          type: "control",
          name: "Done",
          does: "Closes Pick stock. Changes already patched onto the PO line as you typed.",
        },
      ],
    },
    {
      title: "Overlay: Job print",
      blocks: [
        {
          type: "p",
          text: "Full-screen drawing from header Print or View print. Escape or Close dismisses. Files come from the matching PO line / component drawings.",
        },
        {
          type: "control",
          name: "1 / 2 / …",
          does: "File tabs when more than one print is attached. Tap loads that file.",
        },
        {
          type: "control",
          name: "Window",
          does: "Pops the print into a separate window (allow pop-ups). If blocked, toast tells you to allow popups; the overlay stays.",
        },
        {
          type: "control",
          name: "Close",
          does: "Closes the overlay and revokes the blob URL.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Happy path — You through Done",
        },
        {
          type: "ol",
          items: [
            "Open the machine from Shop Floor.",
            "On You, set Who is on this machine? to yourself.",
            "On Load, tap Load next · {part} (or Search / Load job).",
            "On Stock, check Material / LOC and tap Confirm stock (or Skip for now).",
            "On Jaws, tap Yes — making soft jaws, then Stop jaws timer — or Skip for now.",
            "On Work tap Start {OP1} Setup (one-time). When the vise is set, tap Stop timer.",
            "Tap Start {OP1} Runtime (per piece). Run parts. Tap Stop timer, enter Units completed, Confirm stop.",
            "Repeat Start / Stop for later ops. Pause this timer only for lunch or end of shift.",
            "When the bar is on Done, tap Finish job. Enter Qty completed. Leave Use this run in shop averages checked. Tap Mark completed.",
          ],
        },
        {
          type: "h",
          text: "Load from search (not the queue)",
        },
        {
          type: "ol",
          items: [
            "Open Search a part instead (or Load another part under More).",
            "Type the P/N, Rev, Qty.",
            "Tap Search / Load job.",
            "If New part — add to database opens, fill Customer *, Material, type, and Save to database & load job.",
          ],
        },
        {
          type: "h",
          text: "Nest a pair on this clock",
        },
        {
          type: "ol",
          items: [
            "With a job loaded, type Nested part # or tap Suggestion: {part}.",
            "Tap Nest this part.",
            "If both vises run together, check Two vises, one cycle and do not start a second op timer.",
            "Mark good qty on both parts (Qty / done and Pair qty / done).",
            "Drop nested part if the mate is done and this part continues.",
          ],
        },
        {
          type: "h",
          text: "Pause for lunch or end of shift",
        },
        {
          type: "ol",
          items: [
            "While running, tap Pause this timer.",
            "Pick Lunch or End of Shift (or add a reason).",
            "Tap Pause job.",
            "End of shift: tap Save → Save in progress, then under Shift bonus tap Finalize {shift} after the window end.",
          ],
        },
        {
          type: "h",
          text: "Complete over-run extras",
        },
        {
          type: "ol",
          items: [
            "Tap Finish job or Save.",
            "Set Qty completed above job qty.",
            "Tap Mark completed.",
            "On Extra parts — stock them? set How many extras to stock?, Good or Second quality, Location.",
            "Tap Yes — add to stock (or No — don't stock).",
            "On Write UIN on each part, sharpie the codes, then Done — UINs written on parts.",
          ],
        },
        {
          type: "h",
          text: "Claim a saw blank",
        },
        {
          type: "ol",
          items: [
            "Open More on this machine.",
            "Under Saw / stock cut tap Claim 1 blank when available > 0.",
          ],
        },
        {
          type: "h",
          text: "Admin: fix a wrong clock",
        },
        {
          type: "ol",
          items: [
            "Tap the Setup or Run cell (pencil).",
            "Set Hours / Min / Sec or tap +/− min.",
            "Tap Save time, or Put them back on this timer if they should still be live.",
          ],
        },
        {
          type: "h",
          text: "Clear a botched load",
        },
        {
          type: "ol",
          items: [
            "Open More on this machine.",
            "Tap Clear station if you do not need to keep the run.",
            "Or Save → Save in progress if the time should stay on the job.",
          ],
        },
      ],
    },
  ],
};
