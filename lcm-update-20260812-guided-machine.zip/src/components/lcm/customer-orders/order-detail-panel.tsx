/**
 * Selected customer PO detail: header fields, lines table, actions.
 */
import { Fragment } from "react";
import {
  Plus,
  Trash2,
  Printer,
  FileUp,
  Paperclip,
  CheckCircle2,
  RefreshCw,
  ChevronRight,
  ChevronDown,
  FileOutput,
  HelpCircle,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CreatableSelect } from "@/components/ui/creatable-select";
import { SmartNumberInput } from "@/components/ui/smart-number-input";
import { Typeahead } from "@/components/ui/typeahead";
import { HelpTip, WithHelp } from "@/components/ui/help-tip";
import {
  shopLineExtension,
  shopLineOpenQty,
  shopOrderSubtotal,
} from "@/lib/lcm/po";
import type { ShopOrder, ShopOrderLine, Quote, MaterialStock } from "@/lib/lcm/types";
import { formatCurrency } from "@/lib/utils";
import { cn } from "@/lib/utils";
import { openPoAttachment } from "@/lib/lcm/open-attachment";
import {
  classifyPackageFile,
  matchFilesToParts,
  fileToBase64 as poFileToBase64,
} from "@/lib/lcm/po-import";
import {
  addFileToLine,
  lineCadFiles,
  lineDrawings,
  matchFileToAssemblyLine,
  normalizeComponents,
  promoteRelatedFilesToComponents,
  removeFileFromLine,
} from "@/lib/lcm/line-files";
import { savePoAttachment } from "@/lib/lcm/po-files-api";
import { getShopToken } from "@/lib/lcm/shop-sync";
import {
  enrichShopOrderLines,
  applyMaterialPlanToLine,
  resolveLineMaterial,
  listMaterialStockCandidates,
  estimateMaterialUnits,
  formatSizeNote,
  checkPoLineAgainstQuote,
} from "@/lib/lcm/po-material";
import { allMaterials, allMaterialTypes, allStockShapes } from "@/lib/lcm/lists";
import { stockSizeNoteOptions, stockSizeNoteHint } from "@/lib/lcm/stock-size-catalog";
import {
  materialLineStatus,
  packStatusToShop,
  statusSurfaceClass,
  statusToBadgeTone,
} from "@/lib/lcm/status-colors";
import { MetaCell } from "./meta-widgets";

export type OrderDetailPanelProps = {
  selected: ShopOrder | null;
  canSeePrices: boolean;
  company: string;
  customerNames: string[];
  partNumbers: string[];
  materialStock: MaterialStock[];
  quotes: Quote[];
  customLists: import("@/lib/lcm/types").CustomLists;
  settings: import("@/lib/lcm/types").AppSettings;
  attentionCount: number;
  materialOptions: string[];
  materialEditLineId: string | null;
  setMaterialEditLineId: (id: string | null) => void;
  expandedLines: Record<string, boolean>;
  setExpandedLines: React.Dispatch<React.SetStateAction<Record<string, boolean>>>;
  deleteConfirm: boolean;
  setDeleteConfirm: (v: boolean) => void;
  setSalesOrderOpen: (v: boolean) => void;
  setImportOpen: (v: boolean) => void;
  updateSelected: (patch: Partial<ShopOrder>) => void;
  updateLine: (lineId: string, patch: Partial<ShopOrderLine>) => void;
  addLine: (partNumber?: string) => void;
  fillFromQuote: (lineId: string, partNumber: string) => void;
  checkAllMaterials: () => void;
  enrichShopOrderMaterial: (orderId: string) => void;
  syncPartMaterialRecipe: (...args: any[]) => void;
  setShopLineMaterialReviewed: (orderId: string, lineId: string, reviewed: boolean) => void;
  updateShopOrderLineProgress: (...args: any[]) => void;
  addCustomerQuick: (name: string) => { ok: boolean; error?: string };
  assignShopOrderLine: (...args: any[]) => { ok: boolean; error?: string };
  setAssignLine: (v: { lineId: string; partNumber: string; openQty: number } | null) => void;
  setAssignMachine: (v: string) => void;
  setAssignOperator: (v: string) => void;
  setAssignQty: (v: string) => void;
  setAssignNotes: (v: string) => void;
  machines: string[];
  operatorNames: string[];
  removeShopOrder: (id: string) => void;
  statusTone: (status: string) => any;
};

export function OrderDetailPanel(props: OrderDetailPanelProps) {
  const {
    selected,
    canSeePrices,
    company,
    customerNames,
    partNumbers,
    materialStock,
    quotes,
    customLists,
    settings,
    attentionCount,
    materialOptions,
    materialEditLineId,
    setMaterialEditLineId,
    expandedLines,
    setExpandedLines,
    setDeleteConfirm,
    setSalesOrderOpen,
    setImportOpen,
    updateSelected,
    updateLine,
    addLine,
    fillFromQuote,
    checkAllMaterials,
    setShopLineMaterialReviewed,
    updateShopOrderLineProgress,
    addCustomerQuick,
    setAssignLine,
    setAssignMachine,
    setAssignOperator,
    setAssignQty,
    setAssignNotes,
    machines,
    operatorNames,
    statusTone,
  } = props;

  const subtotal = selected ? shopOrderSubtotal(selected) : 0;

  return (
<div className="lg:col-span-9">
  {!selected ? (
    <Card>
      <CardContent className="p-10 text-center text-[var(--color-muted)]">
        Select or create a customer PO.
      </CardContent>
    </Card>
  ) : (
    <Card className="overflow-hidden border-[var(--color-border)] bg-[var(--color-surface)]">
      <CardHeader className="border-b border-[var(--color-border)] pb-4">
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
          <div className="space-y-1">
            <CardTitle className="text-xl flex flex-wrap items-center gap-2">
              <span className="font-mono">
                {selected.poNumber || "New PO"}{selected.poRevision ? ` rev ${selected.poRevision}` : ""}
              </span>
              <Badge tone={statusTone(selected.status)}>
                {selected.status}
              </Badge>
            </CardTitle>
            <CardDescription>
              {selected.customer || "No customer"}
              {selected.dateRequired
                ? ` · need by ${selected.dateRequired}`
                : ""}
              {selected.rating ? ` · rating ${selected.rating}` : ""}
            </CardDescription>
          </div>
          <div className="flex flex-wrap gap-2 print:hidden">
            {selected.sourceFileId ? (
              <Button
                size="sm"
                variant="secondary"
                type="button"
                onClick={async () => {
                  const r = await openPoAttachment({
                    id: selected.sourceFileId,
                    name: selected.sourceFileName,
                  });
                  if (!r.ok)
                    toast.error(r.error || "Missing PO file");
                }}
              >
                <Paperclip className="h-4 w-4" /> Original PO PDF
              </Button>
            ) : null}
            <label
              className="inline-flex items-center gap-1.5 h-9 px-3 rounded-[var(--radius-md)] border border-[var(--color-border-strong)] bg-[var(--color-surface-2)] text-xs font-medium cursor-pointer hover:bg-[var(--color-surface-3)]"
              title="Multi-select drawings + CAD; match by P/N in filename"
            >
              <FileUp className="h-4 w-4" /> Attach drawings/CAD
              <input
                type="file"
                className="sr-only"
                multiple
                accept=".pdf,image/*,.dxf,.dwg,.tif,.tiff,.x_t,.x_b,.step,.stp,.iges,.igs,.sldprt,.sldasm,.prt,.f3d,.sat,.stl,.obj,application/octet-stream"
                onChange={async (e) => {
                  const files = Array.from(e.target.files || []);
                  e.target.value = "";
                  if (!files.length || !selected) return;
                  const token = getShopToken() || undefined;
                  const parts = selected.lines.map((l) => l.partNumber);
                  const drawingUploads: {
                    name: string;
                    id: string;
                    mime: string;
                  }[] = [];
                  const cadUploads: {
                    name: string;
                    id: string;
                    mime: string;
                  }[] = [];
                  for (const f of files) {
                    const kind = classifyPackageFile(f.name, f.type || "");
                    const b64 = await poFileToBase64(f);
                    const saved = await savePoAttachment({
                      data: {
                        name: f.name,
                        mime: f.type || "application/octet-stream",
                        base64: b64,
                        token,
                      },
                    });
                    if (!saved.ok) {
                      toast.error(saved.error || `Failed ${f.name}`);
                      continue;
                    }
                    const meta = {
                      name: saved.meta.name,
                      id: saved.meta.id,
                      mime: saved.meta.mime,
                    };
                    if (kind === "cad") cadUploads.push(meta);
                    else drawingUploads.push(meta);
                  }
                  let dN = 0;
                  let cN = 0;
                  let used = 0;
                  const allMeta = [
                    ...drawingUploads.map((m) => ({ ...m, kind: "drawing" as const })),
                    ...cadUploads.map((m) => ({ ...m, kind: "cad" as const })),
                  ];
                  for (const meta of allMeta) {
                    const hit =
                      matchFileToAssemblyLine(parts, meta.name) ||
                      (() => {
                        const exact = matchFilesToParts(parts, [meta]);
                        const pn = Object.keys(exact)[0];
                        return pn
                          ? {
                              partNumber: pn,
                              relatedPartNumber: pn,
                              exact: true,
                            }
                          : null;
                      })();
                    if (!hit) continue;
                    const line = selected.lines.find(
                      (l) =>
                        l.partNumber.toUpperCase() ===
                        hit.partNumber.toUpperCase(),
                    );
                    if (!line) continue;
                    const kind =
                      meta.kind === "cad" ||
                      classifyPackageFile(meta.name, meta.mime) === "cad"
                        ? "cad"
                        : "drawing";
                    const patch = addFileToLine(
                      line,
                      kind,
                      meta,
                      hit.relatedPartNumber,
                    );
                    updateLine(line.id, patch);
                    used++;
                    if (kind === "cad") cN++;
                    else dN++;
                  }
                  toast.success(
                    `Added ${dN} drawing(s) · ${cN} CAD (assemblies keep all files)` +
                      (files.length > used
                        ? ` · ${files.length - used} unmatched (name with P/N)`
                        : ""),
                  );
                }}
              />
            </label>
            {canSeePrices && (
              <Button
                size="sm"
                variant="secondary"
                type="button"
                onClick={() => setSalesOrderOpen(true)}
                title="Print Sales Order form or export QuickBooks CSV"
              >
                <FileOutput className="h-4 w-4" />
                Sales Order / QB
              </Button>
            )}
            <Select
              className="h-9 text-xs w-auto min-w-[8rem]"
              value={selected.status}
              onChange={(e) =>
                updateSelected({
                  status: e.target.value as ShopOrder["status"],
                })
              }
            >
              <option value="draft">draft</option>
              <option value="open">open</option>
              <option value="in_progress">in progress</option>
              <option value="complete">complete</option>
              <option value="cancelled">cancelled</option>
            </Select>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-4">
          <div className="space-y-1.5">
            <Label>Customer</Label>
            <CreatableSelect
              value={selected.customer}
              options={customerNames}
              onChange={(v) => updateSelected({ customer: v })}
              onCreate={(v) => {
                addCustomerQuick(v);
                updateSelected({ customer: v });
              }}
              createTitle="Add customer"
            />
          </div>
          <div className="space-y-1.5">
            <Label>PO #</Label>
            <Input
              className="font-mono"
              value={selected.poNumber}
              onChange={(e) =>
                updateSelected({
                  poNumber: e.target.value.toUpperCase(),
                })
              }
              placeholder="PO-26-X679"
            />
          </div>
          <div className="space-y-1.5">
            <Label>PO rev</Label>
            <Input
              className="font-mono uppercase w-20"
              value={selected.poRevision || ""}
              onChange={(e) =>
                updateSelected({
                  poRevision: e.target.value.toUpperCase(),
                })
              }
              placeholder="—"
              title="Blank on the original PO. First customer revise is A, then B, C… Not the part drawing rev."
            />
            <p className="text-[10px] text-[var(--color-subtle)]">
              Blank = original PO. A = first customer revise.
            </p>
          </div>
          <div className="space-y-1.5">
            <Label>Date required</Label>
            <Input
              type="date"
              value={selected.dateRequired || ""}
              onChange={(e) =>
                updateSelected({
                  dateRequired: e.target.value,
                  dueDate: e.target.value,
                })
              }
            />
          </div>
          <div className="space-y-1.5">
            <Label>Rating</Label>
            <Input
              value={selected.rating || ""}
              onChange={(e) =>
                updateSelected({ rating: e.target.value })
              }
              placeholder="Optional"
            />
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-0">
      {attentionCount > 0 && (
        <div className="mx-4 my-3 rounded-md border border-[color-mix(in_oklab,var(--color-warn)_40%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-warn)_12%,transparent)] px-3 py-2 text-xs text-[var(--color-fg)] print:hidden">
          <strong>{attentionCount}</strong> line
          {attentionCount === 1 ? "" : "s"} need material attention
          (marked <HelpCircle className="inline h-3.5 w-3.5 text-[var(--color-warn)]" />).
          Matched lines show a check when stock is planned.
        </div>
      )}

      {/* Lines table */}
      <div className="overflow-x-auto">
        <table className="w-full text-xs min-w-[780px]">
          <thead>
            <tr className="bg-[var(--color-surface-2)] border-b border-[var(--color-border)] text-left">
              <th className="px-2 py-2 font-bold w-10">Item</th>
              <th className="px-2 py-2 font-bold w-12 print:hidden">
                Mat
              </th>
              <th className="px-2 py-2 font-bold">Part #</th>
              <th className="px-2 py-2 font-bold min-w-[2.75rem] w-12 text-center">Rev</th>
              {canSeePrices && (
                <th className="px-2 py-2 font-bold min-w-[6.5rem] w-28">Cost</th>
              )}
              <th className="px-2 py-2 font-bold min-w-[3.25rem] w-16">Order Qty</th>
              <th className="px-2 py-2 font-bold min-w-[4.25rem] w-20">Units</th>
              <th className="px-2 py-2 font-bold min-w-[3.25rem] w-16">Done</th>
              <th className="px-2 py-2 font-bold min-w-[3rem] w-14">Open</th>
              {canSeePrices && (
                <th className="px-2 py-2 font-bold min-w-[3.5rem] w-16">Tax?</th>
              )}
              {canSeePrices && (
                <th className="px-2 py-2 font-bold min-w-[5.5rem] w-24">Extension</th>
              )}
              <th className="px-2 py-2 w-10 print:hidden"> </th>
            </tr>
          </thead>
          <tbody>
            {selected.lines.map((line) => {
              const open = shopLineOpenQty(line);
              const ext = shopLineExtension(line);
              const expanded = Boolean(expandedLines[line.id]);
              const quoteCheck = checkPoLineAgainstQuote(
                quotes,
                line.partNumber,
                line.revision,
                line.qty,
                line.unitCost || 0,
              );
              const costAlert =
                canSeePrices &&
                (quoteCheck.zeroCost || quoteCheck.costMismatch);
              const qtyAlert = quoteCheck.qtyNotOnBreak && quoteCheck.hasQuote;
              const matOk =
                line.materialStatus === "ok" ||
                Boolean(line.materialReviewed);
              const matLabel = line.material
                ? [
                    line.material,
                    line.materialType,
                    line.sizeNote ||
                      (line.dimX
                        ? `${line.dimX}${line.dimY ? "×" + line.dimY : ""}"`
                        : ""),
                  ]
                    .filter(Boolean)
                    .join(" · ")
                : "Material not set";
              // item mat pn rev qty units done open actions + optional cost tax ext
              const colSpan = 9 + (canSeePrices ? 3 : 0);
              return (
                <Fragment key={line.id}>
                  <tr
                    className={cn(
                      "border-b border-[var(--color-border)] align-middle",
                      line.lineStatus === "cancelled" &&
                        "opacity-55 bg-[color-mix(in_oklab,var(--color-muted)_8%,transparent)]",
                    )}
                  >
                    <td className="px-2 py-1.5">
                      {line.lineStatus === "cancelled" ? (
                        <div className="flex flex-col gap-0.5">
                          <span className="font-mono text-[10px] text-[var(--color-muted)]">
                            {line.itemNo}
                          </span>
                          <Badge tone="danger" className="text-[9px] px-1 py-0">
                            Dropped
                          </Badge>
                        </div>
                      ) : (
                      <Input
                        type="number"
                        className="h-8 w-12 text-xs"
                        value={line.itemNo}
                        onChange={(e) =>
                          updateLine(line.id, {
                            itemNo: Number(e.target.value) || 0,
                          })
                        }
                      />
                      )}
                    </td>
                    <td className="px-1 py-1.5 text-center print:hidden">
                      <div className="flex flex-col items-center gap-0.5">
                        <label
                          className="inline-flex items-center justify-center"
                          title={
                            line.materialReviewed
                              ? "Marked OK"
                              : "Check when material is planned"
                          }
                        >
                          <input
                            type="checkbox"
                            className="h-4 w-4 accent-[var(--color-success)]"
                            checked={Boolean(line.materialReviewed)}
                            onChange={(e) =>
                              setShopLineMaterialReviewed(
                                selected.id,
                                line.id,
                                e.target.checked,
                              )
                            }
                          />
                        </label>
                        {matOk ? (
                          <CheckCircle2
                            className="h-3.5 w-3.5 text-[var(--color-success)]"
                            aria-label="Material OK"
                          />
                        ) : (
                          <button
                            type="button"
                            className="text-amber-600 hover:text-amber-800"
                            title={
                              line.attentionReason ||
                              "Needs material attention"
                            }
                            onClick={() =>
                              setMaterialEditLineId(line.id)
                            }
                          >
                            <HelpCircle className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                    <td className="px-2 py-1.5">
                      <div className="flex items-start gap-1 min-w-[11rem]">
                        <button
                          type="button"
                          className="mt-1.5 shrink-0 rounded p-0.5 text-[var(--color-muted)] hover:bg-[var(--color-surface-2)] print:hidden"
                          title={
                            expanded
                              ? "Hide details"
                              : "Description, drawing, material"
                          }
                          onClick={() =>
                            setExpandedLines((m: Record<string, boolean>) => ({
                              ...m,
                              [line.id]: !m[line.id],
                            }))
                          }
                        >
                          {expanded ? (
                            <ChevronDown className="h-4 w-4" />
                          ) : (
                            <ChevronRight className="h-4 w-4" />
                          )}
                        </button>
                        <div className="flex-1 min-w-0 space-y-0.5">
                          <CreatableSelect
                            value={line.partNumber}
                            options={partNumbers}
                            onChange={(v) => {
                              updateLine(line.id, { partNumber: v });
                              fillFromQuote(line.id, v);
                            }}
                            onCreate={(v) =>
                              updateLine(line.id, {
                                partNumber: v.toUpperCase(),
                              })
                            }
                            createTitle="New part #"
                          />
                          <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[10px] leading-tight">
                            <button
                              type="button"
                              className={
                                "truncate max-w-[16rem] text-left font-medium " +
                                (matOk
                                  ? "text-[var(--color-muted)]"
                                  : "text-amber-700")
                              }
                              title={line.attentionReason || matLabel}
                              onClick={() =>
                                setMaterialEditLineId(line.id)
                              }
                            >
                              {matLabel}
                            </button>
                            {lineDrawings(line).length > 0 ||
                            lineCadFiles(line).length > 0 ? (
                              <span className="inline-flex items-center gap-0.5 text-[var(--color-subtle)] shrink-0" title="Files attached">
                                <Paperclip className="h-3 w-3" />
                                {lineDrawings(line).length +
                                  lineCadFiles(line).length >
                                1
                                  ? lineDrawings(line).length +
                                    lineCadFiles(line).length
                                  : null}
                              </span>
                            ) : null}
                            {(line.materialNeeded || 0) >
                              (line.materialOnHand || 0) &&
                            line.material ? (
                              <span className="font-semibold text-[var(--color-status-danger)]">
                                BUY{" "}
                                {(line.materialNeeded || 0) -
                                  (line.materialOnHand || 0)}
                              </span>
                            ) : null}
                            {!line.revPdfOk || !line.stockNoted ? (
                              <Badge tone="hold" className="text-[9px] px-1.5 py-0">
                                Hold
                              </Badge>
                            ) : (
                              <Badge tone="open" className="text-[9px] px-1.5 py-0">
                                Released
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-1 py-1.5 min-w-[2.75rem] w-12">
                      <Input
                        className="!min-h-8 h-8 w-full min-w-[2.5rem] px-0.5 text-center text-sm font-bold uppercase tracking-wide text-[var(--color-fg)]"
                        maxLength={6}
                        value={line.revision}
                        title={line.revision || "Revision"}
                        onChange={(e) =>
                          updateLine(line.id, {
                            revision: e.target.value.toUpperCase(),
                            materialReviewed: false,
                          })
                        }
                      />
                    </td>
                    {canSeePrices && (
                      <td className="px-1.5 py-1.5 min-w-[6.5rem]">
                        <div className="space-y-0.5">
                          <SmartNumberInput
                            format="currency"
                            className={
                              "h-8 !min-h-8 text-xs tabular-nums w-full min-w-[6rem] px-2 " +
                              (quoteCheck.zeroCost
                                ? "border-amber-500 bg-amber-500/15 ring-1 ring-amber-500/50 font-semibold text-amber-100"
                                : quoteCheck.costMismatch
                                  ? "border-orange-500 bg-orange-500/15 ring-1 ring-orange-500/40 font-semibold"
                                  : "")
                            }
                            value={line.unitCost || 0}
                            placeholder="$0.00"
                            onValueChange={(unitCost) =>
                              updateLine(line.id, { unitCost })
                            }
                          />
                          {costAlert && (
                            <p
                              className="text-[9px] leading-tight text-amber-300/95 px-0.5"
                              title={quoteCheck.summary}
                            >
                              {quoteCheck.zeroCost
                                ? quoteCheck.quotedUnitPrice > 0
                                  ? `Need cost — quote $${quoteCheck.quotedUnitPrice.toFixed(2)} (@ qty ${quoteCheck.quoteQtyBreak})`
                                  : "Need cost ($0.00)"
                                : `≠ quote $${quoteCheck.quotedUnitPrice.toFixed(2)} (@ qty ${quoteCheck.quoteQtyBreak})`}
                            </p>
                          )}
                        </div>
                      </td>
                    )}
                    <td className="px-1.5 py-1.5 min-w-[3.25rem] w-16">
                      <div className="space-y-0.5">
                        <Input
                          type="text"
                          inputMode="numeric"
                          title={
                            qtyAlert
                              ? quoteCheck.summary
                              : "Order quantity"
                          }
                          className={
                            "h-8 !min-h-8 text-xs tabular-nums w-full min-w-[2.75rem] px-1.5 text-center " +
                            (qtyAlert
                              ? "border-amber-500/80 bg-amber-500/10 ring-1 ring-amber-500/40"
                              : "")
                          }
                          value={line.qty === 0 ? "" : String(line.qty)}
                          onChange={(e) => {
                            const raw = e.target.value.replace(/[^0-9.]/g, "");
                            updateLine(line.id, {
                              qty: raw === "" ? 0 : Number(raw) || 0,
                            });
                          }}
                        />
                        {qtyAlert && (
                          <p
                            className="text-[9px] leading-tight text-amber-300/90 px-0.5"
                            title={quoteCheck.summary}
                          >
                            qty ≠ quote
                          </p>
                        )}
                      </div>
                    </td>
                    <td className="px-1.5 py-1.5 min-w-[4.25rem]">
                      <Input
                        className="h-8 text-xs w-full min-w-[3.75rem] px-2"
                        value={line.units}
                        onChange={(e) =>
                          updateLine(line.id, {
                            units: e.target.value,
                          })
                        }
                      />
                    </td>
                    <td className="px-1.5 py-1.5 min-w-[3.25rem] w-16">
                      <Input
                        type="text"
                        inputMode="numeric"
                        className="h-8 text-xs tabular-nums w-full min-w-[2.75rem] px-1.5 text-center"
                        value={
                          line.qtyCompleted === 0
                            ? ""
                            : String(line.qtyCompleted)
                        }
                        onChange={(e) => {
                          const raw = e.target.value.replace(/[^0-9.]/g, "");
                          updateShopOrderLineProgress(
                            selected.id,
                            line.id,
                            raw === "" ? 0 : Number(raw) || 0,
                          );
                        }}
                      />
                    </td>
                    <td className="px-2 py-1.5 tabular font-semibold">
                      <span
                        className={
                          open > 0
                            ? "text-amber-700"
                            : "text-green-700"
                        }
                      >
                        {open}
                      </span>
                    </td>
                    {canSeePrices && (
                      <td className="px-1.5 py-1.5 min-w-[3.5rem]">
                        <Select
                          className="h-8 text-xs w-full min-w-[3.25rem] px-1"
                          value={line.taxable ? "Y" : "N"}
                          onChange={(e) =>
                            updateLine(line.id, {
                              taxable: e.target.value === "Y",
                            })
                          }
                        >
                          <option value="N">N</option>
                          <option value="Y">Y</option>
                        </Select>
                      </td>
                    )}
                    {canSeePrices && (
                      <td className="px-2 py-1.5 tabular font-medium">
                        {formatCurrency(ext)}
                      </td>
                    )}
                    <td className="px-1 py-1.5 print:hidden">
                      <div className="flex flex-col gap-1">
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 text-[10px] px-2"
                          disabled={open <= 0 || !line.partNumber}
                          onClick={() => {
                            setAssignLine({
                              lineId: line.id,
                              partNumber: line.partNumber,
                              openQty: open,
                            });
                            setAssignQty(String(open));
                            const pref = quotes.find(
                              (q) =>
                                q.partNumber.toUpperCase() ===
                                line.partNumber.toUpperCase(),
                            )?.machines?.[0];
                            setAssignMachine(
                              pref || machines[0] || "",
                            );
                            setAssignOperator("");
                            setAssignNotes("");
                          }}
                        >
                          Assign
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8"
                          aria-label="Remove line"
                          onClick={() =>
                            updateSelected({
                              lines: selected.lines.filter(
                                (l) => l.id !== line.id,
                              ),
                            })
                          }
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                  {expanded ? (
                    <tr className="border-b border-[var(--color-border)] bg-[var(--color-surface-2)]/70">
                      <td colSpan={colSpan} className="px-3 py-2.5">
                        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                          <div className="space-y-1">
                            <div className="text-[10px] font-semibold uppercase tracking-wide text-[var(--color-muted)]">
                              Description
                            </div>
                            <textarea
                              className="w-full text-xs border border-[var(--color-border)] rounded px-2 py-1.5 bg-[var(--color-surface)] min-h-[2.25rem] resize-y"
                              value={line.description || ""}
                              onChange={(e) =>
                                updateLine(line.id, {
                                  description: e.target.value,
                                })
                              }
                              placeholder="Description (optional)"
                            />
                          </div>
                          <div className="space-y-1 sm:col-span-2">
                            <div className="text-[10px] font-semibold uppercase tracking-wide text-[var(--color-muted)]">
                              Drawings (assembly may have several)
                            </div>
                            <div className="flex flex-wrap items-center gap-2 text-xs">
                              {lineDrawings(line).length === 0 && (
                                <span className="text-[var(--color-subtle)]">
                                  No drawing
                                </span>
                              )}
                              {lineDrawings(line).map((d) => (
                                <span
                                  key={d.id}
                                  className="inline-flex items-center gap-1 rounded border border-[var(--color-border)] px-1.5 py-0.5"
                                >
                                  <button
                                    type="button"
                                    className="text-[var(--color-primary)] underline inline-flex items-center gap-1 max-w-[12rem] truncate"
                                    title={d.name}
                                    onClick={async () => {
                                      const r = await openPoAttachment({
                                        id: d.id,
                                        name: d.name,
                                      });
                                      if (!r.ok)
                                        toast.error(
                                          r.error || "Missing file",
                                        );
                                    }}
                                  >
                                    <Paperclip className="h-3.5 w-3.5 shrink-0" />
                                    {d.relatedPartNumber
                                      ? `${d.relatedPartNumber}: `
                                      : ""}
                                    {d.name}
                                  </button>
                                  <button
                                    type="button"
                                    className="text-[var(--color-muted)] hover:text-[var(--color-danger)]"
                                    title="Remove"
                                    onClick={() =>
                                      updateLine(
                                        line.id,
                                        removeFileFromLine(
                                          line,
                                          "drawing",
                                          d.id,
                                        ),
                                      )
                                    }
                                  >
                                    ×
                                  </button>
                                </span>
                              ))}
                              <label className="text-[var(--color-muted)] underline cursor-pointer">
                                Add drawing
                                <input
                                  type="file"
                                  className="hidden"
                                  multiple
                                  accept=".pdf,image/*,.dxf,.dwg,.tif,.tiff"
                                  onChange={async (e) => {
                                    const files = Array.from(
                                      e.target.files || [],
                                    );
                                    e.target.value = "";
                                    if (!files.length || !selected) return;
                                    for (const f of files) {
                                      const { fileToBase64 } = await import(
                                        "@/lib/lcm/po-import"
                                      );
                                      const { savePoAttachment } =
                                        await import(
                                          "@/lib/lcm/po-files-api"
                                        );
                                      const b64 = await fileToBase64(f);
                                      const saved = await savePoAttachment({
                                        data: {
                                          name: f.name,
                                          mime:
                                            f.type ||
                                            "application/octet-stream",
                                          base64: b64,
                                          token:
                                            (
                                              await import(
                                                "@/lib/lcm/shop-sync"
                                              )
                                            ).getShopToken() || undefined,
                                        },
                                      });
                                      if (!saved.ok) {
                                        toast.error(
                                          saved.error || "Upload failed",
                                        );
                                        continue;
                                      }
                                      const rel =
                                        matchFileToAssemblyLine(
                                          [line.partNumber],
                                          saved.meta.name,
                                        )?.relatedPartNumber;
                                      updateLine(
                                        line.id,
                                        addFileToLine(
                                          line,
                                          "drawing",
                                          saved.meta,
                                          rel,
                                        ),
                                      );
                                    }
                                    toast.success("Drawing(s) added");
                                  }}
                                />
                              </label>
                            </div>
                          </div>

                          <div className="space-y-1 sm:col-span-2 lg:col-span-3">
                            <div className="text-[10px] font-semibold uppercase tracking-wide text-[var(--color-muted)]">
                              Release to job board
                            </div>
                            <div className="flex flex-wrap gap-3 text-xs">
                              <label className="inline-flex items-center gap-1.5 cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={Boolean(line.revPdfOk)}
                                  onChange={(e) =>
                                    updateLine(line.id, {
                                      revPdfOk: e.target.checked,
                                    })
                                  }
                                />
                                PDF rev matches PO
                              </label>
                              <label className="inline-flex items-center gap-1.5 cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={Boolean(line.stockNoted)}
                                  onChange={(e) =>
                                    updateLine(line.id, {
                                      stockNoted: e.target.checked,
                                    })
                                  }
                                />
                                Stock size noted
                              </label>
                              <label className="inline-flex items-center gap-1.5 cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={Boolean(line.revCadOk)}
                                  onChange={(e) =>
                                    updateLine(line.id, {
                                      revCadOk: e.target.checked,
                                    })
                                  }
                                />
                                CAD rev OK
                              </label>
                            </div>
                            <div className="flex flex-wrap items-center gap-2 text-xs mt-1">
                              <span className="text-[10px] font-semibold uppercase tracking-wide text-[var(--color-muted)] w-full">
                                CAD files
                              </span>
                              {lineCadFiles(line).length === 0 && (
                                <span className="text-[var(--color-subtle)]">
                                  No CAD (optional)
                                </span>
                              )}
                              {lineCadFiles(line).map((f) => (
                                <span
                                  key={f.id}
                                  className="inline-flex items-center gap-1 rounded border border-[var(--color-border)] px-1.5 py-0.5"
                                >
                                  <button
                                    type="button"
                                    className="text-[var(--color-primary)] underline max-w-[12rem] truncate"
                                    title={f.name}
                                    onClick={async () => {
                                      const r = await openPoAttachment({
                                        id: f.id,
                                        name: f.name,
                                      });
                                      if (!r.ok)
                                        toast.error(
                                          r.error || "Missing CAD",
                                        );
                                    }}
                                  >
                                    {f.relatedPartNumber
                                      ? `${f.relatedPartNumber}: `
                                      : ""}
                                    {f.name}
                                  </button>
                                  <button
                                    type="button"
                                    className="text-[var(--color-muted)] hover:text-[var(--color-danger)]"
                                    title="Remove"
                                    onClick={() =>
                                      updateLine(
                                        line.id,
                                        removeFileFromLine(
                                          line,
                                          "cad",
                                          f.id,
                                        ),
                                      )
                                    }
                                  >
                                    ×
                                  </button>
                                </span>
                              ))}
                              <label className="text-[var(--color-muted)] underline cursor-pointer">
                                Add CAD
                                <input
                                  type="file"
                                  className="hidden"
                                  multiple
                                  accept=".x_t,.x_b,.step,.stp,.iges,.igs,.sldprt,.sldasm,.prt,.f3d,.sat,.stl,.obj,application/octet-stream"
                                  onChange={async (e) => {
                                    const files = Array.from(
                                      e.target.files || [],
                                    );
                                    e.target.value = "";
                                    if (!files.length || !selected) return;
                                    for (const f of files) {
                                      const { fileToBase64 } = await import(
                                        "@/lib/lcm/po-import"
                                      );
                                      const { savePoAttachment } =
                                        await import(
                                          "@/lib/lcm/po-files-api"
                                        );
                                      const b64 = await fileToBase64(f);
                                      const saved = await savePoAttachment({
                                        data: {
                                          name: f.name,
                                          mime:
                                            f.type ||
                                            "application/octet-stream",
                                          base64: b64,
                                          token:
                                            (
                                              await import(
                                                "@/lib/lcm/shop-sync"
                                              )
                                            ).getShopToken() || undefined,
                                        },
                                      });
                                      if (!saved.ok) {
                                        toast.error(
                                          saved.error || "Upload failed",
                                        );
                                        continue;
                                      }
                                      const rel =
                                        matchFileToAssemblyLine(
                                          [line.partNumber],
                                          saved.meta.name,
                                        )?.relatedPartNumber;
                                      updateLine(
                                        line.id,
                                        addFileToLine(
                                          line,
                                          "cad",
                                          saved.meta,
                                          rel,
                                        ),
                                      );
                                    }
                                    toast.success("CAD file(s) added");
                                  }}
                                />
                              </label>
                            </div>
                            {normalizeComponents(line).length > 0 && (
                              <div className="mt-2 rounded border border-[var(--color-border)] bg-[var(--color-surface-2)] p-2 space-y-1">
                                <div className="text-[10px] font-semibold uppercase tracking-wide text-[var(--color-muted)]">
                                  Assembly components (job board)
                                </div>
                                <p className="text-[10px] text-[var(--color-muted)]">
                                  Shop pulls each component first, then the assembly
                                  line to bolt together.
                                </p>
                                <ul className="text-xs space-y-1">
                                  {normalizeComponents(line).map((c) => (
                                    <li
                                      key={c.id}
                                      className="flex flex-wrap items-center gap-2 font-mono"
                                    >
                                      <span className="font-semibold">
                                        {c.partNumber}
                                      </span>
                                      <span className="text-[var(--color-muted)]">
                                        qty {c.qty}
                                      </span>
                                      <span className="text-[10px] text-[var(--color-muted)]">
                                        {c.drawings?.length || 0} draw ·{" "}
                                        {c.cadFiles?.length || 0} CAD
                                      </span>
                                      {c.complete ? (
                                        <Badge tone="done" className="text-[9px]">
                                          Complete
                                        </Badge>
                                      ) : c.checkedOutBy ? (
                                        <Badge tone="active" className="text-[9px]">
                                          {c.checkedOutBy}
                                        </Badge>
                                      ) : (
                                        <Badge tone="open" className="text-[9px]">
                                          On board
                                        </Badge>
                                      )}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}
                            <p className="text-[10px] text-[var(--color-subtle)]">
                              Line appears on Job Board only after PDF
                              rev + stock note (and CAD rev if CAD
                              attached). Pull is one line — not whole PO.
                            </p>
                          </div>
                          <div
                            className={
                              "rounded-md border px-2.5 py-2 text-[10px] leading-snug sm:col-span-2 lg:col-span-1 " +
                              (matOk
                                ? "border-[color-mix(in_oklab,var(--color-success)_35%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-success)_10%,transparent)]"
                                : "border-[color-mix(in_oklab,var(--color-warn)_35%,var(--color-border))] bg-[color-mix(in_oklab,var(--color-warn)_10%,transparent)]")
                            }
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div>
                                <div className="text-[10px] font-semibold uppercase tracking-wide text-[var(--color-muted)]">
                                  Material
                                </div>
                                <div className="font-semibold text-xs mt-0.5">
                                  {matLabel}
                                </div>
                              </div>
                              <button
                                type="button"
                                className="underline shrink-0 print:hidden"
                                onClick={() =>
                                  setMaterialEditLineId(line.id)
                                }
                              >
                                {matOk ? "Edit" : "Fix"}
                              </button>
                            </div>
                            <div className="mt-1 opacity-90">
                              Need {line.materialNeeded || 0} · On hand{" "}
                              {line.materialOnHand ?? 0}
                              {line.materialLocation
                                ? ` @ ${line.materialLocation}`
                                : ""}
                              {(line.materialNeeded || 0) >
                                (line.materialOnHand || 0) &&
                              line.material ? (
                                <span className="font-semibold">
                                  {" "}
                                  · BUY{" "}
                                  {(line.materialNeeded || 0) -
                                    (line.materialOnHand || 0)}
                                </span>
                              ) : null}
                              {line.finishedOnHand
                                ? ` · Finished: ${line.finishedOnHand}`
                                : ""}
                            </div>
                            {line.attentionReason &&
                              !line.materialReviewed && (
                                <div className="mt-1 font-medium">
                                  {line.attentionReason}
                                </div>
                              )}
                          </div>
                        </div>
                      </td>
                    </tr>
                  ) : null}
                </Fragment>
              );
            })}
          </tbody>
        </table>
        {selected.lines.length === 0 && (
          <p className="text-sm text-[var(--color-muted)] py-6 text-center">
            No line items — add parts from the customer PO.
          </p>
        )}
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 px-4 sm:px-6 py-4 border-t border-[var(--color-border)] print:hidden">
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="secondary" onClick={() => addLine()}>
            <Plus className="h-4 w-4" /> Add line
          </Button>
          <Button size="sm" variant="outline" onClick={checkAllMaterials} type="button">
            <RefreshCw className="h-4 w-4" /> Check materials
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="text-[var(--color-danger)] border-[color-mix(in_oklab,var(--color-danger)_40%,var(--color-border))]"
            type="button"
            onClick={() => setDeleteConfirm(true)}
          >
            <Trash2 className="h-4 w-4" /> Delete PO
          </Button>
        </div>
        {canSeePrices && (
          <div className="text-sm tabular text-[var(--color-muted)]">
            Lines total{" "}
            <span className="font-semibold text-[var(--color-fg)]">
              {formatCurrency(subtotal)}
            </span>
            <span className="text-[10px] ml-1">(office only)</span>
          </div>
        )}
      </div>
      </CardContent>
    </Card>
  )}
  </div>
  );
}
