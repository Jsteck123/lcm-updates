/**
 * 3-way merge so an in-flight checkbox / timer is not wiped when another
 * station (or a stale pull) lands a newer shop rev.
 *
 * base = last snapshot we successfully synced
 * local = this browser's current store (may include unsynced clicks)
 * remote = host snapshot
 */
import type { ShopSharedState } from "./shop-types";
import { mergeChatMessages } from "./chat";
import type { ShopOrder, ShopOrderLine } from "./types";

export function cloneShared(state: ShopSharedState): ShopSharedState {
  return JSON.parse(JSON.stringify(state)) as ShopSharedState;
}

function same(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (a == null && b == null) return true;
  try {
    return JSON.stringify(a) === JSON.stringify(b);
  } catch {
    return false;
  }
}

function isIdRecord(v: unknown): v is { id: string } {
  return Boolean(
    v && typeof v === "object" && typeof (v as { id?: unknown }).id === "string",
  );
}

function asRec(v: unknown): Record<string, unknown> | undefined {
  if (v && typeof v === "object" && !Array.isArray(v)) {
    return v as Record<string, unknown>;
  }
  return undefined;
}

function mergeObj(
  base: Record<string, unknown> | undefined,
  local: Record<string, unknown>,
  remote: Record<string, unknown>,
): Record<string, unknown> {
  if (same(local, remote)) return local;
  if (base && same(local, base)) return remote;
  if (base && same(remote, base)) return local;
  const keys = new Set([
    ...Object.keys(base || {}),
    ...Object.keys(local || {}),
    ...Object.keys(remote || {}),
  ]);
  const out: Record<string, unknown> = { ...remote, ...local };
  for (const k of keys) {
    out[k] = mergeValue(base?.[k], local?.[k], remote?.[k]);
  }
  return out;
}

function mergeValue(base: unknown, local: unknown, remote: unknown): unknown {
  if (same(local, remote)) return local ?? remote;
  if (same(local, base)) return remote;
  if (same(remote, base)) return local;
  if (Array.isArray(local) && Array.isArray(remote)) {
    if (local.every(isIdRecord) && remote.every(isIdRecord)) {
      return mergeById(
        Array.isArray(base) ? (base as { id: string }[]) : [],
        local as { id: string }[],
        remote as { id: string }[],
      );
    }
    return local;
  }
  const lObj = asRec(local);
  const rObj = asRec(remote);
  if (lObj && rObj) {
    return mergeObj(asRec(base), lObj, rObj);
  }
  return local ?? remote;
}

function mergeById<T extends { id: string }>(
  base: T[] | undefined,
  local: T[] | undefined,
  remote: T[] | undefined,
  mergeItem?: (b: T | undefined, l: T, r: T) => T,
): T[] {
  const bMap = new Map((base || []).filter((x) => x?.id).map((x) => [x.id, x]));
  const lMap = new Map((local || []).filter((x) => x?.id).map((x) => [x.id, x]));
  const rMap = new Map((remote || []).filter((x) => x?.id).map((x) => [x.id, x]));
  const order: string[] = [];
  for (const id of rMap.keys()) order.push(id);
  for (const id of lMap.keys()) if (!rMap.has(id)) order.push(id);
  const out: T[] = [];
  for (const id of order) {
    const b = bMap.get(id);
    const l = lMap.get(id);
    const r = rMap.get(id);
    if (l && r) {
      if (same(l, r)) out.push(l);
      else if (b && same(l, b)) out.push(r);
      else if (b && same(r, b)) out.push(l);
      else
        out.push(
          mergeItem ? mergeItem(b, l, r) : (mergeObj(asRec(b), asRec(l)!, asRec(r)!) as unknown as T),
        );
    } else if (l && !r) {
      if (!b || !same(l, b)) out.push(l);
    } else if (!l && r) {
      if (!b || !same(r, b)) out.push(r);
    }
  }
  return out;
}

function mergeRecord<T>(
  base: Record<string, T> | undefined,
  local: Record<string, T> | undefined,
  remote: Record<string, T> | undefined,
): Record<string, T> {
  const b = base || {};
  const l = local || {};
  const r = remote || {};
  const keys = new Set([...Object.keys(b), ...Object.keys(l), ...Object.keys(r)]);
  const out: Record<string, T> = {};
  for (const k of keys) {
    const bv = b[k];
    const lv = l[k];
    const rv = r[k];
    if (lv !== undefined && rv !== undefined) {
      out[k] = mergeValue(bv, lv, rv) as T;
    } else if (lv !== undefined && rv === undefined) {
      if (bv === undefined || !same(lv, bv)) out[k] = lv;
    } else if (lv === undefined && rv !== undefined) {
      if (bv === undefined || !same(rv, bv)) out[k] = rv;
    }
  }
  return out;
}

function mergeLine(
  b: ShopOrderLine | undefined,
  l: ShopOrderLine,
  r: ShopOrderLine,
): ShopOrderLine {
  const merged = mergeObj(asRec(b), asRec(l)!, asRec(r)!) as unknown as ShopOrderLine;
  const comps = mergeById(b?.components || [], l.components || [], r.components || []);
  return { ...merged, components: comps };
}

function mergeOrder(b: ShopOrder | undefined, l: ShopOrder, r: ShopOrder): ShopOrder {
  const merged = mergeObj(asRec(b), asRec(l)!, asRec(r)!) as unknown as ShopOrder;
  return {
    ...merged,
    lines: mergeById(b?.lines || [], l.lines || [], r.lines || [], mergeLine),
  };
}

export function threeWayMergeShop(
  base: ShopSharedState | null,
  local: ShopSharedState,
  remote: ShopSharedState,
): ShopSharedState {
  const b = base || remote;
  return {
    operators: mergeById(b.operators, local.operators, remote.operators),
    customers: mergeById(b.customers, local.customers, remote.customers),
    quotes: mergeById(b.quotes, local.quotes, remote.quotes),
    jobs: mergeById(b.jobs, local.jobs, remote.jobs),
    downtimes: mergeById(b.downtimes, local.downtimes, remote.downtimes),
    operatorTimeLog: mergeById(
      b.operatorTimeLog,
      local.operatorTimeLog,
      remote.operatorTimeLog,
    ),
    auditLog: mergeById(b.auditLog, local.auditLog, remote.auditLog),
    sessions: mergeRecord(b.sessions, local.sessions, remote.sessions),
    activeTimers: mergeRecord(
      b.activeTimers,
      local.activeTimers,
      remote.activeTimers,
    ),
    dayBonuses: mergeById(b.dayBonuses, local.dayBonuses, remote.dayBonuses),
    weeklyPayouts: mergeById(
      b.weeklyPayouts,
      local.weeklyPayouts,
      remote.weeklyPayouts,
    ),
    materialStock: mergeById(
      b.materialStock,
      local.materialStock,
      remote.materialStock,
    ),
    partStock: mergeById(b.partStock, local.partStock, remote.partStock),
    partUnits: mergeById(b.partUnits, local.partUnits, remote.partUnits),
    inventoryTxns: mergeById(
      b.inventoryTxns,
      local.inventoryTxns,
      remote.inventoryTxns,
    ),
    purchaseOrders: mergeById(
      b.purchaseOrders,
      local.purchaseOrders,
      remote.purchaseOrders,
    ),
    vendorRfqs: mergeById(b.vendorRfqs, local.vendorRfqs, remote.vendorRfqs),
    shopOrders: mergeById(
      b.shopOrders,
      local.shopOrders,
      remote.shopOrders,
      mergeOrder,
    ),
    workQueue: mergeById(b.workQueue, local.workQueue, remote.workQueue),
    cutTickets: mergeById(b.cutTickets, local.cutTickets, remote.cutTickets),
    stockPieces: mergeById(b.stockPieces, local.stockPieces, remote.stockPieces),
    quoteHistory: mergeById(
      b.quoteHistory,
      local.quoteHistory,
      remote.quoteHistory,
    ),
    emailLog: mergeById(b.emailLog, local.emailLog, remote.emailLog),
    chatMessages: mergeChatMessages(remote.chatMessages, local.chatMessages),
    shopToolingLogs: mergeById(
      b.shopToolingLogs,
      local.shopToolingLogs,
      remote.shopToolingLogs,
    ),
    settings: mergeObj(
      asRec(b.settings),
      asRec(local.settings)!,
      asRec(remote.settings)!,
    ) as unknown as ShopSharedState["settings"],
  };
}
