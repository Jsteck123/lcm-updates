import type { PageHowToDoc } from "./types";

export const signInHowTo: PageHowToDoc = {
  id: "sign-in",
  path: "/",
  title: "Sign in, Switch user, and the header",
  audience: "all",
  whatThisPageIs:
    "Every station has a person signed in. The left sidebar is the shop map. The top bar is who you are, how the shop is doing this week, whether this PC can save, and whether the host just got a new program. Timers, cuts, chat, and the audit log use the name at the bottom of the sidebar. Shop / operator logins never see customer prices or quote markups. Shop-wide week bonus and a personal Possible today number show when the shop / you are on pace — never a $0 or “no bonus” slap. Office / admin logins still see quote prices and the finalize math.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "One host PC holds the shop book. Every other computer and phone on the shop network opens the same live book. The header pill tells you if this screen is talking to that host and whether this device is unlocked to write.",
        },
        {
          type: "p",
          text: "The sidebar only shows tabs your login is allowed to use. Money tabs — Quoting, Parts & Quotes, Email Quotes, Reports — are admin-only. Assign Queue is also admin-only. If a tab is missing, the office turns it on in Settings → Operators & access.",
        },
        {
          type: "ul",
          items: [
            "Shop / operator — Job Board, machines, saw, inventory, packing. No customer prices. Shop week and your Possible today show when they are real.",
            "Office / admin — everything the floor has, plus Quoting, Parts & Quotes, Email Quotes, Reports, and Settings. Admins always keep Settings and Assign Queue.",
          ],
        },
        {
          type: "note",
          text: "Identity stays on this PC. Shop data is shared. Switching user here does not change who is signed in on the mill PC across the aisle.",
        },
        {
          type: "warn",
          text: "Admins always need a PIN. Shop logins usually do not, unless office set a PIN on that person. Required unlock cannot be dismissed — this device has no shop session until someone unlocks.",
        },
      ],
    },
    {
      title: "Sidebar groups",
      blocks: [
        {
          type: "p",
          text: "Tabs are grouped. Empty groups hide. The company name and Data Management sit at the top; Close menu closes the drawer on a phone.",
        },
        {
          type: "control",
          name: "Floor",
          does: "Dashboard, Shop Floor, Job Board, Active Jobs, Saw / Cut queue, Job History, Feedback. Day-to-day run of the shop. Feedback shows a count badge when tickets are new or looking.",
        },
        {
          type: "control",
          name: "Orders",
          does: "Customer Orders, Assign Queue, Ship Calendar. Work coming in, who runs it, what ships when. Assign Queue is admin-only.",
        },
        {
          type: "control",
          name: "Quote / Buy",
          does: "Quoting, Email Quotes, Parts & Quotes, Inventory / Buy. Quoting, Email Quotes, and Parts & Quotes are money-gated (admin). Inventory / Buy is the rack book — floor can use it if office left the tab on.",
        },
        {
          type: "control",
          name: "Manage",
          does: "Reports and Settings. Both admin-only money / office tabs.",
        },
        {
          type: "control",
          name: "Status colors",
          does: "Same legend on every page. Soft tints mean the same on the board, calendar, inventory, and orders.",
        },
        {
          type: "ul",
          items: [
            "Hold — blocked. Rev or stock not confirmed, paused, or waiting on pack.",
            "Open — available / released / material OK. You can take this job.",
            "Due soon — due within about 2 days.",
            "Overdue — past the due date. These go first unless office says otherwise.",
            "Active — someone has it, a timer is running, or it is packed on the cart.",
            "Ready — next step is waiting (usually pack or ship).",
            "Done — closed.",
            "Problem — out of stock or material short. Do not start until office clears it.",
            "Office — office-only work / note.",
          ],
        },
      ],
    },
    {
      title: "Switch user",
      blocks: [
        {
          type: "control",
          name: "Switch user",
          does: "Label at the bottom of the sidebar. The dropdown under it is every active operator. Admins show (Admin). A shield icon appears when the current person is admin.",
        },
        {
          type: "control",
          name: "Switch signed-in user",
          does: "Pick a name. Same person does nothing. Shop logins with no PIN switch immediately and claim a shop session. Switching to a PIN account (every admin, or an operator office locked) clears the old token and opens Enter PIN.",
        },
        {
          type: "p",
          text: "Under the dropdown the station tells you the lock state:",
        },
        {
          type: "ul",
          items: [
            "Unlocked on this device — PIN account, session claimed. Chat and saves go to the host.",
            "PIN required on this device for chat & saves — signed in as a PIN person but this PC has no token yet.",
            "Open switch — set a PIN in Settings to lock — shop login with no PIN. Anyone can pick this name.",
          ],
        },
      ],
    },
    {
      title: "PIN unlock",
      blocks: [
        {
          type: "p",
          text: "The first time a computer talks to the shop host as a PIN person, it asks you to unlock. After that, this PC can print labels, send chat, and save to the host. Chat and some saves will request the same dialog if the token is gone.",
        },
        {
          type: "control",
          name: "Unlock this device",
          does: "Title when unlock is required (this device has no session). Cannot cancel. Unlocks the pending person so this phone/PC can chat and save to the shop.",
        },
        {
          type: "control",
          name: "Enter PIN",
          does: "Title when you are switching to a PIN account and can still Cancel back to the previous person.",
        },
        {
          type: "control",
          name: "PIN (set in Settings — not your Wi‑Fi password)",
          does: "Numeric PIN office set on that person. Press Enter or Unlock. Wrong PIN stays on the dialog. If the host is unreachable you get a network error — the app will not pretend offline sign-in worked.",
        },
        {
          type: "control",
          name: "Cancel",
          does: "Only when unlock is optional (you were switching users). Required unlock hides Cancel.",
        },
        {
          type: "control",
          name: "Unlock",
          does: "Claims a shop session with that email + PIN. On success: Unlocked · signed in as [name]. Busy label is Checking…",
        },
        {
          type: "control",
          name: "Enter PIN",
          does: "Amber banner button when you are a PIN person and this device has no session. Opens Unlock this device. Chat and saves only work on the host until you enter the PIN.",
        },
        {
          type: "note",
          text: "Operators without a PIN claim a session automatically. You still pick your name so timers and cuts are yours.",
        },
      ],
    },
    {
      title: "Header — who, editor, help, live",
      blocks: [
        {
          type: "control",
          name: "Open menu",
          does: "Hamburger on phones. Opens the sidebar. Close menu / Close overlay closes it.",
        },
        {
          type: "control",
          name: "Back",
          does: "Goes back one screen. If there is no history, goes to Dashboard. Also sits at the bottom of every page for shop gloves.",
        },
        {
          type: "control",
          name: "Shop $ / Today $",
          does: "Header pulse chip (hidden on the smallest phones). Shop week total when the shop has a real week number; otherwise your Possible today if you are on pace; otherwise a short shop line. Never $0. Same math as the dashboard pulse.",
        },
        {
          type: "control",
          name: "Editor",
          does: "Admin-only pill. Turns on Editor mode so you can remove stale jobs from the board and queues. Does not delete customer POs. Lights amber as Editor on.",
        },
        {
          type: "control",
          name: "Editor on",
          does: "Same pill while Editor mode is active. Tap again to turn it off.",
        },
        {
          type: "control",
          name: "Turn off",
          does: "On the amber Editor mode banner. Same as tapping Editor on. Banner text: remove stale jobs from the board and queues. Customer POs are not deleted.",
        },
        {
          type: "control",
          name: "How to use",
          does: "Opens the shop how-to book (/help). Same manuals as How to use this page on each screen.",
        },
        {
          type: "control",
          name: "What’s new",
          does: "Opens the What’s new dialog — version note from the last host install, plus missed updates since you last looked. Tap Got it to mark this version seen on this browser.",
        },
        {
          type: "control",
          name: "Got it",
          does: "Closes What’s new. If you missed more than one note it reads Got it · N notes. Also since last time lists older changelog rows.",
        },
        {
          type: "control",
          name: "Shop live",
          does: "Green pill: connected to the host and this device has a session. Saves go to the shared shop database. Hover shows save # (rev).",
        },
        {
          type: "control",
          name: "Unlock PIN to save",
          does: "Amber pill: host is reachable but this device has no session. You can read. You cannot chat or save until you unlock. On a phone this shortens to PIN.",
        },
        {
          type: "control",
          name: "Shop offline",
          does: "Host not reachable. On a phone this shortens to Off. Connecting… shows while the first check is in flight.",
        },
        {
          type: "control",
          name: "BETA",
          does: "Amber pill when Settings → App mode is Beta. Full shop tools work; bonus Mark paid is practice-only until Production.",
        },
        {
          type: "control",
          name: "Refresh when ready",
          does: "Yellow pulsing pill when the host installed a newer app package than this tab loaded. Finish typing first — forms are saved on this device. Then tap. Reloads this tab only. Shop data stays on the host.",
        },
        {
          type: "control",
          name: "Refresh now",
          does: "Same action on the yellow banner: New app version on the host. Shop data is on the host. Finish typing — this page will not wipe by itself.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Start of shift — get on the right name",
        },
        {
          type: "ol",
          items: [
            "Look at the bottom of the sidebar. If that is not you, open Switch user and pick your name.",
            "If the next person is office / admin (or has a PIN), enter that PIN on Enter PIN / Unlock this device.",
            "Wait for Shop live (or Unlocked on this device). If you see Unlock PIN to save, tap Enter PIN.",
            "Open the tab you need. Missing tab? Ask office to turn it on in Settings → Operators & access.",
          ],
        },
        {
          type: "h",
          text: "Office installed an update",
        },
        {
          type: "ol",
          items: [
            "Finish or save any form you are in the middle of. Running timers are safe.",
            "Tap Refresh when ready (or Refresh now on the banner).",
            "You get the new screens. Jobs and inventory stay. What’s new may open with the host note.",
          ],
        },
        {
          type: "h",
          text: "Clean stale cards without touching POs (admin)",
        },
        {
          type: "ol",
          items: [
            "Tap Editor in the header (or Editor mode on Settings → Update app).",
            "Remove stale jobs from the board / queues where the page offers it.",
            "Tap Turn off or Editor on when you are done. Customer POs are not deleted.",
          ],
        },
      ],
    },
  ],
};

export const shopChatHowTo: PageHowToDoc = {
  id: "shop-chat",
  path: "/",
  title: "Shop Chat",
  audience: "all",
  whatThisPageIs:
    "Bottom-right bubble on every screen. Shop-only — it does not go to the public internet. Shop channel is the floor bullhorn. Pick a name for a direct message. Requires a shop session (PIN unlock on PIN accounts) so messages push to the host. You can still read without unlocking.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "Chat lives on the shop LAN. Everyone signed in on the network can open it. Shop channel messages go to the whole crew. A DM is only you and that person. Opening a thread marks those messages read.",
        },
        {
          type: "p",
          text: "A yellow badge on Chat is unread. You do not have to open chat to see that someone pinged the shop. Header under Shop Chat shows your name and either live on the network or unlock PIN to send.",
        },
        {
          type: "warn",
          text: "If this PC is not unlocked, tap the amber strip, enter the same PIN as Switch user, then send again. Attachments also need a session. Max 5 files per message, 12 MB each.",
        },
      ],
    },
    {
      title: "Open, people, and threads",
      blocks: [
        {
          type: "control",
          name: "Chat",
          does: "Floating button, bottom-right. Opens or closes Shop Chat. Yellow count is unread on threads you have not opened.",
        },
        {
          type: "control",
          name: "Shop Chat",
          does: "Panel title. Close chat (X) closes the panel. Chat stays on this device; history is in the shop book.",
        },
        {
          type: "control",
          name: "Everyone",
          does: "Shop channel. Subtitle: Shop channel. Thread header: Everyone (shop floor + office). Empty state: Ask for tools, share job notes, or ping the whole crew here.",
        },
        {
          type: "control",
          name: "Office / admin",
          does: "Role line under an admin name in the people list. Tap the name for a private thread. Thread header: Chat with [name]. Empty state: Private messages with [name]. Only you two see this.",
        },
        {
          type: "control",
          name: "Shop",
          does: "Role line under a floor operator. Same as above — tap for a DM.",
        },
        {
          type: "p",
          text: "This PC is not unlocked for chat. Tap here, enter your PIN (same as Switch user), then send again. You can still read messages without unlocking. — amber strip at the top of the panel when there is no session.",
        },
      ],
    },
    {
      title: "Compose, attach, send",
      blocks: [
        {
          type: "control",
          name: "Job / machine / tool (optional)",
          does: "Context line stored on the message as Re: …. Use a part #, machine, or tool name so office can find it later.",
        },
        {
          type: "control",
          name: "Attach file",
          does: "Paperclip. PDF, photo, or drawing. Accepts .pdf, .png, .jpg, .jpeg, .webp, .gif, .txt, .csv, .dxf, .dwg. Needs PIN unlock first. Footnote: Paperclip: PDF / photo / drawing · max 5 files · 12 MB each.",
        },
        {
          type: "control",
          name: "Remove attachment",
          does: "X on a pending file chip. Drops that file before send.",
        },
        {
          type: "control",
          name: "Message or attach…",
          does: "Shop-channel box. Unlock PIN to send… when locked. Message [name]… on a DM. Enter sends (Shift+Enter does not). Needs text or at least one file.",
        },
        {
          type: "control",
          name: "Send",
          does: "Pushes the message to the host. If the host asks for a PIN, unlock and send again. Network failure puts your text and files back in the box.",
        },
        {
          type: "p",
          text: "Received files show name and size · tap to preview. Images and PDFs open in the shop preview. Your bubbles say You.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Ask the whole shop for a tool",
        },
        {
          type: "ol",
          items: [
            "Tap Chat. Confirm Everyone / Shop channel is selected.",
            "Optional: type the machine or job in Job / machine / tool (optional).",
            "Type the ask. Attach a photo of the tool crib or the print if it helps.",
            "If the box says Unlock PIN to send…, tap the amber strip, enter PIN, then Send.",
          ],
        },
        {
          type: "h",
          text: "Ping office only",
        },
        {
          type: "ol",
          items: [
            "Open Chat. Tap the office name (Office / admin).",
            "Type the question. Attach the drawing or PO page.",
            "Send. Only you and that person see it.",
          ],
        },
        {
          type: "note",
          text: "Chat is not a substitute for a job note on the machine or a Feedback ticket. Use Notes on the job for things that must ride with the part. Use Feedback when something in the system is broken.",
        },
      ],
    },
  ],
};
