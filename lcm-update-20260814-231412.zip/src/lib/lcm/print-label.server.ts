/**
 * Print a stock-label PNG on the Windows shop PC's Brother QL-810W.
 * Uses the printer's own driver — not Edge's paper list.
 */
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

function runPs(command: string, timeoutMs = 25000): {
  ok: boolean;
  stdout: string;
  stderr: string;
} {
  const r = spawnSync(
    "powershell.exe",
    ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", command],
    { encoding: "utf8", timeout: timeoutMs, windowsHide: true },
  );
  return {
    ok: r.status === 0,
    stdout: String(r.stdout || "").trim(),
    stderr: String(r.stderr || r.error?.message || "").trim(),
  };
}

export function listWindowsPrinters(): string[] {
  if (process.platform !== "win32") return [];
  const r = runPs(
    "Get-Printer | ForEach-Object { $_.Name }",
    12000,
  );
  if (!r.ok) return [];
  return r.stdout
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter(Boolean);
}

export function pickQlPrinter(names: string[]): string | null {
  const ql810 = names.find((n) => /QL-?810/i.test(n));
  if (ql810) return ql810;
  const ql = names.find((n) => /Brother/i.test(n) && /QL/i.test(n));
  if (ql) return ql;
  return names.find((n) => /Brother/i.test(n)) || null;
}

function psScript(): string {
  return `
param([string]$PngPath, [string]$PrinterName)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$img = [System.Drawing.Image]::FromFile((Resolve-Path $PngPath))
try {
  $doc = New-Object System.Drawing.Printing.PrintDocument
  $doc.PrinterSettings.PrinterName = $PrinterName
  if (-not $doc.PrinterSettings.IsValid) { throw "Printer not valid: $PrinterName" }
  $doc.DocumentName = 'LCM label'
  $doc.DefaultPageSettings.Margins = New-Object System.Drawing.Printing.Margins 0,0,0,0
  $doc.OriginAtMargins = $true
  $paper = New-Object System.Drawing.Printing.PaperSize 'LCM-110x60', 110, 60
  $doc.DefaultPageSettings.PaperSize = $paper
  $doc.DefaultPageSettings.Landscape = $true
  $doc.add_PrintPage({
    param($s, $e)
    $e.Graphics.PageUnit = [System.Drawing.GraphicsUnit]::Pixel
    $dest = $e.PageBounds
    if ($dest.Width -lt 2 -or $dest.Height -lt 2) { $dest = $e.MarginBounds }
    $e.Graphics.DrawImage($img, $dest)
    $e.HasMorePages = $false
  })
  $doc.Print()
  $doc.Dispose()
} finally {
  $img.Dispose()
}
Write-Output 'printed'
`.trim();
}

export function printPngOnQl(pngBase64: string):
  | { ok: true; printer: string }
  | { ok: false; error: string; printers?: string[] } {
  if (process.platform !== "win32") {
    return {
      ok: false,
      error:
        "Open LCM on the shop PC next to the QL-810W. This computer is not that host.",
    };
  }
  const names = listWindowsPrinters();
  const printer = pickQlPrinter(names);
  if (!printer) {
    return {
      ok: false,
      error:
        names.length === 0
          ? "Windows did not list any printers. Install the Brother QL-810W driver on this PC."
          : "No Brother QL printer found. Printers on this PC: " + names.join(", "),
      printers: names,
    };
  }
  const raw = String(pngBase64 || "").replace(/^data:image\/png;base64,/, "");
  if (!raw || raw.length < 80) {
    return { ok: false, error: "Label image was empty." };
  }
  let buf: Buffer;
  try {
    buf = Buffer.from(raw, "base64");
  } catch {
    return { ok: false, error: "Label image was not valid." };
  }
  if (buf.length < 80 || buf[0] !== 0x89 || buf[1] !== 0x50) {
    return { ok: false, error: "Label image was not a PNG." };
  }
  const dir = path.join(os.tmpdir(), "lcm-labels");
  fs.mkdirSync(dir, { recursive: true });
  const stamp = Date.now();
  const pngPath = path.join(dir, `label-${stamp}.png`);
  const psPath = path.join(dir, `print-${stamp}.ps1`);
  fs.writeFileSync(pngPath, buf);
  fs.writeFileSync(psPath, psScript(), "utf8");
  const r = spawnSync(
    "powershell.exe",
    [
      "-NoProfile",
      "-NonInteractive",
      "-ExecutionPolicy",
      "Bypass",
      "-File",
      psPath,
      "-PngPath",
      pngPath,
      "-PrinterName",
      printer,
    ],
    { encoding: "utf8", timeout: 40000, windowsHide: true },
  );
  const stderr = String(r.stderr || r.error?.message || "").trim();
  const stdout = String(r.stdout || "").trim();
  if (r.status !== 0 || !/printed/i.test(stdout)) {
    const paint = spawnSync("mspaint.exe", ["/pt", pngPath, printer], {
      encoding: "utf8",
      timeout: 40000,
      windowsHide: true,
    });
    if (paint.status === 0) {
      return { ok: true, printer };
    }
    return {
      ok: false,
      error:
        stderr ||
        stdout ||
        paint.stderr ||
        "Windows refused the print job. Check the QL-810W is online.",
      printers: names,
    };
  }
  return { ok: true, printer };
}
