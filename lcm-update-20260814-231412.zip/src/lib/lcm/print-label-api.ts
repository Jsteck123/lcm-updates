import { createServerFn } from "@tanstack/react-start";

export const listShopLabelPrinters = createServerFn({ method: "POST" })
  .validator((data: { token?: string } = {}) => data ?? {})
  .handler(async ({ data }) => {
    const { verifyShopToken } = await import("./shop-session.server");
    if (!verifyShopToken(data?.token)) {
      return { ok: false as const, error: "Unlock this PC first." };
    }
    const { listWindowsPrinters, pickQlPrinter } = await import(
      "./print-label.server"
    );
    const printers = listWindowsPrinters();
    return {
      ok: true as const,
      printers,
      ql: pickQlPrinter(printers),
      windows: process.platform === "win32",
    };
  });

export const printLabelOnShopHost = createServerFn({ method: "POST" })
  .validator((data: { token?: string; pngBase64: string }) => data)
  .handler(async ({ data }) => {
    const { verifyShopToken } = await import("./shop-session.server");
    if (!verifyShopToken(data.token)) {
      return { ok: false as const, error: "Unlock this PC first (Switch user / PIN)." };
    }
    const { printPngOnQl } = await import("./print-label.server");
    return printPngOnQl(data.pngBase64 || "");
  });
