import { useEffect, useRef, useState } from "react";
import { loadDrawingPreview } from "@/lib/lcm/drawing-preview";

/** Faded part drawing behind a job-board card. Does not capture clicks. */
export function BoardCardArt({
  fileId,
  name,
}: {
  fileId: string;
  name?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [src, setSrc] = useState("");

  useEffect(() => {
    const el = ref.current;
    if (!el || !fileId) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) setVisible(true);
      },
      { rootMargin: "120px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [fileId]);

  useEffect(() => {
    if (!visible || !fileId) return;
    let cancelled = false;
    void loadDrawingPreview(fileId, name).then((url) => {
      if (!cancelled && url) setSrc(url);
    });
    return () => {
      cancelled = true;
    };
  }, [visible, fileId, name]);

  if (!fileId) return null;

  return (
    <div
      ref={ref}
      className="board-card-art print:hidden"
      aria-hidden
    >
      {src ? <img src={src} alt="" /> : null}
    </div>
  );
}
