import { attachmentHttpUrl } from "./open-attachment";
import { getShopToken } from "./shop-sync";

const cache = new Map<string, Promise<string | null>>();

function looksLikeImage(name: string, mime: string) {
  const n = (name || "").toLowerCase();
  const m = (mime || "").toLowerCase();
  return (
    m.startsWith("image/") ||
    /\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(n)
  );
}

function looksLikePdf(name: string, mime: string) {
  const n = (name || "").toLowerCase();
  const m = (mime || "").toLowerCase();
  return m.includes("pdf") || n.endsWith(".pdf");
}

async function rasterizePdfFirstPage(data: ArrayBuffer): Promise<string | null> {
  const pdfjs = await import("pdfjs-dist");
  try {
    const worker = await import("pdfjs-dist/build/pdf.worker.min.mjs?url");
    pdfjs.GlobalWorkerOptions.workerSrc = worker.default as string;
  } catch {
    /* worker optional */
  }
  const doc = await pdfjs.getDocument({ data }).promise;
  const page = await doc.getPage(1);
  const base = page.getViewport({ scale: 1 });
  const scale = Math.min(1.35, 420 / Math.max(1, base.width));
  const viewport = page.getViewport({ scale });
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.floor(viewport.width));
  canvas.height = Math.max(1, Math.floor(viewport.height));
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;
  await page.render({ canvasContext: ctx, viewport, canvas }).promise;
  return canvas.toDataURL("image/jpeg", 0.58);
}

async function resolveDrawingPreview(
  id: string,
  name: string,
): Promise<string | null> {
  const url = attachmentHttpUrl(id);
  if (looksLikeImage(name, "") && !looksLikePdf(name, "")) return url;
  const token = getShopToken();
  const res = await fetch(url, {
    headers: token ? { "x-lcm-shop-token": token } : undefined,
  });
  if (!res.ok) return null;
  const mime = res.headers.get("content-type") || "";
  if (looksLikeImage(name, mime)) {
    const blob = await res.blob();
    return URL.createObjectURL(blob);
  }
  if (looksLikePdf(name, mime)) {
    const buf = await res.arrayBuffer();
    return rasterizePdfFirstPage(buf);
  }
  return null;
}

/** Cached preview URL for a PO drawing (photo or first PDF page). */
export function loadDrawingPreview(
  id: string,
  name?: string,
): Promise<string | null> {
  const key = (id || "").trim();
  if (!key) return Promise.resolve(null);
  const hit = cache.get(key);
  if (hit) return hit;
  const p = resolveDrawingPreview(key, name || "").catch(() => null);
  cache.set(key, p);
  return p;
}
