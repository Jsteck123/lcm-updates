import { Label } from "@/components/ui/input";
import { CreatableSelect } from "@/components/ui/creatable-select";
import { SmartNumberInput } from "@/components/ui/smart-number-input";
import type { LocAxis } from "@/lib/lcm/types";
import {
  axisLabels,
  canonicalizeShape,
  defaultLocAxis,
  describeStock,
  locChoices,
  locValue,
} from "@/lib/lcm/stock-standard";
import { isSheetOrPlate } from "@/lib/lcm/stock-shapes";
import { cn } from "@/lib/utils";

export type GuidedStockValue = {
  stockShape: string;
  dimX: number;
  dimY: number;
  dimZ: number;
  locAxis: LocAxis | "";
  rawMaterialLength: number;
  partLengthEach: number;
};

export function GuidedStockFields({
  value,
  onChange,
  shapeOptions,
  onCreateShape,
}: {
  value: GuidedStockValue;
  onChange: (next: GuidedStockValue) => void;
  shapeOptions: string[];
  onCreateShape?: (name: string) => boolean | void;
}) {
  const shape = canonicalizeShape(value.stockShape);
  const labels = axisLabels(shape);
  const loc = (value.locAxis || defaultLocAxis(shape)) as LocAxis;
  const sheet = isSheetOrPlate(shape);
  const locIn = locValue(loc, value);

  function patch(p: Partial<GuidedStockValue>) {
    const next = { ...value, ...p };
    if (p.stockShape != null) {
      const s = canonicalizeShape(p.stockShape);
      next.stockShape = s;
      if (!next.locAxis) next.locAxis = defaultLocAxis(s);
    }
    if (
      (p.locAxis || p.dimX != null || p.dimY != null || p.dimZ != null) &&
      !next.partLengthEach
    ) {
      const axis = (next.locAxis || loc) as LocAxis;
      const v = locValue(axis, next);
      if (v > 0) next.partLengthEach = v;
    }
    onChange(next);
  }

  return (
    <div className="space-y-3">
      <div className="space-y-1.5">
        <Label>Stock shape</Label>
        <CreatableSelect
          value={shape}
          options={shapeOptions}
          onChange={(v) => patch({ stockShape: v })}
          onCreate={(v) => {
            const ok = onCreateShape?.(v);
            if (ok === false) return false;
            patch({ stockShape: v });
            return true;
          }}
          createTitle="Add shape"
        />
      </div>

      <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-3 space-y-2">
        <div className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]">
          Size in the machine
        </div>
        <p className="text-[11px] text-[var(--color-muted)] leading-snug">
          X Y Z is the <strong className="text-[var(--color-fg)]">stock</strong>{" "}
          as it sits in the mill or lathe — not the finished model. If a stock
          face is a model surface, do not pick that axis as the saw cut.
        </p>
        <div className="grid grid-cols-3 gap-2">
          {(["x", "y", "z"] as const).map((axis) => {
            const key = axis === "x" ? "dimX" : axis === "y" ? "dimY" : "dimZ";
            const isLoc = loc === axis;
            return (
              <div key={axis} className="space-y-1">
                <Label className="text-[10px] leading-tight">{labels[axis]}</Label>
                <SmartNumberInput
                  format="inches"
                  value={Number(value[key]) || 0}
                  placeholder="—"
                  className={cn(isLoc && "ring-1 ring-[var(--color-primary)]")}
                  onValueChange={(n) => patch({ [key]: n })}
                />
              </div>
            );
          })}
        </div>
      </div>

      <div className="space-y-1.5">
        <Label>Length of cut (LOC)</Label>
        <div className="grid gap-1.5">
          {locChoices(shape).map((c) => (
            <label
              key={c.axis}
              className={cn(
                "flex items-start gap-2 rounded-[var(--radius-md)] border px-2.5 py-2 text-sm min-h-11 cursor-pointer",
                loc === c.axis
                  ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_10%,transparent)]"
                  : "border-[var(--color-border)]",
              )}
            >
              <input
                type="radio"
                className="mt-1"
                name="lcm-loc"
                checked={loc === c.axis}
                onChange={() => {
                  const nextLen = locValue(c.axis, value);
                  patch({
                    locAxis: c.axis,
                    partLengthEach: nextLen || value.partLengthEach,
                  });
                }}
              />
              <span>{c.label}</span>
            </label>
          ))}
        </div>
        {loc && loc !== "dia" && locIn > 0 && (
          <p className="text-[11px] text-[var(--color-muted)]">
            Saw takes{" "}
            <span className="font-mono text-[var(--color-fg)]">{locIn}"</span>{" "}
            on {loc.toUpperCase()}. The other faces stay stock.
          </p>
        )}
      </div>

      {!sheet && (
        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1">
            <Label className="text-[10px]">Stock used per part (")</Label>
            <SmartNumberInput
              format="inches"
              value={value.partLengthEach || 0}
              placeholder={locIn ? String(locIn) : "cut + drop"}
              onValueChange={(partLengthEach) => patch({ partLengthEach })}
            />
          </div>
          <div className="space-y-1">
            <Label className="text-[10px]">Full bar on the rack (")</Label>
            <SmartNumberInput
              format="inches"
              value={value.rawMaterialLength || 0}
              placeholder="144"
              onValueChange={(rawMaterialLength) =>
                patch({ rawMaterialLength })
              }
            />
          </div>
        </div>
      )}

      <p className="text-xs rounded-[var(--radius-md)] border border-[var(--color-border)] px-2.5 py-2">
        {describeStock({ ...value, locAxis: loc }) ||
          "Pick a shape and sizes."}
      </p>
    </div>
  );
}
