/**
 * One shop language for stock.
 *
 * X Y Z = the blank sitting in the machine (not the finished model).
 * LOC   = which of those faces the saw cuts.
 * The other faces stay mill/lathe stock (may be a model surface — do not saw them).
 */
import type { LocAxis, ShopOrder, ShopOrderLine } from "./types";
import { profileForShape, isSheetOrPlate } from "./stock-shapes";

const SHAPE_ALIASES: Record<string, string> = {
  rd: "Round Stock",
  round: "Round Stock",
  "round stock": "Round Stock",
  "round bar": "Round Stock",
  bar: "Round Stock",
  "bar stock": "Round Stock",
  hex: "Hex Stock",
  "hex stock": "Hex Stock",
  sq: "Square Stock",
  square: "Square Stock",
  "square stock": "Square Stock",
  rect: "Rectangular Stock",
  rectangle: "Rectangular Stock",
  "rectangle stock": "Rectangular Stock",
  "rectangular stock": "Rectangular Stock",
  flat: "Flat Bar",
  "flat bar": "Flat Bar",
  "flat stock": "Flat Bar",
  plate: "Plate",
  sheet: "Flat Sheet",
  "flat sheet": "Flat Sheet",
  "cast plate": "Cast Plate",
  tube: "Round Tube",
  "round tube": "Round Tube",
  "square tube": "Square Tube",
  pipe: "Pipe",
  angle: "Angle Stock",
  "angle stock": "Angle Stock",
  channel: "Channel",
};

const PLACEHOLDER = new Set([
  "",
  "material shape",
  "material type",
  "rd/sq/ang stock",
  "rd sq ang stock",
  "stock shape",
  "shape",
  "n/a",
  "na",
  "none",
  "-",
  "select",
]);

export function isPlaceholderShape(raw: string): boolean {
  return PLACEHOLDER.has((raw || "").trim().toLowerCase());
}

/** Map old / shorthand names onto the dropdown list. Blank stays blank. */
export function canonicalizeShape(raw: string): string {
  const s = (raw || "").trim();
  if (isPlaceholderShape(s)) return "";
  const hit = SHAPE_ALIASES[s.toLowerCase()];
  return hit || s;
}

export function guessShapeFromDims(opts: {
  dimX: number;
  dimY: number;
  dimZ: number;
  machines?: string[];
}): string {
  const x = Number(opts.dimX) || 0;
  const y = Number(opts.dimY) || 0;
  const z = Number(opts.dimZ) || 0;
  const millish = (opts.machines || []).some((m) =>
    /mill|vf|vm|umc|dt|dmtg/i.test(m),
  );
  const latheish = (opts.machines || []).some((m) =>
    /lathe|sl-|st-|ds\d|tl-/i.test(m),
  );
  if (latheish && !millish) return "Round Stock";
  if (x > 0 && !(y > 0)) return "Round Stock";
  if (x > 0 && y > 0 && Math.abs(x - y) < 0.02) return "Square Stock";
  if (z > 0 && z < 1 && (x >= 6 || y >= 6)) return "Plate";
  if (x > 0 && y > 0) return "Rectangular Stock";
  return "";
}

export type AxisKey = "x" | "y" | "z";

export function axisLabels(shape: string): Record<AxisKey, string> {
  const id = profileForShape(shape).id;
  if (id === "round" || id === "hex") {
    return {
      x: id === "hex" ? "X · across flats" : "X · diameter",
      y: "Y · (not used)",
      z: "Z · length in the machine",
    };
  }
  if (id === "sheet") {
    return {
      x: "X · width in the machine",
      y: "Y · length in the machine",
      z: "Z · thickness",
    };
  }
  return {
    x: "X · as it sits in the machine",
    y: "Y · as it sits in the machine",
    z: "Z · as it sits in the machine",
  };
}

export function defaultLocAxis(shape: string): LocAxis {
  const id = profileForShape(shape).id;
  if (id === "round" || id === "hex" || id === "round-tube" || id === "pipe")
    return "z";
  if (id === "sheet") return "x";
  return "z";
}

export function locChoices(shape: string): { axis: LocAxis; label: string }[] {
  const id = profileForShape(shape).id;
  if (id === "round" || id === "hex") {
    return [
      { axis: "z", label: "Z · saw to length (diameter stays stock)" },
      { axis: "dia", label: "No saw — use bar as-is" },
    ];
  }
  return [
    { axis: "x", label: "X · saw this face" },
    { axis: "y", label: "Y · saw this face" },
    { axis: "z", label: "Z · saw this face" },
  ];
}

export function locValue(
  axis: LocAxis | "",
  dims: { dimX: number; dimY: number; dimZ: number },
): number {
  if (axis === "x") return Number(dims.dimX) || 0;
  if (axis === "y") return Number(dims.dimY) || 0;
  if (axis === "z") return Number(dims.dimZ) || 0;
  return 0;
}

export function describeStock(opts: {
  stockShape: string;
  dimX: number;
  dimY: number;
  dimZ: number;
  locAxis?: LocAxis | "";
}): string {
  const shape = canonicalizeShape(opts.stockShape) || "stock";
  const x = Number(opts.dimX) || 0;
  const y = Number(opts.dimY) || 0;
  const z = Number(opts.dimZ) || 0;
  const id = profileForShape(shape).id;
  let size = "";
  if (id === "round" || id === "hex") {
    size = x ? `${x}" ${id === "hex" ? "AF" : "Ø"}` : "";
    if (z) size += size ? ` × ${z}" long` : `${z}" long`;
  } else {
    size = [x, y, z].filter((n) => n > 0).map((n) => `${n}"`).join(" × ");
  }
  const loc = opts.locAxis || "";
  const locBit =
    loc && loc !== "dia"
      ? ` Saw cuts ${loc.toUpperCase()} — other faces stay stock.`
      : loc === "dia"
        ? " No saw cut — use as-is."
        : "";
  return [shape, size].filter(Boolean).join(" · ") + locBit;
}

export function findShopLineForPart(
  orders: ShopOrder[],
  partNumber: string,
  revision?: string,
): { orderId: string; line: ShopOrderLine } | null {
  const pn = (partNumber || "").trim().toUpperCase();
  if (!pn) return null;
  const rev = (revision || "").trim().toUpperCase();
  let loose: { orderId: string; line: ShopOrderLine } | null = null;
  for (const o of orders || []) {
    for (const line of o.lines || []) {
      if ((line.partNumber || "").trim().toUpperCase() !== pn) continue;
      if (rev && (line.revision || "").trim().toUpperCase() === rev) {
        return { orderId: o.id, line };
      }
      if (!loose) loose = { orderId: o.id, line };
    }
  }
  return loose;
}

export { isSheetOrPlate };
