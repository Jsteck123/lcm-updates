import type { PageHowToDoc } from "./types";

export const packingTableHowTo: PageHowToDoc = {
  id: "packing-table",
  path: "/pack",
  title: "Packing Table",
  tab: "pack",
  whatThisPageIs:
    "The packer’s cut-queue. Every job marked ready for pack sits here as a PO card with its line items and a drawing picture. Pack the parts, tap Packed — the 1.1×2 box label prints (customer, PO, part, rev, qty, QR on the left). Stick it on the box. The line leaves this queue. Pam scans the QR to check the box onto the truck.",
  sections: [
    {
      title: "How this page works",
      blocks: [
        {
          type: "p",
          text: "Soonest due first. One card per PO that has something on the table. Lines that are already packed or not ready for pack do not show. After Packed, Ship Calendar still has the order for office verify / Friday run. The QR is Pam’s truck scan — not this page.",
        },
        {
          type: "ul",
          items: [
            "Picture is the line drawing. Tap it to open the print.",
            "Packed uses the same box label as Ship Calendar Mark packed.",
            "Reset pack on the calendar puts a line back on this table.",
          ],
        },
      ],
    },
    {
      title: "Page chrome",
      blocks: [
        {
          type: "control",
          name: "Packing Table",
          does: "Page title. Subtitle: pack, print the box label, stick it on. Pam scans the QR to load the truck.",
        },
        {
          type: "control",
          name: "N orders on the table",
          does: "How many POs have at least one unpacked ready line, plus how many lines are waiting.",
        },
      ],
    },
    {
      title: "Order card",
      blocks: [
        {
          type: "control",
          name: "PO #",
          does: "Customer PO. Due date is the PO calendar day. Open full PO jumps to Customer Orders on this order.",
        },
        {
          type: "control",
          name: "Line row",
          does: "Drawing thumb, part #, rev, description, qty, who marked ready. Packed prints the box label and removes the row.",
        },
        {
          type: "control",
          name: "Packed",
          does: "Marks the line packed, prints the 1.1×2 label (QR left, text right). Needs PIN if this PC is locked. Same printer as inventory.",
        },
      ],
    },
    {
      title: "Workflows",
      blocks: [
        {
          type: "h",
          text: "Pack a job",
        },
        {
          type: "ol",
          items: [
            "Open Packing Table. Find the PO.",
            "Match the picture and part # to the parts on the table.",
            "Put them in the box. Tap Packed.",
            "Stick the label on the box.",
            "The line leaves the queue. Leave the box for Pam’s truck scan.",
          ],
        },
      ],
    },
  ],
};
