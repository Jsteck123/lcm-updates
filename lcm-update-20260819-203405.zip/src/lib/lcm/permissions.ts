import type { AppTab, Operator } from "./types";

export const APP_TABS = [
  { id: "dashboard" as const, label: "Dashboard", path: "/" },
  { id: "machines" as const, label: "Shop Floor", path: "/machines" },
  { id: "jobs" as const, label: "Job History", path: "/jobs" },
  { id: "quoting" as const, label: "Quoting", path: "/quoting" },
  { id: "database" as const, label: "Parts & Quotes", path: "/database" },
  { id: "inventory" as const, label: "Inventory / Buy", path: "/inventory" },
  { id: "po" as const, label: "Customer Orders", path: "/po" },
  { id: "assign" as const, label: "Assign Queue", path: "/assign" },
  { id: "lanes" as const, label: "Load Lanes", path: "/lanes" },
  { id: "calendar" as const, label: "Ship Calendar", path: "/calendar" },
  { id: "board" as const, label: "Job Board", path: "/board" },
  { id: "active" as const, label: "Active Jobs", path: "/active" },
  { id: "saw" as const, label: "Saw / Cut queue", path: "/saw" },
  { id: "pack" as const, label: "Packing Table", path: "/pack" },
  { id: "feedback" as const, label: "Feedback", path: "/feedback" },
  { id: "email" as const, label: "Email Quotes", path: "/email" },
  { id: "reports" as const, label: "Reports", path: "/reports" },
  { id: "settings" as const, label: "Settings", path: "/settings" },
] as const;

export type AppTabId = (typeof APP_TABS)[number]["id"];

/** Tabs that always expose customer $ / shop cost — operators cannot open these. */
export const MONEY_TABS: AppTab[] = [
  "quoting",
  "database",
  "email",
  "reports",
];

export function isMoneyTab(tab: AppTab | null | undefined): boolean {
  return !!tab && (MONEY_TABS as readonly string[]).includes(tab);
}

/** Dollar amounts, prices, and bonus $ — admin only. */
export function canSeeMoney(op: Operator | undefined): boolean {
  return op?.role === "admin";
}

/** Default tabs for shop-floor operators (starting set only — fully editable in Settings) */
export const DEFAULT_OPERATOR_TABS: AppTab[] = [
  "dashboard",
  "machines",
  "jobs",
  "po",
  "calendar",
  "board",
  "active",
  "saw",
  "pack",
  "feedback",
  "inventory",
];

/** Full access */
export const ALL_TABS: AppTab[] = APP_TABS.map((t) => t.id);

/** Default admin PIN used in seed / migration when none set */
export const DEFAULT_ADMIN_PIN = "6283";

export function normalizeOperator(
  op: Partial<Operator> & Pick<Operator, "id" | "name" | "email">,
): Operator {
  const role = op.role === "admin" ? "admin" : "operator";

  // Respect explicit tab lists from Settings. Only fall back to defaults when
  // tabs is missing/undefined (legacy records) — never re-force tabs the admin
  // unchecked (Customer Orders, Ship Calendar, Job Board used to snap back on).
  let tabs: AppTab[];
  if (Array.isArray(op.tabs)) {
    tabs = op.tabs.filter((t) => ALL_TABS.includes(t as AppTab)) as AppTab[];
  } else if (role === "admin") {
    tabs = [...ALL_TABS];
  } else {
    tabs = [...DEFAULT_OPERATOR_TABS];
  }

  if (role === "operator") {
    tabs = tabs.filter((t) => !MONEY_TABS.includes(t));
  }

  // Admins always keep Settings so they cannot lock themselves out of access control
  if (role === "admin" && !tabs.includes("settings")) {
    tabs = [...tabs, "settings"];
  }
  if (role === "admin" && !tabs.includes("assign")) {
    tabs = [...tabs, "assign"];
  }
  if (role === "admin" && !tabs.includes("lanes")) {
    tabs = [...tabs, "lanes"];
  }

  // Roll-out channel — everyone can report bugs / ideas
  if (!tabs.includes("feedback")) {
    tabs = [...tabs, "feedback"];
  }

  // Packing table sits next to the saw. Give it to anyone who already has floor / ship tabs.
  if (
    !tabs.includes("pack") &&
    (tabs.includes("saw") ||
      tabs.includes("calendar") ||
      tabs.includes("board") ||
      tabs.includes("po"))
  ) {
    const i = tabs.indexOf("saw");
    tabs =
      i >= 0
        ? [...tabs.slice(0, i + 1), "pack", ...tabs.slice(i + 1)]
        : [...tabs, "pack"];
  }

  // Empty list would strand the person with no nav — keep Dashboard as a floor
  if (tabs.length === 0) {
    tabs = ["dashboard"];
  }

  let pin = typeof op.pin === "string" ? op.pin : "";
  // Do not inject default plaintext PIN here — seed/migration sets it once,
  // then it is hashed on the server. Preserve hasPin if present.
  const hasPin =
    typeof (op as Operator).hasPin === "boolean"
      ? (op as Operator).hasPin
      : Boolean(pin.trim() && pin.trim() !== "••••");

  return {
    id: op.id,
    name: op.name,
    email: op.email,
    active: op.active !== false,
    role,
    tabs: [...new Set(tabs)],
    pin: pin.trim(),
    hasPin,
  };
}

export function requiresPinToSwitch(op: Operator | undefined): boolean {
  if (!op) return true;
  if (op.role === "admin") return true;
  // hasPin is set after server strip; pin may be masked "••••"
  if (op.hasPin === true) return true;
  if (op.hasPin === false) return false;
  const pin = (op.pin || "").trim();
  return Boolean(pin && pin !== "••••");
}

/**
 * @deprecated Client-side PIN check is insecure — use claimShopSession.
 * Kept for offline fallback only (legacy plaintext still in localStorage).
 */
export function verifyOperatorPin(op: Operator | undefined, pin: string): boolean {
  if (!op) return false;
  if (!requiresPinToSwitch(op)) return true;
  const stored = (op.pin || "").trim();
  if (!stored || stored === "••••") return false;
  // Never compare against hashed secrets on the client
  if (stored.startsWith("v1$")) return false;
  return stored === pin.trim();
}

export function pathToTab(pathname: string | null | undefined): AppTab | null {
  const path = typeof pathname === "string" ? pathname : "";
  if (!path || path === "/") return "dashboard";
  if (path.startsWith("/machines")) return "machines";
  if (path.startsWith("/jobs")) return "jobs";
  if (path.startsWith("/quoting")) return "quoting";
  if (path.startsWith("/database")) return "database";
  if (path.startsWith("/inventory")) return "inventory";
  if (path.startsWith("/scan") || path.startsWith("/labels") || path.startsWith("/box"))
    return "inventory";
  if (path.startsWith("/po")) return "po";
  if (path.startsWith("/assign")) return "assign";
  if (path.startsWith("/lanes")) return "lanes";
  if (path.startsWith("/calendar")) return "calendar";
  if (path.startsWith("/board")) return "board";
  if (path.startsWith("/active")) return "active";
  if (path.startsWith("/saw")) return "saw";
  if (path.startsWith("/pack")) return "pack";
  if (path.startsWith("/feedback")) return "feedback";
  if (path.startsWith("/email")) return "email";
  if (path.startsWith("/reports")) return "reports";
  if (path.startsWith("/settings") || path.startsWith("/cleanup") || path.startsWith("/recover"))
    return "settings";
  return null;
}

export function operatorCanAccessTab(
  op: Operator | undefined,
  tab: AppTab | null,
): boolean {
  if (!tab) return true;
  if (!op) return false;
  if (isMoneyTab(tab) && op.role !== "admin") return false;
  if (tab === "assign" || tab === "lanes") return op.role === "admin";
  if (tab === "active") {
    return (
      op.tabs.includes("active") ||
      op.tabs.includes("machines") ||
      op.tabs.includes("board")
    );
  }
  return op.tabs.includes(tab);
}

export function firstAllowedPath(op: Operator | undefined): string {
  if (!op) return "/";
  for (const t of APP_TABS) {
    if (operatorCanAccessTab(op, t.id)) return t.path;
  }
  return "/";
}

export function getOperatorByEmail(
  operators: Operator[],
  email: string,
): Operator | undefined {
  const e = email.trim().toLowerCase();
  return operators.find((o) => o.email.toLowerCase() === e);
}
