/**
 * Packing table: PO lines office/floor marked ready for pack, not yet boxed.
 */
import type { LineFileRef, ShopOrder } from "./types";
import { lineDrawings } from "./line-files";
import { lineShipDate } from "./shipping-calendar";

export type PackTableLine = {
  orderId: string;
  lineId: string;
  poNumber: string;
  customer: string;
  partNumber: string;
  revision: string;
  description: string;
  qty: number;
  dueDate: string;
  readyForPackBy: string;
  drawings: LineFileRef[];
};

export type PackTableOrder = {
  orderId: string;
  poNumber: string;
  customer: string;
  dueDate: string;
  lines: PackTableLine[];
};

export function packingTableOrders(orders: ShopOrder[]): PackTableOrder[] {
  const out: PackTableOrder[] = [];
  for (const order of orders || []) {
    if (order.status === "cancelled" || order.deliveredAt) continue;
    const lines: PackTableLine[] = [];
    for (const line of order.lines || []) {
      if (line.lineStatus === "cancelled") continue;
      if (!line.readyForPack || line.linePacked) continue;
      lines.push({
        orderId: order.id,
        lineId: line.id,
        poNumber: order.poNumber || "(no PO)",
        customer: order.customer || "",
        partNumber: line.partNumber || "",
        revision: line.revision || "",
        description: line.description || "",
        qty: Number(line.qty) || 0,
        dueDate: lineShipDate(order, line),
        readyForPackBy: line.readyForPackBy || "",
        drawings: lineDrawings(line),
      });
    }
    if (!lines.length) continue;
    const due =
      lines.map((l) => l.dueDate).filter(Boolean).sort()[0] || "";
    out.push({
      orderId: order.id,
      poNumber: order.poNumber || "(no PO)",
      customer: order.customer || "",
      dueDate: due,
      lines,
    });
  }
  out.sort((a, b) => {
    const da = a.dueDate || "9999-12-31";
    const db = b.dueDate || "9999-12-31";
    if (da !== db) return da.localeCompare(db);
    return a.poNumber.localeCompare(b.poNumber);
  });
  return out;
}

export function packingTableLineCount(groups: PackTableOrder[]): number {
  return groups.reduce((n, g) => n + g.lines.length, 0);
}
