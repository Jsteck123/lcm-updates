import { createFileRoute, Link } from "@tanstack/react-router";
import { Package, Printer } from "lucide-react";
import { toast } from "sonner";
import { useMemo } from "react";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { PageHowTo } from "@/components/lcm/page-howto";
import { DrawingThumb } from "@/components/lcm/drawing-thumb";
import { getOperatorByEmail } from "@/lib/lcm/permissions";
import {
  packingTableLineCount,
  packingTableOrders,
} from "@/lib/lcm/pack-queue";
import { printPackBoxLabelOrToast } from "@/lib/lcm/print-box-labels";
import { formatDate } from "@/lib/utils";

export const Route = createFileRoute("/pack")({
  component: PackingTablePage,
});

function PackingTablePage() {
  const shopOrders = useLcmStore((s) => s.shopOrders || []);
  const packLineIntoBox = useLcmStore((s) => s.packLineIntoBox);
  const shopPublicUrl = useLcmStore((s) => s.settings.shopPublicUrl);
  const email = useLcmStore((s) => s.currentUserEmail);
  const operators = useLcmStore((s) => s.operators);
  const me = getOperatorByEmail(operators, email);
  const myName = me?.name || "";

  const groups = useMemo(
    () => packingTableOrders(shopOrders),
    [shopOrders],
  );
  const lineCount = packingTableLineCount(groups);

  async function markPacked(orderId: string, lineId: string) {
    const r = packLineIntoBox(orderId, lineId, myName);
    if (!r.ok || !r.box) {
      toast.error(r.error || "Could not pack");
      return;
    }
    toast.success(`Packed ${r.box.partNumber} · qty ${r.box.qty}`);
    await printPackBoxLabelOrToast(r.box, shopPublicUrl);
  }

  return (
    <div className="mx-auto max-w-5xl space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight flex items-center gap-2">
            <Package className="h-7 w-7 text-[var(--color-primary)]" />
            Packing Table
          </h1>
          <p className="text-sm text-[var(--color-muted)] mt-1">
            Jobs ready to pack. Pack the parts, tap Packed — the 1.1×2 box
            label prints. Stick it on. Pam scans the QR to load the truck.
          </p>
        </div>
        <PageHowTo id="packing-table" />
      </div>

      <div className="flex flex-wrap items-center gap-2 text-sm">
        <Badge tone={groups.length ? "ready" : "neutral"}>
          {groups.length} order{groups.length === 1 ? "" : "s"} on the table
        </Badge>
        <span className="text-[var(--color-muted)]">
          {lineCount} line{lineCount === 1 ? "" : "s"} waiting
        </span>
      </div>

      {groups.length === 0 ? (
        <p className="text-sm text-[var(--color-muted)] text-center py-12">
          Nothing on the packing table. Finished jobs show here after they are
          marked ready for pack.
        </p>
      ) : (
        <div className="space-y-4">
          {groups.map((g) => (
            <Card key={g.orderId}>
              <CardHeader className="pb-2">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <CardTitle className="font-mono text-base">
                      {g.poNumber}
                    </CardTitle>
                    <CardDescription>
                      {g.customer || "—"}
                      {g.dueDate ? ` · Due ${formatDate(g.dueDate)}` : ""}
                    </CardDescription>
                  </div>
                  <Link
                    to="/po"
                    search={{ order: g.orderId }}
                    className="text-[10px] text-[var(--color-primary)]"
                  >
                    Open full PO
                  </Link>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                {g.lines.map((l) => (
                  <div
                    key={l.lineId}
                    className="flex items-center gap-3 rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface-2)] px-2.5 py-2"
                  >
                    <DrawingThumb size="lg" file={l.drawings[0]} />
                    <div className="min-w-0 flex-1">
                      <div className="font-mono font-semibold text-sm">
                        {l.partNumber || "—"}{" "}
                        <span className="text-xs font-normal">
                          Rev {l.revision || "—"}
                        </span>
                      </div>
                      <div className="text-xs text-[var(--color-muted)] line-clamp-2">
                        {l.description}
                      </div>
                      <div className="text-[11px] mt-0.5">
                        Qty <strong>{l.qty}</strong>
                        {l.readyForPackBy ? (
                          <span className="text-[var(--color-muted)]">
                            {" "}
                            · ready by {l.readyForPackBy}
                          </span>
                        ) : null}
                      </div>
                    </div>
                    <Button
                      type="button"
                      className="shrink-0 min-h-11"
                      onClick={() => void markPacked(l.orderId, l.lineId)}
                    >
                      <Printer className="h-4 w-4" /> Packed
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
