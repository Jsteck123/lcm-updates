/**
 * Desk assign workload — hours from quoted setup + run × qty.
 */
import type { Quote, ShopOrder, WorkQueueItem } from "./types";
import { normalizeComponents } from "./line-files";
import {
  getOpAssignment,
  isMultiMachinePart,
  quoteForPn,
  quotedHoursForOp,
  remainingTimedOps,
} from "./op-slots";
import { workQueueItemStillAssigned } from "./queue-display";

export type WorkloadBar = {
  name: string;
  hours: number;
  jobs: number;
};

function normPn(pn: string) {
  return String(pn || "")
    .trim()
    .toUpperCase();
}

/** Best quote match for a part number */
export function findQuoteForPart(
  quotes: Quote[],
  partNumber: string,
): Quote | undefined {
  const pn = normPn(partNumber);
  if (!pn) return undefined;
  const exact = quotes.filter((q) => normPn(q.partNumber) === pn);
  if (exact.length === 1) return exact[0];
  if (exact.length > 1) {
    return [...exact].sort((a, b) =>
      String(b.date || "").localeCompare(String(a.date || "")),
    )[0];
  }
  // Exact P/N only. Prefix match used to steal "3841" → quote "3".
  return undefined;
}

/** Quoted hours: sum(setup min) + sum(run min) × qty  → hours */
export function quotedHoursForPart(
  quotes: Quote[],
  partNumber: string,
  qty: number,
): number {
  const q = findQuoteForPart(quotes, partNumber);
  if (!q) return 0;
  const setupMin = (q.setupTimes || []).reduce((a, b) => a + (Number(b) || 0), 0);
  const runMinEach = (q.runTimes || []).reduce((a, b) => a + (Number(b) || 0), 0);
  const n = Math.max(1, Number(qty) || 1);
  return Math.round(((setupMin + runMinEach * n) / 60) * 10) / 10;
}

type LoadSlice = {
  machine: string;
  operator: string;
  partNumber: string;
  qty: number;
  hours: number;
  opIndex: number | null;
};

function pushHostSlices(
  out: LoadSlice[],
  quotes: Quote[],
  partNumber: string,
  qty: number,
  host: {
    officeAssignedTo?: string;
    officeAssignedMachine?: string;
    checkedOutBy?: string;
    checkedOutMachine?: string;
    opAssignments?: import("./types").ShopOpAssignment[];
  },
) {
  const quote = quoteForPn(quotes, partNumber);
  if (isMultiMachinePart(quote)) {
    for (const opIndex of remainingTimedOps(quote, host.opAssignments)) {
      const slot = getOpAssignment(host.opAssignments, opIndex);
      const op = (slot?.checkedOutBy || "").trim();
      if (!op) continue;
      out.push({
        machine: (
          slot?.checkedOutMachine ||
          slot?.officeAssignedMachine ||
          ""
        ).trim(),
        operator: op,
        partNumber,
        qty,
        hours: quotedHoursForOp(quote, opIndex, qty),
        opIndex,
      });
    }
    return;
  }
  const op = (host.checkedOutBy || "").trim();
  if (!op) return;
  out.push({
    machine: (host.checkedOutMachine || host.officeAssignedMachine || "").trim(),
    operator: op,
    partNumber,
    qty,
    hours: quotedHoursForPart(quotes, partNumber, qty),
    opIndex: null,
  });
}

function collectAssignedLoads(
  orders: ShopOrder[],
  quotes: Quote[],
): LoadSlice[] {
  const out: LoadSlice[] = [];
  for (const order of orders || []) {
    if (order.status === "cancelled" || order.deliveredAt) continue;
    for (const line of order.lines || []) {
      if (line.lineStatus === "cancelled") continue;
      if (line.readyForPack || line.linePacked) continue;
      const leftover = Math.max(
        0,
        (Number(line.qty) || 0) - (Number(line.qtyCompleted) || 0),
      );
      const comps = normalizeComponents(line);
      if (comps.length) {
        for (const c of comps) {
          if (c.complete) continue;
          const qty = c.qty || leftover || line.qty || 1;
          pushHostSlices(out, quotes, c.partNumber, qty, c);
        }
      }
      if (leftover <= 0) continue;
      pushHostSlices(out, quotes, line.partNumber, leftover, line);
    }
  }
  return out;
}

function collectQueueLoads(
  workQueue: WorkQueueItem[],
  quotes: Quote[],
  orders: ShopOrder[],
): LoadSlice[] {
  return (workQueue || [])
    .filter(
      (q) =>
        (q.status === "queued" ||
          q.status === "active" ||
          q.status === "held") &&
        workQueueItemStillAssigned(q, orders),
    )
    .map((q) => {
      const opIndex =
        typeof q.opIndex === "number" && Number.isFinite(q.opIndex)
          ? q.opIndex
          : null;
      const quote = quoteForPn(quotes, q.partNumber);
      const hours =
        opIndex != null
          ? quotedHoursForOp(quote, opIndex, q.qty || 1)
          : quotedHoursForPart(quotes, q.partNumber, q.qty || 1);
      return {
        machine: (q.machine || "").trim(),
        operator: (q.operatorName || "").trim(),
        partNumber: q.partNumber,
        qty: q.qty || 1,
        hours,
        opIndex,
      };
    });
}

function rollup(
  slices: LoadSlice[],
  key: "machine" | "operator",
  minHours = 0,
): WorkloadBar[] {
  const map = new Map<string, { hours: number; jobs: number }>();
  for (const s of slices) {
    const name = (s[key] || "").trim();
    if (!name) continue;
    const cur = map.get(name) || { hours: 0, jobs: 0 };
    cur.hours += s.hours || 0;
    cur.jobs += 1;
    map.set(name, cur);
  }
  return [...map.entries()]
    .map(([name, v]) => ({
      name,
      hours: Math.round(v.hours * 10) / 10,
      jobs: v.jobs,
    }))
    .filter((b) => b.hours >= minHours || b.jobs > 0)
    .sort((a, b) => b.hours - a.hours);
}

/**
 * Machine + operator booked hours from:
 * - work queue (running order)
 * - office / board assignments still open
 * Hours come from historical quote setup + run × qty when available.
 */
export function buildAssignWorkload(opts: {
  shopOrders: ShopOrder[];
  workQueue: WorkQueueItem[];
  quotes: Quote[];
  /** Floor list only — old quote nicknames like "Haas Lathe" stay off the chart. */
  officialMachines?: string[];
}): { machines: WorkloadBar[]; operators: WorkloadBar[] } {
  const slices = [
    ...collectQueueLoads(
      opts.workQueue || [],
      opts.quotes || [],
      opts.shopOrders || [],
    ),
    ...collectAssignedLoads(opts.shopOrders || [], opts.quotes || []),
  ];
  // de-dupe roughly by machine+operator+part (queue + office double-count)
  const seen = new Set<string>();
  const uniq: LoadSlice[] = [];
  for (const s of slices) {
    const k = `${s.machine}|${s.operator}|${normPn(s.partNumber)}|${s.qty}|${s.opIndex ?? "all"}`;
    if (seen.has(k)) continue;
    seen.add(k);
    uniq.push(s);
  }
  const listed = new Set(
    (opts.officialMachines || [])
      .map((m) => String(m || "").trim().toLowerCase())
      .filter(Boolean),
  );
  const machines = rollup(uniq, "machine").filter((b) =>
    listed.size === 0 ? true : listed.has(b.name.trim().toLowerCase()),
  );
  return {
    machines,
    operators: rollup(uniq, "operator"),
  };
}
