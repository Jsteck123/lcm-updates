import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Scissors, Printer, Check, Plus } from "lucide-react";
import { toast } from "sonner";
import { useLcmStore } from "@/store/lcm-store";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  activeCutTickets,
  cutTicketLabel,
  printCutTicketSheet,
  qtyAvailable,
  statusLabel,
} from "@/lib/lcm/cut-tickets";
import { getOperatorByEmail } from "@/lib/lcm/permissions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/saw")({
  component: SawQueuePage,
});

function SawQueuePage() {
  const cutTickets = useLcmStore((s) => s.cutTickets || []);
  const company = useLcmStore((s) => s.settings.companyName || "Lake Country Machine");
  const email = useLcmStore((s) => s.currentUserEmail);
  const operators = useLcmStore((s) => s.operators);
  const recordCutProgress = useLcmStore((s) => s.recordCutProgress);
  const skipCutTicket = useLcmStore((s) => s.skipCutTicket);
  const cancelCutTicket = useLcmStore((s) => s.cancelCutTicket);
  const writeCutActualsToQuote = useLcmStore((s) => s.writeCutActualsToQuote);
  const me = getOperatorByEmail(operators, email);
  const myName = me?.name || "";

  const [filter, setFilter] = useState<"active" | "all">("active");
  const [addQty, setAddQty] = useState<Record<string, string>>({});

  const list = useMemo(() => {
    const base =
      filter === "active" ? activeCutTickets(cutTickets) : [...cutTickets];
    return base.sort((a, b) => {
      const da = a.dueDate || "9999";
      const db = b.dueDate || "9999";
      if (da !== db) return da.localeCompare(db);
      return (b.requestedAt || "").localeCompare(a.requestedAt || "");
    });
  }, [cutTickets, filter]);

  function markCut(id: string) {
    const raw = addQty[id] ?? "1";
    const n = Math.max(1, Math.floor(Number(raw) || 1));
    const r = recordCutProgress(id, n, myName);
    if (!r.ok) {
      toast.error(r.error || "Failed");
      return;
    }
    toast.success(
      `Cut +${n} · now ${r.ticket?.qtyCut}/${r.ticket?.qtyRequested} · ${qtyAvailable(r.ticket!)} available for machine`,
    );
    setAddQty((s) => ({ ...s, [id]: "1" }));
  }

  return (
    <div className="mx-auto max-w-5xl space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight flex items-center gap-2">
            <Scissors className="h-7 w-7 text-[var(--color-primary)]" />
            Saw / Cut queue
          </h1>
          <p className="text-sm text-[var(--color-muted)] mt-1">
            Cut tickets from the floor (CAD sizes). Mark blanks as they come off —
            mills can start before the full qty is done.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            type="button"
            variant="secondary"
            onClick={() => {
              const ok = printCutTicketSheet(list, company);
              if (!ok) toast.error("Allow pop-ups to print");
            }}
          >
            <Printer className="h-4 w-4" /> Print list
          </Button>
          <Link
            to="/board"
            className="inline-flex items-center rounded-[var(--radius-md)] border border-[var(--color-border)] px-3 py-2 text-sm min-h-10"
          >
            Job board
          </Link>
        </div>
      </div>

      <div className="flex gap-2">
        {(
          [
            ["active", "Active"],
            ["all", "All"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setFilter(id)}
            className={cn(
              "rounded-full px-4 py-2 text-sm font-medium border min-h-10",
              filter === id
                ? "border-[var(--color-primary)] bg-[color-mix(in_oklab,var(--color-primary)_14%,transparent)] text-[var(--color-primary)]"
                : "border-[var(--color-border)] text-[var(--color-muted)]",
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {list.length === 0 ? (
        <Card>
          <CardContent className="py-10 text-center text-[var(--color-muted)] text-sm">
            No cut tickets yet. On the Job Board, hit{" "}
            <strong className="text-[var(--color-fg)]">Request cut</strong> on
            a tile to send sizes to the saw.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {list.map((t) => {
            const avail = qtyAvailable(t);
            const remaining = Math.max(
              0,
              (Number(t.qtyRequested) || 0) - (Number(t.qtyCut) || 0),
            );
            return (
              <Card key={t.id}>
                <CardHeader className="pb-2">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <CardTitle className="text-base font-mono">
                        {t.partNumber}{" "}
                        <span className="font-sans text-sm text-[var(--color-muted)]">
                          Rev {t.revision || "—"}
                        </span>
                      </CardTitle>
                      <CardDescription>
                        {t.customer} · PO {t.poNumber || "—"}
                        {t.dueDate ? ` · due ${t.dueDate.slice(0, 10)}` : ""}
                        {t.requestedMachine
                          ? ` · for ${t.requestedMachine}`
                          : ""}
                      </CardDescription>
                    </div>
                    <Badge
                      tone={
                        
                        t.status === "done" || t.status === "skipped"
                          ? "done"
                          : t.status === "partial" || t.status === "cutting"
                            ? "info"
                            : t.status === "cancelled"
                              ? "danger"
                              : "hold"
                      }
                    >
                      {statusLabel(t.status)}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid sm:grid-cols-3 gap-2 text-sm">
                    <div>
                      <div className="text-[11px] text-[var(--color-muted)] uppercase">
                        Material
                      </div>
                      <div>
                        {t.material} {t.materialType}
                        <div className="text-xs text-[var(--color-muted)]">
                          {t.stockShape}
                        </div>
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-[var(--color-muted)] uppercase">
                        Cut size
                      </div>
                      <div className="font-medium">{cutTicketLabel(t)}</div>
                      <div className="text-xs text-[var(--color-muted)]">
                        {t.process === "lathe" ? "Lathe" : "Mill"} · requested by{" "}
                        {t.requestedBy || "—"}
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-[var(--color-muted)] uppercase">
                        Qty
                      </div>
                      <div className="font-semibold tabular">
                        Cut {t.qtyCut} / {t.qtyRequested}
                      </div>
                      <div className="text-xs text-[var(--color-muted)]">
                        {avail} available · {t.qtyClaimed} claimed · {remaining}{" "}
                        left to cut
                      </div>
                    </div>
                  </div>
                  {t.notes ? (
                    <p className="text-xs text-[var(--color-muted)]">{t.notes}</p>
                  ) : null}

                  {t.status !== "cancelled" &&
                    t.status !== "skipped" &&
                    remaining > 0 && (
                      <div className="flex flex-wrap items-end gap-2 pt-1 border-t border-[var(--color-border)]">
                        <div className="space-y-1">
                          <Label className="text-[11px]">Mark cut qty</Label>
                          <Input
                            className="w-24"
                            inputMode="numeric"
                            value={addQty[t.id] ?? "1"}
                            onChange={(e) =>
                              setAddQty((s) => ({
                                ...s,
                                [t.id]: e.target.value,
                              }))
                            }
                          />
                        </div>
                        <Button type="button" onClick={() => markCut(t.id)}>
                          <Plus className="h-4 w-4" /> Mark cut
                        </Button>
                        <Button
                          type="button"
                          variant="secondary"
                          onClick={() => {
                            const r = recordCutProgress(
                              t.id,
                              remaining,
                              myName,
                            );
                            if (r.ok)
                              toast.success(
                                `All remaining cut · ${r.ticket?.qtyCut}/${r.ticket?.qtyRequested}`,
                              );
                            else toast.error(r.error || "Failed");
                          }}
                        >
                          <Check className="h-4 w-4" /> All remaining
                        </Button>
                      </div>
                    )}

                  <div className="flex flex-wrap gap-2">
                    {t.status !== "skipped" &&
                      t.status !== "cancelled" &&
                      t.status !== "done" && (
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            skipCutTicket(t.id, myName);
                            toast.message("Skipped saw — stock on hand");
                          }}
                        >
                          Skip saw / on hand
                        </Button>
                      )}
                    {t.status !== "cancelled" && (
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          cancelCutTicket(t.id);
                          toast.message("Ticket cancelled");
                        }}
                      >
                        Cancel ticket
                      </Button>
                    )}
                    {(t.status === "done" || t.status === "partial") &&
                      !t.writtenBackAt && (
                        <Button
                          type="button"
                          size="sm"
                          variant="secondary"
                          onClick={() => {
                            const r = writeCutActualsToQuote(t.id);
                            if (r.ok)
                              toast.success(
                                "Wrote actual size to quote (prices unchanged)",
                              );
                            else toast.error(r.error || "No matching quote");
                          }}
                        >
                          Write size to quote
                        </Button>
                      )}
                    {t.writtenBackAt && (
                      <span className="text-[11px] text-[var(--color-muted)] self-center">
                        Size written to quote
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
