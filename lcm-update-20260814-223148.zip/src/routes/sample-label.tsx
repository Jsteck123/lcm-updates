import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Printer, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { barcodeToDataUrl, scanUrlForBarcode } from "@/lib/lcm/barcode";
import { Button } from "@/components/ui/button";
import { Label, Select } from "@/components/ui/input";
import { useLcmStore } from "@/store/lcm-store";
import {
  QL_TAPES,
  isCompactTape,
  loadSavedTapeId,
  printBrotherSampleLabel,
  saveTapeId,
  tapeById,
} from "@/lib/lcm/brother-label-print";

/** Practice barcode for printing a test label — not auto-written into live inventory */
export const SAMPLE_BARCODE = "LCM-SAMPLE-01";

const LOCAL_SAMPLE = {
  barcode: SAMPLE_BARCODE,
  material: "Aluminum",
  materialType: "T6 6061",
  stockShape: "Round Stock",
  sizeNote: '1.5" dia x 12 ft',
  remainingLength: 144,
  originalLength: 144,
  location: "Rack A-1",
  unit: "in" as const,
};

export const Route = createFileRoute("/sample-label")({
  component: SampleLabelPage,
});

function SampleLabelPage() {
  const stockPiecesRaw = useLcmStore((s) => s.stockPieces);
  const stockPieces = stockPiecesRaw || [];
  const shopPublicUrl = useLcmStore((s) => s.settings.shopPublicUrl);
  const [qr, setQr] = useState("");
  const [tapeId, setTapeId] = useState<string>(() => loadSavedTapeId());

  const piece =
    stockPieces.find((p) => p.barcode === SAMPLE_BARCODE) || LOCAL_SAMPLE;
  const tape = tapeById(tapeId);
  const compact = isCompactTape(tape);

  useEffect(() => {
    const url = scanUrlForBarcode(SAMPLE_BARCODE, shopPublicUrl);
    void barcodeToDataUrl(url, 220).then(setQr);
  }, [shopPublicUrl]);

  function pickTape(id: string) {
    setTapeId(id);
    saveTapeId(id);
  }

  function printNow() {
    if (!qr) {
      toast.error("Wait for the barcode to finish drawing");
      return;
    }
    const r = printBrotherSampleLabel({
      tapeId,
      barcode: piece.barcode,
      qrDataUrl: qr,
      line1: `${piece.material} ${piece.materialType}`,
      line2: piece.sizeNote,
    });
    if (!r.ok) toast.error(r.error || "Could not open print");
    else
      toast.message(
        `Print window — paper must be ${tape.windowsPaper} (the line that says 1.1" x 1.6").`,
      );
  }

  return (
    <div className="mx-auto max-w-lg space-y-5 pb-10">
      <div className="flex items-center gap-2">
        <Link
          to="/inventory"
          className="inline-flex items-center justify-center gap-1.5 text-sm text-[var(--color-muted)] hover:text-[var(--color-fg)] min-h-11"
        >
          <ArrowLeft className="h-4 w-4" /> Inventory
        </Link>
      </div>

      <div className="space-y-2">
        <h1 className="text-2xl font-semibold tracking-tight">
          Sample barcode label
        </h1>
        <p className="text-sm text-[var(--color-muted)]">
          Look at the black cassette in the QL-810W — the DK number is printed
          on it. DK-2210 is a 100-foot continuous roll, not a 1.1 × 3.5 sticker.
        </p>
      </div>

      <div className="rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface)] px-3 py-3 space-y-2 text-sm leading-relaxed">
        <p className="font-medium">You just changed rolls</p>
        <ol className="list-decimal pl-5 space-y-1 text-[var(--color-muted)]">
          <li>Close the QL lid until it clicks. Orange light = lid or cassette not seated.</li>
          <li>Power the printer off and on so it re-reads the new cassette.</li>
          <li>
            Windows search → <strong>Printers & scanners</strong> → Brother
            QL-810W → open queue → cancel anything stuck from the 1.1 × 3.5 tests.
          </li>
          <li>
            In the print window pick paper <strong>{tape.windowsPaper}</strong>.
            Leaving “1.1" x 3"” / 1.1 × 3.5 selected is why continuous prints
            nothing.
          </li>
        </ol>
      </div>

      <div className="space-y-1.5">
        <Label>Tape in the printer</Label>
        <Select
          className="h-11"
          value={tapeId}
          onChange={(e) => pickTape(e.target.value)}
        >
          {QL_TAPES.map((t) => (
            <option key={t.id} value={t.id}>
              {t.label}
            </option>
          ))}
        </Select>
        <p className="text-xs text-[var(--color-muted)]">
          {tape.kind === "continuous"
            ? `Continuous roll. Each sticker is cut at ${tape.h}. Windows paper: ${tape.windowsPaper}.`
            : `Die-cut stickers. Windows paper: ${tape.windowsPaper}.`}
        </p>
      </div>

      <div
        className={compact ? "sample-ql-label compact" : "sample-ql-label"}
        style={{ width: tape.w, height: tape.h }}
      >
        {!compact && (
          <div className="sample-ql-name">LAKE COUNTRY MACHINE</div>
        )}
        {qr ? (
          <img src={qr} alt="" className="sample-ql-qr" />
        ) : (
          <div className="sample-ql-qr sample-ql-qr-empty" />
        )}
        <div className="sample-ql-text">
          <div className="sample-ql-code">{piece.barcode}</div>
          <div className="sample-ql-mat">
            {piece.material} {piece.materialType}
          </div>
          <div className="sample-ql-size">{piece.sizeNote}</div>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <Button type="button" className="min-h-11" onClick={printNow}>
          <Printer className="h-4 w-4" /> Print 1 label
        </Button>
      </div>

      <div className="text-sm text-[var(--color-muted)] space-y-1">
        <p>In the print window:</p>
        <ul className="list-disc pl-5 space-y-0.5">
          <li>Printer: Brother QL-810W</li>
          <li>Layout: Portrait</li>
          <li>
            Paper: <strong>{tape.windowsPaper}</strong>
            {tape.kind === "continuous" ? " " : ""}
          </li>
          <li>Margins: None · Headers: Off</li>
        </ul>
        <p>
          Still nothing? Cancel the Windows print queue, then print a Windows
          test page to that printer. If the test page also fails, the printer is
          asleep or Wi-Fi dropped — not LCM.
        </p>
      </div>

      <style>{`
        .sample-ql-label {
          box-sizing: border-box;
          padding: 0.06in 0.05in;
          border: 1px solid var(--color-border);
          background: #fff;
          color: #000;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          text-align: center;
          overflow: hidden;
        }
        .sample-ql-label.compact {
          flex-direction: row;
          padding: 0.04in 0.05in 0.04in 0.03in;
          gap: 0.04in;
          text-align: left;
        }
        .sample-ql-name {
          font-size: 6px;
          font-weight: 700;
          letter-spacing: 0.04em;
          line-height: 1.1;
        }
        .sample-ql-text {
          min-width: 0;
          flex: 1;
          display: flex;
          flex-direction: column;
          justify-content: center;
        }
        .sample-ql-code {
          font-family: ui-monospace, monospace;
          font-size: 9px;
          font-weight: 800;
          line-height: 1.08;
          white-space: nowrap;
        }
        .sample-ql-qr {
          width: 0.55in;
          height: 0.55in;
          object-fit: contain;
          flex-shrink: 0;
        }
        .sample-ql-label:not(.compact) .sample-ql-qr {
          width: 0.78in;
          height: 0.78in;
          margin: 0.04in 0;
        }
        .sample-ql-qr-empty { background: #eee; }
        .sample-ql-mat {
          font-size: 8px;
          font-weight: 800;
          line-height: 1.08;
        }
        .sample-ql-size {
          font-size: 8px;
          font-weight: 700;
          line-height: 1.08;
        }
      `}</style>
    </div>
  );
}
